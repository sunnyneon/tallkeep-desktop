//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CWH63Vgr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-OP4tIqrU.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-ButaonoO.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-pwwX9Fd9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-OP4tIqrU.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BnBFQnc1.js",
			"/assets/log-out-DELCRHmJ.js",
			"/assets/testers.functions-Bt-7Kj80.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CoL71AK9.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-2wHBc_cY.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-ChIFTDwc.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-c_fvtKez.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/dist-BybISOae.js",
			"/assets/dialog-COFRufnp.js",
			"/assets/queries-DTvcVRHg.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/label-B14pxyAQ.js",
			"/assets/textarea-CgOBsXQw.js",
			"/assets/shoebox-B0HINni_.js",
			"/assets/company-BwfNWiKB.js",
			"/assets/reports-Cm8yioUB.js",
			"/assets/access-DwIIRyVR.js",
			"/assets/theme-DKCABe4A.js",
			"/assets/Logo-UNHSu5nx.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-D6tKBtTz.js",
			"/assets/log-out-DELCRHmJ.js",
			"/assets/admin.functions-Deus-BtJ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-UNHSu5nx.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BrxuSBOh.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/label-B14pxyAQ.js",
			"/assets/Logo-UNHSu5nx.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-CSPN5593.js",
			"/assets/testers.functions-Bt-7Kj80.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/coupons.functions-DVD6mBZE.js",
			"/assets/buy.functions-ClJ7K6RP.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CAYY9R_t.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/downloads.functions-CSuJE0RZ.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Bd48L2EB.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/label-B14pxyAQ.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup--yv67KAX.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/label-B14pxyAQ.js",
			"/assets/Logo-UNHSu5nx.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-iPsUZdou.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/upgrade.functions-C5g6tAgi.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-u_8A3GZL.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/label-B14pxyAQ.js",
			"/assets/Logo-UNHSu5nx.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-C0zkS8ur.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-B0oZbnna.js", "/assets/StockDocList-CnoZyirR.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CW6SuDsG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/ai-Bw1EUDOI.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Dtd35Tbr.js",
			"/assets/BankConnections-DpvdZvq2.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-1-dFoTuf.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CvToM_iW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DpvdZvq2.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/ai-Bw1EUDOI.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BdeKeih6.js",
			"/assets/TxnEditor-XqxhHUrX.js",
			"/assets/feedWaiting-CFFyxHPF.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BWIolQlX.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-BOXwu_w_.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-oFxpZIbl.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/personal-69XYxKM2.js",
			"/assets/members-v0WOJtli.js",
			"/assets/WhoPicker-m_5INTAe.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DOm5OdFM.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-yR9uyn_y.js", "/assets/AccountRegister-BBK78DT_.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CVmJ5BUB.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BB-ke48F.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/money-CWWeG1EY.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BwL_JC0Z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Bw1EUDOI.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-CdjiSpS_.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-5Iao6FKI.js", "/assets/StockDocList-CnoZyirR.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DUNYk4At.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CDxXqV3Y.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-v0WOJtli.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-B4eny-oq.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DEVD4Gvo.js", "/assets/PartyList-IykmjiAX.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BklxUN5n.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CdzGtbvM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/storage.functions-ZxgoNpbn.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-B_BwcRpM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DxdeuK5M.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-DZIEaOZL.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CvUFwRg-.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DtQXpTgN.js", "/assets/ChangeHistory-BgKawkkQ.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household--6CZRZKp.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/members-v0WOJtli.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-Bvq6ZOoO.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/personal-69XYxKM2.js",
			"/assets/members-v0WOJtli.js",
			"/assets/WhoPicker-m_5INTAe.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-D1F9tjzA.js", "/assets/SalesList-CejWEmrm.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-Bee1lovU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BvFQHg5P.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-B19p4Mfl.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-Cb_pOaro.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/loans-BdeKeih6.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DS2iNzHi.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-B_3tumVy.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CgeAjRAM.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/personal-69XYxKM2.js",
			"/assets/members-v0WOJtli.js",
			"/assets/WhoPicker-m_5INTAe.js",
			"/assets/reminders-BItSlc9v.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BZirbN4s.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-Ck4GDq3P.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/personal-69XYxKM2.js",
			"/assets/members-v0WOJtli.js",
			"/assets/WhoPicker-m_5INTAe.js",
			"/assets/generateCategoricalChart-95mUM8n3.js",
			"/assets/Area-DXqwAvgk.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-C6P5IAzz.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/generateCategoricalChart-95mUM8n3.js",
			"/assets/PlCharts-DZIEaOZL.js",
			"/assets/BarChart-Cd3YssfP.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CAbDTVwz.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/balances-BOXwu_w_.js",
			"/assets/money-CWWeG1EY.js",
			"/assets/DecimalInput-CjJ9uXWL.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-D9W5KuAn.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-C7aYZiTv.js",
			"/assets/createServerFn-CgEn95Nr.js",
			"/assets/auth-middleware-DCF8kQ1k.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/storage.functions-ZxgoNpbn.js",
			"/assets/coupons.functions-DVD6mBZE.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-EeNhJ12A.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-B7K6LZUb.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/checkbox-CW0XR52R.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CT4DDetE.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-jelaytZb.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CudcrPJx.js", "/assets/SalesList-CejWEmrm.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-0dZg0xvi.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/ai-Bw1EUDOI.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-ZxgoNpbn.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DQuZzDoq.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/money-CWWeG1EY.js",
			"/assets/badge-C9xVLuVH.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-C7BaPFJV.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DO1Te_h-.js", "/assets/AccountRegister-BBK78DT_.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-C4-7W8jn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/MoneyAccountPick-DHZr6h_6.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DGmMTTSC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-CNjb5dz1.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/RepeatInvoice-D9Al6u8j.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-D-jesNVN.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-95mUM8n3.js",
			"/assets/BarChart-Cd3YssfP.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-S22-S0yO.js", "/assets/SalesList-CejWEmrm.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CYXcGNOE.js", "/assets/SalesList-CejWEmrm.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-C9YoIVZt.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-C88Phm2v.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/serials-CSxw0HSJ.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CgcAv8SX.js",
			"/assets/createServerFn-CgEn95Nr.js",
			"/assets/auth-middleware-DCF8kQ1k.js",
			"/assets/AppsCatalog-D8mLY792.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BVBumS3M.js",
			"/assets/switch-B_3tumVy.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-B4eny-oq.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DyHorT5f.js",
			"/assets/footers-CyGPPYpM.js",
			"/assets/PrintFrame-BeVgKG4G.js",
			"/assets/checkbox-CW0XR52R.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BneISKrj.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DeDxuAsF.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-D8mLY792.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-DpvdZvq2.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DDGzKo96.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/StockDialogs-DWtQhwgx.js",
			"/assets/photos-DyHorT5f.js",
			"/assets/stockmove-vpdAj8Sc.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-B1z8eG3d.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/loans-BdeKeih6.js",
			"/assets/feedWaiting-CFFyxHPF.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-ZxgoNpbn.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CKD8XtYX.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/PrintFrame-BeVgKG4G.js",
			"/assets/DocPdf-LnJzhyA7.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-KhnIW4NF.js",
			"/assets/createServerFn-CgEn95Nr.js",
			"/assets/auth-middleware-DCF8kQ1k.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/MoneyAccountPick-DHZr6h_6.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BneISKrj.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BxfFoJKU.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/StockDialogs-DWtQhwgx.js",
			"/assets/stockmove-vpdAj8Sc.js",
			"/assets/checkbox-CW0XR52R.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BHpK9HUs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/members-v0WOJtli.js",
			"/assets/WhoPicker-m_5INTAe.js",
			"/assets/reminders-BItSlc9v.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-Dmchj5f9.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/tickets.functions-C5Hx2JU0.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CESnbMMf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BneISKrj.js",
			"/assets/support.functions-ni0gZkM0.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CVapOLsY.js", "/assets/StockDocList-CnoZyirR.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-B_sh3_Nn.js", "/assets/PartyList-IykmjiAX.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-xk5tLC_u.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/tickets.functions-C5Hx2JU0.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-BD-GK7Ck.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/workorders-CFyZiPxh.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BPB8e8TT.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-BbwlqgFs.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/coupons.functions-DVD6mBZE.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DFfUZJap.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/AdminAccount-BgyS68Kj.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-Db-Ev2UH.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/downloads.functions-CSuJE0RZ.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BisUIw_r.js",
			"/assets/createServerFn-CgEn95Nr.js",
			"/assets/auth-middleware-DCF8kQ1k.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CoedHgYh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CdQ5cRqS.js",
			"/assets/testers.functions-Bt-7Kj80.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-C-EsW1YG.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-DZbwq1iK.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-ClJ7K6RP.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CJ7QNatT.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/textarea-CgOBsXQw.js",
			"/assets/support.functions-ni0gZkM0.js",
			"/assets/HelpParts-BpKMNOAB.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BJEgdLm7.js",
			"/assets/ManualFrame-BKN1OK54.js",
			"/assets/manual._slug-CQqf4md4.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BYyEECMJ.js",
			"/assets/createServerFn-CgEn95Nr.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-C2mL4ILj.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-C5g6tAgi.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-swHkprId.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Bw1EUDOI.js",
			"/assets/personal-69XYxKM2.js",
			"/assets/reminders-BItSlc9v.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B_yV2Ue5.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/AdminAccount-BgyS68Kj.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-B4yNLyAA.js", "/assets/ManualFrame-BKN1OK54.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CgWcFM1B.js", "/assets/AccountRegister-BBK78DT_.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DToumBe6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/OriginalLink-DbJ3G_Ep.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/realestate-Bj-4nQNz.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-vE6GUCe3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/realestate-Bj-4nQNz.js",
			"/assets/money-CWWeG1EY.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-D1Edkw_C.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-BtJmiZOb.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/SideList-DIypsg3f.js",
			"/assets/PartyHistory-DTOwWqoh.js",
			"/assets/tabs-Cu8uDRN_.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-hgOka1Wh.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/ChangeHistory-BgKawkkQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/SideList-DIypsg3f.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-CjJ9uXWL.js",
			"/assets/StockDialogs-DWtQhwgx.js",
			"/assets/NewProductDialog-9qZBYHYL.js",
			"/assets/MoneyAccountPick-DHZr6h_6.js",
			"/assets/footers-CyGPPYpM.js",
			"/assets/PrintFrame-BeVgKG4G.js",
			"/assets/serials-CSxw0HSJ.js",
			"/assets/SerialsBox-D_siLUVn.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DdEHEiFx.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BgKawkkQ.js",
			"/assets/switch-B_3tumVy.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-C9xVLuVH.js",
			"/assets/SideList-DIypsg3f.js",
			"/assets/tabs-Cu8uDRN_.js",
			"/assets/StockDialogs-DWtQhwgx.js",
			"/assets/photos-DyHorT5f.js",
			"/assets/stockmove-vpdAj8Sc.js",
			"/assets/serials-CSxw0HSJ.js",
			"/assets/SerialsBox-D_siLUVn.js",
			"/assets/workorders-CFyZiPxh.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-0BXv4Oqp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/ChangeHistory-BgKawkkQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/booksStart-BtJmiZOb.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/SideList-DIypsg3f.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-CjJ9uXWL.js",
			"/assets/NewProductDialog-9qZBYHYL.js",
			"/assets/MoneyAccountPick-DHZr6h_6.js",
			"/assets/footers-CyGPPYpM.js",
			"/assets/PrintFrame-BeVgKG4G.js",
			"/assets/cardpay-D-eTmLuM.js",
			"/assets/checkbox-CW0XR52R.js",
			"/assets/serials-CSxw0HSJ.js",
			"/assets/workorders-CFyZiPxh.js",
			"/assets/RepeatInvoice-D9Al6u8j.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-C5Hx2JU0.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CfMCkIoH.js",
			"/assets/select-DXx4pGbf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/SideList-DIypsg3f.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-Fzgydpoa.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/quickadd-Ddcw8UgV.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BneISKrj.js",
			"/assets/support.functions-ni0gZkM0.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-uyo3JKTg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0H4TEL08.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/SideList-DIypsg3f.js",
			"/assets/PartyHistory-DTOwWqoh.js",
			"/assets/tabs-Cu8uDRN_.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BXvOr4UG.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/accounting-DxdpWwp4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/sales-CdjiSpS_.js",
			"/assets/footers-CyGPPYpM.js",
			"/assets/tickets.functions-C5Hx2JU0.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-S3anQXhN.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/input-BhH1WDHs.js",
			"/assets/skeleton-BO2jDxH7.js",
			"/assets/AdminAccount-BgyS68Kj.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BsqQsxGu.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-Dxn7XrjC.js",
			"/assets/textarea-CgOBsXQw.js",
			"/assets/support-BneISKrj.js",
			"/assets/support.functions-ni0gZkM0.js",
			"/assets/HelpParts-BpKMNOAB.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CcBPmNBD.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BO2jDxH7.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
