//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DOu4R7Io.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-XB_ybvS_.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bw20J02D.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuWl1-_-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-XB_ybvS_.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-udcM1D8Q.js",
			"/assets/log-out-CBYFUWWo.js",
			"/assets/testers.functions-CUjP5rEn.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-BOCHCs9D.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CYM17qEY.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CA1LzuzU.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/dist-kaR494-N.js",
			"/assets/dialog-DBuFOcod.js",
			"/assets/queries-CoTwIZGh.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/label-BqJqcM9o.js",
			"/assets/textarea-BaZID4KH.js",
			"/assets/shoebox-DflhL8-P.js",
			"/assets/company-BAAB7oLB.js",
			"/assets/reports-DU1m_pTa.js",
			"/assets/access-n-RMpd0n.js",
			"/assets/LicenseCard-DokGUZru.js",
			"/assets/Logo-C1cJZAi-.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-B7Eu_5Vu.js",
			"/assets/log-out-CBYFUWWo.js",
			"/assets/admin.functions-BIJWC-hz.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-C1cJZAi-.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DgYj5xEq.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/label-BqJqcM9o.js",
			"/assets/Logo-C1cJZAi-.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DRqNoSVy.js",
			"/assets/testers.functions-CUjP5rEn.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/buy.functions-rFtzDI0U.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-wlnjpSuV.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/downloads.functions-_sandrGU.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-B32qQjIx.js",
			"/assets/testers.functions-CUjP5rEn.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/textarea-BaZID4KH.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CEHrkwwE.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/label-BqJqcM9o.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DgYp2BmI.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/label-BqJqcM9o.js",
			"/assets/Logo-C1cJZAi-.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CDMy44b5.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/upgrade.functions-B0wJwvJB.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-C1hwilIh.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/label-BqJqcM9o.js",
			"/assets/Logo-C1cJZAi-.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BRSxuS3N.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DCnTJc6U.js", "/assets/StockDocList-DkMHKlQb.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DJ-yexKH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/ai-64A5nqQh.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-B3Lhx7CO.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DcOwD3xg.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/ai-64A5nqQh.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/TxnEditor-DdJoC5Xc.js",
			"/assets/feedWaiting-DLL1S0nn.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BhdcGKYR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-BcEwr9c0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-C4DdaOlw.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-tFZSYDzF.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-B3hgtag3.js", "/assets/AccountRegister-C4vi8SUi.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-B17YhUku.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-B6Hn3SWR.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-UcRIhqOA.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-64A5nqQh.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-D0gD1-Vz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BWyB5rG3.js", "/assets/StockDocList-DkMHKlQb.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Dt-9Nyd_.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-tJuYZQdf.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-D8eV3kH3.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D5fpd9ti.js", "/assets/PartyList-B2CWl6MI.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DBzR0wwV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-C0ZxMziR.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/storage.functions-KA4_eHnf.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Dfj8iqNY.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BTkoO1IN.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BUFR3FpX.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BLLYk54V.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-Bu-2vrml.js", "/assets/ChangeHistory-D2gWi8BT.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-oM7jkO3v.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/members-B1ktLCoR.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BSgr3aPI.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-C4DdaOlw.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BX-LKRNG.js", "/assets/SalesList-B4NXj9TB.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal--xzm9AKw.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Dzjl1EQf.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BALkJ9Mn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-Cl0BP5LE.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/loans-DlX_C_YK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Cb1usbpZ.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-B1eNHWAZ.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-DgXdONll.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-C4DdaOlw.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BnSlbmly.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-Bwg3CvQj.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-C4DdaOlw.js",
			"/assets/generateCategoricalChart-BB8yD3K5.js",
			"/assets/Area-BpBC08XF.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CMLLGPff.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/generateCategoricalChart-BB8yD3K5.js",
			"/assets/PlCharts-BUFR3FpX.js",
			"/assets/BarChart-CSx2q9rj.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CyPHPYaX.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-OJj8hhmI.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-D2k-WIru.js",
			"/assets/createServerFn-2yPl2-0t.js",
			"/assets/auth-middleware-MyoM7OEC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/storage.functions-KA4_eHnf.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-TVf0uWWz.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-JvVsFb_T.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/checkbox-BO_O6z1m.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-D8Q4CVGM.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BnMDBBTo.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CelotYDy.js", "/assets/SalesList-B4NXj9TB.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DnwOznOh.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/ai-64A5nqQh.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-KA4_eHnf.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DhxKu2lg.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-DbxQcXMw.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-MdKA3jYe.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CNoRfjJA.js", "/assets/AccountRegister-C4vi8SUi.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Mn69SmMA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/MoneyAccountPick-CvgGpnru.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BEHmaQdZ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DCgwnYJ0.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/RepeatInvoice-D1PEzVvL.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-9xmY0NOY.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BB8yD3K5.js",
			"/assets/BarChart-CSx2q9rj.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BNT3AobE.js", "/assets/SalesList-B4NXj9TB.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DTJQ3D89.js", "/assets/SalesList-B4NXj9TB.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Dlqx7qPH.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-XOowgHwQ.js",
			"/assets/createServerFn-2yPl2-0t.js",
			"/assets/auth-middleware-MyoM7OEC.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DrqSOKYL.js",
			"/assets/switch-B1eNHWAZ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/QuickBooksImport-D8eV3kH3.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-BO_O6z1m.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-ovm2fxlp.js",
			"/assets/FeaturePicker-CV53VwTj.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BquRzQ1F.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/FeaturePicker-CV53VwTj.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-Bltardfr.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BtWr2kaI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DrR9HCG_.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/feedWaiting-DLL1S0nn.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-KA4_eHnf.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-iKtDX6D8.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/DocPdf-C28tKPZt.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-BvpoK4Ab.js",
			"/assets/createServerFn-2yPl2-0t.js",
			"/assets/auth-middleware-MyoM7OEC.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/MoneyAccountPick-CvgGpnru.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-lX0SMm_0.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/StockDialogs-BtWr2kaI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/checkbox-BO_O6z1m.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Cm-LB0Xf.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-C4DdaOlw.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DmVfZ3-N.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/tickets.functions-BzMHY6QA.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-C-UtopXC.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-BHwLnrCy.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-D3HbeuVs.js", "/assets/StockDocList-DkMHKlQb.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-SnArha7w.js", "/assets/PartyList-B2CWl6MI.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-NzTFSur2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/tickets.functions-BzMHY6QA.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DMjfT-jg.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DYLWpK0D.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-UX4I54aX.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/AdminAccount-C7gRIhwr.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-B0LOWwW2.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/downloads.functions-_sandrGU.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-3cntdpab.js",
			"/assets/createServerFn-2yPl2-0t.js",
			"/assets/auth-middleware-MyoM7OEC.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DV-W1btF.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BQm1vfqD.js",
			"/assets/testers.functions-CUjP5rEn.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-p_mOptSO.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BrPOgniU.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-rFtzDI0U.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-C4oGXOLg.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/textarea-BaZID4KH.js",
			"/assets/support.functions-BHwLnrCy.js",
			"/assets/HelpParts-BxMm-zOa.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-Bs1HVZYt.js",
			"/assets/ManualFrame-D30GE3PV.js",
			"/assets/manual._slug-Dw0ngs3b.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DeAy5KG5.js",
			"/assets/createServerFn-2yPl2-0t.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BYVRlxZj.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-B0wJwvJB.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-09i0_FMx.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-64A5nqQh.js",
			"/assets/personal-DMq024VV.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DWFV-F2d.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/AdminAccount-C7gRIhwr.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-61WGMxmm.js", "/assets/ManualFrame-D30GE3PV.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-qHHEnScg.js", "/assets/AccountRegister-C4vi8SUi.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-PGq-tR-N.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/OriginalLink-DUfQW7oR.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C7simqYG.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DRtRJPlF.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CZrtU11f.js",
			"/assets/PartyHistory-B0YBcGT9.js",
			"/assets/tabs-ynCCrlRR.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BG-WXX9y.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-D2gWi8BT.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CZrtU11f.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-C6FJtnvS.js",
			"/assets/MoneyAccountPick-CvgGpnru.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DNAKrLch.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BtWr2kaI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-D2gWi8BT.js",
			"/assets/switch-B1eNHWAZ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/badge-DbxQcXMw.js",
			"/assets/SideList-CZrtU11f.js",
			"/assets/tabs-ynCCrlRR.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DEVdA3W0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-D2gWi8BT.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CZrtU11f.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-C6FJtnvS.js",
			"/assets/MoneyAccountPick-CvgGpnru.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-BO_O6z1m.js",
			"/assets/workorders-CiTNPjMt.js",
			"/assets/RepeatInvoice-D1PEzVvL.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BzMHY6QA.js",
			"/assets/users.functions-ovm2fxlp.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-Dv68MIdd.js",
			"/assets/select-4Ox7NCZI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CZrtU11f.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-C0mPC0vO.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-BHwLnrCy.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BP6rXUzr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BTzGWpKb.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/SideList-CZrtU11f.js",
			"/assets/PartyHistory-B0YBcGT9.js",
			"/assets/tabs-ynCCrlRR.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-o_7yF_Kf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/footers-C066M_rV.js",
			"/assets/tickets.functions-BzMHY6QA.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DtU6Yfk5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/input-B3-YMKIQ.js",
			"/assets/skeleton-BwfZigcI.js",
			"/assets/AdminAccount-C7gRIhwr.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-Be1wV1kv.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-BdBqXjW8.js",
			"/assets/textarea-BaZID4KH.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-BHwLnrCy.js",
			"/assets/HelpParts-BxMm-zOa.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CpcYXWPy.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BwfZigcI.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
