//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay.server-CEi7GKV3.js
/** How the customer paid, in words for the books. */
var methodName = (m) => m === "us_bank_account" ? "Bank account (Stripe)" : m === "apple_pay" ? "Apple Pay (Stripe)" : m === "google_pay" ? "Google Pay (Stripe)" : m === "link" ? "Link (Stripe)" : "Card (Stripe)";
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var randomToken = (bytes = 18) => Buffer.from(crypto.getRandomValues(new Uint8Array(bytes))).toString("base64url");
/** Call Stripe. `account` makes the call on a connected business's account. */
async function stripe(path, form, account, method) {
	const key = process.env["STRIPE_SECRET_KEY"];
	if (!key) throw new Error("Card payments aren't open yet.");
	const base = process.env["STRIPE_API_BASE"] || "https://api.stripe.com";
	const body = form ? new URLSearchParams(Object.entries(form).filter(([, v]) => v !== void 0).map(([k, v]) => [k, String(v)])) : null;
	let res;
	try {
		res = await fetch(`${base}/v1/${path}`, {
			method: method ?? (body ? "POST" : "GET"),
			headers: {
				Authorization: `Bearer ${key}`,
				...body ? { "Content-Type": "application/x-www-form-urlencoded" } : {},
				...account ? { "Stripe-Account": account } : {}
			},
			body
		});
	} catch {
		throw new Error("Couldn't reach Stripe. Try again in a minute.");
	}
	const out = await res.json();
	if (!res.ok) throw new Error(out.error?.message ?? `Stripe said ${res.status}`);
	return out;
}
/** Tallkeep's share of each card payment, in percent (0 = none). */
async function appFeePct() {
	const { readPrices } = await import("./admin.functions-CC9-d3eH.mjs");
	const row = await readPrices().catch(() => null);
	const v = Number((row?.prices)?.payments?.app_fee_pct ?? 0);
	return Number.isFinite(v) && v > 0 && v < 10 ? v : 0;
}
async function merchantByKey(key) {
	if (!/^[A-Za-z0-9_-]{20,}$/.test(key)) return null;
	const { data } = await (await admin()).from("pay_merchants").select("*").eq("merchant_key", key).maybeSingle();
	return data ?? null;
}
var lastState = {};
var stripeState = (m) => m.stripe_account ? lastState[m.stripe_account] ?? null : null;
var NEED = {
	external_account: "a bank account for payouts",
	tos_acceptance: "accepting Stripe's terms",
	business_profile: "business details (website or product description)",
	individual: "the owner's details",
	representative: "the representative's details",
	company: "company details",
	owners: "the owners' details",
	directors: "the directors' details",
	executives: "the executives' details",
	documents: "an ID or company document"
};
var plainNeed = (k) => {
	const head = k.split(".")[0] ?? k;
	if (/verification\.document|\.document$/.test(k)) return "a photo ID or document";
	if (/ssn|id_number/.test(k)) return "the full SSN or tax ID";
	return NEED[head] ?? head.replace(/_/g, " ");
};
/** Ask Stripe whether the business can take payments yet; remember it. */
/** The Stripe account was made under Tallkeep's earlier Stripe account: start again. */
var lostAccess = (e) => /does not have access to account|No such account|application access may have been revoked/i.test(e?.message ?? "");
/** Forget a Stripe account that Tallkeep's current Stripe account can't reach. */
async function forgetAccount(m) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.from("pay_merchants").update({
		stripe_account: null,
		charges_enabled: false
	}).eq("id", m.id);
	return {
		...m,
		stripe_account: null,
		charges_enabled: false
	};
}
async function refreshMerchant(m) {
	if (!m.stripe_account) return m;
	let raw;
	try {
		raw = await stripe(`accounts/${m.stripe_account}`);
	} catch (e) {
		if (lostAccess(e)) return forgetAccount(m);
		throw e;
	}
	const a = raw;
	const enabled = !!a.charges_enabled;
	const due = [...a.requirements?.past_due ?? [], ...a.requirements?.currently_due ?? []];
	const reason = a.requirements?.disabled_reason ?? null;
	lastState = {
		...lastState,
		[m.stripe_account]: {
			submitted: !!a.details_submitted,
			needs: [...new Set(due.map(plainNeed))].slice(0, 6),
			why: !reason ? null : /pending_verification|under_review/.test(reason) ? "Stripe is checking the details (this can take a few minutes, sometimes a day)" : /past_due|requirements/.test(reason) ? "Stripe needs more details" : /rejected/.test(reason) ? "Stripe declined this account; contact Stripe support" : reason.replace(/[._]/g, " ")
		}
	};
	if (enabled !== m.charges_enabled) await (await admin()).from("pay_merchants").update({ charges_enabled: enabled }).eq("id", m.id);
	return {
		...m,
		charges_enabled: enabled
	};
}
/** A link for the business to finish (or start) setting up its Stripe account. */
async function onboardingLink(m, returnUrl) {
	return (await stripe("account_links", {
		account: m.stripe_account,
		type: "account_onboarding",
		refresh_url: returnUrl,
		return_url: returnUrl
	})).url;
}
/**
* A payment finished on Stripe: record it once. Asks Stripe itself (on the business's account)
* whether the checkout is paid, so a made-up message can't mark an invoice paid.
*/
async function fulfillPay(requestId, session) {
	const db = await admin();
	const { data: r } = await db.from("pay_requests").select("*").eq("id", requestId).maybeSingle();
	const req = r;
	if (!req) return null;
	if (req.status === "paid") return req;
	const { data: m } = await db.from("pay_merchants").select("*").eq("id", req.merchant_id).maybeSingle();
	const merchant = m;
	if (!merchant?.stripe_account) return req;
	const s = await stripe(`checkout/sessions/${encodeURIComponent(session)}?expand[]=payment_intent.latest_charge.balance_transaction&expand[]=payment_intent.payment_method`, void 0, merchant.stripe_account);
	if (s.metadata?.["pay_request"] !== req.id) return req;
	const pi = typeof s.payment_intent === "object" ? s.payment_intent : null;
	const charge = pi && typeof pi.latest_charge === "object" ? pi.latest_charge : null;
	const pmd = charge?.payment_method_details;
	const pm = pi?.payment_method ?? null;
	const method = pmd?.card?.wallet?.type ?? pm?.card?.wallet?.type ?? pmd?.type ?? pm?.type ?? null;
	if (s.payment_status !== "paid") {
		if (s.status === "complete" && !req.pending_at) {
			const pending = {
				pending_at: (/* @__PURE__ */ new Date()).toISOString(),
				method,
				stripe_session: session
			};
			await db.from("pay_requests").update(pending).eq("id", req.id).eq("status", "open");
			return {
				...req,
				...pending
			};
		}
		return req;
	}
	const bt = charge && typeof charge.balance_transaction === "object" ? charge.balance_transaction : null;
	const done = {
		status: "paid",
		stripe_session: session,
		payment_intent: pi?.id ?? (typeof s.payment_intent === "string" ? s.payment_intent : null),
		paid_cents: s.amount_total ?? req.amount_cents,
		fee_cents: bt?.fee ?? null,
		method,
		paid_at: (/* @__PURE__ */ new Date()).toISOString(),
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	};
	const { data: up } = await db.from("pay_requests").update(done).eq("id", req.id).eq("status", "open").select("*").maybeSingle();
	return up ?? {
		...req,
		...done
	};
}
//#endregion
export { admin, appFeePct, forgetAccount, fulfillPay, lostAccess, merchantByKey, methodName, onboardingLink, randomToken, refreshMerchant, stripe, stripeState };
