import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B4zWMztx.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/users.functions-C5JXyVjc.js
/** The account (customer) a person belongs to. */
/** People in an account. */
/** The account's Owner (database step 75); null when there is none or the step isn't run. */
/** Only admins may manage users, and only the people in their own account. With `owner`,
*  only the account's Owner (an account without one: any admin). */
/** Stop when the account is read-only or its plan has no room for another person. */
/** Stop if this person isn't in the admin's account. */
var listUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d96fc76850779782acfe0d57c8df91435fcd2dbdbbe157b34f6d9842c0ffc4b6"));
var addUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^\S+@\S+\.\S+$/.test(d.email)) throw new Error("Type a valid email.");
	if ((d.password ?? "").length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(createSsrRpc("57ddaa5e4421dbf7df4d9f414643f1bb27a4c291bf5708d6c31cd31cadffedf0"));
var changeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.password != null && d.password.length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(createSsrRpc("bf7e244e8d039b3b242642889b54fe2c274ff956811728d8b7818fd4aa2b3bd6"));
/** Open a company for someone (or not), as its admin, all sections or some sections. */
var setCompanyAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("3428c6d6ad7cd8fa7491ab7411d6d8472cd18aba914aa7ac7fd3b8eec2fb01e4"));
var removeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("9361df1a94e7b3318a7f52ef7419757434e15b7dead8b1cb6636b5adf3d5a46d"));
/** The Owner hands the role to another admin in the account. */
var handOverOwner = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("b87d33d66f88c754a25edb36b521a4273fbe7196266c87d0ade8aaec6f498df0"));
/** Names for the Sales rep menu: everyone who can sign in (staff may call this). */
var listRepNames = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("64019a9e45f7e8b0375e3d14f1984dc6e6493f506a342471c10221dced5b5d46"));
//#endregion
export { listUsers as a, listRepNames as i, changeUser as n, removeUser as o, handOverOwner as r, setCompanyAccess as s, addUser as t };
