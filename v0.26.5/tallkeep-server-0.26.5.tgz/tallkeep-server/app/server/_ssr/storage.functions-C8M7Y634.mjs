import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B4zWMztx.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/storage.functions-C8M7Y634.js
/**
* How much space an account's kept files take (statements, receipts, photos), and how much its
* online plan includes. The desktop app has no limit: files stay on the office computer.
*/
var getStorage = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("1acd810adfe8cc90c5543dff8b075033311630f73f88b295ecf5aa9bfb29a954"));
/** "1.2 MB", "3.4 GB". */
function fmtBytes(n) {
	if (n < 1024) return `${n} bytes`;
	const u = [
		"KB",
		"MB",
		"GB",
		"TB"
	];
	let v = n / 1024;
	let i = 0;
	while (v >= 1024 && i < u.length - 1) {
		v /= 1024;
		i++;
	}
	return `${v >= 10 ? Math.round(v) : v.toFixed(1)} ${u[i]}`;
}
//#endregion
export { getStorage as n, fmtBytes as t };
