-- Tallkeep — step 35: short-term stays from Airbnb, VRBO and Booking.com.
--
-- * stay_feeds: a unit's calendar link from Airbnb/VRBO/Booking.com (the "export calendar"
--   link). Tallkeep reads it and adds the bookings as stays, moves them when dates change, and
--   cancels the ones that disappear.
-- * units.calendar_token: the secret part of the unit's own Tallkeep calendar link, to paste into
--   Airbnb/VRBO so they block the nights booked elsewhere.
-- * stays.source / feed_uid: where a stay came from (typed in, a calendar, an earnings file) and
--   which calendar booking it is, so it's never added twice.

alter table public.units add column if not exists calendar_token uuid not null default gen_random_uuid();
create unique index if not exists units_calendar_token_idx on public.units (calendar_token);

alter table public.stays add column if not exists source text not null default 'manual';
do $$ begin
  alter table public.stays add constraint stays_source_check check (source in ('manual', 'calendar', 'import'));
exception when duplicate_object then null; end $$;
alter table public.stays add column if not exists feed_uid text;
create unique index if not exists stays_feed_uid_idx on public.stays (unit_id, feed_uid) where feed_uid is not null;
create index if not exists stays_confirmation_idx on public.stays (company_id, confirmation) where confirmation is not null;

create table if not exists public.stay_feeds (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  unit_id uuid not null references public.units(id) on delete cascade,
  channel text not null default 'airbnb' check (channel in ('airbnb','vrbo','booking','direct','other')),
  url text not null,
  last_synced timestamptz,
  last_result text,
  created_at timestamptz not null default now()
);
create index if not exists stay_feeds_unit_idx on public.stay_feeds (unit_id);

alter table public.stay_feeds enable row level security;
drop policy if exists "Staff can use" on public.stay_feeds;
create policy "Staff can use" on public.stay_feeds for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()));
grant select, insert, update, delete on public.stay_feeds to authenticated;

-- "Other fees" can be below zero (an earnings file that paid a little less): post it either way.
create or replace function public.post_stay(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare s record; bank uuid; memo text;
begin
  delete from public.journal_entries where source_type = 'stay' and source_id = _id;
  select st.*, u.property_id, u.name as unit into s
    from public.stays st join public.units u on u.id = st.unit_id
   where st.id = _id;
  if s.id is null or s.paid_on is null or not public.books_open(s.company_id, s.paid_on) then return; end if;
  perform public.seed_short_stay_accounts(s.company_id);
  bank := coalesce(s.account_id,
    (select default_bank_account_id from public.company_settings where company_id = s.company_id),
    public.acct(s.company_id, 'bank'));
  memo := s.guest_name || ' · ' || to_char(s.check_in, 'Mon DD') || '–' || to_char(s.check_out, 'Mon DD');
  perform public.write_entry(s.company_id, s.paid_on, 'stay', s.id, coalesce(s.confirmation, s.unit),
    'Stay · ' || memo,
    jsonb_build_array(
      jsonb_build_object('account', bank, 'debit', greatest(s.payout, 0), 'credit', greatest(-s.payout, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'platform_fees'), 'debit', greatest(s.platform_fee, 0), 'credit', greatest(-s.platform_fee, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'stay_income'), 'credit', greatest(s.rent, 0), 'debit', greatest(-s.rent, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'cleaning_income'), 'credit', greatest(s.cleaning_fee, 0), 'debit', greatest(-s.cleaning_fee, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'guest_fees'), 'credit', greatest(s.other_fees, 0), 'debit', greatest(-s.other_fees, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'lodging_tax'), 'credit', greatest(s.taxes, 0), 'debit', greatest(-s.taxes, 0), 'property', s.property_id, 'memo', memo)));
end $$;
