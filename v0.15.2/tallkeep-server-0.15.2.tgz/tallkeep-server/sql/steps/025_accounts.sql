-- SunRise Office / Tallkeep — step 25: customer accounts ("orgs") and free-trial sign-up.
--
-- * orgs: one per customer (a business owner and everything they run). Our own group is the first
--   one (is_platform = true). Holds the trial / subscription status.
-- * org_members: which account each person belongs to (one account per person).
-- * companies.org_id: every company belongs to one account.
-- * Admins are admins of THEIR account only: they see and manage only their account's companies,
--   members and roles. All business tables already require the active company, and you can only
--   open a company of your own account.
-- * start_trial(): a new person who just signed up makes their account and first company
--   (90 days free). make_company() is the shared, server-only way to set up a company.
-- Security: org tables are read-only for signed-in people (their own account only); changes go
-- through the functions below or the server.

create table if not exists public.orgs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  status text not null default 'trial' check (status in ('trial','active','past_due','canceled')),
  trial_ends_at timestamptz,
  is_platform boolean not null default false,
  created_by uuid,
  created_at timestamptz not null default now()
);

grant select on public.orgs to authenticated;
grant select, insert, update, delete on public.orgs to service_role;

create table if not exists public.org_members (
  org_id uuid not null references public.orgs(id) on delete cascade,
  user_id uuid not null,
  created_at timestamptz not null default now(),
  primary key (org_id, user_id),
  unique (user_id)
);

grant select on public.org_members to authenticated;
grant select, insert, update, delete on public.org_members to service_role;

alter table public.companies add column if not exists org_id uuid references public.orgs(id) on delete cascade;

-- Everything that exists today belongs to our own group.
do $$
declare o uuid;
begin
  select id into o from public.orgs where is_platform order by created_at limit 1;
  if o is null then
    insert into public.orgs (name, status, is_platform)
    values (coalesce((select name from public.companies order by created_at limit 1), 'SunRise LED Inc.'), 'active', true)
    returning id into o;
  end if;
  update public.companies set org_id = o where org_id is null;
  insert into public.org_members (org_id, user_id)
    select distinct o, user_id from public.user_roles
  on conflict do nothing;
end $$;

-- (org_id becomes required in step 26, after this step fills it in.)
create index if not exists companies_org_idx on public.companies (org_id);

-- The account a person belongs to.
create or replace function public.org_of(_uid uuid)
returns uuid language sql stable security definer set search_path = public as $$
  select org_id from public.org_members where user_id = _uid
$$;
create or replace function public.my_org()
returns uuid language sql stable security definer set search_path = public as $$
  select public.org_of(auth.uid())
$$;
grant execute on function public.org_of(uuid) to authenticated;
grant execute on function public.my_org() to authenticated;

alter table public.orgs enable row level security;
drop policy if exists "See my account" on public.orgs;
create policy "See my account" on public.orgs for select to authenticated
  using (id = public.my_org());

alter table public.org_members enable row level security;
drop policy if exists "See my account's people" on public.org_members;
create policy "See my account's people" on public.org_members for select to authenticated
  using (org_id = public.my_org());

-- You can open a company only in your own account: admins every one, staff the ones they're in.
create or replace function public.can_use_company(_uid uuid, _c uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.companies c where c.id = _c and c.org_id = public.org_of(_uid))
     and (public.has_role(_uid, 'admin')
          or exists (select 1 from public.company_members where user_id = _uid and company_id = _c))
$$;

-- Companies: admins rename only their own account's companies.
drop policy if exists "Admins rename companies" on public.companies;
create policy "Admins rename companies" on public.companies for update to authenticated
  using (public.has_role(auth.uid(), 'admin') and org_id = public.my_org())
  with check (public.has_role(auth.uid(), 'admin') and org_id = public.my_org());

-- Company members: only within your own account.
drop policy if exists "See members" on public.company_members;
create policy "See members" on public.company_members for select to authenticated
  using (user_id = auth.uid()
         or (public.has_role(auth.uid(), 'admin')
             and exists (select 1 from public.companies c where c.id = company_id and c.org_id = public.my_org())));
drop policy if exists "Admins manage members" on public.company_members;
create policy "Admins manage members" on public.company_members for all to authenticated
  using (public.has_role(auth.uid(), 'admin')
         and exists (select 1 from public.companies c where c.id = company_id and c.org_id = public.my_org()))
  with check (public.has_role(auth.uid(), 'admin')
         and exists (select 1 from public.companies c where c.id = company_id and c.org_id = public.my_org())
         and public.org_of(user_id) = public.my_org());

-- Roles: admins see and change only people in their own account.
drop policy if exists "Users see their own roles" on public.user_roles;
create policy "Users see their own roles" on public.user_roles for select to authenticated
  using (user_id = auth.uid()
         or (public.has_role(auth.uid(), 'admin') and public.org_of(user_id) = public.my_org()));
drop policy if exists "Admins manage roles" on public.user_roles;
create policy "Admins manage roles" on public.user_roles for all to authenticated
  using (public.has_role(auth.uid(), 'admin') and public.org_of(user_id) = public.my_org())
  with check (public.has_role(auth.uid(), 'admin') and public.org_of(user_id) = public.my_org());

-- Set up a company in an account: settings (which seeds the chart of accounts), document numbers,
-- payment terms and price lists copied from _src (or from our first company for a new account).
-- Server only; people use create_company() or start_trial().
create or replace function public.make_company(_org uuid, _name text, _business_type text,
                                               _addons text[], _uid uuid, _src uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare n uuid; src uuid := _src;
begin
  if src is null then
    select c.id into src from public.companies c join public.orgs o on o.id = c.org_id
     where o.is_platform order by c.created_at limit 1;
  end if;
  insert into public.companies (name, org_id) values (_name, _org) returning id into n;
  if _uid is not null then
    insert into public.company_members (company_id, user_id) values (n, _uid) on conflict do nothing;
  end if;
  insert into public.company_settings (company_id, name, business_type, addons)
  values (n, _name, coalesce(_business_type, 'products'),
          coalesce(_addons, array['sales','purchasing','inventory','accounting']));
  insert into public.doc_counters (company_id, kind, prefix, next_number)
    select n, kind, prefix, case when kind = 'rma' then 100001 else 1001 end
      from public.doc_counters where company_id = src
  on conflict do nothing;
  insert into public.payment_terms (company_id, name, days_due, is_active)
    select n, name, days_due, is_active from public.payment_terms where company_id = src;
  insert into public.price_lists (company_id, name, is_default, is_active)
    select n, name, is_default, is_active from public.price_lists where company_id = src;
  return n;
end $$;
revoke execute on function public.make_company(uuid, text, text, text[], uuid, uuid) from public, anon, authenticated;
grant execute on function public.make_company(uuid, text, text, text[], uuid, uuid) to service_role;

-- Add a company (admin): in your own account, copied from the company you're working in.
create or replace function public.create_company(_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare n uuid; o uuid := public.my_org();
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can add a company.'; end if;
  if o is null then raise exception 'Your account is not set up yet.'; end if;
  if coalesce(trim(_name), '') = '' then raise exception 'Type the company name.'; end if;
  n := public.make_company(o, trim(_name), null, null, auth.uid(), public.active_company());
  -- Same taxes as the company you're working in.
  insert into public.tax_rates (company_id, name, rate, is_active)
    select n, name, rate, is_active from public.tax_rates where company_id = public.active_company();
  return n;
end $$;
grant execute on function public.create_company(text) to authenticated;

-- A person who just signed up: make their account (90 days free), make them its admin, and set up
-- their first company.
create or replace function public.start_trial(_company text, _business_type text, _addons text[])
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); o uuid; n uuid;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if exists (select 1 from public.org_members where user_id = uid)
     or exists (select 1 from public.user_roles where user_id = uid) then
    raise exception 'You already have an account. Sign in to open it.';
  end if;
  if coalesce(trim(_company), '') = '' then raise exception 'Type your company name.'; end if;
  if length(trim(_company)) > 120 then raise exception 'That company name is too long.'; end if;
  insert into public.orgs (name, status, trial_ends_at, created_by)
  values (trim(_company), 'trial', now() + interval '90 days', uid)
  returning id into o;
  insert into public.org_members (org_id, user_id) values (o, uid);
  insert into public.user_roles (user_id, role) values (uid, 'admin');
  n := public.make_company(o, trim(_company), _business_type,
                           (select array(select x from unnest(_addons) x
                                          where x in ('sales','purchasing','inventory','accounting',
                                                      'work_orders','tickets','real_estate','tech_pay'))),
                           uid, null);
  insert into public.user_company (user_id, company_id) values (uid, n)
  on conflict (user_id) do update set company_id = excluded.company_id;
  return n;
end $$;
grant execute on function public.start_trial(text, text, text[]) to authenticated;
