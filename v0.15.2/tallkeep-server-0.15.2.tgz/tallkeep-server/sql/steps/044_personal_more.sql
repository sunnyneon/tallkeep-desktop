-- Tallkeep — step 44: more for personal money.
--
-- * money_reminders: bills to remember (due day, autopay or not) and subscriptions (what they
--   cost each week/month/quarter/year), with the next date and what was last paid.
-- * household_members: the people in a household (you, a spouse, a child…). Each account can
--   belong to one of them, or be joint (no one), so pages can show the household or one person.
-- * Crypto tax add-on: tax_wallets (an exchange account or wallet), tax_records (each buy, sell,
--   reward or move, from an exchange's history file), tax_methods (FIFO/HIFO/LIFO per year).
--   Gains are worked out from these when the Tax page opens; nothing here touches the books.

-- ---------- Bills and subscriptions ----------
create table if not exists public.money_reminders (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  kind text not null default 'bill' check (kind in ('bill','subscription')),
  name text not null,
  amount numeric(14,2),                          -- empty when it changes (like a power bill)
  every text not null default 'month' check (every in ('week','month','quarter','year')),
  next_date date not null,
  account_id uuid references public.accounts(id) on delete set null,          -- paid from
  category_id uuid references public.accounts(id) on delete set null,         -- what it's for
  autopay boolean not null default false,
  status text not null default 'active' check (status in ('active','paused','cancelled')),
  match_text text,                               -- words on the bank/card line, to see it was paid
  last_paid date,
  member_id uuid,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists money_reminders_company_idx on public.money_reminders (company_id, status, next_date);

-- ---------- Household members ----------
create table if not exists public.household_members (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  name text not null,
  color text,
  sort int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.accounts add column if not exists member_id uuid
  references public.household_members(id) on delete set null;
do $$ begin
  alter table public.money_reminders add constraint money_reminders_member_fk
    foreign key (member_id) references public.household_members(id) on delete set null;
exception when duplicate_object then null; end $$;

-- ---------- Crypto and investment tax ----------
create table if not exists public.tax_wallets (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  name text not null,                            -- Coinbase, Kraken, Ledger…
  source text not null default 'other',          -- coinbase, kraken, other
  member_id uuid references public.household_members(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.tax_records (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  wallet_id uuid not null references public.tax_wallets(id) on delete cascade,
  happened_at timestamptz not null,
  kind text not null check (kind in ('buy','sell','income','send','receive','fee','trade_in','trade_out','ignore')),
  asset text not null,                           -- BTC, ETH…
  qty numeric(30,12) not null,                   -- always positive
  usd numeric(18,2),                             -- value in dollars at the time (cost for buys, proceeds for sells)
  fee_usd numeric(18,2) not null default 0,
  note text,
  source_id text,                                -- the exchange's own id, so a file isn't read twice
  needs_review boolean not null default false,
  created_at timestamptz not null default now()
);
create unique index if not exists tax_records_source_idx on public.tax_records (company_id, wallet_id, source_id)
  where source_id is not null;
create index if not exists tax_records_company_idx on public.tax_records (company_id, happened_at);

create table if not exists public.tax_methods (
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  year int not null,
  method text not null default 'fifo' check (method in ('fifo','hifo','lifo')),
  primary key (company_id, year)
);

do $$
declare t text;
begin
  foreach t in array array['money_reminders','household_members','tax_wallets','tax_records','tax_methods'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('grant select, insert, update, delete on public.%I to service_role', t);
  end loop;
end $$;
