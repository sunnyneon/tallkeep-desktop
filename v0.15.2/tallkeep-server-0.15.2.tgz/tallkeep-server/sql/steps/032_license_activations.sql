-- Tallkeep — step 32: license activation. Each desktop license key works on a set number of office
-- computers (usually one: the computer that keeps the books). The office computer checks its key
-- with our server when it's entered and about once a day after that; the server answers whether
-- the key is one we made, still on, and on this computer.
--
-- * desktop_licenses.computers: how many office computers the key may run on.
-- * desktop_activations: the computers using each key, and when each was last seen. A computer not
--   seen for 30 days frees its place automatically (a replaced computer), or the owner releases it
--   in the owner panel.
-- Only the server (service role) reads or writes these.

alter table public.desktop_licenses add column if not exists computers int not null default 1;

create table if not exists public.desktop_activations (
  id uuid primary key default gen_random_uuid(),
  license_id text not null references public.desktop_licenses(id) on delete cascade,
  machine text not null,                 -- a one-way code for the computer (not its real ID)
  machine_name text,                     -- the Windows computer name, to recognize it
  app_version text,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  released_at timestamptz,
  unique (license_id, machine)
);
create index if not exists desktop_activations_license_idx on public.desktop_activations (license_id);
alter table public.desktop_activations enable row level security;
revoke all on public.desktop_activations from anon, authenticated;
grant select, insert, update, delete on public.desktop_activations to service_role;
