-- Tallkeep — step 39: renewing updates and adding companies or people to a license bought
-- earlier. Each paid upgrade is kept here (once per Stripe checkout); the license keeps its number
-- and gets a new key, which the office computer picks up by itself at its next check.
create table if not exists public.license_upgrades (
  id uuid primary key default gen_random_uuid(),
  license_id text not null references public.desktop_licenses(id) on delete cascade,
  stripe_session text not null unique,
  renew_years int not null default 0,
  add_companies int not null default 0,
  add_users int not null default 0,
  paid_cents int,
  created_at timestamptz not null default now()
);
alter table public.license_upgrades enable row level security;
revoke all on public.license_upgrades from anon, authenticated;
grant select, insert, update, delete on public.license_upgrades to service_role;
