-- Tallkeep — step 36: card payments (Pay now with Stripe), in each business's books.
--
-- * A card payment lands in a "Stripe" account (money held at Stripe until it pays out to the
--   bank), and Stripe's fee is recorded as an expense, so the payout to the bank matches.
-- * payments.fee: the card fee taken from this payment. payments.external_ref: Stripe's payment id,
--   so a payment is never recorded twice.
-- * sales_orders.pay_url: the invoice's "Pay now" link, for emails and statements.

alter table public.payments add column if not exists fee numeric(14,2) not null default 0;
alter table public.payments add column if not exists external_ref text;
create unique index if not exists payments_external_ref_idx on public.payments (company_id, external_ref)
  where external_ref is not null;
alter table public.sales_orders add column if not exists pay_url text;

create or replace function public.seed_card_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, x.key
    from (values
      ('1060', 'Stripe', 'asset', 'bank', 'stripe'),
      ('6170', 'Card Processing Fees', 'expense', 'expense', 'card_fees')
    ) as x(number, name, type, kind, key)
   where not exists (select 1 from public.accounts a where a.company_id = _co
                      and ((x.key is not null and a.key = x.key) or a.number = x.number));
end $$;
revoke all on function public.seed_card_accounts(uuid) from public, anon;
grant execute on function public.seed_card_accounts(uuid) to authenticated, service_role;

-- A payment into the books (same as step 21, plus the card fee).
create or replace function public.post_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; co uuid; bank uuid; who uuid; ref text;
begin
  delete from public.journal_entries where source_type in ('payment', 'po_payment') and source_id = _id;
  select * into p from public.payments where id = _id;
  if p.id is null or p.check_id is not null then return; end if;
  if p.sales_order_id is not null then
    select company_id, customer_id, number into co, who, ref from public.sales_orders where id = p.sales_order_id;
  else
    select company_id, vendor_id, number into co, who, ref from public.purchase_orders where id = p.purchase_order_id;
  end if;
  if co is null or not public.books_open(co, p.paid_on::date) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = co),
    public.acct(co, 'bank'));
  if p.sales_order_id is not null then
    if coalesce(p.fee, 0) <> 0 then perform public.seed_card_accounts(co); end if;
    perform public.write_entry(co, p.paid_on::date, 'payment', p.id, ref, 'Payment for ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', bank, 'debit', p.amount - coalesce(p.fee, 0), 'customer', who),
        jsonb_build_object('account', public.acct(co, 'card_fees'), 'debit', coalesce(p.fee, 0), 'customer', who,
                           'memo', 'Card fee'),
        jsonb_build_object('account', public.acct(co, 'ar'), 'credit', p.amount, 'customer', who)));
  else
    perform public.write_entry(co, p.paid_on::date, 'po_payment', p.id, ref, 'Paid ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'ap'), 'debit', p.amount, 'vendor', who),
        jsonb_build_object('account', bank, 'credit', p.amount, 'vendor', who)));
  end if;
end $$;
