-- Tallkeep — step 45: access per company.
--
-- Before: a person was Admin (every company) or Staff, with one set of sections for all the
-- companies they open. Now, for each company they open (company_members), they can be:
--   * an admin of that company (settings and deleting there, but not users, plan or other companies),
--   * every section, or
--   * only some sections (zones).
-- Admins of every company (user_roles.role = 'admin') stay as they are: they also manage users,
-- the plan and backups.

alter table public.company_members add column if not exists is_admin boolean not null default false;
alter table public.company_members add column if not exists zones text[];

-- Sections someone was limited to before now apply to each company they open.
update public.company_members cm set zones = ur.zones
  from public.user_roles ur
 where ur.user_id = cm.user_id and ur.role <> 'admin' and ur.zones is not null and cm.zones is null;
update public.user_roles set zones = null where role <> 'admin' and zones is not null;

-- ---------- Sections: per company ----------
create or replace function public.has_zone(_uid uuid, _zone text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare r public.user_roles; m public.company_members; z text[];
begin
  select * into r from public.user_roles where user_id = _uid order by (role = 'admin') desc limit 1;
  if not found then return false; end if;
  if r.role = 'admin' then return true; end if;
  select * into m from public.company_members where user_id = _uid and company_id = public.active_company();
  if found and m.is_admin then return true; end if;
  z := case when found then m.zones else r.zones end;
  return z is null or _zone = any(z);
end $$;
grant execute on function public.has_zone(uuid, text) to authenticated;

-- ---------- Admin of the company being worked in ----------
create or replace function public.is_company_admin(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_uid, 'admin')
      or exists (select 1 from public.company_members
                  where user_id = _uid and is_admin and company_id = public.active_company())
$$;
grant execute on function public.is_company_admin(uuid) to authenticated;

-- What the signed-in person may do in the company they're working in (for the menus).
create or replace function public.my_access()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r public.user_roles; m public.company_members; z text[];
begin
  select * into r from public.user_roles where user_id = auth.uid() order by (role = 'admin') desc limit 1;
  if not found then return jsonb_build_object('member', false, 'owner', false, 'admin', false, 'zones', null); end if;
  if r.role = 'admin' then return jsonb_build_object('member', true, 'owner', true, 'admin', true, 'zones', null); end if;
  select * into m from public.company_members where user_id = auth.uid() and company_id = public.active_company();
  if found and m.is_admin then return jsonb_build_object('member', true, 'owner', false, 'admin', true, 'zones', null); end if;
  z := case when found then m.zones else r.zones end;
  return jsonb_build_object('member', true, 'owner', false, 'admin', false, 'zones', to_jsonb(z));
end $$;
grant execute on function public.my_access() to authenticated;

-- ---------- Company admins may do what admins do inside their company's data ----------
-- (Not users, companies, the account or roles: those stay with admins of every company.)
do $$
declare p record; q text; c text;
begin
  for p in
    select tablename, policyname, qual, with_check from pg_policies
     where schemaname = 'public'
       and tablename not in ('companies','company_members','user_roles','user_company','orgs','org_members')
       and (coalesce(qual, '') like '%has_role(auth.uid(), ''admin''%'
            or coalesce(with_check, '') like '%has_role(auth.uid(), ''admin''%')
  loop
    q := regexp_replace(p.qual, 'has_role\(auth\.uid\(\), ''admin''::app_role\)', 'is_company_admin(auth.uid())', 'g');
    c := regexp_replace(p.with_check, 'has_role\(auth\.uid\(\), ''admin''::app_role\)', 'is_company_admin(auth.uid())', 'g');
    if p.qual is not null then
      execute format('alter policy %I on public.%I using (%s)', p.policyname, p.tablename, q);
    end if;
    if p.with_check is not null then
      execute format('alter policy %I on public.%I with check (%s)', p.policyname, p.tablename, c);
    end if;
  end loop;
end $$;

-- Year-end, rebuilding the books and closing out old sales: company admins too.
do $$
declare f record; src text;
begin
  for f in
    select p.oid from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.proname in ('close_books', 'rebuild_books', 'close_out_sales')
  loop
    src := pg_get_functiondef(f.oid);
    if src like '%has_role(auth.uid(), ''admin'')%' then
      execute replace(src, 'has_role(auth.uid(), ''admin'')', 'is_company_admin(auth.uid())');
    end if;
  end loop;
end $$;
