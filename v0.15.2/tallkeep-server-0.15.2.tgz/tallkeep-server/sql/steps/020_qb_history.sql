-- SunRise Office — step 20: history brought over from QuickBooks.
--
-- Transactions from the QuickBooks Journal report come in as journal entries of type 'history'
-- (dated before the books start). Rebuilding the books keeps them, like typed-in entries.

create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust', 'history');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  for r in select id from public.rent_charges where company_id = _co loop perform public.post_rent_charge(r.id); end loop;
  for r in select id from public.rent_payments where company_id = _co loop perform public.post_rent_payment(r.id); end loop;
  for r in select id from public.work_orders where company_id = _co and status = 'done' loop perform public.post_work_order(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;
