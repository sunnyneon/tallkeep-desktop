-- SunRise Office — step 12: company setup details and optional add-ons.
alter table public.company_settings add column if not exists legal_name text;        -- if different from the name
alter table public.company_settings add column if not exists tax_id text;            -- EIN / Tax ID
alter table public.company_settings add column if not exists mailing_address text;   -- if payments go elsewhere
alter table public.company_settings add column if not exists email_from_name text;   -- name customers see on emails
alter table public.company_settings add column if not exists email_reply_to text;    -- where customer replies go
alter table public.company_settings add column if not exists addons text[] not null default '{}';

-- The first company (SunRise LED) keeps the add-ons it uses today.
update public.company_settings
   set addons = array['tickets', 'tech_pay']
 where company_id = (select id from public.companies order by created_at limit 1)
   and addons = '{}';

