-- Tallkeep — step 31: license keys for Tallkeep Desktop, made in the owner panel (admin.tallkeep.com).
--
-- The key itself is a signed note (see desktop/server/lib/license.mjs), checked on the office
-- computer without internet. This table is our record of the keys we made: who for, what it
-- covers, and notes. Only the server (service role) reads or writes it.

create table if not exists public.desktop_licenses (
  id text primary key,                      -- short code printed on the license, like K7Q2-9XMA
  license_key text not null,
  to_name text not null,                    -- the business it's for
  email text,
  companies int,                            -- null = any number
  users int,
  updates_until date,
  notes text,
  revoked boolean not null default false,
  created_by uuid,                          -- who made it (plain id, like step 021)
  created_at timestamptz not null default now()
);
alter table public.desktop_licenses enable row level security;
revoke all on public.desktop_licenses from anon, authenticated;
grant select, insert, update, delete on public.desktop_licenses to service_role;
