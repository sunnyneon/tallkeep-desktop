-- Tallkeep — step 37: "Pay now" links, on Tallkeep's own server (app.tallkeep.com).
--
-- A business connects its own Stripe account (Stripe Connect); its customers pay invoices on a
-- Tallkeep page that opens Stripe's secure checkout. The money goes straight to the business's
-- Stripe account. The office computer (Tallkeep Desktop) asks for links and picks up the payments.
--
-- * pay_merchants: a business (one company in one license's books) and its Stripe account.
--   merchant_key is the secret the office computer uses to talk to us.
-- * pay_requests: one invoice's payment link and whether it's paid.
-- Only the server (service role) reads or writes these.

create table if not exists public.pay_merchants (
  id uuid primary key default gen_random_uuid(),
  license_id text,                      -- desktop_licenses.id (Tallkeep Desktop)
  company_ref text not null,            -- the company's id in the business's own books
  business_name text not null,
  email text,
  stripe_account text,
  charges_enabled boolean not null default false,
  merchant_key text not null unique,
  created_at timestamptz not null default now(),
  unique (license_id, company_ref)
);

create table if not exists public.pay_requests (
  id uuid primary key default gen_random_uuid(),
  token text not null unique,           -- the public link: /pay/<token>
  merchant_id uuid not null references public.pay_merchants(id) on delete cascade,
  invoice_ref text not null,            -- the invoice's id in the business's books
  number text,
  customer_name text,
  customer_email text,
  amount_cents int not null check (amount_cents > 0),
  currency text not null default 'usd',
  status text not null default 'open' check (status in ('open', 'paid', 'canceled')),
  stripe_session text,
  payment_intent text,
  paid_cents int,
  fee_cents int,
  paid_at timestamptz,
  picked_up_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists pay_requests_open_idx on public.pay_requests (merchant_id, invoice_ref)
  where status = 'open';
create index if not exists pay_requests_pickup_idx on public.pay_requests (merchant_id)
  where status = 'paid' and picked_up_at is null;

do $$
declare t text;
begin
  foreach t in array array['pay_merchants', 'pay_requests'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon, authenticated', t);
    execute format('grant select, insert, update, delete on public.%I to service_role', t);
  end loop;
end $$;
