-- Tallkeep — step 41: testers before launch, and "Report a problem".
--
-- * tester_requests: people ask to test Tallkeep (app.tallkeep.com/testers). Tallkeep looks at
--   the business and approves or declines. Approved testers get a free license until the end of
--   January 2027 and a code for 50% off when they buy.
-- * problem_reports: "Report a problem" from inside Tallkeep (Help panel), online or desktop.
-- * desktop_licenses.expires: a key that stops working after this day (tester keys).
-- Only Tallkeep's server reads and writes these (no access for signed-in users).

alter table public.desktop_licenses add column if not exists expires date;

create table if not exists public.tester_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  company text not null,
  website text,
  phone text,
  location text,
  business text,                 -- what the business does
  uses text[] not null default '{}',  -- inventory, accounting, properties, personal…
  people int,
  now_using text,                -- QuickBooks, inFlow, Excel…
  setup text,                    -- windows, synology, online
  notes text,
  ip text,
  status text not null default 'pending' check (status in ('pending','approved','declined')),
  reviewed_at timestamptz,
  license_id text references public.desktop_licenses(id) on delete set null,
  code text unique,              -- 50% off code, given when approved
  code_used_at timestamptz,
  code_session text              -- the Stripe checkout that used it
);
create index if not exists tester_requests_created_idx on public.tester_requests (created_at desc);
create index if not exists tester_requests_email_idx on public.tester_requests (lower(email));
alter table public.tester_requests enable row level security;
revoke all on public.tester_requests from anon, authenticated;

create table if not exists public.problem_reports (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  email text,
  name text,
  company text,
  license_id text,
  edition text,                  -- online, desktop, docker, service
  version text,
  page text,
  message text not null,
  has_picture boolean not null default false,
  status text not null default 'new' check (status in ('new','fixed','not_a_bug')),
  reply text
);
create index if not exists problem_reports_created_idx on public.problem_reports (created_at desc);
alter table public.problem_reports enable row level security;
revoke all on public.problem_reports from anon, authenticated;
