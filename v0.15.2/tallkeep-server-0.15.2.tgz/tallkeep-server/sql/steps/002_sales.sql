-- SunRise Office — step 2: quotes, orders, invoices and payments.
-- Structure only (no data changes), so it can run as one migration.

-- Company details printed on quotes and invoices (one row).
create table public.company_settings (
  id int primary key default 1 check (id = 1),
  name text not null default 'SunRise LED Inc.',
  address text,
  phone text,
  fax text,
  email text,
  website text,
  logo_path text,                 -- file in the "product-photos" bucket
  quote_footer text,              -- printed at the bottom of quotes
  invoice_footer text,            -- printed at the bottom of invoices
  default_tax_rate_id uuid references public.tax_rates(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.company_settings enable row level security;
create policy "Staff can read" on public.company_settings for select to authenticated using (true);
create policy "Admins can add" on public.company_settings for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins can edit" on public.company_settings for update to authenticated
  using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
grant select, insert, update on public.company_settings to authenticated;

-- When stock was taken out for an order (so it only happens once).
alter table public.sales_orders add column stock_taken_at timestamptz;
-- When stock was put in for a purchase order.
alter table public.purchase_orders add column stock_received_at timestamptz;

-- Keep amount paid, balance and paid status right whenever a payment is added, changed or removed.
create or replace function public.refresh_order_payments()
returns trigger language plpgsql security definer set search_path = public as $$
declare so uuid; po uuid; paid numeric;
begin
  so := coalesce(new.sales_order_id, old.sales_order_id);
  po := coalesce(new.purchase_order_id, old.purchase_order_id);
  if so is not null then
    select coalesce(sum(amount),0) into paid from public.payments where sales_order_id = so;
    update public.sales_orders
       set amount_paid = paid,
           balance = total - paid,
           status = case
             when status = 'invoiced' and total - paid <= 0 then 'paid'
             when status = 'paid' and total - paid > 0 then 'invoiced'
             else status end
     where id = so;
  end if;
  if po is not null then
    select coalesce(sum(amount),0) into paid from public.payments where purchase_order_id = po;
    update public.purchase_orders set amount_paid = paid, balance = total - paid where id = po;
  end if;
  return null;
end $$;

create trigger payments_refresh_orders after insert or update or delete on public.payments
  for each row execute function public.refresh_order_payments();

-- Take the items on a sales order out of stock (once), from the order's location.
create or replace function public.take_order_stock(_order_id uuid, _location_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare l record; o record;
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  select * into o from public.sales_orders where id = _order_id for update;
  if o.id is null then raise exception 'Order not found'; end if;
  if o.stock_taken_at is not null then raise exception 'Stock was already taken out for this order'; end if;
  for l in
    select sol.product_id, sum(sol.qty) as qty
      from public.sales_order_lines sol
      join public.products p on p.id = sol.product_id and p.item_type = 'stocked'
     where sol.sales_order_id = _order_id
     group by sol.product_id
  loop
    perform public.change_stock(l.product_id, _location_id, '', -l.qty, 'sold', o.number, 'sales_order', _order_id);
  end loop;
  update public.sales_orders set stock_taken_at = now(), location_id = _location_id where id = _order_id;
end $$;

-- Put the items on a purchase order into stock (once).
create or replace function public.receive_po_stock(_po_id uuid, _location_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare l record; o record;
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  select * into o from public.purchase_orders where id = _po_id for update;
  if o.id is null then raise exception 'Purchase order not found'; end if;
  if o.stock_received_at is not null then raise exception 'Stock was already received for this order'; end if;
  for l in
    select pol.product_id, sum(pol.qty) as qty
      from public.purchase_order_lines pol
      join public.products p on p.id = pol.product_id and p.item_type = 'stocked'
     where pol.purchase_order_id = _po_id
     group by pol.product_id
  loop
    perform public.change_stock(l.product_id, _location_id, '', l.qty, 'received', o.number, 'purchase_order', _po_id);
  end loop;
  update public.purchase_order_lines set qty_received = qty where purchase_order_id = _po_id;
  update public.purchase_orders set stock_received_at = now(), location_id = _location_id,
    status = case when status in ('draft','open') then 'received' else status end
   where id = _po_id;
end $$;

grant execute on function public.take_order_stock(uuid, uuid) to authenticated;
grant execute on function public.receive_po_stock(uuid, uuid) to authenticated;
