-- SunRise Office — step 16: year-end and the package for your accountant (CPA).
--
-- * Close the books through a date (usually Dec 31). After that, nothing dated on or before that
--   day can change the books: editing an old invoice, a hand-typed entry, a bank line… is refused.
--   Paying an old invoice today still works (the payment is dated today).
--   How: when closing, the totals of every account through that day are saved. Any later change
--   that would make them different is refused when it is saved. An admin can reopen.
-- * Accountant adjustments: hand-typed entries of type 'adjust' (shown in their own column on the
--   Trial Balance). Rebuilding the books keeps them.
-- * 1099: vendors can be marked "gets a 1099", with their Tax ID.
-- * Report helpers: general ledger lines, totals split into before/after adjustments, and what was
--   paid to each vendor.

-- ---------- Vendors: 1099 ----------
alter table public.vendors add column if not exists is_1099 boolean not null default false;
alter table public.vendors add column if not exists tax_id text;

-- ---------- Closing the books ----------
alter table public.company_settings add column if not exists books_closed_through date;
alter table public.company_settings add column if not exists books_closed_totals jsonb;
alter table public.company_settings add column if not exists books_closed_at timestamptz;
alter table public.company_settings add column if not exists books_closed_by uuid references auth.users(id) on delete set null;

-- Debit/credit totals of every account of a company through a day, as one value to compare.
create or replace function public.closed_totals(_co uuid, _through date)
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_object_agg(account_id::text, v), '{}'::jsonb) from (
    select l.account_id, round(sum(l.debit), 2)::text || '/' || round(sum(l.credit), 2)::text as v
      from public.journal_lines l join public.journal_entries e on e.id = l.entry_id
     where e.company_id = _co and e.entry_date <= _through
     group by l.account_id
    having round(sum(l.debit), 2) <> 0 or round(sum(l.credit), 2) <> 0) t
$$;

-- Runs when a change is saved (end of the transaction), so the books are compared after
-- documents have re-written their entries. Checked once per company per save.
create or replace function public.trg_closed_books()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record; co uuid; d date; s record; flag text;
begin
  if tg_table_name = 'journal_entries' then
    r := coalesce(new, old);
    co := r.company_id;
    d := r.entry_date;
    if tg_op = 'UPDATE' then d := least(old.entry_date, new.entry_date); end if;
  else
    r := coalesce(new, old);
    select e.company_id, e.entry_date into co, d from public.journal_entries e where e.id = r.entry_id;
    if d is null then return null; end if;   -- the entry itself was removed: its own check covers it
  end if;
  flag := 'app.books_ok_' || replace(co::text, '-', '');
  if current_setting(flag, true) = '1' then return null; end if;
  select books_closed_through, books_closed_totals into s from public.company_settings where company_id = co;
  if s.books_closed_through is null or d > s.books_closed_through then return null; end if;
  if public.closed_totals(co, s.books_closed_through) is distinct from s.books_closed_totals then
    raise exception 'The books are closed through %. Nothing dated on or before that day can be changed. An admin can reopen them in Accounting → Year-End.',
      to_char(s.books_closed_through, 'Mon DD, YYYY');
  end if;
  perform set_config(flag, '1', true);
  return null;
end $$;

drop trigger if exists journal_entries_closed on public.journal_entries;
create constraint trigger journal_entries_closed after insert or update or delete on public.journal_entries
  deferrable initially deferred for each row execute function public.trg_closed_books();
drop trigger if exists journal_lines_closed on public.journal_lines;
create constraint trigger journal_lines_closed after insert or update or delete on public.journal_lines
  deferrable initially deferred for each row execute function public.trg_closed_books();

-- Only close_books() may change the closing date.
create or replace function public.trg_guard_closing()
returns trigger language plpgsql set search_path = public as $$
begin
  if (new.books_closed_through is distinct from old.books_closed_through
      or new.books_closed_totals is distinct from old.books_closed_totals)
     and coalesce(current_setting('app.closing', true), '') <> '1' then
    raise exception 'Use Accounting → Year-End to close or reopen the books.';
  end if;
  return new;
end $$;
drop trigger if exists company_settings_guard_closing on public.company_settings;
create trigger company_settings_guard_closing before update on public.company_settings
  for each row execute function public.trg_guard_closing();

-- Close the books through a day (admin). Pass null to reopen.
create or replace function public.close_books(_through date)
returns json language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company();
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can close or reopen the books'; end if;
  perform set_config('app.closing', '1', true);
  update public.company_settings set
    books_closed_through = _through,
    books_closed_totals = case when _through is null then null else public.closed_totals(co, _through) end,
    books_closed_at = case when _through is null then null else now() end,
    books_closed_by = case when _through is null then null else auth.uid() end
   where company_id = co;
  perform set_config('app.closing', '', true);
  return json_build_object('closed_through', _through);
end $$;
grant execute on function public.close_books(date) to authenticated;

-- ---------- Rebuilding keeps accountant adjustments too ----------
create or replace function public.rebuild_books()
returns json language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company(); r record;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  perform public.seed_accounts(co);
  delete from public.journal_entries
   where company_id = co and source_type not in ('manual', 'opening', 'bank', 'adjust');
  for r in select id from public.sales_orders where company_id = co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = co loop perform public.post_bill_payment(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = co));
end $$;

-- ---------- Report helpers (use the reader's access rules) ----------

-- Every line of the books in a period, with the customer or vendor name.
create or replace function public.general_ledger(_from date, _to date)
returns table (
  line_id uuid, account_id uuid, entry_id uuid, entry_date date, ref text, memo text,
  source_type text, name text, debit numeric, credit numeric
)
language sql stable set search_path = public as $$
  select l.id, l.account_id, e.id, e.entry_date, e.ref, coalesce(l.memo, e.memo), e.source_type,
         coalesce(c.name, v.name), l.debit, l.credit
    from public.journal_lines l
    join public.journal_entries e on e.id = l.entry_id
    left join public.customers c on c.id = l.customer_id
    left join public.vendors v on v.id = l.vendor_id
   where (_from is null or e.entry_date >= _from) and (_to is null or e.entry_date <= _to)
   order by l.account_id, e.entry_date, e.created_at, l.id
$$;
grant execute on function public.general_ledger(date, date) to authenticated;

-- Totals per account through a day, split into "before adjustments" and the accountant's adjustments.
create or replace function public.account_totals_split(_from date, _to date)
returns table (account_id uuid, debit numeric, credit numeric, adj_debit numeric, adj_credit numeric)
language sql stable set search_path = public as $$
  select l.account_id,
         coalesce(sum(l.debit) filter (where e.source_type <> 'adjust'), 0),
         coalesce(sum(l.credit) filter (where e.source_type <> 'adjust'), 0),
         coalesce(sum(l.debit) filter (where e.source_type = 'adjust'), 0),
         coalesce(sum(l.credit) filter (where e.source_type = 'adjust'), 0)
    from public.journal_lines l join public.journal_entries e on e.id = l.entry_id
   where (_from is null or e.entry_date >= _from) and (_to is null or e.entry_date <= _to)
   group by l.account_id
$$;
grant execute on function public.account_totals_split(date, date) to authenticated;

-- What was paid to each vendor in a period (bills and purchase orders), and how much of it by
-- credit card (card payments are reported by the card company, not on your 1099s).
create or replace function public.vendor_payments(_from date, _to date)
returns table (vendor_id uuid, paid numeric, by_card numeric)
language sql stable set search_path = public as $$
  select x.vendor_id, sum(x.amount), sum(case when x.card then x.amount else 0 end)
    from (
      select b.vendor_id, bp.amount, coalesce(a.kind = 'credit_card', false) as card
        from public.bill_payments bp
        join public.bills b on b.id = bp.bill_id
        left join public.accounts a on a.id = bp.account_id
       where bp.paid_on between _from and _to and b.vendor_id is not null
      union all
      select po.vendor_id, p.amount, coalesce(a.kind = 'credit_card', false)
        from public.payments p
        join public.purchase_orders po on po.id = p.purchase_order_id
        left join public.accounts a on a.id = p.account_id
       where p.paid_on::date between _from and _to and po.vendor_id is not null
    ) x
   group by x.vendor_id
$$;
grant execute on function public.vendor_payments(date, date) to authenticated;
