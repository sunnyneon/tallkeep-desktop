-- SunRise Office — step 4: saved footers you pick per document, and RMA documents.

-- Saved footer texts (terms & conditions, restocking fee, RMA agreement, ...).
create table public.doc_footers (
  id uuid primary key default gen_random_uuid(),
  name text not null,                               -- short name shown in the pick list
  body text not null default '',                    -- the text printed at the end of the document
  default_for text[] not null default '{}',         -- picked automatically on new: quote, order, invoice, rma, po
  sort int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger doc_footers_touch before update on public.doc_footers for each row execute function public.touch_updated_at();
alter table public.doc_footers enable row level security;
create policy "Staff can read" on public.doc_footers for select to authenticated using (true);
create policy "Admins can add" on public.doc_footers for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins can edit" on public.doc_footers for update to authenticated
  using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins can delete" on public.doc_footers for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
grant select, insert, update, delete on public.doc_footers to authenticated;

-- Which footer a document uses. The text is copied onto the document so later edits
-- to a saved footer don't change documents already sent.
alter table public.sales_orders add column footer_id uuid references public.doc_footers(id) on delete set null;
alter table public.sales_orders add column footer_text text;
alter table public.purchase_orders add column footer_id uuid references public.doc_footers(id) on delete set null;
alter table public.purchase_orders add column footer_text text;

-- RMA (Return Merchandise Authorization): looks like a quote, no money or stock changes.
alter table public.sales_orders drop constraint if exists sales_orders_status_check;
alter table public.sales_orders add constraint sales_orders_status_check
  check (status in ('quote','rma','open','invoiced','paid','completed','cancelled'));
insert into public.doc_counters (kind, prefix, next_number) values ('rma', 'RMA-', 100001)
  on conflict (kind) do nothing;

-- Start the list with the two footers already saved in Company details.
insert into public.doc_footers (name, body, default_for, sort)
select 'Quote terms', quote_footer, '{quote}'::text[], 1 from public.company_settings where coalesce(quote_footer,'') <> ''
union all
select 'Invoice terms', invoice_footer, '{order,invoice}'::text[], 2 from public.company_settings where coalesce(invoice_footer,'') <> '';
