-- Tallkeep — step 30: Support Desk (add-on "support").
--
-- * tickets: a customer's request, with a number (T-1001…), status, who it's assigned to and the
--   customer it belongs to. public_key is the secret in the customer's link to follow the ticket.
-- * ticket_messages: the conversation: what the customer wrote, staff replies, internal notes
--   (never shown to the customer) and events ("Status: Done"). Files are in the ticket-files bucket.
-- * ticket_templates: saved replies.
-- * company_settings: the support page address (support_slug), who gets new-ticket emails, the
--   topics customers pick from, and a line of text for the top of the page.
-- * sales_orders.ticket_id: quotes and invoices made from a ticket.
-- Customers never sign in: the support page talks to the server, which uses the service role.
-- Security: staff with the Sales section, in the active company.

alter table public.company_settings add column if not exists support_slug text;
alter table public.company_settings add column if not exists support_notify_email text;
alter table public.company_settings add column if not exists support_topics text[] not null default '{}';
alter table public.company_settings add column if not exists support_intro text;
create unique index if not exists company_settings_support_slug_idx
  on public.company_settings (lower(support_slug)) where support_slug is not null;

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  number text,
  status text not null default 'new' check (status in ('new','open','waiting','done','closed')),
  priority text not null default 'normal' check (priority in ('low','normal','high','urgent')),
  topic text,
  subject text not null,
  customer_id uuid references public.customers(id) on delete set null,
  name text,
  company_name text,
  email text,
  phone text,
  address text,                                  -- where the work is (job site)
  assigned_to uuid references auth.users(id) on delete set null,
  source text not null default 'staff' check (source in ('staff','page','email','website','phone')),
  public_key text not null default (replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '')),
  last_customer_at timestamptz,
  last_staff_at timestamptz,
  closed_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists tickets_number_idx on public.tickets (company_id, number);
create unique index if not exists tickets_key_idx on public.tickets (public_key);
create index if not exists tickets_status_idx on public.tickets (company_id, status, updated_at desc);
create index if not exists tickets_customer_idx on public.tickets (customer_id);

create table if not exists public.ticket_messages (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  ticket_id uuid not null references public.tickets(id) on delete cascade,
  kind text not null check (kind in ('customer','staff','note','event')),
  author_id uuid references auth.users(id) on delete set null,
  author_name text,
  body text not null default '',
  files jsonb not null default '[]'::jsonb,      -- [{path, name, size, type}] in ticket-files
  emailed boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists ticket_messages_ticket_idx on public.ticket_messages (ticket_id, created_at);

create table if not exists public.ticket_templates (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);

alter table public.sales_orders add column if not exists ticket_id uuid references public.tickets(id) on delete set null;
create index if not exists sales_orders_ticket_idx on public.sales_orders (ticket_id) where ticket_id is not null;

-- Ticket numbers: T-1001, T-1002… per company (works for the support page too, which has no sign-in).
create or replace function public.tickets_number()
returns trigger language plpgsql security definer set search_path = public as $$
declare p text; n int;
begin
  if new.number is null or new.number = '' then
    insert into public.doc_counters (company_id, kind, prefix, next_number)
    values (new.company_id, 'ticket', 'T-', 1001) on conflict do nothing;
    update public.doc_counters set next_number = next_number + 1
     where company_id = new.company_id and kind = 'ticket'
     returning prefix, next_number - 1 into p, n;
    new.number := p || n::text;
  end if;
  if new.status in ('done','closed') and new.closed_at is null then new.closed_at := now(); end if;
  if new.status not in ('done','closed') then new.closed_at := null; end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists tickets_number on public.tickets;
create trigger tickets_number before insert or update on public.tickets
  for each row execute function public.tickets_number();

-- A message moves the ticket: a customer's reopens it, a staff reply waits for the customer.
create or replace function public.ticket_messages_touch()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'customer' then
    update public.tickets set last_customer_at = new.created_at,
      status = case when status in ('waiting','done','closed') then 'open' else status end
     where id = new.ticket_id;
  elsif new.kind = 'staff' then
    update public.tickets set last_staff_at = new.created_at,
      status = case when status in ('new','open') then 'waiting' else status end
     where id = new.ticket_id;
  else
    update public.tickets set updated_at = now() where id = new.ticket_id;
  end if;
  return null;
end $$;
drop trigger if exists ticket_messages_touch on public.ticket_messages;
create trigger ticket_messages_touch after insert on public.ticket_messages
  for each row execute function public.ticket_messages_touch();

grant select, insert, update, delete on public.tickets, public.ticket_messages, public.ticket_templates to authenticated;
grant select, insert, update, delete on public.tickets, public.ticket_messages, public.ticket_templates to service_role;

alter table public.tickets enable row level security;
alter table public.ticket_messages enable row level security;
alter table public.ticket_templates enable row level security;
do $$
declare t text;
begin
  foreach t in array array['tickets','ticket_messages','ticket_templates'] loop
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format('create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), ''Sales'') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), ''Sales'') and company_id = (select public.active_company()))', t);
  end loop;
end $$;

-- Only admins delete tickets.
drop policy if exists "Admins delete tickets" on public.tickets;
create policy "Admins delete tickets" on public.tickets as restrictive for delete to authenticated
  using (public.has_role(auth.uid(), 'admin'));

-- Private storage for ticket files: <company id>/<ticket id>/<file>.
insert into storage.buckets (id, name, public)
values ('ticket-files', 'ticket-files', false)
on conflict (id) do nothing;

drop policy if exists "Ticket files: staff of the company" on storage.objects;
create policy "Ticket files: staff of the company" on storage.objects for all to authenticated
  using (bucket_id = 'ticket-files'
         and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Sales')
         and (storage.foldername(name))[1] = (select public.active_company())::text)
  with check (bucket_id = 'ticket-files'
         and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Sales')
         and (storage.foldername(name))[1] = (select public.active_company())::text);

-- Like every business table: no adding, changing or deleting while the account is read-only.
do $$
declare t text;
begin
  foreach t in array array['tickets','ticket_messages','ticket_templates'] loop
    execute format('drop policy if exists "Read-only when the plan ends (add)" on public.%I', t);
    execute format('drop policy if exists "Read-only when the plan ends (change)" on public.%I', t);
    execute format('drop policy if exists "Read-only when the plan ends (delete)" on public.%I', t);
    execute format('create policy "Read-only when the plan ends (add)" on public.%I as restrictive for insert to authenticated with check (public.can_write_company(company_id))', t);
    execute format('create policy "Read-only when the plan ends (change)" on public.%I as restrictive for update to authenticated using (public.can_write_company(company_id))', t);
    execute format('create policy "Read-only when the plan ends (delete)" on public.%I as restrictive for delete to authenticated using (public.can_write_company(company_id))', t);
  end loop;
end $$;

-- New accounts can start with Support Desk on ("Services only" does).
create or replace function public.start_trial(_company text, _business_type text, _addons text[])
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); o uuid; n uuid; days int;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if exists (select 1 from public.org_members where user_id = uid)
     or exists (select 1 from public.user_roles where user_id = uid) then
    raise exception 'You already have an account. Sign in to open it.';
  end if;
  if coalesce(trim(_company), '') = '' then raise exception 'Type your company name.'; end if;
  if length(trim(_company)) > 120 then raise exception 'That company name is too long.'; end if;
  select least(greatest(coalesce((value->>'trial_days')::int, 30), 1), 365) into days
    from public.platform_settings where key = 'prices';
  insert into public.orgs (name, status, trial_ends_at, created_by)
  values (trim(_company), 'trial', now() + make_interval(days => coalesce(days, 30)), uid)
  returning id into o;
  insert into public.org_members (org_id, user_id) values (o, uid);
  insert into public.user_roles (user_id, role) values (uid, 'admin');
  n := public.make_company(o, trim(_company), _business_type,
                           (select array(select x from unnest(_addons) x
                                          where x in ('sales','purchasing','inventory','accounting',
                                                      'work_orders','tickets','real_estate','tech_pay','support'))),
                           uid, null);
  insert into public.user_company (user_id, company_id) values (uid, n)
  on conflict (user_id) do update set company_id = excluded.company_id;
  return n;
end $$;
grant execute on function public.start_trial(text, text, text[]) to authenticated;
