-- SunRise Office — step 5: footers on every page, and pages attached after a document
-- (like the Quote Terms & Conditions).

alter table public.doc_footers add column placement text not null default 'end'
  check (placement in ('end','page','attach'));   -- end of document / bottom of every page / own page after

alter table public.sales_orders add column page_footer_id uuid references public.doc_footers(id) on delete set null;
alter table public.sales_orders add column page_footer_text text;
alter table public.sales_orders add column attach_id uuid references public.doc_footers(id) on delete set null;
alter table public.sales_orders add column attach_text text;
alter table public.purchase_orders add column page_footer_id uuid references public.doc_footers(id) on delete set null;
alter table public.purchase_orders add column page_footer_text text;
alter table public.purchase_orders add column attach_id uuid references public.doc_footers(id) on delete set null;
alter table public.purchase_orders add column attach_text text;

-- Matthew's quote footer and Terms & Conditions page, picked automatically on new quotes.
insert into public.doc_footers (name, body, placement, default_for, sort) values
('Quote approval line',
 'By approving this quote, customer agrees to the attached SunRise LED Inc. Quote Terms & Conditions.',
 'page', '{quote}'::text[], 10),
('Quote Terms & Conditions', $tc$QUOTE TERMS & CONDITIONS
By approving the related quote, purchase order, invoice, or proposal, Customer agrees to these Terms & Conditions unless SunRise LED Inc. agrees otherwise in writing.
1. Quote Validity - Quotes are valid for 30 days unless otherwise stated. Pricing may change due to material cost, freight, tariffs, taxes, labor, exchange rate, or project scope changes.
2. Order Acceptance - An order is not accepted until SunRise LED Inc. receives written approval, signed quote or purchase order, and required deposit or payment. Conflicting customer purchase terms are rejected unless accepted in writing.
3. Payment Terms - Unless stated otherwise, custom product orders require a deposit before production or reservation of inventory. Final balance is due before shipment, delivery, installation, or release of goods.
4. Lead Time - Estimated lead time begins only after deposit, written approval, approved specifications/artwork, and all required project information. Lead times are estimates and are not guaranteed.
5. Changes to Order - Changes requested after approval may result in additional cost and revised delivery or installation dates. All changes must be approved in writing by SunRise LED Inc.
6. Shipping & Damage - Unless stated otherwise, freight, insurance, unloading, lift equipment, storage, and handling are Customer responsibility. Customer must inspect goods at delivery. Visible damage or shortages must be noted on carrier paperwork and reported promptly. Hidden damage must be reported within 7 days.
7. Storage & Customer Delay - If goods are ready and Customer delays payment, pickup, delivery, access, or installation scheduling, SunRise LED Inc. may charge reasonable storage fees beginning 5 business days after written notice. Customer is responsible for related handling, freight, insurance, labor, or rescheduling costs.
8. Installation Conditions - Installation pricing includes only work specifically listed in the quote. Customer is responsible for safe access, adequate structure, electrical power, permits, landlord approvals, engineering approvals, and removal of obstacles unless specifically included. Waiting time, unsafe conditions, restricted access, extra trips, lift equipment, electrical work, structural work, after-hours work, or changed site conditions may be billed separately.
9. Permits, Electrical & Structure - Unless specifically included, permits, city approvals, engineering drawings, structural support, primary electrical wiring, data wiring, and code compliance are Customer responsibility. SunRise LED Inc. is not responsible for delays or costs caused by permitting, inspection, landlord, city, or utility requirements.
10. Warranty - Warranty is limited to the product warranty stated in the quote, invoice, or manufacturer documentation. Warranty excludes misuse, improper installation by others, water intrusion, power surge, lightning, accident, vandalism, unauthorized repair, modification, improper ventilation, structural failure, environmental conditions, or failure to follow instructions. Remedy is limited to repair or replacement of defective parts at SunRise LED Inc. discretion.
11. Non-Warranty Service - Labor, travel, lift rental, shipping, event support, emergency service, training, calibration, customer-equipment troubleshooting, and non-warranty repairs are billable unless included in writing.
12. Ownership / Title - Products remain the property of SunRise LED Inc. until paid in full. Customer may not sell, transfer, pledge, or modify unpaid goods without written consent.
13. Cancellations & Returns - Custom-made, special-order, configured, fabricated, or modified LED products are non-cancelable and non-refundable once production, procurement, or customization has started. Deposits may be applied to material, engineering, design, production, administrative, or restocking costs.
14. Limitation of Liability - SunRise LED Inc. is not liable for incidental, indirect, special, consequential, or lost-profit damages, including business interruption, event cancellation, advertising loss, or lost revenue. Total liability is limited to the amount paid for the specific product or service giving rise to the claim.
15. Confidentiality & IP - Drawings, designs, pricing, technical documents, software, configurations, and project information provided by SunRise LED Inc. are confidential and remain SunRise LED Inc. property unless agreed otherwise in writing.
16. Force Majeure - SunRise LED Inc. is not responsible for delay or failure caused by events beyond reasonable control, including weather, natural disaster, fire, labor disruption, carrier/supplier/customs delay, government action, power outage, pandemic, war, or similar events.
17. Governing Law - Transactions with SunRise LED Inc. are governed by Texas law. Any dispute shall be handled in a Texas court or arbitration venue unless otherwise agreed in writing.
18. Entire Agreement - The quote, invoice, approved specifications, and these Terms & Conditions are the complete agreement. Changes must be in writing and approved by SunRise LED Inc.
CUSTOMER ACKNOWLEDGMENT - Customer confirms receipt and acceptance of these Terms & Conditions as part of the related quote/proposal.$tc$,
 'attach', '{quote}'::text[], 11);
