-- SunRise Office — step 15: bank feeds by file, matching, rules and reconciling.
--
-- * bank_transactions: lines imported from a bank / credit card statement file (CSV, OFX, QFX).
--   Each one is matched to something already in the books, added as a new entry, or ignored.
-- * bank_rules: "when the description contains X, it's account Y" for next time.
-- * cleared_items / reconciliations: what has been ticked off against a statement. Items are kept
--   by their document (not by the journal line), so rebuilding the books keeps them.
-- Amounts: money in = positive, money out = negative (as the bank shows it).

create table if not exists public.bank_transactions (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  txn_date date not null,
  amount numeric(14,2) not null,
  description text,
  ref text,
  fit_id text,                                  -- the bank's own id for the line (stops doubles)
  status text not null default 'new' check (status in ('new','matched','added','ignored')),
  source_type text,                             -- what it matched / became in the books
  source_id uuid,
  imported_at timestamptz not null default now(),
  unique (account_id, fit_id)
);
create index if not exists bank_transactions_account_idx on public.bank_transactions (account_id, status, txn_date);

create table if not exists public.bank_rules (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  contains text not null,
  account_id uuid not null references public.accounts(id) on delete cascade,
  payee text,
  created_at timestamptz not null default now()
);

create table if not exists public.reconciliations (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  statement_date date not null,
  ending_balance numeric(14,2) not null,
  completed_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.cleared_items (
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  item_key uuid not null,                       -- the document (or hand-typed entry) behind the line
  reconciliation_id uuid references public.reconciliations(id) on delete cascade,
  primary key (account_id, item_key)
);

-- Rules and table access, like the other accounting tables.
do $$
declare t text;
begin
  foreach t in array array['bank_transactions','bank_rules','reconciliations','cleared_items'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- The lines of one account, each with the key that ties it to its document, whether it's
-- cleared, and which bank line matched it. Uses the reader's access rules.
create or replace function public.account_lines(_account uuid, _to date)
returns table (
  line_id uuid, entry_id uuid, item_key uuid, entry_date date, ref text, memo text,
  source_type text, amount numeric, cleared boolean, reconciliation_id uuid
)
language sql stable set search_path = public as $$
  select l.id, e.id, coalesce(e.source_id, e.id), e.entry_date, e.ref, coalesce(l.memo, e.memo),
         e.source_type, l.debit - l.credit,
         c.item_key is not null, c.reconciliation_id
    from public.journal_lines l
    join public.journal_entries e on e.id = l.entry_id
    left join public.cleared_items c on c.account_id = l.account_id and c.item_key = coalesce(e.source_id, e.id)
   where l.account_id = _account and (_to is null or e.entry_date <= _to)
$$;
grant execute on function public.account_lines(uuid, date) to authenticated;

-- A bank line added straight to the books (fees, small purchases, deposits not from an invoice):
-- one entry between the bank account and the chosen account.
create or replace function public.add_bank_transaction(_txn uuid, _other uuid, _memo text)
returns uuid language plpgsql set search_path = public as $$
declare t record; e uuid;
begin
  select * into t from public.bank_transactions where id = _txn;
  if t.id is null then raise exception 'Bank line not found'; end if;
  if t.status <> 'new' then raise exception 'This bank line was already handled'; end if;
  insert into public.journal_entries (entry_date, memo, source_type, ref, created_by)
  values (t.txn_date, coalesce(nullif(_memo, ''), t.description), 'bank', t.ref, auth.uid()) returning id into e;
  insert into public.journal_lines (entry_id, account_id, debit, credit, memo) values
    (e, t.account_id, greatest(t.amount, 0), greatest(-t.amount, 0), t.description),
    (e, _other, greatest(-t.amount, 0), greatest(t.amount, 0), t.description);
  update public.bank_transactions set status = 'added', source_type = 'bank', source_id = e where id = _txn;
  insert into public.cleared_items (account_id, item_key) values (t.account_id, e) on conflict do nothing;
  return e;
end $$;
grant execute on function public.add_bank_transaction(uuid, uuid, text) to authenticated;

-- Undo: put a bank line back to "for review" (removes the entry it created, if any).
create or replace function public.undo_bank_transaction(_txn uuid)
returns void language plpgsql set search_path = public as $$
declare t record;
begin
  select * into t from public.bank_transactions where id = _txn;
  if t.id is null then return; end if;
  if t.source_id is not null then
    delete from public.cleared_items where account_id = t.account_id and item_key = t.source_id and reconciliation_id is null;
  end if;
  if t.status = 'added' and t.source_id is not null then
    delete from public.journal_entries where id = t.source_id and source_type = 'bank';
  end if;
  update public.bank_transactions set status = 'new', source_type = null, source_id = null where id = _txn;
end $$;
grant execute on function public.undo_bank_transaction(uuid) to authenticated;

-- Bank entries are typed-in entries: rebuilding the books keeps them.
create or replace function public.rebuild_books()
returns json language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company(); r record;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  perform public.seed_accounts(co);
  delete from public.journal_entries
   where company_id = co and source_type not in ('manual', 'opening', 'bank');
  for r in select id from public.sales_orders where company_id = co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = co loop perform public.post_bill_payment(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = co));
end $$;
