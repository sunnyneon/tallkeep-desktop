-- SunRise Office — step 17: kinds of business with features, and backups that include the books.
--
-- * company_settings.business_type: what the company does (products, manufacturing, services,
--   real_estate, other). It picks the features a new company starts with.
-- * company_settings.addons now holds every feature that is on, including the main parts
--   (sales, purchasing, inventory, accounting). Existing companies keep everything they had.
-- * rebuild_books_company(): rebuilds one company's books; only the server (backups/restore) can
--   use it. rebuild_books() (the Settings button) now calls it.

alter table public.company_settings add column if not exists business_type text;

-- Existing companies: the main parts stay on.
update public.company_settings
   set addons = array(select distinct x from unnest(addons || array['sales','purchasing','inventory','accounting']) x),
       business_type = coalesce(business_type, 'products')
 where business_type is null;

-- New companies start with the main parts until their setup picks a kind of business.
alter table public.company_settings alter column addons set default array['sales','purchasing','inventory','accounting'];

create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;

create or replace function public.rebuild_books()
returns json language plpgsql security definer set search_path = public as $$
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  return public.rebuild_books_company(public.active_company());
end $$;
