-- SunRise Office — step 9: fulfill / unfulfill invoices.
-- Fulfill takes each item from wherever it sits (the chosen place first, biggest shelf first).
-- If there isn't enough, stock goes below zero (shown in red so someone checks the count).
-- Unfulfill puts back exactly what was taken.

create or replace function public.take_order_stock(_order_id uuid, _location_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare l record; o record; s record; need numeric; take numeric; loc uuid; spot text;
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.sales_orders where id = _order_id for update;
  if o.id is null then raise exception 'Order not found'; end if;
  if o.stock_taken_at is not null then raise exception 'Stock was already taken out for this order'; end if;
  for l in
    select sol.product_id, sum(sol.qty) as qty, p.default_location_id, coalesce(p.default_shelf,'') as default_shelf
      from public.sales_order_lines sol
      join public.products p on p.id = sol.product_id and p.item_type = 'stocked'
     where sol.sales_order_id = _order_id
     group by sol.product_id, p.default_location_id, p.default_shelf
  loop
    need := l.qty;
    -- 1. Take from spots that have stock: chosen place first, then the rest, biggest first.
    for s in
      select location_id, shelf, qty from public.stock
       where product_id = l.product_id and qty > 0
       order by (location_id = _location_id) desc nulls last, qty desc
    loop
      exit when need <= 0;
      take := least(need, s.qty);
      perform public.change_stock(l.product_id, s.location_id, s.shelf, -take, 'sold', o.number, 'sales_order', _order_id);
      need := need - take;
    end loop;
    -- 2. Not enough: the rest comes off one spot and goes below zero.
    if need > 0 then
      select st.location_id, st.shelf into loc, spot from public.stock st
       where st.product_id = l.product_id
       order by (st.location_id = _location_id) desc nulls last, st.qty desc limit 1;
      if loc is null then
        loc := coalesce(_location_id, l.default_location_id, (select id from public.locations where is_active order by name limit 1));
        spot := case when loc = l.default_location_id then l.default_shelf else '' end;
      end if;
      perform public.change_stock(l.product_id, loc, coalesce(spot,''), -need, 'sold', o.number, 'sales_order', _order_id);
    end if;
  end loop;
  update public.sales_orders set stock_taken_at = now(), location_id = coalesce(_location_id, location_id) where id = _order_id;
end $$;
grant execute on function public.take_order_stock(uuid, uuid) to authenticated;

create or replace function public.return_order_stock(_order_id uuid)
returns int language plpgsql security definer set search_path = public as $$
declare o record; m record; n int := 0;
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.sales_orders where id = _order_id for update;
  if o.id is null then raise exception 'Order not found'; end if;
  -- Net amount taken per spot for this order (taken minus already put back).
  for m in
    select product_id, location_id, shelf, sum(qty_change) as net
      from public.stock_moves
     where ref_type = 'sales_order' and ref_id = _order_id and reason in ('sold','returned')
     group by product_id, location_id, shelf
    having sum(qty_change) < 0
  loop
    perform public.change_stock(m.product_id, m.location_id, m.shelf, -m.net, 'returned', o.number || ' unfulfilled', 'sales_order', _order_id);
    n := n + 1;
  end loop;
  update public.sales_orders set stock_taken_at = null where id = _order_id;
  return n;
end $$;
grant execute on function public.return_order_stock(uuid) to authenticated;
