-- SunRise Office — step 13.
-- Logos: no company falls back to the SunRise logo anymore. SunRise keeps it if it had none.
update public.company_settings
   set logo_path = '/sunrise-logo.png'
 where company_id = (select id from public.companies order by created_at limit 1)
   and logo_path is null;
