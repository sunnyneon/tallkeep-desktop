-- SunRise Office — step 21: money in and out (like QuickBooks' Banking section).
--
-- * checks: money paid out — a written check, an ACH/online payment, a debit or credit card
--   charge, or cash. Its lines are expenses (any account); it can also pay bills and purchase
--   orders (bill_payments.check_id / payments.check_id), so one check can pay several bills of a
--   vendor and shows as ONE line in the bank register, like on the bank statement.
-- * deposits: customer payments waiting in Undeposited Funds go into the bank together as one
--   deposit, plus any other money (other lines).
-- * transfers: moving money between accounts (also paying the credit card from checking).
-- Security: staff with the Accounting section, in the active company.

-- ---------- Checks and other money out ----------
create table if not exists public.checks (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id),       -- paid from (bank or credit card)
  method text not null default 'check' check (method in ('check','ach','card','cash','other')),
  number text,                                                     -- check number
  check_date date not null default current_date,
  vendor_id uuid references public.vendors(id) on delete set null,
  payee text,                                                      -- name printed on the check
  address text,
  memo text,
  total numeric(14,2) not null default 0,
  status text not null default 'ok' check (status in ('ok','void')),
  to_print boolean not null default false,
  printed_at timestamptz,
  created_by uuid,                         -- who made it (sign-in id)
  created_at timestamptz not null default now()
);
create index if not exists checks_account_idx on public.checks (account_id, check_date);

create table if not exists public.check_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  check_id uuid not null references public.checks(id) on delete cascade,
  line_no int not null default 0,
  account_id uuid not null references public.accounts(id),
  description text,
  amount numeric(14,2) not null default 0,
  property_id uuid references public.properties(id) on delete set null
);
create index if not exists check_lines_check_idx on public.check_lines (check_id);

alter table public.bill_payments add column if not exists check_id uuid references public.checks(id) on delete cascade;
alter table public.payments add column if not exists check_id uuid references public.checks(id) on delete cascade;
create index if not exists bill_payments_check_idx on public.bill_payments (check_id) where check_id is not null;
create index if not exists payments_check_idx on public.payments (check_id) where check_id is not null;

-- ---------- Deposits ----------
create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id),        -- the bank it went into
  deposit_date date not null default current_date,
  memo text,
  total numeric(14,2) not null default 0,
  created_by uuid,                         -- who made it (sign-in id)
  created_at timestamptz not null default now()
);
create table if not exists public.deposit_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  deposit_id uuid not null references public.deposits(id) on delete cascade,
  payment_id uuid unique references public.payments(id) on delete cascade,
  rent_payment_id uuid unique references public.rent_payments(id) on delete cascade,
  account_id uuid references public.accounts(id),                 -- "other" money: where it comes from
  name text,
  description text,
  amount numeric(14,2) not null
);
create index if not exists deposit_lines_deposit_idx on public.deposit_lines (deposit_id);

-- ---------- Transfers ----------
create table if not exists public.transfers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  from_account_id uuid not null references public.accounts(id),
  to_account_id uuid not null references public.accounts(id),
  amount numeric(14,2) not null check (amount > 0),
  transfer_date date not null default current_date,
  memo text,
  created_by uuid,                         -- who made it (sign-in id)
  created_at timestamptz not null default now(),
  check (from_account_id <> to_account_id)
);

do $$
declare t text;
begin
  foreach t in array array['checks','check_lines','deposits','deposit_lines','transfers'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('grant select, insert, update, delete on public.%I to service_role', t);
  end loop;
end $$;

-- ---------- Posting ----------
-- A check: Dr each expense line, Dr Accounts Payable for bills/POs it pays, Cr the account it's paid from.
create or replace function public.post_check(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare c record; lines jsonb; ap numeric; tot numeric;
begin
  if _id is null then return; end if;
  delete from public.journal_entries where source_type = 'check' and source_id = _id;
  select * into c from public.checks where id = _id;
  if c.id is null then return; end if;
  select coalesce(sum(amount), 0) into ap from (
    select amount from public.bill_payments where check_id = _id
    union all select amount from public.payments where check_id = _id) x;
  select coalesce(sum(amount), 0) + ap into tot from public.check_lines where check_id = _id;
  if c.total is distinct from tot then update public.checks set total = tot where id = _id; end if;
  if c.status = 'void' or not public.books_open(c.company_id, c.check_date) then return; end if;
  select coalesce(jsonb_agg(jsonb_build_object('account', l.account_id, 'debit', greatest(l.amount, 0),
           'credit', greatest(-l.amount, 0), 'memo', l.description, 'vendor', c.vendor_id, 'property', l.property_id)), '[]'::jsonb)
    into lines from public.check_lines l where l.check_id = _id;
  perform public.write_entry(c.company_id, c.check_date, 'check', c.id,
    coalesce(c.number, upper(c.method)), coalesce(c.payee, 'Payment'),
    lines || jsonb_build_array(
      jsonb_build_object('account', public.acct(c.company_id, 'ap'), 'debit', ap, 'vendor', c.vendor_id, 'memo', 'Bills paid'),
      jsonb_build_object('account', c.account_id, 'credit', tot, 'vendor', c.vendor_id, 'memo', coalesce(c.memo, c.payee))));
end $$;

-- Bill and PO payments made with a check post through the check (one bank line).
create or replace function public.post_bill_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; b record;
begin
  delete from public.journal_entries where source_type = 'bill_payment' and source_id = _id;
  select * into p from public.bill_payments where id = _id;
  if p.id is null or p.check_id is not null then return; end if;
  select * into b from public.bills where id = p.bill_id;
  if b.id is null or not public.books_open(b.company_id, p.paid_on) then return; end if;
  perform public.write_entry(b.company_id, p.paid_on, 'bill_payment', p.id, b.ref, 'Paid bill ' || coalesce(b.vendor_name, ''),
    jsonb_build_array(
      jsonb_build_object('account', public.acct(b.company_id, 'ap'), 'debit', p.amount, 'vendor', b.vendor_id),
      jsonb_build_object('account', coalesce(p.account_id,
          (select default_bank_account_id from public.company_settings where company_id = b.company_id),
          public.acct(b.company_id, 'bank')), 'credit', p.amount, 'vendor', b.vendor_id)));
end $$;

create or replace function public.post_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; co uuid; bank uuid; who uuid; ref text;
begin
  delete from public.journal_entries where source_type in ('payment', 'po_payment') and source_id = _id;
  select * into p from public.payments where id = _id;
  if p.id is null or p.check_id is not null then return; end if;
  if p.sales_order_id is not null then
    select company_id, customer_id, number into co, who, ref from public.sales_orders where id = p.sales_order_id;
  else
    select company_id, vendor_id, number into co, who, ref from public.purchase_orders where id = p.purchase_order_id;
  end if;
  if co is null or not public.books_open(co, p.paid_on::date) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = co),
    public.acct(co, 'bank'));
  if p.sales_order_id is not null then
    perform public.write_entry(co, p.paid_on::date, 'payment', p.id, ref, 'Payment for ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', bank, 'debit', p.amount, 'customer', who),
        jsonb_build_object('account', public.acct(co, 'ar'), 'credit', p.amount, 'customer', who)));
  else
    perform public.write_entry(co, p.paid_on::date, 'po_payment', p.id, ref, 'Paid ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'ap'), 'debit', p.amount, 'vendor', who),
        jsonb_build_object('account', bank, 'credit', p.amount, 'vendor', who)));
  end if;
end $$;

-- A deposit: Dr the bank; Cr Undeposited Funds for payments in it, Cr other accounts for other lines.
create or replace function public.post_deposit(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare d record; und uuid; held numeric; lines jsonb; tot numeric;
begin
  if _id is null then return; end if;
  delete from public.journal_entries where source_type = 'deposit' and source_id = _id;
  select * into d from public.deposits where id = _id;
  if d.id is null then return; end if;
  select coalesce(sum(amount), 0) into tot from public.deposit_lines where deposit_id = _id;
  if d.total is distinct from tot then update public.deposits set total = tot where id = _id; end if;
  if not public.books_open(d.company_id, d.deposit_date) then return; end if;
  und := public.acct(d.company_id, 'undeposited');
  select coalesce(sum(amount), 0) into held from public.deposit_lines
   where deposit_id = _id and (payment_id is not null or rent_payment_id is not null);
  select coalesce(jsonb_agg(jsonb_build_object('account', l.account_id, 'credit', greatest(l.amount, 0),
           'debit', greatest(-l.amount, 0), 'memo', concat_ws(' · ', l.name, l.description))), '[]'::jsonb)
    into lines from public.deposit_lines l
   where l.deposit_id = _id and l.payment_id is null and l.rent_payment_id is null and l.account_id is not null;
  perform public.write_entry(d.company_id, d.deposit_date, 'deposit', d.id, null, coalesce(d.memo, 'Deposit'),
    jsonb_build_array(
      jsonb_build_object('account', d.account_id, 'debit', tot, 'memo', coalesce(d.memo, 'Deposit')),
      jsonb_build_object('account', und, 'credit', held, 'memo', 'Payments deposited')) || lines);
end $$;

create or replace function public.post_transfer(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t record;
begin
  delete from public.journal_entries where source_type = 'transfer' and source_id = _id;
  select * into t from public.transfers where id = _id;
  if t.id is null or not public.books_open(t.company_id, t.transfer_date) then return; end if;
  perform public.write_entry(t.company_id, t.transfer_date, 'transfer', t.id, null, coalesce(t.memo, 'Transfer'),
    jsonb_build_array(
      jsonb_build_object('account', t.to_account_id, 'debit', t.amount, 'memo', coalesce(t.memo, 'Transfer in')),
      jsonb_build_object('account', t.from_account_id, 'credit', t.amount, 'memo', coalesce(t.memo, 'Transfer out'))));
end $$;

create or replace function public.trg_post_money()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  r := coalesce(new, old);
  case tg_table_name
    when 'checks' then perform public.post_check(r.id);
    when 'check_lines' then perform public.post_check(r.check_id);
    when 'bill_payments' then
      perform public.post_check(r.check_id);
      if tg_op = 'UPDATE' and old.check_id is distinct from new.check_id then perform public.post_check(old.check_id); end if;
    when 'payments' then
      perform public.post_check(r.check_id);
      if tg_op = 'UPDATE' and old.check_id is distinct from new.check_id then perform public.post_check(old.check_id); end if;
    when 'deposits' then perform public.post_deposit(r.id);
    when 'deposit_lines' then perform public.post_deposit(r.deposit_id);
    when 'transfers' then perform public.post_transfer(r.id);
  end case;
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['checks','check_lines','bill_payments','payments','deposits','deposit_lines','transfers'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_money', t);
  end loop;
  -- checks/deposits: only when the row itself changes, not when post_* updates its total
  create trigger checks_money after insert or delete or update of account_id, method, number, check_date, vendor_id, payee, memo, status
    on public.checks for each row execute function public.trg_post_money();
  create trigger deposits_money after insert or delete or update of account_id, deposit_date, memo
    on public.deposits for each row execute function public.trg_post_money();
  foreach t in array array['check_lines','bill_payments','payments','deposit_lines','transfers'] loop
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.trg_post_money()', t || '_money', t);
  end loop;
end $$;

-- Void a check: it stays (with its number) but pays nothing; bills and POs it paid are open again.
create or replace function public.void_check(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')) then raise exception 'Not allowed'; end if;
  if not exists (select 1 from public.checks where id = _id and company_id = public.active_company()) then
    raise exception 'Check not found';
  end if;
  delete from public.bill_payments where check_id = _id;
  delete from public.payments where check_id = _id;
  update public.checks set status = 'void', memo = trim(coalesce(memo, '') || ' (void)') where id = _id;
end $$;
grant execute on function public.void_check(uuid) to authenticated;

-- Payments sitting in Undeposited Funds, not yet in a deposit (sales and rent).
create or replace function public.undeposited_items()
returns table (kind text, id uuid, paid_on date, name text, ref text, method text, amount numeric)
language sql stable set search_path = public as $$
  -- Only payments whose entry in the books went into Undeposited Funds.
  with u as (select public.acct(public.active_company(), 'undeposited') a),
       held as (
         select e.source_type, e.source_id from public.journal_entries e
           join public.journal_lines l on l.entry_id = e.id, u
          where e.source_type in ('payment', 'rent_payment') and l.account_id = u.a and l.debit > 0)
  select 'payment', p.id, p.paid_on::date, o.customer_name, o.number, p.method, p.amount
    from public.payments p join public.sales_orders o on o.id = p.sales_order_id
   where exists (select 1 from held h where h.source_type = 'payment' and h.source_id = p.id)
     and not exists (select 1 from public.deposit_lines dl where dl.payment_id = p.id)
  union all
  select 'rent', rp.id, rp.paid_on, t.name, un.name, rp.method, rp.amount
    from public.rent_payments rp
    join public.rent_charges rc on rc.id = rp.charge_id
    join public.leases l on l.id = rc.lease_id
    join public.tenants t on t.id = l.tenant_id
    join public.units un on un.id = l.unit_id
   where exists (select 1 from held h where h.source_type = 'rent_payment' and h.source_id = rp.id)
     and not exists (select 1 from public.deposit_lines dl where dl.rent_payment_id = rp.id)
$$;
grant execute on function public.undeposited_items() to authenticated;

-- ---------- Rebuilding the books includes all of this ----------
create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust', 'history');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  for r in select id from public.rent_charges where company_id = _co loop perform public.post_rent_charge(r.id); end loop;
  for r in select id from public.rent_payments where company_id = _co loop perform public.post_rent_payment(r.id); end loop;
  for r in select id from public.work_orders where company_id = _co and status = 'done' loop perform public.post_work_order(r.id); end loop;
  for r in select id from public.checks where company_id = _co loop perform public.post_check(r.id); end loop;
  for r in select id from public.deposits where company_id = _co loop perform public.post_deposit(r.id); end loop;
  for r in select id from public.transfers where company_id = _co loop perform public.post_transfer(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;
