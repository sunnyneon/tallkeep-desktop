-- Tallkeep — step 43: Personal & family money.
--
-- A company can be "Personal": the same books (bank, cards, checks, Shoebox), with categories for
-- a household instead of a business, plus a monthly budget and investments.
-- * budgets: how much to spend (or earn) in a category each month.
-- * holdings: what's in an investment account (shares, what they cost, the latest price), so
--   net worth shows what the account is worth today.
-- * Picking "Personal" adds household categories and hides business accounts nobody has used yet
--   (nothing is deleted; they can be turned back on in Chart of Accounts).

create table if not exists public.budgets (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  amount numeric(14,2) not null default 0,     -- each month
  created_at timestamptz not null default now(),
  unique (company_id, account_id)
);

create table if not exists public.holdings (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  symbol text,                                  -- AAPL, VTI, BTC…
  name text not null,
  shares numeric(20,8) not null default 0,
  cost numeric(14,2) not null default 0,        -- what all the shares cost together
  price numeric(18,6) not null default 0,       -- latest price of one share
  price_date date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists holdings_company_idx on public.holdings (company_id, account_id);

do $$
declare t text;
begin
  foreach t in array array['budgets','holdings'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
    execute format('grant select, insert, update, delete on public.%I to service_role', t);
  end loop;
end $$;

-- ---------- Household categories ----------
create or replace function public.seed_personal_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.seed_accounts(_co);

  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, x.key
    from (values
      ('1010', 'Savings', 'asset', 'bank', null),
      ('1300', 'Investments', 'asset', 'other_asset', 'investments'),
      ('1310', 'Retirement (401k, IRA)', 'asset', 'other_asset', null),
      ('1520', 'Home', 'asset', 'fixed_asset', null),
      ('1530', 'Cars', 'asset', 'fixed_asset', null),
      ('2510', 'Mortgage', 'liability', 'long_term_liability', null),
      ('2520', 'Car Loan', 'liability', 'long_term_liability', null),
      ('2530', 'Student Loans', 'liability', 'long_term_liability', null),
      ('4300', 'Paychecks', 'income', 'income', null),
      ('4310', 'Interest and Dividends', 'income', 'other_income', null),
      ('4320', 'Gifts Received', 'income', 'other_income', null),
      ('4330', 'Refunds and Reimbursements', 'income', 'other_income', null),
      ('8000', 'Groceries', 'expense', 'expense', null),
      ('8010', 'Household', 'expense', 'expense', null),
      ('8020', 'Health and Medical', 'expense', 'expense', null),
      ('8030', 'Kids and School', 'expense', 'expense', null),
      ('8040', 'Clothing', 'expense', 'expense', null),
      ('8050', 'Shopping', 'expense', 'expense', null),
      ('8060', 'Fun and Entertainment', 'expense', 'expense', null),
      ('8070', 'Subscriptions', 'expense', 'expense', null),
      ('8080', 'Gifts and Donations', 'expense', 'expense', null),
      ('8090', 'Personal Care', 'expense', 'expense', null),
      ('8100', 'Pets', 'expense', 'expense', null),
      ('8110', 'Childcare', 'expense', 'expense', null),
      ('8120', 'Loan Interest', 'expense', 'expense', null),
      ('8130', 'Vacation', 'expense', 'expense', null)
    ) as x(number, name, type, kind, key)
   where not exists (select 1 from public.accounts a where a.company_id = _co
                      and ((x.key is not null and a.key = x.key) or a.number = x.number));

  -- Household names for the starter accounts, when nobody has used them yet.
  update public.accounts a set name = x.name
    from (values
      ('6400', 'Rent', 'Rent or Mortgage Payment'),
      ('6600', 'Vehicle and Fuel', 'Car and Gas'),
      ('7000', 'Meals', 'Dining Out'),
      ('7300', 'Taxes and Licenses', 'Taxes'),
      ('7400', 'Phone and Internet', 'Phone, Internet and TV'),
      ('7900', 'Other Expenses', 'Other Spending'),
      ('1500', 'Equipment and Vehicles', 'Other Things of Value'),
      ('6200', 'Insurance', 'Insurance (home, car, health, life)')
    ) as x(number, old, name)
   where a.company_id = _co and a.number = x.number and a.name = x.old
     and not exists (select 1 from public.journal_lines l where l.account_id = a.id);

  -- Hide the business-only accounts nobody has used (the app still knows them by key).
  update public.accounts a set is_active = false
   where a.company_id = _co and a.is_active
     and a.number in ('1100','1200','1590','2000','2200','2300','3100','3200','4000','4100',
                      '5000','5100','5200','6000','6300','6700','6900')
     and not exists (select 1 from public.journal_lines l where l.account_id = a.id);
end $$;
revoke all on function public.seed_personal_accounts(uuid) from public, anon, authenticated;
grant execute on function public.seed_personal_accounts(uuid) to service_role;

create or replace function public.trg_seed_personal()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.business_type = 'personal'
     and (tg_op = 'INSERT' or old.business_type is distinct from new.business_type) then
    perform public.seed_personal_accounts(new.company_id);
  end if;
  return new;
end $$;
drop trigger if exists company_settings_seed_personal on public.company_settings;
create trigger company_settings_seed_personal after insert or update of business_type on public.company_settings
  for each row execute function public.trg_seed_personal();
