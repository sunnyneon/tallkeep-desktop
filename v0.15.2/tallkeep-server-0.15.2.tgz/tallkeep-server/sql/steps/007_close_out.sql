-- SunRise Office — step 7: one-time "start fresh" for sales.
-- Marks every sales order / invoice as invoiced and fully paid as of a date, by adding a
-- payment for whatever balance is left (so totals still add up). Admin only. Quotes, RMAs
-- and cancelled documents are not touched. Optionally marks them shipped (stock is NOT changed).

create or replace function public.close_out_sales(_as_of timestamptz, _mark_shipped boolean default true)
returns json language plpgsql security definer set search_path = public as $$
declare n_inv int := 0; n_pay int := 0; amt numeric := 0; n_ship int := 0;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;

  -- 1. Not invoiced yet -> invoiced (invoice date = order date if missing).
  update public.sales_orders
     set status = 'invoiced', invoice_date = coalesce(invoice_date, order_date)
   where status = 'open' and number not like 'RMA-%';
  get diagnostics n_inv = row_count;

  -- 2. Pay off what's left with one payment each.
  select count(*), coalesce(sum(balance), 0) into n_pay, amt
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%';
  insert into public.payments (sales_order_id, paid_on, amount, method, remarks, created_by)
  select id, _as_of, balance, 'Paid before switch-over', 'Marked paid when moving from inFlow', auth.uid()
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%';

  -- 3. Anything invoiced with nothing owed is paid.
  update public.sales_orders set status = 'paid'
   where status = 'invoiced' and balance <= 0.005 and number not like 'RMA-%';

  -- 4. Optionally: mark as shipped (no stock change).
  if _mark_shipped then
    update public.sales_orders set stock_taken_at = _as_of
     where stock_taken_at is null and status in ('paid','completed','invoiced') and number not like 'RMA-%';
    get diagnostics n_ship = row_count;
  end if;

  return json_build_object('invoiced', n_inv, 'payments', n_pay, 'amount', amt, 'shipped', n_ship);
end $$;
grant execute on function public.close_out_sales(timestamptz, boolean) to authenticated;
