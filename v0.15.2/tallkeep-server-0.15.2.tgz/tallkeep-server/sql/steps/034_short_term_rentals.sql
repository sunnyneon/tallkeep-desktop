-- Tallkeep — step 34: short-term rentals (Airbnb, VRBO, Booking.com, direct) in the Real estate
-- add-on.
--
-- * A unit is rented long-term (leases, monthly rent) or short-term (stays by the night).
--   Short-term units have a nightly rate, cleaning fee, minimum nights, most guests, lodging tax.
-- * stays: one booking: guest, where it came from, check-in and check-out, the money (nights,
--   cleaning fee, other fees, taxes you collect, the platform's fee) and the payout.
-- * Two stays can't overlap in the same unit.
-- * When the payout is received, it goes into the books: the payout into the bank, the platform's
--   fee as an expense, the nights and fees as income, the taxes as owed to the city/state.

alter table public.units add column if not exists rental_type text not null default 'long';
do $$ begin
  alter table public.units add constraint units_rental_type_check check (rental_type in ('long', 'short'));
exception when duplicate_object then null; end $$;
alter table public.units add column if not exists nightly_rate numeric(14,2);
alter table public.units add column if not exists cleaning_fee numeric(14,2);
alter table public.units add column if not exists min_nights int;
alter table public.units add column if not exists max_guests int;
alter table public.units add column if not exists lodging_tax_pct numeric(6,3);
alter table public.units add column if not exists check_in_time text;
alter table public.units add column if not exists check_out_time text;
alter table public.units add column if not exists listing_url text;

create table if not exists public.stays (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  unit_id uuid not null references public.units(id) on delete cascade,
  guest_name text not null,
  guest_email text,
  guest_phone text,
  guests int,
  channel text not null default 'airbnb' check (channel in ('airbnb','vrbo','booking','direct','other')),
  confirmation text,                               -- the platform's confirmation code
  check_in date not null,
  check_out date not null,
  nights int generated always as (check_out - check_in) stored,
  rent numeric(14,2) not null default 0,           -- all the nights together
  cleaning_fee numeric(14,2) not null default 0,
  other_fees numeric(14,2) not null default 0,     -- pet fee, extra guest, early check-in…
  taxes numeric(14,2) not null default 0,          -- lodging taxes you collect and pay yourself
  platform_fee numeric(14,2) not null default 0,   -- Airbnb/VRBO host fee or card fees
  payout numeric(14,2) generated always as (rent + cleaning_fee + other_fees + taxes - platform_fee) stored,
  status text not null default 'booked' check (status in ('booked','canceled')),
  paid_on date,                                    -- the day the payout reached the bank
  account_id uuid references public.accounts(id),  -- the bank it went to
  notes text,
  created_at timestamptz not null default now(),
  check (check_out > check_in)
);
create index if not exists stays_unit_idx on public.stays (unit_id, check_in);
create index if not exists stays_dates_idx on public.stays (company_id, check_in);

alter table public.stays enable row level security;
drop policy if exists "Staff can use" on public.stays;
create policy "Staff can use" on public.stays for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()));
grant select, insert, update, delete on public.stays to authenticated;

-- No double bookings.
create or replace function public.trg_stay_overlap()
returns trigger language plpgsql security definer set search_path = public as $$
declare other record;
begin
  if new.status = 'canceled' then return new; end if;
  select s.guest_name, s.check_in, s.check_out into other
    from public.stays s
   where s.unit_id = new.unit_id and s.id <> new.id and s.status <> 'canceled'
     and s.check_in < new.check_out and new.check_in < s.check_out
   limit 1;
  if found then
    raise exception 'That unit is already booked then (% from % to %).',
      other.guest_name, to_char(other.check_in, 'Mon DD'), to_char(other.check_out, 'Mon DD');
  end if;
  return new;
end $$;
drop trigger if exists stays_overlap on public.stays;
create trigger stays_overlap before insert or update on public.stays
  for each row execute function public.trg_stay_overlap();

-- Accounts for short stays.
create or replace function public.seed_short_stay_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.seed_real_estate_accounts(_co);
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, x.key
    from (values
      ('4250', 'Short-Term Rental Income', 'income', 'income', 'stay_income'),
      ('4260', 'Cleaning Fee Income', 'income', 'income', 'cleaning_income'),
      ('4270', 'Other Guest Fees', 'income', 'income', 'guest_fees'),
      ('2360', 'Lodging Taxes Owed', 'liability', 'other_liability', 'lodging_tax'),
      ('6160', 'Booking Platform Fees', 'expense', 'expense', 'platform_fees')
    ) as x(number, name, type, kind, key)
   where not exists (select 1 from public.accounts a where a.company_id = _co
                      and ((x.key is not null and a.key = x.key) or a.number = x.number));
end $$;

-- A stay's payout, into the books (once it's received).
create or replace function public.post_stay(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare s record; bank uuid; memo text;
begin
  delete from public.journal_entries where source_type = 'stay' and source_id = _id;
  select st.*, u.property_id, u.name as unit into s
    from public.stays st join public.units u on u.id = st.unit_id
   where st.id = _id;
  if s.id is null or s.paid_on is null or not public.books_open(s.company_id, s.paid_on) then return; end if;
  perform public.seed_short_stay_accounts(s.company_id);
  bank := coalesce(s.account_id,
    (select default_bank_account_id from public.company_settings where company_id = s.company_id),
    public.acct(s.company_id, 'bank'));
  memo := s.guest_name || ' · ' || to_char(s.check_in, 'Mon DD') || '–' || to_char(s.check_out, 'Mon DD');
  perform public.write_entry(s.company_id, s.paid_on, 'stay', s.id, coalesce(s.confirmation, s.unit),
    'Stay · ' || memo,
    jsonb_build_array(
      jsonb_build_object('account', bank, 'debit', greatest(s.payout, 0), 'credit', greatest(-s.payout, 0), 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'platform_fees'), 'debit', s.platform_fee, 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'stay_income'), 'credit', s.rent, 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'cleaning_income'), 'credit', s.cleaning_fee, 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'guest_fees'), 'credit', s.other_fees, 'property', s.property_id, 'memo', memo),
      jsonb_build_object('account', public.acct(s.company_id, 'lodging_tax'), 'credit', s.taxes, 'property', s.property_id, 'memo', memo)));
end $$;

create or replace function public.trg_post_stay()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' then
    delete from public.journal_entries where source_type = 'stay' and source_id = old.id;
    return old;
  end if;
  perform public.post_stay(new.id);
  return new;
end $$;
drop trigger if exists stays_post on public.stays;
create trigger stays_post after insert or update or delete on public.stays
  for each row execute function public.trg_post_stay();

-- Rebuilding the books includes stays (same as step 21, plus stays).
create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust', 'history');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  for r in select id from public.rent_charges where company_id = _co loop perform public.post_rent_charge(r.id); end loop;
  for r in select id from public.rent_payments where company_id = _co loop perform public.post_rent_payment(r.id); end loop;
  for r in select id from public.stays where company_id = _co loop perform public.post_stay(r.id); end loop;
  for r in select id from public.work_orders where company_id = _co and status = 'done' loop perform public.post_work_order(r.id); end loop;
  for r in select id from public.checks where company_id = _co loop perform public.post_check(r.id); end loop;
  for r in select id from public.deposits where company_id = _co loop perform public.post_deposit(r.id); end loop;
  for r in select id from public.transfers where company_id = _co loop perform public.post_transfer(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;
