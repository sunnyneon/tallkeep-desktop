-- Tallkeep — step 40: Tallkeep Connect, on Tallkeep's own server (app.tallkeep.com).
--
-- A Tallkeep Desktop license can add Connect ($/month, Stripe subscription): the office computer
-- gets its own web address (like sunrise-led.tallkeep.app) through a Cloudflare tunnel, so phones,
-- people at home and Airbnb's calendar can reach it. One row per license.
-- tunnel_token is the secret the office computer runs the tunnel with; it's only given to the
-- computer that holds the license key. Only the server (service role) reads or writes this.
create table if not exists public.connect_subscriptions (
  id uuid primary key default gen_random_uuid(),
  license_id text not null unique references public.desktop_licenses(id) on delete cascade,
  stripe_customer text,
  stripe_subscription text unique,
  status text not null default 'none',      -- Stripe's: active, trialing, past_due, canceled, …
  current_period_end timestamptz,
  hostname text unique,                      -- sunrise-led-7k2.tallkeep.app
  tunnel_id text,
  tunnel_token text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.connect_subscriptions enable row level security;
revoke all on public.connect_subscriptions from anon, authenticated;
grant select, insert, update, delete on public.connect_subscriptions to service_role;
