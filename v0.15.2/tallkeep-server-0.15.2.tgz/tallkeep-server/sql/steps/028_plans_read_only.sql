-- SunRise Office / Tallkeep — step 28: plan limits, and read-only when the trial ends.
--
-- * orgs.edition: 'cloud' or 'desktop'. companies_allowed / users_allowed: how many the plan
--   includes (empty = no limit, as for our own group). Free trials get 3 companies and 5 people.
-- * When a trial ends or an account is canceled, its books become read-only: people can still
--   open, print and download everything, but can't add, change or delete. Our own group is never
--   read-only. Paying accounts ('active') and late payers ('past_due', a grace period) can write.
-- * Adding a company stops at the plan's limit.

alter table public.orgs add column if not exists edition text not null default 'cloud';
alter table public.orgs drop constraint if exists orgs_edition_check;
alter table public.orgs add constraint orgs_edition_check check (edition in ('cloud', 'desktop'));
alter table public.orgs add column if not exists companies_allowed int;
alter table public.orgs add column if not exists users_allowed int;
alter table public.orgs alter column companies_allowed set default 3;
alter table public.orgs alter column users_allowed set default 5;
update public.orgs set companies_allowed = 3, users_allowed = 5
 where not is_platform and companies_allowed is null and users_allowed is null;

-- Can this account still add and change things?
create or replace function public.org_can_write(_org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select o.is_platform
                          or o.status in ('active', 'past_due')
                          or (o.status = 'trial' and (o.trial_ends_at is null or o.trial_ends_at > now()))
                     from public.orgs o where o.id = _org), true)
$$;
grant execute on function public.org_can_write(uuid) to authenticated;

-- Same, for the account a company belongs to.
create or replace function public.can_write_company(_c uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select _c is null or public.org_can_write((select org_id from public.companies where id = _c))
$$;
grant execute on function public.can_write_company(uuid) to authenticated;

-- Every business table (every table with a company_id) gets an extra rule: no adding, changing
-- or deleting while the account is read-only. Picking which company you're working in still works.
do $$
declare t text;
begin
  for t in
    select c.table_name from information_schema.columns c
      join information_schema.tables x on x.table_schema = c.table_schema and x.table_name = c.table_name
     where c.table_schema = 'public' and c.column_name = 'company_id' and x.table_type = 'BASE TABLE'
       and c.table_name not in ('user_company', 'company_members')
  loop
    execute format('drop policy if exists "Read-only when the plan ends (add)" on public.%I', t);
    execute format('drop policy if exists "Read-only when the plan ends (change)" on public.%I', t);
    execute format('drop policy if exists "Read-only when the plan ends (delete)" on public.%I', t);
    execute format('create policy "Read-only when the plan ends (add)" on public.%I as restrictive for insert to authenticated with check (public.can_write_company(company_id))', t);
    execute format('create policy "Read-only when the plan ends (change)" on public.%I as restrictive for update to authenticated using (public.can_write_company(company_id))', t);
    execute format('create policy "Read-only when the plan ends (delete)" on public.%I as restrictive for delete to authenticated using (public.can_write_company(company_id))', t);
  end loop;
end $$;

-- Add a company (admin): in your own account, within the plan, copied from the company you're in.
create or replace function public.create_company(_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare n uuid; o uuid := public.my_org(); lim int;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can add a company.'; end if;
  if o is null then raise exception 'Your account is not set up yet.'; end if;
  if not public.org_can_write(o) then
    raise exception 'Your account is read-only. Choose a plan to keep working.';
  end if;
  select companies_allowed into lim from public.orgs where id = o;
  if lim is not null and (select count(*) from public.companies where org_id = o) >= lim then
    raise exception 'Your plan includes % compan%. Add another company to your plan first.',
      lim, case when lim = 1 then 'y' else 'ies' end;
  end if;
  if coalesce(trim(_name), '') = '' then raise exception 'Type the company name.'; end if;
  n := public.make_company(o, trim(_name), null, null, auth.uid(), public.active_company());
  -- Same taxes as the company you're working in.
  insert into public.tax_rates (company_id, name, rate, is_active)
    select n, name, rate, is_active from public.tax_rates where company_id = public.active_company();
  return n;
end $$;
grant execute on function public.create_company(text) to authenticated;
