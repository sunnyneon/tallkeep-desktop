-- SunRise Office — step 6: only people an admin added (they have a role) can see or change data.
-- Someone who signs up on their own gets no role, so they see nothing.

create or replace function public.is_staff(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _uid)
$$;
grant execute on function public.is_staff(uuid) to authenticated;

-- New accounts get no role automatically anymore (the very first account still becomes admin).
-- Admins add people in Settings -> Users, which gives them a role.
create or replace function public.handle_new_user_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;

-- Add "and is a staff member" to every rule for signed-in users on our tables and photo storage.
do $$
declare p record;
begin
  for p in
    select schemaname, tablename, policyname, qual, with_check
    from pg_policies
    where (schemaname = 'public' or (schemaname = 'storage' and tablename = 'objects'
             and coalesce(qual, with_check) like '%product-photos%'))
      and 'authenticated' = any(roles)
      and tablename <> 'user_roles'
      and coalesce(qual, '') not like '%is_staff%'
      and coalesce(with_check, '') not like '%is_staff%'
  loop
    if p.qual is not null then
      execute format('alter policy %I on %I.%I using ((%s) and public.is_staff(auth.uid()))',
        p.policyname, p.schemaname, p.tablename, p.qual);
    end if;
    if p.with_check is not null then
      execute format('alter policy %I on %I.%I with check ((%s) and public.is_staff(auth.uid()))',
        p.policyname, p.schemaname, p.tablename, p.with_check);
    end if;
  end loop;
end $$;

-- Stock changes and new document numbers also require a staff member. Every stock action
-- (move, count, receive, pick, documents) goes through change_stock.
do $$
declare src text;
begin
  select pg_get_functiondef('public.change_stock(uuid,uuid,text,numeric,text,text,text,uuid)'::regprocedure) into src;
  if src not like '%is_staff%' then
    src := replace(src, 'if auth.uid() is null then raise exception ''Please sign in''; end if;',
      'if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception ''Please sign in''; end if;');
    execute src;
  end if;
  select pg_get_functiondef('public.next_doc_number(text)'::regprocedure) into src;
  if src not like '%is_staff%' then
    src := replace(src, 'begin
  update public.doc_counters',
      'begin
  if not public.is_staff(auth.uid()) then raise exception ''Please sign in''; end if;
  update public.doc_counters');
    execute src;
  end if;
end $$;
