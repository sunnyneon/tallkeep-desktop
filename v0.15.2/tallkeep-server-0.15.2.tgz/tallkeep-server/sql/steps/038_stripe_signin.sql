-- Tallkeep — step 38: a business can connect the Stripe account it already has (it signs in to
-- Stripe), instead of making a new one. While it's signing in, we keep a one-time code (oauth_state)
-- and where to send it back to (oauth_return). Server only, like step 37.
alter table public.pay_merchants add column if not exists oauth_state text;
alter table public.pay_merchants add column if not exists oauth_return text;
create unique index if not exists pay_merchants_oauth_state_idx on public.pay_merchants (oauth_state)
  where oauth_state is not null;
