-- Tallkeep — step 42: the Shoebox.
--
-- Drop bank and card statements, receipts, bills and checks in one place. Tallkeep works out what
-- each file is, reads it, and puts it where it belongs: statement lines into Bank Feeds (and into
-- the books when sure), receipts into Receipts, bills into Bills, checks into Checks Received.
-- What it isn't sure of waits here for one click.
-- The files are kept in the private "receipts" storage (<company id>/shoebox/<file>).

create table if not exists public.shoebox_items (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  created_at timestamptz not null default now(),
  created_by uuid,
  file_name text not null,
  file_path text,
  mime text,
  size int,
  hash text,                       -- the file's fingerprint: the same file isn't read twice
  kind text not null default 'unknown'
    check (kind in ('statement','receipt','bill','check','unknown')),
  status text not null default 'reading'
    check (status in ('reading','done','needs_you','failed','skipped')),
  account_id uuid references public.accounts(id) on delete set null,  -- statements
  summary text,                    -- what happened, in plain words
  ai jsonb,                        -- what the AI read
  target_type text,                -- receipt, bill, bank_import, check
  target_id uuid,
  error text
);
create index if not exists shoebox_items_company_idx on public.shoebox_items (company_id, created_at desc);
create unique index if not exists shoebox_items_hash_idx on public.shoebox_items (company_id, hash)
  where hash is not null;

grant select, insert, update, delete on public.shoebox_items to authenticated;
grant select, insert, update, delete on public.shoebox_items to service_role;

alter table public.shoebox_items enable row level security;
drop policy if exists "Staff can use" on public.shoebox_items;
create policy "Staff can use" on public.shoebox_items for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()));
