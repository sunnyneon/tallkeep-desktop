-- SunRise Office / Tallkeep — step 29: Tallkeep's own settings (price list, trial length).
--
-- * platform_settings: one row per setting, for the Tallkeep admin panel. Only the server reads and
--   writes it (no access for signed-in people). The website reads the price list through the
--   app's public price link.
-- * start_trial() now takes the trial length from the price list (30 days if not set).

create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid
);

grant select, insert, update, delete on public.platform_settings to service_role;

alter table public.platform_settings enable row level security;

insert into public.platform_settings (key, value) values ('prices', '{
  "trial_days": 30,
  "desktop": {"base": 799, "base_companies": 1, "base_users": 3, "extra_company": 199, "extra_user": 99, "connect_monthly": 15, "updates_yearly": 199},
  "cloud": {"monthly": 29, "base_companies": 1, "base_users": 2, "extra_company": 15, "extra_user": 8, "yearly_months_free": 2},
  "ai_pack": {"price": 10, "pages": 500},
  "founders": {"desktop": 499, "cloud_discount_pct": 40, "limit": 100}
}'::jsonb)
on conflict (key) do nothing;

-- A person who just signed up: make their account (free trial as long as the price list says),
-- make them its admin, and set up their first company.
create or replace function public.start_trial(_company text, _business_type text, _addons text[])
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); o uuid; n uuid; days int;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if exists (select 1 from public.org_members where user_id = uid)
     or exists (select 1 from public.user_roles where user_id = uid) then
    raise exception 'You already have an account. Sign in to open it.';
  end if;
  if coalesce(trim(_company), '') = '' then raise exception 'Type your company name.'; end if;
  if length(trim(_company)) > 120 then raise exception 'That company name is too long.'; end if;
  select least(greatest(coalesce((value->>'trial_days')::int, 30), 1), 365) into days
    from public.platform_settings where key = 'prices';
  insert into public.orgs (name, status, trial_ends_at, created_by)
  values (trim(_company), 'trial', now() + make_interval(days => coalesce(days, 30)), uid)
  returning id into o;
  insert into public.org_members (org_id, user_id) values (o, uid);
  insert into public.user_roles (user_id, role) values (uid, 'admin');
  n := public.make_company(o, trim(_company), _business_type,
                           (select array(select x from unnest(_addons) x
                                          where x in ('sales','purchasing','inventory','accounting',
                                                      'work_orders','tickets','real_estate','tech_pay'))),
                           uid, null);
  insert into public.user_company (user_id, company_id) values (uid, n)
  on conflict (user_id) do update set company_id = excluded.company_id;
  return n;
end $$;
grant execute on function public.start_trial(text, text, text[]) to authenticated;
