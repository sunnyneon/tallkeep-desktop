-- SunRise Office — core database (step 1)
-- Products, stock in any number of places, customers, vendors,
-- quotes / sales orders / invoices, purchase orders, payments.
-- Every table keeps `inflow_id` so data imported from inFlow can be matched later.

-- ========== Roles ==========
create type public.app_role as enum ('admin', 'staff');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "Users see their own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Admins manage roles" on public.user_roles
  for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

-- The first person to sign up becomes admin; everyone after is staff.
create or replace function public.handle_new_user_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'staff');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_role after insert on auth.users
  for each row execute function public.handle_new_user_role();

-- ========== Helpers ==========
create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end $$;

-- ========== Lookups ==========
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  parent_id uuid references public.categories(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.locations (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Shelves / bins / spots inside a location. Optional and unlimited.
create table public.shelves (
  id uuid primary key default gen_random_uuid(),
  location_id uuid not null references public.locations(id) on delete cascade,
  name text not null,
  created_at timestamptz not null default now(),
  unique (location_id, name)
);

create table public.price_lists (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  is_default boolean not null default false,
  is_active boolean not null default true
);

create table public.payment_terms (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  days_due int not null default 0,
  is_active boolean not null default true
);

create table public.tax_rates (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  rate numeric(9,5) not null default 0,   -- percent, e.g. 8.25
  is_active boolean not null default true
);

-- ========== Products ==========
create table public.products (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  description text,
  item_type text not null default 'stocked' check (item_type in ('stocked','non_stocked','service')),
  category_id uuid references public.categories(id) on delete set null,
  barcode text,
  unit text,                         -- e.g. "ea"
  sell_unit text, sell_unit_ratio numeric(14,4) default 1,
  buy_unit text,  buy_unit_ratio  numeric(14,4) default 1,
  cost numeric(14,4) not null default 0,
  price numeric(14,4) not null default 0,   -- default selling price
  reorder_point numeric(14,4),
  reorder_qty numeric(14,4),
  default_location_id uuid references public.locations(id) on delete set null,
  default_shelf text,
  track_serials boolean not null default false,
  weight numeric(14,4), length numeric(14,4), width numeric(14,4), height numeric(14,4),
  picture_path text,                  -- file in the "product-photos" storage bucket
  custom jsonb not null default '{}'::jsonb,
  remarks text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_name_idx on public.products using gin (to_tsvector('simple', name || ' ' || coalesce(description,'') || ' ' || coalesce(barcode,'')));
create index products_barcode_idx on public.products (barcode);
create trigger products_touch before update on public.products for each row execute function public.touch_updated_at();

create table public.product_prices (
  product_id uuid not null references public.products(id) on delete cascade,
  price_list_id uuid not null references public.price_lists(id) on delete cascade,
  price numeric(14,4) not null default 0,
  primary key (product_id, price_list_id)
);

create table public.serial_numbers (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  product_id uuid not null references public.products(id) on delete cascade,
  serial text not null,
  location_id uuid references public.locations(id) on delete set null,
  status text not null default 'in_stock' check (status in ('in_stock','sold','returned','scrapped')),
  unique (product_id, serial)
);

-- ========== Stock ==========
-- How many of each product sit in each place. shelf '' = no shelf.
create table public.stock (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  location_id uuid not null references public.locations(id) on delete cascade,
  shelf text not null default '',
  qty numeric(14,4) not null default 0,
  updated_at timestamptz not null default now(),
  unique (product_id, location_id, shelf)
);
create index stock_product_idx on public.stock (product_id);

-- Every change to stock, for history ("who moved what, when, why").
create table public.stock_moves (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  location_id uuid not null references public.locations(id) on delete cascade,
  shelf text not null default '',
  qty_change numeric(14,4) not null,
  reason text not null,              -- 'count', 'adjust', 'move_in', 'move_out', 'sold', 'received', 'returned', 'import'
  note text,
  ref_type text, ref_id uuid,
  user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index stock_moves_product_idx on public.stock_moves (product_id, created_at desc);

-- Change stock in one place and log it. Use for adjust / count / receive / sell.
create or replace function public.change_stock(
  _product_id uuid, _location_id uuid, _shelf text, _qty_change numeric,
  _reason text, _note text default null, _ref_type text default null, _ref_id uuid default null)
returns numeric language plpgsql security definer set search_path = public as $$
declare new_qty numeric;
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  insert into public.stock (product_id, location_id, shelf, qty)
    values (_product_id, _location_id, coalesce(_shelf,''), _qty_change)
  on conflict (product_id, location_id, shelf)
    do update set qty = public.stock.qty + excluded.qty, updated_at = now()
  returning qty into new_qty;
  insert into public.stock_moves (product_id, location_id, shelf, qty_change, reason, note, ref_type, ref_id, user_id)
    values (_product_id, _location_id, coalesce(_shelf,''), _qty_change, _reason, _note, _ref_type, _ref_id, auth.uid());
  return new_qty;
end $$;

-- Set the counted quantity in one place (stock count).
create or replace function public.set_stock_count(
  _product_id uuid, _location_id uuid, _shelf text, _counted numeric, _note text default null)
returns numeric language plpgsql security definer set search_path = public as $$
declare cur numeric;
begin
  select qty into cur from public.stock
   where product_id = _product_id and location_id = _location_id and shelf = coalesce(_shelf,'');
  return public.change_stock(_product_id, _location_id, _shelf, _counted - coalesce(cur,0), 'count', _note);
end $$;

-- Move stock from one place to another.
create or replace function public.move_stock(
  _product_id uuid, _from_location uuid, _from_shelf text, _to_location uuid, _to_shelf text,
  _qty numeric, _note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if _qty <= 0 then raise exception 'Quantity must be more than 0'; end if;
  perform public.change_stock(_product_id, _from_location, _from_shelf, -_qty, 'move_out', _note);
  perform public.change_stock(_product_id, _to_location, _to_shelf, _qty, 'move_in', _note);
end $$;

-- Total on hand per product.
create or replace view public.product_stock_totals with (security_invoker = on) as
  select p.id as product_id, coalesce(sum(s.qty),0) as on_hand
  from public.products p left join public.stock s on s.product_id = p.id
  group by p.id;

-- ========== Customers & vendors ==========
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  contact_name text, phone text, fax text, email text, website text,
  address text,            -- main address, multi-line
  billing_address text,
  shipping_address text,
  payment_terms_id uuid references public.payment_terms(id) on delete set null,
  price_list_id uuid references public.price_lists(id) on delete set null,
  tax_rate_id uuid references public.tax_rates(id) on delete set null,
  discount numeric(9,4) default 0,
  sales_rep text,
  tax_exempt_number text,
  remarks text,
  custom jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index customers_name_idx on public.customers (lower(name));
create trigger customers_touch before update on public.customers for each row execute function public.touch_updated_at();

create table public.vendors (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  name text not null,
  contact_name text, phone text, fax text, email text, website text,
  address text,
  payment_terms_id uuid references public.payment_terms(id) on delete set null,
  remarks text,
  custom jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index vendors_name_idx on public.vendors (lower(name));
create trigger vendors_touch before update on public.vendors for each row execute function public.touch_updated_at();

create table public.vendor_items (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  vendor_id uuid not null references public.vendors(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  vendor_code text,
  cost numeric(14,4) not null default 0
);

-- ========== Quotes / sales orders / invoices ==========
-- One table: a quote becomes an order, then an invoice.
create table public.sales_orders (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  number text not null,
  status text not null default 'quote'
    check (status in ('quote','open','invoiced','paid','completed','cancelled')),
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text,          -- kept in case the customer is later removed
  contact_name text, phone text, email text,
  po_number text,
  sales_rep text,
  location_id uuid references public.locations(id) on delete set null,
  order_date timestamptz not null default now(),
  ship_by date,
  invoice_date timestamptz,
  due_date timestamptz,
  payment_terms_id uuid references public.payment_terms(id) on delete set null,
  billing_address text,
  shipping_address text,
  tax_name text, tax_rate numeric(9,5) default 0,
  subtotal numeric(14,2) not null default 0,
  tax numeric(14,2) not null default 0,
  shipping numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  amount_paid numeric(14,2) not null default 0,
  balance numeric(14,2) not null default 0,
  remarks text,
  custom jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index sales_orders_customer_idx on public.sales_orders (customer_id);
create index sales_orders_date_idx on public.sales_orders (order_date desc);
create trigger sales_orders_touch before update on public.sales_orders for each row execute function public.touch_updated_at();

create table public.sales_order_lines (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  sales_order_id uuid not null references public.sales_orders(id) on delete cascade,
  line_no int not null default 0,
  product_id uuid references public.products(id) on delete set null,
  description text,
  qty numeric(14,4) not null default 1,
  unit text,
  unit_price numeric(14,4) not null default 0,
  discount numeric(14,4) not null default 0,
  discount_is_percent boolean not null default true,
  taxable boolean not null default true,
  line_total numeric(14,2) not null default 0,
  serials text
);
create index sales_order_lines_order_idx on public.sales_order_lines (sales_order_id, line_no);

-- ========== Purchase orders ==========
create table public.purchase_orders (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  number text not null,
  status text not null default 'open'
    check (status in ('draft','open','received','paid','completed','cancelled')),
  vendor_id uuid references public.vendors(id) on delete set null,
  vendor_name text,
  vendor_order_number text,
  contact_name text, phone text,
  vendor_address text,
  ship_to_address text,
  location_id uuid references public.locations(id) on delete set null,
  order_date timestamptz not null default now(),
  due_date timestamptz,
  payment_terms_id uuid references public.payment_terms(id) on delete set null,
  carrier text,
  tax_name text, tax_rate numeric(9,5) default 0,
  subtotal numeric(14,2) not null default 0,
  tax numeric(14,2) not null default 0,
  freight numeric(14,2) not null default 0,
  total numeric(14,2) not null default 0,
  amount_paid numeric(14,2) not null default 0,
  balance numeric(14,2) not null default 0,
  remarks text,
  custom jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index purchase_orders_vendor_idx on public.purchase_orders (vendor_id);
create trigger purchase_orders_touch before update on public.purchase_orders for each row execute function public.touch_updated_at();

create table public.purchase_order_lines (
  id uuid primary key default gen_random_uuid(),
  inflow_id int unique,
  purchase_order_id uuid not null references public.purchase_orders(id) on delete cascade,
  line_no int not null default 0,
  product_id uuid references public.products(id) on delete set null,
  vendor_code text,
  description text,
  qty numeric(14,4) not null default 1,
  unit text,
  unit_cost numeric(14,4) not null default 0,
  discount numeric(14,4) not null default 0,
  discount_is_percent boolean not null default true,
  line_total numeric(14,2) not null default 0,
  qty_received numeric(14,4) not null default 0
);
create index purchase_order_lines_order_idx on public.purchase_order_lines (purchase_order_id, line_no);

-- ========== Payments ==========
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  inflow_id text unique,               -- 'so-123' / 'po-45'
  sales_order_id uuid references public.sales_orders(id) on delete cascade,
  purchase_order_id uuid references public.purchase_orders(id) on delete cascade,
  paid_on timestamptz not null default now(),
  amount numeric(14,2) not null,
  method text,
  reference text,
  remarks text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  check ((sales_order_id is null) <> (purchase_order_id is null))
);

-- ========== Document numbers ==========
create table public.doc_counters (
  kind text primary key,      -- 'quote', 'sales_order', 'purchase_order'
  prefix text not null,
  next_number int not null
);

create or replace function public.next_doc_number(_kind text)
returns text language plpgsql security definer set search_path = public as $$
declare p text; n int;
begin
  update public.doc_counters set next_number = next_number + 1
   where kind = _kind returning prefix, next_number - 1 into p, n;
  if p is null then raise exception 'Unknown document type %', _kind; end if;
  return p || lpad(n::text, 6, '0');
end $$;

-- ========== Security: signed-in staff can use everything ==========
do $$
declare t text;
begin
  foreach t in array array['categories','locations','shelves','price_lists','payment_terms','tax_rates',
    'products','product_prices','serial_numbers','stock','stock_moves','customers','vendors','vendor_items',
    'sales_orders','sales_order_lines','purchase_orders','purchase_order_lines','payments','doc_counters']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy "Staff can read" on public.%I for select to authenticated using (true)', t);
    execute format('create policy "Staff can add" on public.%I for insert to authenticated with check (true)', t);
    execute format('create policy "Staff can edit" on public.%I for update to authenticated using (true) with check (true)', t);
    execute format('create policy "Admins can delete" on public.%I for delete to authenticated using (public.has_role(auth.uid(), ''admin''))', t);
  end loop;
end $$;

-- Stock history is append-only: nobody edits or deletes it from the app.
drop policy "Staff can edit" on public.stock_moves;
drop policy "Admins can delete" on public.stock_moves;

-- ========== Photos ==========
-- The private "product-photos" bucket and its 4 policies were created with
-- Lovable's storage tool (storage can't be created inside a migration).
-- Staff can read/add/change photos; only admins can delete.

-- ========== Grants ==========
-- Lovable added GRANTs so signed-in staff (role "authenticated") can use the
-- tables, the product_stock_totals view and the stock/number functions.

-- Run separately after the migration (data change):
-- Anyone who already signed up before this step becomes admin.
insert into public.user_roles (user_id, role)
  select id, 'admin' from auth.users
  on conflict (user_id, role) do nothing;
