-- SunRise Office / Tallkeep — step 26: every company must belong to an account.
-- Step 25 filled companies.org_id in; from now on it can't be empty.
alter table public.companies alter column org_id set not null;
