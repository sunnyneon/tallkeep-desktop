-- SunRise Office — step 8: quote follow-ups and closing old quotes.

-- The rules (Settings → Quote follow-ups). Off until an admin turns them on.
alter table public.company_settings add column followup_enabled boolean not null default false;
alter table public.company_settings add column followup_days1 int not null default 14;   -- 1st follow-up
alter table public.company_settings add column followup_days2 int not null default 30;   -- 2nd follow-up
alter table public.company_settings add column quote_close_days int not null default 45; -- close the quote
alter table public.company_settings add column followup_auto_email boolean not null default false; -- email customers automatically

-- What happened on each quote.
alter table public.sales_orders add column followup_count int not null default 0;
alter table public.sales_orders add column last_followup_at timestamptz;
alter table public.sales_orders add column closed_reason text;
