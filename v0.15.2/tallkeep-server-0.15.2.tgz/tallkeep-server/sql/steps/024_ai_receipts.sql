-- SunRise Office — step 24: AI reading (PDF bank statements, receipts), AI usage log, receipts.
--
-- * ai_usage: one row per AI use (which company, what for, size, estimated cost). Written by the
--   server only; staff can read their company's rows.
-- * ai_settings: which AI a company uses ('vooska' = built in, or their own OpenAI / Google /
--   Anthropic account), the model, and a monthly spending cap for the built-in AI.
-- * ai_keys: a company's own AI key. Server only: nobody can read it from the app.
-- * receipts: a photo or PDF of a receipt, what the AI read from it, and what it became
--   (a matched bank line or a payment). Files live in the private 'receipts' storage bucket,
--   in a folder named after the company.
-- Security: staff with the Accounting section, in the active company.

create table if not exists public.ai_usage (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid,
  feature text not null,
  provider text not null,
  model text not null,
  pages integer not null default 0,
  input_tokens integer not null default 0,
  output_tokens integer not null default 0,
  cost_usd numeric(12,6) not null default 0,
  own_key boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists ai_usage_company_idx on public.ai_usage (company_id, created_at);

grant select on public.ai_usage to authenticated;
grant select, insert, update, delete on public.ai_usage to service_role;

alter table public.ai_usage enable row level security;
drop policy if exists "Staff can read" on public.ai_usage;
create policy "Staff can read" on public.ai_usage for select to authenticated
  using (public.is_staff(auth.uid()) and company_id = (select public.active_company()));

create table if not exists public.ai_settings (
  company_id uuid primary key references public.companies(id) on delete cascade,
  provider text not null default 'vooska' check (provider in ('vooska','openai','google','anthropic')),
  model text,
  monthly_cap_usd numeric(10,2),
  updated_at timestamptz not null default now()
);

grant select on public.ai_settings to authenticated;
grant select, insert, update, delete on public.ai_settings to service_role;

alter table public.ai_settings enable row level security;
drop policy if exists "Staff can read" on public.ai_settings;
create policy "Staff can read" on public.ai_settings for select to authenticated
  using (public.is_staff(auth.uid()) and company_id = (select public.active_company()));

create table if not exists public.ai_keys (
  company_id uuid primary key references public.companies(id) on delete cascade,
  api_key text not null,
  updated_at timestamptz not null default now()
);

grant select, insert, update, delete on public.ai_keys to service_role;

alter table public.ai_keys enable row level security;
-- No policies: only the server (service role) reads or writes keys.

create table if not exists public.receipts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  file_path text not null,
  file_name text,
  mime text,
  status text not null default 'new' check (status in ('new','read','done','ignored','failed')),
  vendor_name text,
  receipt_date date,
  total numeric(14,2),
  tax numeric(14,2),
  vendor_id uuid references public.vendors(id) on delete set null,
  account_id uuid references public.accounts(id) on delete set null,
  paid_from uuid references public.accounts(id) on delete set null,
  memo text,
  ai jsonb,
  error text,
  bank_txn_id uuid references public.bank_transactions(id) on delete set null,
  check_id uuid references public.checks(id) on delete set null,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists receipts_company_idx on public.receipts (company_id, status, created_at);

grant select, insert, update, delete on public.receipts to authenticated;
grant select, insert, update, delete on public.receipts to service_role;

alter table public.receipts enable row level security;
drop policy if exists "Staff can use" on public.receipts;
create policy "Staff can use" on public.receipts for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()));

-- Private storage for receipt files: <company id>/<file>.
insert into storage.buckets (id, name, public)
values ('receipts', 'receipts', false)
on conflict (id) do nothing;

drop policy if exists "Receipts: staff of the company" on storage.objects;
create policy "Receipts: staff of the company" on storage.objects for all to authenticated
  using (bucket_id = 'receipts'
         and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')
         and (storage.foldername(name))[1] = (select public.active_company())::text)
  with check (bucket_id = 'receipts'
         and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')
         and (storage.foldername(name))[1] = (select public.active_company())::text);
