-- SunRise Office — step 18: real estate (the "Real estate" feature).
--
-- * properties → units; tenants; leases (a tenant in a unit, with rent, due day, deposit, late fee).
-- * rent_charges: what a tenant owes (monthly rent, late fees, deposit, other charges).
--   rent_payments: money received against a charge.
-- * The books: a charge is owed to us (Accounts Receivable) against Rental Income / Late Fee
--   Income / Security Deposits Held; a payment moves it into the bank.
-- * Each journal line and bill line can name a property, so each property has its own
--   Profit & Loss (what the accountant needs for Schedule E).
-- * generate_rent(): charges every active lease's rent up to a day (no doubles).
--   apply_late_fees(): adds a late fee to rent still unpaid after the grace days.
-- Security: staff with the Properties section, in the active company.

-- ---------- Tables ----------
create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  name text not null,
  address text,
  kind text not null default 'residential' check (kind in ('residential','commercial','land','other')),
  purchase_date date,
  purchase_price numeric(14,2),
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.units (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  property_id uuid not null references public.properties(id) on delete cascade,
  name text not null,
  bedrooms numeric(4,1),
  bathrooms numeric(4,1),
  sqft int,
  market_rent numeric(14,2),
  notes text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists units_property_idx on public.units (property_id);

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  name text not null,
  email text,
  phone text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.leases (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  unit_id uuid not null references public.units(id) on delete cascade,
  tenant_id uuid not null references public.tenants(id) on delete restrict,
  start_date date not null,
  end_date date,                                  -- empty = month to month
  rent numeric(14,2) not null default 0,
  due_day int not null default 1 check (due_day between 1 and 28),
  deposit numeric(14,2) not null default 0,
  late_fee numeric(14,2) not null default 0,
  grace_days int not null default 5,
  charge_from date,                               -- first month to charge here (older months were in the old system)
  status text not null default 'active' check (status in ('active','ended')),
  ended_on date,
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists leases_unit_idx on public.leases (unit_id);

create table if not exists public.rent_charges (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  lease_id uuid not null references public.leases(id) on delete cascade,
  kind text not null default 'rent' check (kind in ('rent','late_fee','deposit','other')),
  charge_date date not null,
  due_date date not null,
  description text,
  amount numeric(14,2) not null,
  amount_paid numeric(14,2) not null default 0,
  balance numeric(14,2) not null default 0,
  status text not null default 'open' check (status in ('open','paid','void')),
  account_id uuid references public.accounts(id),  -- for "other" charges: the income account
  created_at timestamptz not null default now()
);
create unique index if not exists rent_charges_once on public.rent_charges (lease_id, kind, charge_date)
  where kind in ('rent','late_fee');
create index if not exists rent_charges_lease_idx on public.rent_charges (lease_id, status);

create table if not exists public.rent_payments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  charge_id uuid not null references public.rent_charges(id) on delete cascade,
  paid_on date not null default current_date,
  amount numeric(14,2) not null check (amount > 0),
  account_id uuid references public.accounts(id),  -- deposited to
  method text,
  reference text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists rent_payments_charge_idx on public.rent_payments (charge_id);

-- Which property a line of the books / a bill line is for.
alter table public.journal_lines add column if not exists property_id uuid references public.properties(id) on delete set null;
alter table public.bill_lines add column if not exists property_id uuid references public.properties(id) on delete set null;
create index if not exists journal_lines_property_idx on public.journal_lines (property_id) where property_id is not null;

do $$
declare t text;
begin
  foreach t in array array['properties','units','tenants','leases','rent_charges','rent_payments'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- ---------- Accounts used by real estate (added when first needed) ----------
create or replace function public.seed_real_estate_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, x.key
    from (values
      ('4200', 'Rental Income', 'income', 'income', 'rent_income'),
      ('4210', 'Late Fee Income', 'income', 'income', 'late_fees'),
      ('2350', 'Security Deposits Held', 'liability', 'other_liability', 'deposits_held'),
      ('7500', 'Property Taxes', 'expense', 'expense', null),
      ('7550', 'Mortgage Interest', 'expense', 'expense', null),
      ('7600', 'Property Management and HOA', 'expense', 'expense', null),
      ('7650', 'Depreciation', 'expense', 'expense', null)
    ) as x(number, name, type, kind, key)
   where not exists (select 1 from public.accounts a where a.company_id = _co
                      and ((x.key is not null and a.key = x.key) or a.number = x.number));
end $$;

-- ---------- Writing entries: lines can now name a property ----------
create or replace function public.write_entry(_co uuid, _date date, _type text, _src uuid, _ref text,
  _memo text, _lines jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare e uuid; x jsonb; dr numeric := 0; cr numeric := 0;
begin
  for x in select value from jsonb_array_elements(_lines) loop
    dr := dr + coalesce((x->>'debit')::numeric, 0);
    cr := cr + coalesce((x->>'credit')::numeric, 0);
  end loop;
  if round(dr, 2) = 0 and round(cr, 2) = 0 then return; end if;
  if round(dr, 2) <> round(cr, 2) then
    raise exception 'Entry for % % does not balance (% vs %)', _type, coalesce(_ref, ''), dr, cr;
  end if;
  insert into public.journal_entries (company_id, entry_date, memo, source_type, source_id, ref)
  values (_co, _date, _memo, _type, _src, _ref) returning id into e;
  insert into public.journal_lines (company_id, entry_id, account_id, debit, credit, memo, customer_id, vendor_id, property_id)
  select _co, e, (l->>'account')::uuid, round(coalesce((l->>'debit')::numeric, 0), 2),
         round(coalesce((l->>'credit')::numeric, 0), 2), l->>'memo',
         nullif(l->>'customer', '')::uuid, nullif(l->>'vendor', '')::uuid, nullif(l->>'property', '')::uuid
    from jsonb_array_elements(_lines) l
   where round(coalesce((l->>'debit')::numeric, 0), 2) <> 0 or round(coalesce((l->>'credit')::numeric, 0), 2) <> 0;
end $$;

-- Bills: each line can be for a property.
create or replace function public.post_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b record; lines jsonb;
begin
  delete from public.journal_entries where source_type = 'bill' and source_id = _id;
  select * into b from public.bills where id = _id;
  if b.id is null or b.status = 'void' or not public.books_open(b.company_id, b.bill_date) then return; end if;
  select coalesce(jsonb_agg(jsonb_build_object('account', coalesce(l.account_id, public.acct(b.company_id, 'cogs')),
           'debit', l.amount, 'memo', l.description, 'vendor', b.vendor_id, 'property', l.property_id)), '[]'::jsonb)
    into lines from public.bill_lines l where l.bill_id = b.id;
  perform public.write_entry(b.company_id, b.bill_date, 'bill', b.id, b.ref, 'Bill ' || coalesce(b.vendor_name, ''),
    lines || jsonb_build_array(jsonb_build_object('account', public.acct(b.company_id, 'ap'),
      'credit', (select coalesce(sum(amount), 0) from public.bill_lines where bill_id = b.id), 'vendor', b.vendor_id)));
end $$;

-- ---------- Posting rent ----------
-- A charge: owed by the tenant (A/R) against income, or against Security Deposits Held.
create or replace function public.post_rent_charge(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare c record; other uuid; label text;
begin
  delete from public.journal_entries where source_type = 'rent_charge' and source_id = _id;
  select rc.*, u.property_id, t.name as tenant, u.name as unit
    into c
    from public.rent_charges rc
    join public.leases l on l.id = rc.lease_id
    join public.units u on u.id = l.unit_id
    join public.tenants t on t.id = l.tenant_id
   where rc.id = _id;
  if c.id is null or c.status = 'void' or not public.books_open(c.company_id, c.charge_date) then return; end if;
  perform public.seed_real_estate_accounts(c.company_id);
  other := case c.kind
    when 'rent' then public.acct(c.company_id, 'rent_income')
    when 'late_fee' then public.acct(c.company_id, 'late_fees')
    when 'deposit' then public.acct(c.company_id, 'deposits_held')
    else coalesce(c.account_id, public.acct(c.company_id, 'rent_income')) end;
  label := case c.kind when 'rent' then 'Rent' when 'late_fee' then 'Late fee' when 'deposit' then 'Security deposit'
           else coalesce(c.description, 'Charge') end;
  perform public.write_entry(c.company_id, c.charge_date, 'rent_charge', c.id, c.unit,
    label || ' · ' || c.tenant,
    jsonb_build_array(
      jsonb_build_object('account', public.acct(c.company_id, 'ar'), 'debit', c.amount, 'property', c.property_id, 'memo', c.tenant),
      jsonb_build_object('account', other, 'credit', c.amount, 'property', c.property_id, 'memo', c.tenant)));
end $$;

-- A payment: into the bank, out of A/R.
create or replace function public.post_rent_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; bank uuid;
begin
  delete from public.journal_entries where source_type = 'rent_payment' and source_id = _id;
  select rp.*, rc.lease_id, u.property_id, u.name as unit, t.name as tenant
    into p
    from public.rent_payments rp
    join public.rent_charges rc on rc.id = rp.charge_id
    join public.leases l on l.id = rc.lease_id
    join public.units u on u.id = l.unit_id
    join public.tenants t on t.id = l.tenant_id
   where rp.id = _id;
  if p.id is null or not public.books_open(p.company_id, p.paid_on) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = p.company_id),
    public.acct(p.company_id, 'bank'));
  perform public.write_entry(p.company_id, p.paid_on, 'rent_payment', p.id, p.unit, 'Payment · ' || p.tenant,
    jsonb_build_array(
      jsonb_build_object('account', bank, 'debit', p.amount, 'property', p.property_id, 'memo', p.tenant),
      jsonb_build_object('account', public.acct(p.company_id, 'ar'), 'credit', p.amount, 'property', p.property_id, 'memo', p.tenant)));
end $$;

-- Keep a charge's paid amount, balance and status up to date.
create or replace function public.refresh_rent_charge(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare paid numeric;
begin
  select coalesce(sum(amount), 0) into paid from public.rent_payments where charge_id = _id;
  update public.rent_charges
     set amount_paid = paid,
         balance = greatest(amount - paid, 0),
         status = case when status = 'void' then 'void' when paid >= amount then 'paid' else 'open' end
   where id = _id
     and (amount_paid, balance, status) is distinct from
         (paid, greatest(amount - paid, 0), case when status = 'void' then 'void' when paid >= amount then 'paid' else 'open' end);
end $$;

create or replace function public.trg_post_rent()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  r := coalesce(new, old);
  if tg_table_name = 'rent_charges' then
    if tg_op = 'INSERT' or (tg_op = 'UPDATE' and new.amount is distinct from old.amount) then
      perform public.refresh_rent_charge(r.id);
    end if;
    perform public.post_rent_charge(r.id);
  else
    perform public.refresh_rent_charge(r.charge_id);
    perform public.post_rent_payment(r.id);
  end if;
  return null;
end $$;
drop trigger if exists rent_charges_post on public.rent_charges;
create trigger rent_charges_post after insert or update or delete on public.rent_charges
  for each row execute function public.trg_post_rent();
drop trigger if exists rent_payments_post on public.rent_payments;
create trigger rent_payments_post after insert or update or delete on public.rent_payments
  for each row execute function public.trg_post_rent();

-- Renaming a unit or tenant, or moving a unit: charges and payments write their entries again.
create or replace function public.trg_repost_lease()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in
    select rc.id from public.rent_charges rc join public.leases l on l.id = rc.lease_id
     where (tg_table_name = 'leases' and l.id = new.id)
        or (tg_table_name = 'units' and l.unit_id = new.id)
        or (tg_table_name = 'tenants' and l.tenant_id = new.id)
  loop
    perform public.post_rent_charge(r.id);
    perform public.post_rent_payment(p.id) from public.rent_payments p where p.charge_id = r.id;
  end loop;
  return null;
end $$;
drop trigger if exists units_repost on public.units;
create trigger units_repost after update of name, property_id on public.units
  for each row execute function public.trg_repost_lease();
drop trigger if exists tenants_repost on public.tenants;
create trigger tenants_repost after update of name on public.tenants
  for each row execute function public.trg_repost_lease();
drop trigger if exists leases_repost on public.leases;
create trigger leases_repost after update of unit_id, tenant_id on public.leases
  for each row execute function public.trg_repost_lease();

-- ---------- Charging rent and late fees ----------
-- Every active lease's rent for each month up to _through (from its start / "charge from" month).
create or replace function public.generate_rent_company(_co uuid, _through date)
returns int language plpgsql security definer set search_path = public as $$
declare l record; m date; due date; n int := 0; c int;
begin
  for l in select * from public.leases where company_id = _co and status = 'active' and rent > 0 loop
    m := date_trunc('month', greatest(l.start_date, coalesce(l.charge_from, l.start_date)))::date;
    while m <= _through loop
      due := m + (l.due_day - 1);
      if due >= l.start_date and (l.end_date is null or due <= l.end_date) and due <= _through then
        insert into public.rent_charges (company_id, lease_id, kind, charge_date, due_date, description, amount)
        values (_co, l.id, 'rent', due, due, 'Rent ' || to_char(m, 'Mon YYYY'), l.rent)
        on conflict (lease_id, kind, charge_date) where kind in ('rent','late_fee') do nothing;
        get diagnostics c = row_count;
        n := n + c;
      end if;
      m := (m + interval '1 month')::date;
    end loop;
  end loop;
  return n;
end $$;
revoke all on function public.generate_rent_company(uuid, date) from public, anon, authenticated;
grant execute on function public.generate_rent_company(uuid, date) to service_role;

create or replace function public.apply_late_fees_company(_co uuid, _asof date)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into public.rent_charges (company_id, lease_id, kind, charge_date, due_date, description, amount)
  select _co, rc.lease_id, 'late_fee', rc.due_date + l.grace_days + 1, rc.due_date + l.grace_days + 1,
         'Late fee · ' || coalesce(rc.description, 'rent'), l.late_fee
    from public.rent_charges rc join public.leases l on l.id = rc.lease_id
   where rc.company_id = _co and rc.kind = 'rent' and rc.status = 'open' and rc.balance > 0
     and l.late_fee > 0 and rc.due_date + l.grace_days < _asof
  on conflict (lease_id, kind, charge_date) where kind in ('rent','late_fee') do nothing;
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.apply_late_fees_company(uuid, date) from public, anon, authenticated;
grant execute on function public.apply_late_fees_company(uuid, date) to service_role;

-- The buttons on the Rent page (staff with Properties, in the active company).
create or replace function public.generate_rent(_through date)
returns json language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company();
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Properties')) then
    raise exception 'Not allowed';
  end if;
  return json_build_object('charged', public.generate_rent_company(co, _through),
                           'late_fees', public.apply_late_fees_company(co, least(_through, current_date)));
end $$;
grant execute on function public.generate_rent(date) to authenticated;

-- ---------- Rebuilding the books includes rent ----------
create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  for r in select id from public.rent_charges where company_id = _co loop perform public.post_rent_charge(r.id); end loop;
  for r in select id from public.rent_payments where company_id = _co loop perform public.post_rent_payment(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;

-- ---------- Report: totals per property and account ----------
create or replace function public.property_totals(_from date, _to date)
returns table (property_id uuid, account_id uuid, debit numeric, credit numeric)
language sql stable set search_path = public as $$
  select l.property_id, l.account_id, sum(l.debit), sum(l.credit)
    from public.journal_lines l join public.journal_entries e on e.id = l.entry_id
   where l.property_id is not null
     and (_from is null or e.entry_date >= _from) and (_to is null or e.entry_date <= _to)
   group by l.property_id, l.account_id
$$;
grant execute on function public.property_totals(date, date) to authenticated;
