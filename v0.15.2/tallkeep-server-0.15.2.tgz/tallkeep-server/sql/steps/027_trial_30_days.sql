-- SunRise Office / Tallkeep — step 27: the free trial is 30 days (was 90).
-- Same start_trial() as step 25, only the length changes. Accounts already in a trial keep their date.

-- A person who just signed up: make their account (30 days free), make them its admin, and set up
-- their first company.
create or replace function public.start_trial(_company text, _business_type text, _addons text[])
returns uuid language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); o uuid; n uuid;
begin
  if uid is null then raise exception 'Please sign in first.'; end if;
  if exists (select 1 from public.org_members where user_id = uid)
     or exists (select 1 from public.user_roles where user_id = uid) then
    raise exception 'You already have an account. Sign in to open it.';
  end if;
  if coalesce(trim(_company), '') = '' then raise exception 'Type your company name.'; end if;
  if length(trim(_company)) > 120 then raise exception 'That company name is too long.'; end if;
  insert into public.orgs (name, status, trial_ends_at, created_by)
  values (trim(_company), 'trial', now() + interval '30 days', uid)
  returning id into o;
  insert into public.org_members (org_id, user_id) values (o, uid);
  insert into public.user_roles (user_id, role) values (uid, 'admin');
  n := public.make_company(o, trim(_company), _business_type,
                           (select array(select x from unnest(_addons) x
                                          where x in ('sales','purchasing','inventory','accounting',
                                                      'work_orders','tickets','real_estate','tech_pay'))),
                           uid, null);
  insert into public.user_company (user_id, company_id) values (uid, n)
  on conflict (user_id) do update set company_id = excluded.company_id;
  return n;
end $$;
grant execute on function public.start_trial(text, text, text[]) to authenticated;
