-- SunRise Office — step 19: Work Orders (the "Work Orders" feature).
--
-- * product_parts: the recipe of a product — which parts (other products) and how many go into ONE.
--   products.build_extra_cost: labor and other cost added per one built (optional).
-- * work_orders (WO-000001): "build N of this product" at a place; work_order_lines: the parts needed.
--   Can come from an invoice (sales_order_id).
-- * finish_work_order(): takes the parts out of stock, adds the finished products, sets the
--   product's cost (average with what's already in stock) and writes the entry in the books.
--   undo_work_order() puts it all back.
-- Security: staff with the Inventory section, in the active company.

alter table public.products add column if not exists build_extra_cost numeric(14,4) not null default 0;

create table if not exists public.product_parts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  part_id uuid not null references public.products(id) on delete restrict,
  qty numeric(14,4) not null check (qty > 0),
  notes text,
  unique (product_id, part_id),
  check (product_id <> part_id)
);
create index if not exists product_parts_product_idx on public.product_parts (product_id);

create table if not exists public.work_orders (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  number text not null,
  product_id uuid not null references public.products(id) on delete restrict,
  qty numeric(14,4) not null check (qty > 0),
  location_id uuid not null references public.locations(id),
  shelf text not null default '',
  status text not null default 'planned' check (status in ('planned','in_progress','done','cancelled')),
  due_date date,
  sales_order_id uuid references public.sales_orders(id) on delete set null,
  extra_cost numeric(14,2) not null default 0,     -- labor etc. for the whole order
  parts_cost numeric(14,2),                        -- set when finished
  old_unit_cost numeric(14,4),                     -- product cost before finishing (for undo)
  done_on date,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (company_id, number)
);
create index if not exists work_orders_status_idx on public.work_orders (company_id, status);
create index if not exists work_orders_order_idx on public.work_orders (sales_order_id);

create table if not exists public.work_order_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  work_order_id uuid not null references public.work_orders(id) on delete cascade,
  part_id uuid not null references public.products(id) on delete restrict,
  qty numeric(14,4) not null check (qty >= 0),
  unit_cost numeric(14,4)                           -- set when finished
);
create index if not exists work_order_lines_wo_idx on public.work_order_lines (work_order_id);

do $$
declare t text;
begin
  foreach t in array array['product_parts','work_orders','work_order_lines'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can use" on public.%I', t);
    execute format($p$create policy "Staff can use" on public.%I for all to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Inventory') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Inventory') and company_id = (select public.active_company()))$p$, t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- Work order numbers for every company (new companies copy them).
insert into public.doc_counters (company_id, kind, prefix, next_number)
select c.id, 'work_order', 'WO-', 1001 from public.companies c
on conflict (company_id, kind) do nothing;

-- ---------- Account for labor added to built products ----------
create or replace function public.seed_work_order_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, '5300', 'Labor and Overhead Applied', 'expense', 'cogs', 'labor_applied'
   where not exists (select 1 from public.accounts where company_id = _co and key = 'labor_applied');
end $$;

-- ---------- Books ----------
-- Parts leave Inventory, the finished products come in at parts + extra cost.
create or replace function public.post_work_order(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare w record; inv uuid;
begin
  delete from public.journal_entries where source_type = 'work_order' and source_id = _id;
  select wo.*, p.name as pname into w
    from public.work_orders wo join public.products p on p.id = wo.product_id where wo.id = _id;
  if w.id is null or w.status <> 'done' or w.done_on is null then return; end if;
  if not public.books_open(w.company_id, w.done_on) then return; end if;
  perform public.seed_work_order_accounts(w.company_id);
  inv := public.acct(w.company_id, 'inventory');
  perform public.write_entry(w.company_id, w.done_on, 'work_order', w.id, w.number,
    'Built ' || trim(to_char(w.qty, 'FM999999990.####')) || ' × ' || w.pname,
    jsonb_build_array(
      jsonb_build_object('account', inv, 'debit', coalesce(w.parts_cost, 0) + w.extra_cost, 'memo', 'Finished: ' || w.pname),
      jsonb_build_object('account', inv, 'credit', coalesce(w.parts_cost, 0), 'memo', 'Parts used'),
      jsonb_build_object('account', public.acct(w.company_id, 'labor_applied'), 'credit', w.extra_cost, 'memo', 'Labor and other cost')));
end $$;

create or replace function public.trg_post_work_order()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.post_work_order(coalesce(new.id, old.id));
  return null;
end $$;
drop trigger if exists work_orders_post on public.work_orders;
create trigger work_orders_post after insert or update or delete on public.work_orders
  for each row execute function public.trg_post_work_order();

-- ---------- Finish / undo ----------
create or replace function public.finish_work_order(_id uuid, _done_on date default current_date)
returns json language plpgsql security definer set search_path = public as $$
declare w record; l record; parts numeric := 0; on_hand numeric; old_cost numeric; new_cost numeric;
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Inventory')) then raise exception 'Not allowed'; end if;
  select * into w from public.work_orders where id = _id and company_id = public.active_company() for update;
  if w.id is null then raise exception 'Work order not found'; end if;
  if w.status in ('done','cancelled') then raise exception 'This work order is already %', w.status; end if;
  -- Parts out, at today's cost.
  for l in select wl.*, p.cost from public.work_order_lines wl join public.products p on p.id = wl.part_id
            where wl.work_order_id = _id and wl.qty > 0 loop
    update public.work_order_lines set unit_cost = l.cost where id = l.id;
    parts := parts + round(l.qty * coalesce(l.cost, 0), 2);
    perform public.change_stock(l.part_id, w.location_id, w.shelf, -l.qty, 'build_use', w.number, 'work_order', w.id);
  end loop;
  -- Finished products in; their cost becomes the average of what was there and this build.
  select coalesce(sum(qty), 0) into on_hand from public.stock where product_id = w.product_id;
  select cost into old_cost from public.products where id = w.product_id;
  new_cost := case when on_hand > 0 and coalesce(old_cost, 0) > 0
                   then (on_hand * old_cost + parts + w.extra_cost) / (on_hand + w.qty)
                   else (parts + w.extra_cost) / w.qty end;
  perform public.change_stock(w.product_id, w.location_id, w.shelf, w.qty, 'build_make', w.number, 'work_order', w.id);
  update public.products set cost = round(new_cost, 4) where id = w.product_id;
  update public.work_orders
     set status = 'done', done_on = _done_on, parts_cost = parts, old_unit_cost = old_cost
   where id = _id;
  return json_build_object('parts_cost', parts, 'unit_cost', round(new_cost, 4));
end $$;
grant execute on function public.finish_work_order(uuid, date) to authenticated;

create or replace function public.undo_work_order(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare w record; l record;
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Inventory')) then raise exception 'Not allowed'; end if;
  select * into w from public.work_orders where id = _id and company_id = public.active_company() for update;
  if w.id is null or w.status <> 'done' then raise exception 'Only a finished work order can be undone'; end if;
  perform public.change_stock(w.product_id, w.location_id, w.shelf, -w.qty, 'build_undo', w.number, 'work_order', w.id);
  for l in select * from public.work_order_lines where work_order_id = _id and qty > 0 loop
    perform public.change_stock(l.part_id, w.location_id, w.shelf, l.qty, 'build_undo', w.number, 'work_order', w.id);
  end loop;
  if w.old_unit_cost is not null then
    update public.products set cost = w.old_unit_cost where id = w.product_id;
  end if;
  update public.work_order_lines set unit_cost = null where work_order_id = _id;
  update public.work_orders set status = 'in_progress', done_on = null, parts_cost = null, old_unit_cost = null where id = _id;
end $$;
grant execute on function public.undo_work_order(uuid) to authenticated;

-- ---------- Rebuilding the books includes work orders ----------
create or replace function public.rebuild_books_company(_co uuid)
returns json language plpgsql security definer set search_path = public as $$
declare r record;
begin
  perform public.seed_accounts(_co);
  delete from public.journal_entries
   where company_id = _co and source_type not in ('manual', 'opening', 'bank', 'adjust');
  for r in select id from public.sales_orders where company_id = _co loop perform public.post_invoice(r.id); end loop;
  for r in select id from public.purchase_orders where company_id = _co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = _co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = _co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = _co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = _co loop perform public.post_bill_payment(r.id); end loop;
  for r in select id from public.rent_charges where company_id = _co loop perform public.post_rent_charge(r.id); end loop;
  for r in select id from public.rent_payments where company_id = _co loop perform public.post_rent_payment(r.id); end loop;
  for r in select id from public.work_orders where company_id = _co and status = 'done' loop perform public.post_work_order(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = _co));
end $$;
revoke all on function public.rebuild_books_company(uuid) from public, anon, authenticated;
grant execute on function public.rebuild_books_company(uuid) to service_role;
