-- SunRise Office — step 23: vendor credits.
--
-- A vendor credit is a bill with a minus total (the vendor owes us). It stays open until it is
-- used in Pay Bills (a minus payment on the same check as that vendor's bills).
-- * post_bill writes minus lines the other way round (a credit lowers the expense and what we owe).
-- * refresh_bill marks a credit "paid" once it is fully used.

create or replace function public.post_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b record; lines jsonb; tot numeric;
begin
  delete from public.journal_entries where source_type = 'bill' and source_id = _id;
  select * into b from public.bills where id = _id;
  if b.id is null or b.status = 'void' or not public.books_open(b.company_id, b.bill_date) then return; end if;
  select coalesce(sum(amount), 0) into tot from public.bill_lines where bill_id = b.id;
  select coalesce(jsonb_agg(jsonb_build_object('account', coalesce(l.account_id, public.acct(b.company_id, 'cogs')),
           'debit', greatest(l.amount, 0), 'credit', greatest(-l.amount, 0),
           'memo', l.description, 'vendor', b.vendor_id, 'property', l.property_id)), '[]'::jsonb)
    into lines from public.bill_lines l where l.bill_id = b.id;
  perform public.write_entry(b.company_id, b.bill_date, 'bill', b.id, b.ref,
    (case when tot < 0 then 'Vendor credit ' else 'Bill ' end) || coalesce(b.vendor_name, ''),
    lines || jsonb_build_array(jsonb_build_object('account', public.acct(b.company_id, 'ap'),
      'credit', greatest(tot, 0), 'debit', greatest(-tot, 0), 'vendor', b.vendor_id)));
end $$;

create or replace function public.refresh_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t numeric; paid numeric;
begin
  select coalesce(sum(amount), 0) into t from public.bill_lines where bill_id = _id;
  select coalesce(sum(amount), 0) into paid from public.bill_payments where bill_id = _id;
  update public.bills set total = t, amount_paid = paid, balance = t - paid, updated_at = now(),
    status = case when status = 'void' then 'void'
                  when t <> 0 and abs(t - paid) <= 0.005 then 'paid'
                  when t > 0 and t - paid <= 0.005 then 'paid'
                  else 'open' end
   where id = _id;
end $$;
grant execute on function public.refresh_bill(uuid) to authenticated;
