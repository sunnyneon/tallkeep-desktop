-- Tallkeep — step 33: license keys bought online. When a customer pays on the Buy page (Stripe
-- checkout), Tallkeep makes their key and emails it. The Stripe checkout id is kept on the key so a
-- payment never makes two keys.
alter table public.desktop_licenses add column if not exists stripe_session text;
alter table public.desktop_licenses add column if not exists paid_cents int;
create unique index if not exists desktop_licenses_stripe_session_idx
  on public.desktop_licenses (stripe_session) where stripe_session is not null;
