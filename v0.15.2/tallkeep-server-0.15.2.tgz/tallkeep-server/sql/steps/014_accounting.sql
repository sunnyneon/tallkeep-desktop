-- SunRise Office — step 14: accounting core (double-entry books per company).
--
-- How it works:
-- * Each company has a chart of accounts (a ready-made one is added; edit it freely).
-- * Books start on a date (Company setting "books_start_date"). From that date, every invoice,
--   payment, received purchase order, PO payment, stock adjustment and bill writes its own journal
--   entry automatically. Nothing before that date is posted: opening balances cover it.
-- * Journal entries made automatically are rebuilt whenever their document changes, so the books
--   always match the documents. Manual and opening-balance entries are typed in by people.
-- * Debits = credits on every entry.

-- ---------- Accounts ----------
create table if not exists public.accounts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  number text,
  name text not null,
  type text not null check (type in ('asset','liability','equity','income','expense')),
  kind text not null check (kind in ('bank','ar','inventory','other_asset','fixed_asset',
    'ap','credit_card','other_liability','long_term_liability','equity',
    'income','other_income','cogs','expense','other_expense')),
  key text,                       -- accounts the app posts to: ar, ap, inventory, sales, ...
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (company_id, key)
);
create index if not exists accounts_company_idx on public.accounts (company_id);

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  entry_date date not null,
  memo text,
  source_type text not null default 'manual',  -- invoice, payment, po, po_payment, stock, bill, bill_payment, manual, opening
  source_id uuid,
  ref text,                                     -- document number shown in reports
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists journal_entries_source_idx on public.journal_entries (source_type, source_id);
create index if not exists journal_entries_company_date_idx on public.journal_entries (company_id, entry_date);

create table if not exists public.journal_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  entry_id uuid not null references public.journal_entries(id) on delete cascade,
  account_id uuid not null references public.accounts(id),
  debit numeric(14,2) not null default 0,
  credit numeric(14,2) not null default 0,
  memo text,
  customer_id uuid references public.customers(id) on delete set null,
  vendor_id uuid references public.vendors(id) on delete set null,
  check (debit >= 0 and credit >= 0)
);
create index if not exists journal_lines_entry_idx on public.journal_lines (entry_id);
create index if not exists journal_lines_account_idx on public.journal_lines (account_id);

-- ---------- Bills and expenses (things we owe that aren't purchase orders) ----------
create table if not exists public.bills (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  vendor_id uuid references public.vendors(id) on delete set null,
  vendor_name text,
  ref text,                       -- the vendor's bill / receipt number
  bill_date date not null default current_date,
  due_date date,
  memo text,
  status text not null default 'open' check (status in ('open','paid','void')),
  total numeric(14,2) not null default 0,
  amount_paid numeric(14,2) not null default 0,
  balance numeric(14,2) not null default 0,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.bill_lines (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  bill_id uuid not null references public.bills(id) on delete cascade,
  line_no int not null default 0,
  account_id uuid references public.accounts(id),
  description text,
  amount numeric(14,2) not null default 0
);
create table if not exists public.bill_payments (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  bill_id uuid not null references public.bills(id) on delete cascade,
  paid_on date not null default current_date,
  amount numeric(14,2) not null,
  account_id uuid references public.accounts(id),   -- paid from (bank or credit card)
  method text,
  reference text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists bill_lines_bill_idx on public.bill_lines (bill_id);
create index if not exists bill_payments_bill_idx on public.bill_payments (bill_id);

-- Where money goes in and out.
alter table public.payments add column if not exists account_id uuid references public.accounts(id);
alter table public.payments add column if not exists company_id uuid references public.companies(id) on delete cascade;
alter table public.company_settings add column if not exists books_start_date date;
alter table public.company_settings add column if not exists default_bank_account_id uuid references public.accounts(id);

-- ---------- Security: staff with the Accounting section, in the active company ----------
do $$
declare t text;
begin
  foreach t in array array['accounts','journal_entries','journal_lines','bills','bill_lines','bill_payments'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "Staff can read" on public.%I', t);
    execute format('drop policy if exists "Staff can add" on public.%I', t);
    execute format('drop policy if exists "Staff can edit" on public.%I', t);
    execute format('drop policy if exists "Staff can delete" on public.%I', t);
    execute format($p$create policy "Staff can read" on public.%I for select to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format($p$create policy "Staff can add" on public.%I for insert to authenticated
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format($p$create policy "Staff can edit" on public.%I for update to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
      with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
    execute format($p$create policy "Staff can delete" on public.%I for delete to authenticated
      using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))$p$, t);
  end loop;
end $$;

-- Signed-in users may use these tables; the rules above decide which rows (staff, Accounting
-- section, active company).
grant select, insert, update, delete on public.accounts, public.journal_entries, public.journal_lines,
  public.bills, public.bill_lines, public.bill_payments to authenticated;

-- ---------- A ready-made chart of accounts ----------
create or replace function public.seed_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.accounts where company_id = _co) then return; end if;
  insert into public.accounts (company_id, number, name, type, kind, key) values
    (_co, '1000', 'Checking', 'asset', 'bank', 'bank'),
    (_co, '1050', 'Undeposited Funds', 'asset', 'other_asset', 'undeposited'),
    (_co, '1100', 'Accounts Receivable', 'asset', 'ar', 'ar'),
    (_co, '1200', 'Inventory', 'asset', 'inventory', 'inventory'),
    (_co, '1500', 'Equipment and Vehicles', 'asset', 'fixed_asset', null),
    (_co, '1590', 'Accumulated Depreciation', 'asset', 'fixed_asset', null),
    (_co, '2000', 'Accounts Payable', 'liability', 'ap', 'ap'),
    (_co, '2100', 'Credit Card', 'liability', 'credit_card', null),
    (_co, '2200', 'Sales Tax Payable', 'liability', 'other_liability', 'sales_tax'),
    (_co, '2300', 'Customer Deposits', 'liability', 'other_liability', null),
    (_co, '2500', 'Loans', 'liability', 'long_term_liability', null),
    (_co, '3000', 'Opening Balance Equity', 'equity', 'equity', 'opening'),
    (_co, '3100', 'Owner''s Investment', 'equity', 'equity', null),
    (_co, '3200', 'Owner''s Draw', 'equity', 'equity', null),
    (_co, '3900', 'Retained Earnings', 'equity', 'equity', 'retained'),
    (_co, '4000', 'Sales', 'income', 'income', 'sales'),
    (_co, '4100', 'Installation and Service Income', 'income', 'income', null),
    (_co, '4900', 'Other Income', 'income', 'other_income', null),
    (_co, '5000', 'Cost of Goods Sold', 'expense', 'cogs', 'cogs'),
    (_co, '5100', 'Inventory Adjustments', 'expense', 'cogs', 'inv_adjust'),
    (_co, '5200', 'Freight and Delivery', 'expense', 'cogs', null),
    (_co, '6000', 'Advertising and Marketing', 'expense', 'expense', null),
    (_co, '6100', 'Bank and Card Fees', 'expense', 'expense', null),
    (_co, '6200', 'Insurance', 'expense', 'expense', null),
    (_co, '6300', 'Office Supplies and Software', 'expense', 'expense', null),
    (_co, '6400', 'Rent', 'expense', 'expense', null),
    (_co, '6500', 'Utilities', 'expense', 'expense', null),
    (_co, '6600', 'Vehicle and Fuel', 'expense', 'expense', null),
    (_co, '6700', 'Subcontractors', 'expense', 'expense', null),
    (_co, '6800', 'Professional Fees', 'expense', 'expense', null),
    (_co, '6900', 'Payroll', 'expense', 'expense', null),
    (_co, '7000', 'Meals', 'expense', 'expense', null),
    (_co, '7100', 'Travel', 'expense', 'expense', null),
    (_co, '7200', 'Repairs and Maintenance', 'expense', 'expense', null),
    (_co, '7300', 'Taxes and Licenses', 'expense', 'expense', null),
    (_co, '7400', 'Phone and Internet', 'expense', 'expense', null),
    (_co, '7900', 'Other Expenses', 'expense', 'other_expense', null);
  update public.company_settings
     set default_bank_account_id = (select id from public.accounts where company_id = _co and key = 'bank')
   where company_id = _co and default_bank_account_id is null;
end $$;

select public.seed_accounts(id) from public.companies;

-- New companies get the chart too.
create or replace function public.seed_accounts_for_new_company()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.seed_accounts(new.company_id);
  return new;
end $$;
drop trigger if exists company_settings_seed_accounts on public.company_settings;
create trigger company_settings_seed_accounts after insert on public.company_settings
  for each row execute function public.seed_accounts_for_new_company();

-- Payments belong to their order's company.
update public.payments p set company_id = coalesce(
  (select company_id from public.sales_orders where id = p.sales_order_id),
  (select company_id from public.purchase_orders where id = p.purchase_order_id))
 where p.company_id is null;

-- ---------- Posting ----------
create or replace function public.acct(_co uuid, _key text)
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.accounts where company_id = _co and key = _key
$$;

-- On or after the company's books start date?
create or replace function public.books_open(_co uuid, _d date)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(_d >= (select books_start_date from public.company_settings where company_id = _co), false)
$$;

-- Write one entry from a list of (account, debit, credit, memo) lines; skips zero lines.
create or replace function public.write_entry(_co uuid, _date date, _type text, _src uuid, _ref text,
  _memo text, _lines jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare e uuid; x jsonb; dr numeric := 0; cr numeric := 0;
begin
  for x in select value from jsonb_array_elements(_lines) loop
    dr := dr + coalesce((x->>'debit')::numeric, 0);
    cr := cr + coalesce((x->>'credit')::numeric, 0);
  end loop;
  if round(dr, 2) = 0 and round(cr, 2) = 0 then return; end if;
  if round(dr, 2) <> round(cr, 2) then
    raise exception 'Entry for % % does not balance (% vs %)', _type, coalesce(_ref, ''), dr, cr;
  end if;
  insert into public.journal_entries (company_id, entry_date, memo, source_type, source_id, ref)
  values (_co, _date, _memo, _type, _src, _ref) returning id into e;
  insert into public.journal_lines (company_id, entry_id, account_id, debit, credit, memo, customer_id, vendor_id)
  select _co, e, (l->>'account')::uuid, round(coalesce((l->>'debit')::numeric, 0), 2),
         round(coalesce((l->>'credit')::numeric, 0), 2), l->>'memo',
         nullif(l->>'customer', '')::uuid, nullif(l->>'vendor', '')::uuid
    from jsonb_array_elements(_lines) l
   where round(coalesce((l->>'debit')::numeric, 0), 2) <> 0 or round(coalesce((l->>'credit')::numeric, 0), 2) <> 0;
end $$;

-- Invoice: owed by the customer (A/R) = sales + sales tax; when shipped, cost of the goods
-- moves from Inventory to Cost of Goods Sold.
create or replace function public.post_invoice(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare o record; cost numeric; d date;
begin
  delete from public.journal_entries where source_type in ('invoice', 'invoice_cogs') and source_id = _id;
  select * into o from public.sales_orders where id = _id;
  if o.id is null then return; end if;
  if o.status not in ('invoiced','paid','completed') or o.number like 'RMA-%' then return; end if;
  d := coalesce(o.invoice_date, o.order_date)::date;
  if not public.books_open(o.company_id, d) then return; end if;
  perform public.write_entry(o.company_id, d, 'invoice', o.id, o.number, 'Invoice ' || o.number,
    jsonb_build_array(
      jsonb_build_object('account', public.acct(o.company_id, 'ar'), 'debit', o.total, 'customer', o.customer_id),
      jsonb_build_object('account', public.acct(o.company_id, 'sales'), 'credit', o.total - o.tax, 'customer', o.customer_id),
      jsonb_build_object('account', public.acct(o.company_id, 'sales_tax'), 'credit', o.tax)));
  if o.stock_taken_at is not null then
    select coalesce(sum(l.qty * p.cost), 0) into cost
      from public.sales_order_lines l join public.products p on p.id = l.product_id
     where l.sales_order_id = o.id and p.item_type = 'stocked';
    perform public.write_entry(o.company_id, greatest(d, o.stock_taken_at::date), 'invoice_cogs', o.id, o.number,
      'Cost of goods, invoice ' || o.number,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(o.company_id, 'cogs'), 'debit', cost),
        jsonb_build_object('account', public.acct(o.company_id, 'inventory'), 'credit', cost)));
  end if;
end $$;

-- Received purchase order: what we owe the vendor (A/P); stocked items go to Inventory,
-- everything else (non-stock items, freight, tax) to Cost of Goods Sold.
create or replace function public.post_po(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare o record; stocked numeric; d date;
begin
  delete from public.journal_entries where source_type = 'po' and source_id = _id;
  select * into o from public.purchase_orders where id = _id;
  if o.id is null or o.status = 'cancelled' then return; end if;
  if o.stock_received_at is null and o.status not in ('received','paid','completed') then return; end if;
  d := coalesce(o.stock_received_at, o.order_date)::date;
  if not public.books_open(o.company_id, d) then return; end if;
  select coalesce(sum(l.line_total), 0) into stocked
    from public.purchase_order_lines l join public.products p on p.id = l.product_id
   where l.purchase_order_id = o.id and p.item_type = 'stocked';
  perform public.write_entry(o.company_id, d, 'po', o.id, o.number, 'Purchase order ' || o.number,
    jsonb_build_array(
      jsonb_build_object('account', public.acct(o.company_id, 'inventory'), 'debit', least(stocked, o.total), 'vendor', o.vendor_id),
      jsonb_build_object('account', public.acct(o.company_id, 'cogs'), 'debit', o.total - least(stocked, o.total), 'vendor', o.vendor_id),
      jsonb_build_object('account', public.acct(o.company_id, 'ap'), 'credit', o.total, 'vendor', o.vendor_id)));
end $$;

-- Money received from a customer (into the bank) or paid to a vendor for a PO (out of the bank).
create or replace function public.post_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; co uuid; bank uuid; who uuid; ref text;
begin
  delete from public.journal_entries where source_type in ('payment', 'po_payment') and source_id = _id;
  select * into p from public.payments where id = _id;
  if p.id is null then return; end if;
  if p.sales_order_id is not null then
    select company_id, customer_id, number into co, who, ref from public.sales_orders where id = p.sales_order_id;
  else
    select company_id, vendor_id, number into co, who, ref from public.purchase_orders where id = p.purchase_order_id;
  end if;
  if co is null or not public.books_open(co, p.paid_on::date) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = co),
    public.acct(co, 'bank'));
  if p.sales_order_id is not null then
    perform public.write_entry(co, p.paid_on::date, 'payment', p.id, ref, 'Payment for ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', bank, 'debit', p.amount, 'customer', who),
        jsonb_build_object('account', public.acct(co, 'ar'), 'credit', p.amount, 'customer', who)));
  else
    perform public.write_entry(co, p.paid_on::date, 'po_payment', p.id, ref, 'Paid ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'ap'), 'debit', p.amount, 'vendor', who),
        jsonb_build_object('account', bank, 'credit', p.amount, 'vendor', who)));
  end if;
end $$;

-- Stock counted or adjusted by hand changes the value of Inventory.
-- Opening stock (brought over) goes against Opening Balance Equity.
create or replace function public.post_stock_move(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m record; co uuid; value numeric; other uuid;
begin
  delete from public.journal_entries where source_type = 'stock' and source_id = _id;
  select sm.*, p.cost, p.company_id as co, p.name as pname into m
    from public.stock_moves sm join public.products p on p.id = sm.product_id where sm.id = _id;
  if m.id is null or m.reason not in ('adjust', 'count', 'import') then return; end if;
  co := m.co;
  if not public.books_open(co, m.created_at::date) then return; end if;
  value := round(m.qty_change * m.cost, 2);
  other := case when coalesce(m.note, '') ilike 'opening stock%' or m.reason = 'import'
                then public.acct(co, 'opening') else public.acct(co, 'inv_adjust') end;
  perform public.write_entry(co, m.created_at::date, 'stock', m.id, null, 'Stock ' || m.reason || ': ' || m.pname,
    case when value >= 0 then jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'inventory'), 'debit', value),
        jsonb_build_object('account', other, 'credit', value))
      else jsonb_build_array(
        jsonb_build_object('account', other, 'debit', -value),
        jsonb_build_object('account', public.acct(co, 'inventory'), 'credit', -value)) end);
end $$;

-- Bill: each line's account (expense, asset...) against Accounts Payable.
create or replace function public.post_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare b record; lines jsonb;
begin
  delete from public.journal_entries where source_type = 'bill' and source_id = _id;
  select * into b from public.bills where id = _id;
  if b.id is null or b.status = 'void' or not public.books_open(b.company_id, b.bill_date) then return; end if;
  select coalesce(jsonb_agg(jsonb_build_object('account', coalesce(l.account_id, public.acct(b.company_id, 'cogs')),
           'debit', l.amount, 'memo', l.description, 'vendor', b.vendor_id)), '[]'::jsonb)
    into lines from public.bill_lines l where l.bill_id = b.id;
  perform public.write_entry(b.company_id, b.bill_date, 'bill', b.id, b.ref, 'Bill ' || coalesce(b.vendor_name, ''),
    lines || jsonb_build_array(jsonb_build_object('account', public.acct(b.company_id, 'ap'),
      'credit', (select coalesce(sum(amount), 0) from public.bill_lines where bill_id = b.id), 'vendor', b.vendor_id)));
end $$;

create or replace function public.post_bill_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; b record;
begin
  delete from public.journal_entries where source_type = 'bill_payment' and source_id = _id;
  select * into p from public.bill_payments where id = _id;
  if p.id is null then return; end if;
  select * into b from public.bills where id = p.bill_id;
  if b.id is null or not public.books_open(b.company_id, p.paid_on) then return; end if;
  perform public.write_entry(b.company_id, p.paid_on, 'bill_payment', p.id, b.ref, 'Paid bill ' || coalesce(b.vendor_name, ''),
    jsonb_build_array(
      jsonb_build_object('account', public.acct(b.company_id, 'ap'), 'debit', p.amount, 'vendor', b.vendor_id),
      jsonb_build_object('account', coalesce(p.account_id,
          (select default_bank_account_id from public.company_settings where company_id = b.company_id),
          public.acct(b.company_id, 'bank')), 'credit', p.amount, 'vendor', b.vendor_id)));
end $$;

-- Keep a bill's paid amount, balance and status up to date.
create or replace function public.refresh_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t numeric; paid numeric;
begin
  select coalesce(sum(amount), 0) into t from public.bill_lines where bill_id = _id;
  select coalesce(sum(amount), 0) into paid from public.bill_payments where bill_id = _id;
  update public.bills set total = t, amount_paid = paid, balance = t - paid, updated_at = now(),
    status = case when status = 'void' then 'void' when t - paid <= 0.005 and t > 0 then 'paid' else 'open' end
   where id = _id;
end $$;

grant execute on function public.refresh_bill(uuid) to authenticated;

-- ---------- Triggers: re-post when a document changes ----------
create or replace function public.trg_post()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  r := coalesce(new, old);
  case tg_table_name
    when 'sales_orders' then perform public.post_invoice(r.id);
    when 'sales_order_lines' then perform public.post_invoice(r.sales_order_id);
    when 'purchase_orders' then perform public.post_po(r.id);
    when 'purchase_order_lines' then perform public.post_po(r.purchase_order_id);
    when 'payments' then perform public.post_payment(r.id);
    when 'stock_moves' then perform public.post_stock_move(r.id);
    when 'bills' then perform public.post_bill(r.id);
    when 'bill_lines' then perform public.refresh_bill(r.bill_id); perform public.post_bill(r.bill_id);
    when 'bill_payments' then perform public.refresh_bill(r.bill_id); perform public.post_bill_payment(r.id);
  end case;
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['sales_orders','sales_order_lines','purchase_orders','purchase_order_lines',
    'payments','stock_moves','bills','bill_lines','bill_payments'] loop
    execute format('drop trigger if exists %I on public.%I', t || '_post', t);
    execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.trg_post()', t || '_post', t);
  end loop;
end $$;

-- Re-post everything for the active company (after setting the books start date, or a restore).
create or replace function public.rebuild_books()
returns json language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company(); r record; n int := 0;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  perform public.seed_accounts(co);
  delete from public.journal_entries
   where company_id = co and source_type not in ('manual', 'opening');
  for r in select id from public.sales_orders where company_id = co loop perform public.post_invoice(r.id); n := n + 1; end loop;
  for r in select id from public.purchase_orders where company_id = co loop perform public.post_po(r.id); end loop;
  for r in select p.id from public.payments p where p.company_id = co loop perform public.post_payment(r.id); end loop;
  for r in select sm.id from public.stock_moves sm where sm.company_id = co and sm.reason in ('adjust','count','import')
    loop perform public.post_stock_move(r.id); end loop;
  for r in select id from public.bills where company_id = co loop perform public.post_bill(r.id); end loop;
  for r in select bp.id from public.bill_payments bp where bp.company_id = co loop perform public.post_bill_payment(r.id); end loop;
  return json_build_object('entries', (select count(*) from public.journal_entries where company_id = co));
end $$;
grant execute on function public.rebuild_books() to authenticated;

-- ---------- Reports ----------
-- Totals per account for a period (from/to may be null). Uses the reader's access rules.
create or replace function public.account_totals(_from date, _to date)
returns table (account_id uuid, debit numeric, credit numeric)
language sql stable set search_path = public as $$
  select l.account_id, sum(l.debit), sum(l.credit)
    from public.journal_lines l join public.journal_entries e on e.id = l.entry_id
   where (_from is null or e.entry_date >= _from) and (_to is null or e.entry_date <= _to)
   group by l.account_id
$$;
grant execute on function public.account_totals(date, date) to authenticated;
