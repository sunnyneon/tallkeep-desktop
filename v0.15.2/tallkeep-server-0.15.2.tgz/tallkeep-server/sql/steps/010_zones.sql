-- SunRise Office — step 10: users can be limited to some sections (for example only Inventory).
-- user_roles.zones: empty (null) = every section. Otherwise a list like {Inventory}.
-- Admins always have every section.

alter table public.user_roles add column if not exists zones text[];

create or replace function public.has_zone(_uid uuid, _zone text)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _uid and (role = 'admin' or zones is null or _zone = any(zones))
  )
$$;
grant execute on function public.has_zone(uuid, text) to authenticated;

-- Add the section check to every rule on these tables.
-- Sales: customers, quotes/invoices, their lines, payments.
-- Purchasing: purchase orders. Vendors are shared by Purchasing and Inventory (product vendor menu).
do $$
declare p record; zone_check text;
begin
  for p in
    select tablename, policyname, qual, with_check from pg_policies
    where schemaname = 'public'
      and tablename in ('customers','sales_orders','sales_order_lines','payments',
                        'purchase_orders','purchase_order_lines','vendors','vendor_items')
      and coalesce(qual, '') not like '%has_zone%'
      and coalesce(with_check, '') not like '%has_zone%'
  loop
    zone_check := case
      when p.tablename in ('customers','sales_orders','sales_order_lines','payments')
        then 'public.has_zone(auth.uid(), ''Sales'')'
      when p.tablename in ('purchase_orders','purchase_order_lines')
        then 'public.has_zone(auth.uid(), ''Purchasing'')'
      else '(public.has_zone(auth.uid(), ''Purchasing'') or public.has_zone(auth.uid(), ''Inventory''))'
    end;
    if p.qual is not null then
      execute format('alter policy %I on public.%I using ((%s) and %s)',
        p.policyname, p.tablename, p.qual, zone_check);
    end if;
    if p.with_check is not null then
      execute format('alter policy %I on public.%I with check ((%s) and %s)',
        p.policyname, p.tablename, p.with_check, zone_check);
    end if;
  end loop;
end $$;

-- Mark fulfilled / Undo fulfilled are Sales actions.
do $$
declare f text; src text;
begin
  foreach f in array array['public.take_order_stock(uuid,uuid)', 'public.return_order_stock(uuid)'] loop
    select pg_get_functiondef(f::regprocedure) into src;
    if src not like '%has_zone%' then
      src := replace(src, 'not public.is_staff(auth.uid())', 'not public.has_zone(auth.uid(), ''Sales'')');
      execute src;
    end if;
  end loop;
end $$;
