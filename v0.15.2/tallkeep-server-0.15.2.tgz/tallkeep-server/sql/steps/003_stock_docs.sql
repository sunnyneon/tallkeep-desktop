-- SunRise Office — step 3: Adjust Stock, Transfer Stock and Count Sheet documents (like inFlow).
-- Structure only.

create table public.stock_docs (
  id uuid primary key default gen_random_uuid(),
  inflow_id text unique,                 -- 'sa-12', 'st-5', 'cs-3'
  kind text not null check (kind in ('adjust','transfer','count')),
  number text not null,
  doc_date timestamptz not null default now(),
  status text not null default 'open' check (status in ('open','completed','cancelled')),
  counted_by text,
  remarks text,
  completed_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index stock_docs_kind_idx on public.stock_docs (kind, doc_date desc);
create trigger stock_docs_touch before update on public.stock_docs for each row execute function public.touch_updated_at();

create table public.stock_doc_lines (
  id uuid primary key default gen_random_uuid(),
  inflow_id text unique,
  doc_id uuid not null references public.stock_docs(id) on delete cascade,
  line_no int not null default 0,
  product_id uuid references public.products(id) on delete set null,
  description text,
  location_id uuid references public.locations(id) on delete set null,
  shelf text not null default '',
  to_location_id uuid references public.locations(id) on delete set null,   -- transfers
  to_shelf text not null default '',
  qty numeric(14,4),          -- transfer: how many to move
  old_qty numeric(14,4),      -- adjust: before / count: what the system had
  new_qty numeric(14,4)       -- adjust: after  / count: what was counted
);
create index stock_doc_lines_doc_idx on public.stock_doc_lines (doc_id, line_no);

alter table public.stock_docs enable row level security;
alter table public.stock_doc_lines enable row level security;
create policy "Staff can read" on public.stock_docs for select to authenticated using (true);
create policy "Staff can add" on public.stock_docs for insert to authenticated with check (true);
create policy "Staff can edit" on public.stock_docs for update to authenticated using (true) with check (true);
create policy "Admins can delete" on public.stock_docs for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Staff can read" on public.stock_doc_lines for select to authenticated using (true);
create policy "Staff can add" on public.stock_doc_lines for insert to authenticated with check (true);
create policy "Staff can edit" on public.stock_doc_lines for update to authenticated using (true) with check (true);
create policy "Staff can delete lines" on public.stock_doc_lines for delete to authenticated using (true);
grant select, insert, update, delete on public.stock_docs, public.stock_doc_lines to authenticated;

-- Apply a stock document to stock, once. Adjust and count set each line to its new/counted
-- number; transfer moves the quantity from one place to another.
create or replace function public.complete_stock_doc(_doc_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare d record; l record; cur numeric;
begin
  if auth.uid() is null then raise exception 'Please sign in'; end if;
  select * into d from public.stock_docs where id = _doc_id for update;
  if d.id is null then raise exception 'Document not found'; end if;
  if d.status <> 'open' then raise exception 'This document is already %', d.status; end if;
  for l in select * from public.stock_doc_lines where doc_id = _doc_id and product_id is not null order by line_no loop
    if d.kind = 'transfer' then
      if l.location_id is null or l.to_location_id is null or coalesce(l.qty,0) <= 0 then
        raise exception 'Line % needs a from place, a to place and a quantity', l.line_no;
      end if;
      perform public.change_stock(l.product_id, l.location_id, l.shelf, -l.qty, 'move_out', d.number, 'stock_doc', d.id);
      perform public.change_stock(l.product_id, l.to_location_id, l.to_shelf, l.qty, 'move_in', d.number, 'stock_doc', d.id);
    else
      if l.location_id is null or l.new_qty is null then
        raise exception 'Line % needs a place and a new quantity', l.line_no;
      end if;
      select qty into cur from public.stock where product_id = l.product_id and location_id = l.location_id and shelf = l.shelf;
      update public.stock_doc_lines set old_qty = coalesce(cur,0) where id = l.id;
      if l.new_qty - coalesce(cur,0) <> 0 then
        perform public.change_stock(l.product_id, l.location_id, l.shelf, l.new_qty - coalesce(cur,0),
          case when d.kind = 'count' then 'count' else 'adjust' end, d.number, 'stock_doc', d.id);
      end if;
    end if;
  end loop;
  update public.stock_docs set status = 'completed', completed_at = now() where id = _doc_id;
end $$;
grant execute on function public.complete_stock_doc(uuid) to authenticated;
