-- SunRise Office — step 11: more than one company.
-- Every record belongs to a company. Each person has an "active company"; the database only
-- shows and saves records of that company, so every screen works per company without changes.
-- Admins can open every company; staff only the companies they are members of.
-- Existing data all becomes the first company (named from Company details).

-- ---------- Companies, members, active company ----------
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.company_members (
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (company_id, user_id)
);
create table if not exists public.user_company (
  user_id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete cascade
);

create or replace function public.can_use_company(_uid uuid, _c uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_uid, 'admin')
      or exists (select 1 from public.company_members where user_id = _uid and company_id = _c)
$$;

create or replace function public.active_company()
returns uuid language sql stable security definer set search_path = public as $$
  select coalesce(
    (select uc.company_id from public.user_company uc
      where uc.user_id = auth.uid() and public.can_use_company(auth.uid(), uc.company_id)),
    (select c.id from public.companies c
      where public.can_use_company(auth.uid(), c.id) order by c.created_at, c.name limit 1)
  )
$$;
grant execute on function public.can_use_company(uuid, uuid) to authenticated;
grant execute on function public.active_company() to authenticated;

-- The first company holds everything that exists today.
insert into public.companies (name)
select coalesce((select name from public.company_settings order by id limit 1), 'SunRise LED Inc.')
where not exists (select 1 from public.companies);

insert into public.company_members (company_id, user_id)
select c.id, r.user_id
  from (select id from public.companies order by created_at limit 1) c,
       (select distinct user_id from public.user_roles) r
on conflict do nothing;

-- ---------- company_id on every business table ----------
do $$
declare t text; first_co uuid := (select id from public.companies order by created_at limit 1);
begin
  foreach t in array array['company_settings','doc_counters','doc_footers','payment_terms','tax_rates',
    'price_lists','categories','locations','shelves','products','product_prices','serial_numbers',
    'stock','stock_moves','stock_docs','stock_doc_lines','customers','vendors','vendor_items',
    'sales_orders','sales_order_lines','purchase_orders','purchase_order_lines','payments']
  loop
    execute format('alter table public.%I add column if not exists company_id uuid references public.companies(id) on delete cascade', t);
    execute format('update public.%I set company_id = %L where company_id is null', t, first_co);
    execute format('alter table public.%I alter column company_id set not null', t);
    execute format('alter table public.%I alter column company_id set default public.active_company()', t);
    execute format('create index if not exists %I on public.%I (company_id)', t || '_company_idx', t);
  end loop;
end $$;

-- One settings row per company (it used to be a single row with id 1).
do $$
declare c record;
begin
  for c in select conname from pg_constraint
            where conrelid = 'public.company_settings'::regclass and contype = 'c'
              and pg_get_constraintdef(oid) like '%id = 1%'
  loop
    execute format('alter table public.company_settings drop constraint %I', c.conname);
  end loop;
end $$;
create sequence if not exists public.company_settings_id_seq start 2 owned by public.company_settings.id;
alter table public.company_settings alter column id set default nextval('public.company_settings_id_seq');
create unique index if not exists company_settings_one_per_company on public.company_settings (company_id);

-- Document numbers per company.
alter table public.doc_counters drop constraint if exists doc_counters_pkey;
alter table public.doc_counters add primary key (company_id, kind);

-- ---------- Every rule also requires the active company ----------
do $$
declare p record; tables text[] := array['company_settings','doc_counters','doc_footers','payment_terms',
  'tax_rates','price_lists','categories','locations','shelves','products','product_prices',
  'serial_numbers','stock','stock_moves','stock_docs','stock_doc_lines','customers','vendors',
  'vendor_items','sales_orders','sales_order_lines','purchase_orders','purchase_order_lines','payments'];
begin
  for p in
    select tablename, policyname, qual, with_check from pg_policies
     where schemaname = 'public' and tablename = any(tables)
       and coalesce(qual, '') not like '%active_company%'
       and coalesce(with_check, '') not like '%active_company%'
  loop
    if p.qual is not null then
      execute format('alter policy %I on public.%I using ((%s) and company_id = (select public.active_company()))',
        p.policyname, p.tablename, p.qual);
    end if;
    if p.with_check is not null then
      execute format('alter policy %I on public.%I with check ((%s) and company_id = (select public.active_company()))',
        p.policyname, p.tablename, p.with_check);
    end if;
  end loop;
end $$;

-- Rules for the new tables.
alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.user_company enable row level security;
drop policy if exists "See my companies" on public.companies;
create policy "See my companies" on public.companies for select to authenticated
  using (public.can_use_company(auth.uid(), id));
drop policy if exists "Admins rename companies" on public.companies;
create policy "Admins rename companies" on public.companies for update to authenticated
  using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
drop policy if exists "See members" on public.company_members;
create policy "See members" on public.company_members for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
drop policy if exists "Admins manage members" on public.company_members;
create policy "Admins manage members" on public.company_members for all to authenticated
  using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
drop policy if exists "See my active company" on public.user_company;
create policy "See my active company" on public.user_company for select to authenticated
  using (user_id = auth.uid());

-- ---------- Functions that now work within the active company ----------
create or replace function public.next_doc_number(_kind text)
returns text language plpgsql security definer set search_path = public as $$
declare p text; n int;
begin
  if not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  update public.doc_counters set next_number = next_number + 1
   where kind = _kind and company_id = public.active_company()
   returning prefix, next_number - 1 into p, n;
  if p is null then raise exception 'Unknown document type %', _kind; end if;
  return p || lpad(n::text, 6, '0');
end $$;

create or replace function public.close_out_sales(_as_of timestamptz, _mark_shipped boolean default true)
returns json language plpgsql security definer set search_path = public as $$
declare n_inv int := 0; n_pay int := 0; amt numeric := 0; n_ship int := 0; co uuid := public.active_company();
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  update public.sales_orders
     set status = 'invoiced', invoice_date = coalesce(invoice_date, order_date)
   where status = 'open' and number not like 'RMA-%' and company_id = co;
  get diagnostics n_inv = row_count;
  select count(*), coalesce(sum(balance), 0) into n_pay, amt
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%' and company_id = co;
  insert into public.payments (company_id, sales_order_id, paid_on, amount, method, remarks, created_by)
  select co, id, _as_of, balance, 'Paid before switch-over', 'Marked paid when moving from inFlow', auth.uid()
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%' and company_id = co;
  update public.sales_orders set status = 'paid'
   where status = 'invoiced' and balance <= 0.005 and number not like 'RMA-%' and company_id = co;
  if _mark_shipped then
    update public.sales_orders set stock_taken_at = _as_of
     where stock_taken_at is null and status in ('paid','completed','invoiced') and number not like 'RMA-%' and company_id = co;
    get diagnostics n_ship = row_count;
  end if;
  return json_build_object('invoiced', n_inv, 'payments', n_pay, 'amount', amt, 'shipped', n_ship);
end $$;

-- Switch company (only to one you may open).
create or replace function public.set_active_company(_c uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_use_company(auth.uid(), _c) then raise exception 'You can''t open that company.'; end if;
  insert into public.user_company (user_id, company_id) values (auth.uid(), _c)
  on conflict (user_id) do update set company_id = excluded.company_id;
end $$;
grant execute on function public.set_active_company(uuid) to authenticated;

-- The companies I can open, and which one is active.
create or replace function public.my_companies()
returns table (id uuid, name text, active boolean)
language sql stable security definer set search_path = public as $$
  select c.id, c.name, c.id = public.active_company()
    from public.companies c
   where public.can_use_company(auth.uid(), c.id)
   order by c.created_at, c.name
$$;
grant execute on function public.my_companies() to authenticated;

-- Add a company (admin): its own settings, document numbers, payment terms, taxes and price lists,
-- copied from the active company so it is ready to use.
create or replace function public.create_company(_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare src uuid := public.active_company(); n uuid;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can add a company.'; end if;
  if coalesce(trim(_name), '') = '' then raise exception 'Type the company name.'; end if;
  insert into public.companies (name) values (trim(_name)) returning id into n;
  insert into public.company_members (company_id, user_id) values (n, auth.uid()) on conflict do nothing;
  insert into public.company_settings (company_id, name) values (n, trim(_name));
  insert into public.doc_counters (company_id, kind, prefix, next_number)
    select n, kind, prefix, 1001 from public.doc_counters where company_id = src;
  insert into public.payment_terms (company_id, name, days_due, is_active)
    select n, name, days_due, is_active from public.payment_terms where company_id = src;
  insert into public.tax_rates (company_id, name, rate, is_active)
    select n, name, rate, is_active from public.tax_rates where company_id = src;
  insert into public.price_lists (company_id, name, is_default, is_active)
    select n, name, is_default, is_active from public.price_lists where company_id = src;
  return n;
end $$;
grant execute on function public.create_company(text) to authenticated;
