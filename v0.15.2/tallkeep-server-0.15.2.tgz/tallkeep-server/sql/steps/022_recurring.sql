-- SunRise Office — step 22: payments and bills that repeat (autopay, rent, loans, insurance…).
--
-- * recurring: a saved payment (from a bank or card) or bill, with how often it repeats and the
--   next date. "auto" ones are made by the daily job on their day; the others wait for
--   "Make it now" on the Recurring page.
-- * make_recurring(): makes one check/payment (or bill) from a saved one.
-- * run_recurring_company(): what the daily job runs for each company (server only).
-- Security: staff with the Accounting section, in the active company.

create table if not exists public.recurring (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  name text not null,
  kind text not null default 'check' check (kind in ('check','bill')),
  account_id uuid references public.accounts(id),             -- paid from (for payments)
  method text not null default 'ach' check (method in ('check','ach','card','cash','other')),
  vendor_id uuid references public.vendors(id) on delete set null,
  payee text,
  memo text,
  lines jsonb not null default '[]'::jsonb,                    -- [{account_id, description, amount, property_id}]
  every text not null default 'month' check (every in ('week','month','quarter','year')),
  next_date date not null,
  end_date date,
  auto boolean not null default true,
  active boolean not null default true,
  last_made date,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists recurring_due_idx on public.recurring (company_id, active, next_date);

grant select, insert, update, delete on public.recurring to authenticated;
grant select, insert, update, delete on public.recurring to service_role;

alter table public.recurring enable row level security;
drop policy if exists "Staff can use" on public.recurring;
create policy "Staff can use" on public.recurring for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()));

-- The day after this one, for each "every".
create or replace function public.recurring_next(_d date, _every text)
returns date language sql immutable as $$
  select (case _every
    when 'week' then _d + interval '7 days'
    when 'quarter' then _d + interval '3 months'
    when 'year' then _d + interval '1 year'
    else _d + interval '1 month' end)::date
$$;

-- Make one payment (or bill) from a saved one, dated _date. Returns the new check or bill id.
create or replace function public.make_recurring(_id uuid, _date date)
returns uuid language plpgsql security definer set search_path = public as $$
declare r record; n uuid; x jsonb; i int := 0; vname text;
begin
  select * into r from public.recurring where id = _id;
  if r.id is null then raise exception 'Not found'; end if;
  vname := coalesce(r.payee, (select name from public.vendors where id = r.vendor_id), r.name);
  if r.kind = 'check' then
    insert into public.checks (company_id, account_id, method, number, check_date, vendor_id, payee, memo, to_print)
    values (r.company_id, r.account_id, r.method, null, _date, r.vendor_id, vname,
            coalesce(r.memo, r.name), r.method = 'check')
    returning id into n;
    for x in select value from jsonb_array_elements(r.lines) loop
      i := i + 1;
      insert into public.check_lines (company_id, check_id, line_no, account_id, description, amount, property_id)
      values (r.company_id, n, i, (x->>'account_id')::uuid, nullif(x->>'description', ''),
              coalesce((x->>'amount')::numeric, 0), nullif(x->>'property_id', '')::uuid);
    end loop;
  else
    insert into public.bills (company_id, vendor_id, vendor_name, bill_date, due_date, memo)
    values (r.company_id, r.vendor_id, vname, _date, _date, coalesce(r.memo, r.name))
    returning id into n;
    for x in select value from jsonb_array_elements(r.lines) loop
      i := i + 1;
      insert into public.bill_lines (company_id, bill_id, line_no, account_id, description, amount, property_id)
      values (r.company_id, n, i, (x->>'account_id')::uuid, nullif(x->>'description', ''),
              coalesce((x->>'amount')::numeric, 0), nullif(x->>'property_id', '')::uuid);
    end loop;
  end if;
  update public.recurring set last_made = _date where id = _id;
  return n;
end $$;
revoke all on function public.make_recurring(uuid, date) from public, anon, authenticated;
grant execute on function public.make_recurring(uuid, date) to service_role;

-- "Make it now" on the Recurring page: makes the next one and moves the date on.
create or replace function public.make_recurring_now(_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare r record; n uuid;
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')) then raise exception 'Not allowed'; end if;
  select * into r from public.recurring where id = _id and company_id = public.active_company();
  if r.id is null then raise exception 'Not found'; end if;
  n := public.make_recurring(_id, r.next_date);
  update public.recurring set next_date = public.recurring_next(r.next_date, r.every),
    active = case when r.end_date is not null and public.recurring_next(r.next_date, r.every) > r.end_date then false else active end
   where id = _id;
  return n;
end $$;
grant execute on function public.make_recurring_now(uuid) to authenticated;

-- The daily job: make everything that is due (catching up missed days, at most a year).
create or replace function public.run_recurring_company(_co uuid, _today date)
returns int language plpgsql security definer set search_path = public as $$
declare r record; d date; k int := 0; guard int;
begin
  for r in select * from public.recurring
            where company_id = _co and active and auto and next_date <= _today loop
    d := r.next_date; guard := 0;
    while d <= _today and (r.end_date is null or d <= r.end_date) and guard < 53 loop
      perform public.make_recurring(r.id, d);
      d := public.recurring_next(d, r.every);
      k := k + 1; guard := guard + 1;
    end loop;
    update public.recurring set next_date = d,
      active = case when r.end_date is not null and d > r.end_date then false else true end
     where id = r.id;
  end loop;
  return k;
end $$;
revoke all on function public.run_recurring_company(uuid, date) from public, anon, authenticated;
grant execute on function public.run_recurring_company(uuid, date) to service_role;
