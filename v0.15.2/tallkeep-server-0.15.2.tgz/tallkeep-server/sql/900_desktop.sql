-- Tallkeep Desktop: things the cloud app gets from Lovable's setup, filled in for an office install.
-- Safe to run again on every start.

insert into storage.buckets (id, name, public) values
  ('receipts', 'receipts', false),
  ('product-photos', 'product-photos', false),
  ('office-backups', 'office-backups', false)
on conflict (id) do nothing;

-- Every company has its settings row (this also sets up its chart of accounts).
insert into public.company_settings (company_id, name, business_type, addons)
select c.id, c.name, 'products', array['sales','purchasing','inventory','accounting']
  from public.companies c
 where not exists (select 1 from public.company_settings s where s.company_id = c.id);

-- Every company gets document numbers, payment terms and a price list if it has none.
insert into public.doc_counters (company_id, kind, prefix, next_number)
select c.id, k.kind, k.prefix, k.n
  from public.companies c
  cross join (values ('quote', 'QT-', 1001), ('sales_order', 'SO-', 1001),
                     ('purchase_order', 'PO-', 1001), ('rma', 'RMA-', 100001),
                     ('work_order', 'WO-', 1001)) as k(kind, prefix, n)
 where not exists (select 1 from public.doc_counters d where d.company_id = c.id and d.kind = k.kind);

insert into public.payment_terms (company_id, name, days_due, is_active)
select c.id, t.name, t.days, true
  from public.companies c
  cross join (values ('Due on receipt', 0), ('Net 15', 15), ('Net 30', 30)) as t(name, days)
 where not exists (select 1 from public.payment_terms p where p.company_id = c.id);

insert into public.price_lists (company_id, name, is_default, is_active)
select c.id, 'Regular price', true, true
  from public.companies c
 where not exists (select 1 from public.price_lists p where p.company_id = c.id);

-- The office's own account. Its trial, license and limits are set by the server's license check
-- (lib/license.mjs) right after this file runs.
update public.orgs set edition = 'desktop', is_platform = true where is_platform;

-- On an office computer the license decides: add and change only during the trial or with a
-- license (no "own group" exception here, unlike the cloud).
create or replace function public.org_can_write(_org uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select o.status in ('active', 'past_due')
                          or (o.status = 'trial' and (o.trial_ends_at is null or o.trial_ends_at > now()))
                     from public.orgs o where o.id = _org), true)
$$;
