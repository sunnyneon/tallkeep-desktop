import { i as __toESM } from "./_runtime.mjs";
import { n as db } from "./_ssr/db-zltnVrwr.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "./_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./_ssr/addons-KjiIkqpF.mjs";
import { b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./_authenticated-DCSCRNU2.mjs";
import { d as today, f as useAccounts, p as useTotals } from "./_ssr/accounting-QuDdqtoA.mjs";
import { r as fmtMoney } from "./_ssr/format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./_ssr/PageHeader-BwqSvPCx.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { t as Button } from "./_ssr/button-Bq5vK6RO.mjs";
import { f as thisMonth, h as worth, i as amountIn, l as monthRange, m as useHoldings, p as useBudgets } from "./_ssr/personal-BW24I9nu.mjs";
import { A as Scale, B as Percent, Cn as BadgeDollarSign, Ct as HandCoins, D as ScrollText, Dn as ArrowDown, F as Receipt, H as PenLine, Ht as CreditCard, I as Printer, It as FileCheckCorner, Kt as ClipboardList, M as Repeat, Mt as FileText, Nt as FileSpreadsheet, P as ReceiptText, Pt as FilePlusCorner, St as HardHat, Wt as Coins, Z as PackageCheck, _ as Target, _t as Inbox, a as Wallet, an as Camera, c as Users, d as Upload, dn as CalendarCheck, f as Undo2, fn as Building2, ft as LifeBuoy, gn as BookOpen, h as TrendingUp, ht as KeyRound, in as ChartColumn, ln as CalendarDays, lt as ListChecks, mn as Boxes, mt as Landmark, p as Truck, pt as LayoutDashboard, q as Package, qt as ClipboardCheck, r as Wrench, rn as ChartLine, t as Zap, un as CalendarClock, w as Settings, wn as ArrowRight, wt as Hammer, xn as Banknote, yn as Bitcoin, z as PiggyBank } from "./_libs/lucide-react.mjs";
import { t as GROUP_COLOR } from "./_ssr/nav-zxEQFfAn.mjs";
import { r as canSeeGroup, s as useAccess } from "./_ssr/access-DKSYonr4.mjs";
import { s as queueShoebox } from "./_ssr/shoebox-CG5vY4HE.mjs";
import { l as useReminders, n as daysBetween } from "./_ssr/reminders-vPYfNAHe.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/_authenticated-BxlDQ7qW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* The Shoebox on Home: drop papers (or choose them, or take a photo) and they go to the Shoebox,
* which reads and files them. Shows how many are waiting for you.
*/
function HomeShoebox() {
	const navigate = useNavigate();
	const pick = (0, import_react.useRef)(null);
	const photo = (0, import_react.useRef)(null);
	const [over, setOver] = (0, import_react.useState)(false);
	const waiting = useQuery({
		queryKey: ["shoebox-waiting"],
		queryFn: async () => {
			const { count } = await db.from("shoebox_items").select("id", {
				count: "exact",
				head: true
			}).eq("status", "needs_you");
			return count ?? 0;
		}
	});
	const send = (files) => {
		if (!files.length) return;
		queueShoebox(files);
		navigate({ to: "/shoebox" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		onDragOver: (e) => {
			if ([...e.dataTransfer.types].includes("Files")) {
				e.preventDefault();
				setOver(true);
			}
		},
		onDragLeave: () => setOver(false),
		onDrop: (e) => {
			e.preventDefault();
			setOver(false);
			send([...e.dataTransfer.files]);
		},
		className: cn("flex flex-col items-center gap-4 rounded-2xl border-2 border-dashed bg-card p-4 transition-colors sm:flex-row", over ? "border-[#F28C38] bg-[#F28C38]/10" : "border-[#F28C38]/40"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/shoebox.png",
				alt: "",
				className: "h-28 w-28 shrink-0 object-contain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 text-center sm:text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Shoebox"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Drop bank and card statements, receipts, bills and checks here. Tallkeep reads them and puts each one where it belongs."
					}),
					!!waiting.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shoebox",
						className: "mt-1 inline-block text-sm font-medium text-[#C2410C] underline",
						children: waiting.data === 1 ? "1 paper needs you" : `${waiting.data} papers need you`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 flex-wrap justify-center gap-2 sm:flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => pick.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }), " Choose files"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => photo.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }), " Take a photo"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: pick,
				type: "file",
				multiple: true,
				accept: ".pdf,.csv,.ofx,.qfx,.qbo,image/*",
				className: "hidden",
				onChange: (e) => send([...e.target.files ?? []])
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: photo,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => send([...e.target.files ?? []])
			})
		]
	});
}
/**
* Personal books, at the top of Home: net worth, this month's spending against the budget, bills
* due this week, and lines waiting in Bank Feeds. Each one opens its page.
*/
function PersonalSummary() {
	const { data: accounts } = useAccounts();
	const { data: all } = useTotals(null, today());
	const m = monthRange(thisMonth());
	const { data: month } = useTotals(m.from, m.to);
	const { data: holdings } = useHoldings();
	const { data: budgets } = useBudgets();
	const { data: reminders } = useReminders();
	const waiting = useQuery({
		queryKey: ["bank-waiting-count"],
		queryFn: async () => {
			const { count } = await db.from("bank_transactions").select("id", {
				count: "exact",
				head: true
			}).eq("status", "new");
			return count ?? 0;
		}
	});
	if (!accounts) return null;
	const net = all ? worth(accounts, all, holdings ?? []).net : null;
	const spendCats = accounts.filter((a) => a.type === "expense");
	const spent = spendCats.reduce((s, a) => s + amountIn(a, month), 0);
	const planned = spendCats.reduce((s, a) => s + ((budgets ?? []).find((b) => b.account_id === a.id)?.amount ?? 0), 0);
	const now = today();
	const due = (reminders ?? []).filter((r) => r.status === "active" && daysBetween(now, r.next_date) <= 7);
	const late = due.filter((r) => r.next_date < now).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/net-worth",
				label: "Net worth",
				value: net == null ? "…" : fmtMoney(net),
				main: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/budget",
				label: "Spent this month",
				value: fmtMoney(spent),
				note: planned ? `${planned - spent >= 0 ? `${fmtMoney(planned - spent)} left` : `${fmtMoney(spent - planned)} over`} of ${fmtMoney(planned)}` : "No budget yet",
				bad: planned > 0 && spent > planned
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/subscriptions",
				label: "Bills this week",
				value: String(due.length),
				note: late ? `${late} late` : due.length ? fmtMoney(due.reduce((s, r) => s + (r.amount ?? 0), 0)) : "Nothing due",
				bad: late > 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/banking",
				label: "Waiting in Bank Feeds",
				value: String(waiting.data ?? 0),
				note: waiting.data ? "Lines to record" : "All recorded",
				bad: !!waiting.data
			})
		]
	});
}
function Tile({ to, label, value, note, bad, main }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("rounded-2xl border p-4 transition-shadow hover:shadow-md", main ? "border-transparent bg-[#0E7C74] text-white" : "bg-card"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs", main ? "text-white/80" : "text-muted-foreground"),
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-2xl font-semibold tabular-nums", bad && "text-amber-600"),
				children: value
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs", main ? "text-white/80" : bad ? "text-amber-700" : "text-muted-foreground"),
				children: note
			})
		]
	});
}
var MY_MONEY = [
	{
		label: "Budget",
		to: "/budget",
		icon: Target,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Net Worth",
		to: "/net-worth",
		icon: TrendingUp,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Investments",
		to: "/investments",
		icon: ChartLine,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Bills & Subscriptions",
		to: "/subscriptions",
		icon: CalendarClock,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Monthly Review",
		to: "/monthly-review",
		icon: ListChecks,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Crypto Tax",
		to: "/crypto-tax",
		icon: Bitcoin,
		group: "Accounting",
		feature: "crypto_tax"
	},
	{
		label: "Shoebox",
		to: "/shoebox",
		icon: Inbox,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Check Register",
		to: "/register",
		icon: BookOpen,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Credit Card Register",
		to: "/card-register",
		icon: CreditCard,
		group: "Accounting",
		feature: "personal"
	}
];
var VENDORS = [
	{
		label: "Purchase Orders",
		to: "/purchase-orders",
		icon: ClipboardList,
		group: "Purchasing",
		feature: "purchasing"
	},
	{
		label: "Receive Stock",
		to: "/purchase-orders",
		icon: PackageCheck,
		group: "Purchasing",
		feature: "purchasing"
	},
	{
		label: "Enter Bills",
		to: "/bills/$id",
		params: { id: "new" },
		search: {},
		icon: ReceiptText,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Pay Bills",
		to: "/pay-bills",
		icon: Wallet,
		group: "Accounting",
		feature: "accounting"
	}
];
var VENDORS_MORE = [
	{
		label: "Vendors",
		to: "/vendors",
		icon: Truck,
		group: "Purchasing",
		feature: "purchasing"
	},
	{
		label: "Expense Paid Now",
		to: "/bills/$id",
		params: { id: "new" },
		search: { paid: 1 },
		icon: Receipt,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Technician Pay",
		to: "/tech-pay",
		icon: HardHat,
		group: "Purchasing",
		feature: "tech_pay"
	},
	{
		label: "Pay Sales Tax",
		to: "/sales-tax",
		icon: Percent,
		group: "Accounting",
		feature: "sales"
	},
	{
		label: "Vendor Credits",
		to: "/refunds",
		icon: Undo2,
		group: "Accounting",
		feature: "accounting"
	}
];
var CUSTOMERS = [
	{
		label: "Quotes",
		to: "/new-quote",
		icon: FilePlusCorner,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Invoices",
		to: "/new-invoice",
		icon: Receipt,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Receive Payments",
		to: "/sales-list",
		icon: HandCoins,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting"
	}
];
var CUSTOMERS_MORE = [
	{
		label: "Customers",
		to: "/customers",
		icon: Users,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Sales List",
		to: "/sales-list",
		icon: FileText,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Sales Receipt",
		to: "/sales-receipt",
		icon: BadgeDollarSign,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Statements",
		to: "/statements",
		icon: FileSpreadsheet,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Refunds & Credits",
		to: "/refunds",
		icon: Undo2,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Tickets",
		to: "/tickets",
		icon: LifeBuoy,
		group: "Sales",
		feature: "support"
	},
	{
		label: "Website Tickets",
		to: "/website-tickets",
		icon: LifeBuoy,
		group: "Sales",
		feature: "tickets"
	}
];
var INVENTORY = [
	{
		label: "Products",
		to: "/products",
		icon: Package,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Current Stock",
		to: "/stock",
		icon: Boxes,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Count Sheet",
		to: "/count",
		icon: ClipboardCheck,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Adjust Stock",
		to: "/adjust",
		icon: Wrench,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Work Orders",
		to: "/work-orders",
		search: {},
		icon: Hammer,
		group: "Inventory",
		feature: "work_orders"
	}
];
var PROPERTIES = [
	{
		label: "Properties",
		to: "/properties",
		icon: Building2,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Leases & Tenants",
		to: "/leases",
		search: {},
		icon: KeyRound,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Charge & Collect Rent",
		to: "/rent",
		icon: HandCoins,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting"
	}
];
var PROPERTIES_MORE = [{
	label: "Rent Roll",
	to: "/rent-roll",
	icon: ScrollText,
	group: "Properties",
	feature: "real_estate"
}];
var BANKING = [
	{
		label: "Fast Entry",
		to: "/fast-entry",
		icon: Zap,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Receipts",
		to: "/receipts",
		icon: Camera,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Write Checks",
		to: "/checks/$id",
		params: { id: "new" },
		search: {},
		icon: PenLine,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Credit Cards",
		to: "/credit-cards",
		search: {},
		icon: CreditCard,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Print Checks",
		to: "/print-checks",
		search: {},
		icon: Printer,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Transfers",
		to: "/bank-transfers",
		icon: Repeat,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Recurring",
		to: "/recurring",
		search: {},
		icon: CalendarClock,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Bank Feeds & Reconcile",
		to: "/banking",
		icon: Banknote,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Checks & Payments",
		to: "/checks",
		icon: BookOpen,
		group: "Accounting",
		feature: "accounting"
	}
];
var COMPANY = [
	{
		label: "Calendar",
		to: "/calendar",
		icon: CalendarDays,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Chart of Accounts",
		to: "/accounts",
		icon: Landmark,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Journal Entries",
		to: "/journal",
		search: {},
		icon: BookOpen,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Financial Reports",
		to: "/financials",
		search: {},
		icon: Scale,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Payroll",
		to: "/payroll",
		icon: Coins,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "1099 Forms",
		to: "/forms-1099",
		icon: FileCheckCorner,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Year-End & CPA",
		to: "/year-end",
		icon: CalendarCheck,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Reports",
		to: "/reports",
		icon: ChartColumn,
		group: "Reports"
	},
	{
		label: "Overview",
		to: "/overview",
		icon: LayoutDashboard,
		group: "General"
	},
	{
		label: "Settings",
		to: "/settings",
		icon: Settings,
		group: "Options"
	}
];
function Home() {
	const { user } = Route.useRouteContext();
	const { data: access } = useAccess(user.id);
	const { data: features } = useFeatures();
	const show = (t) => canSeeGroup(access, t.group) && (!t.feature || !features || features.includes(t.feature)) && !(t.hideWith && features?.includes(t.hideWith));
	const pick = (l) => l.filter(show);
	const sections = [
		{
			title: "Purchasing",
			color: GROUP_COLOR.Purchasing.main,
			flow: pick(VENDORS),
			more: pick(VENDORS_MORE)
		},
		{
			title: "Sales",
			color: GROUP_COLOR.Sales.main,
			flow: pick(CUSTOMERS),
			more: pick(CUSTOMERS_MORE)
		},
		{
			title: "Properties",
			color: GROUP_COLOR.Properties.main,
			flow: pick(PROPERTIES),
			more: pick(PROPERTIES_MORE)
		},
		{
			title: "Inventory",
			color: GROUP_COLOR.Inventory.main,
			flow: [],
			more: pick(INVENTORY)
		}
	].filter((s) => s.title === "Properties" || s.title === "Sales" ? [...s.flow, ...s.more].some((t) => t.group === s.title) : s.flow.length + s.more.length > 0).map((s) => s.title === "Purchasing" && features?.includes("personal") ? {
		...s,
		title: "Bills"
	} : s);
	const personal = !!features?.includes("personal");
	const myMoney = pick(MY_MONEY).filter((t) => t.to !== "/shoebox");
	const banking = pick(BANKING);
	const company = pick(COMPANY);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Home",
			text: personal ? "Your money at a glance. Drop papers in the Shoebox; open anything below." : "Where to go for each job, in the order the work flows. Numbers and to-dos are on Overview."
		}),
		personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonalSummary, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					features?.includes("accounting") && canSeeGroup(access, "Accounting") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeShoebox, {}),
					myMoney.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "My Money",
						color: "#0E7C74",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2 sm:grid-cols-6",
							children: myMoney.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
								t,
								color: "#0E7C74"
							}, t.label))
						})
					}),
					sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: s.title,
						color: s.color,
						children: [s.flow.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flow, {
							tiles: s.flow,
							color: s.color
						}), s.more.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid grid-cols-3 gap-2 sm:grid-cols-5 ${s.flow.length ? "mt-3 border-t pt-3" : ""}`,
							children: s.more.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
								t,
								color: s.color
							}, t.label))
						})]
					}, s.title))
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [banking.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Banking",
					color: GROUP_COLOR.Accounting.main,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3",
						children: banking.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
							t,
							color: GROUP_COLOR.Accounting.main
						}, t.label))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Company",
					color: GROUP_COLOR.Options.main,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3",
						children: company.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
							t,
							color: GROUP_COLOR[t.group].main
						}, t.label))
					})
				})]
			})]
		})
	] });
}
function Panel({ title, color, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 inline-block rounded-full px-3 py-0.5 text-xs font-bold uppercase tracking-wider text-white",
			style: { backgroundColor: color },
			children: title
		}), children]
	});
}
/** Steps in order, with arrows between them (down the page on phones). */
function Flow({ tiles, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col items-stretch gap-1 sm:flex-row sm:items-center",
		children: tiles.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "sm:flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
				t,
				color
			})
		}), i < tiles.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "hidden h-5 w-5 shrink-0 text-muted-foreground/60 sm:block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "mx-auto h-4 w-4 text-muted-foreground/60 sm:hidden" })] })] }, t.label))
	});
}
function TileLink({ t, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: t.to,
		params: t.params,
		search: t.search,
		className: "flex flex-col items-center gap-1.5 rounded-xl p-2 text-center text-xs font-medium transition-colors hover:bg-muted/60 sm:text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-11 w-11 place-items-center rounded-xl",
			style: {
				backgroundColor: `${color}1f`,
				color
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "h-6 w-6" })
		}), t.label]
	});
}
//#endregion
export { Home as component };
