import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stays.functions-BQCiGsL7.js
/**
* Short-term stays: read a calendar link from Airbnb, VRBO or Booking.com. The browser can't read
* those links itself (the sites don't allow it), so the server fetches the calendar text.
*/
var fetchCalendar_createServerFn_handler = createServerRpc({
	id: "983bd78fdde0496a70eac804f7e75ce9364b7de2107c5e0370f4fa96bfe9fad1",
	name: "fetchCalendar",
	filename: "src/lib/stays.functions.ts"
}, (opts) => fetchCalendar.__executeServer(opts));
var fetchCalendar = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	let u;
	try {
		u = new URL(String(d.url ?? "").trim().replace(/^webcal:/i, "https:"));
	} catch {
		throw new Error("That isn't a link. Copy the calendar link from Airbnb, VRBO or Booking.com.");
	}
	const testing = process.env["TALLKEEP_TEST_CALENDARS"] === "1";
	if (u.protocol !== "https:" && !testing) throw new Error("The calendar link must start with https://");
	if (!testing && /^(localhost|127\.|10\.|192\.168\.|169\.254\.|\[)/i.test(u.hostname)) throw new Error("That calendar link isn't on the internet.");
	return { url: u.toString() };
}).handler(fetchCalendar_createServerFn_handler, async ({ data }) => {
	let res;
	try {
		res = await fetch(data.url, {
			headers: {
				"user-agent": "Tallkeep calendar sync",
				accept: "text/calendar,*/*"
			},
			signal: AbortSignal.timeout(2e4)
		});
	} catch {
		throw new Error("Couldn't reach that calendar. Check the link and the internet connection.");
	}
	if (!res.ok) throw new Error(`The calendar site said ${res.status}. Check the link.`);
	const text = await res.text();
	if (text.length > 3e6) throw new Error("That calendar is too big.");
	if (!text.includes("BEGIN:VCALENDAR")) throw new Error("That link isn't a calendar (.ics) link.");
	return { text };
});
//#endregion
export { fetchCalendar_createServerFn_handler };
