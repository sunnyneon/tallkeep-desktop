import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { n as fileToPages, r as shrinkForStorage } from "./ai-C4gd9Sqm.mjs";
import { t as aiRead } from "./ai.functions-DP3vVMF7.mjs";
import { a as ruleFor, n as parseBankCsv, r as parseOfx } from "./bankfile-C7N990Vr.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/shoebox-CG5vY4HE.js
/**
* The Shoebox: drop bank and card statements, receipts, bills and checks in one place.
*
* For each file: is it the same file as before (fingerprint)? What is it (statements by file type;
* PDFs and photos by AI)? Then it goes where it belongs:
*   - statement → its bank or card account is found by the last 4 digits; the lines go into Bank
*     Feeds, and every line Tallkeep is sure of (a match in the books, or a remembered payee) is
*     recorded right away. The rest wait in Bank Feeds.
*   - receipt → Receipts, already read, ready to record with one click.
*   - bill → a bill to pay, when the vendor is known and the expense account can be guessed;
*     otherwise it waits here with the details filled in.
*   - check → waits here; one click opens it in Checks Received.
* Anything Tallkeep isn't sure of waits here ("needs you").
*/
var BUCKET = "receipts";
var T = (t) => db.from(t);
var waiting = [];
/** Files dropped on another page, for the Shoebox page to take in. */
function queueShoebox(files) {
	waiting = [...waiting, ...files];
}
function takeShoebox() {
	const f = waiting;
	waiting = [];
	return f;
}
var isTextBank = (f) => /\.(csv|ofx|qfx|qbo)$/i.test(f.name);
var canTake = (f) => isTextBank(f) || /^image\//.test(f.type) || /\.pdf$/i.test(f.name);
async function fingerprint(f) {
	const buf = await f.arrayBuffer();
	const h = await crypto.subtle.digest("SHA-256", buf);
	return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
var isDay = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? ""));
var money = (v) => v == null || v === "" || Number.isNaN(Number(v)) ? null : Math.abs(Number(v));
/** Take one file in. Returns the Shoebox item's id (or null when it was the same file again). */
async function takeIn(file, ctx) {
	const hash = await fingerprint(file);
	const { data: had } = await T("shoebox_items").select("id").eq("hash", hash).maybeSingle();
	if (had) return null;
	const { data: co } = await db.rpc("active_company");
	const { data: u } = await db.auth.getUser();
	const text = isTextBank(file);
	const pdf = /\.pdf$/i.test(file.name);
	ctx.step(`${file.name}: saving…`);
	const ext = text ? (file.name.split(".").pop() ?? "txt").toLowerCase() : pdf ? "pdf" : "jpg";
	const path = `${String(co)}/shoebox/${crypto.randomUUID()}.${ext}`;
	const blob = text ? file : await shrinkForStorage(file);
	const mime = text ? "text/plain" : pdf ? "application/pdf" : "image/jpeg";
	const up = await db.storage.from(BUCKET).upload(path, blob, { contentType: mime });
	const { data: row, error } = await T("shoebox_items").insert({
		file_name: file.name,
		file_path: up.error ? null : path,
		mime,
		size: file.size,
		hash,
		created_by: u.user?.id,
		kind: text ? "statement" : "unknown"
	}).select("id").single();
	if (error) throw new Error(error.message);
	const id = row.id;
	try {
		await sortAndFile(id, file, ctx);
	} catch (e) {
		await T("shoebox_items").update({
			status: "failed",
			error: e.message
		}).eq("id", id);
	}
	return id;
}
/** Work out what the file is, then put it where it belongs. */
async function sortAndFile(id, file, ctx) {
	if (isTextBank(file)) {
		const text = await file.text();
		const last4 = /<OFX>|<STMTTRN>/i.test(text) ? /<ACCTID>\s*[^<\s]*?(\d{4})\s*</i.exec(text)?.[1] ?? null : null;
		const acct = findAccount(ctx.accounts, last4, null);
		await T("shoebox_items").update({
			kind: "statement",
			ai: last4 ? { account_last4: last4 } : null
		}).eq("id", id);
		if (!acct) return void await needsYou(id, "statement", "A bank or card file. Which account is it for?");
		await fileStatement(id, file, acct, ctx);
		return;
	}
	ctx.step(`${file.name}: AI is looking at it…`);
	const pages = await fileToPages(file, 2);
	const r = JSON.parse(await aiRead({ data: {
		feature: "sort",
		images: pages
	} }));
	const kind = String(r["kind"] ?? "other");
	await T("shoebox_items").update({ ai: r }).eq("id", id);
	if (kind === "bank_statement" || kind === "card_statement") {
		await T("shoebox_items").update({ kind: "statement" }).eq("id", id);
		const acct = findAccount(ctx.accounts, r["account_last4"] ? String(r["account_last4"]) : null, kind === "card_statement" ? "credit_card" : "bank");
		if (!acct) return void await needsYou(id, "statement", `${kind === "card_statement" ? "A credit card" : "A bank"} statement${r["issuer"] ? ` from ${String(r["issuer"])}` : ""}${r["account_last4"] ? ` (ending ${String(r["account_last4"])})` : ""}. Which account is it for?`);
		await fileStatement(id, file, acct, ctx);
		return;
	}
	if (kind === "receipt") return void await fileReceipt(id, r, ctx);
	if (kind === "bill") return void await fileBill(id, r, ctx, false);
	if (kind === "check") return void await needsYou(id, "check", `A check${r["payer"] ? ` from ${String(r["payer"])}` : ""}${money(r["amount"]) ? ` for $${money(r["amount"]).toFixed(2)}` : ""}. Open it in Checks Received to put it on their invoices.`);
	await needsYou(id, "unknown", `Not sure what this is${r["description"] ? ` (${String(r["description"])})` : ""}. Tell Tallkeep what it is.`);
}
async function needsYou(id, kind, summary) {
	await T("shoebox_items").update({
		status: "needs_you",
		kind,
		summary
	}).eq("id", id);
}
/** A bank or card account by the last 4 digits on the statement (only when exactly one fits). */
function findAccount(accounts, last4, kind) {
	const regs = accounts.filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	const pool = kind ? regs.filter((a) => a.kind === kind) : regs;
	if (last4) {
		const hits = regs.filter((a) => `${a.number ?? ""} ${a.name} ${a.description ?? ""}`.includes(last4));
		if (hits.length === 1) return hits[0];
	}
	return pool.length === 1 && kind ? pool[0] : null;
}
/** The lines of a PDF statement, read by AI (6 pages at a time). */
async function readStatementPdf(file, kind, step) {
	const pages = await fileToPages(file, 40);
	const lines = [];
	for (let i = 0; i < pages.length; i += 6) {
		step(`${file.name}: reading pages ${i + 1}–${Math.min(i + 6, pages.length)} of ${pages.length}…`);
		const r = JSON.parse(await aiRead({ data: {
			feature: "statement",
			images: pages.slice(i, i + 6),
			hint: `This is a ${kind === "credit_card" ? "credit card" : "bank account"} statement${pages.length > 6 ? `, pages ${i + 1}-${Math.min(i + 6, pages.length)} of ${pages.length}` : ""}.`
		} }));
		lines.push(...r["lines"] ?? []);
	}
	const seen = /* @__PURE__ */ new Map();
	const out = [];
	for (const l of lines) {
		const date = String(l.date ?? "").slice(0, 10);
		const amount = Math.round(Number(l.amount) * 100) / 100;
		if (!isDay(date) || !amount) continue;
		const description = String(l.description ?? "").trim();
		const k = `${date}|${amount}|${description.toLowerCase()}`;
		const n = (seen.get(k) ?? 0) + 1;
		seen.set(k, n);
		out.push({
			txn_date: date,
			amount,
			description,
			ref: l.ref ? String(l.ref) : null,
			fit_id: `pdf:${k}:${n}`
		});
	}
	return out;
}
/** Bring a statement's lines into Bank Feeds, then record the sure ones. */
async function fileStatement(id, file, acct, ctx) {
	let lines;
	if (isTextBank(file)) {
		const text = await file.text();
		lines = /<OFX>|<STMTTRN>/i.test(text) ? parseOfx(text) : parseBankCsv(text, false);
	} else lines = await readStatementPdf(file, acct.kind, ctx.step);
	if (typeof lines === "string") throw new Error(lines);
	if (!lines.length) throw new Error("No lines found in this statement.");
	ctx.step(`${file.name}: putting the lines in Bank Feeds…`);
	const count = async () => (await db.from("bank_transactions").select("id", {
		count: "exact",
		head: true
	}).eq("account_id", acct.id)).count ?? 0;
	const before = await count();
	const { error } = await db.from("bank_transactions").upsert(lines.map((p) => ({
		...p,
		account_id: acct.id
	})), {
		onConflict: "account_id,fit_id",
		ignoreDuplicates: true
	});
	if (error) throw new Error(error.message);
	const added = await count() - before;
	const sure = added > 0 ? await recordSure(acct.id, new Set(lines.map((l) => l.fit_id))) : {
		matched: 0,
		added: 0
	};
	const done = sure.matched + sure.added;
	const left = Math.max(0, added - done);
	await T("shoebox_items").update({
		status: "done",
		kind: "statement",
		account_id: acct.id,
		target_type: "bank_import",
		summary: added === 0 ? `All ${lines.length} lines were already in ${acct.name}.` : `${added} new lines in ${acct.name}${lines.length > added ? ` (${lines.length - added} were already there)` : ""}. ${done} recorded automatically${left ? `, ${left} wait for you in Bank Feeds` : ""}.`
	}).eq("id", id);
}
var daysApart = (a, b) => Math.abs(Date.parse(`${a}T12:00:00`) - Date.parse(`${b}T12:00:00`)) / 864e5;
/** Record every new line Tallkeep is sure of: a match in the books, or a remembered payee. */
async function recordSure(accountId, only) {
	const [{ data: t }, { data: l }, rules] = await Promise.all([
		db.from("bank_transactions").select("id,txn_date,amount,description,status,source_id,fit_id").eq("account_id", accountId).limit(5e3),
		db.rpc("account_lines", {
			_account: accountId,
			_to: null
		}),
		fetchAll("bank_rules", "id,contains,account_id")
	]);
	const txns = t ?? [];
	const lines = l ?? [];
	const used = new Set(txns.filter((x) => x.source_id).map((x) => x.source_id));
	let matched = 0;
	let added = 0;
	for (const x of txns.filter((y) => y.status === "new" && (!only || only.has(y.fit_id ?? "")))) {
		const hit = lines.filter((b) => !b.cleared && !used.has(b.item_key) && Math.abs(Number(b.amount) - Number(x.amount)) < .005 && daysApart(b.entry_date, x.txn_date) <= 10).sort((a, b) => daysApart(a.entry_date, x.txn_date) - daysApart(b.entry_date, x.txn_date))[0];
		if (hit) {
			used.add(hit.item_key);
			if (!(await db.from("bank_transactions").update({
				status: "matched",
				source_type: hit.source_type,
				source_id: hit.item_key
			}).eq("id", x.id)).error) {
				await db.from("cleared_items").upsert({
					account_id: accountId,
					item_key: hit.item_key
				}, { onConflict: "account_id,item_key" });
				matched++;
			}
			continue;
		}
		const r = ruleFor(rules, x.description);
		if (r) {
			const { error } = await db.rpc("add_bank_transaction", {
				_txn: x.id,
				_other: r.account_id,
				_memo: x.description ?? ""
			});
			if (!error) added++;
			else console.warn("[shoebox] couldn't record a line", error.message);
		}
	}
	return {
		matched,
		added
	};
}
var vendorFor = (vendors, name) => name ? vendors.find((x) => x.name.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(x.name.toLowerCase())) : void 0;
async function fileReceipt(id, r, ctx) {
	const { data: item } = await T("shoebox_items").select("file_path,file_name,mime").eq("id", id).single();
	const it = item;
	if (!it.file_path) throw new Error("The file couldn't be saved. Try again.");
	const vendor = r["vendor"] ? String(r["vendor"]) : r["issuer"] ? String(r["issuer"]) : null;
	const v = vendorFor(ctx.vendors, vendor);
	const rule = vendor ? ruleFor(ctx.rules, vendor) : null;
	const { data: u } = await db.auth.getUser();
	const { data: rec, error } = await T("receipts").insert({
		file_path: it.file_path,
		file_name: it.file_name,
		mime: it.mime,
		created_by: u.user?.id,
		status: "read",
		vendor_name: v?.name ?? vendor,
		vendor_id: v?.id ?? null,
		receipt_date: isDay(r["date"]) ? String(r["date"]) : null,
		total: money(r["total"]),
		tax: r["tax"] == null ? null : Number(r["tax"]),
		account_id: rule?.account_id ?? null,
		ai: r
	}).select("id").single();
	if (error) throw new Error(error.message);
	await T("shoebox_items").update({
		status: "done",
		kind: "receipt",
		target_type: "receipt",
		target_id: rec.id,
		summary: `Receipt${v?.name || vendor ? ` from ${v?.name ?? vendor}` : ""}${money(r["total"]) ? ` for $${money(r["total"]).toFixed(2)}` : ""}. Ready in Receipts: one click to record it.`
	}).eq("id", id);
}
/** The expense account to guess for a vendor: a remembered payee, or their last bill's account. */
async function guessAccount(ctx, vendorId, name) {
	const rule = name ? ruleFor(ctx.rules, name) : null;
	if (rule) return rule.account_id;
	if (!vendorId) return null;
	const { data } = await T("bills").select("id,bill_lines(account_id)").eq("vendor_id", vendorId).order("bill_date", { ascending: false }).limit(1);
	return (data ?? [])[0]?.bill_lines?.find((x) => x.account_id)?.account_id ?? null;
}
/** A bill: entered right away when the vendor is known and the account can be guessed. */
async function fileBill(id, r, ctx, force) {
	const name = r["vendor"] ? String(r["vendor"]) : r["issuer"] ? String(r["issuer"]) : null;
	const v = vendorFor(ctx.vendors, name);
	const draft = {
		vendor: v?.name ?? name ?? "",
		total: money(r["total"]),
		billDate: isDay(r["date"]) ? String(r["date"]) : null,
		dueDate: isDay(r["due_date"]) ? String(r["due_date"]) : null,
		ref: r["bill_number"] ? String(r["bill_number"]) : null,
		accountId: await guessAccount(ctx, v?.id ?? null, name)
	};
	await T("shoebox_items").update({
		kind: "bill",
		ai: {
			...r,
			draft
		}
	}).eq("id", id);
	if ((v || force) && draft.total && draft.accountId) return addBill(id, draft, ctx);
	await needsYou(id, "bill", `A bill${draft.vendor ? ` from ${draft.vendor}` : ""}${draft.total ? ` for $${draft.total.toFixed(2)}` : ""}${draft.dueDate ? `, due ${draft.dueDate}` : ""}. Check the details and add it.`);
}
/** Enter the bill (to pay later in Pay Bills). */
async function addBill(id, d, ctx) {
	if (!d.vendor.trim()) throw new Error("Type who the bill is from.");
	if (!d.total || d.total <= 0) throw new Error("Type the amount due.");
	if (!d.accountId) throw new Error("Choose what the bill is for (the expense account).");
	const v = vendorFor(ctx.vendors, d.vendor.trim());
	const { data: u } = await db.auth.getUser();
	const { data: bill, error } = await T("bills").insert({
		vendor_id: v?.id ?? null,
		vendor_name: v?.name ?? d.vendor.trim(),
		ref: d.ref,
		bill_date: d.billDate ?? (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"),
		due_date: d.dueDate,
		memo: "From the Shoebox",
		created_by: u.user?.id
	}).select("id").single();
	if (error) throw new Error(error.message);
	const billId = bill.id;
	const ln = await T("bill_lines").insert({
		bill_id: billId,
		line_no: 1,
		account_id: d.accountId,
		description: d.ref ? `Bill ${d.ref}` : "Bill",
		amount: d.total
	});
	if (ln.error) throw new Error(ln.error.message);
	await T("shoebox_items").update({
		status: "done",
		kind: "bill",
		target_type: "bill",
		target_id: billId,
		summary: `Bill from ${v?.name ?? d.vendor} for $${d.total.toFixed(2)}${d.dueDate ? `, due ${d.dueDate}` : ""}. Entered in Bills; pay it in Pay Bills.`
	}).eq("id", id);
}
/** The file back from storage (to read it again as something else). */
async function fileOf(item) {
	if (!item.file_path) throw new Error("The file wasn't saved. Drop it in again.");
	const { data, error } = await db.storage.from(BUCKET).download(item.file_path);
	if (error || !data) throw new Error(error?.message ?? "File not found.");
	return new File([data], item.file_name, { type: item.mime ?? data.type });
}
/** "It's a …": file it again as the kind the person picked. */
async function fileAs(item, kind, ctx, accountId) {
	await T("shoebox_items").update({
		status: "reading",
		error: null
	}).eq("id", item.id);
	try {
		const file = await fileOf(item);
		if (kind === "statement") {
			const acct = ctx.accounts.find((a) => a.id === accountId);
			if (!acct) throw new Error("Pick the account.");
			await fileStatement(item.id, file, acct, ctx);
			return;
		}
		let r = item.ai ?? {};
		if (!r["vendor"] && !r["total"] && !/^text\//.test(item.mime ?? "")) {
			ctx.step(`${item.file_name}: AI is reading it…`);
			r = JSON.parse(await aiRead({ data: {
				feature: "receipt",
				images: await fileToPages(file, 3)
			} }));
		}
		if (kind === "receipt") await fileReceipt(item.id, r, ctx);
		else await fileBill(item.id, r, ctx, false);
	} catch (e) {
		await T("shoebox_items").update({
			status: "needs_you",
			error: e.message
		}).eq("id", item.id);
		throw e;
	}
}
async function skipItem(id) {
	await T("shoebox_items").update({ status: "skipped" }).eq("id", id);
}
async function loadItems() {
	const { data, error } = await T("shoebox_items").select("*").order("created_at", { ascending: false }).limit(300);
	if (error) throw new Error(error.message);
	return data ?? [];
}
//#endregion
export { fileOf as a, skipItem as c, fileAs as i, takeIn as l, addBill as n, loadItems as o, canTake as r, queueShoebox as s, BUCKET as t, takeShoebox as u };
