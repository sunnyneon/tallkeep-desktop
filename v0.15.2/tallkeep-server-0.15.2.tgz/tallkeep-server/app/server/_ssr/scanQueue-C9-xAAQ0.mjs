//#region ../../node_modules/.nitro/vite/services/ssr/assets/scanQueue-C9-xAAQ0.js
var pending = {
	kind: "receipt",
	files: []
};
function queueScans(files, kind = "receipt") {
	pending = {
		kind,
		files
	};
}
/** The files waiting for this kind of page (and only those). */
function takeScans(kind = "receipt") {
	if (pending.kind !== kind) return [];
	const out = pending.files;
	pending = {
		kind: "receipt",
		files: []
	};
	return out;
}
//#endregion
export { takeScans as n, queueScans as t };
