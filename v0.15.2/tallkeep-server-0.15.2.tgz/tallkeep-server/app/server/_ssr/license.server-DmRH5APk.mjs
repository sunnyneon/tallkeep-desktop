import { licensePem } from "./license-pem-Bul1iZky.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/license.server-DmRH5APk.js
/**
* Making and sending Tallkeep Desktop license keys (server only). Used by the owner panel (a key
* made by hand) and by checkout (a key made when a customer pays).
*/
var CODE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function newId() {
	const s = [...crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(8))].map((x) => CODE[x % 32]).join("");
	return `${s.slice(0, 4)}-${s.slice(4)}`;
}
/** Sign a license key (TK1.<payload>.<signature>) with Tallkeep's private key. */
async function signLicenseKey(d) {
	const pem = licensePem();
	if (!pem) throw new Error("License keys can't be made yet: add the LICENSE_PRIVATE_KEY secret.");
	const nodeCrypto = await import("node:crypto");
	const payload = {
		v: 1,
		id: d.id,
		to: d.to,
		...d.email?.trim() ? { email: d.email.trim() } : {},
		companies: d.companies,
		users: d.users,
		updates: d.updatesUntil || null,
		...d.expires ? { expires: d.expires } : {},
		issued: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	};
	const body = `TK1.${Buffer.from(JSON.stringify(payload)).toString("base64url")}`;
	return `${body}.${nodeCrypto.sign(null, Buffer.from(body), pem).toString("base64url")}`;
}
/** The license number inside a key, if the key carries Tallkeep's signature. */
async function keyId(key) {
	const m = /^(TK1\.([A-Za-z0-9_-]+))\.([A-Za-z0-9_-]+)$/.exec(key);
	const pem = licensePem();
	if (!m || !pem) return null;
	const nodeCrypto = await import("node:crypto");
	const pub = nodeCrypto.createPublicKey(pem);
	if (!nodeCrypto.verify(null, Buffer.from(m[1]), pub, Buffer.from(m[3], "base64url"))) return null;
	try {
		const p = JSON.parse(Buffer.from(m[2], "base64url").toString("utf8"));
		return typeof p.id === "string" ? p.id : null;
	} catch {
		return null;
	}
}
/** Sign a new key and record it. Returns its short id and the key. */
async function createLicense(admin, d) {
	const id = newId();
	const key = await signLicenseKey({
		id,
		to: d.to,
		email: d.email ?? null,
		companies: d.companies,
		users: d.users,
		updatesUntil: d.updatesUntil || null,
		expires: d.expires ?? null
	});
	const { error } = await admin.from("desktop_licenses").insert({
		id,
		license_key: key,
		to_name: d.to,
		email: d.email?.trim() || null,
		companies: d.companies,
		users: d.users,
		updates_until: d.updatesUntil || null,
		computers: d.computers,
		notes: d.notes?.trim() || null,
		created_by: d.createdBy ?? null,
		...d.expires ? { expires: d.expires } : {},
		...d.stripeSession ? {
			stripe_session: d.stripeSession,
			paid_cents: d.paidCents ?? null
		} : {}
	});
	if (error) throw new Error(error.message);
	return {
		id,
		key
	};
}
var DOWNLOAD_PATH = "/api/public/download";
/** Email a key to the customer, with a copy to Tallkeep. Says whether it went. */
async function mailLicense(o) {
	const apiKey = process.env["TALLKEEP_RESEND_API_KEY"] || process.env["RESEND_API_KEY"];
	if (!apiKey) return {
		ok: false,
		why: "the TALLKEEP_RESEND_API_KEY secret is missing"
	};
	const from = process.env["TALLKEEP_EMAIL_FROM"] || "Tallkeep <hello@send.tallkeep.com>";
	const copyTo = process.env["LICENSE_COPY_TO"] || "hello@tallkeep.com";
	const n = (v, one, many) => v == null ? `any number of ${many}` : `${v} ${v === 1 ? one : many}`;
	const text = [
		o.updated ? `Thank you, ${o.name}. Your Tallkeep license is updated.` : `Thank you for buying Tallkeep, ${o.name}.`,
		"",
		o.updated ? "Your new license key (copy all of it):" : "Your license key (copy all of it):",
		"",
		o.key,
		"",
		`Your license covers ${n(o.companies, "company", "companies")}, ${n(o.users, "person", "people")}, 1 office computer${o.updatesUntil ? `, updates until ${o.updatesUntil}` : ""}.`,
		`License number: ${o.id} (give us this number if you ever contact us).`,
		"",
		...o.updated ? ["Your office computer picks up the new key by itself within a day. To use it now:", "Settings → Plan & computer → Check for my updated key (or paste the key there)."] : [
			"Getting started:",
			`1. Download Tallkeep on the computer that will keep your books: ${o.origin}${DOWNLOAD_PATH}`,
			"2. Install it and create your company. If Windows says it protected your PC, click More info, then Run anyway (Tallkeep is new, so Windows doesn't know it yet).",
			"3. Open Settings → Plan & computer, paste the key and press Save the license key."
		],
		"",
		"Questions? Just reply to this email.",
		"",
		"Tallkeep"
	].join("\n");
	try {
		const res = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from,
				to: [o.to],
				bcc: [copyTo],
				reply_to: copyTo,
				subject: o.updated ? "Your updated Tallkeep license key" : "Your Tallkeep license key",
				text
			})
		});
		if (res.ok) return {
			ok: true,
			why: ""
		};
		return {
			ok: false,
			why: `the email service said: ${(await res.json().catch(() => ({}))).message ?? res.status}`
		};
	} catch {
		return {
			ok: false,
			why: "the email service couldn't be reached"
		};
	}
}
/** Note on the license whether its key email went. */
var mailNote = (r) => r.ok ? `key emailed ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}` : `key email didn't go (${r.why})`;
var wasMailed = (notes) => /key emailed/.test(notes ?? "");
/** A plain email from Tallkeep to a customer, with a copy to Tallkeep (hello@tallkeep.com). */
async function sendTallkeepMail(o) {
	const apiKey = process.env["TALLKEEP_RESEND_API_KEY"] || process.env["RESEND_API_KEY"];
	if (!apiKey) return {
		ok: false,
		why: "the TALLKEEP_RESEND_API_KEY secret is missing"
	};
	const from = process.env["TALLKEEP_EMAIL_FROM"] || "Tallkeep <hello@send.tallkeep.com>";
	const copyTo = process.env["LICENSE_COPY_TO"] || "hello@tallkeep.com";
	try {
		const res = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${apiKey}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from,
				to: [o.to],
				bcc: [copyTo],
				reply_to: o.replyTo || copyTo,
				subject: o.subject,
				text: o.text,
				...o.attachments?.length ? { attachments: o.attachments } : {}
			})
		});
		if (res.ok) return {
			ok: true,
			why: ""
		};
		return {
			ok: false,
			why: `the email service said: ${(await res.json().catch(() => ({}))).message ?? res.status}`
		};
	} catch {
		return {
			ok: false,
			why: "the email service couldn't be reached"
		};
	}
}
//#endregion
export { createLicense, keyId, mailLicense, mailNote, sendTallkeepMail, signLicenseKey, wasMailed };
