import { t as supabase } from "./client-C9I0PyVu.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/db-zltnVrwr.js
/**
* Untyped handle to the database. The generated types in
* integrations/supabase/types.ts lag behind new tables, so pages use the
* small row types below instead.
*/
var db = supabase;
/** Read every row of a table (the API returns at most 1000 per request). */
async function fetchAll(table, select = "*", pageSize = 1e3) {
	const out = [];
	for (let from = 0;; from += pageSize) {
		const { data, error } = await db.from(table).select(select).range(from, from + pageSize - 1);
		if (error) throw error;
		out.push(...data ?? []);
		if (!data || data.length < pageSize) break;
	}
	return out;
}
var REASON_LABEL = {
	count: "Count sheet",
	adjust: "Stock adjustment",
	move_in: "Transfer in",
	move_out: "Transfer out",
	sold: "Sales order picking",
	received: "Purchase order receive",
	returned: "Returned",
	import: "Stock on hand when moved from inFlow",
	build_use: "Used in a work order",
	build_make: "Made by a work order",
	build_undo: "Work order undone"
};
//#endregion
export { db as n, fetchAll as r, REASON_LABEL as t };
