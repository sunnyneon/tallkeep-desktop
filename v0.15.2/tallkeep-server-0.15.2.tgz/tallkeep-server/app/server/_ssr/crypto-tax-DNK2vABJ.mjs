import { i as __toESM } from "../_runtime.mjs";
import { r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { st as LoaderCircle, tn as Check, zt as Download } from "../_libs/lucide-react.mjs";
import { a as num, o as parseCsv, v as qbDate } from "./quickbooks-DDZqKZVM.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as mtbl } from "./members-CRgkIqM9.mjs";
import { t as FilePick } from "./QuickBooksImport-M5D5JcMC.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/crypto-tax-DNK2vABJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Crypto tax (step 44 add-on): read an exchange's history file, keep each buy, sell, reward and
* move, and work out gains the way the IRS wants them: lots per wallet, matched by FIFO, HIFO or
* LIFO (chosen per year), short or long term (held more than a year), plus crypto income.
* Nothing here changes the books; it's for the tax return (Form 8949 rows for the CPA).
*/
var KIND_LABEL = {
	buy: "Bought",
	sell: "Sold",
	income: "Income (reward, staking, interest)",
	send: "Sent out",
	receive: "Received",
	fee: "Network fee",
	trade_in: "Traded for (got)",
	trade_out: "Traded away (gave)",
	ignore: "Leave out"
};
function table(csv, must) {
	const i = csv.findIndex((r) => must.every((m) => r.some((c) => c.trim().toLowerCase() === m.toLowerCase())));
	if (i < 0) return null;
	const head = csv[i].map((c) => c.trim().toLowerCase());
	const col = (...names) => {
		for (const n of names) {
			const k = head.indexOf(n.toLowerCase());
			if (k >= 0) return k;
		}
		return -1;
	};
	return {
		rows: csv.slice(i + 1).filter((r) => r.some((c) => c.trim())),
		col
	};
}
var at = (r, i) => i >= 0 ? (r[i] ?? "").trim() : "";
var money = (s) => {
	const v = num(s.replace(/[$€£]/g, ""));
	return Number.isFinite(v) ? Math.abs(v) : NaN;
};
var when = (s) => {
	const d = new Date(s.replace(" UTC", "Z").replace(/^(\d{4}-\d{2}-\d{2}) (\d)/, "$1T$2"));
	if (!Number.isNaN(d.getTime())) return d.toISOString();
	const q = qbDate(s);
	return q ? `${q}T12:00:00.000Z` : "";
};
/** Coinbase: Statements → Transaction history (CSV). */
function coinbase(csv) {
	const t = table(csv, [
		"Timestamp",
		"Transaction Type",
		"Asset"
	]);
	if (!t) return null;
	const c = {
		id: t.col("ID"),
		time: t.col("Timestamp"),
		type: t.col("Transaction Type"),
		asset: t.col("Asset"),
		qty: t.col("Quantity Transacted"),
		sub: t.col("Subtotal"),
		total: t.col("Total (inclusive of fees and/or spread)", "Total"),
		fee: t.col("Fees and/or Spread", "Fees"),
		price: t.col("Price at Transaction", "Spot Price at Transaction"),
		notes: t.col("Notes")
	};
	const out = [];
	for (const r of t.rows) {
		const type = at(r, c.type).toLowerCase();
		const asset = at(r, c.asset).toUpperCase();
		const qty = money(at(r, c.qty));
		const happened_at = when(at(r, c.time));
		if (!asset || !happened_at || !Number.isFinite(qty) || qty === 0) continue;
		const sub = money(at(r, c.sub));
		const price = money(at(r, c.price));
		const usd = Number.isFinite(sub) && sub > 0 ? sub : Number.isFinite(price) ? Math.round(price * qty * 100) / 100 : null;
		const fee = money(at(r, c.fee));
		const note = at(r, c.notes) || null;
		const base = {
			happened_at,
			asset,
			qty,
			usd,
			fee_usd: Number.isFinite(fee) ? fee : 0,
			note,
			source_id: at(r, c.id) || `${happened_at}|${type}|${asset}|${qty}`,
			needs_review: false
		};
		const kind = /^(buy|advanced trade buy|advance trade buy)$/.test(type) ? "buy" : /^(sell|advanced trade sell|advance trade sell)$/.test(type) ? "sell" : /convert/.test(type) ? null : /(reward|staking|learning|interest|inflation|income|earn|airdrop|cashback)/.test(type) ? "income" : /^(send|withdrawal|pro withdrawal)$/.test(type) ? "send" : /^(receive|deposit|pro deposit)$/.test(type) ? "receive" : null;
		if (/convert/.test(type)) {
			const m = (note ?? "").match(/converted\s+([\d.,]+)\s+(\w+)\s+to\s+([\d.,]+)\s+(\w+)/i);
			out.push({
				...base,
				kind: "trade_out",
				source_id: `${base.source_id}|out`
			});
			if (m) out.push({
				...base,
				kind: "trade_in",
				asset: m[4].toUpperCase(),
				qty: money(m[3]),
				source_id: `${base.source_id}|in`
			});
			continue;
		}
		if (!kind) {
			out.push({
				...base,
				kind: "ignore",
				needs_review: true
			});
			continue;
		}
		out.push({
			...base,
			kind,
			needs_review: kind === "receive" || kind === "send" || usd == null
		});
	}
	return out;
}
/** Kraken: History → Export → Trades (CSV). Buys and sells with their dollar cost. */
function krakenTrades(csv) {
	const t = table(csv, [
		"pair",
		"type",
		"cost",
		"vol"
	]);
	if (!t) return null;
	const c = {
		id: t.col("txid"),
		pair: t.col("pair"),
		time: t.col("time"),
		type: t.col("type"),
		cost: t.col("cost"),
		fee: t.col("fee"),
		vol: t.col("vol")
	};
	const out = [];
	for (const r of t.rows) {
		const pair = at(r, c.pair).toUpperCase();
		const m = pair.match(/^(.+?)(ZUSD|USD|USDT|USDC)$/);
		if (!m) continue;
		const asset = m[1].replace(/^X(?=[A-Z]{3,})/, "").replace(/^XBT$/, "BTC").replace(/^XXBT$/, "BTC");
		const happened_at = when(at(r, c.time));
		const qty = money(at(r, c.vol));
		if (!happened_at || !Number.isFinite(qty)) continue;
		const type = at(r, c.type).toLowerCase();
		out.push({
			happened_at,
			kind: type === "sell" ? "sell" : "buy",
			asset: asset === "XBT" ? "BTC" : asset,
			qty,
			usd: money(at(r, c.cost)),
			fee_usd: money(at(r, c.fee)) || 0,
			note: pair,
			source_id: at(r, c.id) || `${happened_at}|${pair}|${qty}`,
			needs_review: false
		});
	}
	return out;
}
/** Any other exchange or wallet: Date, Type, Asset, Quantity, USD (and Fee) columns. */
function generic(csv) {
	const t = table(csv, [
		"Date",
		"Type",
		"Asset"
	]);
	if (!t) return null;
	const c = {
		date: t.col("Date"),
		type: t.col("Type"),
		asset: t.col("Asset", "Coin"),
		qty: t.col("Quantity", "Amount", "Qty"),
		usd: t.col("USD", "Value", "USD Value", "Total"),
		fee: t.col("Fee", "Fee USD")
	};
	const out = [];
	for (const r of t.rows) {
		const happened_at = when(at(r, c.date));
		const asset = at(r, c.asset).toUpperCase();
		const qty = money(at(r, c.qty));
		if (!happened_at || !asset || !Number.isFinite(qty)) continue;
		const ty = at(r, c.type).toLowerCase();
		const kind = /buy/.test(ty) ? "buy" : /sell/.test(ty) ? "sell" : /(reward|stak|interest|income|airdrop)/.test(ty) ? "income" : /(send|withdraw)/.test(ty) ? "send" : /(receive|deposit)/.test(ty) ? "receive" : "ignore";
		const usd = money(at(r, c.usd));
		out.push({
			happened_at,
			kind,
			asset,
			qty,
			usd: Number.isFinite(usd) ? usd : null,
			fee_usd: money(at(r, c.fee)) || 0,
			note: at(r, c.type) || null,
			source_id: `${happened_at}|${ty}|${asset}|${qty}`,
			needs_review: kind === "ignore" || kind === "receive" || !Number.isFinite(usd)
		});
	}
	return out;
}
function readHistory(csv) {
	const cb = coinbase(csv);
	if (cb) return {
		source: "coinbase",
		records: cb
	};
	const kr = krakenTrades(csv);
	if (kr) return {
		source: "kraken",
		records: kr
	};
	const g = generic(csv);
	if (g) return {
		source: "other",
		records: g
	};
	return null;
}
var YEAR_MS = 31536e6;
var r2 = (n) => Math.round(n * 100) / 100;
/**
* Walk every record in time order. Buys and income make lots; sells take lots out by the year's
* method; a send matched with a receive of the same coin within 3 days (in another of your
* wallets) moves the lots, keeping their dates and cost.
*/
function work(records, methodFor) {
	const recs = [...records].filter((r) => r.kind !== "ignore").sort((a, b) => a.happened_at.localeCompare(b.happened_at));
	const lots = [];
	const res = {
		sales: [],
		income: [],
		holdings: [],
		review: []
	};
	const used = /* @__PURE__ */ new Set();
	const pairOf = /* @__PURE__ */ new Map();
	for (const s of recs.filter((r) => r.kind === "send")) {
		const rcv = recs.find((r) => r.kind === "receive" && !used.has(r.id) && r.asset === s.asset && r.wallet_id !== s.wallet_id && Math.abs(new Date(r.happened_at).getTime() - new Date(s.happened_at).getTime()) < 2592e5 && r.qty <= s.qty * 1.0001 && r.qty >= s.qty * .95);
		if (rcv) {
			used.add(rcv.id);
			pairOf.set(s.id, rcv);
			pairOf.set(rcv.id, s);
		}
	}
	const take = (wallet, asset, qty, year) => {
		const method = methodFor(year);
		const mine = lots.filter((l) => l.wallet === wallet && l.asset === asset && l.qty > 1e-12);
		mine.sort((a, b) => method === "hifo" ? b.cost / b.qty - a.cost / a.qty : method === "lifo" ? b.acquired.localeCompare(a.acquired) : a.acquired.localeCompare(b.acquired));
		const out = [];
		let left = qty;
		for (const l of mine) {
			if (left <= 1e-12) break;
			const q = Math.min(l.qty, left);
			const cost = l.cost / l.qty * q;
			out.push({
				...l,
				qty: q,
				cost
			});
			l.cost -= cost;
			l.qty -= q;
			left -= q;
		}
		return {
			out,
			short: left > 1e-9 ? left : 0
		};
	};
	for (const r of recs) {
		const year = new Date(r.happened_at).getUTCFullYear();
		if (r.kind === "buy" || r.kind === "trade_in") {
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			lots.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: r.qty,
				cost: (r.usd ?? 0) + (r.kind === "buy" ? r.fee_usd : 0),
				acquired: r.happened_at
			});
		} else if (r.kind === "income") {
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			res.income.push({
				date: r.happened_at,
				asset: r.asset,
				qty: r.qty,
				usd: r.usd ?? 0,
				wallet: r.wallet_id
			});
			lots.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: r.qty,
				cost: r.usd ?? 0,
				acquired: r.happened_at
			});
		} else if (r.kind === "sell" || r.kind === "trade_out" || r.kind === "fee") {
			const { out, short } = take(r.wallet_id, r.asset, r.qty, year);
			if (short) res.review.push({
				id: r.id,
				why: `Sold ${short.toFixed(8)} ${r.asset} more than this wallet had: bring in the earlier history`
			});
			if (r.kind === "fee") continue;
			const proceeds = r2((r.usd ?? 0) - r.fee_usd);
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			if (short) out.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: short,
				cost: 0,
				acquired: r.happened_at
			});
			for (const long of [false, true]) {
				const part = out.filter((l) => new Date(r.happened_at).getTime() - new Date(l.acquired).getTime() > YEAR_MS === long);
				if (!part.length) continue;
				const q = part.reduce((s, l) => s + l.qty, 0);
				const c = r2(part.reduce((s, l) => s + l.cost, 0));
				const p = r2(proceeds * (q / r.qty));
				const dates = part.map((l) => l.acquired).sort();
				res.sales.push({
					asset: r.asset,
					qty: q,
					acquired: dates[0],
					various: new Set(dates.map((d) => d.slice(0, 10))).size > 1,
					sold: r.happened_at,
					proceeds: p,
					cost: c,
					gain: r2(p - c),
					long,
					wallet: r.wallet_id
				});
			}
		} else if (r.kind === "send") {
			const rcv = pairOf.get(r.id);
			const { out } = take(r.wallet_id, r.asset, r.qty, year);
			if (rcv) {
				const ratio = rcv.qty / (out.reduce((s, l) => s + l.qty, 0) || 1);
				for (const l of out) lots.push({
					...l,
					wallet: rcv.wallet_id,
					qty: l.qty * Math.min(1, ratio),
					cost: l.cost
				});
			} else res.review.push({
				id: r.id,
				why: "Sent out with no matching receive: a gift, payment, or a wallet not brought in yet?"
			});
		} else if (r.kind === "receive") {
			if (!pairOf.has(r.id)) {
				res.review.push({
					id: r.id,
					why: "Received from outside: is it income, a gift, or from a wallet not brought in yet?"
				});
				lots.push({
					wallet: r.wallet_id,
					asset: r.asset,
					qty: r.qty,
					cost: r.usd ?? 0,
					acquired: r.happened_at
				});
			}
		}
	}
	const hold = /* @__PURE__ */ new Map();
	for (const l of lots) {
		if (l.qty <= 1e-10) continue;
		const k = `${l.wallet}|${l.asset}`;
		const h = hold.get(k) ?? {
			wallet: l.wallet,
			asset: l.asset,
			qty: 0,
			cost: 0
		};
		h.qty += l.qty;
		h.cost += l.cost;
		hold.set(k, h);
	}
	res.holdings = [...hold.values()].map((h) => ({
		...h,
		cost: r2(h.cost)
	})).sort((a, b) => b.cost - a.cost);
	return res;
}
/** Form 8949 rows for one year, as a CSV the CPA (or tax software) can read. */
function form8949(sales, year) {
	const d = (s) => {
		const x = new Date(s);
		return `${String(x.getUTCMonth() + 1).padStart(2, "0")}/${String(x.getUTCDate()).padStart(2, "0")}/${x.getUTCFullYear()}`;
	};
	return [[
		"(a) Description",
		"(b) Date acquired",
		"(c) Date sold",
		"(d) Proceeds",
		"(e) Cost basis",
		"(f) Code",
		"(g) Adjustment",
		"(h) Gain or loss",
		"Part"
	], ...sales.filter((s) => new Date(s.sold).getUTCFullYear() === year).map((s) => [
		`${Number(s.qty.toFixed(8))} ${s.asset}`,
		s.various ? "VARIOUS" : d(s.acquired),
		d(s.sold),
		s.proceeds.toFixed(2),
		s.cost.toFixed(2),
		"",
		"",
		s.gain.toFixed(2),
		s.long ? "Long term (Part II)" : "Short term (Part I)"
	])].map((r) => r.map((c) => /[",]/.test(c) ? `"${c.replace(/"/g, "\"\"")}"` : c).join(",")).join("\r\n");
}
var METHOD_LABEL = {
	fifo: "First in, first out (FIFO)",
	hifo: "Highest cost first (HIFO)",
	lifo: "Last in, first out (LIFO)"
};
var fmtDay = (s) => new Date(s).toLocaleDateString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric"
});
function CryptoTax() {
	const qc = useQueryClient();
	const [year, setYear] = (0, import_react.useState)((/* @__PURE__ */ new Date()).getFullYear());
	const data = useQuery({
		queryKey: ["crypto-tax"],
		queryFn: async () => {
			const [wallets, records, methods] = await Promise.all([
				fetchAll("tax_wallets", "id,name,source"),
				fetchAll("tax_records", "id,wallet_id,happened_at,kind,asset,qty,usd,fee_usd,note,source_id,needs_review"),
				fetchAll("tax_methods", "year,method")
			]);
			return {
				wallets,
				records: records.map((r) => ({
					...r,
					qty: Number(r.qty),
					usd: r.usd == null ? null : Number(r.usd),
					fee_usd: Number(r.fee_usd)
				})),
				methods: new Map(methods.map((m) => [m.year, m.method]))
			};
		}
	});
	const refresh = () => void qc.invalidateQueries({ queryKey: ["crypto-tax"] });
	const d = data.data;
	const res = (0, import_react.useMemo)(() => d ? work(d.records, (y) => d.methods.get(y) ?? "fifo") : null, [d]);
	if (data.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	if (data.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "rounded-2xl border bg-card p-6 text-sm text-destructive",
		children: [
			"Crypto Tax isn't ready yet: the database step 44 needs to run first. (",
			data.error.message,
			")"
		]
	}) });
	if (!d || !res) return null;
	const inYear = (s) => new Date(s).getUTCFullYear() === year;
	const sales = res.sales.filter((s) => inYear(s.sold));
	const short = sales.filter((s) => !s.long).reduce((t, s) => t + s.gain, 0);
	const long = sales.filter((s) => s.long).reduce((t, s) => t + s.gain, 0);
	const income = res.income.filter((i) => inYear(i.date));
	const incomeUsd = income.reduce((t, i) => t + i.usd, 0);
	const why = new Map(res.review.map((r) => [r.id, r.why]));
	const review = d.records.filter((r) => r.needs_review || why.has(r.id));
	const walletName = (id) => d.wallets.find((w) => w.id === id)?.name ?? "";
	const years = [.../* @__PURE__ */ new Set([(/* @__PURE__ */ new Date()).getFullYear(), ...d.records.map((r) => new Date(r.happened_at).getUTCFullYear())])].sort((a, b) => b - a);
	const method = d.methods.get(year) ?? "fifo";
	async function setMethod(m) {
		const { error } = await mtbl("tax_methods").upsert({
			year,
			method: m
		}, { onConflict: "company_id,year" });
		if (error) return void toast.error(error.message);
		refresh();
	}
	function download() {
		const blob = new Blob([form8949(res.sales, year)], { type: "text/csv" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `Form-8949-crypto-${year}.csv`;
		a.click();
		URL.revokeObjectURL(a.href);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Crypto Tax",
			text: "Bring in each exchange's history file. Tallkeep works out gains (short and long term) and crypto income for the tax return. It doesn't change your books.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					"aria-label": "Tax year",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: year,
					onChange: (e) => setYear(Number(e.target.value)),
					children: years.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: y,
						children: y
					}, y))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					"aria-label": "Matching method",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: method,
					onChange: (e) => void setMethod(e.target.value),
					children: Object.keys(METHOD_LABEL).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: m,
						children: METHOD_LABEL[m]
					}, m))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: `Short-term gain ${year}`,
					value: short
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: `Long-term gain ${year}`,
					value: long
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: `Crypto income ${year}`,
					value: incomeUsd
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "To look at"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("text-2xl font-semibold", review.length > 0 && "text-amber-600"),
						children: review.length
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BringIn, {
			wallets: d.wallets,
			onDone: refresh
		}),
		review.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Box, {
			title: `To look at (${review.length})`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pt-2 text-xs text-muted-foreground",
				children: "Say what each one was, or type its dollar value, then press the check. Moves between your own wallets match up by themselves once both wallets are brought in."
			}), review.slice(0, 50).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewRow, {
				r,
				why: why.get(r.id),
				wallet: walletName(r.wallet_id),
				onSaved: refresh
			}, r.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
			title: `Sales in ${year} (${sales.length})`,
			right: sales.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: download,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Form 8949 rows (CSV)"]
			}),
			children: sales.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [
				"No sales in ",
				year,
				"."
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 text-left font-normal",
									children: "What"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-normal",
									children: "Bought"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-normal",
									children: "Sold"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-normal",
									children: "Got"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-normal",
									children: "Cost"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-2 py-2 font-normal",
									children: "Gain"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-normal",
									children: "Term"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sales.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t text-right tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2 text-left",
								children: [
									Number(s.qty.toFixed(8)),
									" ",
									s.asset,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: walletName(s.wallet)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: s.various ? "Various" : fmtDay(s.acquired)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: fmtDay(s.sold)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: fmtMoney(s.proceeds)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: fmtMoney(s.cost)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: cn("px-2 py-2", s.gain < 0 ? "text-destructive" : "text-emerald-700"),
								children: fmtMoney(s.gain)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2",
								children: s.long ? "Long" : "Short"
							})
						]
					}, i)) })]
				})
			})
		}),
		income.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
			title: `Income in ${year}: ${fmtMoney(incomeUsd)}`,
			children: summarize(income).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between border-t px-4 py-2 text-sm first:border-t-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					x.asset,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							"· ",
							x.count,
							" payments"
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: fmtMoney(x.usd)
				})]
			}, x.asset))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
			title: "What you hold now (at what it cost)",
			children: res.holdings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nothing yet." }) : res.holdings.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between border-t px-4 py-2 text-sm first:border-t-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					Number(h.qty.toFixed(8)),
					" ",
					h.asset,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["· ", walletName(h.wallet)]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: fmtMoney(h.cost)
				})]
			}, `${h.wallet}${h.asset}`))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Lots are kept per wallet, as the IRS asks from 2025 on. This is a worksheet for you and your tax preparer, not tax advice."
		})
	] });
}
function summarize(list) {
	const m = /* @__PURE__ */ new Map();
	for (const i of list) {
		const x = m.get(i.asset) ?? {
			asset: i.asset,
			usd: 0,
			count: 0
		};
		x.usd += i.usd;
		x.count++;
		m.set(i.asset, x);
	}
	return [...m.values()].sort((a, b) => b.usd - a.usd);
}
function BringIn({ wallets, onDone }) {
	const [wallet, setWallet] = (0, import_react.useState)(wallets[0]?.id ?? "new");
	const [newName, setNewName] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		if (!file) return;
		setBusy(true);
		try {
			let id = wallet;
			if (wallet === "new") {
				const name = newName.trim() || (file.source === "coinbase" ? "Coinbase" : file.source === "kraken" ? "Kraken" : "");
				if (!name) throw new Error("Type a name for the wallet, like Ledger or Gemini.");
				const { data, error } = await mtbl("tax_wallets").insert({
					name,
					source: file.source
				}).select("id").single();
				if (error) throw new Error(error.message);
				id = data.id;
			}
			const have = new Set((await fetchAll("tax_records", "wallet_id,source_id")).filter((r) => r.wallet_id === id).map((r) => r.source_id));
			const rows = file.records.filter((r) => !have.has(r.source_id)).map((r) => ({
				...r,
				wallet_id: id
			}));
			for (let i = 0; i < rows.length; i += 500) {
				const { error } = await mtbl("tax_records").insert(rows.slice(i, i + 500));
				if (error) throw new Error(error.message);
			}
			toast.success(`Added ${rows.length} records${file.records.length - rows.length ? ` (${file.records.length - rows.length} were already here)` : ""}.`);
			setFile(null);
			setWallet(id);
			onDone();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "Bring in a history file"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "list-disc space-y-1 pl-5 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Coinbase: Profile → Statements → Transaction history → CSV." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Kraken: History → Export → Trades → CSV." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Any other exchange or wallet: a CSV with Date, Type, Asset, Quantity and USD columns." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Wallet",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: wallet,
					onChange: (e) => setWallet(e.target.value),
					children: [wallets.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: w.id,
						children: w.name
					}, w.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "new",
						children: "A new wallet or exchange…"
					})]
				}), wallet === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "w-56",
					placeholder: "Name (Coinbase, Ledger…)",
					value: newName,
					onChange: (e) => setNewName(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the history .CSV file",
				onText: (t) => {
					const h = readHistory(parseCsv(t));
					if (!h || !h.records.length) return void toast.error("This doesn't look like a Coinbase, Kraken or Date/Type/Asset history file.");
					setFile(h);
				}
			}),
			file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					file.records.length,
					" records from",
					" ",
					file.source === "other" ? "the file" : file.source[0].toUpperCase() + file.source.slice(1),
					file.records.filter((r) => r.needs_review).length > 0 && ` · ${file.records.filter((r) => r.needs_review).length} to look at`
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), "Bring them in"]
				})]
			})
		]
	});
}
function ReviewRow({ r, why, wallet, onSaved }) {
	const [kind, setKind] = (0, import_react.useState)(r.kind);
	const [usd, setUsd] = (0, import_react.useState)(r.usd == null ? "" : String(r.usd));
	async function save() {
		const v = usd.replace(/[$,\s]/g, "");
		const { error } = await mtbl("tax_records").update({
			kind,
			usd: v === "" ? null : Number(v),
			needs_review: false
		}).eq("id", r.id);
		if (error) return void toast.error(error.message);
		onSaved();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-2 border-t px-4 py-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium",
					children: [
						fmtDay(r.happened_at),
						" · ",
						Number(r.qty.toFixed(8)),
						" ",
						r.asset
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: [
						wallet,
						r.note,
						why
					].filter(Boolean).join(" · ")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				"aria-label": "What was it",
				className: "h-8 rounded-md border bg-background px-2 text-sm",
				value: kind,
				onChange: (e) => setKind(e.target.value),
				children: Object.keys(KIND_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: k,
					children: KIND_LABEL[k]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				"aria-label": "Dollar value",
				className: "h-8 w-28",
				placeholder: "$ value",
				value: usd,
				onChange: (e) => setUsd(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "outline",
				"aria-label": "Looks right",
				onClick: () => void save(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
			})
		]
	});
}
function Tile({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-2xl font-semibold tabular-nums", value < 0 && "text-destructive"),
			children: fmtMoney(value)
		})]
	});
}
function Box({ title, right, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center justify-between gap-2 border-b bg-muted/40 px-4 py-2 font-semibold",
			children: [title, right]
		}), children]
	});
}
var Empty = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	className: "px-4 py-6 text-center text-sm text-muted-foreground",
	children
});
//#endregion
export { CryptoTax as component };
