import { a as num, o as parseCsv } from "./quickbooks-DDZqKZVM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bankfile-C7N990Vr.js
/** "20270115120000[-5:EST]" → "2027-01-15" */
var ofxDate = (v) => `${v.slice(0, 4)}-${v.slice(4, 6)}-${v.slice(6, 8)}`;
/** OFX / QFX (Quicken / Web Connect) files: every <STMTTRN> block is one line. */
function parseOfx(text) {
	const out = [];
	const blocks = text.split(/<STMTTRN>/i).slice(1);
	for (const raw of blocks) {
		const b = raw.split(/<\/STMTTRN>/i)[0] ?? raw;
		const tag = (t) => new RegExp(`<${t}>([^<\\r\\n]*)`, "i").exec(b)?.[1]?.trim() ?? "";
		const date = tag("DTPOSTED");
		const amount = Number(tag("TRNAMT"));
		if (!date || !Number.isFinite(amount)) continue;
		const name = tag("NAME");
		const memo = tag("MEMO");
		const d = ofxDate(date);
		out.push({
			txn_date: d,
			amount,
			description: [name, memo].filter(Boolean).join(" · ") || "Bank line",
			ref: tag("CHECKNUM") || null,
			fit_id: tag("FITID") || `${d}|${amount}|${name}|${memo}`
		});
	}
	return out;
}
/** "01/15/2027", "2027-01-15", "1/5/27" → "2027-01-15" */
function anyDate(v) {
	let m = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(v);
	if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
	m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/.exec(v);
	if (m) return `${m[3].length === 2 ? `20${m[3]}` : m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
	return null;
}
/**
* CSV statements. Finds the date, description and either one Amount column or separate
* money-out / money-in columns, whatever the bank calls them.
*/
function parseBankCsv(text, flip = false) {
	const rows = parseCsv(text).filter((r) => r.some((c) => c));
	const lc = (s) => s.toLowerCase().trim();
	const hi = rows.findIndex((r) => r.some((c) => /date/i.test(c)));
	if (hi < 0) return "Couldn't find a Date column in this file.";
	const head = rows[hi].map(lc);
	const find = (...names) => head.findIndex((h) => names.some((n) => h === n || h.includes(n)));
	const cDate = find("posting date", "transaction date", "post date", "date");
	const cDesc = find("description", "payee", "name", "memo", "details");
	const cMemo = head.findIndex((h, i) => i !== cDesc && (h.includes("memo") || h.includes("note")));
	const cAmt = head.findIndex((h) => h === "amount" || h.includes("amount"));
	const cOut = find("debit", "withdrawal", "money out", "payments");
	const cIn = find("credit", "deposit", "money in");
	const cRef = find("check", "reference", "ref");
	if (cAmt < 0 && cOut < 0 && cIn < 0) return "Couldn't find an Amount (or Debit/Credit) column.";
	const out = [];
	const seen = /* @__PURE__ */ new Map();
	for (const r of rows.slice(hi + 1)) {
		const d = anyDate(r[cDate] ?? "");
		if (!d) continue;
		let amount;
		if (cAmt >= 0 && !(cOut >= 0 && cIn >= 0)) amount = num(r[cAmt]);
		else {
			const o = num(r[cOut]);
			const i = num(r[cIn]);
			amount = (Number.isFinite(i) ? Math.abs(i) : 0) - (Number.isFinite(o) ? Math.abs(o) : 0);
		}
		if (!Number.isFinite(amount) || amount === 0) continue;
		if (flip) amount = -amount;
		const desc = [r[cDesc] ?? "", cMemo >= 0 ? r[cMemo] ?? "" : ""].filter(Boolean).join(" · ");
		const base = `${d}|${amount.toFixed(2)}|${desc}`;
		const n = (seen.get(base) ?? 0) + 1;
		seen.set(base, n);
		out.push({
			txn_date: d,
			amount: Math.round(amount * 100) / 100,
			description: desc || "Bank line",
			ref: cRef >= 0 ? r[cRef] || null : null,
			fit_id: `${base}|${n}`
		});
	}
	return out;
}
/** Bank noise around the payee name: card words, dates, long numbers, card endings. */
var NOISE = /\b(pos|debit|credit|card|checkcard|check card|purchase|authorized|on|recurring|payment|to|from|ach|web|ppd|ccd|withdrawal|deposit|online|transfer|visa|mastercard|ref|id|trn|des|indn|co|xx+\d*)\b/gi;
/** The payee part of a bank description, used to remember an account for it.
*  "POS PURCHASE 10/12 HOME DEPOT #4521 CHICAGO IL" → "HOME DEPOT" */
function cleanDesc(desc) {
	return (desc ?? "").replace(/\d{1,2}\/\d{1,2}(\/\d{2,4})?/g, " ").replace(/[#*]\s*\w+/g, " ").replace(/\b\w*\d{3,}\w*\b/g, " ").replace(NOISE, " ").replace(/[^A-Za-z0-9&' .-]/g, " ").replace(/\s+/g, " ").trim().split(" ").filter((w) => w.length > 1 || w === "&").join(" ").toUpperCase();
}
function payeeKey(desc) {
	return cleanDesc(desc).split(" ").filter(Boolean).slice(0, 2).join(" ") || (desc ?? "").slice(0, 20).toUpperCase();
}
/** The most specific remembered rule whose text is in the description. */
function ruleFor(rules, desc) {
	const d = (desc ?? "").toLowerCase().replace(/\s+/g, " ");
	const c = cleanDesc(desc).toLowerCase();
	const has = (k) => d.includes(k) || c.includes(k);
	return rules.filter((r) => r.contains.trim() && has(r.contains.toLowerCase().trim())).sort((a, b) => b.contains.length - a.contains.length)[0] ?? null;
}
//#endregion
export { ruleFor as a, payeeKey as i, parseBankCsv as n, parseOfx as r, anyDate as t };
