//#region ../../node_modules/.nitro/vite/services/ssr/assets/format-CORJO1ov.js
var money = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD"
});
var qtyFmt = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });
var fmtMoney = (n) => money.format(Math.round(Number(n ?? 0) * 100) / 100 + 0);
var fmtQty = (n) => qtyFmt.format(Number(n ?? 0));
var fmtDate = (s) => s ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}T12:00:00` : s).toLocaleDateString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric"
}) : "";
var fmtDateTime = (s) => s ? new Date(s).toLocaleString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric",
	hour: "numeric",
	minute: "2-digit"
}) : "";
//#endregion
export { fmtQty as i, fmtDateTime as n, fmtMoney as r, fmtDate as t };
