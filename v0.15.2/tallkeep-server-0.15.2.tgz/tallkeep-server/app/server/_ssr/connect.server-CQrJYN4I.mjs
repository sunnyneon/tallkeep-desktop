//#region ../../node_modules/.nitro/vite/services/ssr/assets/connect.server-CQrJYN4I.js
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
/** Paid up (or Stripe still trying a failed card for a few days). */
var isActive = (s) => s === "active" || s === "trialing" || s === "past_due";
/** A license from its key (it must carry our signature, and be on). */
async function licenseFromKey(key) {
	const { keyId } = await import("./license.server-DmRH5APk.mjs");
	const id = await keyId(String(key ?? "").replace(/\s+/g, ""));
	if (!id) return null;
	const { data } = await (await admin()).from("desktop_licenses").select("*").eq("id", id).maybeSingle();
	return data && !data.revoked ? data : null;
}
async function cf(path, method = "GET", body) {
	const token = process.env["CLOUDFLARE_API_TOKEN"];
	if (!token) throw new Error("Tallkeep Connect isn't set up yet (Cloudflare).");
	const base = process.env["CLOUDFLARE_API_BASE"] || "https://api.cloudflare.com/client/v4";
	const res = await fetch(`${base}${path}`, {
		method,
		headers: {
			Authorization: `Bearer ${token}`,
			"Content-Type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await res.json().catch(() => ({}));
	if (!res.ok || out.success === false) throw new Error(`Cloudflare: ${out.errors?.[0]?.message ?? res.status}`);
	return out.result;
}
var slug = (name) => name.toLowerCase().replace(/\b(inc|llc|ltd|corp|co)\b\.?/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30) || "office";
/** Make the office computer's tunnel and web address (once). Returns the row with them. */
async function provision(row, businessName) {
	if (row.tunnel_id && row.tunnel_token && row.hostname) return row;
	const acct = process.env["CLOUDFLARE_ACCOUNT_ID"];
	const zone = process.env["CLOUDFLARE_ZONE_ID"];
	const domain = process.env["CONNECT_DOMAIN"];
	if (!acct || !zone || !domain) throw new Error("Tallkeep Connect isn't set up yet (Cloudflare).");
	const db = await admin();
	let next = { ...row };
	if (!next.hostname) {
		const rand = Buffer.from(crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(3))).toString("hex");
		next.hostname = `${slug(businessName)}-${rand}.${domain}`;
	}
	if (!next.tunnel_id) next.tunnel_id = (await cf(`/accounts/${acct}/cfd_tunnel`, "POST", {
		name: `tallkeep-${row.license_id}`,
		config_src: "cloudflare"
	})).id;
	await cf(`/accounts/${acct}/cfd_tunnel/${next.tunnel_id}/configurations`, "PUT", { config: { ingress: [{
		hostname: next.hostname,
		service: "http://localhost:4600"
	}, { service: "http_status:404" }] } });
	await cf(`/zones/${zone}/dns_records`, "POST", {
		type: "CNAME",
		name: next.hostname,
		content: `${next.tunnel_id}.cfargotunnel.com`,
		proxied: true
	}).catch((e) => {
		if (!/already exists/i.test(e.message)) throw e;
	});
	next.tunnel_token = await cf(`/accounts/${acct}/cfd_tunnel/${next.tunnel_id}/token`);
	await db.from("connect_subscriptions").update({
		hostname: next.hostname,
		tunnel_id: next.tunnel_id,
		tunnel_token: next.tunnel_token,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", row.id);
	return next;
}
/** Bring a license's subscription up to date from Stripe itself (never from a message's body). */
async function syncSubscription(subscriptionId) {
	const { stripe } = await import("./pay.server-ZAvSX03A.mjs");
	const sub = await stripe(`subscriptions/${encodeURIComponent(subscriptionId)}`);
	const license = sub.metadata?.["license"];
	if (!license || sub.metadata?.["product"] !== "tallkeep_connect") return null;
	const end = sub.current_period_end ?? sub.items?.data?.[0]?.current_period_end ?? null;
	const db = await admin();
	const { data: before } = await db.from("connect_subscriptions").select("status,hostname").eq("license_id", license).maybeSingle();
	const row = {
		license_id: license,
		stripe_customer: sub.customer,
		stripe_subscription: sub.id,
		status: sub.status,
		current_period_end: end ? (/* @__PURE__ */ new Date(end * 1e3)).toISOString() : null,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	};
	const { data } = await db.from("connect_subscriptions").upsert(row, { onConflict: "license_id" }).select("*").single();
	const was = isActive(before?.status);
	const now = isActive(sub.status);
	if (was !== now) await mailConnect(license, now, before?.hostname ?? null);
	return data;
}
var RESERVED = /* @__PURE__ */ new Set([
	"www",
	"app",
	"api",
	"admin",
	"mail",
	"email",
	"smtp",
	"connect",
	"tallkeep",
	"help",
	"support",
	"status",
	"docs",
	"blog",
	"login",
	"signin",
	"account",
	"billing",
	"pay",
	"secure",
	"ftp",
	"ns1",
	"ns2",
	"office",
	"demo",
	"test",
	"testing",
	"tests",
	"sample",
	"example",
	"dev",
	"staging",
	"stage",
	"beta",
	"preview",
	"sandbox",
	"prod",
	"production",
	"root",
	"system",
	"server",
	"host",
	"localhost",
	"owner",
	"manager",
	"user",
	"users",
	"team",
	"my",
	"home",
	"web",
	"site",
	"portal",
	"dashboard",
	"store",
	"shop",
	"sales",
	"info",
	"contact",
	"hello",
	"official",
	"security",
	"abuse",
	"postmaster",
	"webmaster",
	"hostmaster",
	"noreply",
	"no-reply",
	"cdn",
	"static",
	"assets",
	"files",
	"download",
	"downloads",
	"update",
	"updates",
	"backup",
	"backups",
	"cloud",
	"mobile",
	"phone",
	"books",
	"invoice",
	"invoices",
	"quickbooks",
	"inflow",
	"signup",
	"register",
	"buy",
	"upgrade",
	"license",
	"licenses"
]);
/** Check a short name for a Connect address ("sunriseled" → sunriseled.tallkeep.app). */
function cleanName(name) {
	const n = String(name ?? "").trim().toLowerCase().replace(/\.tallkeep\.app$/, "").replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "");
	if (n.length < 3 || n.length > 40) throw new Error("Use 3 to 40 letters, numbers or dashes.");
	if (RESERVED.has(n)) throw new Error("That name is kept for Tallkeep. Try another.");
	return n;
}
/** Move a license's Connect address to a new name. The old address stops working. */
async function rename(row, name) {
	const acct = process.env["CLOUDFLARE_ACCOUNT_ID"];
	const zone = process.env["CLOUDFLARE_ZONE_ID"];
	const domain = process.env["CONNECT_DOMAIN"];
	if (!acct || !zone || !domain || !row.tunnel_id) throw new Error("Tallkeep Connect isn't ready yet. Try again in a minute.");
	const host = `${cleanName(name)}.${domain}`;
	if (host === row.hostname) return row;
	const db = await admin();
	const { data: taken } = await db.from("connect_subscriptions").select("id").eq("hostname", host).maybeSingle();
	if (taken) throw new Error("Someone already has that address. Try another.");
	await cf(`/zones/${zone}/dns_records`, "POST", {
		type: "CNAME",
		name: host,
		content: `${row.tunnel_id}.cfargotunnel.com`,
		proxied: true
	}).catch((e) => {
		if (/already exists/i.test(e.message)) throw new Error("That address is taken. Try another.");
		throw e;
	});
	await cf(`/accounts/${acct}/cfd_tunnel/${row.tunnel_id}/configurations`, "PUT", { config: { ingress: [{
		hostname: host,
		service: "http://localhost:4600"
	}, { service: "http_status:404" }] } });
	const { error } = await db.from("connect_subscriptions").update({
		hostname: host,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", row.id);
	if (error) throw new Error(error.message);
	if (row.hostname) {
		const old = await cf(`/zones/${zone}/dns_records?type=CNAME&name=${encodeURIComponent(row.hostname)}`).catch(() => []);
		for (const r of Array.isArray(old) ? old : []) await cf(`/zones/${zone}/dns_records/${r.id}`, "DELETE").catch(() => null);
	}
	return {
		...row,
		hostname: host
	};
}
async function mailConnect(licenseId, started, hostname) {
	const { data: lic } = await (await admin()).from("desktop_licenses").select("id,to_name,email").eq("id", licenseId).maybeSingle();
	if (!lic?.email) return;
	const { sendTallkeepMail } = await import("./license.server-DmRH5APk.mjs");
	const text = started ? [
		`Thank you, ${lic.to_name}. Tallkeep Connect is on.`,
		"",
		"Your office computer now has its own secure web address, so you can use Tallkeep from phones, from home and anywhere else.",
		"",
		"Find your address in Tallkeep: Settings → Plan & computer → Tallkeep Connect. You can change it to a short name there.",
		"On a phone: open the address, sign in, then Share → Add to Home Screen (iPhone) or ⋮ → Install app (Android).",
		"",
		"Keep the office computer on, with Tallkeep open.",
		"To change your card or cancel: Settings → Plan & computer → Change card or cancel.",
		"",
		`License number: ${lic.id}`,
		"",
		"Questions? Just reply to this email.",
		"",
		"Tallkeep"
	] : [
		`Hello ${lic.to_name},`,
		"",
		`Tallkeep Connect has ended${hostname ? `, so https://${hostname} no longer opens Tallkeep` : ""}.`,
		"Tallkeep keeps working on your office computer and office network as before.",
		"",
		"To turn Connect back on: Settings → Plan & computer → Turn on Tallkeep Connect.",
		"",
		`License number: ${lic.id}`,
		"",
		"Tallkeep"
	];
	const r = await sendTallkeepMail({
		to: lic.email,
		subject: started ? "Tallkeep Connect is on" : "Tallkeep Connect has ended",
		text: text.join("\n")
	});
	if (!r.ok) console.error("[connect mail]", r.why);
}
//#endregion
export { admin, isActive, licenseFromKey, provision, rename, syncSubscription };
