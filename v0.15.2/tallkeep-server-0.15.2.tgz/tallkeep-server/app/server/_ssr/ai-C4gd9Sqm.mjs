//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai-C4gd9Sqm.js
var AI_PROVIDERS = {
	vooska: {
		label: "Built-in AI (included)",
		url: "https://ai.gateway.lovable.dev/v1/chat/completions",
		model: "google/gemini-3.7-flash",
		keyHelp: ""
	},
	openai: {
		label: "My own OpenAI account",
		url: "https://api.openai.com/v1/chat/completions",
		model: "gpt-5-mini",
		keyHelp: "platform.openai.com → API keys"
	},
	google: {
		label: "My own Google Gemini account",
		url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
		model: "gemini-2.5-flash",
		keyHelp: "aistudio.google.com → Get API key"
	},
	anthropic: {
		label: "My own Anthropic (Claude) account",
		url: "https://api.anthropic.com/v1/chat/completions",
		model: "claude-haiku-4-5",
		keyHelp: "console.anthropic.com → API keys"
	}
};
/** Turn a PDF or a photo into page images the AI can read (JPEG data URLs). */
async function fileToPages(file, maxPages = 12) {
	if (file.type === "application/pdf" || /\.pdf$/i.test(file.name)) return pdfToPages(file, maxPages);
	if (!file.type.startsWith("image/")) throw new Error("Use a PDF or a photo.");
	return [await imageToJpeg(file, 1800)];
}
async function imageToJpeg(file, max) {
	const bmp = await createImageBitmap(file);
	const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
	const c = document.createElement("canvas");
	c.width = Math.round(bmp.width * scale);
	c.height = Math.round(bmp.height * scale);
	const ctx = c.getContext("2d");
	ctx.drawImage(bmp, 0, 0, c.width, c.height);
	clarify(ctx, c.width, c.height);
	return c.toDataURL("image/jpeg", .85);
}
async function pdfToPages(file, maxPages) {
	const pdfjs = await import("../_libs/pdfjs-dist.mjs").then((n) => n.t);
	pdfjs.GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();
	const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
	if (doc.numPages > maxPages) throw new Error(`This PDF has ${doc.numPages} pages. ${maxPages} at most, please.`);
	const out = [];
	for (let i = 1; i <= doc.numPages; i++) {
		const page = await doc.getPage(i);
		const base = page.getViewport({ scale: 1 });
		const scale = Math.min(2, 1600 / Math.max(base.width, base.height));
		const vp = page.getViewport({ scale });
		const c = document.createElement("canvas");
		c.width = Math.round(vp.width);
		c.height = Math.round(vp.height);
		const ctx = c.getContext("2d");
		ctx.fillStyle = "#fff";
		ctx.fillRect(0, 0, c.width, c.height);
		await page.render({
			canvas: c,
			canvasContext: ctx,
			viewport: vp
		}).promise;
		out.push(c.toDataURL("image/jpeg", .8));
	}
	return out;
}
/** A small preview-size copy of a photo for storing (receipts). */
async function shrinkForStorage(file) {
	if (!file.type.startsWith("image/")) return file;
	const url = await imageToJpeg(file, 1800);
	return await (await fetch(url)).blob();
}
/** Make a photo of paper easier to read: stretch the darkest 1% to black and the lightest 1% to
*  white, so faded receipt print stands out. Colors keep their balance. */
function clarify(ctx, w, h) {
	try {
		const img = ctx.getImageData(0, 0, w, h);
		const d = img.data;
		const hist = /* @__PURE__ */ new Uint32Array(256);
		for (let i = 0; i < d.length; i += 4) hist[Math.round(.299 * d[i] + .587 * d[i + 1] + .114 * d[i + 2])]++;
		const total = d.length / 4;
		let lo = 0;
		let hi = 255;
		for (let s = 0; lo < 255 && (s += hist[lo]) < total * .01; lo++);
		for (let s = 0; hi > 0 && (s += hist[hi]) < total * .01; hi--);
		if (hi - lo < 40 || lo < 8 && hi > 247) return;
		const k = 255 / (hi - lo);
		for (let i = 0; i < d.length; i += 4) for (let j = 0; j < 3; j++) d[i + j] = Math.max(0, Math.min(255, (d[i + j] - lo) * k));
		ctx.putImageData(img, 0, 0);
	} catch {}
}
//#endregion
export { fileToPages as n, shrinkForStorage as r, AI_PROVIDERS as t };
