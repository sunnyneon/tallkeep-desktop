import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/admin.functions-CrE1BFt9.js
/** The control panel is for admins of our own group (the Tallkeep owners) only. */
async function requireOwner(userId) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
	const { data: m } = await supabaseAdmin.from("org_members").select("orgs(is_platform)").eq("user_id", userId).maybeSingle();
	if (!data || !m?.orgs?.is_platform) throw new Error("Only Tallkeep owners can open the admin panel.");
	return supabaseAdmin;
}
var listAccounts_createServerFn_handler = createServerRpc({
	id: "8c56746723b59acb7fff2062af8cf1b67256fe267c1b064d2d55aadbe60477ad",
	name: "listAccounts",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listAccounts.__executeServer(opts));
var listAccounts = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listAccounts_createServerFn_handler, async ({ context }) => {
	const admin = await requireOwner(context.userId);
	const loose = admin;
	const [orgs, companies, members, users, ai] = await Promise.all([
		loose.from("orgs").select("*").order("created_at", { ascending: false }),
		loose.from("companies").select("id,org_id"),
		loose.from("org_members").select("org_id,user_id"),
		admin.auth.admin.listUsers({
			page: 1,
			perPage: 1e3
		}),
		loose.from("ai_usage").select("company_id,pages,cost_usd").gte("created_at", new Date((/* @__PURE__ */ new Date()).setDate(1)).toISOString().slice(0, 10))
	]);
	if (orgs.error) throw new Error(orgs.error.message);
	const orgOfCompany = /* @__PURE__ */ new Map();
	const companyCount = /* @__PURE__ */ new Map();
	for (const c of companies.data ?? []) {
		orgOfCompany.set(c.id, c.org_id);
		companyCount.set(c.org_id, (companyCount.get(c.org_id) ?? 0) + 1);
	}
	const peopleOf = /* @__PURE__ */ new Map();
	for (const m of members.data ?? []) peopleOf.set(m.org_id, [...peopleOf.get(m.org_id) ?? [], m.user_id]);
	const userById = new Map((users.data?.users ?? []).map((u) => [u.id, u]));
	const aiCost = /* @__PURE__ */ new Map();
	for (const r of ai.data ?? []) {
		const o = orgOfCompany.get(r.company_id);
		if (!o) continue;
		const t = aiCost.get(o) ?? {
			cost: 0,
			pages: 0
		};
		aiCost.set(o, {
			cost: t.cost + Number(r.cost_usd),
			pages: t.pages + Number(r.pages)
		});
	}
	return (orgs.data ?? []).map((o) => {
		const id = String(o["id"]);
		const ids = peopleOf.get(id) ?? [];
		const owner = userById.get(String(o["created_by"] ?? "")) ?? userById.get(ids[0] ?? "");
		const last = ids.map((u) => userById.get(u)?.last_sign_in_at ?? "").filter(Boolean).sort().at(-1);
		return {
			id,
			name: String(o["name"]),
			status: o["status"],
			edition: o["edition"] ?? "cloud",
			trial_ends_at: o["trial_ends_at"] ?? null,
			created_at: String(o["created_at"]),
			is_platform: Boolean(o["is_platform"]),
			companies_allowed: o["companies_allowed"] ?? null,
			users_allowed: o["users_allowed"] ?? null,
			companies: companyCount.get(id) ?? 0,
			people: ids.length,
			owner_email: owner?.email ?? "",
			last_sign_in: last ?? null,
			ai_cost_month: aiCost.get(id)?.cost ?? 0,
			ai_pages_month: aiCost.get(id)?.pages ?? 0
		};
	});
});
var changeAccount_createServerFn_handler = createServerRpc({
	id: "9423a679c9df2f139cb12313a6efb5e9668960218a0e540c16ac757a25d12b4a",
	name: "changeAccount",
	filename: "src/lib/admin.functions.ts"
}, (opts) => changeAccount.__executeServer(opts));
var changeAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const bad = (n) => n != null && (!Number.isInteger(n) || n < 1 || n > 1e3);
	if (bad(d.companies_allowed) || bad(d.users_allowed)) throw new Error("Type a whole number from 1 to 1000, or leave it empty for no limit.");
	if (d.status && ![
		"trial",
		"active",
		"past_due",
		"canceled"
	].includes(d.status)) throw new Error("Pick a status.");
	if (d.edition && !["cloud", "desktop"].includes(d.edition)) throw new Error("Pick a version.");
	return d;
}).handler(changeAccount_createServerFn_handler, async ({ data, context }) => {
	const loose = await requireOwner(context.userId);
	const { data: o } = await loose.from("orgs").select("is_platform").eq("id", data.id).maybeSingle();
	if (!o) throw new Error("That account is gone.");
	if (o.is_platform) throw new Error("Our own account can't be changed here.");
	const patch = {};
	for (const k of [
		"status",
		"edition",
		"trial_ends_at",
		"companies_allowed",
		"users_allowed"
	]) if (k in data) patch[k] = data[k];
	const { error } = await loose.from("orgs").update(patch).eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var amIOwner_createServerFn_handler = createServerRpc({
	id: "52ae71e6cfacb229eefce10e007b4d0a433e4dce525a87615321e3d6b52ab56c",
	name: "amIOwner",
	filename: "src/lib/admin.functions.ts"
}, (opts) => amIOwner.__executeServer(opts));
var amIOwner = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(amIOwner_createServerFn_handler, async ({ context }) => {
	try {
		await requireOwner(context.userId);
		return true;
	} catch {
		return false;
	}
});
var accountDetail_createServerFn_handler = createServerRpc({
	id: "5a54f5d01d810c6d5e874565da0aeb5aadeade5c8114b4385004d9622e252c91",
	name: "accountDetail",
	filename: "src/lib/admin.functions.ts"
}, (opts) => accountDetail.__executeServer(opts));
var accountDetail = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(accountDetail_createServerFn_handler, async ({ data, context }) => {
	const admin = await requireOwner(context.userId);
	const loose = admin;
	const [companies, members] = await Promise.all([loose.from("companies").select("id,name,created_at").eq("org_id", data.id).order("name"), loose.from("org_members").select("user_id").eq("org_id", data.id)]);
	const ids = (members.data ?? []).map((m) => m.user_id);
	const companyIds = (companies.data ?? []).map((c) => c.id);
	const [roles, users, ai] = await Promise.all([
		ids.length ? loose.from("user_roles").select("user_id,role").in("user_id", ids) : Promise.resolve({ data: [] }),
		admin.auth.admin.listUsers({
			page: 1,
			perPage: 1e3
		}),
		companyIds.length ? loose.from("ai_usage").select("feature,pages,cost_usd").in("company_id", companyIds).gte("created_at", new Date((/* @__PURE__ */ new Date()).setDate(1)).toISOString().slice(0, 10)) : Promise.resolve({ data: [] })
	]);
	const roleOf = /* @__PURE__ */ new Map();
	for (const r of roles.data ?? []) if (r.role === "admin" || !roleOf.has(r.user_id)) roleOf.set(r.user_id, r.role);
	const byFeature = /* @__PURE__ */ new Map();
	for (const r of ai.data ?? []) {
		const t = byFeature.get(r.feature) ?? {
			pages: 0,
			cost: 0
		};
		byFeature.set(r.feature, {
			pages: t.pages + Number(r.pages),
			cost: t.cost + Number(r.cost_usd)
		});
	}
	return {
		companies: companies.data ?? [],
		people: (users.data?.users ?? []).filter((u) => ids.includes(u.id)).map((u) => ({
			id: u.id,
			email: u.email ?? "",
			name: String(u.user_metadata?.["name"] ?? ""),
			role: roleOf.get(u.id) ?? "none",
			last_sign_in: u.last_sign_in_at ?? null,
			created_at: u.created_at
		})).sort((a, b) => a.email.localeCompare(b.email)),
		ai: [...byFeature.entries()].map(([feature, v]) => ({
			feature,
			...v
		}))
	};
});
async function readPrices() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("platform_settings").select("value,updated_at").eq("key", "prices").maybeSingle();
	const row = data;
	return row ? {
		prices: row.value,
		updated_at: row.updated_at
	} : null;
}
var getPrices_createServerFn_handler = createServerRpc({
	id: "ca683ec40b811885e1486d71d87808c320b5bf90f0646637e04e8cfcb4f839b5",
	name: "getPrices",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getPrices.__executeServer(opts));
var getPrices = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getPrices_createServerFn_handler, async ({ context }) => {
	await requireOwner(context.userId);
	return readPrices();
});
var savePrices_createServerFn_handler = createServerRpc({
	id: "34f565de0ecb973594612848b517ea391eeac0fb71632eadf4ed88a61b35e07a",
	name: "savePrices",
	filename: "src/lib/admin.functions.ts"
}, (opts) => savePrices.__executeServer(opts));
var savePrices = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const walk = (o) => typeof o === "number" ? Number.isFinite(o) && o >= 0 && o <= 1e5 : typeof o === "object" && o !== null && Object.values(o).every(walk);
	if (!walk(d)) throw new Error("Every price must be a number from 0 to 100,000.");
	if (d.trial_days < 1 || d.trial_days > 365) throw new Error("The free trial must be 1 to 365 days.");
	return d;
}).handler(savePrices_createServerFn_handler, async ({ data, context }) => {
	const { error } = await (await requireOwner(context.userId)).from("platform_settings").upsert({
		key: "prices",
		value: data,
		updated_at: (/* @__PURE__ */ new Date()).toISOString(),
		updated_by: context.userId
	});
	if (error) throw new Error(error.message);
	return { ok: true };
});
var listWaitlist_createServerFn_handler = createServerRpc({
	id: "a2d9697780227560abcb1156f5bdea1ac030d03848cf0ea525e850d95e904a84",
	name: "listWaitlist",
	filename: "src/lib/admin.functions.ts"
}, (opts) => listWaitlist.__executeServer(opts));
var listWaitlist = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listWaitlist_createServerFn_handler, async ({ context }) => {
	await requireOwner(context.userId);
	const key = process.env["TALLKEEP_SITE_KEY"];
	if (!key) return {
		ready: false,
		entries: []
	};
	try {
		const res = await fetch("https://tallkeep.com/api/admin/waitlist", { headers: { "x-admin-key": key } });
		if (!res.ok) return {
			ready: true,
			entries: [],
			problem: `The website said ${res.status}.`
		};
		return {
			ready: true,
			entries: (await res.json()).entries ?? []
		};
	} catch (e) {
		return {
			ready: true,
			entries: [],
			problem: e.message
		};
	}
});
//#endregion
export { accountDetail_createServerFn_handler, amIOwner_createServerFn_handler, changeAccount_createServerFn_handler, getPrices_createServerFn_handler, listAccounts_createServerFn_handler, listWaitlist_createServerFn_handler, savePrices_createServerFn_handler };
