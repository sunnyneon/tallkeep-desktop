import { supabaseAdmin } from "./client.server-KzwUIAkW.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/support.server-Bv8yioBw.js
/**
* Support Desk on the server: the support page (no sign-in, so it uses the service role and
* checks everything itself), files and email.
*/
var admin = supabaseAdmin;
var BUCKET = "ticket-files";
var COLS = "company_id,name,email,email_from_name,email_reply_to,support_slug,support_intro,support_topics,support_notify_email,addons";
/** The company whose support page this is (only when Support Desk is on). */
async function companyForSlug(slug) {
	const s = String(slug ?? "").trim().toLowerCase();
	if (!/^[a-z0-9-]{2,60}$/.test(s)) return null;
	const { data } = await admin.from("company_settings").select(COLS).ilike("support_slug", s).maybeSingle();
	const co = data;
	return co && (co.addons ?? []).includes("support") ? co : null;
}
async function companyById(id) {
	const { data } = await admin.from("company_settings").select(COLS).eq("company_id", id).maybeSingle();
	return data ?? null;
}
/** Send an email through Resend. No email set up (like on an office computer): returns false. */
async function sendMail(opts) {
	return (await sendMailWhy(opts)).ok;
}
/** Like sendMail, and says why when it didn't go. */
async function sendMailWhy(opts) {
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const fromName = (opts.co?.email_from_name || opts.co?.name || "").trim();
	const replyTo = opts.replyTo ?? opts.co?.email_reply_to ?? opts.co?.email ?? null;
	const r = await deliver({
		fromName,
		to: opts.to,
		replyTo,
		subject: opts.subject,
		text: opts.text
	});
	return {
		ok: r.ok,
		why: r.why
	};
}
/** Save files a customer added on the support page. */
async function saveFiles(companyId, ticketId, files) {
	const out = [];
	for (const f of files.slice(0, 4)) {
		const bytes = Buffer.from(f.base64, "base64");
		if (!bytes.length || bytes.length > 8388608) continue;
		const clean = (f.name || "file").replace(/[^\w.\- ]+/g, "_").slice(-80);
		const path = `${companyId}/${ticketId}/${crypto.randomUUID().slice(0, 8)}-${clean}`;
		const { error } = await admin.storage.from(BUCKET).upload(path, bytes, {
			contentType: f.type || "application/octet-stream",
			upsert: false
		});
		if (error) {
			console.error("[support files]", error.message);
			continue;
		}
		out.push({
			path,
			name: f.name || clean,
			size: bytes.length,
			type: f.type || ""
		});
	}
	return out;
}
/** Plain-text check of what a customer typed. */
function clean(v, max) {
	return String(v ?? "").replace(/\u0000/g, "").trim().slice(0, max);
}
//#endregion
export { BUCKET, admin, clean, companyById, companyForSlug, saveFiles, sendMail, sendMailWhy };
