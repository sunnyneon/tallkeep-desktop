import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy.functions-7131XI8K.js
/**
* Buying Tallkeep Desktop online: the Buy page (no sign-in) works out the price, sends the
* customer to Stripe to pay, and once Stripe says it's paid, makes the license key and emails it.
* Needs the STRIPE_SECRET_KEY secret (and LICENSE_PRIVATE_KEY, RESEND_API_KEY).
*/
var FOUNDERS_UNTIL = "2027-01-30";
function priceFor(info, companies, users) {
	const extraC = Math.max(0, companies - info.baseCompanies);
	const extraU = Math.max(0, users - info.baseUsers);
	return {
		extraC,
		extraU,
		total: info.base + extraC * info.extraCompany + extraU * info.extraUser
	};
}
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
async function buyInfo() {
	const { readPrices } = await import("./admin.functions-yTiQNb_O.mjs");
	const d = (await readPrices())?.prices ?? null;
	const { count } = await (await admin()).from("desktop_licenses").select("id", {
		count: "exact",
		head: true
	}).not("stripe_session", "is", null);
	const limit = d?.founders?.limit ?? 0;
	const foundersLeft = Math.max(0, limit - (count ?? 0));
	const foundersUntil = (d?.founders)?.until ?? FOUNDERS_UNTIL;
	const ended = Date.now() > (/* @__PURE__ */ new Date(`${foundersUntil}T23:59:59-06:00`)).getTime();
	const founders = !!d?.founders?.desktop && foundersLeft > 0 && !ended;
	const regularBase = d?.desktop.base ?? 0;
	return {
		ready: !!process.env["STRIPE_SECRET_KEY"] && regularBase > 0,
		base: founders ? d.founders.desktop : regularBase,
		founders,
		foundersUntil,
		regularBase,
		foundersLeft,
		baseCompanies: d?.desktop.base_companies ?? 1,
		baseUsers: d?.desktop.base_users ?? 1,
		extraCompany: d?.desktop.extra_company ?? 0,
		extraUser: d?.desktop.extra_user ?? 0,
		updatesYearly: d?.desktop.updates_yearly ?? 0
	};
}
var getBuyInfo_createServerFn_handler = createServerRpc({
	id: "222764ceb133430e5ba744ea2a49ff737733dc9183d46b15301b1c7e2ef2bb4a",
	name: "getBuyInfo",
	filename: "src/lib/buy.functions.ts"
}, (opts) => getBuyInfo.__executeServer(opts));
var getBuyInfo = createServerFn({ method: "GET" }).handler(getBuyInfo_createServerFn_handler, async () => ({
	...await buyInfo(),
	foundersLeft: 0
}));
async function stripe(path, form) {
	const key = process.env["STRIPE_SECRET_KEY"];
	if (!key) throw new Error("Buying online isn't open yet.");
	const base = process.env["STRIPE_API_BASE"] || "https://api.stripe.com";
	let res;
	try {
		res = await fetch(`${base}/v1/${path}`, {
			method: form ? "POST" : "GET",
			headers: {
				Authorization: `Bearer ${key}`,
				...form ? { "Content-Type": "application/x-www-form-urlencoded" } : {}
			},
			body: form ?? null
		});
	} catch {
		throw new Error("Couldn't reach the payment service. Try again in a minute.");
	}
	const body = await res.json();
	if (!res.ok) throw new Error(body.error?.message ?? `Stripe said ${res.status}`);
	return body;
}
var startCheckout_createServerFn_handler = createServerRpc({
	id: "f9954db22f4c3a8f70b27c51d850a744ed1538ae448929e6afd51e15b23278e7",
	name: "startCheckout",
	filename: "src/lib/buy.functions.ts"
}, (opts) => startCheckout.__executeServer(opts));
var startCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	const to = String(d.to ?? "").trim().slice(0, 100);
	const email = String(d.email ?? "").trim().slice(0, 200);
	if (!to) throw new Error("Type your business name.");
	if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Type your email address.");
	const companies = Math.floor(Number(d.companies));
	const users = Math.floor(Number(d.users));
	if (!(companies >= 1 && companies <= 100)) throw new Error("Companies: 1 to 100.");
	if (!(users >= 1 && users <= 500)) throw new Error("People: 1 to 500.");
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	const code = String(d.code ?? "").trim().toUpperCase().slice(0, 20);
	return {
		to,
		email,
		companies,
		users,
		origin: d.origin,
		code
	};
}).handler(startCheckout_createServerFn_handler, async ({ data }) => {
	const info = await buyInfo();
	if (!info.ready) throw new Error("Buying online isn't open yet. Email hello@tallkeep.com.");
	const companies = Math.max(data.companies, info.baseCompanies);
	const users = Math.max(data.users, info.baseUsers);
	const p = priceFor(info, companies, users);
	const { testerCode, TESTER_DISCOUNT_PCT } = await import("./testers.functions-V-g6Iwz2.mjs").then((n) => n.c);
	const tc = data.code ? await testerCode(data.code) : null;
	if (data.code && !tc) throw new Error("That early access code isn't right, or it was already used. Check your welcome email.");
	const off = tc ? 1 - TESTER_DISCOUNT_PCT / 100 : 1;
	const f = new URLSearchParams();
	let i = 0;
	const line = (name, dollars, qty) => {
		if (qty <= 0 || dollars <= 0) return;
		f.set(`line_items[${i}][price_data][currency]`, "usd");
		f.set(`line_items[${i}][price_data][product_data][name]`, name);
		f.set(`line_items[${i}][price_data][unit_amount]`, String(Math.round(dollars * 100)));
		f.set(`line_items[${i}][quantity]`, String(qty));
		i++;
	};
	line(`Tallkeep Desktop${tc ? ` (early access price, ${TESTER_DISCOUNT_PCT}% off)` : info.founders ? " (founders price)" : ""}: ${info.baseCompanies} ${info.baseCompanies === 1 ? "company" : "companies"}, ${info.baseUsers} ${info.baseUsers === 1 ? "person" : "people"}, 1 year of updates`, tc ? Math.floor(info.regularBase * off) : info.base, 1);
	line("Extra company", Math.floor(info.extraCompany * off), p.extraC);
	line("Extra person", Math.floor(info.extraUser * off), p.extraU);
	f.set("mode", "payment");
	f.set("customer_email", data.email);
	f.set("allow_promotion_codes", "true");
	f.set("success_url", `${data.origin}/buy/done?session={CHECKOUT_SESSION_ID}`);
	f.set("cancel_url", `${data.origin}/buy`);
	f.set("metadata[product]", "tallkeep_desktop");
	f.set("metadata[to]", data.to);
	f.set("metadata[companies]", String(companies));
	f.set("metadata[users]", String(users));
	f.set("metadata[origin]", data.origin);
	if (tc) f.set("metadata[tester_code]", tc.code);
	const s = await stripe("checkout/sessions", f);
	return { url: String(s["url"]) };
});
async function fulfill(session) {
	if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return { status: "unpaid" };
	const db = await admin();
	const existing = async () => {
		const { data } = await db.from("desktop_licenses").select("id,license_key,email,notes").eq("stripe_session", session).maybeSingle();
		return data;
	};
	const { wasMailed } = await import("./license.server-DmRH5APk.mjs");
	const had = await existing();
	if (had) return {
		status: "paid",
		id: had.id,
		key: had.license_key,
		email: had.email,
		mailed: wasMailed(had.notes)
	};
	const s = await stripe(`checkout/sessions/${session}`);
	if (s.payment_status !== "paid" || s.metadata?.["product"] !== "tallkeep_desktop") return { status: "unpaid" };
	const m = s.metadata;
	const email = s.customer_details?.email || s.customer_email || null;
	const until = /* @__PURE__ */ new Date();
	until.setFullYear(until.getFullYear() + 1);
	const { createLicense, mailLicense, mailNote } = await import("./license.server-DmRH5APk.mjs");
	const lic = {
		to: m["to"] || s.customer_details?.name || "Tallkeep customer",
		email,
		companies: Number(m["companies"]) || 1,
		users: Number(m["users"]) || 1,
		updatesUntil: until.toISOString().slice(0, 10),
		computers: 1,
		notes: `Paid online $${((s.amount_total ?? 0) / 100).toFixed(2)}`,
		stripeSession: session,
		paidCents: s.amount_total ?? null
	};
	let made;
	try {
		made = await createLicense(db, lic);
	} catch (e) {
		const again = await existing();
		if (again) return {
			status: "paid",
			id: again.id,
			key: again.license_key,
			email: again.email,
			mailed: wasMailed(again.notes)
		};
		throw e;
	}
	const sent = email ? await mailLicense({
		to: email,
		name: lic.to,
		id: made.id,
		key: made.key,
		companies: lic.companies,
		users: lic.users,
		updatesUntil: lic.updatesUntil,
		origin: m["origin"] || "https://app.tallkeep.com"
	}) : {
		ok: false,
		why: "no email address"
	};
	if (!sent.ok) console.error("[buy] license email", sent.why);
	if (m["tester_code"]) {
		const { markTesterCodeUsed } = await import("./testers.functions-V-g6Iwz2.mjs").then((n) => n.c);
		await markTesterCodeUsed(m["tester_code"], session).catch(() => null);
	}
	await db.from("desktop_licenses").update({ notes: `${lic.notes} · ${mailNote(sent)}` }).eq("id", made.id);
	const mailed = sent.ok;
	return {
		status: "paid",
		id: made.id,
		key: made.key,
		email,
		mailed
	};
}
var getOrder_createServerFn_handler = createServerRpc({
	id: "9c23602d2497e87db527c2f51f96da388bc05788ddb83ab0c420cfc762bcd869",
	name: "getOrder",
	filename: "src/lib/buy.functions.ts"
}, (opts) => getOrder.__executeServer(opts));
var getOrder = createServerFn({ method: "GET" }).inputValidator((d) => ({ session: String(d.session ?? "") })).handler(getOrder_createServerFn_handler, async ({ data }) => fulfill(data.session));
//#endregion
export { getBuyInfo_createServerFn_handler, getOrder_createServerFn_handler, startCheckout_createServerFn_handler };
