import { t as supabase } from "./client-C9I0PyVu.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/cardpay-CotP51jv.js
/**
* "Pay now" card payments, from the app's side (Tallkeep Desktop): ask the office computer for
* the Stripe connection's status, an invoice's link, or to pick up new payments.
*/
var desktopApp = () => !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1"
}["VITE_TALLKEEP_DESKTOP"];
async function call(method, path, body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/pay${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
async function activeCompany() {
	const { data } = await supabase.rpc("active_company");
	return String(data ?? "");
}
var returnHere = () => `${window.location.origin}/settings?card=back`;
function useCardPay() {
	return useQuery({
		queryKey: ["card-pay"],
		enabled: desktopApp(),
		staleTime: 3e5,
		queryFn: async () => {
			const company = await activeCompany();
			return {
				company,
				...await call("GET", `?${new URLSearchParams({
					company,
					returnUrl: returnHere()
				})}`)
			};
		}
	});
}
/** Start connecting Stripe: sign in to an existing account, or make a new one. */
var connectStripe = (company, existing = false) => call("POST", "/connect", {
	company,
	returnUrl: returnHere(),
	existing
});
/** The invoice's Pay now link; `cents` asks for part of it (a deposit) instead of all that's owed. */
var payLink = (invoice, cents) => call("POST", "/link", {
	invoice,
	cents
});
var disconnectStripe = (company) => call("POST", "/disconnect", { company });
var syncCardPayments = () => call("POST", "/sync", {});
//#endregion
export { useCardPay as a, syncCardPayments as i, disconnectStripe as n, payLink as r, connectStripe as t };
