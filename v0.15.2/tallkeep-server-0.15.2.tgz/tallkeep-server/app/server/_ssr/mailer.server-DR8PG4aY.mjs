//#region ../../node_modules/.nitro/vite/services/ssr/assets/mailer.server-DR8PG4aY.js
var desktop = () => process.env["TALLKEEP_DESKTOP"] === "1";
/** Plain text as simple HTML: line breaks kept, links clickable. */
function textToHtml(text) {
	return `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5">${text.split("\n").map((l) => l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/(https?:\/\/\S+)/g, "<a href=\"$1\">$1</a>")).join("<br>")}</div>`;
}
/** Is email set up? */
async function mailReady() {
	if (!desktop()) return !!process.env["RESEND_API_KEY"];
	if (!process.env["TALLKEEP_MAIL_URL"]) return false;
	return !!(await deliverDesktop({
		to: [],
		subject: "",
		text: ""
	}, true).catch(() => null))?.ok;
}
async function deliverDesktop(m, check = false) {
	const url = process.env["TALLKEEP_MAIL_URL"];
	if (!url) return {
		ok: false,
		why: "email isn't set up on the office computer"
	};
	const res = await fetch(check ? url.replace(/\/mail\/send$/, "/mail/ready") : url, {
		method: "POST",
		headers: {
			"content-type": "application/json",
			"x-tallkeep-mail": process.env["TALLKEEP_MAIL_TOKEN"] ?? ""
		},
		body: JSON.stringify(m)
	});
	return await res.json().catch(() => ({
		ok: false,
		why: `${res.status}`
	}));
}
async function deliver(m) {
	const to = m.to.filter((e) => /^\S+@\S+\.\S+$/.test(e));
	if (!to.length) return {
		ok: false,
		why: "there's no email address to send to"
	};
	const mail = {
		...m,
		to,
		html: m.html ?? textToHtml(m.text)
	};
	try {
		if (desktop()) return await deliverDesktop(mail);
		const key = process.env["RESEND_API_KEY"];
		if (!key) return {
			ok: false,
			why: "email isn't set up (the RESEND_API_KEY secret is missing)"
		};
		const base = process.env["RESEND_FROM"] || "Tallkeep <hello@send.tallkeep.com>";
		const address = /<([^>]+)>/.exec(base)?.[1] ?? base;
		const name = (m.fromName ?? "").replace(/[<>"]/g, "").trim();
		const res = await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${key}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from: name ? `${name} <${address}>` : base,
				to,
				...m.cc?.length ? { cc: m.cc } : {},
				...m.bcc?.length ? { bcc: m.bcc } : {},
				...m.replyTo ? { reply_to: m.replyTo } : {},
				subject: m.subject,
				text: m.text,
				html: mail.html,
				...m.attachments?.length ? { attachments: m.attachments } : {}
			})
		});
		const body = await res.json().catch(() => ({}));
		if (!res.ok) return {
			ok: false,
			why: `the email service said: ${body.message ?? res.status}`
		};
		return {
			ok: true,
			why: "",
			id: body.id ?? ""
		};
	} catch (e) {
		console.error("[mail]", e);
		return {
			ok: false,
			why: "the email service couldn't be reached"
		};
	}
}
//#endregion
export { deliver, mailReady };
