import { n as db } from "./db-zltnVrwr.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as PHOTO_BUCKET } from "./photos-PwQoyCNs.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PrintFrame-PJ2rEoZR.js
var import_jsx_runtime = require_jsx_runtime();
/**
* The company logo uploaded in Settings ("" = no logo). A path starting with "/" is a file
* that ships with the app (the SunRise logo).
*/
function useCompanyLogo() {
	const { data } = useQuery({
		queryKey: ["company-logo"],
		staleTime: 3e6,
		queryFn: async () => {
			const { data: c } = await db.from("company_settings").select("logo_path").maybeSingle();
			const path = c?.logo_path;
			if (!path) return "";
			if (path.startsWith("/")) return path;
			const { data: s } = await db.storage.from(PHOTO_BUCKET).createSignedUrl(path, 3600);
			return s?.signedUrl ?? "";
		}
	});
	return data ?? "";
}
/**
* The paper version of a document. Only shows when printing or saving as PDF.
* The browser's own date/link lines are turned off (see styles.css), the page footer
* repeats at the bottom of every page, and an attached page (Terms & Conditions) follows.
*/
function PrintFrame({ pageFooter, attach, logo, company, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden bg-white text-[12px] text-black print:block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full border-collapse",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[0.45in]" }) }) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-[0.65in] items-center justify-center px-[0.6in] text-center text-[10px] italic text-gray-700",
					children: pageFooter
				}) }) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "px-[0.6in] align-top",
					children
				}) }) })
			]
		}), attach && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachedPage, {
			text: attach,
			logo,
			company
		})]
	});
}
/** A saved page printed after the document, e.g. the Quote Terms & Conditions. */
function AttachedPage({ text, logo, company }) {
	const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
	const first = lines[0] ?? "";
	const title = first === first.toUpperCase() && first.length < 60 ? first : null;
	const rest = title ? lines.slice(1) : lines;
	const items = rest.filter((l) => /^\d+\.\s/.test(l));
	const before = rest.filter((l, i) => !/^\d+\.\s/.test(l) && i < rest.findIndex((x) => /^\d+\.\s/.test(x)));
	const after = rest.filter((l) => !/^\d+\.\s/.test(l) && !before.includes(l));
	const ack = after.some((l) => /ACKNOWLEDG/i.test(l));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "break-before-page px-[0.5in] pt-[0.45in] text-[9.5px] leading-snug",
		style: { breakBefore: "page" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between border-b-2 border-black pb-2",
				children: [logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: logo,
					alt: company,
					className: "h-10 object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-bold",
					style: { color: "#E30613" },
					children: title
				})]
			}),
			before.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-semibold",
				children: l
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 columns-2 gap-6",
				children: items.map((l, i) => {
					const m = l.match(/^(\d+\.\s.+?)\s[-–]\s(.*)$/);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 break-inside-avoid",
						children: m ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: m[1] }),
							" – ",
							m[2]
						] }) : l
					}, i);
				})
			}),
			after.map((l, i) => {
				const m = l.match(/^([A-Z][A-Z\s&]+)\s[-–]\s(.*)$/);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: m ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: m[1] }),
						" – ",
						m[2]
					] }) : l
				}, i);
			}),
			ack && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-4 gap-6 text-center text-[9px]",
				children: [
					"Customer initials",
					"Authorized signature",
					"Print name / title",
					"Date"
				].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 border-b border-black" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: x
				})] }, x))
			})
		]
	});
}
//#endregion
export { useCompanyLogo as n, PrintFrame as t };
