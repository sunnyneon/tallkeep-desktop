import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/email.functions-f4BY8LFE.js
/** Send a quote / invoice / PO as a PDF from the company (see mailer.server.ts). */
var sendDocEmail_createServerFn_handler = createServerRpc({
	id: "a7f32f276406e2d7206bbca2e8c5fc871d65fb4425fcac828b84b5aae9eb123f",
	name: "sendDocEmail",
	filename: "src/lib/email.functions.ts"
}, (opts) => sendDocEmail.__executeServer(opts));
var sendDocEmail = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const ok = (e) => /^\S+@\S+\.\S+$/.test(e);
	if (!d.to.length || !d.to.every(ok)) throw new Error("Type a valid email for the customer.");
	if (!d.cc.every(ok)) throw new Error("One of the copy addresses isn't a valid email.");
	if (!d.pdfBase64) throw new Error("The PDF is missing.");
	if (d.pdfBase64.length > 14e6) throw new Error("The PDF is too big to email.");
	return d;
}).handler(sendDocEmail_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone } = await import("./zone.server-Do4zmXJ2.mjs");
	await requireZone(context.userId, ["Sales", "Purchasing"], "emailing documents");
	const { data: me } = await supabaseAdmin.auth.admin.getUserById(context.userId);
	const { data: uc } = await supabaseAdmin.from("user_company").select("company_id").eq("user_id", context.userId).maybeSingle();
	const companyId = uc?.company_id;
	let settingsQ = supabaseAdmin.from("company_settings").select("*");
	if (companyId) settingsQ = settingsQ.eq("company_id", companyId);
	const { data: coRows } = await settingsQ.limit(1);
	const co = (coRows ?? [])[0] ?? {};
	const fromName = (co.email_from_name || co.name || "").trim();
	const replyTo = co.email_reply_to || me.user?.email || co.email || null;
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const r = await deliver({
		fromName,
		to: data.to,
		cc: data.cc,
		replyTo,
		subject: data.subject,
		text: data.message,
		attachments: [{
			filename: data.filename,
			content: data.pdfBase64
		}]
	});
	if (!r.ok) throw new Error(process.env["TALLKEEP_DESKTOP"] === "1" && /isn't set up/.test(r.why) ? "Email isn't set up yet: an admin can set it up in Settings → Company → Email." : `The email didn't go: ${r.why}.`);
	return { id: r.id ?? "" };
});
//#endregion
export { sendDocEmail_createServerFn_handler };
