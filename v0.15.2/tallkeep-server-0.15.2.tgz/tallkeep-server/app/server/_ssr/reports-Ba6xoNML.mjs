import { n as db } from "./db-zltnVrwr.mjs";
import { c as kindLabel, i as accountLabel, n as TYPE_LABEL, o as balanceOf, s as dayBefore } from "./accounting-QuDdqtoA.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/reports-Ba6xoNML.js
/**
* Report data and math, shared by Financial Reports (on screen) and the year-end package
* for the accountant (files in a .zip).
*/
function profitLoss(accounts, bal) {
	const pick = (kinds) => accounts.filter((a) => kinds.includes(a.kind) && Math.abs(bal(a)) > .004);
	const income = pick(["income"]);
	const cogs = pick(["cogs"]);
	const expenses = pick(["expense"]);
	const otherIncome = pick(["other_income"]);
	const otherExp = pick(["other_expense"]);
	const sum = (l) => l.reduce((s, a) => s + bal(a), 0);
	const gross = sum(income) - sum(cogs);
	const operating = gross - sum(expenses);
	const net = operating + sum(otherIncome) - sum(otherExp);
	const csv = () => [
		["Account", "Amount"],
		...income.map((a) => [accountLabel(a), bal(a)]),
		["Total income", sum(income)],
		...cogs.map((a) => [accountLabel(a), bal(a)]),
		["Gross profit", gross],
		...expenses.map((a) => [accountLabel(a), bal(a)]),
		["Operating profit", operating],
		...otherIncome.map((a) => [accountLabel(a), bal(a)]),
		...otherExp.map((a) => [accountLabel(a), -bal(a)]),
		["Net profit", net]
	];
	return {
		income,
		cogs,
		expenses,
		otherIncome,
		otherExp,
		sum,
		gross,
		operating,
		net,
		csv
	};
}
/** bal = everything up to the day; yearBal = this fiscal year only (for net profit). */
function balanceSheet(accounts, bal, yearBal) {
	const show = (t) => accounts.filter((a) => a.type === t && Math.abs(bal(a)) > .004);
	const assets = show("asset");
	const liabilities = show("liability");
	const equity = show("equity");
	const pl = (b) => accounts.reduce((s, a) => s + (a.type === "income" ? b(a) : a.type === "expense" ? -b(a) : 0), 0);
	const netAll = pl(bal);
	const netYear = pl(yearBal);
	const prior = netAll - netYear;
	const sum = (l) => l.reduce((s, a) => s + bal(a), 0);
	const totalEquity = sum(equity) + prior + netYear;
	const totalAssets = sum(assets);
	const totalLE = sum(liabilities) + totalEquity;
	const off = Math.round((totalAssets - totalLE) * 100) / 100;
	const csv = () => [
		["Account", "Amount"],
		...assets.map((a) => [accountLabel(a), bal(a)]),
		["Total assets", totalAssets],
		...liabilities.map((a) => [accountLabel(a), bal(a)]),
		["Total liabilities", sum(liabilities)],
		...equity.map((a) => [accountLabel(a), bal(a)]),
		["Retained earnings (earlier years)", prior],
		["Net profit (this year)", netYear],
		["Total equity", totalEquity],
		["Total liabilities and equity", totalLE]
	];
	return {
		assets,
		liabilities,
		equity,
		sum,
		prior,
		netYear,
		totalEquity,
		totalAssets,
		totalLE,
		off,
		csv
	};
}
async function loadSplit(from, to) {
	const { data, error } = await db.rpc("account_totals_split", {
		_from: from,
		_to: to
	});
	if (error) throw error;
	const m = /* @__PURE__ */ new Map();
	for (const r of data ?? []) m.set(r.account_id, {
		debit: Number(r.debit),
		credit: Number(r.credit),
		adj_debit: Number(r.adj_debit),
		adj_credit: Number(r.adj_credit)
	});
	return m;
}
var side = (net) => ({
	dr: net > .004 ? net : 0,
	cr: net < -.004 ? -net : 0
});
function trialBalance(accounts, split) {
	const rows = accounts.map((a) => {
		const t = split.get(a.id);
		const before = t ? t.debit - t.credit : 0;
		const adj = t ? t.adj_debit - t.adj_credit : 0;
		return {
			a,
			before: side(before),
			adj: side(adj),
			after: side(before + adj)
		};
	}).filter((r) => r.before.dr || r.before.cr || r.adj.dr || r.adj.cr || r.after.dr || r.after.cr);
	const total = (k, s) => rows.reduce((x, r) => x + r[k][s], 0);
	const hasAdj = rows.some((r) => r.adj.dr || r.adj.cr);
	const csv = () => [
		[
			"Account number",
			"Account",
			"Before adjustments debit",
			"Before adjustments credit",
			"Adjustments debit",
			"Adjustments credit",
			"Adjusted debit",
			"Adjusted credit"
		],
		...rows.map((r) => [
			r.a.number ?? "",
			r.a.name,
			r.before.dr,
			r.before.cr,
			r.adj.dr,
			r.adj.cr,
			r.after.dr,
			r.after.cr
		]),
		[
			"",
			"Total",
			total("before", "dr"),
			total("before", "cr"),
			total("adj", "dr"),
			total("adj", "cr"),
			total("after", "dr"),
			total("after", "cr")
		]
	];
	return {
		rows,
		total,
		hasAdj,
		csv
	};
}
var SOURCE_NAME = {
	invoice: "Invoice",
	invoice_cogs: "Cost of goods",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	stock: "Stock change",
	bill: "Bill",
	bill_payment: "Bill payment",
	bank: "Bank",
	manual: "Typed by hand",
	opening: "Opening balance",
	adjust: "Accountant adjustment",
	history: "From QuickBooks",
	rent_charge: "Rent charge",
	rent_payment: "Rent received",
	work_order: "Work order",
	check: "Check / payment",
	deposit: "Deposit",
	transfer: "Transfer"
};
async function loadLedger(from, to) {
	const out = [];
	const size = 1e3;
	for (let i = 0;; i += size) {
		const { data, error } = await db.rpc("general_ledger", {
			_from: from,
			_to: to
		}).range(i, i + size - 1);
		if (error) throw error;
		const rows = data ?? [];
		out.push(...rows.map((r) => ({
			...r,
			debit: Number(r.debit),
			credit: Number(r.credit)
		})));
		if (rows.length < size) break;
	}
	return out;
}
/**
* Lines grouped by account with a starting balance and a running balance.
* openAll = totals of everything before `from`; openYear = totals from Jan 1 to the day before
* `from` (income and expense accounts start the year at zero).
*/
function ledger(accounts, lines, openAll, openYear) {
	const by = /* @__PURE__ */ new Map();
	for (const l of lines) {
		const list = by.get(l.account_id) ?? [];
		list.push(l);
		by.set(l.account_id, list);
	}
	const groups = accounts.map((a) => {
		const o = (a.type === "income" || a.type === "expense" ? openYear : openAll).get(a.id);
		const opening = o ? balanceOf(a.type, o.debit, o.credit) : 0;
		let run = opening;
		return {
			a,
			opening,
			rows: (by.get(a.id) ?? []).map((l) => {
				run += balanceOf(a.type, l.debit, l.credit);
				return {
					...l,
					balance: run
				};
			}),
			closing: run
		};
	}).filter((g) => g.rows.length || Math.abs(g.opening) > .004);
	const csv = () => {
		const out = [[
			"Account number",
			"Account",
			"Date",
			"Type",
			"Number",
			"Name",
			"Memo",
			"Debit",
			"Credit",
			"Balance"
		]];
		for (const g of groups) {
			out.push([
				g.a.number ?? "",
				g.a.name,
				"",
				"Starting balance",
				"",
				"",
				"",
				"",
				"",
				g.opening
			]);
			for (const r of g.rows) out.push([
				g.a.number ?? "",
				g.a.name,
				r.entry_date,
				SOURCE_NAME[r.source_type] ?? r.source_type,
				r.ref ?? "",
				r.name ?? "",
				r.memo ?? "",
				r.debit,
				r.credit,
				r.balance
			]);
			out.push([
				g.a.number ?? "",
				g.a.name,
				"",
				"Ending balance",
				"",
				"",
				"",
				"",
				"",
				g.closing
			]);
		}
		return out;
	};
	return {
		groups,
		csv
	};
}
/** The day before `from`, and Jan 1 of that year, for ledger starting balances. */
var ledgerOpenRange = (from) => ({
	before: dayBefore(from),
	yearStart: `${from.slice(0, 4)}-01-01`
});
var BUCKETS = [
	"Not due yet",
	"1–30 days late",
	"31–60 days late",
	"61–90 days late",
	"Over 90 days late"
];
var bucketOf = (due, asOf) => {
	const late = (Date.parse(`${asOf}T12:00:00`) - Date.parse(`${due.slice(0, 10)}T12:00:00`)) / 864e5;
	return late <= 0 ? 0 : late <= 30 ? 1 : late <= 60 ? 2 : late <= 90 ? 3 : 4;
};
async function loadOpen(kind) {
	if (kind === "ar") {
		const { data, error } = await db.from("sales_orders").select("customer_name,number,invoice_date,order_date,due_date,balance,status").in("status", [
			"invoiced",
			"paid",
			"completed"
		]).gt("balance", 0).limit(1e4);
		if (error) throw error;
		return (data ?? []).filter((o) => !o.number.startsWith("RMA-")).map((o) => ({
			who: o.customer_name ?? "No customer",
			number: o.number,
			date: (o.invoice_date ?? o.order_date).slice(0, 10),
			due: (o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10),
			balance: Number(o.balance)
		}));
	}
	const [bills, pos] = await Promise.all([db.from("bills").select("vendor_name,ref,bill_date,due_date,balance,status").eq("status", "open").gt("balance", 0).limit(1e4), db.from("purchase_orders").select("vendor_name,number,order_date,due_date,balance,status,stock_received_at").gt("balance", 0).neq("status", "cancelled").limit(1e4)]);
	if (bills.error) throw bills.error;
	return [...(bills.data ?? []).map((b) => ({
		who: b.vendor_name ?? "No vendor",
		number: b.ref ? `Bill ${b.ref}` : "Bill",
		date: b.bill_date,
		due: b.due_date ?? b.bill_date,
		balance: Number(b.balance)
	})), ...(pos.data ?? []).filter((p) => p.stock_received_at || [
		"received",
		"paid",
		"completed"
	].includes(p.status)).map((p) => ({
		who: p.vendor_name ?? "No vendor",
		number: p.number,
		date: p.order_date.slice(0, 10),
		due: (p.due_date ?? p.order_date).slice(0, 10),
		balance: Number(p.balance)
	}))];
}
function aging(kind, all, asOf) {
	const rows = all.filter((r) => r.date <= asOf);
	const people = /* @__PURE__ */ new Map();
	for (const r of rows) {
		const b = people.get(r.who) ?? [
			0,
			0,
			0,
			0,
			0
		];
		const k = bucketOf(r.due, asOf);
		b[k] = (b[k] ?? 0) + r.balance;
		people.set(r.who, b);
	}
	const sum = (b) => b.reduce((s, x) => s + x, 0);
	const list = [...people.entries()].sort((a, b) => sum(b[1]) - sum(a[1]));
	const totals = BUCKETS.map((_, i) => list.reduce((s, [, b]) => s + (b[i] ?? 0), 0));
	const grand = sum(totals);
	const csv = () => [
		[
			kind === "ar" ? "Customer" : "Vendor",
			...BUCKETS,
			"Total"
		],
		...list.map(([w, b]) => [
			w,
			...b,
			sum(b)
		]),
		[
			"Total",
			...totals,
			grand
		]
	];
	return {
		list,
		totals,
		grand,
		sum,
		csv
	};
}
async function loadTaxRows() {
	const { data, error } = await db.from("sales_orders").select("number,tax_name,tax_rate,tax,total,invoice_date,order_date,status").in("status", [
		"invoiced",
		"paid",
		"completed"
	]).limit(2e4);
	if (error) throw error;
	return data ?? [];
}
function salesTax(all, from, to) {
	const rows = all.filter((o) => {
		const d = (o.invoice_date ?? o.order_date).slice(0, 10);
		return !o.number.startsWith("RMA-") && d >= from && d <= to;
	});
	const groups = /* @__PURE__ */ new Map();
	for (const o of rows) {
		const taxed = Number(o.tax) > 0;
		const k = taxed ? `${o.tax_name || "Sales tax"} (${Number(o.tax_rate ?? 0)}%)` : "No tax charged";
		const g = groups.get(k) ?? {
			sales: 0,
			taxable: 0,
			tax: 0,
			count: 0
		};
		const sales = Number(o.total) - Number(o.tax);
		g.sales += sales;
		g.taxable += taxed ? sales : 0;
		g.tax += Number(o.tax);
		g.count += 1;
		groups.set(k, g);
	}
	const list = [...groups.entries()];
	const t = list.reduce((s, [, g]) => ({
		sales: s.sales + g.sales,
		taxable: s.taxable + g.taxable,
		tax: s.tax + g.tax
	}), {
		sales: 0,
		taxable: 0,
		tax: 0
	});
	const csv = () => [
		[
			"Tax",
			"Invoices",
			"Sales",
			"Taxable sales",
			"Tax collected"
		],
		...list.map(([k, g]) => [
			k,
			g.count,
			g.sales,
			g.taxable,
			g.tax
		]),
		[
			"Total",
			rows.length,
			t.sales,
			t.taxable,
			t.tax
		]
	];
	return {
		list,
		count: rows.length,
		t,
		csv
	};
}
/** IRS 1099-NEC/MISC reporting amount: $600 through 2025, $2,000 from 2026 payments on. */
var threshold1099 = (year) => year >= 2026 ? 2e3 : 600;
async function load1099(from, to) {
	const [pay, vend] = await Promise.all([db.rpc("vendor_payments", {
		_from: from,
		_to: to
	}), db.from("vendors").select("id,name,tax_id,is_1099,address").limit(1e4)]);
	if (pay.error) throw pay.error;
	if (vend.error) throw vend.error;
	const paid = new Map((pay.data ?? []).map((r) => [r.vendor_id, r]));
	return (vend.data ?? []).map((v) => {
		const p = paid.get(v.id);
		const total = Number(p?.paid ?? 0);
		const card = Number(p?.by_card ?? 0);
		return {
			...v,
			is_1099: !!v.is_1099,
			paid: total,
			by_card: card,
			counted: total - card
		};
	}).filter((v) => v.paid > 0 || v.is_1099).sort((a, b) => b.counted - a.counted);
}
function v1099Csv(rows, threshold) {
	return [[
		"Vendor",
		"Tax ID",
		"Address",
		"Marked for 1099",
		"Paid",
		"Paid by credit card",
		"Counts toward 1099",
		`Needs a 1099 (marked and ${threshold} or more)`
	], ...rows.map((v) => [
		v.name,
		v.tax_id ?? "",
		v.address ?? "",
		v.is_1099 ? "Yes" : "No",
		v.paid,
		v.by_card,
		v.counted,
		v.is_1099 && v.counted >= threshold ? "Yes" : "No"
	])];
}
function chartCsv(accounts, bal) {
	return [[
		"Number",
		"Name",
		"Type",
		"Kind",
		"Active",
		"Balance"
	], ...accounts.map((a) => [
		a.number ?? "",
		a.name,
		TYPE_LABEL[a.type],
		kindLabel(a.kind),
		a.is_active ? "Yes" : "No",
		bal(a)
	])];
}
//#endregion
export { v1099Csv as _, chartCsv as a, load1099 as c, loadSplit as d, loadTaxRows as f, trialBalance as g, threshold1099 as h, balanceSheet as i, loadLedger as l, salesTax as m, SOURCE_NAME as n, ledger as o, profitLoss as p, aging as r, ledgerOpenRange as s, BUCKETS as t, loadOpen as u };
