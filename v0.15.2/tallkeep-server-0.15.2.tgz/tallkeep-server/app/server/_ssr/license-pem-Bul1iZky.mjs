import { createPrivateKey } from "node:crypto";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/license-pem-Bul1iZky.js
/**
* The LICENSE_PRIVATE_KEY secret, however it was pasted: with or without the BEGIN/END lines, on
* one line, with spaces or "\n" instead of line breaks, or in quotes. Returns a proper PEM, or "".
*/
function licensePem() {
	const body = String(process.env["LICENSE_PRIVATE_KEY"] ?? "").replace(/\\n/g, "\n").replace(/-----(BEGIN|END)[A-Z ]*-----/g, "").replace(/[^A-Za-z0-9+/=]/g, "");
	if (body.length < 40) return "";
	const pem = `-----BEGIN PRIVATE KEY-----\n${(body.match(/.{1,64}/g) ?? []).join("\n")}\n-----END PRIVATE KEY-----\n`;
	try {
		createPrivateKey(pem);
	} catch {
		throw new Error("The LICENSE_PRIVATE_KEY secret isn't the private key. Paste it again from your password manager: all of it, from -----BEGIN to END-----.");
	}
	return pem;
}
//#endregion
export { licensePem };
