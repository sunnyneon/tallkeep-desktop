import { n as db } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/footers-BNGmbiMB.js
var FOOTER_KINDS = [
	{
		key: "quote",
		label: "Quotes"
	},
	{
		key: "order",
		label: "Sales orders"
	},
	{
		key: "invoice",
		label: "Invoices"
	},
	{
		key: "rma",
		label: "RMAs"
	},
	{
		key: "po",
		label: "Purchase orders"
	}
];
var PLACEMENTS = [
	{
		key: "page",
		label: "Bottom of every page",
		pick: "Footer on every page"
	},
	{
		key: "end",
		label: "End of the document",
		pick: "Footer at the end"
	},
	{
		key: "attach",
		label: "Own page after the document",
		pick: "Attached page (e.g. Terms & Conditions)"
	}
];
var NO_FOOTERS = {
	footer_id: null,
	footer_text: null,
	page_footer_id: null,
	page_footer_text: null,
	attach_id: null,
	attach_text: null
};
var SLOT = {
	end: {
		id: "footer_id",
		text: "footer_text"
	},
	page: {
		id: "page_footer_id",
		text: "page_footer_text"
	},
	attach: {
		id: "attach_id",
		text: "attach_text"
	}
};
function useFooters() {
	return useQuery({
		queryKey: ["doc-footers"],
		queryFn: async () => {
			const { data, error } = await db.from("doc_footers").select("*").order("sort").order("name");
			if (error) throw error;
			return (data ?? []).map((f) => ({
				...f,
				placement: f.placement ?? "end"
			}));
		}
	});
}
var defaultFooter = (list, kind, placement = "end") => list?.find((f) => (f.placement ?? "end") === placement && f.default_for.includes(kind));
/** All three default footers for a new document of this kind. */
function defaultsFor(list, kind) {
	const out = { ...NO_FOOTERS };
	Object.keys(SLOT).forEach((pl) => {
		const f = defaultFooter(list, kind, pl);
		if (f) {
			out[SLOT[pl].id] = f.id;
			out[SLOT[pl].text] = f.body;
		}
	});
	return out;
}
/**
* Moving a document to the next step (quote → invoice): swap each footer that is still
* the old step's default, untouched, for the new step's default. Hand-picked ones stay.
*/
function swapDefaults(list, doc, from, to) {
	const out = {};
	Object.keys(SLOT).forEach((pl) => {
		const { id, text } = SLOT[pl];
		const cur = list?.find((f) => f.id === doc[id]);
		if (!(!doc[id] ? !doc[text] : !!cur && cur.body === doc[text] && cur.default_for.includes(from))) return;
		const f = defaultFooter(list, to, pl);
		out[id] = f?.id ?? null;
		out[text] = f?.body ?? null;
	});
	return out;
}
//#endregion
export { defaultsFor as a, SLOT as i, NO_FOOTERS as n, swapDefaults as o, PLACEMENTS as r, useFooters as s, FOOTER_KINDS as t };
