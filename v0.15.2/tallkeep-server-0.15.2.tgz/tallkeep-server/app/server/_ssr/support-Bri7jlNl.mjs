//#region ../../node_modules/.nitro/vite/services/ssr/assets/support-Bri7jlNl.js
/** Support Desk: shared bits for the app and the support page. */
var TICKET_STATUS = {
	new: {
		label: "New",
		customer: "Received",
		tone: "bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-200"
	},
	open: {
		label: "Open",
		customer: "We're on it",
		tone: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200"
	},
	waiting: {
		label: "Waiting on customer",
		customer: "Waiting for your reply",
		tone: "bg-violet-100 text-violet-800 dark:bg-violet-950 dark:text-violet-200"
	},
	done: {
		label: "Done",
		customer: "Done",
		tone: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200"
	},
	closed: {
		label: "Closed",
		customer: "Closed",
		tone: "bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
	}
};
var TICKET_STATUSES = Object.keys(TICKET_STATUS);
var PRIORITY = {
	low: "Low",
	normal: "Normal",
	high: "High",
	urgent: "Urgent"
};
/** A file as base64 (for sending to the server from the support page). */
function fileToBase64(f) {
	return new Promise((resolve, reject) => {
		const r = new FileReader();
		r.onload = () => resolve(String(r.result).split(",")[1] ?? "");
		r.onerror = () => reject(r.error);
		r.readAsDataURL(f);
	});
}
var fileSize = (n) => n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
/**
* The address customers can open. On the office computer itself that's "localhost", which only
* works there, so use its office network address instead.
*/
async function publicOrigin() {
	if (typeof window === "undefined") return "";
	const { hostname, origin } = window.location;
	if (!!!{
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
		"VITE_SUPABASE_URL": "http://localhost:4600",
		"VITE_TALLKEEP_DESKTOP": "1"
	}["VITE_TALLKEEP_DESKTOP"] && hostname !== "localhost" && hostname !== "127.0.0.1") return origin;
	try {
		const h = await (await fetch("/tallkeep/health")).json();
		if (h.connectUrl) return h.connectUrl;
		if (hostname !== "localhost" && hostname !== "127.0.0.1") return origin;
		return h.addresses?.[0] ?? origin;
	} catch {
		return origin;
	}
}
/** Make a support page address from a company name: "SunRise LED Inc." → "sunrise-led". */
var slugFrom = (name) => name.toLowerCase().replace(/\b(inc|llc|ltd|corp|co)\b\.?/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
var ago = (iso) => {
	if (!iso) return "";
	const m = Math.round((Date.now() - new Date(iso).getTime()) / 6e4);
	if (m < 1) return "just now";
	if (m < 60) return `${m} min ago`;
	const h = Math.round(m / 60);
	if (h < 24) return `${h} h ago`;
	const d = Math.round(h / 24);
	return d < 30 ? `${d} day${d === 1 ? "" : "s"} ago` : new Date(iso).toLocaleDateString();
};
/** Does the customer have the last word (so it's our turn)? */
var ourTurn = (t) => !["done", "closed"].includes(t.status) && !!t.last_customer_at && (!t.last_staff_at || t.last_customer_at > t.last_staff_at);
//#endregion
export { fileSize as a, publicOrigin as c, ago as i, slugFrom as l, TICKET_STATUS as n, fileToBase64 as o, TICKET_STATUSES as r, ourTurn as s, PRIORITY as t };
