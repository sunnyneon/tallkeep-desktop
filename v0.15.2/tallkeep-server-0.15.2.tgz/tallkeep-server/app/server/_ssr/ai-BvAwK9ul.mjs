import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as AI_PROVIDERS } from "./ai-C4gd9Sqm.mjs";
import { n as aiSave, r as aiStatus } from "./ai.functions-DP3vVMF7.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-wDrazOwE.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai-BvAwK9ul.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FEATURE = {
	statement: "Bank statement",
	receipt: "Receipt",
	check: "Check received"
};
var usd = (n) => n < .01 && n > 0 ? "under 1¢" : fmtMoney(n);
function AiPage() {
	const qc = useQueryClient();
	const status = useQuery({
		queryKey: ["ai-status"],
		queryFn: () => aiStatus()
	});
	const uses = useQuery({
		queryKey: ["ai-usage"],
		queryFn: async () => {
			const { data, error } = await db.from("ai_usage").select("id,created_at,feature,model,pages,cost_usd,own_key").order("created_at", { ascending: false }).limit(100);
			if (error) throw error;
			return data ?? [];
		}
	});
	const s = status.data;
	const [provider, setProvider] = (0, import_react.useState)("vooska");
	const [model, setModel] = (0, import_react.useState)("");
	const [cap, setCap] = (0, import_react.useState)("");
	const [key, setKey] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!s) return;
		setProvider(s.provider);
		setModel(s.model === AI_PROVIDERS[s.provider].model ? "" : s.model);
		setCap(s.cap == null ? "" : String(s.cap));
	}, [s]);
	async function save(removeKey = false) {
		setBusy(true);
		try {
			await aiSave({ data: {
				provider,
				model,
				cap: cap.trim() === "" ? null : Number(cap),
				key: removeKey ? "" : key.trim() || null
			} });
			setKey("");
			toast.success("Saved.");
			qc.invalidateQueries({ queryKey: ["ai-status"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const own = provider !== "vooska";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "AI & Usage",
			text: "AI reads PDF bank statements and receipts for you. Use the built-in AI, or connect your own AI account and pay that company directly."
		}),
		!s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "This month"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/50 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-2xl font-bold",
									children: s.monthUses
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "times used"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/50 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-2xl font-bold",
									children: s.monthPages
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "pages read"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/50 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-2xl font-bold",
									children: usd(s.monthCost)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: ["built-in AI cost (estimate)", s.cap != null ? ` of ${fmtMoney(s.cap)}` : ""]
								})]
							})
						]
					}),
					s.provider === "vooska" && !s.builtInReady && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
						children: "The built-in AI isn't turned on yet. Turn on Lovable AI for this project, or connect your own AI account."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Which AI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "AI",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: provider,
							onChange: (e) => setProvider(e.target.value),
							className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
							children: Object.keys(AI_PROVIDERS).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: AI_PROVIDERS[k].label
							}, k))
						})
					}),
					own && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: s.hasKey && s.provider === provider ? "API key (a key is saved; type a new one to replace it)" : `API key (from ${AI_PROVIDERS[provider].keyHelp})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "password",
							autoComplete: "off",
							value: key,
							onChange: (e) => setKey(e.target.value),
							placeholder: "Paste the key"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Model (leave empty for ${AI_PROVIDERS[provider].model})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: model,
							onChange: (e) => setModel(e.target.value)
						})
					}),
					!own && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Monthly limit for the built-in AI, in $ (empty = no limit)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "1",
							min: "0",
							value: cap,
							onChange: (e) => setCap(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void save(),
							disabled: busy,
							children: busy ? "Saving…" : "Save"
						}), own && s.hasKey && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => void save(true),
							disabled: busy,
							children: "Remove the saved key"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Keys are kept on the server and are never shown again in the app."
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "pt-2 font-semibold",
			children: "Recent AI use"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [uses.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-6 text-center text-muted-foreground",
				children: "None yet."
			}), uses.data?.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-36 text-xs",
						children: new Date(u.created_at).toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							FEATURE[u.feature] ?? u.feature,
							" · ",
							u.pages,
							" page",
							u.pages === 1 ? "" : "s",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [u.model, u.own_key ? " · your own account" : ""]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: u.own_key ? "" : usd(Number(u.cost_usd))
					})
				]
			}, u.id))]
		})
	] });
}
//#endregion
export { AiPage as component };
