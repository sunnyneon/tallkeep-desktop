//#region ../../node_modules/.nitro/vite/services/ssr/assets/stockdocs-mmIhxNRj.js
var KIND = {
	adjust: {
		title: "Adjust Stock",
		one: "Stock adjustment",
		counter: "stock_adjust",
		url: "/adjust",
		help: "Fix stock numbers: type the new quantity for each item and place, then press Save and complete."
	},
	transfer: {
		title: "Transfer Stock",
		one: "Stock transfer",
		counter: "stock_transfer",
		url: "/transfer",
		help: "Move items between places: pick from where, to where and how many, then press Save and complete."
	},
	count: {
		title: "Count Sheet",
		one: "Count sheet",
		counter: "stock_count",
		url: "/count",
		help: "Check that the numbers match your shelves. Add items by place, type what you count, then press Complete and fix stock."
	}
};
//#endregion
export { KIND as t };
