import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/realestate-DQ-XkZ06.js
var CHANNEL = {
	airbnb: {
		label: "Airbnb",
		color: "bg-rose-500"
	},
	vrbo: {
		label: "VRBO",
		color: "bg-blue-600"
	},
	booking: {
		label: "Booking.com",
		color: "bg-indigo-700"
	},
	direct: {
		label: "Direct",
		color: "bg-emerald-600"
	},
	other: {
		label: "Other",
		color: "bg-slate-500"
	}
};
/** All stays (money as numbers), newest check-in first. */
async function loadStays() {
	const rows = await fetchAll("stays");
	const money = [
		"rent",
		"cleaning_fee",
		"other_fees",
		"taxes",
		"platform_fee",
		"payout"
	];
	for (const r of rows) for (const k of money) r[k] = Number(r[k] ?? 0);
	return rows.sort((a, b) => b.check_in.localeCompare(a.check_in));
}
var PROPERTY_KIND = {
	residential: "Residential",
	commercial: "Commercial",
	land: "Land",
	other: "Other"
};
var CHARGE_KIND = {
	rent: "Rent",
	late_fee: "Late fee",
	deposit: "Security deposit",
	other: "Other charge"
};
/** Everything real estate in one go (small tables). */
function useRealEstate(enabled = true) {
	return useQuery({
		queryKey: ["real-estate"],
		enabled,
		queryFn: async () => {
			const [properties, units, tenants, leases] = await Promise.all([
				fetchAll("properties"),
				fetchAll("units"),
				fetchAll("tenants"),
				fetchAll("leases")
			]);
			const num = (r, keys) => {
				for (const k of keys) if (r[k] != null) r[k] = Number(r[k]);
				return r;
			};
			leases.forEach((l) => num(l, [
				"rent",
				"deposit",
				"late_fee"
			]));
			units.forEach((u) => num(u, [
				"market_rent",
				"bedrooms",
				"bathrooms",
				"nightly_rate",
				"cleaning_fee",
				"lodging_tax_pct"
			]));
			properties.sort((a, b) => a.name.localeCompare(b.name));
			units.sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true }));
			tenants.sort((a, b) => a.name.localeCompare(b.name));
			const property = new Map(properties.map((p) => [p.id, p]));
			const unit = new Map(units.map((u) => [u.id, u]));
			const tenant = new Map(tenants.map((t) => [t.id, t]));
			const lease = new Map(leases.map((l) => [l.id, l]));
			/** The active lease in a unit, if any. */
			const current = (unitId) => leases.find((l) => l.unit_id === unitId && l.status === "active") ?? null;
			const unitLabel = (unitId) => {
				const u = unit.get(unitId);
				if (!u) return "";
				const p = property.get(u.property_id);
				return p ? `${p.name} · ${u.name}` : u.name;
			};
			return {
				properties,
				units,
				tenants,
				leases,
				property,
				unit,
				tenant,
				lease,
				current,
				unitLabel
			};
		}
	});
}
async function loadCharges(onlyOpen) {
	const out = [];
	for (let i = 0;; i += 1e3) {
		let q = db.from("rent_charges").select("*").order("due_date", { ascending: false }).range(i, i + 999);
		if (onlyOpen) q = q.eq("status", "open");
		const { data, error } = await q;
		if (error) throw error;
		const rows = data ?? [];
		out.push(...rows.map((r) => ({
			...r,
			amount: Number(r.amount),
			amount_paid: Number(r.amount_paid),
			balance: Number(r.balance)
		})));
		if (rows.length < 1e3) break;
	}
	return out;
}
function refreshRealEstate(qc) {
	qc.invalidateQueries({ queryKey: ["real-estate"] });
	qc.invalidateQueries({ queryKey: ["rent-charges"] });
	qc.invalidateQueries({ queryKey: ["stays"] });
	qc.invalidateQueries({ queryKey: ["account-totals"] });
}
//#endregion
export { loadStays as a, loadCharges as i, CHARGE_KIND as n, refreshRealEstate as o, PROPERTY_KIND as r, useRealEstate as s, CHANNEL as t };
