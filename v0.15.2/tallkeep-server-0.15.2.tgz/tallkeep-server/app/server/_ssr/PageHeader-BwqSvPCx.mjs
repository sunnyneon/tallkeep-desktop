import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PageHeader-BwqSvPCx.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ title, text, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "border-l-4 border-[var(--section)] pl-3 font-display text-3xl font-bold tracking-tight sm:text-4xl md:sr-only",
				children: title
			}), text && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted-foreground md:mt-0 md:text-sm",
				children: text
			})]
		}), actions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-2",
			children: actions
		})]
	});
}
function Page({ children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `mx-auto ${wide ? "max-w-[1600px]" : "max-w-6xl"} space-y-6 px-4 py-6 sm:px-8 md:py-5`,
		children
	});
}
//#endregion
export { PageHeader as n, Page as t };
