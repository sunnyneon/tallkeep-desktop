//#region ../../node_modules/.nitro/vite/services/ssr/assets/zone.server-Do4zmXJ2.js
/** Server-side check: does this user have the section (admins and full staff always do)? */
async function requireZone(userId, zones, what) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("*").eq("user_id", userId);
	if (!(data ?? []).some((r) => r.role === "admin" || r.zones == null || r.zones.some((z) => zones.includes(z)))) throw new Error(`You don't have access to ${what}.`);
}
//#endregion
export { requireZone };
