//#region ../../node_modules/.nitro/vite/services/ssr/assets/search-DEWqelr9.js
/**
* One smart search for every list in the app.
* Every word you type must be found (in any order). Best matches come first:
* names that start with what you typed, then names with a word starting with it,
* then names that just contain it. "NBM" finds "NBM Inc.", "ver mod" finds
* "Versa E Mini Module".
*/
var ID = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
var norm = (s) => s.toLowerCase().replace(ID, " ").replace(/[^\p{L}\p{N}.#/-]+/gu, " ").trim();
/** 0 = no match. Higher is better. `name` is ranked above `extra` (description, phone...). */
function matchScore(query, name, extra = "") {
	const words = norm(query).split(" ").filter(Boolean);
	if (!words.length) return 1;
	const n = norm(name);
	const all = `${n} ${norm(extra)}`;
	if (!words.every((w) => all.includes(w))) return 0;
	const q = words.join(" ");
	if (n === q) return 1;
	if (n.startsWith(q)) return .95;
	const starts = (hay, w) => hay.startsWith(w) || hay.includes(` ${w}`);
	if (words.every((w) => starts(n, w))) return n.startsWith(words[0]) ? .9 : .8;
	if (words.every((w) => n.includes(w))) return .6;
	if (words.every((w) => starts(all, w))) return .4;
	return .2;
}
/** Filter for cmdk <Command>: same rules, used by every searchable menu. */
function cmdkFilter(value, search, keywords) {
	return matchScore(search, value, (keywords ?? []).join(" "));
}
/** Filter and sort a list by the smart search. Keeps the original order for ties. */
function smartSearch(list, query, name, extra = () => "") {
	if (!query.trim()) return list;
	return list.map((x, i) => ({
		x,
		i,
		s: matchScore(query, name(x), extra(x))
	})).filter((r) => r.s > 0).sort((a, b) => b.s - a.s || a.i - b.i).map((r) => r.x);
}
//#endregion
export { smartSearch as n, cmdkFilter as t };
