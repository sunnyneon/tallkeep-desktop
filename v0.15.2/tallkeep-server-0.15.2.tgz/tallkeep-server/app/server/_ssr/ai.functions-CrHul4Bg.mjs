import { t as AI_PROVIDERS } from "./ai-C4gd9Sqm.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai.functions-CrHul4Bg.js
async function companyOf(context) {
	const { data } = await context.supabase.rpc("active_company");
	if (!data) throw new Error("No company chosen.");
	return data;
}
var monthStart = () => {
	const d = /* @__PURE__ */ new Date();
	return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString();
};
/** What this company's AI looks like right now (never the key itself). */
var aiStatus_createServerFn_handler = createServerRpc({
	id: "eb2ee64070a95f5ca231302b02ebc4033bc4338affec0d905e7b745c92a76c32",
	name: "aiStatus",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiStatus.__executeServer(opts));
var aiStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(aiStatus_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const co = await companyOf(context);
	const admin = supabaseAdmin;
	const [s, k, u] = await Promise.all([
		admin.from("ai_settings").select("provider,model,monthly_cap_usd").eq("company_id", co).maybeSingle(),
		admin.from("ai_keys").select("company_id").eq("company_id", co).maybeSingle(),
		admin.from("ai_usage").select("cost_usd,pages,own_key").eq("company_id", co).gte("created_at", monthStart())
	]);
	const provider = s.data?.["provider"] || "vooska";
	const rows = u.data ?? [];
	return {
		provider,
		model: s.data?.["model"] || AI_PROVIDERS[provider].model,
		cap: s.data?.["monthly_cap_usd"] == null ? null : Number(s.data["monthly_cap_usd"]),
		hasKey: !!k.data,
		builtInReady: !!process.env["LOVABLE_API_KEY"],
		monthCost: rows.filter((r) => !r["own_key"]).reduce((t, r) => t + Number(r["cost_usd"]), 0),
		monthPages: rows.reduce((t, r) => t + Number(r["pages"]), 0),
		monthUses: rows.length
	};
});
/** Choose the AI for this company. Admins or staff with the Accounting section. */
var aiSave_createServerFn_handler = createServerRpc({
	id: "cf6f48d63d7d776519762389066263927129c6ba829b48eeab381d2ca77616fa",
	name: "aiSave",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiSave.__executeServer(opts));
var aiSave = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!(d.provider in AI_PROVIDERS)) throw new Error("Unknown AI.");
	if (d.cap != null && !(d.cap >= 0)) throw new Error("The monthly limit must be 0 or more.");
	if (d.key && d.key.length > 400) throw new Error("That key is too long.");
	return d;
}).handler(aiSave_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone } = await import("./zone.server-Do4zmXJ2.mjs");
	await requireZone(context.userId, ["Accounting"], "AI settings");
	const co = await companyOf(context);
	const admin = supabaseAdmin;
	const s = await admin.from("ai_settings").upsert({
		company_id: co,
		provider: data.provider,
		model: data.model.trim() || null,
		monthly_cap_usd: data.cap,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	});
	if (s.error) throw new Error(s.error.message);
	if (data.key === "") await admin.from("ai_keys").delete().eq("company_id", co);
	else if (data.key) {
		const k = await admin.from("ai_keys").upsert({
			company_id: co,
			api_key: data.key.trim(),
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		if (k.error) throw new Error(k.error.message);
	}
	return { ok: true };
});
var PROMPTS = {
	sort: `You sort business paperwork. Look at the first page(s) and say what it is, and read the key
facts. Return JSON only:
{"kind":"bank_statement"|"card_statement"|"receipt"|"bill"|"check"|"other",
 "issuer":"bank, card company, store or vendor name"|null,
 "account_last4":"last 4 digits of the bank or card account on a statement"|null,
 "period_end":"YYYY-MM-DD"|null,
 "vendor":"…"|null,"date":"YYYY-MM-DD"|null,"due_date":"YYYY-MM-DD"|null,"total":number|null,
 "tax":number|null,"bill_number":"…"|null,"category":"short guess like Supplies, Utilities, Rent"|null,
 "payer":"…"|null,"amount":number|null,"check_number":"…"|null,"memo":"…"|null,
 "description":"one short line saying what it is"}
kind: bank_statement = a bank account statement with many transactions; card_statement = a credit
card statement; receipt = proof of something already paid (store or online receipt, paid
invoice); bill = an invoice or bill that still has to be paid (shows an amount due or a due date);
check = a paper check someone wrote to this business; other = anything else.
total = the amount paid (receipt) or the amount due (bill). Never return full account, card or
routing numbers: only the last 4 digits.`,
	statement: `You read bank and credit card statements. Return JSON only:
{"account_kind":"bank"|"credit_card","period_end":"YYYY-MM-DD"|null,"ending_balance":number|null,
 "lines":[{"date":"YYYY-MM-DD","description":"…","amount":number,"ref":"check number or null"}]}
Rules: one entry per transaction line, in statement order. Money INTO the account is positive,
money OUT is negative (for a credit card: purchases and fees negative, payments and refunds
positive). Skip balances, subtotals, headers and summaries. Use the statement's year for dates.
Copy descriptions as printed (no card numbers).`,
	receipt: `You read store receipts and vendor invoices. Return JSON only:
{"vendor":"…"|null,"date":"YYYY-MM-DD"|null,"total":number|null,"tax":number|null,
 "payment":"card"|"cash"|"check"|"other"|null,"card_last4":"1234"|null,
 "category":"short guess like Supplies, Fuel, Meals, Repairs"|null,"items":"one short line"|null}
total = the amount actually paid, including tax and tip.`,
	check: `You read a paper check that a business RECEIVED from its customer. Return JSON only:
{"payer":"…"|null,"amount":number|null,"date":"YYYY-MM-DD"|null,"check_number":"…"|null,
 "memo":"…"|null,"bank":"…"|null}
payer = the person or company that wrote the check (printed top left), not the bank and not who it
is paid to. amount = the number in the amount box. check_number = the number at the top right.
memo = the memo line, often an invoice number. Never return account or routing numbers.`
};
/** Read statement pages or a receipt with AI. Logs the use; stops at the monthly limit. */
var aiRead_createServerFn_handler = createServerRpc({
	id: "add849362d949ebbc4eb83205c60058bb0fff83a0b7d10809a072293a387221a",
	name: "aiRead",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiRead.__executeServer(opts));
var aiRead = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!PROMPTS[d.feature]) throw new Error("Unknown job.");
	if (!d.images.length) throw new Error("Nothing to read.");
	if (d.images.length > 12) throw new Error("Too many pages at once (12 at most).");
	if (d.images.reduce((t, i) => t + i.length, 0) > 18e6) throw new Error("These pages are too big. Try fewer pages at a time.");
	if (!d.images.every((i) => /^data:image\/(jpeg|png|webp);base64,/.test(i))) throw new Error("Pages must be images.");
	return d;
}).handler(aiRead_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone } = await import("./zone.server-Do4zmXJ2.mjs");
	await requireZone(context.userId, ["Accounting"], "reading statements and receipts");
	const co = await companyOf(context);
	const admin = supabaseAdmin;
	const [s, k] = await Promise.all([admin.from("ai_settings").select("provider,model,monthly_cap_usd").eq("company_id", co).maybeSingle(), admin.from("ai_keys").select("api_key").eq("company_id", co).maybeSingle()]);
	const provider = s.data?.["provider"] || "vooska";
	const p = AI_PROVIDERS[provider];
	const own = provider !== "vooska";
	const key = own ? k.data?.["api_key"] : process.env["LOVABLE_API_KEY"];
	if (!key) throw new Error(own ? "Add your AI key in Settings → AI first." : "The built-in AI isn't turned on yet. Turn on Lovable AI for this project.");
	const model = s.data?.["model"] || process.env["AI_MODEL"] || p.model;
	const cap = s.data?.["monthly_cap_usd"];
	if (!own && cap != null) {
		const { data: used } = await admin.from("ai_usage").select("cost_usd").eq("company_id", co).eq("own_key", false).gte("created_at", monthStart());
		if ((used ?? []).reduce((t, r) => t + Number(r["cost_usd"]), 0) >= Number(cap)) throw new Error("This month's AI limit is used up. Raise it in Settings → AI.");
	}
	const res = await fetch(p.url, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${key}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model,
			messages: [{
				role: "system",
				content: PROMPTS[data.feature]
			}, {
				role: "user",
				content: [{
					type: "text",
					text: data.hint || "Read this."
				}, ...data.images.map((url) => ({
					type: "image_url",
					image_url: { url }
				}))]
			}],
			response_format: { type: "json_object" }
		})
	});
	const body = await res.json().catch(() => ({}));
	if (!res.ok) {
		const msg = typeof body.error === "string" ? body.error : body.error?.message;
		if (res.status === 429) throw new Error("The AI is busy. Try again in a minute.");
		if (res.status === 402) throw new Error("AI credits are used up. Add credits in Lovable.");
		throw new Error(`The AI couldn't read it (${res.status}${msg ? `: ${msg}` : ""}).`);
	}
	const inTok = body.usage?.prompt_tokens ?? 0;
	const outTok = body.usage?.completion_tokens ?? 0;
	const rateIn = Number(process.env["AI_COST_IN_PER_M"] ?? .3);
	const rateOut = Number(process.env["AI_COST_OUT_PER_M"] ?? 2.5);
	await admin.from("ai_usage").insert({
		company_id: co,
		user_id: context.userId,
		feature: data.feature,
		provider,
		model,
		pages: data.images.length,
		input_tokens: inTok,
		output_tokens: outTok,
		cost_usd: (inTok * rateIn + outTok * rateOut) / 1e6,
		own_key: own
	});
	const text = (body.choices?.[0]?.message?.content ?? "").replace(/^```(json)?|```$/g, "").trim();
	try {
		JSON.parse(text);
	} catch {
		throw new Error("The AI's answer wasn't readable. Try again.");
	}
	return text;
});
//#endregion
export { aiRead_createServerFn_handler, aiSave_createServerFn_handler, aiStatus_createServerFn_handler };
