import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { at as Lock, st as LoaderCircle, tn as Check } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as checkTesterCode } from "./testers.functions-V-g6Iwz2.mjs";
import { getBuyInfo, priceFor, startCheckout } from "./buy.functions-DF2PRswO.mjs";
import { n as Route } from "./buy-Ccc7zCGs.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy-DUHZ2e3J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Buy Tallkeep Desktop: no sign-in, pay with Stripe, the key comes by email. */
var usd = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
});
function BuyFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "https://tallkeep.com",
				className: "inline-block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-light.svg",
					alt: "Tallkeep",
					className: "h-9 dark:hidden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-dark.svg",
					alt: "Tallkeep",
					className: "hidden h-9 dark:block"
				})]
			}), children]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: label
		}), children]
	});
}
function BuyPage() {
	const { data: info, isLoading } = useQuery({
		queryKey: ["buy-info"],
		queryFn: () => getBuyInfo()
	});
	const search = Route.useSearch();
	const [f, setF] = (0, import_react.useState)({
		to: "",
		email: "",
		companies: "",
		users: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)((search.code ?? "").toUpperCase());
	const codeNow = code.trim().toUpperCase();
	const { data: tester } = useQuery({
		queryKey: ["tester-code", codeNow],
		enabled: /^TEST-[A-Z0-9]{6}$/.test(codeNow),
		queryFn: () => checkTesterCode({ data: { code: codeNow } })
	});
	if (isLoading || !info) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96 rounded-2xl" }) });
	const companies = Math.max(Number(f.companies) || info.baseCompanies, info.baseCompanies);
	const users = Math.max(Number(f.users) || info.baseUsers, info.baseUsers);
	const off = tester?.ok ? 1 - tester.pct / 100 : 1;
	const t = tester?.ok ? {
		...info,
		base: Math.floor(info.regularBase * off),
		founders: false,
		extraCompany: Math.floor(info.extraCompany * off),
		extraUser: Math.floor(info.extraUser * off)
	} : info;
	const p = priceFor(t, companies, users);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const r = await startCheckout({ data: {
				to: f.to,
				email: f.email,
				companies,
				users,
				origin: window.location.origin,
				...tester?.ok ? { code: codeNow } : {}
			} });
			window.location.href = r.url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Buy Tallkeep Desktop"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Pay once. Your books stay on your own computer. Your license key arrives by email right after you pay."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1.5 text-sm",
				children: [
					`${info.baseCompanies} ${info.baseCompanies === 1 ? "company" : "companies"} and ${info.baseUsers} ${info.baseUsers === 1 ? "person" : "people"} included`,
					"Sales, purchasing, inventory, banking and accounting",
					"1 year of updates included",
					"Works on your office network: other computers and phones connect to it"
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 h-4 w-4 shrink-0 text-emerald-600" }),
						" ",
						t
					]
				}, t))
			}),
			!info.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: [
					"Buying online opens soon. Email",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline",
						href: "mailto:hello@tallkeep.com",
						children: "hello@tallkeep.com"
					}),
					" ",
					"and we'll set you up."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Business name (shows on the license)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.to,
									onChange: (e) => setF({
										...f,
										to: e.target.value
									}),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Your email (the key is sent here)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: f.email,
									onChange: (e) => setF({
										...f,
										email: e.target.value
									}),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "How many companies",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: info.baseCompanies,
									placeholder: String(info.baseCompanies),
									value: f.companies,
									onChange: (e) => setF({
										...f,
										companies: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "How many people will sign in",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: info.baseUsers,
									placeholder: String(info.baseUsers),
									value: f.users,
									onChange: (e) => setF({
										...f,
										users: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Early access code (optional)",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: code,
							onChange: (e) => setCode(e.target.value.toUpperCase()),
							placeholder: "TEST-XXXXXX"
						}), codeNow && /^TEST-[A-Z0-9]{6}$/.test(codeNow) && tester && !tester.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-destructive",
							children: "That code isn't right, or it was already used."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 rounded-xl bg-muted/40 p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Tallkeep Desktop",
									tester?.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-2 rounded bg-emerald-100 px-1.5 py-0.5 text-xs text-emerald-800",
										children: [
											"Early access price: ",
											tester.pct,
											"% off"
										]
									}),
									t.founders && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-2 rounded bg-emerald-100 px-1.5 py-0.5 text-xs text-emerald-800",
										children: [
											"Founders price until",
											" ",
											(/* @__PURE__ */ new Date(`${info.foundersUntil}T12:00:00`)).toLocaleDateString("en-US", {
												month: "short",
												day: "numeric",
												year: "numeric"
											})
										]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [(t.founders || tester?.ok) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("s", {
									className: "mr-2 text-muted-foreground",
									children: usd(info.regularBase)
								}), usd(t.base)] })]
							}),
							p.extraC > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									p.extraC,
									" extra ",
									p.extraC === 1 ? "company" : "companies"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(p.extraC * t.extraCompany) })]
							}),
							p.extraU > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									p.extraU,
									" extra ",
									p.extraU === 1 ? "person" : "people"
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(p.extraU * t.extraUser) })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between border-t pt-2 text-base font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total, one time" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(p.total) })]
							}),
							info.updatesYearly > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "pt-1 text-xs text-muted-foreground",
								children: [
									"Updates after the first year are optional: ",
									usd(info.updatesYearly),
									" a year. Tallkeep keeps working without them."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						size: "lg",
						className: "w-full",
						disabled: busy,
						children: [
							busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
							"Pay ",
							usd(p.total),
							" with card"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "Secure payment by Stripe. Questions? hello@tallkeep.com"
					})
				]
			})
		]
	}) });
}
//#endregion
export { BuyFrame, BuyPage as component };
