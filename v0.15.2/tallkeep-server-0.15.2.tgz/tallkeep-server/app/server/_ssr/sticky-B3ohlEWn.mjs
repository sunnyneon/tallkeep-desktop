import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sticky-B3ohlEWn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* State that survives opening a record and coming back (search words, filters): kept for this
* browser tab in sessionStorage. Several screens can share one key (the Invoice List and the list
* on the left of an invoice share the same search).
*/
var EVENT = "tallkeep-sticky";
function read(key, initial) {
	try {
		const raw = sessionStorage.getItem(`sticky:${key}`);
		if (raw == null) return initial;
		const v = JSON.parse(raw);
		return initial && typeof initial === "object" && !Array.isArray(initial) ? {
			...initial,
			...v
		} : v;
	} catch {
		return initial;
	}
}
function useSticky(key, initial) {
	const [value, setValue] = (0, import_react.useState)(() => read(key, initial));
	(0, import_react.useEffect)(() => {
		const on = (e) => {
			if (e.detail === key) setValue(read(key, initial));
		};
		window.addEventListener(EVENT, on);
		return () => window.removeEventListener(EVENT, on);
	}, [key]);
	return [value, (0, import_react.useCallback)((v) => {
		setValue((old) => {
			const next = typeof v === "function" ? v(old) : v;
			try {
				sessionStorage.setItem(`sticky:${key}`, JSON.stringify(next));
				queueMicrotask(() => window.dispatchEvent(new CustomEvent(EVENT, { detail: key })));
			} catch {}
			return next;
		});
	}, [key])];
}
//#endregion
export { useSticky as t };
