//#region ../../node_modules/.nitro/vite/services/ssr/assets/quickbooks-DDZqKZVM.js
/** Every list in an IIF file, by its keyword: { CUST: [...], VEND: [...], INVITEM: [...] }. */
function parseIif(text) {
	const out = {};
	const headers = {};
	for (const raw of text.split(/\r?\n/)) {
		if (!raw.trim()) continue;
		const cells = raw.split("	").map((c) => c.replace(/^"(.*)"$/, "$1").trim());
		const key = cells[0] ?? "";
		if (key.startsWith("!")) {
			headers[key.slice(1)] = cells.slice(1);
			continue;
		}
		const cols = headers[key];
		if (!cols) continue;
		const row = {};
		cols.forEach((c, i) => row[c] = cells[i + 1] ?? "");
		(out[key] ??= []).push(row);
	}
	return out;
}
/** A CSV file as rows of cells (handles quotes and commas inside quotes). */
function parseCsv(text) {
	const rows = [];
	let row = [];
	let cell = "";
	let q = false;
	for (let i = 0; i < text.length; i++) {
		const ch = text[i];
		if (q) if (ch === "\"" && text[i + 1] === "\"") {
			cell += "\"";
			i++;
		} else if (ch === "\"") q = false;
		else cell += ch;
		else if (ch === "\"") q = true;
		else if (ch === ",") {
			row.push(cell);
			cell = "";
		} else if (ch === "\n" || ch === "\r") {
			if (ch === "\r" && text[i + 1] === "\n") i++;
			row.push(cell);
			rows.push(row);
			row = [];
			cell = "";
		} else cell += ch;
	}
	if (cell || row.length) {
		row.push(cell);
		rows.push(row);
	}
	return rows.map((r) => r.map((c) => c.trim()));
}
/** "1,234.50" / "(12.00)" / "-5" → number (NaN when not a number). */
function num(v) {
	if (!v) return NaN;
	const neg = /^\(.*\)$/.test(v);
	const n = Number(v.replace(/[(),$\s]/g, ""));
	return neg ? -n : n;
}
/** Address lines from numbered columns (BADDR1..BADDR5) as one block of text. */
var lines = (r, prefix) => [
	1,
	2,
	3,
	4,
	5
].map((i) => r[`${prefix}${i}`] ?? "").filter((x) => x.trim()).join("\n") || null;
/** "LED Modules:Indoor:P2.5" → { name: "P2.5", parent: "LED Modules:Indoor" } */
var splitName = (full) => {
	const parts = full.split(":");
	return {
		name: parts.at(-1).trim(),
		parent: parts.slice(0, -1).join(":").trim()
	};
};
/** Find the row that holds these column titles; returns its index and a column finder. */
function findHeader(rows, must) {
	const lc = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
	const i = rows.findIndex((r) => must.every((m) => r.some((c) => lc(c) === lc(m))));
	if (i < 0) return null;
	const col = (name) => rows[i].findIndex((c) => lc(c) === lc(name));
	return {
		index: i,
		col
	};
}
/** Is this the QuickBooks date format (MM/DD/YYYY)? → ISO date */
function qbDate(v) {
	const m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(v ?? "");
	if (!m) return null;
	return `${m[3].length === 2 ? `20${m[3]}` : m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
}
/** QuickBooks account types (IIF ACCNTTYPE) → our account kind. NONPOSTING is skipped. */
var QB_ACCOUNT_KIND = {
	BANK: "bank",
	AR: "ar",
	OCASSET: "other_asset",
	FIXASSET: "fixed_asset",
	OASSET: "other_asset",
	AP: "ap",
	CCARD: "credit_card",
	OCLIAB: "other_liability",
	LTLIAB: "long_term_liability",
	EQUITY: "equity",
	INC: "income",
	COGS: "cogs",
	EXP: "expense",
	EXINC: "other_income",
	EXEXP: "other_expense"
};
/**
* An account as QuickBooks reports print it: "Utilities:Gas", "6000 · Utilities:6020 · Gas"
* or "10100 · Checking". → the number (if shown) and the full name without numbers.
*/
function qbAccountLabel(label) {
	const parts = label.split(":").map((p) => p.trim());
	let number = null;
	const names = parts.map((p, i) => {
		const m = /^(\S+)\s+·\s+(.*)$/.exec(p);
		if (!m) return p;
		if (i === parts.length - 1) number = m[1];
		return m[2].trim();
	});
	return {
		number,
		name: names.join(":"),
		last: names.at(-1) ?? ""
	};
}
/** Find our account for a QuickBooks label: by number, then full name, then last part. */
function accountFinder(accounts) {
	const lc = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
	const byNum = new Map(accounts.filter((a) => a.number).map((a) => [a.number, a.id]));
	const byName = new Map(accounts.map((a) => [lc(a.name), a.id]));
	const byLast = /* @__PURE__ */ new Map();
	for (const a of accounts) {
		const k = lc(a.name.split(":").at(-1) ?? a.name);
		byLast.set(k, byLast.has(k) ? null : a.id);
	}
	return (label) => {
		const l = qbAccountLabel(label);
		if (l.number && byNum.has(l.number)) return byNum.get(l.number);
		return byName.get(lc(l.name)) ?? byLast.get(lc(l.last)) ?? null;
	};
}
/** Trial Balance report (CSV): account label, debit, credit. */
function parseTrialBalance(csv) {
	const h = findHeader(csv, ["Debit", "Credit"]);
	if (!h) return null;
	const dc = h.col("Debit");
	const cc = h.col("Credit");
	const out = [];
	for (const r of csv.slice(h.index + 1)) {
		const label = r.slice(0, dc).find((x) => x) ?? "";
		if (!label || /^total/i.test(label)) continue;
		const d = num(r[dc]);
		const c = num(r[cc]);
		const debit = Number.isFinite(d) ? d : 0;
		const credit = Number.isFinite(c) ? c : 0;
		if (!debit && !credit) continue;
		out.push({
			account: label,
			debit,
			credit
		});
	}
	return out;
}
/**
* Journal report (CSV, Reports → Accountant & Taxes → Journal): every transaction with its
* lines. The first line of a transaction carries Trans #, Type, Date and Num; the next lines
* leave them empty.
*/
function parseJournal(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Account",
		"Debit",
		"Credit"
	]);
	if (!h) return null;
	const c = {
		trans: h.col("Trans #"),
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: h.col("Name"),
		memo: h.col("Memo"),
		account: h.col("Account"),
		debit: h.col("Debit"),
		credit: h.col("Credit")
	};
	const out = [];
	let cur = null;
	for (const r of csv.slice(h.index + 1)) {
		const at = (i) => i >= 0 ? r[i] ?? "" : "";
		const date = qbDate(at(c.date));
		if (!!date && (at(c.type) || at(c.trans))) {
			cur = {
				trans: at(c.trans),
				type: at(c.type),
				date,
				num: at(c.num),
				lines: []
			};
			out.push(cur);
		}
		const account = at(c.account);
		if (!cur || !account) continue;
		const d = num(at(c.debit));
		const k = num(at(c.credit));
		const debit = Number.isFinite(d) ? d : 0;
		const credit = Number.isFinite(k) ? k : 0;
		if (!debit && !credit) continue;
		cur.lines.push({
			account,
			name: at(c.name),
			memo: at(c.memo),
			debit,
			credit
		});
	}
	return out.filter((t) => t.lines.length);
}
/** Unpaid Bills Detail report (CSV): bills grouped under each vendor. */
function parseUnpaidBills(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Open Balance"
	]);
	if (!h) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		due: h.col("Due Date"),
		bal: h.col("Open Balance")
	};
	const out = [];
	let vendor = "";
	for (const r of csv.slice(h.index + 1)) {
		const type = r[c.type] ?? "";
		if (!type) {
			const head = r.slice(0, c.type).find((x) => x) ?? "";
			if (head && !/^total/i.test(head)) vendor = head;
			continue;
		}
		if (!/bill/i.test(type) || /pmt|payment|credit/i.test(type)) continue;
		const balance = num(r[c.bal]);
		if (!(balance > 0)) continue;
		out.push({
			vendor: vendor.split(":")[0].trim(),
			num: c.num >= 0 ? r[c.num] ?? "" : "",
			date: qbDate(r[c.date]),
			due: c.due >= 0 ? qbDate(r[c.due]) : null,
			balance
		});
	}
	return out;
}
/**
* Sales by Customer Detail report (CSV, Reports → Sales → Sales by Customer Detail): every
* invoice, sales receipt and credit memo line, grouped under each customer. Sales tax lines are
* not in this report.
*/
function parseSalesDetail(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Num",
		"Item",
		"Amount"
	]);
	if (!h) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: h.col("Name"),
		memo: h.col("Memo"),
		item: h.col("Item"),
		qty: h.col("Qty"),
		price: h.col("Sales Price"),
		amount: h.col("Amount")
	};
	const at = (r, i) => i >= 0 ? (r[i] ?? "").trim() : "";
	const kindOf = (t) => /^invoice$/i.test(t) ? "invoice" : /sales receipt/i.test(t) ? "receipt" : /credit memo/i.test(t) ? "credit" : null;
	const docs = /* @__PURE__ */ new Map();
	let current = "";
	for (const r of csv.slice(h.index + 1)) {
		const type = at(r, c.type);
		if (!type) {
			const head = r.slice(0, c.type).find((x) => x.trim())?.trim() ?? "";
			if (head && !/^total/i.test(head)) current = head;
			continue;
		}
		const kind = kindOf(type);
		const date = qbDate(at(r, c.date));
		if (!kind || !date) continue;
		const customer = (at(r, c.name) || current).split(":")[0].trim();
		const n = at(r, c.num);
		const k = `${kind}|${n || `${date}|${customer}`}`;
		let d = docs.get(k);
		if (!d) {
			d = {
				kind,
				num: n,
				date,
				customer,
				lines: []
			};
			docs.set(k, d);
		}
		const amount = num(at(r, c.amount));
		if (!Number.isFinite(amount) || amount === 0) continue;
		const q = num(at(r, c.qty));
		const p = num(at(r, c.price));
		const qty = Number.isFinite(q) && q !== 0 ? q : 1;
		d.lines.push({
			item: at(r, c.item),
			memo: at(r, c.memo),
			qty,
			price: Number.isFinite(p) && p !== 0 ? p : amount / qty,
			amount
		});
	}
	return [...docs.values()].filter((d) => d.lines.length);
}
/** Rows under customer / vendor headings: the heading is the row's party when Name is empty. */
function grouped(csv, typeCol, nameCol) {
	const out = [];
	let current = "";
	for (const r of csv) {
		if (!(r[typeCol] ?? "").trim()) {
			const head = r.slice(0, typeCol).find((x) => x.trim())?.trim() ?? "";
			if (head && !/^total/i.test(head)) current = head;
			continue;
		}
		const name = nameCol >= 0 ? (r[nameCol] ?? "").trim() : "";
		out.push({
			party: (name || current).split(":")[0].trim(),
			row: r
		});
	}
	return out;
}
/**
* Invoices and Received Payments report (CSV, Reports → Customers & Receivables): each invoice
* with the payments that paid it listed right under it.
*/
function parseInvoicePayments(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Num"
	]);
	if (!h) return null;
	const amt = [
		"Paid Amount",
		"Pmt Amount",
		"Amount"
	].map((n) => h.col(n)).find((i) => i >= 0) ?? -1;
	if (amt < 0) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: h.col("Name")
	};
	const out = [];
	let invoice = "";
	let party = "";
	for (const { party: p, row } of grouped(csv.slice(h.index + 1), c.type, c.name)) {
		const type = (row[c.type] ?? "").trim();
		if (p !== party) {
			party = p;
			invoice = "";
		}
		if (/^invoice$/i.test(type)) {
			invoice = (row[c.num] ?? "").trim();
			continue;
		}
		if (!/payment/i.test(type) || !invoice) continue;
		const date = qbDate((row[c.date] ?? "").trim());
		const a = Math.abs(num(row[amt]));
		if (!date || !Number.isFinite(a) || a === 0) continue;
		out.push({
			customer: p,
			invoice,
			date,
			num: c.num >= 0 ? (row[c.num] ?? "").trim() : "",
			amount: a
		});
	}
	return out;
}
/**
* Expenses by Vendor Detail report (CSV, Reports → Company & Financial): every bill, check and
* card charge, grouped under each vendor, one row per expense line.
*/
function parseVendorExpenses(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Account",
		"Amount"
	]);
	if (!h) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: h.col("Name"),
		memo: h.col("Memo"),
		account: h.col("Account"),
		split: h.col("Split"),
		amount: h.col("Amount")
	};
	const kindOf = (t) => /^bill$/i.test(t) ? "bill" : /^check$/i.test(t) ? "check" : /credit card charge/i.test(t) ? "card" : null;
	const docs = /* @__PURE__ */ new Map();
	for (const { party, row } of grouped(csv.slice(h.index + 1), c.type, c.name)) {
		const at = (i) => i >= 0 ? (row[i] ?? "").trim() : "";
		const type = kindOf(at(c.type));
		const date = qbDate(at(c.date));
		const amount = num(at(c.amount));
		if (!type || !date || !Number.isFinite(amount) || amount === 0) continue;
		const k = `${type}|${party}|${date}|${at(c.num)}`;
		let d = docs.get(k);
		if (!d) {
			d = {
				type,
				vendor: party,
				date,
				num: at(c.num),
				paidFrom: at(c.split),
				lines: []
			};
			docs.set(k, d);
		}
		d.lines.push({
			account: at(c.account),
			memo: at(c.memo),
			amount
		});
	}
	return [...docs.values()];
}
/** Memorized Transaction Listing (CSV, Lists → Memorized Transaction List → Reports button). */
function parseMemorized(csv) {
	const h = findHeader(csv, ["Type", "Amount"]);
	if (!h) return null;
	const nameCol = ["Transaction Name", "Name"].map((n) => h.col(n)).find((i) => i >= 0) ?? -1;
	const c = {
		type: h.col("Type"),
		account: h.col("Source Account"),
		amount: h.col("Amount"),
		freq: h.col("Frequency"),
		next: h.col("Next Date")
	};
	const every = (f) => /week/i.test(f) && !/2|two|bi/i.test(f) ? "week" : /month/i.test(f) && !/2|two|bi/i.test(f) ? "month" : /quarter/i.test(f) ? "quarter" : /year|annual/i.test(f) ? "year" : null;
	const out = [];
	for (const r of csv.slice(h.index + 1)) {
		const at = (i) => i >= 0 ? (r[i] ?? "").trim() : "";
		const t = at(c.type);
		const type = /^check$/i.test(t) ? "check" : /^bill$/i.test(t) ? "bill" : null;
		const e = every(at(c.freq));
		const name = at(nameCol) || r.slice(0, c.type).find((x) => x.trim())?.trim() || "";
		const amount = Math.abs(num(at(c.amount)));
		if (!type || !e || !name || !Number.isFinite(amount)) continue;
		out.push({
			name,
			type,
			account: at(c.account),
			amount,
			every: e,
			next: qbDate(at(c.next))
		});
	}
	return out;
}
/** The first column (of several names) that's in the header; -1 when none. */
function colOf(h, ...names) {
	for (const n of names) {
		const i = h.col(n);
		if (i >= 0) return i;
	}
	return -1;
}
var cell = (r, i) => i >= 0 ? (r[i] ?? "").trim() : "";
/**
* The Item List exported to Excel/CSV (Lists → Item List → Excel → Export all items): the
* details the IIF file doesn't have, like the barcode (UPC), the part number (MPN), the unit and
* the reorder levels.
*/
function parseItemList(csv) {
	const h = findHeader(csv, ["Item"]) ?? findHeader(csv, ["Name", "Type"]);
	if (!h) return null;
	const c = {
		item: colOf(h, "Item", "Name"),
		desc: colOf(h, "Description", "Sales Description"),
		pdesc: colOf(h, "Purchase Description"),
		cost: colOf(h, "Cost"),
		price: colOf(h, "Price", "Sales Price"),
		vendor: colOf(h, "Preferred Vendor"),
		min: colOf(h, "Reorder Pt (Min)", "Reorder Pt", "Reorder Point", "Reorder Point (Min)"),
		max: colOf(h, "Max", "Reorder Pt (Max)", "Max Reorder Point"),
		upc: colOf(h, "UPC", "Barcode", "Bar Code"),
		mpn: colOf(h, "MPN", "Manufacturer's Part Number", "Manufacturer Part Number"),
		unit: colOf(h, "U/M", "Unit of Measure", "U/M Set")
	};
	if (c.item < 0) return null;
	const n = (r, i) => {
		const v = num(cell(r, i));
		return Number.isFinite(v) ? v : null;
	};
	return csv.slice(h.index + 1).map((r) => ({
		item: cell(r, c.item),
		description: cell(r, c.desc),
		purchaseDesc: cell(r, c.pdesc),
		cost: n(r, c.cost),
		price: n(r, c.price),
		vendor: cell(r, c.vendor),
		reorderPoint: n(r, c.min),
		max: n(r, c.max),
		upc: cell(r, c.upc),
		mpn: cell(r, c.mpn),
		unit: cell(r, c.unit)
	})).filter((x) => x.item && !/^total/i.test(x.item));
}
/**
* Open estimates, sales orders and purchase orders, from a Transaction Detail report (Reports →
* Custom Reports → Transaction Detail) with the columns Type, Date, Num, Name, Memo, Item, Qty,
* Sales Price (or Cost Price) and Amount. The Open Purchase Orders Detail report works too (its
* Rcv'd column is kept). Rows without an item (the document's total line) are left out.
*/
function parseOpenDocs(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Num"
	]);
	if (!h) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: colOf(h, "Name", "Source Name"),
		memo: colOf(h, "Memo", "Description"),
		item: h.col("Item"),
		qty: colOf(h, "Qty", "Quantity"),
		price: colOf(h, "Sales Price", "Cost Price", "Rate", "Price"),
		amount: colOf(h, "Amount", "Open Balance"),
		rcvd: colOf(h, "Rcv'd", "Received")
	};
	if (c.item < 0 || c.amount < 0) return null;
	const kindOf = (t) => /estimate/i.test(t) ? "estimate" : /sales order/i.test(t) ? "sales_order" : /purchase order/i.test(t) ? "purchase_order" : null;
	const docs = /* @__PURE__ */ new Map();
	let party = "";
	for (const r of csv.slice(h.index + 1)) {
		const type = cell(r, c.type);
		if (!type) {
			const head = r.slice(0, Math.max(1, c.type)).find((x) => x.trim())?.trim() ?? "";
			if (head && !/^total/i.test(head)) party = head;
			continue;
		}
		const kind = kindOf(type);
		const date = qbDate(cell(r, c.date));
		if (!kind || !date) continue;
		const name = (cell(r, c.name) || party).split(":")[0].trim();
		const n = cell(r, c.num);
		const k = `${kind}|${n || `${date}|${name}`}`;
		let d = docs.get(k);
		if (!d) {
			d = {
				kind,
				num: n,
				date,
				name,
				memo: "",
				lines: []
			};
			docs.set(k, d);
		}
		const item = cell(r, c.item);
		const amount = Math.abs(num(cell(r, c.amount)));
		if (!item) {
			if (!d.memo) d.memo = cell(r, c.memo);
			continue;
		}
		if (!Number.isFinite(amount)) continue;
		const q = Math.abs(num(cell(r, c.qty)));
		const p = Math.abs(num(cell(r, c.price)));
		const rc = Math.abs(num(cell(r, c.rcvd)));
		const qty = Number.isFinite(q) && q !== 0 ? q : 1;
		d.lines.push({
			item,
			memo: cell(r, c.memo),
			qty,
			price: Number.isFinite(p) && p !== 0 ? p : amount / qty,
			amount,
			received: Number.isFinite(rc) ? rc : 0
		});
	}
	return [...docs.values()].filter((d) => d.lines.length);
}
/**
* A bank or card account's QuickReport (Chart of Accounts → the account → Reports → QuickReport)
* with its Clr column: which checks and deposits already cleared the bank.
*/
function parseRegisterReport(csv) {
	const h = findHeader(csv, [
		"Type",
		"Date",
		"Clr"
	]);
	if (!h) return null;
	const c = {
		type: h.col("Type"),
		date: h.col("Date"),
		num: h.col("Num"),
		name: h.col("Name"),
		clr: h.col("Clr"),
		amount: colOf(h, "Amount", "Debit"),
		credit: h.col("Credit")
	};
	const out = [];
	for (const r of csv.slice(h.index + 1)) {
		const date = qbDate(cell(r, c.date));
		if (!date || !cell(r, c.type)) continue;
		let amount = num(cell(r, c.amount));
		if (c.credit >= 0 && !Number.isFinite(amount)) amount = -num(cell(r, c.credit));
		if (!Number.isFinite(amount) || amount === 0) continue;
		out.push({
			type: cell(r, c.type),
			date,
			num: cell(r, c.num),
			name: cell(r, c.name),
			amount,
			cleared: cell(r, c.clr) !== "" && !/^(no|n|-)$/i.test(cell(r, c.clr))
		});
	}
	return out;
}
//#endregion
export { parseVendorExpenses as _, num as a, parseInvoicePayments as c, parseMemorized as d, parseOpenDocs as f, parseUnpaidBills as g, parseTrialBalance as h, lines as i, parseItemList as l, parseSalesDetail as m, accountFinder as n, parseCsv as o, parseRegisterReport as p, findHeader as r, parseIif as s, QB_ACCOUNT_KIND as t, parseJournal as u, qbDate as v, splitName as y };
