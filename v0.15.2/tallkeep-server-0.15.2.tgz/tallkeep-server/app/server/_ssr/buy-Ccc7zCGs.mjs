import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy-Ccc7zCGs.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./buy-DUHZ2e3J.mjs");
/** Buy Tallkeep Desktop: no sign-in, pay with Stripe, the key comes by email. */
var Route = createFileRoute("/buy")({
	ssr: false,
	validateSearch: (s) => typeof s["code"] === "string" ? { code: s["code"] } : {},
	head: () => ({ meta: [{ title: "Buy Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function BuyFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "https://tallkeep.com",
				className: "inline-block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-light.svg",
					alt: "Tallkeep",
					className: "h-9 dark:hidden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-dark.svg",
					alt: "Tallkeep",
					className: "hidden h-9 dark:block"
				})]
			}), children]
		})
	});
}
//#endregion
export { Route as n, BuyFrame as t };
