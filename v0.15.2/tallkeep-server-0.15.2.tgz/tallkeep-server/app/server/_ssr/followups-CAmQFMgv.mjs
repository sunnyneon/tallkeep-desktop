//#region ../../node_modules/.nitro/vite/services/ssr/assets/followups-CAmQFMgv.js
var DEFAULT_RULES = {
	followup_enabled: false,
	followup_days1: 14,
	followup_days2: 30,
	quote_close_days: 45,
	followup_auto_email: false
};
var ageDays = (iso, now = Date.now()) => Math.floor((now - new Date(iso).getTime()) / 864e5);
/** What a quote needs today: a 1st or 2nd follow-up, to be closed, or nothing. */
function stageOf(q, r, now = Date.now()) {
	if (q.status !== "quote" || q.number.startsWith("RMA-")) return null;
	const age = ageDays(q.order_date, now);
	const done = Number(q.followup_count ?? 0);
	if (age >= r.quote_close_days) return "close";
	if (age >= r.followup_days2 && done < 2) return "second";
	if (age >= r.followup_days1 && done < 1) return "first";
	return null;
}
function followupMessage(q, company, second) {
	const hi = q.contact_name || q.customer_name || "there";
	const offer = "If you'd like a new quote with different specs, are looking for a lower price, or have any questions, just reply to this email and we'll be happy to help.";
	return second ? `Hello ${hi},\n\nI wanted to follow up once more on our quote ${q.number}. Our quotes are good for 30 days, so if you'd like to go ahead, please let us know and we'll confirm pricing and lead time.\n\n${offer}\n\nThank you,\n${company}` : `Hello ${hi},\n\nI'm following up on our quote ${q.number}.\n\n${offer}\n\nThank you,\n${company}`;
}
/** Asking a customer about a past-due invoice (short, polite, easy to change before sending). */
function paymentFollowupMessage(o, company, balance, due, second) {
	return `Hello ${o.contact_name || o.customer_name || "there"},\n\n${second ? "Following up again on" : "A friendly reminder about"} invoice ${o.number}: ${balance} ${due ? `was due on ${due}` : "is still open"}. The invoice is attached.\n\nPlease send us the status of this payment. If you've already sent it, thank you, and please let us know the date and how it was paid.\n\nThank you,\n${company}`;
}
/** An invoice that is past its due date and not fully paid. */
var isPastDue = (o, today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)) => !!o.due_date && o.due_date < today && Number(o.balance) > .005 && ![
	"quote",
	"rma",
	"cancelled"
].includes(o.status);
//#endregion
export { paymentFollowupMessage as a, isPastDue as i, ageDays as n, stageOf as o, followupMessage as r, DEFAULT_RULES as t };
