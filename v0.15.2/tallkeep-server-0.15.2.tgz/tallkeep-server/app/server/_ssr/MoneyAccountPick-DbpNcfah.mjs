import { n as db } from "./db-zltnVrwr.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/MoneyAccountPick-DbpNcfah.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Which bank / credit card account money goes into or comes out of. Shown only to people who
* can see Accounting; otherwise the company's default bank account is used.
*/
function MoneyAccountPick({ label, value, onChange, cards = false }) {
	const { data: accounts } = useAccounts();
	const { data: def } = useQuery({
		queryKey: ["books-settings", "default-bank"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("default_bank_account_id").maybeSingle();
			return data?.default_bank_account_id ?? "";
		}
	});
	const list = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "other_asset" || cards && a.kind === "credit_card"));
	if (list.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			value: value || def || "",
			onValueChange: onChange,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Default bank account" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: a.id,
				children: accountLabel(a)
			}, a.id)) })]
		})]
	});
}
//#endregion
export { MoneyAccountPick as t };
