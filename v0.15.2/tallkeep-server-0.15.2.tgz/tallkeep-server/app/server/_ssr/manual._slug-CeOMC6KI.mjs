import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ManualFrame } from "./ManualFrame-ZWLGCAFh.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/manual._slug-CeOMC6KI.js
var import_jsx_runtime = require_jsx_runtime();
/** One manual article, open to everyone. */
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
	"That page isn't in the manual.",
	" ",
	/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/manual",
		className: "text-primary underline",
		children: "See all topics"
	})
] }) });
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
