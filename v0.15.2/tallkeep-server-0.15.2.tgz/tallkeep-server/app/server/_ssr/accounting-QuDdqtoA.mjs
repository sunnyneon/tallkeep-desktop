import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/accounting-QuDdqtoA.js
var TYPE_LABEL = {
	asset: "Assets",
	liability: "Liabilities",
	equity: "Equity",
	income: "Income",
	expense: "Expenses"
};
var TYPE_ORDER = [
	"asset",
	"liability",
	"equity",
	"income",
	"expense"
];
/** Kinds people pick from, with the type they belong to. */
var KINDS = [
	{
		kind: "bank",
		label: "Bank account",
		type: "asset"
	},
	{
		kind: "ar",
		label: "Accounts receivable",
		type: "asset"
	},
	{
		kind: "inventory",
		label: "Inventory",
		type: "asset"
	},
	{
		kind: "other_asset",
		label: "Other current asset",
		type: "asset"
	},
	{
		kind: "fixed_asset",
		label: "Fixed asset (equipment, vehicles)",
		type: "asset"
	},
	{
		kind: "ap",
		label: "Accounts payable",
		type: "liability"
	},
	{
		kind: "credit_card",
		label: "Credit card",
		type: "liability"
	},
	{
		kind: "other_liability",
		label: "Other current liability",
		type: "liability"
	},
	{
		kind: "long_term_liability",
		label: "Long-term liability (loans)",
		type: "liability"
	},
	{
		kind: "equity",
		label: "Equity",
		type: "equity"
	},
	{
		kind: "income",
		label: "Income",
		type: "income"
	},
	{
		kind: "other_income",
		label: "Other income",
		type: "income"
	},
	{
		kind: "cogs",
		label: "Cost of goods sold",
		type: "expense"
	},
	{
		kind: "expense",
		label: "Expense",
		type: "expense"
	},
	{
		kind: "other_expense",
		label: "Other expense",
		type: "expense"
	}
];
var kindLabel = (k) => KINDS.find((x) => x.kind === k)?.label ?? k;
/** Assets and expenses grow with debits; the rest with credits. */
var debitNormal = (t) => t === "asset" || t === "expense";
var balanceOf = (t, debit, credit) => debitNormal(t) ? debit - credit : credit - debit;
var accountLabel = (a) => a.number ? `${a.number} · ${a.name}` : a.name;
async function loadAccounts() {
	return (await fetchAll("accounts", "id,number,name,type,kind,key,description,is_active")).sort((a, b) => TYPE_ORDER.indexOf(a.type) - TYPE_ORDER.indexOf(b.type) || (a.number ?? "~").localeCompare(b.number ?? "~", void 0, { numeric: true }) || a.name.localeCompare(b.name));
}
function useAccounts() {
	return useQuery({
		queryKey: ["accounts"],
		queryFn: loadAccounts
	});
}
/** Debit/credit totals per account for a period (null = no limit). */
async function loadTotals(from, to) {
	const { data, error } = await db.rpc("account_totals", {
		_from: from,
		_to: to
	});
	if (error) throw error;
	const m = /* @__PURE__ */ new Map();
	for (const r of data ?? []) m.set(r.account_id, {
		debit: Number(r.debit),
		credit: Number(r.credit)
	});
	return m;
}
function useTotals(from, to) {
	return useQuery({
		queryKey: [
			"account-totals",
			from,
			to
		],
		queryFn: () => loadTotals(from, to)
	});
}
/** Balance of an account from a set of totals, in the account's natural sign. */
var balFrom = (totals) => (acc) => {
	const t = totals?.get(acc.id);
	return t ? balanceOf(acc.type, t.debit, t.credit) : 0;
};
var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
var yearStart = () => `${(/* @__PURE__ */ new Date()).getFullYear()}-01-01`;
/** "2027-01-01" → "2026-12-31" */
function dayBefore(iso) {
	const d = /* @__PURE__ */ new Date(`${iso}T12:00:00`);
	d.setDate(d.getDate() - 1);
	return d.toLocaleDateString("en-CA");
}
//#endregion
export { balFrom as a, kindLabel as c, today as d, useAccounts as f, accountLabel as i, loadAccounts as l, yearStart as m, TYPE_LABEL as n, balanceOf as o, useTotals as p, TYPE_ORDER as r, dayBefore as s, KINDS as t, loadTotals as u };
