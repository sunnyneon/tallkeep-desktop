import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/members-CRgkIqM9.js
/**
* The people in a household (step 44). Each account can belong to one person or be joint (no
* one). Personal pages can show everyone, or one person's accounts.
*/
var mtbl = (t) => db.from(t);
var MEMBER_COLORS = [
	"#0E7C74",
	"#F28C38",
	"#5B8BD0",
	"#B5764A",
	"#8A6A93",
	"#4E9A72"
];
function useMembers() {
	return useQuery({
		queryKey: ["household-members"],
		queryFn: async () => {
			try {
				return (await fetchAll("household_members", "id,name,color,sort")).sort((a, b) => a.sort - b.sort || a.name.localeCompare(b.name));
			} catch {
				return [];
			}
		}
	});
}
/** Whose each account is: account id → member id (missing = joint). */
function useAccountOwners() {
	return useQuery({
		queryKey: ["account-owners"],
		queryFn: async () => {
			try {
				const rows = await fetchAll("accounts", "id,member_id");
				return new Map(rows.filter((r) => r.member_id).map((r) => [r.id, r.member_id]));
			} catch {
				return /* @__PURE__ */ new Map();
			}
		}
	});
}
/** The person picked at the top of personal pages ("" = everyone). Kept while the tab is open. */
var useWho = () => useSticky("household-who", "");
//#endregion
export { useWho as a, useMembers as i, mtbl as n, useAccountOwners as r, MEMBER_COLORS as t };
