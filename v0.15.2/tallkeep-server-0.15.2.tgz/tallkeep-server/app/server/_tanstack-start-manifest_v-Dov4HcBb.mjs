//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dov4HcBb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-AewFmtty.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/react-dom-8HkkFvw6.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/lazyRouteComponent-Cqxa6b2F.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BOnD92nf.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/preload-helper-Czpn1I53.js",
			"/assets/db-CPMf25U9.js",
			"/assets/addons-3xN8z3BQ.js",
			"/assets/manual-BAAGE6zT.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-AewFmtty.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/leases",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DupirfmI.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/log-out-CHvMDyR9.js",
			"/assets/testers.functions-Chz74ZoE.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-Bja9CCn7.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/BarcodeScanner-BilOmuCR.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/label-Cab5h76V.js",
			"/assets/textarea-BYGvtQeg.js",
			"/assets/dist-D3Afcv8N.js",
			"/assets/dialog-DcT7gL__.js",
			"/assets/command-BymBikjK.js",
			"/assets/company-CJ01NU37.js",
			"/assets/reports-gi3P3Ahh.js",
			"/assets/access-DmSlcDWc.js",
			"/assets/shoebox-CCp9eNEh.js",
			"/assets/UpdateBar-C9ekMuZu.js",
			"/assets/Logo-DiDHru_z.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CYsDnfA0.js",
			"/assets/log-out-CHvMDyR9.js",
			"/assets/admin.functions-qS740nLq.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/Logo-DiDHru_z.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DjzGjY8b.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/label-Cab5h76V.js",
			"/assets/Logo-DiDHru_z.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DdFPXA4M.js",
			"/assets/testers.functions-Chz74ZoE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/buy.functions-MUwM2LIA.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-BCxOR323.js",
			"/assets/testers.functions-Chz74ZoE.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/textarea-BYGvtQeg.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CeNWVr07.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/label-Cab5h76V.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CzfVnWAQ.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/label-Cab5h76V.js",
			"/assets/Logo-DiDHru_z.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-9O_nR3ZP.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/upgrade.functions-fWfTO9KQ.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-_1u_ff-W.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/label-Cab5h76V.js",
			"/assets/Logo-DiDHru_z.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DndcawTT.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Djr7mpL4.js", "/assets/StockDocList-CDyiPYfx.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-Y2OwrzvN.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/ai.functions-DTRpU5tL.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-fNkMBTtG.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/SearchSelect-CO-NvDP_.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BZ6kW01j.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/ai.functions-DTRpU5tL.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/bankfile-CQXrRFI-.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-FCsbGmFr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DJRZWKKF.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-CYQYuvaK.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CuV-Tabc.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DKDq7tvK.js", "/assets/AccountRegister-DxqTdXut.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BzcIUN-D.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BXwkTWwq.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DsJFSS9a.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-DTRpU5tL.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BMoxvjWb.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Bd_uwGj6.js", "/assets/StockDocList-CDyiPYfx.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CgII4s4J.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CiOxijct.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BbwacfAV.js",
			"/assets/QuickBooksImport-C38uxX0d.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BJpl187h.js", "/assets/PartyList-B6O933U4.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-tEgHoQ9j.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-B2y1Llbw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-RFKDG4z9.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CWUPU1Q7.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BJxqJQod.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/members-BbwacfAV.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BuhbqBta.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-CYQYuvaK.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CKEjKidl.js", "/assets/SalesList-NLei0_Yn.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BEgCWmxx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-FeS8b7Pa.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-BIXMa3wA.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-D3kMUN0B.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-DGtwT_ST.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-CYQYuvaK.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Dr0YXhr8.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-VpeXBW1D.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-CYQYuvaK.js",
			"/assets/generateCategoricalChart-BARHTs4c.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-ZY7niQPx.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-BARHTs4c.js",
			"/assets/BarChart-BEjEHU58.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BliA_Xmo.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DOu3OwtP.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-qgk3eVLU.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CLnesqgZ.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/badge-CMLPIDvY.js",
			"/assets/checkbox-Ce84qT_S.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DVZm6ZcF.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CVBQfH-Y.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-D3VKjumW.js", "/assets/SalesList-NLei0_Yn.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-sQZ8H7bO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/ai.functions-DTRpU5tL.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/scanQueue-tUCNVqIP.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-gQq73mjT.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CMLPIDvY.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BJjlKafx.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DlBHV7yH.js", "/assets/AccountRegister-DxqTdXut.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-CYpeq5xK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CMLPIDvY.js",
			"/assets/MoneyAccountPick-kuyruQQF.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DxyeWhfR.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BfxI0u6a.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BARHTs4c.js",
			"/assets/BarChart-BEjEHU58.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CTa7F5fI.js", "/assets/SalesList-NLei0_Yn.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DWMnfw0j.js", "/assets/SalesList-NLei0_Yn.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-LI06wbIt.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DB5L5oo3.js",
			"/assets/createServerFn-BAWqnSsh.js",
			"/assets/auth-middleware-cY1x8kLU.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/dist-D1isL80d.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/QuickBooksImport-C38uxX0d.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-Ce84qT_S.js",
			"/assets/users.functions-DwptPXtj.js",
			"/assets/FeaturePicker-CrGKE6uk.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-b6fnTiI5.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/FeaturePicker-CrGKE6uk.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DvMDa8XR.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/stockmove-MPZeRZQ3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/photos-DS6FdkZl.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-eTl-sb0Z.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/scanQueue-tUCNVqIP.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DiLoGoT-.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/DocPdf-CAw6xM_Y.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-_nGjST4r.js",
			"/assets/createServerFn-BAWqnSsh.js",
			"/assets/auth-middleware-cY1x8kLU.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CMLPIDvY.js",
			"/assets/MoneyAccountPick-kuyruQQF.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-ubKB9OjJ.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/stockmove-MPZeRZQ3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/checkbox-Ce84qT_S.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DUdrTdD9.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-CYQYuvaK.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-D8gAE9qu.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/tickets.functions-BMrUug_t.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CujRQa0U.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-vJSFWfNA.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BPgExwFW.js", "/assets/StockDocList-CDyiPYfx.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-4lm--Xfn.js", "/assets/PartyList-B6O933U4.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-NiTEH13-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/tickets.functions-BMrUug_t.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-dO7LCeH4.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/badge-CMLPIDvY.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-9Wj7nPtZ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DdvJL19H.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/AdminAccount-ReOk-nFG.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-DxescTB3.js",
			"/assets/createServerFn-BAWqnSsh.js",
			"/assets/auth-middleware-cY1x8kLU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DEC925ps.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DRH1OvVG.js",
			"/assets/testers.functions-Chz74ZoE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-BKq-cvqu.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-i_vBCOnJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/buy.functions-MUwM2LIA.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-st9s2vvl.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/input-Njx7yl6V.js",
			"/assets/textarea-BYGvtQeg.js",
			"/assets/support.functions-vJSFWfNA.js",
			"/assets/HelpParts-JNEEufuk.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BXi5RgZ6.js",
			"/assets/useNavigate-BkLYxs6i.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CeX-DiZm.js",
			"/assets/manual._slug-BvA0z6_j.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DGHhbbb7.js",
			"/assets/createServerFn-BAWqnSsh.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BcgRhiin.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/upgrade.functions-fWfTO9KQ.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-mS1AgQzz.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CtaflDjT.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/AdminAccount-ReOk-nFG.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DsKewx0v.js", "/assets/ManualFrame-CeX-DiZm.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-scUXuAJX.js", "/assets/AccountRegister-DxqTdXut.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DLwtahS3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/realestate-hdRlfiWs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C0orj98X.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-pl2SEKag.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CYLYnZn9.js",
			"/assets/PartyHistory-CtZ_dFSm.js",
			"/assets/tabs-CEhpqUvs.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DTJY2uBR.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/popover-DAqAtyA-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CYLYnZn9.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/MoneyAccountPick-kuyruQQF.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-rcsTdVGo.js",
			"/assets/PrintFrame-DdqbEiyY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-D-Ljp2PP.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/popover-DAqAtyA-.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/stockmove-MPZeRZQ3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-D3kMUN0B.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/badge-CMLPIDvY.js",
			"/assets/SideList-CYLYnZn9.js",
			"/assets/tabs-CEhpqUvs.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-D5OpjKdz.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/popover-DAqAtyA-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CYLYnZn9.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/MoneyAccountPick-kuyruQQF.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-rcsTdVGo.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-Ce84qT_S.js",
			"/assets/workorders-B0SB58LO.js",
			"/assets/tickets.functions-BMrUug_t.js",
			"/assets/users.functions-DwptPXtj.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D9Rbplrr.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/select-BY1LyNQY.js",
			"/assets/popover-DAqAtyA-.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CYLYnZn9.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-Bn0DitJ-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SearchSelect-CO-NvDP_.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-vJSFWfNA.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BBMtpsi9.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-XlEgzgVs.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/SideList-CYLYnZn9.js",
			"/assets/PartyHistory-CtZ_dFSm.js",
			"/assets/tabs-CEhpqUvs.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-1Ym9fCrR.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/tickets.functions-BMrUug_t.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CcXuJyaT.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/skeleton-CHoL7VKk.js",
			"/assets/AdminAccount-ReOk-nFG.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BZm0NWXI.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/button-CqpA6QQr.js",
			"/assets/textarea-BYGvtQeg.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-vJSFWfNA.js",
			"/assets/HelpParts-JNEEufuk.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CWQbpPp1.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CHoL7VKk.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
