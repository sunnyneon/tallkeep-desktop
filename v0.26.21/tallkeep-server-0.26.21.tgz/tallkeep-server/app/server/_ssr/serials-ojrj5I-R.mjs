import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-BnCGTaKJ.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { M as ScanLine } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
import { t as STATUS_LABEL } from "./serials-TXod6xX6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/serials-ojrj5I-R.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function SerialsPage() {
	const [q, setQ] = (0, import_react.useState)("");
	const term = q.trim();
	const { data: rows, error } = useQuery({
		queryKey: ["serial-lookup", term],
		retry: false,
		queryFn: async () => {
			let r = db.from("serial_numbers").select("*, products(name), sales_orders(number, customer_name)").order("created_at", { ascending: false }).limit(term ? 100 : 30);
			if (term) r = r.ilike("serial", `%${term.replace(/[%_]/g, "")}%`);
			const { data, error } = await r;
			if (error) throw error;
			return data ?? [];
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Serial Numbers",
			text: "Scan or type a serial number to see the product, where it came from, and who bought it and when. Good for warranty and returns."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative max-w-xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "pointer-events-none absolute left-3 top-3 h-5 w-5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				autoFocus: true,
				className: "h-11 pl-10 text-base",
				placeholder: "Scan or type a serial number",
				value: q,
				onChange: (e) => setQ(e.target.value)
			})]
		}),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Serial numbers need database step 77 (docs/db/077_serial_numbers.sql)."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card",
			children: [
				!term && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "bg-muted/30 px-4 py-2 text-xs font-medium text-muted-foreground",
					children: "Latest serial numbers"
				}),
				rows?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-muted-foreground",
					children: term ? `No serial number like "${term}".` : "No serial numbers yet. Turn on Track serial numbers on a product (its Details tab)."
				}),
				rows?.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1 px-4 py-3 text-sm sm:grid-cols-[12rem_1fr_auto] sm:items-center sm:gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-semibold",
							children: r.serial
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/products/$id",
								params: { id: r.product_id },
								className: "font-medium text-primary underline",
								children: r.products?.name ?? "Product"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [
									r.received_at ? `In ${fmtDate(r.received_at)}` : r.inflow_id ? "Moved from inFlow" : `Added ${fmtDate(r.created_at)}`,
									r.received_from ? ` from ${r.received_from}` : "",
									r.received_doc ? ` (${r.received_doc})` : "",
									r.status === "sold" && r.sales_orders ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										" · ",
										"sold ",
										fmtDate(r.sold_at),
										" to",
										" ",
										r.sales_orders.customer_name ?? "a customer",
										" on",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/sales/$id",
											params: { id: r.sales_order_id },
											className: "font-medium text-primary underline",
											children: r.sales_orders.number
										})
									] }) : null,
									r.notes ? ` · ${r.notes}` : ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: r.status === "in_stock" ? "secondary" : "outline",
							className: "w-fit",
							children: STATUS_LABEL[r.status]
						})
					]
				}, r.id))
			]
		})
	] });
}
//#endregion
export { SerialsPage as component };
