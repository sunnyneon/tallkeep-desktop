//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DYvcQrnz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CFHCJWTe.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DIc6ayM0.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CYW-8W6T.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CFHCJWTe.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CQ9_Ehxn.js",
			"/assets/log-out-DOaJZj0Z.js",
			"/assets/testers.functions-DCRiYGIM.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BLFv5-jp.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-oBjS1lGw.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-B1Md3dbN.js",
			"/assets/button-DIKruSeI.js",
			"/assets/dist-C0wUTv9Q.js",
			"/assets/dialog-4gfD9Rs4.js",
			"/assets/queries-BQkev_Y-.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/label-EvNrt3SZ.js",
			"/assets/textarea-CfstpIhh.js",
			"/assets/shoebox-uE-P1Q2_.js",
			"/assets/company-CqYJsqQJ.js",
			"/assets/reports-C3PrkPXP.js",
			"/assets/access-D0PXL4Hq.js",
			"/assets/LicenseCard-CImQyXs4.js",
			"/assets/Logo-DytmzQY1.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-DbYmntpy.js",
			"/assets/log-out-DOaJZj0Z.js",
			"/assets/admin.functions-DSXz7XpG.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DytmzQY1.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-eN6WfMll.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/label-EvNrt3SZ.js",
			"/assets/Logo-DytmzQY1.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-C70JgcMn.js",
			"/assets/testers.functions-DCRiYGIM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/coupons.functions-DiUHOB1k.js",
			"/assets/buy.functions-DTUvXxrs.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CdE21P0C.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/downloads.functions-CyX1ya9r.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Bow1WSq7.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/label-EvNrt3SZ.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup--TprzcnU.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/label-EvNrt3SZ.js",
			"/assets/Logo-DytmzQY1.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-fxwGRjF2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/upgrade.functions-Cn_E3l1U.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CVlKYHI1.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/label-EvNrt3SZ.js",
			"/assets/Logo-DytmzQY1.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CSR5pmVW.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-be7Ri4nt.js", "/assets/StockDocList-CCRwVxnn.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-80hy3BqR.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/ai-DHuGHSGh.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-P8pf4Uyy.js",
			"/assets/BankConnections-DmX3ndnD.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-XNqVNCKq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-Bt86mmgC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DmX3ndnD.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/ai-DHuGHSGh.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-B_-8rp04.js",
			"/assets/TxnEditor-_TqkmEeH.js",
			"/assets/feedWaiting-CjDC_RkR.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-CgHHWkQD.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-B26QpJoZ.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/personal-DuzEzLS1.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/WhoPicker-DcKt7zLO.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-_7O8nQD7.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-C5T2Mr2i.js", "/assets/AccountRegister-DUDgm5w_.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-XcBmjQ_m.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-C3EX28yB.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/money-FW0KDPJW.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-nax0NntF.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DHuGHSGh.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-CzNDFQgS.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-rpr9vsaz.js", "/assets/StockDocList-CCRwVxnn.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D-PrufUk.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-DHFbs1Nm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BSKFaUxK.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-B8lWG0Hn.js", "/assets/PartyList-JeURJMXf.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-PiFuI66F.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CuFiiiBP.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/storage.functions-B22u5j5D.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BP9-Q7aO.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-IccuFE9w.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-DZJM7Dlt.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Cy6_MsxC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BTb5yyIn.js", "/assets/ChangeHistory-DG1vYzNa.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-Bw3H9Nh_.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/members-qD9mI0tC.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-CbgMCmf2.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/personal-DuzEzLS1.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/WhoPicker-DcKt7zLO.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CHZg_gvB.js", "/assets/SalesList-BWYAuQqF.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CyNbpDTW.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BEoHzoYT.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-f15VO2xT.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BXTcABkH.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/loans-B_-8rp04.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-nU2L9I2j.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Ix5ObKaS.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Bowes_0C.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/personal-DuzEzLS1.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/WhoPicker-DcKt7zLO.js",
			"/assets/reminders-DDNd20WR.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-VhFhgSyw.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CKsHlK5r.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/personal-DuzEzLS1.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/WhoPicker-DcKt7zLO.js",
			"/assets/generateCategoricalChart-CpL5Sc8O.js",
			"/assets/Area-Dg3mXziA.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CIN3Aw13.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/generateCategoricalChart-CpL5Sc8O.js",
			"/assets/PlCharts-DZJM7Dlt.js",
			"/assets/BarChart-jUAwqEsF.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CFtwjPP9.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BnnbSV3w.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DLxL41mo.js",
			"/assets/createServerFn-CpHX3CNb.js",
			"/assets/auth-middleware-BqlZZ3rc.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/storage.functions-B22u5j5D.js",
			"/assets/coupons.functions-DiUHOB1k.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-zxP4o_ij.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BlwCwEIw.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/checkbox-BIlg-lC1.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CTDcPX42.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DQN4vATK.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CYg7XtHM.js", "/assets/SalesList-BWYAuQqF.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-Y9yvx_th.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/ai-DHuGHSGh.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-B22u5j5D.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-KPTfAWcb.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/money-FW0KDPJW.js",
			"/assets/badge-BH4zkp01.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DY3dMzMQ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BDlY3Oet.js", "/assets/AccountRegister-DUDgm5w_.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Czr2xCNZ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/MoneyAccountPick-7KONF-_N.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-KLXhsSJK.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-a22NE44_.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/RepeatInvoice-plb6fjl0.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CzTTE9sD.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-CpL5Sc8O.js",
			"/assets/BarChart-jUAwqEsF.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CblEVN71.js", "/assets/SalesList-BWYAuQqF.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DWxtlA5J.js", "/assets/SalesList-BWYAuQqF.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CYmh_adj.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-DjGEhGmd.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/serials-CarQ8erm.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DrHf3Fh3.js",
			"/assets/createServerFn-CpHX3CNb.js",
			"/assets/auth-middleware-BqlZZ3rc.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-jciGqW3O.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CV28lM5q.js",
			"/assets/switch-Ix5ObKaS.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-BSKFaUxK.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BIE4DtZP.js",
			"/assets/footers-B9GRJKD4.js",
			"/assets/PrintFrame-CUuY-ZPp.js",
			"/assets/checkbox-BIlg-lC1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-2E6gCakT.js",
			"/assets/FeaturePicker-ClrtPtpy.js",
			"/assets/support-DhHmArGM.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BwSIFJVp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/FeaturePicker-ClrtPtpy.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-Dk1Bbc5e.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DMvmhGED.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/photos-BIE4DtZP.js",
			"/assets/stockmove-D81yPh6C.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-pn7RExjl.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/loans-B_-8rp04.js",
			"/assets/feedWaiting-CjDC_RkR.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-B22u5j5D.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-BNQcoPys.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/PrintFrame-CUuY-ZPp.js",
			"/assets/DocPdf-DSVEvMYO.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-t19DzMCc.js",
			"/assets/createServerFn-CpHX3CNb.js",
			"/assets/auth-middleware-BqlZZ3rc.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/MoneyAccountPick-7KONF-_N.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DhHmArGM.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BhBWsU08.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/StockDialogs-DMvmhGED.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/stockmove-D81yPh6C.js",
			"/assets/checkbox-BIlg-lC1.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BSfEK086.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/members-qD9mI0tC.js",
			"/assets/WhoPicker-DcKt7zLO.js",
			"/assets/reminders-DDNd20WR.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-ytHLly_S.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/tickets.functions-Cumj7kFz.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CNULXhn5.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DhHmArGM.js",
			"/assets/support.functions-BTmVqDe8.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DZJnscfl.js", "/assets/StockDocList-CCRwVxnn.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-C2as1tAZ.js", "/assets/PartyList-JeURJMXf.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BHubqCtH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/tickets.functions-Cumj7kFz.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CM7VWKKn.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/workorders-DJwFe7_K.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-RKqvppx1.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-qFSGLeWf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/coupons.functions-DiUHOB1k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DauMOr15.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/AdminAccount-CgyfzJEE.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-B-Xy6OPl.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/downloads.functions-CyX1ya9r.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-DdFUV5I6.js",
			"/assets/createServerFn-CpHX3CNb.js",
			"/assets/auth-middleware-BqlZZ3rc.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-C5CCLRSC.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DZPdfYHH.js",
			"/assets/testers.functions-DCRiYGIM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-KwK_Eaab.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BZPVMWf4.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DIKruSeI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DTUvXxrs.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-B7TWHqd5.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/textarea-CfstpIhh.js",
			"/assets/support.functions-BTmVqDe8.js",
			"/assets/HelpParts-yaRecXgs.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BknBQhD_.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CFVeP5rE.js",
			"/assets/manual._slug-DKrpkhpN.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DWAe2TA1.js",
			"/assets/createServerFn-CpHX3CNb.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Cr--L6ks.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DIKruSeI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-Cn_E3l1U.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Bwymky-d.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DHuGHSGh.js",
			"/assets/personal-DuzEzLS1.js",
			"/assets/reminders-DDNd20WR.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-zNxPnwxP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/AdminAccount-CgyfzJEE.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CHVswVwK.js", "/assets/ManualFrame-CFVeP5rE.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CnkrnYOf.js", "/assets/AccountRegister-DUDgm5w_.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-L6oI-yvG.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/OriginalLink-DqixeqvT.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/realestate-dCzFdaQr.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Dy84bhxL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Cw6hpQrd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/realestate-dCzFdaQr.js",
			"/assets/money-FW0KDPJW.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-C4RYbQVW.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/SideList-Dq2hQ_2S.js",
			"/assets/PartyHistory-Cs5VsDfh.js",
			"/assets/tabs-BegQ2Xdv.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-hH1Pw0po.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-jciGqW3O.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DG1vYzNa.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/SideList-Dq2hQ_2S.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BDGrZupl.js",
			"/assets/MoneyAccountPick-7KONF-_N.js",
			"/assets/footers-B9GRJKD4.js",
			"/assets/PrintFrame-CUuY-ZPp.js",
			"/assets/serials-CarQ8erm.js",
			"/assets/SerialsBox-C0gYoPnz.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-C4DsQmrP.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DMvmhGED.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DG1vYzNa.js",
			"/assets/switch-Ix5ObKaS.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BH4zkp01.js",
			"/assets/SideList-Dq2hQ_2S.js",
			"/assets/tabs-BegQ2Xdv.js",
			"/assets/photos-BIE4DtZP.js",
			"/assets/stockmove-D81yPh6C.js",
			"/assets/serials-CarQ8erm.js",
			"/assets/SerialsBox-C0gYoPnz.js",
			"/assets/workorders-DJwFe7_K.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-CXegouyt.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-jciGqW3O.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DG1vYzNa.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/SideList-Dq2hQ_2S.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BDGrZupl.js",
			"/assets/MoneyAccountPick-7KONF-_N.js",
			"/assets/footers-B9GRJKD4.js",
			"/assets/PrintFrame-CUuY-ZPp.js",
			"/assets/checkbox-BIlg-lC1.js",
			"/assets/serials-CarQ8erm.js",
			"/assets/workorders-DJwFe7_K.js",
			"/assets/RepeatInvoice-plb6fjl0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-Cumj7kFz.js",
			"/assets/users.functions-2E6gCakT.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-5sUXxr5M.js",
			"/assets/select-pfMXUYbm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/SideList-Dq2hQ_2S.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CKoUVwjF.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/quickadd-CspJkx0H.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DhHmArGM.js",
			"/assets/support.functions-BTmVqDe8.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CFczCe6C.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-qGiNMLci.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/SideList-Dq2hQ_2S.js",
			"/assets/PartyHistory-Cs5VsDfh.js",
			"/assets/tabs-BegQ2Xdv.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-D1yn0dqd.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/sales-CzNDFQgS.js",
			"/assets/footers-B9GRJKD4.js",
			"/assets/tickets.functions-Cumj7kFz.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Dd1KCmtw.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DIKruSeI.js",
			"/assets/input-YuUtp4BG.js",
			"/assets/skeleton-B98Wr91J.js",
			"/assets/AdminAccount-CgyfzJEE.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-hpGZb9lI.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DIKruSeI.js",
			"/assets/textarea-CfstpIhh.js",
			"/assets/support-DhHmArGM.js",
			"/assets/support.functions-BTmVqDe8.js",
			"/assets/HelpParts-yaRecXgs.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-ihG8t4gC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B98Wr91J.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
