//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C2mywXsb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-AclqGIzm.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-D5PfKdLy.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-8lT4J6Av.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-AclqGIzm.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BGADVa6-.js",
			"/assets/log-out-CA2p7dES.js",
			"/assets/testers.functions-w4iAUQ0_.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-qS3AV9Cj.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-Db6WCGrJ.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-BG-Ku3Ep.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/dist-FwQfH8SX.js",
			"/assets/dialog-DV6PoEjv.js",
			"/assets/queries-B0HAvuqm.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/label-CuOaAi-n.js",
			"/assets/textarea-DMf8TJte.js",
			"/assets/shoebox-BguzWThK.js",
			"/assets/company-DHSFKE3Z.js",
			"/assets/reports-B1F1c5qw.js",
			"/assets/access-C152jKYk.js",
			"/assets/LicenseCard-DKtdLZhh.js",
			"/assets/Logo-Dt2rqN7e.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-BhGwkqix.js",
			"/assets/log-out-CA2p7dES.js",
			"/assets/admin.functions-BowO1Wx9.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-Dt2rqN7e.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Bf592mHC.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/label-CuOaAi-n.js",
			"/assets/Logo-Dt2rqN7e.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-xcCs_aSX.js",
			"/assets/testers.functions-w4iAUQ0_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/buy.functions-CVsa2CtR.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DrPQcIGU.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/downloads.functions-0HG2Qr0Q.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-D9Nw2yWM.js",
			"/assets/testers.functions-w4iAUQ0_.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/textarea-DMf8TJte.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BHzdFb7o.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/label-CuOaAi-n.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-lOBo1J5M.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/label-CuOaAi-n.js",
			"/assets/Logo-Dt2rqN7e.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-B0G7MQor.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/upgrade.functions-BJn4DCLR.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-njYc9iy0.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/label-CuOaAi-n.js",
			"/assets/Logo-Dt2rqN7e.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-Dw0MzP7p.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-TXwxeiNn.js", "/assets/StockDocList-BeFiiw5e.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-hWl6d8WT.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/ai-B3M_lRNF.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Cl9cEGal.js",
			"/assets/BankConnections-TCzOQfZm.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-EzOqHtHX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CQ0guO-t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-TCzOQfZm.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/ai-B3M_lRNF.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BIJLmyeo.js",
			"/assets/TxnEditor-DfmTx_Em.js",
			"/assets/feedWaiting-I6XY55Qi.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-l1RS1N3y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DKROLPvN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/personal-SFoXC-n3.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/WhoPicker-BmCUsZtQ.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-P3ZCSR2K.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DgUHPSkj.js", "/assets/AccountRegister-Wlv0a6ea.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-A5qVFPuy.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DQ7WOyOK.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/money-9l_xESmI.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BO4Ulqca.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B3M_lRNF.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DJewfYNX.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-31Pirxf2.js", "/assets/StockDocList-BeFiiw5e.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DdKodal4.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-uXHxhjU9.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-Ou9cKjBs.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CYhnIZcH.js", "/assets/PartyList-QMXcH86j.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BQ0T8ghq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Bs4SVWU1.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/storage.functions-3RJoB2sJ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-B9vNYaqF.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-B4ujCFGT.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BVZt-Sqh.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DMtbudiC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BUZgUOOq.js", "/assets/ChangeHistory-B_FVnUsL.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-w_A4jPvY.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/members-DIlrGU9r.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-y4CZtv3I.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/personal-SFoXC-n3.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/WhoPicker-BmCUsZtQ.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-YzNlzbYO.js", "/assets/SalesList-ij-F7XV5.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-COKu5wJf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CQN-4ie6.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-u5KdL1lA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-DriaPCPd.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/loans-BIJLmyeo.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CosCdeld.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-nbt420ZV.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-D-C43s5V.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/personal-SFoXC-n3.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/WhoPicker-BmCUsZtQ.js",
			"/assets/reminders-Bq5CgwA1.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-B23ThSSy.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DmczVb2J.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/personal-SFoXC-n3.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/WhoPicker-BmCUsZtQ.js",
			"/assets/generateCategoricalChart-kiP5wSPH.js",
			"/assets/Area-R_P1cJfo.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-C6XadYwd.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/generateCategoricalChart-kiP5wSPH.js",
			"/assets/PlCharts-BVZt-Sqh.js",
			"/assets/BarChart-BHlyEmJP.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-GZ_mJ3qj.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DiLY7pgL.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BHOXARrL.js",
			"/assets/createServerFn-hsgEALsD.js",
			"/assets/auth-middleware-DNfD-G2t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/storage.functions-3RJoB2sJ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BGQDy0LG.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DV45Uphv.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/checkbox-B7igpwML.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-AJLJuGso.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-Bg2VnNCD.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-cpl2-9ad.js", "/assets/SalesList-ij-F7XV5.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-YZDfG8eK.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/ai-B3M_lRNF.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-3RJoB2sJ.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-JUw3Wwou.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/money-9l_xESmI.js",
			"/assets/badge-BZOL6N3s.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-wlusTxFP.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-C7ifLV5d.js", "/assets/AccountRegister-Wlv0a6ea.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BWnJ-_de.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/MoneyAccountPick-SPGBpBFk.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DTEosQYf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BqXSzwmk.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/RepeatInvoice-DU3C2473.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CtDLixTR.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-kiP5wSPH.js",
			"/assets/BarChart-BHlyEmJP.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-EOSA276i.js", "/assets/SalesList-ij-F7XV5.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-Ep8qqvyL.js", "/assets/SalesList-ij-F7XV5.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-ComHAQ_H.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-0ywC7ALe.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/serials-11wdB0xx.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Di-g3ijl.js",
			"/assets/createServerFn-hsgEALsD.js",
			"/assets/auth-middleware-DNfD-G2t.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-bHgQwG_a.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-C8S6cOwn.js",
			"/assets/switch-nbt420ZV.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-Ou9cKjBs.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DrEJfufr.js",
			"/assets/footers-Bge6Cl2f.js",
			"/assets/PrintFrame-BGCHJSz3.js",
			"/assets/checkbox-B7igpwML.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-GuJZFx4F.js",
			"/assets/FeaturePicker-DofN002W.js",
			"/assets/support-f13yu2Mf.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-VKsSgMI1.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/FeaturePicker-DofN002W.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DtrgEoyy.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BMeYvSDj.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/photos-DrEJfufr.js",
			"/assets/stockmove-B3t9C266.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BNQ2386r.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/loans-BIJLmyeo.js",
			"/assets/feedWaiting-I6XY55Qi.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-3RJoB2sJ.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Cvwz7A9X.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/PrintFrame-BGCHJSz3.js",
			"/assets/DocPdf-vq3FA_JU.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-Dc38St4C.js",
			"/assets/createServerFn-hsgEALsD.js",
			"/assets/auth-middleware-DNfD-G2t.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/MoneyAccountPick-SPGBpBFk.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-f13yu2Mf.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DEJEMj7T.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/StockDialogs-BMeYvSDj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/stockmove-B3t9C266.js",
			"/assets/checkbox-B7igpwML.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BkGZ19tu.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/members-DIlrGU9r.js",
			"/assets/WhoPicker-BmCUsZtQ.js",
			"/assets/reminders-Bq5CgwA1.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BFKjsoom.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/tickets.functions-nwtMmDGg.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-RzBKWmaT.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-f13yu2Mf.js",
			"/assets/support.functions-Dr1D5yaQ.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BTGwd2as.js", "/assets/StockDocList-BeFiiw5e.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-C4nRJwZo.js", "/assets/PartyList-QMXcH86j.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-DMWbPvry.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/tickets.functions-nwtMmDGg.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-BcYCGWJ3.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/workorders-C9aLMtxQ.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CjTwrf3g.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DNfddxh1.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/AdminAccount-Bv3pyVZt.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-B-KstM9b.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/downloads.functions-0HG2Qr0Q.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-D2IeeNiD.js",
			"/assets/createServerFn-hsgEALsD.js",
			"/assets/auth-middleware-DNfD-G2t.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DNJcOABv.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CmL5wrSo.js",
			"/assets/testers.functions-w4iAUQ0_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-Dgg0bJNQ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-DZPi_agb.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CVsa2CtR.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CrwVESrJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/textarea-DMf8TJte.js",
			"/assets/support.functions-Dr1D5yaQ.js",
			"/assets/HelpParts-CF0M-bH9.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CBtSazaB.js",
			"/assets/ManualFrame-n_xyKOyv.js",
			"/assets/manual._slug-Rli7X50m.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-C9P_5hGK.js",
			"/assets/createServerFn-hsgEALsD.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DditTe7z.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-BJn4DCLR.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-C1F8H1Ou.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B3M_lRNF.js",
			"/assets/personal-SFoXC-n3.js",
			"/assets/reminders-Bq5CgwA1.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DdnzDwk3.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/AdminAccount-Bv3pyVZt.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-ByENH3Zi.js", "/assets/ManualFrame-n_xyKOyv.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DaXSPXhQ.js", "/assets/AccountRegister-Wlv0a6ea.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Blvsa0WI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/OriginalLink-BSNi7syK.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/realestate-BF4zPB9G.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-yc2gy8Fu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-Bm_tNjw5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/realestate-BF4zPB9G.js",
			"/assets/money-9l_xESmI.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BneMiK7M.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/SideList-C77EErrD.js",
			"/assets/PartyHistory-W4y8Izu4.js",
			"/assets/tabs-BrRqqz6i.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-Dwy0J0LB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-bHgQwG_a.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_FVnUsL.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/SideList-C77EErrD.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BVxIDP-w.js",
			"/assets/MoneyAccountPick-SPGBpBFk.js",
			"/assets/footers-Bge6Cl2f.js",
			"/assets/PrintFrame-BGCHJSz3.js",
			"/assets/serials-11wdB0xx.js",
			"/assets/SerialsBox-CaaLx_5V.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DuGdAFOD.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BMeYvSDj.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_FVnUsL.js",
			"/assets/switch-nbt420ZV.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BZOL6N3s.js",
			"/assets/SideList-C77EErrD.js",
			"/assets/tabs-BrRqqz6i.js",
			"/assets/photos-DrEJfufr.js",
			"/assets/stockmove-B3t9C266.js",
			"/assets/serials-11wdB0xx.js",
			"/assets/SerialsBox-CaaLx_5V.js",
			"/assets/workorders-C9aLMtxQ.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DMsqkr36.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-bHgQwG_a.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_FVnUsL.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/SideList-C77EErrD.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BVxIDP-w.js",
			"/assets/MoneyAccountPick-SPGBpBFk.js",
			"/assets/footers-Bge6Cl2f.js",
			"/assets/PrintFrame-BGCHJSz3.js",
			"/assets/checkbox-B7igpwML.js",
			"/assets/serials-11wdB0xx.js",
			"/assets/workorders-C9aLMtxQ.js",
			"/assets/RepeatInvoice-DU3C2473.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-nwtMmDGg.js",
			"/assets/users.functions-GuJZFx4F.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DZUQScwL.js",
			"/assets/select-PPLWA2Ud.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/SideList-C77EErrD.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CtRAx69d.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/quickadd-B7owrZKE.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-f13yu2Mf.js",
			"/assets/support.functions-Dr1D5yaQ.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-D2Ly74GV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Ccdih1qB.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/SideList-C77EErrD.js",
			"/assets/PartyHistory-W4y8Izu4.js",
			"/assets/tabs-BrRqqz6i.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DgniEUxf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/sales-DJewfYNX.js",
			"/assets/footers-Bge6Cl2f.js",
			"/assets/tickets.functions-nwtMmDGg.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B5IJkqPb.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/input-CMOh12Y6.js",
			"/assets/skeleton-YcfsZqBA.js",
			"/assets/AdminAccount-Bv3pyVZt.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BtBusF0h.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-0NihQCuZ.js",
			"/assets/textarea-DMf8TJte.js",
			"/assets/support-f13yu2Mf.js",
			"/assets/support.functions-Dr1D5yaQ.js",
			"/assets/HelpParts-CF0M-bH9.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Ca4MZiy6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-YcfsZqBA.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
