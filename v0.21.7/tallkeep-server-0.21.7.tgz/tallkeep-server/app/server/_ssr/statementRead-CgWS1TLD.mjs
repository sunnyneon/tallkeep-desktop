import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as fileToPages } from "./ai-DoFpV1D-.mjs";
import { t as aiRead } from "./ai.functions-DzKY_vC-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/statementRead-CgWS1TLD.js
/**
* Statement dates that cross New Year. A January statement often lists December lines, and the
* AI gives them the statement's year (Dec 17, 2026 on a statement that ends Jan 17, 2026). A line
* can't be after the statement ends, so those go back a year.
*/
var DAY = 864e5;
var t = (d) => Date.parse(`${d}T12:00:00Z`);
/** The statement's end date: what the AI read, else the newest line not in the future. */
function statementEnd(periodEnds, dates) {
	const ok = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v.slice(0, 10));
	const pe = periodEnds.filter(ok).map((v) => String(v).slice(0, 10));
	if (pe.length) return pe.sort().at(-1);
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return dates.filter((d) => d <= today).sort().at(-1) ?? today;
}
/** The line's date, moved back a year (or more) while it's after the statement's end. */
function fixLineYear(date, end) {
	let d = date;
	for (let i = 0; i < 3 && t(d) > t(end) + 5 * DAY; i++) d = `${Number(d.slice(0, 4)) - 1}${d.slice(4)}`;
	return d;
}
/**
* Read a PDF bank or card statement with the AI, then check it: the lines must add up to the
* difference between the statement's opening and closing balances. When they don't, read it once
* more, telling the AI what was off; keep whichever reading fits. What's still off is returned so
* the person can be told before reconciling (a line read the wrong way round, doubled or missed).
*/
var num = (v) => typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v.replace(/[$,]/g, ""))) ? Number(v.replace(/[$,]/g, "")) : null;
var r2 = (n) => Math.round(n * 100) / 100;
async function readOnce(pages, card, step, note) {
	const raw = [];
	const ends = [];
	let begin = null;
	let end = null;
	for (let i = 0; i < pages.length; i += 6) {
		step(`reading pages ${i + 1}–${Math.min(i + 6, pages.length)} of ${pages.length}…`);
		const r = JSON.parse(await aiRead({ data: {
			feature: "statement",
			images: pages.slice(i, i + 6),
			hint: `This is a ${card ? "credit card" : "bank account"} statement${pages.length > 6 ? `, pages ${i + 1}-${Math.min(i + 6, pages.length)} of ${pages.length}` : ""}.${note}`
		} }));
		raw.push(...r["lines"] ?? []);
		ends.push(r["period_end"]);
		begin ??= num(r["beginning_balance"]);
		end = num(r["ending_balance"]) ?? end;
	}
	const last = statementEnd(ends, raw.map((l) => String(l.date ?? "").slice(0, 10)));
	const seen = /* @__PURE__ */ new Map();
	const lines = [];
	for (const l of raw) {
		const date = fixLineYear(String(l.date ?? "").slice(0, 10), last);
		const amount = r2(Number(l.amount));
		if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !amount) continue;
		const description = String(l.description ?? "").trim();
		const k = `${date}|${amount}|${description.toLowerCase()}`;
		const n = (seen.get(k) ?? 0) + 1;
		seen.set(k, n);
		lines.push({
			txn_date: date,
			amount,
			description,
			ref: l.ref ? String(l.ref) : null,
			fit_id: `pdf:${k}:${n}`
		});
	}
	const total = r2(lines.reduce((t, l) => t + l.amount, 0));
	const want = begin != null && end != null ? r2(card ? begin - end : end - begin) : null;
	return {
		lines,
		begin,
		end,
		off: want == null ? null : r2(total - want)
	};
}
async function readStatement(file, card, step) {
	const pages = await fileToPages(file, 40);
	const first = await readOnce(pages, card, step, "");
	if (!first.off) return first;
	step("the lines don't add up to the statement's balances: reading it again…");
	const total = r2(first.lines.reduce((t, l) => t + l.amount, 0));
	const second = await readOnce(pages, card, step, ` Careful: a first reading's lines added up to ${total.toFixed(2)}, but the statement's balances say ${(total - first.off).toFixed(2)}. Check every line's sign (${card ? "purchases, interest and fees negative; payments and credits positive" : "deposits positive, withdrawals negative"}), and that no line is missed or listed twice.`);
	if (second.off != null && Math.abs(second.off) < Math.abs(first.off)) return second;
	return first;
}
/** Plain words for a statement that doesn't add up (null when it does, or can't be told). */
function offWarning(r) {
	if (!r.off) return null;
	return `Check this statement: its lines add up to ${fmtMoney(Math.abs(r.off))} ${r.off > 0 ? "more" : "less"} than its opening and closing balances say. A line may be read the wrong way round (a charge as a payment), listed twice or missed. Fix it in Bank Feeds or the register before reconciling.`;
}
//#endregion
export { readStatement as n, offWarning as t };
