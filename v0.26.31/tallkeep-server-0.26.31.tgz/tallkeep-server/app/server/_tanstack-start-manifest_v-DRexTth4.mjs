//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DRexTth4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CkqxXGhG.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BJKainV3.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-Duei4hzk.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CkqxXGhG.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CwWETO8l.js",
			"/assets/log-out-Bjl1Jr57.js",
			"/assets/testers.functions-D6UgXdjN.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CoL71AK9.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-B0CQrIYT.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CuxiYKZr.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/dist-CGJQSMiH.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/dist-Bksb-czM.js",
			"/assets/dialog-Cp-pNCWx.js",
			"/assets/queries-IrCasH8n.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/label-CgoxTNV5.js",
			"/assets/textarea-VpUqFCrh.js",
			"/assets/shoebox-DbkZMBm9.js",
			"/assets/company-BB6w32zB.js",
			"/assets/reports-BxSKqPzi.js",
			"/assets/access-BPUQfuBQ.js",
			"/assets/theme-Cev_O0m1.js",
			"/assets/Logo-BpqWusKS.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CglTFlXi.js",
			"/assets/log-out-Bjl1Jr57.js",
			"/assets/admin.functions-14ZpQ6xT.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-BpqWusKS.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Bdd1OcTh.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/label-CgoxTNV5.js",
			"/assets/Logo-BpqWusKS.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BQBgQbsp.js",
			"/assets/testers.functions-D6UgXdjN.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/coupons.functions-BtM0n-4M.js",
			"/assets/buy.functions-DDWzeLNx.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DPIRkz2M.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/downloads.functions-DrXkqfxU.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-ja8LP7cF.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/label-CgoxTNV5.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-c_FK_VA0.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/label-CgoxTNV5.js",
			"/assets/Logo-BpqWusKS.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-Zbvq5A2s.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/upgrade.functions-D3nwoxMf.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-40sNqWeT.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/label-CgoxTNV5.js",
			"/assets/Logo-BpqWusKS.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-C1Wm_1j4.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Ce8tpFXm.js", "/assets/StockDocList-YpsS78bl.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DznxxveE.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/ai-B004aCHH.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-D6jU-gaN.js",
			"/assets/BankConnections-3BWC_fP6.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BFcT5Ena.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-OWvP6UMW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-3BWC_fP6.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/ai-B004aCHH.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-CMI8WmEZ.js",
			"/assets/TxnEditor-CXxJdatr.js",
			"/assets/feedWaiting-CA6mhbF1.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-CyzLllKL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/bills-CguplMIv.js",
			"/assets/balances-jtRmK3HL.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CnOUb-EC.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/personal-Bu7tQaY8.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/WhoPicker-B8Ce0tZ_.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DFIlaQES.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BL3s6kLi.js", "/assets/AccountRegister-BXk88qhW.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-B5b_PUS-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-ClNH4AnO.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/money-LfnP1T2j.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BF_ZAwyJ.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B004aCHH.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BTRC4h6P.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BSpnyu3u.js", "/assets/StockDocList-YpsS78bl.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-BoziDgRr.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BIOeZuLW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-N6as-fy6.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-Bm_A0zFD.js", "/assets/PartyList-lzW4_Fxb.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Y1iM_kL6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-AfTGSlTP.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/storage.functions-DSDF4zxb.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Beo58ATZ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-D6xsxkOs.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-oeSVNvra.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-FyzCvUZ-.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DcAlSqWT.js", "/assets/ChangeHistory-d1QRJkFl.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BWfcE2um.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/members-C8ZE_8GT.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DdVIO7iU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/personal-Bu7tQaY8.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/WhoPicker-B8Ce0tZ_.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-kx_PawwG.js", "/assets/SalesList-DUe0vyt5.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CgpasMdc.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-DOEey2Bi.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-uFXzBwhF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CZu4IWtv.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/loans-CMI8WmEZ.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-S0u0uG2K.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-C4jgLVe7.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-keDuuQU2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/personal-Bu7tQaY8.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/WhoPicker-B8Ce0tZ_.js",
			"/assets/reminders-B_xFblBb.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BBkVg-hI.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BxrsbT_3.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/personal-Bu7tQaY8.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/WhoPicker-B8Ce0tZ_.js",
			"/assets/generateCategoricalChart-DKwq21Jr.js",
			"/assets/Area-BXeByZUu.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-BRCbEyU-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/generateCategoricalChart-DKwq21Jr.js",
			"/assets/PlCharts-oeSVNvra.js",
			"/assets/BarChart-DPwW7Rb6.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-kk90VyFJ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-Do3PPWuN.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CnyTmjfM.js",
			"/assets/createServerFn-CS8WsTUX.js",
			"/assets/auth-middleware-BC8RIm0C.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/storage.functions-DSDF4zxb.js",
			"/assets/coupons.functions-BtM0n-4M.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CWxxOr-E.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CK_5P5vH.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/checkbox-CYZHj4W-.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CKzjM--O.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CEKRBzbK.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-B0J9KDiH.js", "/assets/SalesList-DUe0vyt5.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CFAdymES.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/ai-B004aCHH.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DSDF4zxb.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BC6ftzpO.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/money-LfnP1T2j.js",
			"/assets/badge-G3Ct_LV5.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BpZAAcAW.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DQEh2hU-.js", "/assets/AccountRegister-BXk88qhW.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BEGyBhkV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/MoneyAccountPick-9f_Scqug.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BPdJGvHm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DA-miqdq.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/RepeatInvoice-C-C9f-k-.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BHQyUa01.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-DKwq21Jr.js",
			"/assets/BarChart-DPwW7Rb6.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-3r-ZTNan.js", "/assets/SalesList-DUe0vyt5.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DIn-owNb.js", "/assets/SalesList-DUe0vyt5.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-B3-H2sU6.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-cMYJJ7G5.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/serials-ByGw8uA2.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DshsILPE.js",
			"/assets/createServerFn-CS8WsTUX.js",
			"/assets/auth-middleware-BC8RIm0C.js",
			"/assets/AppsCatalog-DAMEUSxk.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DxF5Frgm.js",
			"/assets/switch-C4jgLVe7.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-N6as-fy6.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-03hb8mHL.js",
			"/assets/footers-DqYsj_Z_.js",
			"/assets/PrintFrame-B5zwFLNr.js",
			"/assets/checkbox-CYZHj4W-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-Dta-6RZx.js",
			"/assets/support-wuHNYImp.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DM2xE6Ms.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-DAMEUSxk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-3BWC_fP6.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/users.functions-Dta-6RZx.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-wzGC-wQx.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BQnBndgJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/photos-03hb8mHL.js",
			"/assets/stockmove-BFUL-oII.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BBkUIOUe.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/loans-CMI8WmEZ.js",
			"/assets/feedWaiting-CA6mhbF1.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DSDF4zxb.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-D-7f-Quy.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/PrintFrame-B5zwFLNr.js",
			"/assets/DocPdf-DsrFn6T3.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-D-3-_b5v.js",
			"/assets/createServerFn-CS8WsTUX.js",
			"/assets/auth-middleware-BC8RIm0C.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/MoneyAccountPick-9f_Scqug.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-wuHNYImp.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-6Z0botw_.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/StockDialogs-BQnBndgJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/stockmove-BFUL-oII.js",
			"/assets/checkbox-CYZHj4W-.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-I56sph-2.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/members-C8ZE_8GT.js",
			"/assets/WhoPicker-B8Ce0tZ_.js",
			"/assets/reminders-B_xFblBb.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DF5o_hPA.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/tickets.functions-DWLEg9Qe.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Blu0bDwU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-wuHNYImp.js",
			"/assets/support.functions-f0HxtwdF.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CxeCNpXG.js", "/assets/StockDocList-YpsS78bl.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-VBBQQnpu.js", "/assets/PartyList-lzW4_Fxb.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-Bl9VdcpQ.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/tickets.functions-DWLEg9Qe.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-C6h7ktn_.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/workorders-CM941yPl.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DgWEYV13.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-3fnX55IX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/coupons.functions-BtM0n-4M.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CkzSnYWX.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/AdminAccount-BzDb9aVI.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-B2uUh8tB.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/downloads.functions-DrXkqfxU.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-dbUxjGFt.js",
			"/assets/createServerFn-CS8WsTUX.js",
			"/assets/auth-middleware-BC8RIm0C.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BSgd3VmO.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CdoG8uq4.js",
			"/assets/testers.functions-D6UgXdjN.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-veb5gzaM.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-Du2WkBiz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DDWzeLNx.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Byi6n-jI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/textarea-VpUqFCrh.js",
			"/assets/support.functions-f0HxtwdF.js",
			"/assets/HelpParts-BfSxhMQk.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-ClpIIlQk.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BTafqyD0.js",
			"/assets/manual._slug-CnqHuj2J.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-dA_ekNDW.js",
			"/assets/createServerFn-CS8WsTUX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BwM_dypn.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-D3nwoxMf.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BopTCKZq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B004aCHH.js",
			"/assets/personal-Bu7tQaY8.js",
			"/assets/reminders-B_xFblBb.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DKyfyqAG.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/AdminAccount-BzDb9aVI.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BzMSmzVW.js", "/assets/ManualFrame-BTafqyD0.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D7s-_afo.js", "/assets/AccountRegister-BXk88qhW.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BVE0V3YB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/OriginalLink-LMc6m_mE.js",
			"/assets/bills-CguplMIv.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/realestate-CXF_VWcE.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CuILOO0C.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-a9nSzXqV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/realestate-CXF_VWcE.js",
			"/assets/money-LfnP1T2j.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-C5xps1zd.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/SideList-CqdOygYb.js",
			"/assets/PartyHistory-CA3OW0yS.js",
			"/assets/tabs-DmVSr7SM.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-QC7GJ81V.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-d1QRJkFl.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/SideList-CqdOygYb.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/NewProductDialog-DPBLaVRL.js",
			"/assets/MoneyAccountPick-9f_Scqug.js",
			"/assets/footers-DqYsj_Z_.js",
			"/assets/PrintFrame-B5zwFLNr.js",
			"/assets/serials-ByGw8uA2.js",
			"/assets/SerialsBox-BwfhiQqY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DHxMrCuG.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BQnBndgJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-d1QRJkFl.js",
			"/assets/switch-C4jgLVe7.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-G3Ct_LV5.js",
			"/assets/SideList-CqdOygYb.js",
			"/assets/tabs-DmVSr7SM.js",
			"/assets/photos-03hb8mHL.js",
			"/assets/stockmove-BFUL-oII.js",
			"/assets/serials-ByGw8uA2.js",
			"/assets/SerialsBox-BwfhiQqY.js",
			"/assets/workorders-CM941yPl.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-CDQ3ZjVA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-d1QRJkFl.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/SideList-CqdOygYb.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-DPBLaVRL.js",
			"/assets/MoneyAccountPick-9f_Scqug.js",
			"/assets/footers-DqYsj_Z_.js",
			"/assets/PrintFrame-B5zwFLNr.js",
			"/assets/cardpay-CwhRLrEC.js",
			"/assets/checkbox-CYZHj4W-.js",
			"/assets/serials-ByGw8uA2.js",
			"/assets/workorders-CM941yPl.js",
			"/assets/RepeatInvoice-C-C9f-k-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DWLEg9Qe.js",
			"/assets/users.functions-Dta-6RZx.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DjOp5qAR.js",
			"/assets/select-Q28r1cjz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/SideList-CqdOygYb.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CFLfhmkT.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/quickadd-CbXpRtSJ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-wuHNYImp.js",
			"/assets/support.functions-f0HxtwdF.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DC5UbHvx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DfMEbkkl.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/SideList-CqdOygYb.js",
			"/assets/PartyHistory-CA3OW0yS.js",
			"/assets/tabs-DmVSr7SM.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C9nbQBQn.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/sales-BTRC4h6P.js",
			"/assets/footers-DqYsj_Z_.js",
			"/assets/tickets.functions-DWLEg9Qe.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-QNdeXd8L.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/input-Bkb5ozLs.js",
			"/assets/skeleton-7heDBj0y.js",
			"/assets/AdminAccount-BzDb9aVI.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-B4EWnhE3.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/button-D4cDeR1D.js",
			"/assets/textarea-VpUqFCrh.js",
			"/assets/support-wuHNYImp.js",
			"/assets/support.functions-f0HxtwdF.js",
			"/assets/HelpParts-BfSxhMQk.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-DnAXyqRZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-7heDBj0y.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
