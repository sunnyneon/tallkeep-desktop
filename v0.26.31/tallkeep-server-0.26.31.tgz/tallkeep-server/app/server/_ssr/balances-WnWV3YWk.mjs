import { r as fetchAll } from "./db-CRCUsAot.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/balances-WnWV3YWk.js
/**
* What we owe each vendor and what each customer owes us, the same way as What we owe / Who owes
* us and the Balance Sheet: bills (less vendor credits not used yet) plus received purchase orders
* still unpaid; invoices still unpaid.
*/
async function vendorBalances() {
	const [bills, pos] = await Promise.all([fetchAll("bills", "vendor_id,balance,status"), fetchAll("purchase_orders", "vendor_id,balance,status,stock_received_at")]);
	const out = /* @__PURE__ */ new Map();
	const at = (id) => {
		const r = out.get(id) ?? {
			bills: 0,
			pos: 0,
			credits: 0,
			total: 0
		};
		out.set(id, r);
		return r;
	};
	for (const b of bills) {
		if (!b.vendor_id || b.status !== "open" || Math.abs(Number(b.balance)) < .005) continue;
		const r = at(b.vendor_id);
		if (Number(b.balance) < 0) r.credits += Number(b.balance);
		else r.bills += Number(b.balance);
		r.total += Number(b.balance);
	}
	for (const p of pos) {
		if (!p.vendor_id || p.status === "cancelled" || Number(p.balance) <= .005) continue;
		if (!(p.stock_received_at || [
			"received",
			"paid",
			"completed"
		].includes(p.status))) continue;
		const r = at(p.vendor_id);
		r.pos += Number(p.balance);
		r.total += Number(p.balance);
	}
	return out;
}
async function customerBalances() {
	const rows = await fetchAll("sales_orders", "customer_id,balance,status,number");
	const out = /* @__PURE__ */ new Map();
	for (const o of rows) {
		if (!o.customer_id || ![
			"invoiced",
			"paid",
			"completed"
		].includes(o.status)) continue;
		if (o.number.startsWith("RMA-") || Number(o.balance) <= .005) continue;
		const r = out.get(o.customer_id) ?? { total: 0 };
		r.total += Number(o.balance);
		out.set(o.customer_id, r);
	}
	return out;
}
function usePartyBalances(kind) {
	return useQuery({
		queryKey: ["party-balances", kind],
		queryFn: async () => kind === "vendors" ? new Map([...await vendorBalances()].map(([k, v]) => [k, v.total])) : new Map([...await customerBalances()].map(([k, v]) => [k, v.total]))
	});
}
//#endregion
export { vendorBalances as n, usePartyBalances as t };
