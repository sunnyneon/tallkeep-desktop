//#region ../../node_modules/.nitro/vite/services/ssr/assets/format-BVuRObRk.js
var money = new Intl.NumberFormat("en-US", {
	style: "currency",
	currency: "USD"
});
var qtyFmt = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });
var fmtMoney = (n) => money.format(Math.round(Number(n ?? 0) * 100) / 100 + 0);
var fmtQty = (n) => qtyFmt.format(Number(n ?? 0));
var fmtDate = (s) => s ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}T12:00:00` : s).toLocaleDateString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric"
}) : "";
var fmtDateTime = (s) => s ? new Date(s).toLocaleString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric",
	hour: "numeric",
	minute: "2-digit"
}) : "";
/** A chart axis label: $50, $1.5k, $12k, $1.2M (small amounts stay in dollars, never "$0k"). */
function axisMoney(n) {
	const a = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	if (a >= 1e6) return `${sign}$${(a / 1e6).toFixed(a >= 1e7 ? 0 : 1).replace(/\.0$/, "")}M`;
	if (a >= 1e3) return `${sign}$${(a / 1e3).toFixed(a >= 1e4 ? 0 : 1).replace(/\.0$/, "")}k`;
	return `${sign}$${Math.round(a)}`;
}
//#endregion
export { fmtQty as a, fmtMoney as i, fmtDate as n, fmtDateTime as r, axisMoney as t };
