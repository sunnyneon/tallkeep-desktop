//#region ../../node_modules/.nitro/vite/services/ssr/assets/bills-DepmKqNz.js
function billStatus(b, today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA")) {
	if (b.status === "void") return {
		label: "Void",
		style: "bg-muted text-muted-foreground"
	};
	const total = Number(b.total);
	const bal = Number(b.balance);
	if (b.status === "paid" || bal <= .005) return {
		label: "Paid",
		style: "bg-emerald-100 text-emerald-800"
	};
	const partial = total - bal > .005;
	const late = !!b.due_date && b.due_date < today;
	if (partial && late) return {
		label: "Partly paid · overdue",
		style: "bg-red-100 text-red-800"
	};
	if (late) return {
		label: "Overdue",
		style: "bg-red-100 text-red-800"
	};
	if (partial) return {
		label: "Partly paid",
		style: "bg-orange-100 text-orange-800"
	};
	return {
		label: "Unpaid",
		style: "bg-amber-100 text-amber-800"
	};
}
//#endregion
export { billStatus as t };
