import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, n as fmtDate, r as fmtDateTime } from "./format-BVuRObRk.mjs";
import { n as db } from "./db-CRCUsAot.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-BIxnl3zd.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { F as RefreshCw, Fn as ArrowRight, Wt as ExternalLink, d as Unlink, m as TriangleAlert, mt as Link2, pt as ListChecks, un as Check, vt as Landmark } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as useFeedWaiting } from "./feedWaiting-DJLensAx.mjs";
import { a as setBankLinkAccount, i as removeBankLink, n as listBankLinks, r as pullBankNow, t as connectBank } from "./bankfeed.functions-C-oouOnh.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/BankConnections-7s4IVHA2.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var SIMPLEFIN = "https://beta-bridge.simplefin.org/";
var isoDay = (d) => d.toLocaleDateString("en-CA");
/** Banking: banks connected through SimpleFIN, which send new lines in every day. */
function BankConnections({ compact = false }) {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: links, error } = useQuery({
		queryKey: ["bank-links"],
		retry: false,
		queryFn: () => listBankLinks()
	});
	const { data: booksStart } = useQuery({
		queryKey: ["books-start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
	const { data: waiting } = useFeedWaiting();
	const [connecting, setConnecting] = (0, import_react.useState)(false);
	const [pulling, setPulling] = (0, import_react.useState)(false);
	const [removing, setRemoving] = (0, import_react.useState)(null);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["bank-links"] });
		qc.invalidateQueries({ queryKey: ["bank-txns"] });
		qc.invalidateQueries({ queryKey: ["bank-feed-waiting"] });
	};
	const thirty = isoDay(/* @__PURE__ */ new Date(Date.now() - 2592e6));
	const defaultStart = booksStart && booksStart > thirty ? booksStart : thirty;
	const ninety = isoDay(/* @__PURE__ */ new Date(Date.now() - 76896e5));
	async function pull() {
		setPulling(true);
		try {
			const r = await pullBankNow();
			if (r.errors.length) toast.error(r.errors[0]);
			else toast.success(r.added ? `Brought in ${r.added} new line${r.added === 1 ? "" : "s"}. They're in For review.` : "No new lines yet.");
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setPulling(false);
		}
	}
	async function map(id, accountId, startDate) {
		try {
			setPulling(!!accountId);
			const r = await setBankLinkAccount({ data: {
				id,
				accountId,
				startDate
			} });
			if (r.errors.length) toast.error(r.errors[0]);
			else if (accountId) toast.success(r.added ? `Brought in ${r.added} new line${r.added === 1 ? "" : "s"}. They're in For review.` : "Saved. No new lines for those dates.");
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setPulling(false);
		}
	}
	async function remove(id) {
		try {
			await removeBankLink({ data: { id } });
			toast.success("Connection removed. Lines already brought in stay.");
			setRemoving(null);
			refresh();
		} catch (e) {
			toast.error(e.message);
		}
	}
	if (error && compact) return null;
	if (error) {
		const msg = String(error.message ?? "");
		if (/bank_link|does not exist|schema cache/i.test(msg)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
			children: "Bank connections need database step 76 (docs/db/076_bank_connections.sql)."
		});
		if (/don't have access/i.test(msg)) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
			children: ["Bank connections couldn't load: ", msg]
		});
	}
	if (!links) return null;
	if (compact) {
		const linked = links.flatMap((l) => l.accounts).filter((a) => a.account_id).length;
		const last = links.map((l) => l.last_pulled_at).filter(Boolean).sort().pop();
		const problem = links.find((l) => l.last_error)?.last_error;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-wrap items-center gap-3 rounded-2xl border bg-card px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4 shrink-0 text-[var(--section)]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: "Bank connections"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [" · ", links.length ? `${linked} account${linked === 1 ? "" : "s"} bringing in lines every morning${last ? ` · last checked ${fmtDateTime(last)}` : ""}` : "connect your bank once and new lines come in by themselves"]
						}),
						problem && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-2 inline-flex items-center gap-1 text-amber-700 dark:text-amber-400",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3.5 w-3.5" }), " Needs a look"]
						})
					]
				}),
				links.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => void pull(),
					disabled: pulling || !linked,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-4 w-4 ${pulling ? "animate-spin" : ""}` }), pulling ? "Getting…" : "Get new lines now"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: links.length ? "ghost" : "default",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/bank-connections",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" }),
							" ",
							links.length ? "Bank connections" : "Connect a bank"
						]
					})
				})
			]
		});
	}
	const banks = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4 text-[var(--section)]" }), " Bank connections"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-muted-foreground",
						children: links.length ? "New lines from your bank come in by themselves every morning. Tallkeep can only read them; it can never move money." : "Skip the statement files: connect your bank once and new lines come in by themselves every day. Read-only: it can never move money."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setConnecting(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" }),
							" ",
							links.length ? "Connect another bank" : "Connect a bank"
						]
					})
				})]
			}),
			links.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Steps, {
				linked: links.flatMap((l) => l.accounts).filter((a) => a.account_id).length,
				pulling,
				onPull: () => void pull(),
				waiting: waiting?.total ?? 0,
				top: links.flatMap((l) => l.accounts).find((a) => a.account_id && waiting?.per.get(a.account_id))?.account_id ?? waiting?.top ?? null
			}),
			links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							l.name ?? "SimpleFIN",
							" · connected ",
							fmtDate(l.created_at),
							" ·",
							" ",
							l.last_pulled_at ? `last checked ${fmtDateTime(l.last_pulled_at)}` : "not checked yet"
						] }), removing === l.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [
								"Remove this connection?",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "destructive",
									onClick: () => void remove(l.id),
									children: "Yes, remove it"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => setRemoving(null),
									children: "Keep it"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setRemoving(l.id),
							className: "inline-flex items-center gap-1 rounded-md px-2 py-1 hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unlink, { className: "h-3.5 w-3.5" }), " Remove"]
						})]
					}),
					l.last_error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-start gap-2 border-b bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							l.last_error,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SIMPLEFIN,
								target: "_blank",
								rel: "noreferrer",
								className: "underline",
								children: "Open SimpleFIN"
							}),
							" ",
							"to fix it."
						] })]
					}),
					l.accounts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-3 text-sm text-muted-foreground",
						children: "No accounts shared yet. Add your bank in SimpleFIN, then press Get now."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: l.accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_19rem_10rem] sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: a.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: [a.bank_name, a.balance == null ? null : `balance ${fmtMoney(a.balance)}`].filter(Boolean).join(" · ")
										}),
										a.account_id && (waiting?.per.get(a.account_id) ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/banking",
											search: {
												account: a.account_id,
												tab: "review"
											},
											className: "mt-0.5 inline-flex items-center gap-1 text-xs font-medium text-primary",
											children: [
												waiting.per.get(a.account_id),
												" new to review",
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3" })
											]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-0.5 text-xs text-muted-foreground",
									children: ["Put its lines in", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: a.account_id ?? "",
										onChange: (e) => void map(a.id, e.target.value || null, a.start_date ?? defaultStart),
										className: "h-9 rounded-md border bg-background px-2 text-sm text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Don't bring in"
										}), banks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: b.id,
											children: accountLabel(b)
										}, b.id))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-0.5 text-xs text-muted-foreground",
									children: ["Lines from", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										className: "h-9",
										disabled: !a.account_id,
										value: a.start_date ?? defaultStart,
										onChange: (e) => e.target.value && void map(a.id, a.account_id, e.target.value)
									})]
								})
							]
						}, a.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border-t bg-muted/20 px-3 py-2 text-xs text-muted-foreground",
						children: [
							"Banks share about the last 90 days (from ",
							fmtDate(ninety),
							"). For older lines, bring in statements once in Review & Reconcile, up to the day before that."
						]
					})
				]
			}, l.id)),
			connecting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectDialog, {
				onClose: () => setConnecting(false),
				onDone: () => {
					setConnecting(false);
					refresh();
				}
			})
		]
	});
}
function ConnectDialog({ onClose, onDone }) {
	const [code, setCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function go() {
		setBusy(true);
		try {
			const r = await connectBank({ data: { code } });
			toast.success(r.accounts ? `Connected. ${r.accounts} account${r.accounts === 1 ? "" : "s"} found: pick where each one's lines go.` : "Connected. Add your bank in SimpleFIN, then press Get now.");
			onDone();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Connect a bank" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Tallkeep connects to banks through SimpleFIN Bridge. It costs $15 a year (or $1.50 a month), paid to SimpleFIN, and covers up to 25 banks and cards." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: SIMPLEFIN,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 font-medium text-primary underline",
								children: ["Open SimpleFIN Bridge ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5" })]
							}),
							" ",
							"and make an account."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Add your banks and cards there (you sign in to each bank on SimpleFIN's page)." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Choose ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "New app connection" }),
							" (or ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Setup token" }),
							"), name it Tallkeep, and copy the code it shows."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Paste the code below and press Connect." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 3,
					value: code,
					onChange: (e) => setCode(e.target.value),
					placeholder: "Paste the setup code here",
					className: "font-mono text-xs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "The code works once. Tallkeep keeps the private read-only address it gets in return; you can remove the connection here, or in SimpleFIN, any time."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "More than one company in Tallkeep? Each code works once, so make a new setup code in SimpleFIN for each company, and in each company pick only that company's accounts."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void go(),
					disabled: busy || !code.trim(),
					children: busy ? "Connecting…" : "Connect"
				})] })
			]
		})
	});
}
/** Connect → Get new lines → Review & reconcile, with the next step standing out. */
function Steps({ linked, pulling, onPull, waiting, top }) {
	const step = "flex min-w-0 flex-1 items-center gap-3 rounded-xl border p-3";
	const num = (n, done) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold ${done ? "bg-emerald-600 text-white" : "bg-primary text-primary-foreground"}`,
		children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) : n
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 lg:flex-row lg:items-stretch",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: step,
				children: [num(1, linked > 0), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Connect"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: linked ? `${linked} account${linked === 1 ? "" : "s"} bringing in lines` : "Pick where each account's lines go, below"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "hidden h-4 w-4 shrink-0 self-center text-muted-foreground lg:block" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: step,
				children: [
					num(2, false),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Get new lines"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Every morning by itself, or now"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: onPull,
						disabled: pulling || !linked,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-4 w-4 ${pulling ? "animate-spin" : ""}` }), pulling ? "Getting…" : "Get now"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "hidden h-4 w-4 shrink-0 self-center text-muted-foreground lg:block" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `${step} ${waiting ? "border-primary/40 bg-primary/5" : ""}`,
				children: [
					num(3, false),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Review & reconcile"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: waiting ? `${waiting} new line${waiting === 1 ? "" : "s"} waiting` : "Nothing waiting"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						asChild: true,
						variant: waiting ? "default" : "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/banking",
							search: top ? {
								account: top,
								tab: "review"
							} : { tab: "review" },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "h-4 w-4" }), " Review"]
						})
					})
				]
			})
		]
	});
}
//#endregion
export { BankConnections as t };
