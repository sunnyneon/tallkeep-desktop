//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BL8faCKa.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CQ6r4fJR.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-CmG5sEMU.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CS44MCyc.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CQ6r4fJR.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-Dn1ZXA2g.js",
			"/assets/log-out-DzN5Pb_-.js",
			"/assets/testers.functions-BDMqFYGw.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DL6K1eG6.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DJDr7n6Z.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CvdkIxbU.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-BfXAVHER.js",
			"/assets/dist-DweY6Om1.js",
			"/assets/dialog-DWtUGCz0.js",
			"/assets/queries-BvgGOVA-.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/label-BZy18Ahz.js",
			"/assets/textarea-BgLyPLuh.js",
			"/assets/shoebox-DCeadpJA.js",
			"/assets/company-DYxj9TJ6.js",
			"/assets/reports-NMr7IN2k.js",
			"/assets/access-Bnw-rRQ7.js",
			"/assets/LicenseCard-DqzZBe6V.js",
			"/assets/Logo-C9E2iLMJ.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-DpEhHH8c.js",
			"/assets/log-out-DzN5Pb_-.js",
			"/assets/admin.functions-L9AQaQVx.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-C9E2iLMJ.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DN0kEdWA.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/label-BZy18Ahz.js",
			"/assets/Logo-C9E2iLMJ.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DJr9Fep7.js",
			"/assets/testers.functions-BDMqFYGw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/buy.functions-CJ8rH-n_.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-7LnvQNFe.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/downloads.functions-Cpky9ILJ.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-CcysZHVA.js",
			"/assets/testers.functions-BDMqFYGw.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/textarea-BgLyPLuh.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-C45N184I.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/label-BZy18Ahz.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-ByHrisk6.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/label-BZy18Ahz.js",
			"/assets/Logo-C9E2iLMJ.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-Dhzu_tw-.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/upgrade.functions-C-_wFT_V.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-DVUFO3YH.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/label-BZy18Ahz.js",
			"/assets/Logo-C9E2iLMJ.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DjZA5KQa.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-i3S0LTvT.js", "/assets/StockDocList-BPqFdfHA.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-vs2AzPYa.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/ai-RCTbTWN6.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Bv4AWOch.js",
			"/assets/BankConnections-DPIYZS2a.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-m9rpHSwL.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-Bhdv4DNm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DPIYZS2a.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/ai-RCTbTWN6.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DmeP_MAQ.js",
			"/assets/TxnEditor-TPmVqBn6.js",
			"/assets/feedWaiting-D7RfHt7j.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BXM6nivi.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CG-ofMVv.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/personal-CEYeBIot.js",
			"/assets/members-B06X3UGN.js",
			"/assets/WhoPicker-DovSu4yx.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-73TJ7B0J.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DvceV8zo.js", "/assets/AccountRegister-DuOgWWWf.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CtGnajhC.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-0380mh1J.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/money-BoDxyGX3.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DRtNIYNf.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-RCTbTWN6.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-fOQAoi8M.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BA2cdenh.js", "/assets/StockDocList-BPqFdfHA.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D01bhFcN.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-d2N9G2Kj.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B06X3UGN.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BeBDMJf8.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers--JJBMbT9.js", "/assets/PartyList-Ccn9ZGNK.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BBhWRm1a.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-rD8x_Adj.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/storage.functions-gpwE8sJK.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BFRzgIQz.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CD0t5TB4.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-D7_LUZMq.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Ciw0OOeQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-D6DEYzi6.js", "/assets/ChangeHistory-BMNd9plh.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-Dn5wzupW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/members-B06X3UGN.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-ByggnRRK.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/personal-CEYeBIot.js",
			"/assets/members-B06X3UGN.js",
			"/assets/WhoPicker-DovSu4yx.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-COaIUsjm.js", "/assets/SalesList-Czjjv18w.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-B3XF0HgR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CBu7tbJe.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BEPjDDr0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BCItMdvK.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/loans-DmeP_MAQ.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DpsTmFpk.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-AZKdTMim.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-D69ny2xa.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/personal-CEYeBIot.js",
			"/assets/members-B06X3UGN.js",
			"/assets/WhoPicker-DovSu4yx.js",
			"/assets/reminders-Bzenb-ol.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Cs9blhhX.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-D1Kr13iK.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/personal-CEYeBIot.js",
			"/assets/members-B06X3UGN.js",
			"/assets/WhoPicker-DovSu4yx.js",
			"/assets/generateCategoricalChart-Rzo-c-iz.js",
			"/assets/Area-DD4U0718.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CQLdkCTN.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/generateCategoricalChart-Rzo-c-iz.js",
			"/assets/PlCharts-D7_LUZMq.js",
			"/assets/BarChart-QGXxqZTF.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BLT5E2u-.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-nR2iR1nx.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-iW0oSqJ_.js",
			"/assets/createServerFn--xY3GwOQ.js",
			"/assets/auth-middleware-ZgLZXHgD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/storage.functions-gpwE8sJK.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BYI9FwLB.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CrrontUk.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/checkbox-BIC6Ljvc.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DneOgP1m.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DjgxAEgF.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-FwzMjeb0.js", "/assets/SalesList-Czjjv18w.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CEOhjvX2.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/ai-RCTbTWN6.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-gpwE8sJK.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BmJYiEp-.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/money-BoDxyGX3.js",
			"/assets/badge-DVUDgYDh.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Da5pGp8C.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DikbV-7s.js", "/assets/AccountRegister-DuOgWWWf.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-QZb1FYsN.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/MoneyAccountPick-hGnMQPqv.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-tifkde9g.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BG3ziWk_.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/RepeatInvoice-DFptMq5A.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports--SQKalwm.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-Rzo-c-iz.js",
			"/assets/BarChart-QGXxqZTF.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-D9HOdr28.js", "/assets/SalesList-Czjjv18w.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-PKqr7Cf1.js", "/assets/SalesList-Czjjv18w.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BrPwya4Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CALCD9u5.js",
			"/assets/createServerFn--xY3GwOQ.js",
			"/assets/auth-middleware-ZgLZXHgD.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-B_RyP2Sp.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CB9PdAMh.js",
			"/assets/switch-AZKdTMim.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-BeBDMJf8.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-D53gRE_d.js",
			"/assets/footers-DoP2tDVh.js",
			"/assets/PrintFrame-Se3wA9kZ.js",
			"/assets/checkbox-BIC6Ljvc.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-D6QyXfDM.js",
			"/assets/FeaturePicker-DOFle_Rc.js",
			"/assets/support-CndTQ9iD.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CmNlz2d9.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/FeaturePicker-DOFle_Rc.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-D60HMH8e.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DqwTwBew.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/photos-D53gRE_d.js",
			"/assets/stockmove-aheNAsim.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BqktYxZe.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/loans-DmeP_MAQ.js",
			"/assets/feedWaiting-D7RfHt7j.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-gpwE8sJK.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DatQY3_0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/PrintFrame-Se3wA9kZ.js",
			"/assets/DocPdf-BlJIrH6p.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DSXq_Qm_.js",
			"/assets/createServerFn--xY3GwOQ.js",
			"/assets/auth-middleware-ZgLZXHgD.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/MoneyAccountPick-hGnMQPqv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CndTQ9iD.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CxiApEcZ.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/StockDialogs-DqwTwBew.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/stockmove-aheNAsim.js",
			"/assets/checkbox-BIC6Ljvc.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-CKQut4vi.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/members-B06X3UGN.js",
			"/assets/WhoPicker-DovSu4yx.js",
			"/assets/reminders-Bzenb-ol.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-D6kM2I7F.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/tickets.functions-BbStPAgy.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DceUqtPB.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CndTQ9iD.js",
			"/assets/support.functions-Cr6Kkg2D.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-B_BJ8ydY.js", "/assets/StockDocList-BPqFdfHA.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CB8zHA7h.js", "/assets/PartyList-Ccn9ZGNK.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BSU6fmm3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/tickets.functions-BbStPAgy.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-cXNzxaJK.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/workorders-CVSiJ0oF.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DN8MqcPs.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-3GVvex6l.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/AdminAccount-CDu2AqU4.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-Y3oeTMGk.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/downloads.functions-Cpky9ILJ.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-DyGbcWm0.js",
			"/assets/createServerFn--xY3GwOQ.js",
			"/assets/auth-middleware-ZgLZXHgD.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BYH0xY3M.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BlXcZFmd.js",
			"/assets/testers.functions-BDMqFYGw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BfXAVHER.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-DzhotziG.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-Df-sdrWf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BfXAVHER.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CJ8rH-n_.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Bt-ICQHm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/textarea-BgLyPLuh.js",
			"/assets/support.functions-Cr6Kkg2D.js",
			"/assets/HelpParts-BUZHfiT1.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CR2W79H4.js",
			"/assets/ManualFrame-c19ekt2m.js",
			"/assets/manual._slug-DtNoDKxz.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BQYFQLBD.js",
			"/assets/createServerFn--xY3GwOQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DgBIL3Lw.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BfXAVHER.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-C-_wFT_V.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BW8Iqqd2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-RCTbTWN6.js",
			"/assets/personal-CEYeBIot.js",
			"/assets/reminders-Bzenb-ol.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CpCmevcn.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/AdminAccount-CDu2AqU4.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CEYT9xke.js", "/assets/ManualFrame-c19ekt2m.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CTp4sj2M.js", "/assets/AccountRegister-DuOgWWWf.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Dk58xE4_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/OriginalLink-zq1412O_.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/realestate-u5YlElr6.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C8saWOGs.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DtRGqXjJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/realestate-u5YlElr6.js",
			"/assets/money-BoDxyGX3.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-ToTZeG-c.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/SideList-B5rGAGK_.js",
			"/assets/PartyHistory-Dggd4I7H.js",
			"/assets/tabs-CYUDJEHT.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-UofHJRrv.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-B_RyP2Sp.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BMNd9plh.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/SideList-B5rGAGK_.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-CFW97V_E.js",
			"/assets/MoneyAccountPick-hGnMQPqv.js",
			"/assets/footers-DoP2tDVh.js",
			"/assets/PrintFrame-Se3wA9kZ.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BLkjCosV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DqwTwBew.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BMNd9plh.js",
			"/assets/switch-AZKdTMim.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/badge-DVUDgYDh.js",
			"/assets/SideList-B5rGAGK_.js",
			"/assets/tabs-CYUDJEHT.js",
			"/assets/photos-D53gRE_d.js",
			"/assets/stockmove-aheNAsim.js",
			"/assets/workorders-CVSiJ0oF.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DS6qTzS7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-B_RyP2Sp.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BMNd9plh.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/SideList-B5rGAGK_.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-CFW97V_E.js",
			"/assets/MoneyAccountPick-hGnMQPqv.js",
			"/assets/footers-DoP2tDVh.js",
			"/assets/PrintFrame-Se3wA9kZ.js",
			"/assets/checkbox-BIC6Ljvc.js",
			"/assets/workorders-CVSiJ0oF.js",
			"/assets/RepeatInvoice-DFptMq5A.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BbStPAgy.js",
			"/assets/users.functions-D6QyXfDM.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BFPvWqoe.js",
			"/assets/select-BkBHhjIQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/SideList-B5rGAGK_.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BaP2lMxK.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/quickadd-CaBswLMn.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CndTQ9iD.js",
			"/assets/support.functions-Cr6Kkg2D.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BUL_zxI9.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Bz1BSe_o.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/SideList-B5rGAGK_.js",
			"/assets/PartyHistory-Dggd4I7H.js",
			"/assets/tabs-CYUDJEHT.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CWKuzSTo.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/sales-fOQAoi8M.js",
			"/assets/footers-DoP2tDVh.js",
			"/assets/tickets.functions-BbStPAgy.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BZ0xF_9p.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BfXAVHER.js",
			"/assets/input-DCyS8CCa.js",
			"/assets/skeleton-BqULOdl0.js",
			"/assets/AdminAccount-CDu2AqU4.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-6v_L_Ohh.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-BfXAVHER.js",
			"/assets/textarea-BgLyPLuh.js",
			"/assets/support-CndTQ9iD.js",
			"/assets/support.functions-Cr6Kkg2D.js",
			"/assets/HelpParts-BUZHfiT1.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Be2-cbkj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BqULOdl0.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
