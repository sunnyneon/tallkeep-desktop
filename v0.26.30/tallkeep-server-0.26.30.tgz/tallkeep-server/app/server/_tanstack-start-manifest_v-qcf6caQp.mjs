//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-qcf6caQp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-mhFkh3gW.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Dl8_lz2G.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BEhe2c22.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mhFkh3gW.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CQ_T_njd.js",
			"/assets/log-out-CT2KMwDk.js",
			"/assets/testers.functions-B28cSlst.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CAq42yAI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BEKsJ8hP.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-XC9sCeiK.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-BYswFTle.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/dist-DBWv-WgR.js",
			"/assets/dialog-ROoIAjCM.js",
			"/assets/queries-Xx20vMDe.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/label-DGcLdq4A.js",
			"/assets/textarea-CDNLKvIA.js",
			"/assets/shoebox-B1_4_mxD.js",
			"/assets/company-TzHm2umq.js",
			"/assets/reports-BziR0yWl.js",
			"/assets/access-C1a-kokv.js",
			"/assets/theme-DP3Y46Yg.js",
			"/assets/Logo-BRntQGW7.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-1dnbQWoX.js",
			"/assets/log-out-CT2KMwDk.js",
			"/assets/admin.functions-tYV6ykEK.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-BRntQGW7.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-B3v88BdY.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/label-DGcLdq4A.js",
			"/assets/Logo-BRntQGW7.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-g1WmvzYg.js",
			"/assets/testers.functions-B28cSlst.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/coupons.functions-d2JZ2bks.js",
			"/assets/buy.functions-Djl3Z07q.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-Dy48Kufz.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/downloads.functions-DCGzirIS.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-P9cdG5fY.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/label-DGcLdq4A.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-D4yIOmKt.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/label-DGcLdq4A.js",
			"/assets/Logo-BRntQGW7.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CsD91OQ6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/upgrade.functions-CnjmEgT3.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-D9f4LDEC.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/label-DGcLdq4A.js",
			"/assets/Logo-BRntQGW7.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CNVbvHv7.js",
			"/assets/select-D7sllvPo.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-CZ-41xng.js", "/assets/StockDocList-CACGFDED.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-smAw_475.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/ai-3DP2yoVm.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-DFJ2hXft.js",
			"/assets/BankConnections-DegY2sHf.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-m2w8SnMU.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-bo8pNFsU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DegY2sHf.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/ai-3DP2yoVm.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DNX1vcLS.js",
			"/assets/TxnEditor-BV8BkYaF.js",
			"/assets/feedWaiting-BEe6X1R9.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BPKXwnr2.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CHtZKrzq.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/personal-URKaHD1l.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/WhoPicker-C5WVO4QV.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DuZgVzJY.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DckwAu3q.js", "/assets/AccountRegister-BXDVY1VG.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DU8nJvLI.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-_j3HdDJI.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/money-pjxcDfGd.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-q6-IiRFV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-3DP2yoVm.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BqQOzBDx.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CWvpSisa.js", "/assets/StockDocList-CACGFDED.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DJ21rb5v.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CpUZ06ZU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-C3RHYMb7.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DYc3zuAU.js", "/assets/PartyList-D2tQ6nCd.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CLMF3Tgj.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-D4x-ksOW.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/storage.functions-l_K5Uf8H.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-xxiGNg1i.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-Cmv-PwJr.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-xYafsNTN.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-B6VzTb_w.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BSJWpPdo.js", "/assets/ChangeHistory-PnCyPeL0.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-Bp-SajbB.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/members-I-rBz2SB.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BairHGRD.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/personal-URKaHD1l.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/WhoPicker-C5WVO4QV.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BjAFFA_1.js", "/assets/SalesList-DMppZ8Cl.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-aRLpZNxU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BIAH59l0.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BYreS093.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-izgsjVeb.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/loans-DNX1vcLS.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-C-c34EUV.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Bug-xl68.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CnMFgTO6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/personal-URKaHD1l.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/WhoPicker-C5WVO4QV.js",
			"/assets/reminders-Cdrjm-6P.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DdESWnFr.js",
			"/assets/select-D7sllvPo.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-C0ezyeeM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/personal-URKaHD1l.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/WhoPicker-C5WVO4QV.js",
			"/assets/generateCategoricalChart-B6LRziAN.js",
			"/assets/Area-B_pcZvVX.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-B644eLt3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/generateCategoricalChart-B6LRziAN.js",
			"/assets/PlCharts-xYafsNTN.js",
			"/assets/BarChart-Sk8dALHe.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-Dk-fpKqg.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-C_QOKEJ4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-RizgDna1.js",
			"/assets/createServerFn-DYwjGMH8.js",
			"/assets/auth-middleware-DaczY7VW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/storage.functions-l_K5Uf8H.js",
			"/assets/coupons.functions-d2JZ2bks.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CV-uGxqH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-ChzWZPml.js",
			"/assets/select-D7sllvPo.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/checkbox-Dca9PnDs.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DTe8IaJg.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CHd04Szg.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-D7sllvPo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-C058HYNS.js", "/assets/SalesList-DMppZ8Cl.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BTlWGCSa.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/ai-3DP2yoVm.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-l_K5Uf8H.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-D0mY46g5.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/money-pjxcDfGd.js",
			"/assets/badge-BULn1_6a.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Bd_ajOpi.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CHsfhMQu.js", "/assets/AccountRegister-BXDVY1VG.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-CxjW-IFT.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/MoneyAccountPick-CT9Zljnu.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-CA2rhQQ-.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-Ba7CpxSu.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/RepeatInvoice-GfCf4OR6.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DUa8Zuqy.js",
			"/assets/select-D7sllvPo.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-B6LRziAN.js",
			"/assets/BarChart-Sk8dALHe.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BFvQjJ6n.js", "/assets/SalesList-DMppZ8Cl.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CmHG5n8S.js", "/assets/SalesList-DMppZ8Cl.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-C9pa3XDe.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-595kwS2M.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/serials-ByKyFKzd.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BN6SBVu0.js",
			"/assets/createServerFn-DYwjGMH8.js",
			"/assets/auth-middleware-DaczY7VW.js",
			"/assets/AppsCatalog-DMilyisE.js",
			"/assets/select-D7sllvPo.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CYFRC_Va.js",
			"/assets/switch-Bug-xl68.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-C3RHYMb7.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-B7PDV2cM.js",
			"/assets/footers-D4g78hqH.js",
			"/assets/PrintFrame-BibyFlAJ.js",
			"/assets/checkbox-Dca9PnDs.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-MeK9hwHD.js",
			"/assets/support-D5RNeWwt.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-8DGJyzXh.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-DMilyisE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-DegY2sHf.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/users.functions-MeK9hwHD.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CSN6URuY.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CrZC-H2d.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/photos-B7PDV2cM.js",
			"/assets/stockmove-5UW4VpGg.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-0rPkTSwU.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/loans-DNX1vcLS.js",
			"/assets/feedWaiting-BEe6X1R9.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-l_K5Uf8H.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-tzS3IqmM.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/PrintFrame-BibyFlAJ.js",
			"/assets/DocPdf-CHjsVO6z.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DXTaBR0l.js",
			"/assets/createServerFn-DYwjGMH8.js",
			"/assets/auth-middleware-DaczY7VW.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/MoneyAccountPick-CT9Zljnu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D5RNeWwt.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CBo5NbXh.js",
			"/assets/select-D7sllvPo.js",
			"/assets/StockDialogs-CrZC-H2d.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/stockmove-5UW4VpGg.js",
			"/assets/checkbox-Dca9PnDs.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Cy-lSgr5.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/members-I-rBz2SB.js",
			"/assets/WhoPicker-C5WVO4QV.js",
			"/assets/reminders-Cdrjm-6P.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DRmOUELO.js",
			"/assets/select-D7sllvPo.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/tickets.functions-qbm77dXe.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DOGf1r0L.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D5RNeWwt.js",
			"/assets/support.functions-CFoU1gj3.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Ci78g9qC.js", "/assets/StockDocList-CACGFDED.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-BgQdfe9A.js", "/assets/PartyList-D2tQ6nCd.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BF7m0ML7.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/tickets.functions-qbm77dXe.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DvP6LojT.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/workorders-BFc84K6W.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BDL57c6p.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-C4xl6Rks.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/coupons.functions-d2JZ2bks.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BlTNoBvP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/AdminAccount-Dnh9b0RB.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-D5j4n5F3.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/downloads.functions-DCGzirIS.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C_aPyzVW.js",
			"/assets/createServerFn-DYwjGMH8.js",
			"/assets/auth-middleware-DaczY7VW.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BTan8yI5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BJug-B4Q.js",
			"/assets/testers.functions-B28cSlst.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-L7nkjrNY.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-De_Vfy4j.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-Djl3Z07q.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CTkO41Ek.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/textarea-CDNLKvIA.js",
			"/assets/support.functions-CFoU1gj3.js",
			"/assets/HelpParts-BzRH7Zyg.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-4lyOqY4d.js",
			"/assets/ManualFrame-CiVoUPjp.js",
			"/assets/manual._slug-GvxxDXRa.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-C21TT5Kl.js",
			"/assets/createServerFn-DYwjGMH8.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-peisiEXD.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-CnjmEgT3.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-yb3Vu-D7.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-3DP2yoVm.js",
			"/assets/personal-URKaHD1l.js",
			"/assets/reminders-Cdrjm-6P.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DJchQyB1.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/AdminAccount-Dnh9b0RB.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-pKPmRtR1.js", "/assets/ManualFrame-CiVoUPjp.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D5PjTI6Z.js", "/assets/AccountRegister-BXDVY1VG.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-FGUqr48y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/OriginalLink-CWUrHD2B.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/realestate-DUfTKsbs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-DJISmvP-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BK-Q5Qwz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/realestate-DUfTKsbs.js",
			"/assets/money-pjxcDfGd.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-r3x10NTg.js",
			"/assets/select-D7sllvPo.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/SideList-CIHmgyhl.js",
			"/assets/PartyHistory-UW6YXcVT.js",
			"/assets/tabs-BVfYSD3N.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-ry1Ckpue.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-D7sllvPo.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-PnCyPeL0.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/SideList-CIHmgyhl.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-Dnz9-Gxx.js",
			"/assets/MoneyAccountPick-CT9Zljnu.js",
			"/assets/footers-D4g78hqH.js",
			"/assets/PrintFrame-BibyFlAJ.js",
			"/assets/serials-ByKyFKzd.js",
			"/assets/SerialsBox-QyzJH2t-.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CkHgpj2z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-D7sllvPo.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CrZC-H2d.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-PnCyPeL0.js",
			"/assets/switch-Bug-xl68.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BULn1_6a.js",
			"/assets/SideList-CIHmgyhl.js",
			"/assets/tabs-BVfYSD3N.js",
			"/assets/photos-B7PDV2cM.js",
			"/assets/stockmove-5UW4VpGg.js",
			"/assets/serials-ByKyFKzd.js",
			"/assets/SerialsBox-QyzJH2t-.js",
			"/assets/workorders-BFc84K6W.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-aPcY2sEE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-D7sllvPo.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-PnCyPeL0.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/SideList-CIHmgyhl.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-Dnz9-Gxx.js",
			"/assets/MoneyAccountPick-CT9Zljnu.js",
			"/assets/footers-D4g78hqH.js",
			"/assets/PrintFrame-BibyFlAJ.js",
			"/assets/cardpay-sKeFrxQy.js",
			"/assets/checkbox-Dca9PnDs.js",
			"/assets/serials-ByKyFKzd.js",
			"/assets/workorders-BFc84K6W.js",
			"/assets/RepeatInvoice-GfCf4OR6.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-qbm77dXe.js",
			"/assets/users.functions-MeK9hwHD.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BFDNlwHj.js",
			"/assets/select-D7sllvPo.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/SideList-CIHmgyhl.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BeOPjZ7n.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/quickadd-CI3zGCpH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D5RNeWwt.js",
			"/assets/support.functions-CFoU1gj3.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BOvXmGvd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-5DnTWzGz.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/SideList-CIHmgyhl.js",
			"/assets/PartyHistory-UW6YXcVT.js",
			"/assets/tabs-BVfYSD3N.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-D5hMWTNm.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/sales-BqQOzBDx.js",
			"/assets/footers-D4g78hqH.js",
			"/assets/tickets.functions-qbm77dXe.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-0p8WYneq.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/input-B5qQjIlA.js",
			"/assets/skeleton-BbYn2B5w.js",
			"/assets/AdminAccount-Dnh9b0RB.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BPWN8znH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DqRLVbLo.js",
			"/assets/textarea-CDNLKvIA.js",
			"/assets/support-D5RNeWwt.js",
			"/assets/support.functions-CFoU1gj3.js",
			"/assets/HelpParts-BzRH7Zyg.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BBucXuCc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BbYn2B5w.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
