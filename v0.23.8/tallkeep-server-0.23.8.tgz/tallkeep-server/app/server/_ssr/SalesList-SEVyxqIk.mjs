import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { D as Search, Fn as ArrowDownUp, R as Plus, at as Mail } from "../_libs/lucide-react.mjs";
import { o as useLocations, t as byId } from "./queries-DKvOnwaZ.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { c as isRmaDoc, d as payStatus, n as PAY_STYLE, o as invStatus, s as isQuoteLike, t as INV_STYLE } from "./sales-B9r0ST4P.mjs";
import { i as isPastDue } from "./followups-CAmQFMgv.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/SalesList-SEVyxqIk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEFAULT_FILTERS = {
	show: "orders",
	inv: "all",
	pay: "all",
	cancelled: false
};
/** Shortcuts like inFlow's Sales menu. */
var QUICK = [
	{
		label: "Everything",
		f: {
			show: "all",
			inv: "all",
			pay: "all"
		}
	},
	{
		label: "Invoices",
		f: {
			show: "orders",
			inv: "all",
			pay: "all"
		}
	},
	{
		label: "Unfulfilled",
		f: {
			show: "orders",
			inv: "Unfulfilled",
			pay: "all"
		}
	},
	{
		label: "Unpaid",
		f: {
			show: "orders",
			inv: "all",
			pay: "owed"
		}
	},
	{
		label: "Past due",
		f: {
			show: "orders",
			inv: "all",
			pay: "late"
		}
	},
	{
		label: "Uninvoiced",
		f: {
			show: "orders",
			inv: "all",
			pay: "Uninvoiced"
		}
	},
	{
		label: "Quotes",
		f: {
			show: "quotes",
			inv: "all",
			pay: "all"
		}
	},
	{
		label: "RMAs",
		f: {
			show: "rma",
			inv: "all",
			pay: "all"
		}
	}
];
function SalesList({ title, text, initial, newKind, newLabel }) {
	const navigate = useNavigate();
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const [rawF, setF] = useSticky(`sales-list:${title}`, initial ?? DEFAULT_FILTERS);
	const f = rawF ?? DEFAULT_FILTERS;
	const [search, setSearch] = useSticky("sales-search", {
		q: "",
		customer: ""
	});
	const q = search.q;
	const setQ = (v) => setSearch((x) => ({
		...x,
		q: v
	}));
	const [sort, setSort] = useSticky(`sales-sort:${title}`, {
		k: "order_date",
		desc: true
	});
	const { data, isLoading } = useQuery({
		queryKey: ["sales", "all"],
		queryFn: async () => {
			const out = [];
			for (let from = 0;; from += 1e3) {
				const { data, error } = await db.from("sales_orders").select("id,number,status,order_date,customer_name,total,amount_paid,balance,due_date,po_number,location_id,stock_taken_at,ship_by,custom,followup_count,last_followup_at").order("order_date", { ascending: false }).range(from, from + 999);
				if (error) throw error;
				out.push(...data ?? []);
				if (!data || data.length < 1e3) break;
			}
			return out;
		}
	});
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		const cust = search.customer.trim().toLowerCase();
		const list = (data ?? []).filter((r) => {
			if (r.status === "cancelled" && !f.cancelled) return false;
			if (f.show === "all") {} else if (f.show === "rma") {
				if (!isRmaDoc(r)) return false;
			} else if (isRmaDoc(r) && (isQuoteLike(r.status) || r.status === "cancelled")) return false;
			if (f.show === "orders" && r.status === "quote") return false;
			if (f.show === "quotes" && r.status !== "quote") return false;
			if (f.inv !== "all" && invStatus(r) !== f.inv) return false;
			const ps = payStatus(r);
			if (f.pay === "owed" && !(ps === "Unpaid" || ps === "Partial")) return false;
			if (f.pay === "late" && !((ps === "Unpaid" || ps === "Partial") && isPastDue(r))) return false;
			if (f.pay !== "all" && f.pay !== "owed" && f.pay !== "late" && ps !== f.pay) return false;
			if (cust && !(r.customer_name ?? "").toLowerCase().includes(cust)) return false;
			const hay = `${r.number} ${r.customer_name ?? ""} ${r.po_number ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
		const dir = sort.desc ? -1 : 1;
		return list.sort((a, b) => {
			const x = a[sort.k], y = b[sort.k];
			if (typeof x === "number" || typeof y === "number") return (Number(x) - Number(y)) * dir;
			return String(x ?? "").localeCompare(String(y ?? ""), void 0, { numeric: true }) * dir;
		});
	}, [
		data,
		q,
		search.customer,
		f,
		sort
	]);
	const customers = (0, import_react.useMemo)(() => [...new Set((data ?? []).map((r) => r.customer_name).filter(Boolean))].sort((a, b) => a.localeCompare(b)), [data]);
	const sumTotal = rows.reduce((s, r) => s + Number(r.total), 0);
	const sumBal = rows.filter((r) => !isQuoteLike(r.status) && r.status !== "cancelled").reduce((s, r) => s + Number(r.balance), 0);
	const now = Date.now();
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	const late = f.pay === "late";
	const th = (k, label, right) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		className: `px-3 py-2 font-semibold ${right ? "text-right" : "text-left"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			className: "inline-flex items-center gap-1 hover:text-foreground",
			onClick: () => setSort((s) => ({
				k,
				desc: s.k === k ? !s.desc : true
			})),
			children: [label, sort.k === k && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, { className: "h-3 w-3" })]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title,
				text,
				actions: newKind && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sales/$id",
						params: { id: "new" },
						search: { kind: newKind },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }),
							" ",
							newLabel
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: QUICK.map((x) => {
					const on = Object.entries(x.f).every(([k, v]) => f[k] === v);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => set(x.f),
						className: `rounded-full border px-3 py-1.5 text-sm font-medium ${on ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
						children: x.label
					}, x.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-[minmax(0,1fr)_220px_160px_160px_160px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search order #, customer or PO #",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground",
							children: "Customer:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Customer",
							className: "pl-[5.25rem]",
							placeholder: "all",
							list: "sales-list-customers",
							value: search.customer,
							onChange: (e) => setSearch((x) => ({
								...x,
								customer: e.target.value
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
						id: "sales-list-customers",
						children: customers.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: c }, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.show,
						onValueChange: (v) => set({ show: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Everything"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "orders",
								children: "Invoices only"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "quotes",
								children: "Quotes only"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "both",
								children: "Orders and quotes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "rma",
								children: "RMAs"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.inv,
						onValueChange: (v) => set({ inv: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Inventory: all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Unfulfilled",
								children: "Unfulfilled"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Fulfilled",
								children: "Fulfilled"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.pay,
						onValueChange: (v) => set({ pay: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Payment: all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "owed",
								children: "Unpaid or partial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "late",
								children: "Past due"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Uninvoiced",
								children: "Uninvoiced"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Unpaid",
								children: "Unpaid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Partial",
								children: "Partial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Paid",
								children: "Paid"
							})
						] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					rows.length,
					" shown · total ",
					fmtMoney(sumTotal),
					sumBal > 0 ? ` · still owed ${fmtMoney(sumBal)}` : "",
					(q || search.customer) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "ml-3 underline hover:text-foreground",
						onClick: () => setSearch({
							q: "",
							customer: ""
						}),
						children: "Clear search"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: f.cancelled,
							onChange: (e) => set({ cancelled: e.target.checked })
						}),
						" ",
						"Show cancelled"
					]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card md:hidden",
				children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-muted-foreground",
					children: "Nothing here."
				}), rows.slice(0, 300).map((r) => {
					const ps = payStatus(r);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sales/$id",
						params: { id: r.id },
						search: {},
						className: "flex items-center gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: r.customer_name || "No customer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: [
										r.number,
										" · ",
										fmtDate(r.order_date)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded px-1.5 py-0.5 text-[10px] font-medium ${INV_STYLE[invStatus(r)]}`,
										children: invStatus(r)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded px-1.5 py-0.5 text-[10px] font-medium ${PAY_STYLE[ps]}`,
										children: ps
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: fmtMoney(r.total)
							}), Number(r.balance) > 0 && ps !== "Quote" && ps !== "Cancelled" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-primary",
								children: ["owes ", fmtMoney(r.balance)]
							})]
						})]
					}, r.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-2xl border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							th("number", "Order #"),
							th("order_date", "Order date"),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Inventory"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Payment"
							}),
							th("customer_name", "Customer"),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "P.O. #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Location"
							}),
							th("due_date", "Due date"),
							th("total", "Total", true),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right font-semibold",
								children: "Paid"
							}),
							th("balance", "Balance", true),
							late && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Payment follow-up"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 12,
							className: "p-8 text-center text-muted-foreground",
							children: "Nothing here."
						}) }), rows.slice(0, 500).map((r) => {
							const ps = payStatus(r);
							const overdue = (ps === "Unpaid" || ps === "Partial") && r.due_date && new Date(r.due_date).getTime() < now;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "cursor-pointer hover:bg-muted/50",
								onClick: () => navigate({
									to: "/sales/$id",
									params: { id: r.id },
									search: {}
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 font-medium text-primary",
										children: r.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: fmtDate(r.order_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs font-medium ${INV_STYLE[invStatus(r)]}`,
											children: invStatus(r)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs font-medium ${PAY_STYLE[ps]}`,
											children: ps
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[260px] truncate px-3 py-2",
										children: r.customer_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[140px] truncate px-3 py-2",
										children: r.po_number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: r.location_id ? locName.get(r.location_id) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: `whitespace-nowrap px-3 py-2 ${overdue ? "font-semibold text-primary" : ""}`,
										children: fmtDate(r.due_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(r.total)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(r.amount_paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right font-semibold",
										children: ps === "Quote" ? "" : fmtMoney(r.balance)
									}),
									late && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "whitespace-nowrap px-3 py-2",
										onClick: (e) => e.stopPropagation(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											asChild: true,
											size: "sm",
											variant: "outline",
											className: "h-7",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/sales/$id",
												params: { id: r.id },
												search: { followup: "pay" },
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5" }), " Follow up"]
											})
										}), Number(r.followup_count ?? 0) > 0 && r.last_followup_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-2 text-xs text-muted-foreground",
											children: [
												r.followup_count,
												"× · last ",
												fmtDate(r.last_followup_at)
											]
										})]
									})
								]
							}, r.id);
						})]
					})]
				})
			}),
			rows.length > 500 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Showing the first 500. Search or filter to narrow it down."
			})
		]
	});
}
//#endregion
export { SalesList as t };
