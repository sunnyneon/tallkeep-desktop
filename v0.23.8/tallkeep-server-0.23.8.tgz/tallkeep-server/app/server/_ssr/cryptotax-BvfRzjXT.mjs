import { a as num, v as qbDate } from "./quickbooks-DDZqKZVM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/cryptotax-BvfRzjXT.js
/**
* Crypto tax (step 44 add-on): read an exchange's history file, keep each buy, sell, reward and
* move, and work out gains the way the IRS wants them: lots per wallet, matched by FIFO, HIFO or
* LIFO (chosen per year), short or long term (held more than a year), plus crypto income.
* Nothing here changes the books; it's for the tax return (Form 8949 rows for the CPA).
*/
var KIND_LABEL = {
	buy: "Bought",
	sell: "Sold",
	income: "Income (reward, staking, interest)",
	send: "Sent out",
	receive: "Received",
	fee: "Network fee",
	trade_in: "Traded for (got)",
	trade_out: "Traded away (gave)",
	ignore: "Leave out"
};
function table(csv, must) {
	const i = csv.findIndex((r) => must.every((m) => r.some((c) => c.trim().toLowerCase() === m.toLowerCase())));
	if (i < 0) return null;
	const head = csv[i].map((c) => c.trim().toLowerCase());
	const col = (...names) => {
		for (const n of names) {
			const k = head.indexOf(n.toLowerCase());
			if (k >= 0) return k;
		}
		return -1;
	};
	return {
		rows: csv.slice(i + 1).filter((r) => r.some((c) => c.trim())),
		col
	};
}
var at = (r, i) => i >= 0 ? (r[i] ?? "").trim() : "";
var money = (s) => {
	const v = num(s.replace(/[$€£]/g, ""));
	return Number.isFinite(v) ? Math.abs(v) : NaN;
};
var when = (s) => {
	const d = new Date(s.replace(" UTC", "Z").replace(/^(\d{4}-\d{2}-\d{2}) (\d)/, "$1T$2"));
	if (!Number.isNaN(d.getTime())) return d.toISOString();
	const q = qbDate(s);
	return q ? `${q}T12:00:00.000Z` : "";
};
/** Coinbase: Statements → Transaction history (CSV). */
function coinbase(csv) {
	const t = table(csv, [
		"Timestamp",
		"Transaction Type",
		"Asset"
	]);
	if (!t) return null;
	const c = {
		id: t.col("ID"),
		time: t.col("Timestamp"),
		type: t.col("Transaction Type"),
		asset: t.col("Asset"),
		qty: t.col("Quantity Transacted"),
		sub: t.col("Subtotal"),
		total: t.col("Total (inclusive of fees and/or spread)", "Total"),
		fee: t.col("Fees and/or Spread", "Fees"),
		price: t.col("Price at Transaction", "Spot Price at Transaction"),
		notes: t.col("Notes")
	};
	const out = [];
	for (const r of t.rows) {
		const type = at(r, c.type).toLowerCase();
		const asset = at(r, c.asset).toUpperCase();
		const qty = money(at(r, c.qty));
		const happened_at = when(at(r, c.time));
		if (!asset || !happened_at || !Number.isFinite(qty) || qty === 0) continue;
		const sub = money(at(r, c.sub));
		const price = money(at(r, c.price));
		const usd = Number.isFinite(sub) && sub > 0 ? sub : Number.isFinite(price) ? Math.round(price * qty * 100) / 100 : null;
		const fee = money(at(r, c.fee));
		const note = at(r, c.notes) || null;
		const base = {
			happened_at,
			asset,
			qty,
			usd,
			fee_usd: Number.isFinite(fee) ? fee : 0,
			note,
			source_id: at(r, c.id) || `${happened_at}|${type}|${asset}|${qty}`,
			needs_review: false
		};
		const kind = /^(buy|advanced trade buy|advance trade buy)$/.test(type) ? "buy" : /^(sell|advanced trade sell|advance trade sell)$/.test(type) ? "sell" : /convert/.test(type) ? null : /(reward|staking|learning|interest|inflation|income|earn|airdrop|cashback)/.test(type) ? "income" : /^(send|withdrawal|pro withdrawal)$/.test(type) ? "send" : /^(receive|deposit|pro deposit)$/.test(type) ? "receive" : null;
		if (/convert/.test(type)) {
			const m = (note ?? "").match(/converted\s+([\d.,]+)\s+(\w+)\s+to\s+([\d.,]+)\s+(\w+)/i);
			out.push({
				...base,
				kind: "trade_out",
				source_id: `${base.source_id}|out`
			});
			if (m) out.push({
				...base,
				kind: "trade_in",
				asset: m[4].toUpperCase(),
				qty: money(m[3]),
				source_id: `${base.source_id}|in`
			});
			continue;
		}
		if (!kind) {
			out.push({
				...base,
				kind: "ignore",
				needs_review: true
			});
			continue;
		}
		out.push({
			...base,
			kind,
			needs_review: kind === "receive" || kind === "send" || usd == null
		});
	}
	return out;
}
/** Kraken: History → Export → Trades (CSV). Buys and sells with their dollar cost. */
function krakenTrades(csv) {
	const t = table(csv, [
		"pair",
		"type",
		"cost",
		"vol"
	]);
	if (!t) return null;
	const c = {
		id: t.col("txid"),
		pair: t.col("pair"),
		time: t.col("time"),
		type: t.col("type"),
		cost: t.col("cost"),
		fee: t.col("fee"),
		vol: t.col("vol")
	};
	const out = [];
	for (const r of t.rows) {
		const pair = at(r, c.pair).toUpperCase();
		const m = pair.match(/^(.+?)(ZUSD|USD|USDT|USDC)$/);
		if (!m) continue;
		const asset = m[1].replace(/^X(?=[A-Z]{3,})/, "").replace(/^XBT$/, "BTC").replace(/^XXBT$/, "BTC");
		const happened_at = when(at(r, c.time));
		const qty = money(at(r, c.vol));
		if (!happened_at || !Number.isFinite(qty)) continue;
		const type = at(r, c.type).toLowerCase();
		out.push({
			happened_at,
			kind: type === "sell" ? "sell" : "buy",
			asset: asset === "XBT" ? "BTC" : asset,
			qty,
			usd: money(at(r, c.cost)),
			fee_usd: money(at(r, c.fee)) || 0,
			note: pair,
			source_id: at(r, c.id) || `${happened_at}|${pair}|${qty}`,
			needs_review: false
		});
	}
	return out;
}
/** Any other exchange or wallet: Date, Type, Asset, Quantity, USD (and Fee) columns. */
function generic(csv) {
	const t = table(csv, [
		"Date",
		"Type",
		"Asset"
	]);
	if (!t) return null;
	const c = {
		date: t.col("Date"),
		type: t.col("Type"),
		asset: t.col("Asset", "Coin"),
		qty: t.col("Quantity", "Amount", "Qty"),
		usd: t.col("USD", "Value", "USD Value", "Total"),
		fee: t.col("Fee", "Fee USD")
	};
	const out = [];
	for (const r of t.rows) {
		const happened_at = when(at(r, c.date));
		const asset = at(r, c.asset).toUpperCase();
		const qty = money(at(r, c.qty));
		if (!happened_at || !asset || !Number.isFinite(qty)) continue;
		const ty = at(r, c.type).toLowerCase();
		const kind = /buy/.test(ty) ? "buy" : /sell/.test(ty) ? "sell" : /(reward|stak|interest|income|airdrop)/.test(ty) ? "income" : /(send|withdraw)/.test(ty) ? "send" : /(receive|deposit)/.test(ty) ? "receive" : "ignore";
		const usd = money(at(r, c.usd));
		out.push({
			happened_at,
			kind,
			asset,
			qty,
			usd: Number.isFinite(usd) ? usd : null,
			fee_usd: money(at(r, c.fee)) || 0,
			note: at(r, c.type) || null,
			source_id: `${happened_at}|${ty}|${asset}|${qty}`,
			needs_review: kind === "ignore" || kind === "receive" || !Number.isFinite(usd)
		});
	}
	return out;
}
function readHistory(csv) {
	const cb = coinbase(csv);
	if (cb) return {
		source: "coinbase",
		records: cb
	};
	const kr = krakenTrades(csv);
	if (kr) return {
		source: "kraken",
		records: kr
	};
	const g = generic(csv);
	if (g) return {
		source: "other",
		records: g
	};
	return null;
}
var YEAR_MS = 31536e6;
var r2 = (n) => Math.round(n * 100) / 100;
/**
* Walk every record in time order. Buys and income make lots; sells take lots out by the year's
* method; a send matched with a receive of the same coin within 3 days (in another of your
* wallets) moves the lots, keeping their dates and cost.
*/
function work(records, methodFor) {
	const recs = [...records].filter((r) => r.kind !== "ignore").sort((a, b) => a.happened_at.localeCompare(b.happened_at));
	const lots = [];
	const res = {
		sales: [],
		income: [],
		holdings: [],
		review: []
	};
	const used = /* @__PURE__ */ new Set();
	const pairOf = /* @__PURE__ */ new Map();
	for (const s of recs.filter((r) => r.kind === "send")) {
		const rcv = recs.find((r) => r.kind === "receive" && !used.has(r.id) && r.asset === s.asset && r.wallet_id !== s.wallet_id && Math.abs(new Date(r.happened_at).getTime() - new Date(s.happened_at).getTime()) < 2592e5 && r.qty <= s.qty * 1.0001 && r.qty >= s.qty * .95);
		if (rcv) {
			used.add(rcv.id);
			pairOf.set(s.id, rcv);
			pairOf.set(rcv.id, s);
		}
	}
	const take = (wallet, asset, qty, year) => {
		const method = methodFor(year);
		const mine = lots.filter((l) => l.wallet === wallet && l.asset === asset && l.qty > 1e-12);
		mine.sort((a, b) => method === "hifo" ? b.cost / b.qty - a.cost / a.qty : method === "lifo" ? b.acquired.localeCompare(a.acquired) : a.acquired.localeCompare(b.acquired));
		const out = [];
		let left = qty;
		for (const l of mine) {
			if (left <= 1e-12) break;
			const q = Math.min(l.qty, left);
			const cost = l.cost / l.qty * q;
			out.push({
				...l,
				qty: q,
				cost
			});
			l.cost -= cost;
			l.qty -= q;
			left -= q;
		}
		return {
			out,
			short: left > 1e-9 ? left : 0
		};
	};
	for (const r of recs) {
		const year = new Date(r.happened_at).getUTCFullYear();
		if (r.kind === "buy" || r.kind === "trade_in") {
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			lots.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: r.qty,
				cost: (r.usd ?? 0) + (r.kind === "buy" ? r.fee_usd : 0),
				acquired: r.happened_at
			});
		} else if (r.kind === "income") {
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			res.income.push({
				date: r.happened_at,
				asset: r.asset,
				qty: r.qty,
				usd: r.usd ?? 0,
				wallet: r.wallet_id
			});
			lots.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: r.qty,
				cost: r.usd ?? 0,
				acquired: r.happened_at
			});
		} else if (r.kind === "sell" || r.kind === "trade_out" || r.kind === "fee") {
			const { out, short } = take(r.wallet_id, r.asset, r.qty, year);
			if (short) res.review.push({
				id: r.id,
				why: `Sold ${short.toFixed(8)} ${r.asset} more than this wallet had: bring in the earlier history`
			});
			if (r.kind === "fee") continue;
			const proceeds = r2((r.usd ?? 0) - r.fee_usd);
			if (r.usd == null) res.review.push({
				id: r.id,
				why: "No dollar value"
			});
			if (short) out.push({
				wallet: r.wallet_id,
				asset: r.asset,
				qty: short,
				cost: 0,
				acquired: r.happened_at
			});
			for (const long of [false, true]) {
				const part = out.filter((l) => new Date(r.happened_at).getTime() - new Date(l.acquired).getTime() > YEAR_MS === long);
				if (!part.length) continue;
				const q = part.reduce((s, l) => s + l.qty, 0);
				const c = r2(part.reduce((s, l) => s + l.cost, 0));
				const p = r2(proceeds * (q / r.qty));
				const dates = part.map((l) => l.acquired).sort();
				res.sales.push({
					asset: r.asset,
					qty: q,
					acquired: dates[0],
					various: new Set(dates.map((d) => d.slice(0, 10))).size > 1,
					sold: r.happened_at,
					proceeds: p,
					cost: c,
					gain: r2(p - c),
					long,
					wallet: r.wallet_id
				});
			}
		} else if (r.kind === "send") {
			const rcv = pairOf.get(r.id);
			const { out } = take(r.wallet_id, r.asset, r.qty, year);
			if (rcv) {
				const ratio = rcv.qty / (out.reduce((s, l) => s + l.qty, 0) || 1);
				for (const l of out) lots.push({
					...l,
					wallet: rcv.wallet_id,
					qty: l.qty * Math.min(1, ratio),
					cost: l.cost
				});
			} else res.review.push({
				id: r.id,
				why: "Sent out with no matching receive: a gift, payment, or a wallet not brought in yet?"
			});
		} else if (r.kind === "receive") {
			if (!pairOf.has(r.id)) {
				res.review.push({
					id: r.id,
					why: "Received from outside: is it income, a gift, or from a wallet not brought in yet?"
				});
				lots.push({
					wallet: r.wallet_id,
					asset: r.asset,
					qty: r.qty,
					cost: r.usd ?? 0,
					acquired: r.happened_at
				});
			}
		}
	}
	const hold = /* @__PURE__ */ new Map();
	for (const l of lots) {
		if (l.qty <= 1e-10) continue;
		const k = `${l.wallet}|${l.asset}`;
		const h = hold.get(k) ?? {
			wallet: l.wallet,
			asset: l.asset,
			qty: 0,
			cost: 0
		};
		h.qty += l.qty;
		h.cost += l.cost;
		hold.set(k, h);
	}
	res.holdings = [...hold.values()].map((h) => ({
		...h,
		cost: r2(h.cost)
	})).sort((a, b) => b.cost - a.cost);
	return res;
}
/** Form 8949 rows for one year, as a CSV the CPA (or tax software) can read. */
function form8949(sales, year) {
	const d = (s) => {
		const x = new Date(s);
		return `${String(x.getUTCMonth() + 1).padStart(2, "0")}/${String(x.getUTCDate()).padStart(2, "0")}/${x.getUTCFullYear()}`;
	};
	return [[
		"(a) Description",
		"(b) Date acquired",
		"(c) Date sold",
		"(d) Proceeds",
		"(e) Cost basis",
		"(f) Code",
		"(g) Adjustment",
		"(h) Gain or loss",
		"Part"
	], ...sales.filter((s) => new Date(s.sold).getUTCFullYear() === year).map((s) => [
		`${Number(s.qty.toFixed(8))} ${s.asset}`,
		s.various ? "VARIOUS" : d(s.acquired),
		d(s.sold),
		s.proceeds.toFixed(2),
		s.cost.toFixed(2),
		"",
		"",
		s.gain.toFixed(2),
		s.long ? "Long term (Part II)" : "Short term (Part I)"
	])].map((r) => r.map((c) => /[",]/.test(c) ? `"${c.replace(/"/g, "\"\"")}"` : c).join(",")).join("\r\n");
}
//#endregion
export { work as i, form8949 as n, readHistory as r, KIND_LABEL as t };
