import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { l as require_react_dom, u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, Ut as Download } from "../_libs/lucide-react.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as downloadCsv } from "./csv-D0ewwTlm.mjs";
import { c as load1099, h as threshold1099 } from "./reports-BrTLGjes.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/forms-1099-Gq1JMt89.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
/** "Chicago, IL 60601" from the last line of an address. */
function cityLine(addr) {
	const lines = (addr ?? "").split(/\n/).map((l) => l.trim()).filter(Boolean);
	const last = lines.at(-1) ?? "";
	const m = /^(.*?),?\s+([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$/.exec(last);
	return {
		street: (m ? lines.slice(0, -1) : lines).join(", "),
		city: m?.[1] ?? "",
		state: m?.[2] ?? "",
		zip: m?.[3] ?? ""
	};
}
function Forms1099() {
	const thisYear = (/* @__PURE__ */ new Date()).getFullYear();
	const [year, setYear] = (0, import_react.useState)((/* @__PURE__ */ new Date()).getMonth() < 6 ? thisYear - 1 : thisYear);
	const from = `${year}-01-01`;
	const to = `${year}-12-31`;
	const limit = threshold1099(year);
	const { data, isLoading } = useQuery({
		queryKey: ["forms-1099", year],
		queryFn: async () => {
			const [rows, p] = await Promise.all([load1099(from, to), db.from("company_settings").select("name,legal_name,tax_id,address,mailing_address,phone").maybeSingle()]);
			return {
				rows: rows.filter((v) => v.is_1099 && v.counted >= limit),
				payer: p.data ?? {}
			};
		}
	});
	const rows = data?.rows ?? [];
	const payer = data?.payer;
	const payerName = payer?.legal_name || payer?.name || "";
	const payerAddr = payer?.mailing_address || payer?.address || "";
	const missing = rows.filter((v) => !v.tax_id || !v.address);
	const csv = () => {
		const pa = cityLine(payerAddr);
		downloadCsv(`1099-NEC-${year}`, [[
			"Tax year",
			"Payer name",
			"Payer TIN",
			"Payer street",
			"Payer city",
			"Payer state",
			"Payer ZIP",
			"Recipient name",
			"Recipient TIN",
			"Recipient street",
			"Recipient city",
			"Recipient state",
			"Recipient ZIP",
			"Box 1 Nonemployee compensation"
		], ...rows.map((v) => {
			const ra = cityLine(v.address);
			return [
				String(year),
				payerName,
				payer?.tax_id ?? "",
				pa.street,
				pa.city,
				pa.state,
				pa.zip,
				v.name,
				v.tax_id ?? "",
				ra.street,
				ra.city,
				ra.state,
				ra.zip,
				Math.round(v.counted * 100) / 100
			];
		})]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 print:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "1099 Forms",
				text: "1099-NEC for vendors you marked 'gets a 1099' and paid enough (not counting card payments). Send each vendor their copy by January 31.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: year,
					onChange: (e) => setYear(Number(e.target.value)),
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					children: [
						thisYear,
						thisYear - 1,
						thisYear - 2
					].map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: y,
						children: ["Year ", y]
					}, y))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "How to file"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "mt-1 list-decimal space-y-1 pl-5 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Copy for each vendor (Copy B):" }), " press \"Print vendor copies\" and mail or email one to each vendor."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Copy for the IRS (Copy A):" }), " e-file it with the IRS (free IRIS system) or your accountant, using \"Download the e-file list\". The IRS copy can't be a plain-paper printout; it must be e-filed or on the official red form."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Some states want a copy too. Ask your accountant." })
					]
				})]
			}),
			payer && (!payer.tax_id || !payerAddr) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
				children: [
					"Your company's Tax ID or address is missing. Add it in",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/settings",
						className: "underline",
						children: "Settings → Company"
					}),
					"."
				]
			}),
			missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
				children: [
					missing.length,
					" vendor",
					missing.length === 1 ? " is" : "s are",
					" missing a Tax ID or address:",
					" ",
					missing.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/vendors/$id",
						params: { id: v.id },
						className: "underline",
						children: v.name
					}), i < missing.length - 1 ? ", " : ""] }, v.id)),
					". Get it from their W-9."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => window.print(),
					disabled: !rows.length,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }),
						" Print vendor copies (",
						rows.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: csv,
					disabled: !rows.length,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download the e-file list"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "p-8 text-center text-muted-foreground",
					children: [
						"No vendor needs a 1099 for ",
						year,
						" (marked \"gets a 1099\" and paid",
						" ",
						fmtMoney(limit),
						" or more)."
					]
				}), rows.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [v.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted-foreground",
							children: [
								v.tax_id ? `Tax ID ${v.tax_id}` : "No Tax ID",
								" ·",
								" ",
								v.address ? v.address.split("\n")[0] : "No address"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: fmtMoney(v.counted)
					})]
				}, v.id))]
			})
		]
	}), typeof document !== "undefined" && data && (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "form1099-print hidden bg-white text-black print:block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: "@page { size: letter; margin: 0.6in } @media print { body > *:not(.form1099-print) { display: none !important } }" }), rows.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-[10pt]",
			style: { pageBreakAfter: "always" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between border-b-2 border-black pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[16pt] font-bold",
						children: "Form 1099-NEC"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nonemployee Compensation" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[14pt] font-bold",
							children: year
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Copy B — For Recipient"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-0 border border-black",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-r border-black p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[8pt] uppercase",
									children: "Payer's name and address"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: payerName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "whitespace-pre-line",
									children: payerAddr
								}),
								payer?.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: payer.phone })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-black p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[8pt] uppercase",
								children: "1 Nonemployee compensation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[16pt] font-bold",
								children: fmtMoney(v.counted)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-r border-black p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[8pt] uppercase",
								children: "Payer's TIN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: payer?.tax_id ?? "" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-black p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[8pt] uppercase",
								children: "Recipient's TIN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: v.tax_id ? `***-**-${v.tax_id.replace(/\D/g, "").slice(-4)}` : "" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "col-span-2 p-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[8pt] uppercase",
									children: "Recipient's name and address"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: v.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "whitespace-pre-line",
									children: v.address
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[8pt] leading-snug",
					children: "This is important tax information and is being furnished to the IRS. If you are required to file a return, a negligence penalty or other sanction may be imposed on you if this income is taxable and the IRS determines that it has not been reported. Card and third-party network payments are not included; they are reported on Form 1099-K."
				})
			]
		}, v.id))]
	}), document.body)] });
}
//#endregion
export { Forms1099 as component };
