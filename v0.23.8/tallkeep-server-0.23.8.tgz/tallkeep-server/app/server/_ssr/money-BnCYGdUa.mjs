import { n as db } from "./db-C-LmScFU.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/money-BnCYGdUa.js
var METHOD_LABEL = {
	check: "Check",
	ach: "Online / ACH",
	card: "Card",
	cash: "Cash",
	other: "Other"
};
/** Accounts money can be paid from: banks, credit cards, cash-like accounts. */
var payFromAccounts = (accounts) => (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card" || a.kind === "other_asset"));
/** Next check number for a bank account: one more than the highest used. */
async function nextCheckNumber(accountId) {
	const { data } = await db.from("checks").select("number").eq("account_id", accountId).eq("method", "check").not("number", "is", null).order("created_at", { ascending: false }).limit(500);
	const nums = (data ?? []).map((r) => Number(r.number)).filter((n) => Number.isFinite(n) && n > 0);
	return nums.length ? String(Math.max(...nums) + 1) : "1001";
}
var ONES = [
	"",
	"One",
	"Two",
	"Three",
	"Four",
	"Five",
	"Six",
	"Seven",
	"Eight",
	"Nine",
	"Ten",
	"Eleven",
	"Twelve",
	"Thirteen",
	"Fourteen",
	"Fifteen",
	"Sixteen",
	"Seventeen",
	"Eighteen",
	"Nineteen"
];
var TENS = [
	"",
	"",
	"Twenty",
	"Thirty",
	"Forty",
	"Fifty",
	"Sixty",
	"Seventy",
	"Eighty",
	"Ninety"
];
function under1000(n) {
	const h = Math.floor(n / 100);
	const r = n % 100;
	const parts = [];
	if (h) parts.push(`${ONES[h]} Hundred`);
	if (r >= 20) parts.push(TENS[Math.floor(r / 10)] + (r % 10 ? `-${ONES[r % 10]}` : ""));
	else if (r) parts.push(ONES[r]);
	return parts.join(" ");
}
/** 1234.5 → "One Thousand Two Hundred Thirty-Four and 50/100" (as written on a check). */
function amountInWords(amount) {
	const cents = Math.round(Math.abs(amount) * 100);
	let dollars = Math.floor(cents / 100);
	const c = cents % 100;
	if (dollars === 0) return `Zero and ${String(c).padStart(2, "0")}/100`;
	const scales = [
		"",
		"Thousand",
		"Million",
		"Billion"
	];
	const parts = [];
	for (let i = 0; dollars > 0; i++) {
		const chunk = dollars % 1e3;
		if (chunk) parts.unshift(`${under1000(chunk)}${scales[i] ? ` ${scales[i]}` : ""}`);
		dollars = Math.floor(dollars / 1e3);
	}
	return `${parts.join(" ")} and ${String(c).padStart(2, "0")}/100`;
}
//#endregion
export { payFromAccounts as i, amountInWords as n, nextCheckNumber as r, METHOD_LABEL as t };
