import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/workorders-CuzhTmEg.js
var WO_STATUS = {
	planned: "Planned",
	in_progress: "Being built",
	done: "Finished",
	cancelled: "Cancelled"
};
function useLiteProducts() {
	return useQuery({
		queryKey: ["products-lite"],
		queryFn: async () => {
			return (await fetchAll("products", "id,name,cost,item_type,is_active,default_location_id,build_extra_cost")).map((r) => ({
				...r,
				cost: Number(r.cost),
				build_extra_cost: Number(r.build_extra_cost ?? 0)
			})).sort((a, b) => a.name.localeCompare(b.name));
		}
	});
}
/** Every recipe line (small table), grouped by the product they make. */
function useRecipes() {
	return useQuery({
		queryKey: ["recipes"],
		queryFn: async () => {
			const rows = await fetchAll("product_parts", "id,product_id,part_id,qty,notes");
			const by = /* @__PURE__ */ new Map();
			for (const r of rows) {
				const list = by.get(r.product_id) ?? [];
				list.push({
					...r,
					qty: Number(r.qty)
				});
				by.set(r.product_id, list);
			}
			return by;
		}
	});
}
/** Make a work order with its parts from the product's recipe. Returns its id and number. */
async function createWorkOrder(o) {
	const { data: number, error: ne } = await db.rpc("next_doc_number", { _kind: "work_order" });
	if (ne) throw ne;
	const { data: u } = await db.auth.getUser();
	const { data: wo, error } = await db.from("work_orders").insert({
		number,
		product_id: o.product_id,
		qty: o.qty,
		location_id: o.location_id,
		due_date: o.due_date ?? null,
		sales_order_id: o.sales_order_id ?? null,
		extra_cost: Math.round(o.extra_per_unit * o.qty * 100) / 100,
		notes: o.notes ?? null,
		created_by: u.user?.id
	}).select("id,number").single();
	if (error) throw error;
	const w = wo;
	if (o.recipe.length) {
		const { error: le } = await db.from("work_order_lines").insert(o.recipe.map((r) => ({
			work_order_id: w.id,
			part_id: r.part_id,
			qty: Math.round(r.qty * o.qty * 1e4) / 1e4
		})));
		if (le) throw le;
	}
	return w;
}
//#endregion
export { useRecipes as i, createWorkOrder as n, useLiteProducts as r, WO_STATUS as t };
