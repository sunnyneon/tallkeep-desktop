//#region ../../node_modules/.nitro/vite/services/ssr/assets/zone.server-sf_zdRjJ.js
/**
* Server-side check: does this user have the section in the company they're working in?
* With the person's own sign-in (sb), the database decides (per-company sections, company
* admins); without it, only the account-wide sections are checked.
*/
async function requireZone(userId, zones, what, sb) {
	if (sb) {
		const db = sb;
		for (const z of zones) {
			const { data } = await db.rpc("has_zone", {
				_uid: userId,
				_zone: z
			});
			if (data === true) return;
		}
		throw new Error(`You don't have access to ${what}.`);
	}
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("*").eq("user_id", userId);
	if (!(data ?? []).some((r) => r.role === "admin" || r.zones == null || r.zones.some((z) => zones.includes(z)))) throw new Error(`You don't have access to ${what}.`);
}
/**
* The company the signed-in person is working in, checked by the database (they must be
* allowed in it). Stops when there's none, or when the account is read-only and `write` is set.
*/
async function activeCompany(sb, write = false) {
	const db = sb;
	const { data: co } = await db.rpc("active_company");
	if (!co) throw new Error("Open a company first.");
	if (write) {
		const { data: ok } = await db.rpc("can_write_company", { _c: co });
		if (ok === false) throw new Error("Your books are read-only. Pick a plan in Plan & billing to keep going.");
	}
	return co;
}
/** People in Tallkeep's own account (SunRise LED's website tools and the like). */
async function requirePlatform(userId) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { data: m } = await db.from("org_members").select("org_id").eq("user_id", userId).maybeSingle();
	if (!m?.org_id) {
		if (process.env["TALLKEEP_DESKTOP"]) return;
		throw new Error("This isn't open for your account.");
	}
	const { data: o } = await db.from("orgs").select("is_platform").eq("id", m.org_id).maybeSingle();
	if (!o?.is_platform && !process.env["TALLKEEP_DESKTOP"]) throw new Error("This isn't open for your account.");
}
//#endregion
export { activeCompany, requirePlatform, requireZone };
