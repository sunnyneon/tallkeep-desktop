import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { C as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Route } from "./go._kind._id-D892-DFJ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/go._kind._id-CENcGJqq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Where a journal entry's source document lives in the app. */
async function sourceHref(type, id) {
	if (!id) return "/journal";
	const one = async (table, cols) => {
		const { data } = await db.from(table).select(cols).eq("id", id).maybeSingle();
		return data ?? {};
	};
	switch (type) {
		case "invoice":
		case "invoice_cogs": return `/sales/${id}`;
		case "po": return `/po/${id}`;
		case "bill": return `/bills/${id}`;
		case "check": return `/checks/${id}`;
		case "payment":
		case "po_payment": {
			const p = await one("payments", "sales_order_id,purchase_order_id,check_id");
			if (p["check_id"]) return `/checks/${p["check_id"]}`;
			if (p["sales_order_id"]) return `/sales/${p["sales_order_id"]}`;
			if (p["purchase_order_id"]) return `/po/${p["purchase_order_id"]}`;
			return "/sales-list";
		}
		case "bill_payment": {
			const p = await one("bill_payments", "bill_id,check_id");
			if (p["check_id"]) return `/checks/${p["check_id"]}`;
			return p["bill_id"] ? `/bills/${p["bill_id"]}` : "/bills";
		}
		case "stock": {
			const m = await one("stock_moves", "ref_type,ref_id,product_id");
			if (m["ref_type"] === "sales_order" && m["ref_id"]) return `/sales/${m["ref_id"]}`;
			if (m["ref_type"] === "purchase_order" && m["ref_id"]) return `/po/${m["ref_id"]}`;
			if (m["ref_type"] === "stock_doc" && m["ref_id"]) return `/stock-doc/${m["ref_id"]}`;
			return m["product_id"] ? `/products/${m["product_id"]}` : "/movements";
		}
		case "deposit": return "/deposits";
		case "transfer": return "/bank-transfers";
		case "rent_charge":
		case "rent_payment": return "/rent";
		case "work_order": return "/work-orders";
		default: return "/journal";
	}
}
/** Same, starting from a journal entry id. */
async function entryHref(entryId) {
	const { data } = await db.from("journal_entries").select("source_type,source_id,ref").eq("id", entryId).maybeSingle();
	if (!data) return "/journal";
	if (data.source_type === "manual" && data.ref === "PAYROLL") return "/payroll";
	return sourceHref(data.source_type, data.source_id);
}
/** Opens whatever made a line in the books: /go/entry/<journal entry id> or /go/<type>/<id>. */
function Go() {
	const { kind, id } = Route.useParams();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		let live = true;
		(kind === "entry" ? entryHref(id) : sourceHref(kind, id)).then((href) => {
			if (live) router.history.replace(href);
		});
		return () => {
			live = false;
		};
	}, [
		kind,
		id,
		router
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) });
}
//#endregion
export { Go as component };
