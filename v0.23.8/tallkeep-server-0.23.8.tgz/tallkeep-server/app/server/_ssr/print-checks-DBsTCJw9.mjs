import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { l as require_react_dom, u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as amountInWords } from "./money-BnCYGdUa.mjs";
import { t as Route } from "./print-checks-xMXT7MII.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/print-checks-DBsTCJw9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
var NUDGE_KEY = "print-checks-nudge";
function PrintChecks() {
	const search = Route.useSearch();
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data, isLoading } = useQuery({
		queryKey: [
			"checks",
			"to-print",
			search.only ?? ""
		],
		queryFn: async () => {
			let q = db.from("checks").select("*").eq("status", "ok").eq("method", "check");
			q = search.only ? q.eq("id", search.only) : q.eq("to_print", true);
			const { data: cs, error } = await q.order("check_date").order("created_at");
			if (error) throw error;
			const checks = (cs ?? []).map((c) => ({
				...c,
				total: Number(c.total)
			}));
			const ids = checks.map((c) => c.id);
			const details = /* @__PURE__ */ new Map();
			if (ids.length) {
				const [l, bp, pp] = await Promise.all([
					db.from("check_lines").select("check_id,description,amount,account_id").in("check_id", ids),
					db.from("bill_payments").select("check_id,amount,bills(ref,bill_date)").in("check_id", ids),
					db.from("payments").select("check_id,amount,purchase_orders(number)").in("check_id", ids)
				]);
				const add = (id, d) => details.set(id, [...details.get(id) ?? [], d]);
				for (const x of bp.data ?? []) add(x.check_id, {
					label: `Bill ${x.bills?.ref ?? ""} ${x.bills ? fmtDate(x.bills.bill_date) : ""}`.trim(),
					amount: Number(x.amount)
				});
				for (const x of pp.data ?? []) add(x.check_id, {
					label: x.purchase_orders?.number ?? "Purchase order",
					amount: Number(x.amount)
				});
				for (const x of l.data ?? []) add(x.check_id, {
					label: x.description || "Expense",
					amount: Number(x.amount)
				});
			}
			return {
				checks,
				details
			};
		}
	});
	const [pick, setPick] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [first, setFirst] = (0, import_react.useState)("");
	const [nudge, setNudge] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const [printed, setPrinted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const v = JSON.parse(localStorage.getItem(NUDGE_KEY) ?? "null");
			if (v) setNudge(v);
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!data) return;
		setPick(new Set(data.checks.map((c) => c.id)));
		const n = data.checks.find((c) => c.number)?.number;
		if (n && !first) setFirst(n);
	}, [data, first]);
	const chosen = (0, import_react.useMemo)(() => (data?.checks ?? []).filter((c) => pick.has(c.id)), [data, pick]);
	const numbered = chosen.map((c, i) => ({
		...c,
		number: /^\d+$/.test(first) ? String(Number(first) + i) : c.number
	}));
	const acctName = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
	const saveNudge = (n) => {
		setNudge(n);
		try {
			localStorage.setItem(NUDGE_KEY, JSON.stringify(n));
		} catch {}
	};
	async function markPrinted() {
		for (const c of numbered) {
			const { error } = await db.from("checks").update({
				number: c.number,
				to_print: false,
				printed_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("id", c.id);
			if (error) return void toast.error(error.message);
		}
		toast.success(`${numbered.length} check${numbered.length === 1 ? "" : "s"} marked as printed.`);
		setPrinted(false);
		qc.invalidateQueries({ queryKey: ["checks"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 print:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Print Checks",
				text: "For voucher checks (check on top, two stubs below), one check per page. Put the check paper in the printer, then press Print."
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
			data && data.checks.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-2xl border bg-card p-8 text-center text-muted-foreground",
				children: [
					"No checks waiting to print. Tick \"Print later\" when you",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checks/$id",
						params: { id: "new" },
						search: {},
						className: "underline",
						children: "write a check"
					}),
					" ",
					"or pay bills by check."
				]
			}),
			data && data.checks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-2xl border bg-card text-sm",
					children: data.checks.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer items-center gap-3 px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: pick.has(c.id),
								onChange: (e) => {
									const n = new Set(pick);
									if (e.target.checked) n.add(c.id);
									else n.delete(c.id);
									setPick(n);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24 text-xs",
								children: fmtDate(c.check_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [c.payee, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: acctName.get(c.account_id)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: fmtMoney(c.total)
							})
						]
					}, c.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Number on the first check in the printer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "w-32",
								value: first,
								onChange: (e) => setFirst(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Move right (1/16 in)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "w-24",
								type: "number",
								value: nudge.x,
								onChange: (e) => saveNudge({
									...nudge,
									x: Number(e.target.value) || 0
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Move down (1/16 in)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "w-24",
								type: "number",
								value: nudge.y,
								onChange: (e) => saveNudge({
									...nudge,
									y: Number(e.target.value) || 0
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							disabled: !chosen.length,
							onClick: () => {
								window.print();
								setPrinted(true);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }),
								" Print ",
								chosen.length,
								" check",
								chosen.length === 1 ? "" : "s"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Tip: print one on plain paper first and hold it over a check to see if it lines up. In the print window, choose no margins and 100% size."
				}),
				printed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
					children: [
						"Did all the checks print right?",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							onClick: () => void markPrinted(),
							children: "Yes, mark them printed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setPrinted(false),
							children: "No, I'll print again"
						})
					]
				})
			] })
		]
	}), typeof document !== "undefined" && (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "check-print hidden print:block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: "@page { size: letter; margin: 0 } @media print { body > *:not(.check-print) { display: none !important } }" }), numbered.map((c) => {
			const lines = data?.details.get(c.id) ?? [];
			const stub = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "h-[3.5in] px-[0.5in] pt-[0.4in] text-[10pt]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.payee }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							fmtDate(c.check_date),
							" · Check ",
							c.number
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "mt-2 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.slice(0, 10).map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: l.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right",
							children: fmtMoney(l.amount)
						})] }, i)) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex justify-between border-t pt-1 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: acctName.get(c.account_id) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtMoney(c.total) })]
					})
				]
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-[11in] w-[8.5in] break-after-page text-black",
				style: { pageBreakAfter: "always" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-[3.5in]",
						style: { transform: `translate(${nudge.x / 16}in, ${nudge.y / 16}in)` },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-[6.6in] top-[0.62in] text-[11pt]",
								children: fmtDate(c.check_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-[0.95in] top-[1.22in] text-[11pt]",
								children: c.payee
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "absolute left-[6.6in] top-[1.22in] text-[11pt]",
								children: ["**", c.total.toLocaleString("en-US", {
									minimumFractionDigits: 2,
									maximumFractionDigits: 2
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "absolute left-[0.4in] top-[1.58in] text-[10.5pt]",
								children: [amountInWords(c.total), "*".repeat(Math.max(3, 90 - amountInWords(c.total).length))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-[0.95in] top-[1.95in] whitespace-pre-line text-[10pt] leading-tight",
								children: [c.payee, c.address].filter(Boolean).join("\n")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute left-[0.6in] top-[2.92in] text-[10pt]",
								children: c.memo
							})
						]
					}),
					stub,
					stub
				]
			}, c.id);
		})]
	}), document.body)] });
}
//#endregion
export { PrintChecks as component };
