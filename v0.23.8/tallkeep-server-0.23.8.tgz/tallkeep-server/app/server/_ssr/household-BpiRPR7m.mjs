import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { f as useAccounts } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { g as Trash2, u as UserPlus } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as useMembers, n as mtbl, r as useAccountOwners, t as MEMBER_COLORS } from "./members-BvdxHr68.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/household-BpiRPR7m.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OWNED_KINDS = [
	"bank",
	"credit_card",
	"other_asset",
	"fixed_asset",
	"long_term_liability",
	"other_liability"
];
function Household() {
	const qc = useQueryClient();
	const { data: members, isLoading } = useMembers();
	const { data: owners } = useAccountOwners();
	const { data: accounts } = useAccounts();
	const [name, setName] = (0, import_react.useState)("");
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["household-members"] });
		qc.invalidateQueries({ queryKey: ["account-owners"] });
	};
	async function add() {
		const n = name.trim();
		if (!n) return void toast.error("Type a name.");
		const color = MEMBER_COLORS[(members?.length ?? 0) % MEMBER_COLORS.length];
		const { error } = await mtbl("household_members").insert({
			name: n,
			color,
			sort: members?.length ?? 0
		});
		if (error) return void toast.error(error.message);
		setName("");
		refresh();
	}
	async function rename(id, n) {
		if (!n.trim()) return;
		const { error } = await mtbl("household_members").update({ name: n.trim() }).eq("id", id);
		if (error) return void toast.error(error.message);
		refresh();
	}
	async function remove(id) {
		const { error } = await mtbl("household_members").delete().eq("id", id);
		if (error) return void toast.error(error.message);
		toast.success("Removed. Their accounts are now joint.");
		refresh();
	}
	async function owner(accountId, memberId) {
		const { error } = await mtbl("accounts").update({ member_id: memberId || null }).eq("id", accountId);
		if (error) return void toast.error(error.message);
		refresh();
	}
	if (isLoading || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" }) });
	const list = accounts.filter((a) => a.is_active && OWNED_KINDS.includes(a.kind));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Household",
			text: "Add the people in your household, then say whose each account is. Budget, Net Worth, Investments and Bills can then show everyone or one person."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-3 rounded-2xl border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "People"
				}),
				(members ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-w-lg items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "h-4 w-4 shrink-0 rounded-full",
							style: { backgroundColor: m.color ?? "#0E7C74" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Name",
							defaultValue: m.name,
							onBlur: (e) => e.target.value !== m.name && void rename(m.id, e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": `Remove ${m.name}`,
							onClick: () => void remove(m.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, m.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-w-lg gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						"aria-label": "New person",
						placeholder: "Like Matthew, Sara or Kids",
						value: name,
						onChange: (e) => setName(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && void add()
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void add(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), " Add person"]
					})]
				})
			]
		}),
		(members?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "border-b bg-muted/40 px-4 py-2 font-semibold",
				children: "Whose is each account?"
			}), list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-t px-4 py-2 text-sm first:border-t-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: a.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": `Whose is ${a.name}`,
					className: "h-9 w-44 rounded-md border bg-background px-2 text-sm",
					value: owners?.get(a.id) ?? "",
					onChange: (e) => void owner(a.id, e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Joint (everyone)"
					}), (members ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: m.id,
						children: m.name
					}, m.id))]
				})]
			}, a.id))]
		})
	] });
}
//#endregion
export { Household as component };
