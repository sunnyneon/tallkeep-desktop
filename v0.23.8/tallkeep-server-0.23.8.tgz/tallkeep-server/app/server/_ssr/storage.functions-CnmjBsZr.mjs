import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/storage.functions-CnmjBsZr.js
/**
* How much space an account's kept files take (statements, receipts, photos), and how much its
* online plan includes. The desktop app has no limit: files stay on the office computer.
*/
var getStorage_createServerFn_handler = createServerRpc({
	id: "1acd810adfe8cc90c5543dff8b075033311630f73f88b295ecf5aa9bfb29a954",
	name: "getStorage",
	filename: "src/lib/storage.functions.ts"
}, (opts) => getStorage.__executeServer(opts));
var getStorage = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getStorage_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { EDITIONS, TRIAL_STORAGE_GB } = await import("./editions-CIhnK_Ff.mjs").then((n) => n.c).then((n) => n.l);
	const db = supabaseAdmin;
	const { data: m } = await db.from("org_members").select("org_id").eq("user_id", context.userId).maybeSingle();
	if (!m?.org_id) return {
		used: 0,
		limit: null,
		desktop: false
	};
	const { data: o } = await db.from("orgs").select("status,plan,edition,is_platform").eq("id", m.org_id).maybeSingle();
	const { data: used } = await db.rpc("org_storage_used", { _org: m.org_id });
	const desktop = o?.edition === "desktop";
	const gb = desktop || o?.is_platform ? null : o?.plan && EDITIONS[o.plan] ? EDITIONS[o.plan].storageGb : TRIAL_STORAGE_GB;
	return {
		used: Number(used ?? 0),
		limit: gb == null ? null : gb * 1024 ** 3,
		desktop
	};
});
//#endregion
export { getStorage_createServerFn_handler };
