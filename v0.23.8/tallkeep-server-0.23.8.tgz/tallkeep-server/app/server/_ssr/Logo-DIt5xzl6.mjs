import { t as cn } from "./utils-C_uf36nf.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/Logo-DIt5xzl6.js
var import_jsx_runtime = require_jsx_runtime();
/** Tallkeep logo: the mark is exactly as tall as the name's capitals. */
function Logo({ compactOnTablet, className, light, auto }) {
	if (auto) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
		compactOnTablet: !!compactOnTablet,
		className: cn("dark:hidden", className),
		light: true
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
		compactOnTablet: !!compactOnTablet,
		className: cn("hidden dark:flex", className)
	})] });
	const full = light ? "/tallkeep-menu-light.svg" : "/tallkeep-menu-dark.svg";
	const mark = light ? "/tallkeep-mark.svg" : "/tallkeep-mark-light.svg";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center", className),
		children: [compactOnTablet && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: mark,
			alt: "Tallkeep",
			className: "h-8 w-auto lg:hidden"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: full,
			alt: "Tallkeep",
			className: cn("h-9 w-auto", compactOnTablet && "hidden lg:block")
		})]
	});
}
//#endregion
export { Logo as t };
