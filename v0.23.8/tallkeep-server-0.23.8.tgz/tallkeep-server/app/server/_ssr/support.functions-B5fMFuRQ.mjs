import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/support.functions-B5fMFuRQ.js
/**
* Support Desk server calls.
*
* The support page (/help/<address>) has no sign-in: a customer opens a ticket, then follows it
* with the secret link /help/t/<key>. Staff work tickets in the app; replies are emailed.
*/
var validOrigin = (o) => {
	const s = String(o ?? "");
	return /^https?:\/\/[^\s/]+$/.test(s) ? s : "";
};
var getSupportPage_createServerFn_handler = createServerRpc({
	id: "f8465b5a6844a72aa64a56949439349602aaa2860cac1d67442dfe948e025036",
	name: "getSupportPage",
	filename: "src/lib/support.functions.ts"
}, (opts) => getSupportPage.__executeServer(opts));
var getSupportPage = createServerFn({ method: "GET" }).inputValidator((d) => ({ slug: String(d?.slug ?? "") })).handler(getSupportPage_createServerFn_handler, async ({ data }) => {
	const { companyForSlug } = await import("./support.server-Bv8yioBw.mjs");
	const co = await companyForSlug(data.slug);
	if (!co) return null;
	return {
		name: co.name ?? "Support",
		intro: co.support_intro,
		topics: (co.support_topics ?? []).filter(Boolean)
	};
});
var openTicket_createServerFn_handler = createServerRpc({
	id: "40f995acabc3d24a380ab7d182bbf46b853bb07eb89be8ccb844a7b7012a806d",
	name: "openTicket",
	filename: "src/lib/support.functions.ts"
}, (opts) => openTicket.__executeServer(opts));
var openTicket = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(openTicket_createServerFn_handler, async ({ data }) => {
	const s = await import("./support.server-Bv8yioBw.mjs");
	const co = await s.companyForSlug(data.slug);
	if (!co) throw new Error("This support page isn't open.");
	if (data.website) return { key: "" };
	const name = s.clean(data.name, 120);
	const email = s.clean(data.email, 200).toLowerCase();
	const subject = s.clean(data.subject, 200);
	const message = s.clean(data.message, 2e4);
	if (!name) throw new Error("Type your name.");
	if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Type a valid email.");
	if (!subject) throw new Error("Type what it's about.");
	if (!message) throw new Error("Tell us what's going on.");
	const hourAgo = (/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString();
	const { count } = await s.admin.from("tickets").select("id", {
		count: "exact",
		head: true
	}).eq("company_id", co.company_id).ilike("email", email).gte("created_at", hourAgo);
	if ((count ?? 0) >= 5) throw new Error("You've opened several tickets just now. Please wait a little.");
	const { count: all } = await s.admin.from("tickets").select("id", {
		count: "exact",
		head: true
	}).eq("company_id", co.company_id).gte("created_at", hourAgo);
	if ((all ?? 0) >= 30) throw new Error("Lots of tickets came in just now. Please try again in an hour.");
	const { data: cust } = await s.admin.from("customers").select("id").eq("company_id", co.company_id).ilike("email", email).limit(1);
	const topics = (co.support_topics ?? []).filter(Boolean);
	const topic = s.clean(data.topic, 80);
	const { data: t, error } = await s.admin.from("tickets").insert({
		company_id: co.company_id,
		subject,
		topic: topics.includes(topic) ? topic : null,
		name,
		email,
		phone: s.clean(data.phone, 40) || null,
		company_name: s.clean(data.company, 120) || null,
		address: s.clean(data.address, 300) || null,
		customer_id: cust?.[0]?.id ?? null,
		source: "page",
		last_customer_at: (/* @__PURE__ */ new Date()).toISOString()
	}).select("id,number,public_key").single();
	if (error) throw new Error(error.message);
	const files = await s.saveFiles(co.company_id, t.id, data.files ?? []);
	await s.admin.from("ticket_messages").insert({
		company_id: co.company_id,
		ticket_id: t.id,
		kind: "customer",
		author_name: name,
		body: message,
		files
	});
	const origin = validOrigin(data.origin);
	const link = origin ? `${origin}/help/t/${t.public_key}` : "";
	const toCustomer = await s.sendMailWhy({
		co,
		to: [email],
		subject: `We got your request ${t.number}: ${subject}`,
		text: `Hi ${name},\n\nThanks for reaching out. We got your request and will get back to you soon.\n\nTicket: ${t.number}\nAbout: ${subject}${link ? `\n\nSee it and add more here:\n${link}` : ""}\n\n${co.name ?? ""}`
	});
	const staffTo = (co.support_notify_email || co.email || "").split(/[,;\s]+/).filter(Boolean);
	const toStaff = await s.sendMailWhy({
		co,
		to: staffTo,
		replyTo: email,
		subject: `New ticket ${t.number} from ${name}: ${subject}`,
		text: `${name} <${email}>${data.phone ? ` · ${s.clean(data.phone, 40)}` : ""}\n\n${message}${origin ? `\n\nOpen it: ${origin}/tickets/${t.id}` : ""}`
	});
	const lines = [toCustomer.ok ? `Emailed ${email} that we got the request.` : `Couldn't email the customer: ${toCustomer.why}.`, toStaff.ok ? `Emailed ${staffTo.join(", ")} about the new ticket.` : staffTo.length ? `Couldn't email ${staffTo.join(", ")}: ${toStaff.why}.` : "No one was emailed about the new ticket: add an address in Settings → Features → Support Desk."];
	await s.admin.from("ticket_messages").insert({
		company_id: co.company_id,
		ticket_id: t.id,
		kind: "note",
		author_name: "Tallkeep",
		body: lines.join("\n")
	});
	return {
		key: t.public_key,
		number: t.number
	};
});
async function ticketForKey(key) {
	const s = await import("./support.server-Bv8yioBw.mjs");
	if (!/^[a-f0-9]{32,80}$/.test(key)) return null;
	const { data } = await s.admin.from("tickets").select("id,company_id,number,subject,status,created_at,name,email,assigned_to").eq("public_key", key).maybeSingle();
	return data;
}
var getTicketByKey_createServerFn_handler = createServerRpc({
	id: "edd227bdb9a1f3153ddfc027e2f64c788faedc6d7a2198167ff802f227dbcb5f",
	name: "getTicketByKey",
	filename: "src/lib/support.functions.ts"
}, (opts) => getTicketByKey.__executeServer(opts));
var getTicketByKey = createServerFn({ method: "GET" }).inputValidator((d) => ({ key: String(d?.key ?? "") })).handler(getTicketByKey_createServerFn_handler, async ({ data }) => {
	const s = await import("./support.server-Bv8yioBw.mjs");
	const t = await ticketForKey(data.key);
	if (!t) return null;
	const co = await s.companyById(t.company_id);
	const { data: msgs } = await s.admin.from("ticket_messages").select("id,kind,author_name,body,files,created_at").eq("ticket_id", t.id).in("kind", [
		"customer",
		"staff",
		"event"
	]).order("created_at");
	const { data: docs } = await s.admin.from("sales_orders").select("number,status,total,balance").eq("ticket_id", t.id).neq("status", "cancelled").order("created_at");
	return {
		company: co?.name ?? "",
		number: t.number,
		subject: t.subject,
		status: t.status,
		created_at: t.created_at,
		name: t.name,
		messages: (msgs ?? []).map((m) => ({
			...m,
			files: (m.files ?? []).map((f) => ({
				path: f.path,
				name: f.name,
				size: f.size
			}))
		})),
		docs: (docs ?? []).map((d) => ({
			number: d.number,
			kind: d.status === "quote" ? "quote" : "invoice",
			total: Number(d.total),
			balance: Number(d.balance),
			status: d.status
		}))
	};
});
var replyByKey_createServerFn_handler = createServerRpc({
	id: "f4a3843ba5b275a7d0f9497fd6e3748d8da5db0d4783dfa53e26efdbece5ca69",
	name: "replyByKey",
	filename: "src/lib/support.functions.ts"
}, (opts) => replyByKey.__executeServer(opts));
var replyByKey = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(replyByKey_createServerFn_handler, async ({ data }) => {
	const s = await import("./support.server-Bv8yioBw.mjs");
	const t = await ticketForKey(String(data.key ?? ""));
	if (!t) throw new Error("This ticket link doesn't work anymore.");
	const body = s.clean(data.body, 2e4);
	const files = await s.saveFiles(t.company_id, t.id, data.files ?? []);
	if (!body && !files.length) throw new Error("Type a message.");
	const { error } = await s.admin.from("ticket_messages").insert({
		company_id: t.company_id,
		ticket_id: t.id,
		kind: "customer",
		author_name: t.name,
		body,
		files
	});
	if (error) throw new Error(error.message);
	const co = await s.companyById(t.company_id);
	let to = (co?.support_notify_email || co?.email || "").split(/[,;\s]+/).filter(Boolean);
	if (t.assigned_to) {
		const { data: u } = await s.admin.auth.admin.getUserById(t.assigned_to);
		if (u?.user?.email) to = [u.user.email];
	}
	const origin = validOrigin(data.origin);
	await s.sendMail({
		co,
		to,
		replyTo: t.email,
		subject: `Reply on ${t.number}: ${t.subject}`,
		text: `${t.name ?? "The customer"} wrote:\n\n${body}${files.length ? `\n\n(${files.length} file${files.length === 1 ? "" : "s"} added)` : ""}${origin ? `\n\nOpen it: ${origin}/tickets/${t.id}` : ""}`
	});
	return { ok: true };
});
var staffReply_createServerFn_handler = createServerRpc({
	id: "3337e16a1ca5d14776fbffb6ab88d8c08897b5c663e19c0a5445cc769c12e08f",
	name: "staffReply",
	filename: "src/lib/support.functions.ts"
}, (opts) => staffReply.__executeServer(opts));
var staffReply = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(staffReply_createServerFn_handler, async ({ data, context }) => {
	const s = await import("./support.server-Bv8yioBw.mjs");
	const db = context.supabase;
	const { data: t } = await db.from("tickets").select("id,company_id,number,subject,email,name,public_key,status").eq("id", data.ticketId).maybeSingle();
	if (!t) throw new Error("That ticket isn't here.");
	const body = s.clean(data.body, 2e4);
	if (!body && !data.files.length) throw new Error("Type a message.");
	const { data: me } = await s.admin.auth.admin.getUserById(context.userId);
	const who = String(me?.user?.user_metadata?.["name"] ?? "") || me?.user?.email || "Staff";
	const files = (data.files ?? []).filter((f) => f.path.startsWith(`${t.company_id}/${t.id}/`));
	let emailed = false;
	if (data.kind === "staff" && t.email) {
		const co = await s.companyById(t.company_id);
		const origin = validOrigin(data.origin);
		const link = origin ? `${origin}/help/t/${t.public_key}` : "";
		emailed = await s.sendMail({
			co,
			to: [t.email],
			subject: `Re: ${t.subject} [${t.number}]`,
			text: `${body}${files.length ? `\n\n(${files.length} file${files.length === 1 ? "" : "s"} attached: see the link below)` : ""}\n\n— ${who}, ${co?.name ?? ""}${link ? `\n\nSee the whole conversation or reply here:\n${link}` : ""}`
		});
	}
	const { error } = await db.from("ticket_messages").insert({
		company_id: t.company_id,
		ticket_id: t.id,
		kind: data.kind,
		author_id: context.userId,
		author_name: who,
		body,
		files,
		emailed
	});
	if (error) throw new Error(error.message);
	if (data.status && data.status !== t.status) {
		const up = await db.from("tickets").update({ status: data.status }).eq("id", t.id);
		if (up.error) throw new Error(up.error.message);
	}
	return { emailed };
});
var supportEmailReady_createServerFn_handler = createServerRpc({
	id: "f3dd04a2849ca3168bd7a7a323490b6df9b1b99564396df67070a7832cdacde3",
	name: "supportEmailReady",
	filename: "src/lib/support.functions.ts"
}, (opts) => supportEmailReady.__executeServer(opts));
var supportEmailReady = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(supportEmailReady_createServerFn_handler, async () => {
	const { mailReady } = await import("./mailer.server-DR8PG4aY.mjs");
	return { ready: await mailReady() };
});
var listSupportStaff_createServerFn_handler = createServerRpc({
	id: "c0a9351fdf5fec73b82f254d09bc44ec7e4d5613560f4b5995f36d4118bc6a9c",
	name: "listSupportStaff",
	filename: "src/lib/support.functions.ts"
}, (opts) => listSupportStaff.__executeServer(opts));
var listSupportStaff = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listSupportStaff_createServerFn_handler, async ({ context }) => {
	const s = await import("./support.server-Bv8yioBw.mjs");
	const { data: members } = await context.supabase.from("org_members").select("user_id");
	const ids = (members ?? []).map((m) => m.user_id);
	if (!ids.includes(context.userId)) ids.push(context.userId);
	const out = [];
	for (const id of ids.slice(0, 200)) {
		const { data } = await s.admin.auth.admin.getUserById(id);
		const u = data?.user;
		if (u) out.push({
			id,
			name: String(u.user_metadata?.["name"] ?? "") || u.email || "Someone"
		});
	}
	return out.sort((a, b) => a.name.localeCompare(b.name));
});
//#endregion
export { getSupportPage_createServerFn_handler, getTicketByKey_createServerFn_handler, listSupportStaff_createServerFn_handler, openTicket_createServerFn_handler, replyByKey_createServerFn_handler, staffReply_createServerFn_handler, supportEmailReady_createServerFn_handler };
