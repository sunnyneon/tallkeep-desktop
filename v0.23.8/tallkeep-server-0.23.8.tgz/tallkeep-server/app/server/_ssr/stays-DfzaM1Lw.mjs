import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C7DN5EUT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { o as parseCsv } from "./quickbooks-DDZqKZVM.mjs";
import { En as BedDouble, P as RefreshCw, Pt as FileUp, R as Plus, an as ChevronLeft, ft as Link2, g as Trash2, in as ChevronRight, lt as LoaderCircle, pn as CalendarSync, qt as Copy } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-aFR9SgbK.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { a as loadStays, o as refreshRealEstate, s as useRealEstate, t as CHANNEL } from "./realestate-B7MhUll3.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { c as publicOrigin } from "./support-Bri7jlNl.mjs";
import { t as MoneyAccountPick } from "./MoneyAccountPick-BF3coPzD.mjs";
import { t as Route } from "./stays-ButFB3Hl.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stays-DfzaM1Lw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Short-term stays: read a calendar link from Airbnb, VRBO or Booking.com. The browser can't read
* those links itself (the sites don't allow it), so the server fetches the calendar text.
*/
var fetchCalendar = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	let u;
	try {
		u = new URL(String(d.url ?? "").trim().replace(/^webcal:/i, "https:"));
	} catch {
		throw new Error("That isn't a link. Copy the calendar link from Airbnb, VRBO or Booking.com.");
	}
	const testing = process.env["TALLKEEP_TEST_CALENDARS"] === "1";
	if (u.protocol !== "https:" && !testing) throw new Error("The calendar link must start with https://");
	if (!testing && /^(localhost|127\.|10\.|192\.168\.|169\.254\.|\[)/i.test(u.hostname)) throw new Error("That calendar link isn't on the internet.");
	return { url: u.toString() };
}).handler(createSsrRpc("983bd78fdde0496a70eac804f7e75ce9364b7de2107c5e0370f4fa96bfe9fad1"));
/**
* Bringing in short-term stays: calendar links (iCal) from Airbnb/VRBO/Booking.com, and Airbnb's
* earnings file (CSV). All the writing goes through the signed-in person's own access.
*/
var ymd = (v) => {
	const m = /(\d{4})(\d{2})(\d{2})/.exec(v);
	return m ? `${m[1]}-${m[2]}-${m[3]}` : "";
};
/** Read the events in an .ics calendar. */
function parseIcs(text) {
	const lines = text.replace(/\r\n/g, "\n").replace(/\n[ \t]/g, "").split("\n");
	const out = [];
	let cur = null;
	for (const line of lines) if (line === "BEGIN:VEVENT") cur = {};
	else if (line === "END:VEVENT") {
		if (cur?.start && cur.end && cur.end > cur.start) out.push({
			uid: cur.uid || `${cur.start}-${cur.end}`,
			start: cur.start,
			end: cur.end,
			summary: cur.summary ?? "",
			description: cur.description ?? ""
		});
		cur = null;
	} else if (cur) {
		const i = line.indexOf(":");
		if (i < 0) continue;
		const key = line.slice(0, i).split(";")[0].toUpperCase();
		const val = line.slice(i + 1).replace(/\\n/gi, "\n").replace(/\\([,;\\])/g, "$1");
		if (key === "UID") cur.uid = val.trim();
		else if (key === "DTSTART") cur.start = ymd(val);
		else if (key === "DTEND") cur.end = ymd(val);
		else if (key === "SUMMARY") cur.summary = val.trim();
		else if (key === "DESCRIPTION") cur.description = val;
	}
	return out;
}
/** A blocked night (owner block, or a booking from another site) rather than a guest booking. */
var isBlock = (e) => /not available|blocked|closed|unavailable/i.test(e.summary);
/** The booking's confirmation code, when the calendar gives it (Airbnb does). */
function codeFrom(e) {
	return /reservations\/details\/([A-Z0-9]{6,14})/i.exec(e.description)?.[1] ?? /\b(HM[A-Z0-9]{6,10})\b/.exec(`${e.summary} ${e.description}`)?.[1] ?? null;
}
function guestFrom(e, channel) {
	const m = /^(?:reserved|booked|reservation)\s*[-–:]\s*(.+)$/i.exec(e.summary);
	if (m?.[1]) return m[1].trim();
	if (e.summary && !/^(reserved|booked|reservation)$/i.test(e.summary)) return e.summary;
	return `${CHANNEL[channel].label} guest`;
}
/** Read one calendar link and bring its bookings in. */
async function syncFeed(feed, today) {
	const r = {
		added: 0,
		moved: 0,
		canceled: 0,
		problems: []
	};
	try {
		const { text } = await fetchCalendar({ data: { url: feed.url } });
		const events = parseIcs(text).filter((e) => !isBlock(e));
		const { data: rows, error } = await db.from("stays").select("id,feed_uid,check_in,check_out,status,paid_on,confirmation,source").eq("unit_id", feed.unit_id);
		if (error) throw error;
		const mine = rows ?? [];
		const byUid = new Map(mine.filter((s) => s.feed_uid).map((s) => [s.feed_uid, s]));
		const seen = /* @__PURE__ */ new Set();
		for (const e of events) {
			const key = `${feed.id}:${e.uid}`;
			seen.add(key);
			const had = byUid.get(key);
			if (had) {
				if (had.check_in !== e.start || had.check_out !== e.end || had.status === "canceled") {
					const { error: err } = await db.from("stays").update({
						check_in: e.start,
						check_out: e.end,
						status: "booked"
					}).eq("id", had.id);
					if (err) r.problems.push(err.message);
					else r.moved++;
				}
				continue;
			}
			if (e.end < addDays$1(today, -365)) continue;
			const code = codeFrom(e);
			const same = mine.find((s) => code && s.confirmation === code || !s.feed_uid && s.check_in === e.start && s.check_out === e.end);
			if (same) {
				await db.from("stays").update({ feed_uid: key }).eq("id", same.id);
				continue;
			}
			const { error: err } = await db.from("stays").insert({
				unit_id: feed.unit_id,
				guest_name: guestFrom(e, feed.channel),
				channel: feed.channel,
				confirmation: code,
				check_in: e.start,
				check_out: e.end,
				source: "calendar",
				feed_uid: key,
				notes: phoneNote(e)
			});
			if (err) r.problems.push(`${e.start}: ${err.message}`);
			else r.added++;
		}
		for (const s of mine) {
			if (!s.feed_uid?.startsWith(`${feed.id}:`) || seen.has(s.feed_uid)) continue;
			if (s.status === "canceled" || s.paid_on || s.check_out < today) continue;
			const { error: err } = await db.from("stays").update({ status: "canceled" }).eq("id", s.id);
			if (!err) r.canceled++;
		}
	} catch (e) {
		r.problems.push(e.message);
	}
	const summary = r.problems.length ? `Problem: ${r.problems[0]}` : `${r.added} new, ${r.moved} changed, ${r.canceled} canceled`;
	await db.from("stay_feeds").update({
		last_synced: (/* @__PURE__ */ new Date()).toISOString(),
		last_result: summary
	}).eq("id", feed.id);
	return r;
}
function phoneNote(e) {
	const p = /phone[^:\n]*:\s*([0-9 ()+-]{4,})/i.exec(e.description)?.[1]?.trim();
	return p ? `Phone (from calendar): ${p}` : null;
}
function addDays$1(d, n) {
	const t = /* @__PURE__ */ new Date(`${d}T00:00:00Z`);
	t.setUTCDate(t.getUTCDate() + n);
	return t.toISOString().slice(0, 10);
}
var num = (v) => {
	if (!v) return 0;
	const neg = /^\(.*\)$/.test(v.trim()) || v.trim().startsWith("-");
	const n = Number(v.replace(/[^0-9.]/g, ""));
	return Number.isFinite(n) ? neg ? -n : n : 0;
};
function date(v) {
	if (!v) return "";
	const s = v.trim();
	let m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
	if (m) return `${m[1]}-${m[2]}-${m[3]}`;
	m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/.exec(s);
	if (m) return `${m[3].length === 2 ? `20${m[3]}` : m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
	return "";
}
/**
* Read Airbnb's earnings file (Earnings → Download CSV, "Transaction history" or "Completed
* payouts"). Each reservation row becomes one stay; payout-only rows are skipped.
*/
function parseAirbnbCsv(text) {
	const all = parseCsv(text.replace(/^﻿/, "")).filter((r) => r.some((c) => c.trim()));
	if (all.length < 2) throw new Error("That file is empty.");
	const head = all[0].map((h) => h.trim().toLowerCase());
	const col = (...names) => head.findIndex((h) => names.some((n) => h === n));
	const c = {
		date: col("date"),
		type: col("type"),
		code: col("confirmation code", "confirmation"),
		start: col("start date", "check-in", "check in", "arrival"),
		end: col("end date", "check-out", "check out", "departure"),
		nights: col("nights"),
		guest: col("guest", "guest name"),
		listing: col("listing", "listing name"),
		amount: col("amount"),
		fee: col("service fee", "host fee"),
		fast: col("fast pay fee"),
		cleaning: col("cleaning fee"),
		gross: col("gross earnings"),
		taxes: col("occupancy taxes", "occupancy tax")
	};
	if (c.start < 0 || c.amount < 0 && c.gross < 0) throw new Error("This doesn't look like Airbnb's earnings file. In Airbnb open Earnings, then Download CSV.");
	const rows = [];
	let skipped = 0;
	for (const r of all.slice(1)) {
		const kind = c.type >= 0 ? (r[c.type] ?? "").trim() : "Reservation";
		const checkIn = date(r[c.start]);
		if (!checkIn || kind && !/reservation/i.test(kind)) {
			skipped++;
			continue;
		}
		const nights = Math.round(num(r[c.nights]));
		const checkOut = date(c.end >= 0 ? r[c.end] : "") || addDays$1(checkIn, Math.max(1, nights));
		const cleaning = num(r[c.cleaning]);
		const fee = Math.abs(num(r[c.fee])) + Math.abs(num(c.fast >= 0 ? r[c.fast] : ""));
		const taxes = num(c.taxes >= 0 ? r[c.taxes] : "");
		const amount = num(c.amount >= 0 ? r[c.amount] : "");
		const gross = c.gross >= 0 ? num(r[c.gross]) : amount + fee;
		rows.push({
			code: (r[c.code] ?? "").trim() || null,
			listing: (r[c.listing] ?? "").trim() || "Listing",
			guest: (r[c.guest] ?? "").trim() || "Airbnb guest",
			checkIn,
			checkOut,
			nights: nights || Math.round((Date.parse(checkOut) - Date.parse(checkIn)) / 864e5),
			rent: Math.round((gross - cleaning) * 100) / 100,
			cleaning,
			taxes,
			fee: Math.round(fee * 100) / 100,
			amount: c.amount >= 0 ? amount : Math.round((gross + taxes - fee) * 100) / 100,
			date: date(c.date >= 0 ? r[c.date] : "") || checkIn,
			kind
		});
	}
	return {
		rows,
		skipped
	};
}
/** The stay's money from a file row; "other fees" makes up any difference so the payout matches. */
function moneyFrom(row) {
	const base = row.rent + row.cleaning + row.taxes - row.fee;
	const other = Math.round((row.amount - base) * 100) / 100;
	return {
		rent: row.rent,
		cleaning_fee: row.cleaning,
		taxes: row.taxes,
		platform_fee: row.fee,
		other_fees: Math.abs(other) >= .01 ? other : 0
	};
}
function useFeeds() {
	return useQuery({
		queryKey: ["stays", "feeds"],
		queryFn: async () => {
			const { data, error } = await db.from("stay_feeds").select("*").order("created_at");
			if (error) throw error;
			return data ?? [];
		}
	});
}
/** Sync calendars that haven't been read in the last hour (when the Stays page opens). */
function useAutoSync(feeds) {
	const qc = useQueryClient();
	const done = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (done.current || !feeds?.length) return;
		done.current = true;
		const stale = feeds.filter((f) => !f.last_synced || Date.now() - Date.parse(f.last_synced) > 36e5);
		if (!stale.length) return;
		(async () => {
			let added = 0;
			for (const f of stale) added += (await syncFeed(f, today())).added;
			refreshRealEstate(qc);
			if (added) toast.success(`${added} new booking${added === 1 ? "" : "s"} from your calendars.`);
		})();
	}, [feeds, qc]);
}
function SyncDialog({ units, unitName, onClose }) {
	const qc = useQueryClient();
	const { data: feeds = [] } = useFeeds();
	const { data: tokens = {} } = useQuery({
		queryKey: ["stays", "calendar-tokens"],
		queryFn: async () => {
			const { data } = await db.from("units").select("id,calendar_token");
			return Object.fromEntries((data ?? []).map((u) => [u.id, u.calendar_token ?? ""]));
		}
	});
	const [origin, setOrigin] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		publicOrigin().then(setOrigin);
	}, []);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const desktop = typeof window !== "undefined" && /^(localhost|127\.|192\.168\.|10\.)/.test(window.location.hostname);
	const reload = () => {
		qc.invalidateQueries({ queryKey: ["stays", "feeds"] });
		refreshRealEstate(qc);
	};
	async function syncAll() {
		setBusy(true);
		let added = 0;
		let moved = 0;
		let canceled = 0;
		const problems = [];
		for (const f of feeds) {
			const r = await syncFeed(f, today());
			added += r.added;
			moved += r.moved;
			canceled += r.canceled;
			problems.push(...r.problems);
		}
		setBusy(false);
		reload();
		if (problems.length) toast.error(problems[0]);
		else toast.success(`Calendars read: ${added} new, ${moved} changed, ${canceled} canceled.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92vh] max-w-2xl overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Calendar sync" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Bookings come in by themselves: paste each listing's calendar link from Airbnb, VRBO or Booking.com. Tallkeep reads them when you open Short-Term Stays (and when you press Sync now). Then give each site Tallkeep's link, so a night booked anywhere is blocked everywhere." })] }),
				units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitFeeds, {
					unit: u,
					name: unitName(u.id),
					feeds: feeds.filter((f) => f.unit_id === u.id),
					link: tokens[u.id] && origin ? `${origin}/api/public/stay-calendar?t=${tokens[u.id]}` : "",
					desktop,
					onChange: reload
				}, u.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Close"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void syncAll(),
					disabled: busy || !feeds.length,
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), "Sync now"]
				})] })
			]
		})
	});
}
function UnitFeeds({ unit, name, feeds, link, desktop, onChange }) {
	const [channel, setChannel] = (0, import_react.useState)("airbnb");
	const [url, setUrl] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function add() {
		if (!/^(https|webcal):\/\//i.test(url.trim())) return void toast.error("Paste the calendar link (it starts with https://).");
		setBusy(true);
		const { data, error } = await db.from("stay_feeds").insert({
			unit_id: unit.id,
			channel,
			url: url.trim().replace(/^webcal:/i, "https:")
		}).select("*").single();
		if (error) {
			setBusy(false);
			toast.error(error.message);
			return;
		}
		const r = await syncFeed(data, today());
		setBusy(false);
		setUrl("");
		onChange();
		if (r.problems.length) toast.error(r.problems[0]);
		else toast.success(`Calendar added: ${r.added} booking${r.added === 1 ? "" : "s"} brought in.`);
	}
	async function remove(f) {
		if (!window.confirm(`Stop reading the ${CHANNEL[f.channel].label} calendar for ${name}? Stays already here stay.`)) return;
		const { error } = await db.from("stay_feeds").delete().eq("id", f.id);
		if (error) return void toast.error(error.message);
		onChange();
	}
	const copy = (text) => {
		copyText(text);
		toast.success("Link copied. Paste it in the site's calendar settings (Import calendar).");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-xl border p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-medium",
				children: name
			}),
			feeds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1 text-sm",
				children: feeds.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `h-2.5 w-2.5 shrink-0 rounded-sm ${CHANNEL[f.channel].color}` }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate",
								children: [
									CHANNEL[f.channel].label,
									": ",
									f.url
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: f.last_synced ? `Read ${fmtDate(f.last_synced)} ${new Date(f.last_synced).toLocaleTimeString([], {
									hour: "numeric",
									minute: "2-digit"
								})} · ${f.last_result ?? ""}` : "Not read yet"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							"aria-label": "Stop reading this calendar",
							onClick: () => void remove(f),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, f.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: channel,
						onChange: (e) => setChannel(e.target.value),
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						"aria-label": "Which site",
						children: [
							"airbnb",
							"vrbo",
							"booking",
							"other"
						].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: CHANNEL[k].label
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: url,
						onChange: (e) => setUrl(e.target.value),
						placeholder: "Paste the calendar link (.ics) from the site",
						className: "min-w-0 flex-1"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void add(),
						disabled: busy || !url.trim(),
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" }), "Add calendar link"]
					})
				]
			}),
			link && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-lg bg-muted/40 p-2 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Tallkeep's calendar for this unit, to paste into each site:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							"airbnb",
							"vrbo",
							"booking"
						].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => copy(`${link}&not=${k}`),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }),
								" Copy link for ",
								CHANNEL[k].label
							]
						}, k))
					}),
					desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: "On Tallkeep Desktop this link works only inside your office network, so Airbnb can't read it yet. Reading Airbnb's calendar into Tallkeep works anywhere."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowTo, {})
		]
	});
}
function HowTo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "text-xs text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "cursor-pointer",
			children: "Where do I find the calendar link?"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-1 list-disc space-y-1 pl-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Airbnb:" }), " Calendar → pick the listing → Availability → Connect calendars (or \"Sync calendars\") → Connect to another website → copy the Airbnb link."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "VRBO:" }), " Calendar → Import & export → Export calendar → copy the link."] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Booking.com:" }), " Rates & Availability → Sync calendars → Export calendar → copy the link."] })
			]
		})]
	});
}
var MAP_KEY = "tallkeep.airbnb-listings";
function ImportDialog({ units, unitName, onClose }) {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [skipped, setSkipped] = (0, import_react.useState)(0);
	const [map, setMap] = (0, import_react.useState)(() => {
		try {
			return JSON.parse(localStorage.getItem(MAP_KEY) ?? "{}");
		} catch {
			return {};
		}
	});
	const [paid, setPaid] = (0, import_react.useState)(true);
	const [account, setAccount] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(null);
	const listings = [...new Set((rows ?? []).map((r) => r.listing))];
	async function read(file) {
		try {
			const r = parseAirbnbCsv(await file.text());
			setRows(r.rows);
			setSkipped(r.skipped);
			setDone(null);
			if (!r.rows.length) toast.error("No reservations in that file.");
			if (units.length === 1) setMap((m) => ({
				...Object.fromEntries(r.rows.map((x) => [x.listing, units[0].id])),
				...m
			}));
		} catch (e) {
			toast.error(e.message);
		}
	}
	async function run() {
		if (!rows) return;
		if (listings.some((l) => !map[l])) return void toast.error("Pick a unit for each listing.");
		try {
			localStorage.setItem(MAP_KEY, JSON.stringify(map));
		} catch {}
		setBusy(true);
		const unitIds = [...new Set(listings.map((l) => map[l]))];
		const { data: existing } = await db.from("stays").select("id,unit_id,confirmation,check_in,check_out,guest_name,paid_on").in("unit_id", unitIds);
		const have = existing ?? [];
		let added = 0;
		let updated = 0;
		const problems = [];
		for (const r of rows) {
			const unit = map[r.listing];
			const money = moneyFrom(r);
			const same = have.find((s) => r.code && s.confirmation === r.code) ?? have.find((s) => s.unit_id === unit && s.check_in === r.checkIn && s.check_out === r.checkOut);
			const payout = paid ? {
				paid_on: r.date,
				account_id: account || null
			} : {};
			if (same) {
				const placeholder = /guest$/i.test(same.guest_name);
				const { error } = await db.from("stays").update({
					...money,
					...same.paid_on ? {} : payout,
					confirmation: r.code ?? same.confirmation,
					...placeholder ? { guest_name: r.guest } : {}
				}).eq("id", same.id);
				if (error) problems.push(`${r.guest} ${r.checkIn}: ${error.message}`);
				else updated++;
			} else {
				const { error } = await db.from("stays").insert({
					unit_id: unit,
					guest_name: r.guest,
					channel: "airbnb",
					confirmation: r.code,
					check_in: r.checkIn,
					check_out: r.checkOut,
					source: "import",
					...money,
					...payout
				});
				if (error) problems.push(`${r.guest} ${r.checkIn}: ${error.message}`);
				else added++;
			}
		}
		setBusy(false);
		refreshRealEstate(qc);
		setDone(`${added} stay${added === 1 ? "" : "s"} added, ${updated} updated.` + (problems.length ? ` ${problems.length} not brought in: ${problems.slice(0, 3).join("; ")}` : ""));
		if (!problems.length) toast.success("Airbnb earnings brought in.");
	}
	const total = (rows ?? []).reduce((s, r) => s + r.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92vh] max-w-2xl overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Bring in Airbnb earnings" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "In Airbnb, open Menu → Earnings → (Paid or Upcoming) → Download CSV. Pick that file here. Each reservation becomes a stay with its nights, cleaning fee, Airbnb's fee and payout. Stays already here (from the calendar) are filled in, not added twice." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed p-6 text-sm hover:bg-muted/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "h-5 w-5" }),
						rows ? "Pick another file" : "Pick the Airbnb earnings file (.csv)",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".csv,text/csv",
							className: "hidden",
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (f) read(f);
								e.target.value = "";
							}
						})
					]
				}),
				rows && rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							rows.length,
							" reservation",
							rows.length === 1 ? "" : "s",
							", ",
							fmtMoney(total),
							" in payouts",
							skipped ? ` (${skipped} other line${skipped === 1 ? "" : "s"} skipped: payouts, adjustments)` : "",
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "Which unit is each listing?"
							}), listings.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: l
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: map[l] ?? "",
									onChange: (e) => setMap({
										...map,
										[l]: e.target.value
									}),
									className: "h-9 rounded-md border bg-background px-2 text-sm",
									"aria-label": `Unit for ${l}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Pick a unit…"
									}), units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: u.id,
										children: unitName(u.id)
									}, u.id))]
								})]
							}, l))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: paid,
								onChange: (e) => setPaid(e.target.checked)
							}), "These payouts have reached my bank (put them in the books on the file's dates)"]
						}),
						paid && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyAccountPick, {
							label: "Into",
							value: account,
							onChange: setAccount
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-h-48 overflow-y-auto rounded-lg border text-xs",
							children: rows.slice(0, 100).map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between gap-2 border-b px-2 py-1 last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "truncate",
									children: [
										r.guest,
										" · ",
										fmtDate(r.checkIn),
										"–",
										fmtDate(r.checkOut),
										" · ",
										r.code ?? ""
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtMoney(r.amount) })]
							}, i))
						})
					]
				}),
				done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg bg-muted/50 p-2 text-sm",
					children: done
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Close"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void run(),
					disabled: busy || !rows?.length,
					children: [
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
						"Bring in ",
						rows?.length ?? 0,
						" stay",
						rows?.length === 1 ? "" : "s"
					]
				})] })
			]
		})
	});
}
var DAY = 864e5;
var d0 = (s) => /* @__PURE__ */ new Date(`${s}T00:00:00Z`);
var iso = (d) => d.toISOString().slice(0, 10);
var addDays = (s, n) => iso(new Date(d0(s).getTime() + n * DAY));
var nightsBetween = (a, b) => Math.round((d0(b).getTime() - d0(a).getTime()) / DAY);
function Stays() {
	const qc = useQueryClient();
	const { unit: onlyUnit } = Route.useSearch();
	const { data: re, isLoading: reLoading } = useRealEstate();
	const { data: stays, isLoading } = useQuery({
		queryKey: ["stays"],
		queryFn: loadStays
	});
	const [month, setMonth] = (0, import_react.useState)(() => today().slice(0, 7));
	const [tab, setTab] = (0, import_react.useState)("upcoming");
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [tool, setTool] = (0, import_react.useState)(null);
	const { data: feeds } = useFeeds();
	useAutoSync(feeds);
	const units = (0, import_react.useMemo)(() => (re?.units ?? []).filter((u) => u.rental_type === "short" && u.is_active && (!onlyUnit || u.id === onlyUnit)), [re, onlyUnit]);
	const unitIds = new Set(units.map((u) => u.id));
	const mine = (stays ?? []).filter((s) => unitIds.has(s.unit_id));
	const live = mine.filter((s) => s.status !== "canceled");
	const first = `${month}-01`;
	const daysIn = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate();
	const days = Array.from({ length: daysIn }, (_, i) => addDays(first, i));
	const after = addDays(first, daysIn);
	const shift = (n) => {
		const d = new Date(Date.UTC(Number(month.slice(0, 4)), Number(month.slice(5, 7)) - 1 + n, 1));
		setMonth(iso(d).slice(0, 7));
	};
	let nights = 0;
	let earned = 0;
	for (const s of live) {
		const a = s.check_in > first ? s.check_in : first;
		const b = s.check_out < after ? s.check_out : after;
		const n = Math.max(0, nightsBetween(a, b));
		if (!n) continue;
		nights += n;
		earned += s.rent / Math.max(1, s.nights) * n;
	}
	const possible = units.length * daysIn;
	const paidOut = mine.filter((s) => s.paid_on && s.paid_on >= first && s.paid_on < after).reduce((t, s) => t + s.payout, 0);
	const now = today();
	const lists = {
		upcoming: live.filter((s) => s.check_out >= now).sort((a, b) => a.check_in.localeCompare(b.check_in)),
		payout: live.filter((s) => !s.paid_on && s.check_in <= now),
		past: live.filter((s) => s.check_out < now),
		canceled: mine.filter((s) => s.status === "canceled")
	};
	const unitName = (id) => re?.unitLabel(id) ?? "";
	const newStay = (unit, day) => {
		const u = unit ?? units[0];
		const inDay = day ?? now;
		const n = Math.max(1, u?.min_nights ?? 1);
		return {
			unit_id: u?.id ?? "",
			channel: "airbnb",
			status: "booked",
			check_in: inDay,
			check_out: addDays(inDay, n)
		};
	};
	if (reLoading || isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Short-Term Stays",
			text: "Bookings from Airbnb, VRBO, Booking.com or your own guests. When a payout reaches your bank, mark it received and it goes into the books: income, cleaning fees, the platform's fee and any lodging tax you owe.",
			actions: units.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setTool("sync"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarSync, { className: "h-4 w-4" }),
							" Calendar sync",
							feeds?.length ? ` (${feeds.length})` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setTool("import"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "h-4 w-4" }), " Bring in Airbnb earnings"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setEdit(newStay()),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a stay"]
					})
				]
			})
		}),
		units.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-8 text-center text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { className: "mx-auto mb-2 h-8 w-8" }),
				"No short-term units yet. Open",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/properties",
					className: "underline",
					children: "Properties"
				}),
				", edit a unit and set \"How it's rented\" to Short-term."
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			onlyUnit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Showing ",
					unitName(onlyUnit),
					" only.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/stays",
						className: "underline",
						children: "Show all short-term units"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					["Nights booked", `${nights} of ${possible}`],
					["Occupancy", possible ? `${Math.round(nights / possible * 100)}%` : "–"],
					["Average nightly rate", nights ? fmtMoney(earned / nights) : "–"],
					["Payouts received", fmtMoney(paidOut)]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold",
						children: v
					})]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "outline",
								"aria-label": "Month before",
								onClick: () => shift(-1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "min-w-40 text-center font-display text-lg font-semibold",
								children: d0(first).toLocaleDateString(void 0, {
									month: "long",
									year: "numeric",
									timeZone: "UTC"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "outline",
								"aria-label": "Month after",
								onClick: () => shift(1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setMonth(now.slice(0, 7)),
								children: "This month"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "ml-auto hidden flex-wrap gap-3 text-xs sm:flex",
								children: Object.values(CHANNEL).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2.5 w-2.5 rounded-sm", c.color) }),
										" ",
										c.label
									]
								}, c.label))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full border-separate border-spacing-0 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "sticky left-0 z-10 min-w-36 bg-card pr-2 text-left font-medium",
								children: "Unit"
							}), days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: cn("min-w-7 px-0.5 text-center font-normal text-muted-foreground", d === now && "font-bold text-foreground"),
								children: Number(d.slice(8))
							}, d))] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "sticky left-0 z-10 truncate bg-card py-1 pr-2 font-medium",
								children: unitName(u.id)
							}), days.map((d) => {
								const s = live.find((x) => x.unit_id === u.id && x.check_in <= d && d < x.check_out);
								const startHere = s && (s.check_in === d || d === first);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "h-8 p-0",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										title: s ? `${s.guest_name} · ${CHANNEL[s.channel].label} · ${fmtDate(s.check_in)}–${fmtDate(s.check_out)}` : `Add a stay from ${fmtDate(d)}`,
										onClick: () => setEdit(s ? { ...s } : newStay(u, d)),
										className: cn("flex h-7 w-full items-center overflow-hidden whitespace-nowrap border-y border-transparent px-0.5 text-[10px] text-white", s ? cn(CHANNEL[s.channel].color, s.check_in === d && "ml-0.5 rounded-l-md") : "rounded-sm hover:bg-muted", s && addDays(d, 1) === s.check_out && "rounded-r-md"),
										children: startHere ? s.guest_name.split(" ")[0] : ""
									})
								}, d);
							})] }, u.id)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted-foreground",
						children: "Click an empty day to add a stay, or a booking to open it."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1 border-b p-2",
					children: [
						["upcoming", "Now and coming up"],
						["payout", "Waiting for payout"],
						["past", "Past stays"],
						["canceled", "Canceled"]
					].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: tab === k ? "secondary" : "ghost",
						onClick: () => setTab(k),
						children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							className: "ml-1",
							children: lists[k].length
						})]
					}, k))
				}), lists[tab].length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted-foreground",
					children: "Nothing here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y text-sm",
					children: lists[tab].slice(0, 300).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setEdit({ ...s }),
						className: "flex w-full flex-wrap items-center gap-3 px-4 py-2.5 text-left hover:bg-muted/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2.5 w-2.5 shrink-0 rounded-sm", CHANNEL[s.channel].color) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: s.guest_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [
										unitName(s.unit_id),
										" · ",
										fmtDate(s.check_in),
										" – ",
										fmtDate(s.check_out),
										" ·",
										" ",
										s.nights,
										" night",
										s.nights === 1 ? "" : "s",
										" · ",
										CHANNEL[s.channel].label,
										s.confirmation ? ` · ${s.confirmation}` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: fmtMoney(s.payout)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: s.paid_on ? `received ${fmtDate(s.paid_on)}` : "payout not received"
								})]
							})
						]
					}, s.id))
				})]
			})
		] }),
		tool === "sync" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SyncDialog, {
			units,
			unitName,
			onClose: () => setTool(null)
		}),
		tool === "import" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportDialog, {
			units,
			unitName,
			onClose: () => setTool(null)
		}),
		edit && re && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StayDialog, {
			draft: edit,
			units: (re.units ?? []).filter((u) => u.rental_type === "short" && u.is_active),
			unitName,
			onClose: () => setEdit(null),
			onSaved: () => refreshRealEstate(qc)
		})
	] });
}
var money = (v) => v === "" || v == null ? 0 : Math.round(Number(v) * 100) / 100;
function StayDialog({ draft, units, unitName, onClose, onSaved }) {
	const [d, setD] = (0, import_react.useState)(() => {
		if (draft.id) return draft;
		const u = units.find((x) => x.id === draft.unit_id);
		return {
			...draft,
			...pricesFor(u, draft.check_in, draft.check_out)
		};
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	const unit = units.find((u) => u.id === d.unit_id);
	const n = d.check_in && d.check_out ? nightsBetween(d.check_in, d.check_out) : 0;
	const payout = money(d.rent) + money(d.cleaning_fee) + money(d.other_fees) + money(d.taxes) - money(d.platform_fee);
	/** Change dates or unit; reprice the nights if it's a new stay. */
	const move = (p) => {
		const next = {
			...d,
			...p
		};
		if (!d.id && next.check_in && next.check_out) {
			const u = units.find((x) => x.id === next.unit_id);
			Object.assign(next, pricesFor(u, next.check_in, next.check_out));
		}
		setD(next);
	};
	async function save() {
		if (!d.unit_id) return void toast.error("Pick the unit.");
		if (!d.guest_name?.trim()) return void toast.error("Type the guest's name.");
		if (!d.check_in || !d.check_out || n < 1) return void toast.error("Check-out must be after check-in.");
		setBusy(true);
		const row = {
			unit_id: d.unit_id,
			guest_name: d.guest_name.trim(),
			guest_email: d.guest_email?.trim() || null,
			guest_phone: d.guest_phone?.trim() || null,
			guests: d.guests ? Number(d.guests) : null,
			channel: d.channel ?? "airbnb",
			confirmation: d.confirmation?.trim() || null,
			check_in: d.check_in,
			check_out: d.check_out,
			rent: money(d.rent),
			cleaning_fee: money(d.cleaning_fee),
			other_fees: money(d.other_fees),
			taxes: money(d.taxes),
			platform_fee: money(d.platform_fee),
			status: d.status ?? "booked",
			paid_on: d.paid_on || null,
			account_id: d.paid_on ? d.account_id || null : null,
			notes: d.notes?.trim() || null
		};
		const { error } = d.id ? await db.from("stays").update(row).eq("id", d.id) : await db.from("stays").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(d.paid_on ? "Stay saved, payout in the books." : "Stay saved.");
		onSaved();
		onClose();
	}
	async function remove() {
		if (!d.id || !window.confirm(`Delete the stay for ${d.guest_name}?`)) return;
		const { error } = await db.from("stays").delete().eq("id", d.id);
		if (error) return void toast.error(error.message);
		toast.success("Stay deleted.");
		onSaved();
		onClose();
	}
	const num = (k) => ({
		type: "number",
		step: "0.01",
		value: d[k] ?? "",
		onChange: (e) => set({ [k]: e.target.value })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92vh] max-w-2xl overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: d.id ? `Stay: ${d.guest_name}` : "Add a stay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: unit?.check_in_time || unit?.check_out_time ? `Check-in ${unit.check_in_time ?? "–"}, check-out ${unit.check_out_time ?? "–"}.` : "A booking for one of your short-term units." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Unit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: d.unit_id ?? "",
								onChange: (e) => move({ unit_id: e.target.value }),
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								children: units.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: u.id,
									children: unitName(u.id)
								}, u.id))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Booked through",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: d.channel ?? "airbnb",
								onChange: (e) => set({ channel: e.target.value }),
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								children: Object.entries(CHANNEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v.label
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Check-in",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.check_in ?? "",
								onChange: (e) => move({ check_in: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `Check-out${n > 0 ? ` (${n} night${n === 1 ? "" : "s"})` : ""}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.check_out ?? "",
								onChange: (e) => move({ check_out: e.target.value })
							})
						}),
						unit?.min_nights && n > 0 && n < unit.min_nights ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-amber-700 sm:col-span-2",
							children: [
								"This unit's fewest nights is ",
								unit.min_nights,
								"."
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Guest's name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.guest_name ?? "",
								onChange: (e) => set({ guest_name: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Confirmation code",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.confirmation ?? "",
								onChange: (e) => set({ confirmation: e.target.value }),
								placeholder: "HM4XQ2…"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Guest's phone",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.guest_phone ?? "",
								onChange: (e) => set({ guest_phone: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Guest's email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.guest_email ?? "",
								onChange: (e) => set({ guest_email: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Number of guests",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: d.guests ?? "",
								onChange: (e) => set({ guests: e.target.value })
							})
						}),
						unit?.max_guests && Number(d.guests) > unit.max_guests ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "self-end text-xs text-amber-700",
							children: [
								"This unit takes up to ",
								unit.max_guests,
								" guests."
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-xl border bg-muted/30 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Money"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Nights (total)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...num("rent") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Cleaning fee",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...num("cleaning_fee") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Other fees (pets, extra guest…)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...num("other_fees") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Lodging tax you collect",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...num("taxes") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Platform's fee to you",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...num("platform_fee") })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-medium",
										children: "Payout"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block pt-1.5 font-display text-lg font-semibold",
										children: fmtMoney(payout)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Copy these from the booking's earnings page. If Airbnb or VRBO pays the lodging tax for you, leave the tax at 0."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Payout received on",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: d.paid_on ?? "",
									onChange: (e) => set({ paid_on: e.target.value })
								})
							}), d.paid_on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyAccountPick, {
								label: "Into",
								value: d.account_id ?? "",
								onChange: (id) => set({ account_id: id })
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "self-end text-xs text-muted-foreground",
								children: "Fill this in when the money reaches your bank; then it goes into the books."
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: d.notes ?? "",
						onChange: (e) => set({ notes: e.target.value })
					})
				}),
				d.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: d.status === "canceled",
						onChange: (e) => set({ status: e.target.checked ? "canceled" : "booked" })
					}), "The guest canceled (frees the dates; keep any money you were paid above)"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2",
					children: [
						d.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "mr-auto text-destructive",
							onClick: () => void remove(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete stay"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Cancel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void save(),
							disabled: busy,
							children: busy ? "Saving…" : "Save stay"
						})
					]
				})
			]
		})
	});
}
/** The usual money for a new stay, from the unit's prices. */
function pricesFor(u, checkIn, checkOut) {
	const n = Math.max(0, nightsBetween(checkIn, checkOut));
	const rent = Math.round((u?.nightly_rate ?? 0) * n * 100) / 100;
	const cleaning = u?.cleaning_fee ?? 0;
	return {
		rent,
		cleaning_fee: cleaning,
		taxes: Math.round((rent + cleaning) * (u?.lodging_tax_pct ?? 0) / 100 * 100) / 100,
		other_fees: 0,
		platform_fee: 0
	};
}
//#endregion
export { Stays as component };
