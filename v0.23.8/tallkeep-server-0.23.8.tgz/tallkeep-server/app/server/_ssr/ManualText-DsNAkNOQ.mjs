import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { pt as Lightbulb } from "../_libs/lucide-react.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ManualText-DsNAkNOQ.js
var import_jsx_runtime = require_jsx_runtime();
function inline(text, open, key) {
	const out = [];
	const re = /\*\*([^*]+)\*\*|\[([^\]]+)\]\(([^)\s]+)\)/g;
	let last = 0;
	let m;
	let i = 0;
	while (m = re.exec(text)) {
		if (m.index > last) out.push(text.slice(last, m.index));
		if (m[1] != null) out.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: m[1] }, `${key}-${i++}`));
		else {
			const label = m[2];
			const href = m[3];
			const slug = /^\/manual\/([a-z0-9-]+)$/.exec(href)?.[1];
			if (slug && open) out.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => open(slug),
				className: "font-medium text-primary underline underline-offset-2",
				children: label
			}, `${key}-${i++}`));
			else if (/^(https?:\/\/|\/)/.test(href)) out.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				className: "font-medium text-primary underline underline-offset-2",
				...href.startsWith("http") ? {
					target: "_blank",
					rel: "noreferrer"
				} : {},
				children: label
			}, `${key}-${i++}`));
			else out.push(label);
		}
		last = re.lastIndex;
	}
	if (last < text.length) out.push(text.slice(last));
	return out;
}
function ManualText({ body, onOpen }) {
	const lines = body.replace(/\r/g, "").trim().split("\n");
	const blocks = [];
	let i = 0;
	let k = 0;
	while (i < lines.length) {
		const t = lines[i].trimEnd().trim();
		if (!t) {
			i++;
			continue;
		}
		const key = `b${k++}`;
		if (t.startsWith("### ")) {
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
				className: "pt-2 font-semibold",
				children: inline(t.slice(4), onOpen, key)
			}, key));
			i++;
		} else if (t.startsWith("## ")) {
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "pt-3 font-display text-lg font-semibold",
				children: inline(t.slice(3), onOpen, key)
			}, key));
			i++;
		} else if (/^\d+\.\s/.test(t)) {
			const items = [];
			while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) items.push(lines[i++].trim().replace(/^\d+\.\s+/, ""));
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "list-decimal space-y-1.5 pl-6",
				children: items.map((x, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inline(x, onOpen, `${key}-${j}`) }, j))
			}, key));
		} else if (/^[-*]\s/.test(t)) {
			const items = [];
			while (i < lines.length && /^[-*]\s/.test(lines[i].trim())) items.push(lines[i++].trim().replace(/^[-*]\s+/, ""));
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "list-disc space-y-1.5 pl-6",
				children: items.map((x, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: inline(x, onOpen, `${key}-${j}`) }, j))
			}, key));
		} else if (t.startsWith(">")) {
			const parts = [];
			while (i < lines.length && lines[i].trim().startsWith(">")) parts.push(lines[i++].trim().replace(/^>\s?/, ""));
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3 text-amber-950 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inline(parts.join(" "), onOpen, key) })]
			}, key));
		} else {
			const parts = [];
			while (i < lines.length && lines[i].trim() && !/^(#{2,3}\s|\d+\.\s|[-*]\s|>)/.test(lines[i].trim())) parts.push(lines[i++].trim());
			blocks.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: inline(parts.join(" "), onOpen, key) }, key));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3 text-[15px] leading-relaxed",
		children: blocks
	});
}
//#endregion
export { ManualText as t };
