import { n as db } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/feedWaiting-CPOsDrkb.js
/** Lines brought into Bank Feeds but not yet in the books, counted per account. */
function useFeedWaiting() {
	return useQuery({
		queryKey: ["bank-feed-waiting"],
		refetchInterval: 15e3,
		queryFn: async () => {
			const per = /* @__PURE__ */ new Map();
			for (let from = 0;; from += 1e3) {
				const { data, error } = await db.from("bank_transactions").select("account_id").eq("status", "new").range(from, from + 999);
				if (error) break;
				for (const r of data ?? []) {
					const id = r.account_id;
					per.set(id, (per.get(id) ?? 0) + 1);
				}
				if ((data ?? []).length < 1e3) break;
			}
			return {
				per,
				total: [...per.values()].reduce((a, b) => a + b, 0),
				top: [...per.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null
			};
		}
	});
}
//#endregion
export { useFeedWaiting as t };
