import { createHmac } from "node:crypto";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/trialmail.server-DD0g_RsZ.js
/**
* Free-trial emails, sent by a daily job: a few short, useful emails to new online accounts and
* to people who downloaded Tallkeep, ending with "your trial ends soon". Each email goes once
* (email_log), only within a few days of its day (so turning this on doesn't send old ones), and
* never to anyone who pressed "Stop these emails" (email_optout).
*/
var APP = "https://app.tallkeep.com";
var DAY = 864e5;
/** An email is sent on its day or up to this many days late (if the job didn't run). */
var LATE_DAYS = 2;
var ONLINE = [
	{
		step: "welcome",
		day: 0,
		subject: "Welcome to Tallkeep: 3 first steps",
		body: (v) => v.personal ? `Hi ${v.first},

Welcome to Tallkeep! Here's how to get going in 10 minutes:

1. Bring in your bank and card lines: drop a statement (PDF or photo) in the Shoebox on Home, and Tallkeep reads it.
2. Add your bills and subscriptions, so Tallkeep reminds you before they're due.
3. Set a monthly budget.

Open Tallkeep: ${APP}

Questions? Just reply to this email.` : `Hi ${v.first},

Welcome to Tallkeep! Here's how to get ${v.company} going:

1. Add your company's address, phone and logo (Settings → Company). They print on your quotes and invoices.
2. Bring your products and customers over from QuickBooks or inFlow (Settings → Import & backups), or type them in.
3. Make your first quote or invoice and email it as a PDF.

Open Tallkeep: ${APP}

Questions? Just reply to this email.`
	},
	{
		step: "import",
		day: 3,
		subject: "Bring your books over in a few minutes",
		body: (v) => v.personal ? `Hi ${v.first},

The fastest way to see your whole picture: drop a few months of bank and card statements in the Shoebox. Tallkeep reads each line, sorts it into a category, and your budget and net worth fill in by themselves.

Open the Shoebox: ${APP}/shoebox

Questions? Just reply to this email.` : `Hi ${v.first},

Coming from QuickBooks or inFlow? You don't have to type anything again:

- QuickBooks: export your lists and reports, then Settings → Import & backups → QuickBooks. Customers, vendors, items, open invoices and balances come over.
- inFlow: export from inFlow and import the files the same way, product photos too.
- Bank: drop statements in the Shoebox, and Tallkeep reads them.

Open Tallkeep: ${APP}/settings#import

Stuck on a step? Reply and we'll help.`
	},
	{
		step: "tips",
		day: 7,
		subject: "3 things people love in Tallkeep",
		body: (v) => v.personal ? `Hi ${v.first},

Three things to try this week:

1. Monthly Review: one page that shows where the money went this month.
2. Net Worth: add your investments and loans, and watch it month by month.
3. Household: add who's in the family, so each account shows whose it is.

Open Tallkeep: ${APP}

Questions? Just reply.` : `Hi ${v.first},

Three things to try this week:

1. Shoebox: take a photo of a receipt or bill on your phone; Tallkeep reads it and records it.
2. Pay now: connect Stripe (Settings → Card payments) so customers can pay your invoices by card, and Tallkeep marks them paid.
3. Your phone: open ${APP} on your phone and add it to your home screen.

Questions? Just reply.`
	},
	{
		step: "ending",
		day: 25,
		subject: "Your Tallkeep trial ends in 5 days",
		body: (v) => `Hi ${v.first},

Your free trial ends in ${v.daysLeft} day${v.daysLeft === 1 ? "" : "s"}. To keep going, pick a plan:

- Personal: $9 a month
- Service Business: $39 a month
- Full Business (with inventory): $59 a month
Pay yearly and get 2 months free. Cancel any time.

Pick a plan: ${APP}/plan

If you don't, nothing is lost: your books turn read-only, and you can still open and download everything.

Questions? Just reply.`
	},
	{
		step: "ended",
		day: 31,
		subject: "Your Tallkeep trial has ended (your books are safe)",
		body: (v) => `Hi ${v.first},

Your free trial has ended. Your books are safe and read-only: you can still open, print and download everything.

To keep working in them, pick a plan: ${APP}/plan

Was something missing, or not right for you? Reply and tell us; we read every answer.`
	}
];
var DOWNLOAD = [
	{
		step: "installed",
		day: 2,
		subject: "Did Tallkeep install OK?",
		body: (v) => `Hi ${v.first},

Just checking that Tallkeep installed fine.

- Windows: if it said "Windows protected your PC", press More info, then Run anyway.
- Synology / Linux: the README in the zip has the steps; then open http://your-server:4600.

Once it's open, make your company, and bring your data over from QuickBooks or inFlow (Settings → Import & backups).

Stuck? Just reply to this email and we'll help.`
	},
	{
		step: "tips",
		day: 7,
		subject: "3 things to try in Tallkeep this week",
		body: (v) => `Hi ${v.first},

Three things to try:

1. Shoebox: drop a bank statement, a receipt or a bill; Tallkeep reads it and records it.
2. Phones: other computers and phones in the office open Tallkeep with the address it shows on the office computer.
3. Nightly backups: Tallkeep keeps one every night. Copy them to another drive or your Synology now and then.

Questions? Just reply.`
	},
	{
		step: "ending",
		day: 25,
		subject: "Your Tallkeep trial ends in about 5 days",
		body: (v) => `Hi ${v.first},

Your 30-day free trial ends in about ${v.daysLeft} day${v.daysLeft === 1 ? "" : "s"}. Tallkeep is pay once, no subscription:

- Personal: from $59
- Service Business: from $299
- Full Business (with inventory): from $499
(founders prices until January 30, 2027)

Buy your license: ${APP}/buy

Enter the key in Settings → Plan & computer, and keep working where you left off. Nothing is lost if you wait: your books turn read-only until you add a key.

Questions? Just reply.`
	}
];
function secret() {
	return process.env["EMAIL_LINK_SECRET"] || process.env["SUPABASE_SERVICE_ROLE_KEY"] || process.env["LICENSE_PRIVATE_KEY"] || "tallkeep";
}
/** A code for an email's "Stop these emails" link (so nobody can stop someone else's). */
function optoutCode(email) {
	return createHmac("sha256", secret()).update(email.toLowerCase()).digest("hex").slice(0, 24);
}
var stopLink = (email) => `${APP}/api/public/unsubscribe?e=${encodeURIComponent(email)}&c=${optoutCode(email)}`;
async function runTrialEmails(now = /* @__PURE__ */ new Date()) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const [{ data: logRows }, { data: outRows }] = await Promise.all([db.from("email_log").select("kind,ref,step"), db.from("email_optout").select("email")]);
	if (!logRows) return {
		ok: false,
		why: "Run database step 50 first."
	};
	const sent = new Set(logRows.map((r) => `${r.kind}|${r.ref}|${r.step}`));
	const stopped = new Set((outRows ?? []).map((r) => r.email.toLowerCase()));
	const out = {
		online: 0,
		download: 0,
		failed: 0
	};
	/** The one step due today for something that started at `start` (or none). */
	const due = (steps, start, kind, ref) => {
		const age = Math.floor((now.getTime() - Date.parse(start)) / DAY);
		return steps.find((s) => age >= s.day && age <= s.day + LATE_DAYS && !sent.has(`${kind}|${ref}|${s.step}`));
	};
	async function send(kind, ref, to, s, v) {
		if (stopped.has(to.toLowerCase())) return;
		if ((await db.from("email_log").insert({
			kind,
			ref,
			step: s.step
		})).error) return;
		const text = `${s.body(v)}

Matthew Kalyani
Tallkeep · ${APP}

You're getting this because you started a Tallkeep trial. Stop these emails: ${stopLink(to)}`;
		if ((await deliver({
			fromName: "Matthew from Tallkeep",
			to: [to],
			replyTo: "hello@tallkeep.com",
			subject: s.subject,
			text
		}).catch((e) => ({
			ok: false,
			why: e.message
		}))).ok) out[kind]++;
		else {
			out.failed++;
			await db.from("email_log").delete().eq("kind", kind).eq("ref", ref).eq("step", s.step);
		}
	}
	const since = (/* @__PURE__ */ new Date(now.getTime() - 40 * DAY)).toISOString();
	const { data: orgs } = await db.from("orgs").select("id,name,status,created_at,created_by,trial_ends_at,is_platform,edition").gte("created_at", since);
	for (const o of orgs ?? []) {
		if (o.is_platform || o.edition === "desktop" || o.status !== "trial" || !o.created_by) continue;
		const s = due(ONLINE, o.created_at, "online", o.id);
		if (!s) continue;
		const { data: u } = await supabaseAdmin.auth.admin.getUserById(o.created_by);
		const email = u.user?.email;
		if (!email) continue;
		const { data: co } = await db.from("companies").select("id,name").eq("org_id", o.id).order("created_at").limit(1).maybeSingle();
		const { data: cs } = co ? await db.from("company_settings").select("business_type").eq("company_id", co.id).maybeSingle() : { data: null };
		const name = String((u.user?.user_metadata)?.name ?? "");
		const left = o.trial_ends_at ? Math.max(0, Math.ceil((Date.parse(o.trial_ends_at) - now.getTime()) / DAY)) : 5;
		await send("online", o.id, email, s, {
			first: name.split(" ")[0] || "there",
			personal: cs?.business_type === "personal",
			company: co?.name ?? o.name,
			daysLeft: left
		});
	}
	const { data: dls } = await db.from("downloads").select("name,email,platform,created_at").neq("platform", "mac").gte("created_at", since).order("created_at", { ascending: true });
	const { data: lic } = await db.from("desktop_licenses").select("email").not("email", "is", null);
	const buyers = new Set((lic ?? []).map((l) => l.email.toLowerCase()));
	const first = /* @__PURE__ */ new Map();
	for (const d of dls ?? []) {
		const k = d.email.toLowerCase();
		if (!first.has(k)) first.set(k, d);
	}
	for (const [k, d] of first) {
		if (buyers.has(k)) continue;
		const s = due(DOWNLOAD, d.created_at, "download", k);
		if (!s) continue;
		const left = Math.max(1, 30 - Math.floor((now.getTime() - Date.parse(d.created_at)) / DAY));
		await send("download", k, d.email, s, {
			first: d.name.split(" ")[0] || "there",
			personal: false,
			company: "",
			daysLeft: left
		});
	}
	return {
		ok: true,
		...out
	};
}
//#endregion
export { optoutCode, runTrialEmails };
