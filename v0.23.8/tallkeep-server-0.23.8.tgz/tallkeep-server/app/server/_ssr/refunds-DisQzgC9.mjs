import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-aFR9SgbK.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as payFromAccounts, r as nextCheckNumber, t as METHOD_LABEL } from "./money-BnCYGdUa.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/refunds-DisQzgC9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** "Sales Returns and Credits": lowers income when you give credit or money back. */
async function returnsAccount(accounts) {
	const have = accounts?.find((a) => a.key === "returns");
	if (have) return have.id;
	const { data, error } = await db.from("accounts").insert({
		number: "4050",
		name: "Sales Returns and Credits",
		type: "income",
		kind: "income",
		key: "returns"
	}).select("id").single();
	if (error) throw error;
	return data.id;
}
function Refunds() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: customers } = useQuery({
		queryKey: ["customers", "names"],
		queryFn: () => fetchAll("customers", "id,name,billing_address,address")
	});
	const { data: recent } = useQuery({
		queryKey: ["refunds", "recent"],
		queryFn: async () => {
			const [cr, rf] = await Promise.all([db.from("payments").select("id,amount,paid_on,reference,sales_orders(number,customer_name)").eq("method", "Credit").order("paid_on", { ascending: false }).limit(50), db.from("checks").select("id,total,check_date,payee,method,number,status").ilike("memo", "Refund%").order("check_date", { ascending: false }).limit(50)]);
			return {
				credits: cr.data ?? [],
				refunds: rf.data ?? []
			};
		}
	});
	const custOpts = (customers ?? []).map((c) => ({
		value: c.id,
		label: c.name
	}));
	const [cCust, setCCust] = (0, import_react.useState)("");
	const [cInv, setCInv] = (0, import_react.useState)("");
	const [cAmt, setCAmt] = (0, import_react.useState)("");
	const [cDate, setCDate] = (0, import_react.useState)(today());
	const [cWhy, setCWhy] = (0, import_react.useState)("");
	const { data: invoices } = useQuery({
		queryKey: [
			"refunds",
			"open",
			cCust
		],
		enabled: !!cCust,
		queryFn: async () => {
			const { data, error } = await db.from("sales_orders").select("id,number,customer_name,customer_id,balance,invoice_date,order_date").eq("customer_id", cCust).in("status", [
				"invoiced",
				"paid",
				"completed"
			]).gt("balance", 0).order("order_date");
			if (error) throw error;
			return (data ?? []).filter((o) => !o.number.startsWith("RMA-")).map((o) => ({
				...o,
				balance: Number(o.balance)
			}));
		}
	});
	const inv = invoices?.find((o) => o.id === cInv);
	(0, import_react.useEffect)(() => {
		if (inv && !cAmt) setCAmt(String(inv.balance));
	}, [inv, cAmt]);
	async function giveCredit() {
		if (!inv) return void toast.error("Pick the invoice.");
		const n = Math.round(Number(cAmt) * 100) / 100;
		if (!(n > 0)) return void toast.error("Type the amount.");
		if (n > inv.balance + .004) return void toast.error(`That's more than is owed (${fmtMoney(inv.balance)}).`);
		try {
			const acc = await returnsAccount(accounts);
			const { data: u } = await db.auth.getUser();
			const { error } = await db.from("payments").insert({
				sales_order_id: inv.id,
				amount: n,
				paid_on: (/* @__PURE__ */ new Date(`${cDate}T12:00:00`)).toISOString(),
				method: "Credit",
				reference: cWhy.trim() || "Credit",
				account_id: acc,
				created_by: u.user?.id
			});
			if (error) throw error;
			toast.success(`Credit of ${fmtMoney(n)} put on ${inv.number}.`);
			setCInv("");
			setCAmt("");
			setCWhy("");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		}
	}
	const pay = payFromAccounts(accounts);
	const [rCust, setRCust] = (0, import_react.useState)("");
	const [rName, setRName] = (0, import_react.useState)("");
	const [rAmt, setRAmt] = (0, import_react.useState)("");
	const [rDate, setRDate] = (0, import_react.useState)(today());
	const [rFrom, setRFrom] = (0, import_react.useState)("");
	const [rHow, setRHow] = (0, import_react.useState)("check");
	const [rWhy, setRWhy] = (0, import_react.useState)("");
	const [rPrint, setRPrint] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!rFrom && pay.length) setRFrom((pay.find((a) => a.kind === "bank") ?? pay[0]).id);
	}, [pay, rFrom]);
	async function refund() {
		const who = rCust ? customers?.find((c) => c.id === rCust)?.name ?? "" : rName.trim();
		const n = Math.round(Number(rAmt) * 100) / 100;
		if (!who) return void toast.error("Who gets the money back?");
		if (!(n > 0)) return void toast.error("Type the amount.");
		if (!rFrom) return void toast.error("Choose which account pays it.");
		try {
			const acc = await returnsAccount(accounts);
			const { data: u } = await db.auth.getUser();
			const cust = customers?.find((c) => c.id === rCust);
			const number = rHow === "check" && !rPrint ? await nextCheckNumber(rFrom) : null;
			const { data: c, error } = await db.from("checks").insert({
				account_id: rFrom,
				method: rHow,
				number,
				check_date: rDate,
				payee: who,
				address: cust?.billing_address ?? cust?.address ?? null,
				memo: `Refund${rWhy.trim() ? ` · ${rWhy.trim()}` : ""}`,
				to_print: rHow === "check" && rPrint,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("check_lines").insert({
				check_id: c.id,
				line_no: 1,
				account_id: acc,
				description: rWhy.trim() || "Refund",
				amount: n
			});
			if (le) throw le;
			toast.success(rHow === "check" && rPrint ? "Refund saved; the check waits in Print Checks." : "Refund saved.");
			setRAmt("");
			setRWhy("");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Refunds & Credits",
			text: "Lower what a customer owes, give money back, or save a credit a vendor gave you. Customer credits and refunds go against Sales Returns and Credits, so your income shows the real number."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Give a credit on an invoice"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "They owe less (a discount after the fact, a returned item not yet paid for)."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Customer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: cCust,
							options: custOpts,
							onChange: (v) => {
								setCCust(v);
								setCInv("");
								setCAmt("");
							},
							placeholder: "Pick a customer"
						})
					}),
					cCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Invoice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: cInv,
							onChange: (e) => {
								setCInv(e.target.value);
								setCAmt("");
							},
							className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: invoices?.length ? "Pick an invoice" : "No unpaid invoices"
							}), (invoices ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: o.id,
								children: [
									o.number,
									" · ",
									fmtDate((o.invoice_date ?? o.order_date).slice(0, 10)),
									" · owes",
									" ",
									fmtMoney(o.balance)
								]
							}, o.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Credit amount",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								value: cAmt,
								onChange: (e) => setCAmt(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: cDate,
								onChange: (e) => setCDate(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Why (shows on the invoice)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: cWhy,
							onChange: (e) => setCWhy(e.target.value),
							placeholder: "Returned 2 modules"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void giveCredit(),
						disabled: !inv,
						children: "Put the credit on the invoice"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Give money back"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "A refund by check, card or transfer for something they already paid."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Customer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: rCust,
							options: custOpts,
							onChange: setRCust,
							placeholder: "Pick a customer"
						}), !rCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-1.5",
							placeholder: "…or type a name",
							value: rName,
							onChange: (e) => setRName(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Amount",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									value: rAmt,
									onChange: (e) => setRAmt(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Date",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: rDate,
									onChange: (e) => setRDate(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Paid from",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: rFrom,
									options: pay.map((a) => ({
										value: a.id,
										label: accountLabel(a)
									})),
									onChange: setRFrom
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "How",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: rHow,
									onChange: (e) => setRHow(e.target.value),
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									children: Object.entries(METHOD_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: k,
										children: v
									}, k))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Why",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: rWhy,
							onChange: (e) => setRWhy(e.target.value),
							placeholder: "Returned screen"
						})
					}),
					rHow === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: rPrint,
								onChange: (e) => setRPrint(e.target.checked)
							}),
							" ",
							"Print the check"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void refund(),
						children: "Save the refund"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Money back FROM a vendor? Add it in",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/deposits",
								className: "underline",
								children: "Record Deposits"
							}),
							" ",
							"as other money, from the expense account it was for."
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VendorCredit, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "pt-2 font-semibold",
			children: "Recent credits and refunds"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [
				!recent?.credits.length && !recent?.refunds.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-muted-foreground",
					children: "None yet."
				}),
				(recent?.credits ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-xs",
							children: fmtDate(c.paid_on.slice(0, 10))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								"Credit · ",
								c.sales_orders?.customer_name,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [
										c.sales_orders?.number,
										" · ",
										c.reference
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: fmtMoney(Number(c.amount))
						})
					]
				}, c.id)),
				(recent?.refunds ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/checks/$id",
					params: { id: r.id },
					search: {},
					className: "flex flex-wrap items-center gap-3 px-4 py-2 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-xs",
							children: fmtDate(r.check_date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								"Refund · ",
								r.payee,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [
										METHOD_LABEL[r.method],
										" ",
										r.number ?? "",
										" ",
										r.status === "void" ? "· void" : ""
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: fmtMoney(Number(r.total))
						})
					]
				}, r.id))
			]
		})
	] });
}
/** A credit from a vendor (they owe us): taken off their next payment in Pay Bills. */
function VendorCredit() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "names"],
		queryFn: () => fetchAll("vendors", "id,name,is_active")
	});
	const [vendor, setVendor] = (0, import_react.useState)("");
	const [amt, setAmt] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today());
	const [acct, setAcct] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	const [why, setWhy] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const opts = (accounts ?? []).filter((a) => a.is_active && ![
		"ar",
		"ap",
		"bank"
	].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	async function save() {
		const v = vendors?.find((x) => x.id === vendor);
		const n = Math.round(Number(amt) * 100) / 100;
		if (!v) return void toast.error("Pick the vendor.");
		if (!(n > 0)) return void toast.error("Type the credit amount.");
		if (!acct) return void toast.error("What was it for? Pick the account (for example the expense or Inventory).");
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const { data: b, error } = await db.from("bills").insert({
				vendor_id: v.id,
				vendor_name: v.name,
				ref: ref.trim() || null,
				bill_date: date,
				due_date: date,
				memo: `Vendor credit${why.trim() ? ` · ${why.trim()}` : ""}`,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("bill_lines").insert({
				bill_id: b.id,
				line_no: 1,
				account_id: acct,
				description: why.trim() || "Vendor credit",
				amount: -n
			});
			if (le) throw le;
			toast.success(`Credit of ${fmtMoney(n)} from ${v.name} saved. It comes off their next payment in Pay Bills.`);
			setAmt("");
			setRef("");
			setWhy("");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "A credit from a vendor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "The vendor owes you (you returned something, or they gave a discount). It comes off what you pay them next, in Pay Bills."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Vendor",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: vendor,
							options: (vendors ?? []).filter((v) => v.is_active).map((v) => ({
								value: v.id,
								label: v.name
							})),
							onChange: setVendor,
							placeholder: "Pick a vendor"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Credit amount",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							value: amt,
							onChange: (e) => setAmt(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What it was for (account)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: acct,
							options: opts,
							onChange: setAcct,
							placeholder: "e.g. Cost of Goods Sold"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Their credit memo # (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Why",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: why,
							onChange: (e) => setWhy(e.target.value),
							placeholder: "Returned 10 modules"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save the vendor credit"
			})
		]
	});
}
//#endregion
export { Refunds as component };
