import { n as db } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/photos-cgxXGXuX.js
var PHOTO_BUCKET = "product-photos";
/** A short-lived link to a private photo. */
function usePhotoUrl(path) {
	return useQuery({
		queryKey: ["photo", path],
		enabled: !!path,
		staleTime: 3e6,
		queryFn: async () => {
			const { data, error } = await db.storage.from(PHOTO_BUCKET).createSignedUrl(path, 3600);
			if (error) throw error;
			return data.signedUrl;
		}
	});
}
/** Make a phone photo smaller before upload (max 1200px, JPEG). */
async function shrinkImage(file) {
	try {
		const bmp = await createImageBitmap(file);
		const scale = Math.min(1, 1200 / Math.max(bmp.width, bmp.height));
		const c = document.createElement("canvas");
		c.width = Math.round(bmp.width * scale);
		c.height = Math.round(bmp.height * scale);
		c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
		return await new Promise((res) => c.toBlob((b) => res(b ?? file), "image/jpeg", .82));
	} catch {
		return file;
	}
}
/** Extra photos live in a folder per product: products/<id>/<time>.jpg */
var extraFolder = (productId) => `products/${productId}`;
async function uploadExtraPhoto(productId, file) {
	const path = `${extraFolder(productId)}/${Date.now()}-${Math.round(Math.random() * 1e4)}.jpg`;
	const { error } = await db.storage.from(PHOTO_BUCKET).upload(path, file, {
		contentType: "image/jpeg",
		upsert: false
	});
	if (error) throw error;
	return path;
}
/** Main photo plus extra photos, with links to show them. */
function useProductPhotos(productId, mainPath) {
	return useQuery({
		queryKey: [
			"photos",
			productId,
			mainPath
		],
		queryFn: async () => {
			const { data, error } = await db.storage.from(PHOTO_BUCKET).list(extraFolder(productId), {
				limit: 100,
				sortBy: {
					column: "name",
					order: "asc"
				}
			});
			if (error) throw error;
			const extra = (data ?? []).filter((f) => f.name.endsWith(".jpg")).map((f) => `${extraFolder(productId)}/${f.name}`);
			const paths = [...mainPath ? [mainPath] : [], ...extra.filter((p) => p !== mainPath)];
			if (!paths.length) return [];
			const { data: signed, error: e2 } = await db.storage.from(PHOTO_BUCKET).createSignedUrls(paths, 3600);
			if (e2) throw e2;
			return paths.map((p, i) => ({
				path: p,
				url: signed?.[i]?.signedUrl ?? ""
			}));
		},
		staleTime: 3e6
	});
}
//#endregion
export { useProductPhotos as a, usePhotoUrl as i, shrinkImage as n, uploadExtraPhoto as r, PHOTO_BUCKET as t };
