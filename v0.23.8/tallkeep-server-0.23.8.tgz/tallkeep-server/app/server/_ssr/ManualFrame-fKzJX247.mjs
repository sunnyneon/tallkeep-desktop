import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as Search } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
import { a as bySection, o as searchManual } from "./manual-C1hviOEM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ManualFrame-fKzJX247.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The full manual pages (/manual): a header with search, the sections on the left. */
function ManualFrame({ current, children }) {
	const [q, setQ] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const results = (0, import_react.useMemo)(() => searchManual(q, 12), [q]);
	const sections = (0, import_react.useMemo)(() => bySection(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b bg-card/95 backdrop-blur print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center gap-4 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/manual",
					className: "flex shrink-0 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { auto: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-sm font-semibold text-muted-foreground sm:inline",
						children: "Manual"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative ml-auto w-full max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search the manual",
							value: q,
							onChange: (e) => setQ(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter" && results[0]) {
									navigate({
										to: "/manual/$slug",
										params: { slug: results[0].slug }
									});
									setQ("");
								}
							}
						}),
						q.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-x-0 top-full mt-1 max-h-[70vh] overflow-y-auto rounded-xl border bg-card p-1 shadow-lg",
							children: [results.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "p-3 text-sm text-muted-foreground",
								children: "Nothing found."
							}), results.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/manual/$slug",
								params: { slug: a.slug },
								onClick: () => setQ(""),
								className: "block rounded-lg px-3 py-2 hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: a.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: a.summary
								})]
							}, a.slug))]
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl gap-8 px-4 py-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "sticky top-20 hidden h-[calc(100vh-6rem)] w-64 shrink-0 overflow-y-auto pr-2 text-sm lg:block print:hidden",
				children: sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-semibold",
						children: s.section
					}), s.list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/manual/$slug",
						params: { slug: a.slug },
						className: `block rounded-md px-2 py-1 ${a.slug === current ? "bg-primary/10 font-medium text-primary" : "text-muted-foreground hover:text-foreground"}`,
						children: a.title
					}, a.slug))]
				}, s.section))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-w-0 flex-1",
				children
			})]
		})]
	});
}
//#endregion
export { ManualFrame as t };
