import { t as cn } from "./utils-C_uf36nf.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { c as Users } from "../_libs/lucide-react.mjs";
import { a as useWho, i as useMembers } from "./members-BvdxHr68.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/WhoPicker-DLJRzcvg.js
var import_jsx_runtime = require_jsx_runtime();
/** Everyone, or one person in the household. Hidden until people are added on Household. */
function WhoPicker() {
	const { data: members } = useMembers();
	const [who, setWho] = useWho();
	if (!members?.length) return null;
	const opts = [{
		id: "",
		name: "Everyone",
		color: null
	}, ...members];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-1.5",
		role: "group",
		"aria-label": "Whose money",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 text-muted-foreground" }), opts.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setWho(m.id),
			className: cn("rounded-full border px-3 py-1 text-sm", who === m.id ? "border-transparent text-white" : "bg-card"),
			style: who === m.id ? { backgroundColor: m.color ?? "#0E7C74" } : void 0,
			children: m.name
		}, m.id))]
	});
}
//#endregion
export { WhoPicker as t };
