import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { i as fmtQty } from "./format-CORJO1ov.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { o as useLocations, u as useShelves } from "./queries-DKvOnwaZ.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/StockDialogs-DZU-z4xh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Stock changes that save once. Each change carries a key; sending the same key again (a quick
* double press, or trying again after the connection dropped) does nothing the second time.
* Keep the key until the change succeeds, then make a new one for the next change.
* Before database step 060 the "_once" functions don't exist; then the plain ones are used.
*/
var newStockKey = () => typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `k${Date.now()}${Math.random().toString(36).slice(2)}`;
async function stockOnce(fn, key, args) {
	const r = await db.rpc(`${fn}_once`, {
		_key: key,
		...args
	});
	if (!r.error) return r;
	if (r.error.code === "PGRST202" || /could not find the function/i.test(r.error.message)) return db.rpc(fn, args);
	return r;
}
var TITLES = {
	add: {
		title: "Add stock",
		text: "Put more of this item in a place.",
		button: "Add to stock"
	},
	remove: {
		title: "Take out stock",
		text: "Remove items (damaged, used, lost…).",
		button: "Take out of stock"
	},
	count: {
		title: "Count stock",
		text: "Type how many you actually see. We fix the number for you.",
		button: "Save count"
	},
	move: {
		title: "Move stock",
		text: "Move items from one place to another.",
		button: "Move stock"
	}
};
/** Pick a location and (optional) shelf. Lets you type a new shelf name. */
function PlacePicker({ label, locationId, shelf, onLocation, onShelf }) {
	const { data: locations } = useLocations();
	const { data: shelves } = useShelves();
	const options = (0, import_react.useMemo)(() => (shelves ?? []).filter((s) => s.location_id === locationId).map((s) => s.name).sort(), [shelves, locationId]);
	const listId = `shelves-${label.replace(/\W/g, "")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: locationId,
				onValueChange: onLocation,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a place" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (locations ?? []).filter((l) => l.is_active).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: l.id,
					children: l.name
				}, l.id)) })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Shelf or spot (optional)" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					list: listId,
					value: shelf,
					onChange: (e) => onShelf(e.target.value),
					placeholder: "e.g. A2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
					id: listId,
					children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: o }, o))
				})
			]
		})]
	});
}
function StockDialog({ action, productId, productName, rows, open, onOpenChange, preset }) {
	const qc = useQueryClient();
	const t = TITLES[action];
	const [loc, setLoc] = (0, import_react.useState)(preset?.location_id ?? "");
	const [shelf, setShelf] = (0, import_react.useState)(preset?.shelf ?? "");
	const [toLoc, setToLoc] = (0, import_react.useState)("");
	const [toShelf, setToShelf] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const key = (0, import_react.useRef)(newStockKey());
	const current = rows.find((r) => r.location_id === loc && r.shelf === shelf.trim())?.qty ?? 0;
	async function ensureShelf(locationId, name) {
		const n = name.trim();
		if (!n) return;
		await db.from("shelves").upsert({
			location_id: locationId,
			name: n
		}, {
			onConflict: "location_id,name",
			ignoreDuplicates: true
		});
	}
	async function submit(e) {
		e.preventDefault();
		const n = Number(qty);
		if (!loc) {
			toast.error("Choose a place first.");
			return;
		}
		if (!Number.isFinite(n) || action !== "count" && n <= 0 || action === "count" && n < 0) {
			toast.error("Type a number.");
			return;
		}
		if (action === "move" && !toLoc) {
			toast.error("Choose where to move it to.");
			return;
		}
		if (busy) return;
		setBusy(true);
		let error;
		if (action === "add" || action === "remove") ({error} = await stockOnce("change_stock", key.current, {
			_product_id: productId,
			_location_id: loc,
			_shelf: shelf.trim(),
			_qty_change: action === "add" ? n : -n,
			_reason: "adjust",
			_note: note || null
		}));
		else if (action === "count") ({error} = await stockOnce("set_stock_count", key.current, {
			_product_id: productId,
			_location_id: loc,
			_shelf: shelf.trim(),
			_counted: n,
			_note: note || null
		}));
		else {
			({error} = await stockOnce("move_stock", key.current, {
				_product_id: productId,
				_from_location: loc,
				_from_shelf: shelf.trim(),
				_to_location: toLoc,
				_to_shelf: toShelf.trim(),
				_qty: n,
				_note: note || null
			}));
			if (!error) await ensureShelf(toLoc, toShelf);
		}
		if (!error) await ensureShelf(loc, shelf);
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Saved.");
		key.current = newStockKey();
		qc.invalidateQueries({ queryKey: ["product", productId] });
		qc.invalidateQueries({ queryKey: ["products"] });
		qc.invalidateQueries({ queryKey: ["stock"] });
		qc.invalidateQueries({ queryKey: ["shelves"] });
		setQty("");
		setNote("");
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "max-w-lg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						productName,
						" — ",
						t.text
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlacePicker, {
						label: action === "move" ? "From" : "Place",
						locationId: loc,
						shelf,
						onLocation: setLoc,
						onShelf: setShelf
					}),
					loc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["Now there: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtQty(current) })]
					}),
					action === "move" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlacePicker, {
						label: "To",
						locationId: toLoc,
						shelf: toShelf,
						onLocation: setToLoc,
						onShelf: setToShelf
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: action === "count" ? "How many do you see?" : "How many?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: qty,
							onChange: (e) => setQty(e.target.value),
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Note (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							value: note,
							onChange: (e) => setNote(e.target.value),
							placeholder: "Why? e.g. damaged in shipping"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => onOpenChange(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Saving…" : t.button
					})] })
				]
			})
		})
	});
}
//#endregion
export { stockOnce as i, StockDialog as n, newStockKey as r, PlacePicker as t };
