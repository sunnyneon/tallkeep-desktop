//#region ../../node_modules/.nitro/vite/services/ssr/assets/csv-D0ewwTlm.js
/** Rows → CSV text (numbers with 2 decimals, text quoted). */
function toCsv(rows) {
	return rows.map((r) => r.map((c) => typeof c === "number" ? c.toFixed(2) : `"${String(c).replace(/"/g, "\"\"")}"`).join(",")).join("\r\n");
}
function downloadBlob(name, blob) {
	const a = document.createElement("a");
	a.href = URL.createObjectURL(blob);
	a.download = name;
	a.click();
	setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
}
/** CSV download of the rows on screen. */
function downloadCsv(name, rows) {
	downloadBlob(`${name}.csv`, new Blob([toCsv(rows)], { type: "text/csv" }));
}
var CRC = (() => {
	const t = /* @__PURE__ */ new Uint32Array(256);
	for (let n = 0; n < 256; n++) {
		let c = n;
		for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
		t[n] = c >>> 0;
	}
	return t;
})();
function crc32(b) {
	let c = 4294967295;
	for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ c >>> 8;
	return (c ^ 4294967295) >>> 0;
}
/** Make a .zip from text files (or files as bytes: PDFs, photos). */
function makeZip(files) {
	const enc = new TextEncoder();
	const now = /* @__PURE__ */ new Date();
	const time = now.getHours() << 11 | now.getMinutes() << 5 | now.getSeconds() >> 1;
	const date = now.getFullYear() - 1980 << 9 | now.getMonth() + 1 << 5 | now.getDate();
	const parts = [];
	const central = [];
	let offset = 0;
	for (const f of files) {
		const name = enc.encode(f.name);
		const data = f.bytes ?? enc.encode(f.text ?? "");
		const crc = crc32(data);
		const head = new Uint8Array(30 + name.length);
		const h = new DataView(head.buffer);
		h.setUint32(0, 67324752, true);
		h.setUint16(4, 20, true);
		h.setUint16(6, 2048, true);
		h.setUint16(8, 0, true);
		h.setUint16(10, time, true);
		h.setUint16(12, date, true);
		h.setUint32(14, crc, true);
		h.setUint32(18, data.length, true);
		h.setUint32(22, data.length, true);
		h.setUint16(26, name.length, true);
		head.set(name, 30);
		const dir = new Uint8Array(46 + name.length);
		const d = new DataView(dir.buffer);
		d.setUint32(0, 33639248, true);
		d.setUint16(4, 20, true);
		d.setUint16(6, 20, true);
		d.setUint16(8, 2048, true);
		d.setUint16(10, 0, true);
		d.setUint16(12, time, true);
		d.setUint16(14, date, true);
		d.setUint32(16, crc, true);
		d.setUint32(20, data.length, true);
		d.setUint32(24, data.length, true);
		d.setUint16(28, name.length, true);
		d.setUint32(42, offset, true);
		dir.set(name, 46);
		parts.push(head, data);
		central.push(dir);
		offset += head.length + data.length;
	}
	const size = central.reduce((s, c) => s + c.length, 0);
	const end = /* @__PURE__ */ new Uint8Array(22);
	const e = new DataView(end.buffer);
	e.setUint32(0, 101010256, true);
	e.setUint16(8, files.length, true);
	e.setUint16(10, files.length, true);
	e.setUint32(12, size, true);
	e.setUint32(16, offset, true);
	return new Blob([
		...parts,
		...central,
		end
	], { type: "application/zip" });
}
//#endregion
export { toCsv as i, downloadCsv as n, makeZip as r, downloadBlob as t };
