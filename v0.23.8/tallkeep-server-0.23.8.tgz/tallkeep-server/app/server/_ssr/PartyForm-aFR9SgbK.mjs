import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { g as Trash2 } from "../_libs/lucide-react.mjs";
import { c as usePaymentTerms, d as useTaxRates, l as usePriceLists } from "./queries-DKvOnwaZ.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PartyForm-aFR9SgbK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, wide, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: wide ? "space-y-1.5 sm:col-span-2" : "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function Pick({ value, onChange, options, none }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value: value ?? "none",
		onValueChange: (v) => onChange(v === "none" ? null : v),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: "none",
			children: none
		}), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: o.id,
			children: o.name
		}, o.id))] })]
	});
}
/** Edit form for a customer or vendor. */
function PartyForm({ kind, record }) {
	const qc = useQueryClient();
	const isCust = kind === "customers";
	const { data: terms } = usePaymentTerms();
	const { data: taxes } = useTaxRates();
	const { data: lists } = usePriceLists();
	const [f, setF] = (0, import_react.useState)(record);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setF(record), [record]);
	const set = (k, v) => setF((x) => ({
		...x,
		[k]: v
	}));
	const navigate = useNavigate();
	async function remove() {
		const who = isCust ? "customer" : "vendor";
		if (!window.confirm(`Delete ${String(record["name"] ?? `this ${who}`)}? This can't be undone.`)) return;
		setBusy(true);
		const { error } = await db.from(kind).delete().eq("id", String(record["id"]));
		setBusy(false);
		if (error) {
			toast.error(/foreign key|violates/i.test(error.message) ? `This ${who} has ${isCust ? "quotes, invoices or payments" : "purchase orders, bills or payments"}, so it can't be deleted. Untick Active to hide it instead.` : error.message, { duration: 1e4 });
			return;
		}
		toast.success(`${isCust ? "Customer" : "Vendor"} deleted.`);
		qc.invalidateQueries({ queryKey: [kind] });
		navigate({ to: isCust ? "/customers" : "/vendors" });
	}
	const text = (k) => ({
		value: f[k] ?? "",
		onChange: (e) => set(k, e.target.value || null)
	});
	async function save(e) {
		e.preventDefault();
		if (!String(f["name"] ?? "").trim()) {
			toast.error("Name can't be empty.");
			return;
		}
		const fields = [
			"name",
			"contact_name",
			"phone",
			"fax",
			"email",
			"website",
			"address",
			"payment_terms_id",
			"remarks",
			"is_active"
		];
		if (isCust) fields.push("billing_address", "shipping_address", "price_list_id", "tax_rate_id", "discount", "sales_rep", "tax_exempt_number");
		const patch = {};
		fields.forEach((k) => patch[k] = f[k] ?? null);
		patch["name"] = String(f["name"]).trim();
		patch["is_active"] = f["is_active"] !== false;
		if (isCust) patch["discount"] = Number(f["discount"]) || 0;
		setBusy(true);
		const { error } = await db.from(kind).update(patch).eq("id", record["id"]);
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Saved.");
		qc.invalidateQueries({ queryKey: [kind] });
		qc.invalidateQueries({ queryKey: [kind.slice(0, -1), record["id"]] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Contact person",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("contact_name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "tel",
							...text("phone")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							...text("email")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Website",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fax",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("fax") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("address")
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bill to (if different)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("billing_address")
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ship to (if different)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("shipping_address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Payment terms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
							value: f["payment_terms_id"],
							onChange: (v) => set("payment_terms_id", v),
							options: terms ?? [],
							none: "Not set"
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Price list",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
								value: f["price_list_id"],
								onChange: (v) => set("price_list_id", v),
								options: lists ?? [],
								none: "Normal price"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Sales tax",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
								value: f["tax_rate_id"],
								onChange: (v) => set("tax_rate_id", v),
								options: (taxes ?? []).map((t) => ({
									id: t.id,
									name: `${t.name} (${Number(t.rate)}%)`
								})),
								none: "Not set"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Discount (%)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f["discount"] ?? "",
								onChange: (e) => set("discount", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Sales rep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("sales_rep") })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tax exempt / resale number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("tax_exempt_number") })
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							...text("remarks")
						})
					})
				]
			}),
			Object.keys(f["custom"] ?? {}).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-muted/50 p-3 text-sm",
				children: Object.entries(f["custom"]).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [k, ":"]
					}),
					" ",
					v
				] }, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: f["is_active"] !== false,
							onCheckedChange: (v) => set("is_active", v)
						}),
						" ",
						"Active"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [record?.["id"] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						disabled: busy,
						onClick: () => void remove(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }),
							" Delete this ",
							isCust ? "customer" : "vendor"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						children: busy ? "Saving…" : isCust ? "Save customer" : "Save vendor"
					})]
				})]
			})
		]
	});
}
//#endregion
export { PartyForm as n, Field as t };
