//#region ../../node_modules/.nitro/vite/services/ssr/assets/manual-C1hviOEM.js
var SECTIONS = [
	"Getting started",
	"Sales",
	"Customers",
	"Purchasing",
	"Inventory",
	"Banking",
	"Accounting",
	"Properties",
	"Personal money",
	"Settings & people",
	"Office computer & backups",
	"Online & phone",
	"Questions & fixes"
];
var articles$3 = [
	{
		slug: "welcome-to-tallkeep",
		title: "Welcome to Tallkeep",
		section: "Getting started",
		summary: "What Tallkeep does and how the Home page takes you to each job.",
		paths: ["/"],
		keywords: [
			"start",
			"home",
			"dashboard",
			"inflow",
			"quickbooks",
			"menu",
			"tiles",
			"what is"
		],
		body: `Read this first if you are new to Tallkeep.

Tallkeep keeps your quotes, invoices, customers, products, stock and books in one place. It does the work of inFlow and QuickBooks together, so you type things once.

## The Home page

Home shows a button for each job, grouped the way the work flows:

- **Sales**: Quotes, then Invoices, then Receive Payments, then Record Deposits. Under them are Customers, Sales List, Sales Receipt, Statements, Refunds & Credits and Tickets.
- **Purchasing**: buying from vendors and paying bills.
- **Inventory**: Products and Current Stock.
- **Banking** and **Company**: checks, deposits, reports and Settings.

You only see the parts your company has turned on, and the parts you are allowed to use.

## The menu

The menu on the left has the same pages under headings (Sales, Purchasing, Inventory, Banking, Company, Reports). Each heading has its own color. The thin colored band at the top of the page tells you which part of the app you are in.

## Numbers and to-dos

Home is for getting to work. For your numbers (sales, what customers owe, quotes to follow up), open **Overview**. See [The Overview page](/manual/overview-page).

> Tip: Press **F1** or the **Help** button on any page to open help for that page.

Next: [Your first steps](/manual/first-steps) and [Getting around](/manual/getting-around).`
	},
	{
		slug: "getting-around",
		title: "Getting around: tabs, lists and Help",
		section: "Getting started",
		summary: "Use the tabs at the top, the list on the left of a page, Esc and F1 to move around quickly.",
		keywords: [
			"tabs",
			"navigate",
			"esc",
			"close page",
			"back",
			"side list",
			"left list",
			"f1",
			"help"
		],
		body: `Use this to move between pages fast, like in QuickBooks and inFlow.

## Tabs at the top

Every page you open gets a tab across the top of the screen.

1. Click a tab to go back to that page.
2. Click the **×** on a tab to close it.
3. Press **Esc** to close the page you are on. If you typed something you did not save, it asks first.

Tabs are remembered on this computer, up to 12 at a time.

## The list on the left

Quote, invoice, customer, product and vendor pages show a list on the left. Click any line to jump to it without going back to the full list. The page you are on is colored in the list.

- Type in **Search** at the top of the list to narrow it down.
- Click the **Hide the list** button to make more room. Click the thin bar on the left (**Show the list**) to bring it back.

For the extra boxes on the invoice list, see [Search and filter quotes and invoices](/manual/search-sales).

## Help

Press **F1** or click **Help** in the menu. Help opens at the article for the page you are on. You can also search all of the help from there.

> Tip: The tabs and the left list show on wider screens. On a phone, see [Using Tallkeep on a phone](/manual/use-on-a-phone).`
	},
	{
		slug: "search-everything",
		title: "Search everything (Ctrl K)",
		section: "Getting started",
		summary: "Find a customer, invoice, product, check or amount from any page.",
		keywords: [
			"ctrl k",
			"cmd k",
			"find",
			"global search",
			"look up",
			"search box",
			"amount",
			"invoice number"
		],
		body: `Use this when you need to find something and don't know which page it is on.

1. Press **Ctrl K** (on a Mac, **⌘ K**). You can also press **/** when you are not typing in a box, or click **Search…** in the menu.
2. Type a name, invoice number, check number, dollar amount, phone or email.
3. Results show in groups: Customers, Vendors, Sales (quotes, orders, invoices), Purchase orders, Bills, Payments received, Products, Accounts and more.
4. Click a result to open it.

> Tip: To find a payment by its amount, type the amount, for example **1250** or **$1,250.00**.

> Tip: To look through only quotes and invoices, the search box on the Sales List is often quicker. See [Search and filter quotes and invoices](/manual/search-sales).`
	},
	{
		slug: "first-steps",
		title: "Your first steps after setup",
		section: "Getting started",
		summary: "Add your company details, products and customers, then send your first invoice.",
		keywords: [
			"setup",
			"set up",
			"begin",
			"new company",
			"logo",
			"first invoice",
			"checklist",
			"onboarding"
		],
		body: `Do these once, right after your company is set up.

1. **Company details.** Open **Settings**, pick **Company**, and fill in **Company details**. Click **Change logo** to add your logo. Click **Save company details**. This is printed at the top of every quote and invoice.
2. **Products.** Open **Product List** and click **New product** for each thing you sell. You can also add a product while making an invoice.
3. **Customers.** Open **Customers** and click **Add customer**. Type the name, then fill in the rest on the customer page. See [Add or change a customer](/manual/add-a-customer).
4. **Your first invoice.** In the menu, click **New Invoice**, choose the customer, add the items, and click **Save**. See [Make a quote or an invoice](/manual/make-a-quote-or-invoice).
5. **Send it.** Click **Email customer** to send it with the PDF attached. See [Email, print or save as PDF](/manual/email-or-print).

> Tip: Coming from inFlow or QuickBooks? When you set up a company you can bring in your products, customers and open invoices instead of typing them.

> Tip: Once card payments are set up for your company, each invoice can carry a **Pay now** link so customers pay by card. See [Pay now links and deposits](/manual/pay-now-and-deposits).`
	},
	{
		slug: "switch-company",
		title: "Switch between companies",
		section: "Getting started",
		summary: "Work in another of your companies, or set up a new one.",
		keywords: [
			"company picker",
			"change company",
			"other business",
			"multiple companies",
			"add company",
			"new company"
		],
		body: `Use this when you run more than one business in Tallkeep.

## Switch company

1. Look under the logo at the top of the menu. When you can open more than one company, the company name is a drop-down.
2. Click it and pick the other company.
3. Tallkeep reloads with that company's customers, invoices, products and books.

On a phone, the same drop-down is in the bar at the top of the screen.

If you see the company name but no drop-down, you only have access to one company. Ask the owner to give you access to the other one.

## Set up a new company

1. Open **Settings** and pick **Company**.
2. Click **Set up a new company**.
3. Follow the short steps: company details, email, document numbers, and the kind of business.
4. At the end, pick **Bring in data from inFlow**, **Bring in data from QuickBooks**, or **Start empty**.

> Tip: Each company has its own numbers, customers and books. Nothing is shared between them, so check the company name before you make an invoice.`
	},
	{
		slug: "use-on-a-phone",
		title: "Using Tallkeep on a phone",
		section: "Getting started",
		summary: "The bottom buttons, the More menu, and picking your own buttons.",
		keywords: [
			"mobile",
			"phone",
			"iphone",
			"android",
			"tablet",
			"bottom bar",
			"bottom buttons",
			"more"
		],
		body: `Use this when you work from your phone.

Tallkeep works in your phone's web browser. Pages fit the small screen: lists become simple lines you tap to open.

## The bottom buttons

At the bottom of the screen are four buttons and **More**. Tap **More** to see every other page.

## Pick your own four buttons

1. Tap **More**.
2. Tap **Change the bottom buttons**.
3. Tap four pages in the order you want them. Tap one again to take it off.
4. Your choice is saved with your login, so it follows you to any phone.

## What is different on a phone

- The tabs at the top and the list on the left of a page are hidden to save room. Use **Back** at the top of a page instead.
- Tap the **Help** icon at the top for help on the page you are on.
- To switch company, use the drop-down in the top bar.

> Tip: You can make a quote, email it and record a payment from your phone, the same as on a computer.`
	},
	{
		slug: "overview-page",
		title: "The Overview page",
		section: "Getting started",
		summary: "Your numbers at a glance: sales, what customers owe, open quotes and quotes to follow up.",
		paths: ["/overview"],
		keywords: [
			"dashboard",
			"numbers",
			"summary",
			"kpi",
			"sales this year",
			"customers owe",
			"top customers",
			"running low"
		],
		body: `Open this to see how the business is doing and what needs your attention today.

## The number boxes

- **Sales this year**, with how it compares to the same time last year.
- **Sales in** this month, and **Payments received** this month.
- **Customers owe**: money still owed on invoices.
- **Open quotes** and what they are worth.
- **Average invoice this year**, **Stock value (at cost)** and **Running low**.

Click a box to open the page behind it.

## Below the boxes

- **How things flow**: Vendor, Purchase order, Inventory, Invoice, Customer. Click any step to go there.
- **Sales by month**: this year next to last year.
- **Top customers this year**.
- **Quotes to follow up**: quotes that are due for a 1st or 2nd follow-up. Click **Email follow-up** to send one, or **Close quote** if the customer is not going ahead. See [Follow up on quotes](/manual/quote-follow-ups).

At the bottom are quick buttons: **New quote**, **New invoice**, **Find a product** and **Check stock**.

> Tip: If the follow-up list says **Turn on daily follow-ups**, follow-ups are off. Click it to turn them on in Settings.`
	},
	{
		slug: "quote-and-invoice-page",
		title: "The quote and invoice page",
		section: "Sales",
		summary: "What each part of a quote or invoice page does, and how its status changes.",
		paths: ["/sales/"],
		keywords: [
			"invoice page",
			"quote page",
			"order",
			"sales order",
			"status",
			"next step",
			"not invoiced yet",
			"save"
		],
		body: `Use this to find your way around a quote or invoice.

Quotes, invoices and RMAs all use the same page. The name at the top (for example **Quote Q-1042**) and the colored label next to it tell you what it is now.

## The status label

- **Quote**: a price offer. It does not change stock or money.
- **Not invoiced yet**: the customer said yes, but you have not billed it.
- **Invoice – unpaid** and **Invoice – paid**.
- **Completed**, **Cancelled**, or **RMA** for returns.

## The parts of the page

1. **Buttons at the top**: **Print or save PDF**, **Copy**, **Start an RMA from this**, **Order from vendor**, **Email customer** and **Save**.
2. **Next step**: the buttons for what usually comes next, like **Create invoice**, **Record payment** or **Mark fulfilled**.
3. **Customer box**: customer, contact, phone, email, addresses, **Terms**, **P.O. #**, **Sales rep**, **Location** and dates.
4. **Lines**: the items, with quantity, price, discount and tax.
5. **Totals**: subtotal, sales tax, shipping, total and **Balance due**.
6. **Payments**: every payment on this invoice.

Click **Save** when you change something. The button says **Saved** when everything is kept.

> Tip: If you change the contact, phone, email, address, terms or sales rep here, a yellow note offers **Save changes to the customer**, so next time it fills in by itself.

> Tip: **Back** at the top takes you to the Sales List.`
	},
	{
		slug: "make-a-quote-or-invoice",
		title: "Make a quote or an invoice",
		section: "Sales",
		summary: "Start a new quote (estimate) or invoice, add the customer and items, and save it.",
		paths: [
			"/new-quote",
			"/new-invoice",
			"/quotes"
		],
		keywords: [
			"new quote",
			"new invoice",
			"estimate",
			"proposal",
			"bill a customer",
			"create invoice",
			"price quote",
			"sales order"
		],
		body: `Use this to give a customer a price, or to bill them.

1. In the menu, click **New Quote** or **New Invoice**. (On the Quotes page, click **New sales quote**. On a customer's page, click **New quote** or **New invoice**.)
2. Under **Customer**, click the box and type a name, phone or email. Pick the customer. Their contact, addresses, terms, sales tax and discount fill in by themselves.
3. In the first line, click **Choose a product (or just type a description)** and pick a product. Or type a description for something that is not a product.
4. Type the **Qty**. Change the **Price** if you need to.
5. Click **Add line** for each other item.
6. Check the sales tax and shipping at the bottom.
7. Click **Save**. The quote or invoice gets its number now.

A new invoice is saved as **Not invoiced yet**. Click **Mark as invoiced (sets the due date)** when you bill it. See [Turn a quote into an invoice](/manual/quote-to-invoice).

> Tip: Can't find the customer? Add them first under **Customers**. Can't find the product? In the product box, click **Add new product**.

> Tip: For discounts, tax and notes, see [Lines, discounts, tax and shipping](/manual/lines-discounts-tax).`
	},
	{
		slug: "quote-to-invoice",
		title: "Turn a quote into an invoice",
		section: "Sales",
		summary: "When the customer says yes, make the quote an invoice and set the due date.",
		keywords: [
			"accept quote",
			"convert quote",
			"quote accepted",
			"make invoice",
			"invoice from quote",
			"due date",
			"mark as invoiced"
		],
		body: `Use this when a customer accepts your quote.

In the **Next step** bar of the quote you have two buttons:

- **Create invoice**: it becomes an invoice right away, dated today, with the due date set from the customer's **Terms**.
- **Customer accepted – make invoice**: it becomes an invoice marked **Not invoiced yet**. Use this when you will ship or do the work first and bill later.

## Bill it now

1. Open the quote.
2. Click **Create invoice**.
3. Click **Email customer** to send the invoice. See [Email, print or save as PDF](/manual/email-or-print).

## Bill it later

1. Open the quote and click **Customer accepted – make invoice**.
2. When the work is done, open it again and click **Mark as invoiced (sets the due date)**.
3. Click **Email customer** to send it.

The number stays the same, so the customer can match it to the quote.

> Tip: The due date comes from **Terms** (for example Net 30). Change **Terms** on the page and the **Due date** moves with it. You can also type a due date yourself.

> Tip: The footer text changes from the quote footer to the invoice footer by itself, unless you changed it.`
	},
	{
		slug: "lines-discounts-tax",
		title: "Lines, discounts, tax and shipping",
		section: "Sales",
		summary: "Add or remove items, give a discount, set sales tax and shipping, and add notes.",
		paths: ["/sales/"],
		keywords: [
			"discount",
			"line item",
			"sales tax",
			"tax rate",
			"taxable",
			"shipping",
			"freight",
			"notes",
			"remove line",
			"price list",
			"footer"
		],
		body: `Use this to change what is on a quote or invoice.

## Items

- Click **Add line** for another item. Click the trash can (**Remove line**) to take one off.
- Under **Qty** you see how many are in stock. If there are not enough, it says **short** in red.
- You can change the description of any line. It prints the way you type it.

## Discounts

Type a percent in **Disc. %** on a line. If the customer has a discount on their customer page, it fills in by itself. The line under the customer box shows **Pricing**: normal price or the customer's price list.

## Sales tax

- Each line has a **Tax** box. Untick it for things that are not taxed.
- At the bottom, pick the tax from the drop-down, or type the percent in the box next to it.

## Shipping

Type the amount in **Shipping / freight**. It is added to the total.

## Notes and footers

- **Notes for the customer (printed)** shows on the PDF.
- Under **Footers and attached pages**, pick saved footer text or your terms and conditions. Changes here are for this one document. Click **Edit saved footers** to change the saved ones.

Click **Save** when done.

> Tip: A cancelled quote or invoice can't be changed. See [Copy, cancel or reopen](/manual/copy-cancel-reopen).`
	},
	{
		slug: "record-a-payment",
		title: "Record a payment on an invoice",
		section: "Sales",
		summary: "Mark money received from a customer, in full or in part.",
		paths: ["/sales/"],
		keywords: [
			"receive payment",
			"customer paid",
			"partial payment",
			"check received",
			"mark paid",
			"payment received",
			"zelle",
			"ach",
			"deposit to"
		],
		body: `Use this when a customer pays an invoice.

1. Open the invoice.
2. In the **Next step** bar, click **Record payment**.
3. **Amount ($)** is filled in with what is still owed. Change it for a part payment.
4. Set **Date paid**.
5. In **How they paid**, pick Check, Credit card, Wire transfer, ACH, Cash or Zelle, or type your own.
6. Type the **Check # or reference**.
7. Pick the account in **Deposit to**.
8. Click **Save payment**.

The payment shows under **Payments** at the bottom. **Balance due** goes down. When it reaches zero, the status changes to **Invoice – paid**.

> Tip: To give money back, type a minus amount, like **-50**. For credits and refunds, you can also use [Refunds and credits](/manual/refunds-and-credits).

> Tip: Card payments made through a **Pay now** link are added for you. You do not need to record them.

> Tip: Paid for several invoices at once? Use **Collect payment** on the customer's page. See [Collect a payment from the customer page](/manual/collect-payment).

> Tip: Typed a payment by mistake? An admin can remove it with the trash can next to it under **Payments**.`
	},
	{
		slug: "email-or-print",
		title: "Email, print or save as PDF",
		section: "Sales",
		summary: "Send a quote or invoice to the customer with the PDF attached, or print it.",
		paths: ["/sales/"],
		keywords: [
			"send invoice",
			"email invoice",
			"email quote",
			"pdf",
			"print",
			"download",
			"attach",
			"cc",
			"send to customer"
		],
		body: `Use this to get a quote, invoice or RMA to your customer.

## Email it

1. Open the quote or invoice and click **Email customer**. It saves first, so the PDF matches the screen.
2. Check **To**. It comes from the email on the page. Add others in **Copy to (optional)**, separated by commas.
3. Leave **Send me a copy** ticked if you want one.
4. Read the **Subject** and **Message**. Change them if you like.
5. Click **Send email**.

The email goes from your company email with the PDF attached. Replies come back to you.

Want the file instead? Click **Download PDF** in the same window.

## Print it or save a PDF

1. Click **Print or save PDF** at the top.
2. Pick your printer, or pick **Save as PDF**. The file is named with the quote or invoice number.

> Tip: The PDF uses your logo and company details from Settings, the notes, and the footers you picked. See [Lines, discounts, tax and shipping](/manual/lines-discounts-tax).

> Tip: To add a card payment link or ask for a deposit in the same email, see [Pay now links and deposits](/manual/pay-now-and-deposits).`
	},
	{
		slug: "pay-now-and-deposits",
		title: "Pay now links and deposits",
		section: "Sales",
		summary: "Let customers pay an invoice by card online, and ask for a deposit.",
		paths: ["/sales/"],
		keywords: [
			"pay now",
			"card payment",
			"credit card link",
			"online payment",
			"deposit",
			"down payment",
			"prepayment",
			"payment link"
		],
		body: `Use this to get paid by card, or to ask for part of the money up front.

These show only once card payments are set up for your company.

## Add a Pay now link to the email

1. Open an invoice that still has money owed and click **Email customer**.
2. Tick **Add a "Pay now by card" link**.
3. Click **Send email**. The link is added at the end of your message.

## Copy the link by itself

Click **Copy Pay now link** at the top of the invoice. Paste it into a text message or your own email.

When the customer pays, the payment shows on the invoice by itself.

## Ask for a deposit

1. Click **Email customer** on the quote or invoice.
2. Tick **Ask for a deposit**.
3. Type the percent. It shows the dollar amount next to it. If the terms name a percent (like "50% deposit"), that is filled in.
4. Click **Send email**.

The PDF gets a **Deposit due now** line. If the Pay now link is ticked, it asks for the deposit amount only.

> Tip: A deposit paid by check or wire is not added by itself. Use **Record payment** when it arrives. See [Record a payment on an invoice](/manual/record-a-payment).`
	},
	{
		slug: "fulfill-an-order",
		title: "Mark an order fulfilled (take items out of stock)",
		section: "Sales",
		summary: "Take the items on an invoice out of stock when they ship, or put them back.",
		paths: ["/sales/"],
		keywords: [
			"fulfill",
			"ship",
			"shipped",
			"pick",
			"take stock",
			"remove from stock",
			"unfulfilled",
			"undo fulfilled",
			"inventory"
		],
		body: `Use this when the items on an invoice leave your shelves.

Until you do this, the items still count as in stock. The page shows **Unfulfilled**.

1. Open the invoice.
2. In the **Next step** bar, click **Mark fulfilled (take items out of stock)**.
3. Pick where to take the items from, or **Wherever it's stocked (biggest shelf first)**.
4. Click **Mark fulfilled**.

The page now shows **Fulfilled** and the date the items were taken out.

If there is not enough stock, the count goes below zero and shows in red, so someone can check it.

## Undo it

Shipped by mistake, or the order changed? Click **Undo fulfilled (put items back)**. The items go back into stock and the invoice is unfulfilled again.

> Tip: This button only shows when the invoice has stocked products. Services and typed lines don't change stock.

> Tip: Quotes and RMAs never change stock.

> Tip: Find invoices not shipped yet with the **Unfulfilled** button on the Invoice List. See [Search and filter quotes and invoices](/manual/search-sales).`
	},
	{
		slug: "sales-receipt",
		title: "Make a sales receipt (paid on the spot)",
		section: "Sales",
		summary: "Ring up a sale the customer pays for right away.",
		paths: ["/sales-receipt"],
		keywords: [
			"cash sale",
			"receipt",
			"paid now",
			"counter sale",
			"walk-in",
			"point of sale",
			"pos"
		],
		body: `Use this when a customer pays at the time of the sale, like a walk-in or a cash sale.

1. In the menu, click **Sales Receipt**. A page called **New sales receipt** opens.
2. Choose the **Customer**.
3. Add the items, the same as on an invoice.
4. Click **Save**.
5. The **Record payment** window opens by itself with the total filled in. Pick **How they paid**, add a reference if there is one, and click **Save payment**.

The sale is saved as an invoice that is already paid.

> Tip: If the customer takes the items with them, click **Mark fulfilled (take items out of stock)** so your stock is right. See [Mark an order fulfilled](/manual/fulfill-an-order).

> Tip: To give them a copy, click **Print or save PDF** or **Email customer**.`
	},
	{
		slug: "copy-cancel-reopen",
		title: "Copy, cancel or reopen a quote or invoice",
		section: "Sales",
		summary: "Start a new quote from an old one, cancel one, or bring a cancelled one back.",
		paths: ["/sales/"],
		keywords: [
			"duplicate",
			"copy",
			"repeat order",
			"cancel",
			"void",
			"delete invoice",
			"reopen",
			"completed",
			"close quote"
		],
		body: `Use this to reuse an old order, or to stop one.

## Copy

1. Open any quote or invoice.
2. Click **Copy** at the top.
3. A new quote opens, dated today, with the same customer and items. The old one is not changed.

## Cancel

1. In the **Next step** bar, click **Cancel this quote** (or **Cancel this invoice**).
2. The page is locked and marked **Cancelled**. It drops off the lists unless you tick **Show cancelled**.

## Reopen

1. Open the cancelled one. (On the Sales List, tick **Show cancelled** to find it.)
2. Click **Reopen as quote**. For a return, click **Reopen RMA**.

A quote that was closed by follow-ups comes back with today's date. Check the prices before you send it again.

## Mark as completed

When an invoice is paid and the job is done, click **Mark as completed** to close it out.

> Tip: A cancelled invoice comes back as a quote. Turn it into an invoice again when ready. See [Turn a quote into an invoice](/manual/quote-to-invoice).`
	},
	{
		slug: "returns-rma",
		title: "Returns (RMA)",
		section: "Sales",
		summary: "Make a return paper (RMA) for items a customer is sending back.",
		paths: ["/rma"],
		keywords: [
			"rma",
			"return",
			"returns",
			"send back",
			"warranty",
			"repair",
			"return merchandise authorization"
		],
		body: `Use this when a customer needs to send items back, for a repair or a return.

An RMA looks like a quote. It does not change money or stock. It is the paper you send the customer so you both know what is coming back.

## Start an RMA from an invoice

1. Open the customer's invoice.
2. Click **Start an RMA from this**.
3. A new RMA opens with the same customer and items. Remove the lines that are not coming back.
4. Click **Save**. It gets an RMA number.

## Start a blank RMA

1. In the Sales List, click the **RMAs** button, or open the RMAs page.
2. Click **New RMA**.
3. Choose the customer, add the items, and click **Save**.

## Send it

Click **Email customer** or **Print or save PDF**.

> Tip: To lower what the customer owes or pay them back for the return, use [Refunds and credits](/manual/refunds-and-credits).

> Tip: A customer's RMAs are also on their page, under the **RMAs** button.`
	},
	{
		slug: "search-sales",
		title: "Search and filter quotes and invoices",
		section: "Sales",
		summary: "Find any quote, invoice or RMA with the search box, customer box and buttons on the lists.",
		paths: [
			"/sales-list",
			"/invoices",
			"/sales-orders"
		],
		keywords: [
			"invoice list",
			"sales list",
			"find invoice",
			"filter",
			"unpaid",
			"past due",
			"unfulfilled",
			"uninvoiced",
			"sort",
			"customer filter",
			"clear search",
			"left list"
		],
		body: `Use this to find a quote, invoice or RMA fast.

## On the Sales List and Invoice List

1. Click a button at the top: **Everything**, **Invoices**, **Unfulfilled**, **Unpaid**, **Past due**, **Uninvoiced**, **Quotes** or **RMAs**.
2. Type in the search box: an order number, customer name or P.O. number.
3. To see one customer only, type their name in the **Customer:** box. It suggests names as you type.
4. Use the **Inventory** and **Payment** drop-downs to narrow it more.
5. Click a column name (like **Due date** or **Balance**) to sort by it. Click again to flip the order.

Under the boxes you see how many are shown, their total, and how much is still owed.

## Your search stays

When you open an invoice and come back, your search is still there. The list on the left of the invoice page uses the same search. Click **Clear search** to start over.

## The list on the left of an invoice

It has the same **Search** and **Customer:** boxes, plus **Inventory** and **Payment** drop-downs and the **Quotes**, **Invoices**, **RMAs** and **All** buttons. Click a line to open it.

> Tip: Cancelled ones are hidden. Tick **Show cancelled** to see them.

> Tip: Only the first 500 show. Search or filter to narrow it down.`
	},
	{
		slug: "quote-follow-ups",
		title: "Follow up on quotes",
		section: "Sales",
		summary: "Get reminded to follow up on open quotes, send the follow-up, and close old ones.",
		paths: ["/overview"],
		keywords: [
			"follow up",
			"followup",
			"reminder",
			"chase quote",
			"open quotes",
			"close quote",
			"stale quote",
			"automatic email"
		],
		body: `Use this so no quote is forgotten.

## Turn follow-ups on

1. Open **Settings** and pick **Features**.
2. Under **Quote follow-ups**, tick **Turn on daily follow-ups**.
3. Set the days: **1st follow-up after** (14), **2nd after** (30), and **Close the quote after** (45).
4. If you want, tick **Also email the customer automatically**. It sends a short, polite note with no PDF.

Every morning, quotes that are due show on **Overview** and are emailed to the office. Quotes past the last number of days are closed. Click **Run today's follow-ups now** to do it right away.

## Send a follow-up

1. Open **Overview** and look at **Quotes to follow up**.
2. Click **Email follow-up** next to a quote.
3. The email opens with a follow-up message and the quote PDF. Change the words if you like.
4. Click **Send email**. The quote now counts one follow-up.

## Close a quote

Click **Close quote** when the customer is not going ahead. You can bring it back later with **Reopen as quote**.

> Tip: Emailing an older quote from its own page also counts as a follow-up.

For unpaid invoices, see [Follow up on late payments](/manual/payment-follow-ups).`
	},
	{
		slug: "payment-follow-ups",
		title: "Follow up on late payments",
		section: "Sales",
		summary: "Send a polite reminder, with the invoice attached, to customers who are past due.",
		keywords: [
			"past due",
			"overdue",
			"late payment",
			"collections",
			"payment reminder",
			"dunning",
			"unpaid invoice",
			"chase payment"
		],
		body: `Use this when an invoice is past its due date and not fully paid.

## From the Invoice List

1. Open the **Invoice List** and click **Past due**.
2. Each invoice has a **Follow up** button in the **Payment follow-up** column.
3. Click **Follow up**. The invoice opens with the email ready.

## From an invoice

On any invoice that still has money owed, click **Follow up on payment** in the **Next step** bar.

## Send it

1. The subject says **Payment reminder** with the invoice number.
2. The message gives the amount owed and the due date, and asks for the status of the payment. Change any words you like.
3. The invoice PDF is attached.
4. Click **Send email**.

Each reminder is counted. The Invoice List shows how many were sent and the last date (for example **2× · last Oct 3**). The button on the invoice shows the last date too. The second reminder says "Following up again".

> Tip: To remind many customers at once, email statements instead. See [Customer statements](/manual/statements).

> Tip: Add a **Pay now** link so they can pay by card right away. See [Pay now links and deposits](/manual/pay-now-and-deposits).`
	},
	{
		slug: "statements",
		title: "Customer statements",
		section: "Sales",
		summary: "Print or email each customer a list of what they still owe.",
		paths: ["/statements"],
		keywords: [
			"statement",
			"account statement",
			"aging",
			"open invoices",
			"what they owe",
			"reminder",
			"balance due",
			"past due"
		],
		body: `Use this to show customers every invoice they still owe, and how late each one is.

1. In the menu, click **Statements**.
2. Set the **Statement date**. Only customers who owe money on that date are listed.
3. Untick customers you don't want, or use **Tick all** and **Clear**. Use **Search customers** to find one.
4. To send only to late payers, tick **Only customers with past-due invoices**.
5. Change the **Note at the bottom** if you like.

## Print

Click **Print** (it shows how many statements). Each customer gets their own page.

## Email

1. Click **Email…**.
2. Pick **Statement** or **Payment reminder**. Each has its own words.
3. Change the **Subject** and **Message**. Write {name} and {total} to fill in each customer's name and amount.
4. Click **Send**. Each customer gets their own statement as a PDF.

> Tip: Customers without an email address are left out and marked **no email** in the list. Add it on their customer page.

> Tip: For one invoice at a time, see [Follow up on late payments](/manual/payment-follow-ups).`
	},
	{
		slug: "refunds-and-credits",
		title: "Refunds and credits",
		section: "Sales",
		summary: "Lower what a customer owes on an invoice, or give money back.",
		paths: ["/refunds"],
		keywords: [
			"refund",
			"credit",
			"credit memo",
			"money back",
			"return",
			"discount after",
			"write off",
			"store credit"
		],
		body: `Use this when a customer should pay less, or should get money back.

## Give a credit on an invoice

They owe less: a discount after the fact, or a returned item they have not paid for yet.

1. Open **Refunds & Credits**.
2. Under **Give a credit on an invoice**, pick the **Customer**, then the **Invoice**.
3. Type the **Credit amount** and the **Date**.
4. In **Why (shows on the invoice)**, write a short reason, like "Returned 2 modules".
5. Click **Put the credit on the invoice**.

The credit can't be more than what is owed on that invoice.

## Give money back

For something they already paid.

1. Under **Give money back**, pick the **Customer** (or type a name).
2. Type the **Amount** and **Date**.
3. In **Paid from**, choose the account the money comes out of. In **How**, pick how you pay it.
4. Write **Why**. For a check, tick **Print the check** if you want it printed.
5. Click **Save the refund**. A check to print waits in **Print Checks**.

Both show under **Recent credits and refunds**. They are booked to Sales Returns and Credits, so your income shows the real number.

> Tip: For the paper the customer needs to send items back, see [Returns (RMA)](/manual/returns-rma).`
	},
	{
		slug: "add-a-customer",
		title: "Add or change a customer",
		section: "Customers",
		summary: "Add a new customer, find one, and set their terms, tax, discount and price list.",
		paths: ["/customers/"],
		keywords: [
			"new customer",
			"add client",
			"client",
			"edit customer",
			"customer list",
			"terms",
			"tax exempt",
			"resale",
			"price list",
			"inactive"
		],
		body: `Use this to add a customer or change their details.

## Add a customer

1. In the menu, click **Customers**.
2. Click **Add customer**, type the **Name**, and click **Add customer**.
3. The customer's page opens. Click the **Customer info** tab.
4. Fill in the contact person, phone, email and address. Use **Bill to** and **Ship to** only if they are different.
5. Set **Payment terms**, **Price list**, **Sales tax**, **Discount (%)** and **Sales rep**. These fill in by themselves on every new quote and invoice.
6. For a tax-exempt customer, type their **Tax exempt / resale number**.
7. Click **Save customer**.

## Find a customer

Type in **Search name, contact, phone or email** on the Customers page. Click a name to open it.

## Stop using a customer

On **Customer info**, turn off **Active** and click **Save customer**. They are hidden from the list but their history stays. Turn on **Show inactive** to see them again.

> Tip: Changed a phone or address while making an invoice? Click **Save changes to the customer** on the invoice instead of typing it twice.

See also [The customer page](/manual/customer-page).`
	},
	{
		slug: "customer-page",
		title: "The customer page and history",
		section: "Customers",
		summary: "See a customer's balance, every quote, invoice and RMA, and their payments.",
		paths: ["/customers/"],
		keywords: [
			"customer history",
			"order history",
			"still owed",
			"balance",
			"payment history",
			"sold all time",
			"credit",
			"customer account"
		],
		body: `Use this to see everything about one customer.

At the top you see **Balance** (what they owe), **Credit** (money they have overpaid) and **Sold all time**.

## Buttons

- **New quote** and **New invoice** start one with this customer filled in.
- **Collect payment** records money they paid. See [Collect a payment from the customer page](/manual/collect-payment).

## Tabs

**Quotes, invoices & RMAs** is their history. Use the buttons to show:

- **All**
- **Quotes**
- **Invoices**
- **RMAs**
- **Still owed**: only invoices that are unpaid or part paid.

Type in **Search order # or PO #** to find one. Click a line to open it.

**Customer info** has their details. See [Add or change a customer](/manual/add-a-customer).

**Payment history** lists every payment, with the invoice number. Click the number to open it.

> Tip: When you open an invoice and come back, the page stays on the same tab and the same filter.

> Tip: The list on the left lets you jump from one customer to the next. Type in **Search** to narrow it.

> Tip: **Customer list** at the top takes you back to all customers.`
	},
	{
		slug: "collect-payment",
		title: "Collect a payment from the customer page",
		section: "Customers",
		summary: "Record a customer's payment when you start from their page instead of the invoice.",
		paths: ["/customers/"],
		keywords: [
			"receive payment",
			"customer paid",
			"collect",
			"apply payment",
			"check from customer",
			"pay invoice"
		],
		body: `Use this when a customer pays and you don't have the invoice open.

1. Open **Customers** and click the customer.
2. Click **Collect payment**. (It is grey when they owe nothing.)
3. Under **Invoice**, pick which invoice this payment is for. Each one shows what is still owed.
4. **Amount ($)** fills in with what is owed on that invoice. Change it for a part payment.
5. Set **Date paid**, **How they paid**, and the **Check # or reference**.
6. Click **Save payment**.

The invoice's balance goes down, and the payment shows in **Payment history**.

> Tip: One check for several invoices? Save one payment for each invoice, with the same check number.

> Tip: To choose which bank account the money goes into, record it from the invoice with **Record payment**. See [Record a payment on an invoice](/manual/record-a-payment).`
	},
	{
		slug: "support-tickets",
		title: "Support tickets",
		section: "Customers",
		summary: "Keep track of customer requests, reply to them, and make a quote or invoice from a ticket.",
		paths: ["/tickets", "/tickets/"],
		keywords: [
			"ticket",
			"support",
			"help desk",
			"service request",
			"repair",
			"customer request",
			"reply",
			"internal note",
			"support page"
		],
		body: `Use this to handle requests from customers in one place. Tickets show only when support is turned on for your company.

## See your tickets

Open **Tickets**. Use **Open**, **Waiting on customer**, **Done** and **All**. Tick **Only mine** for tickets given to you. Search by ticket number, customer or subject.

## Open a ticket for a customer

1. Click **New ticket**.
2. Pick the **Customer**, fill in how to reach them, **How they reached us**, the **Subject** and **What they told us**.
3. Click **Open the ticket**.

## Reply

1. Open the ticket.
2. Pick **Reply to the customer**, or **Internal note** for something only your team sees.
3. Write it. Use **Saved replies…** and **Attach** if you need them.
4. In **then mark it**, pick what the ticket becomes next.
5. Click **Send the reply** (or **Add the note**).

## Quote or invoice from a ticket

Click **Make a quote** or **Make an invoice** on the right. The customer sees it on their ticket. The customer must be added first.

> Tip: Customers can open tickets themselves from your support page. Click **Copy link** at the top of Tickets and put it on your website.

> Tip: Click **Copy the customer's link** to send them their ticket. They can read and reply there.`
	}
];
var articles$2 = [
	{
		slug: "make-a-purchase-order",
		title: "Make a purchase order",
		section: "Purchasing",
		summary: "Order items from a vendor, then print or email the order to them.",
		paths: ["/po/"],
		keywords: [
			"PO",
			"order from supplier",
			"reorder",
			"buy",
			"supplier",
			"new purchase order"
		],
		body: `Use this when you want to buy items from a vendor.

1. Go to **Purchase Orders** in the menu and press **New purchase order**.
2. In **Vendor**, press **Choose a vendor** and type the name. The contact, phone, address and payment terms fill in for you.
3. Pick **Location (where it will arrive)**. Fill in **Vendor order #**, **Carrier** and **Due date** if you have them.
4. In **Ship to**, press **Use our address** to fill in your company address.
5. On each line, press **Choose a product (or just type a description)** and pick the item. If you saved a price and code for this vendor, they fill in by themselves.
6. Type the **Qty**. Change **Unit price** or **Disc. %** if needed. Press **Add line** for more items.
7. Pick a tax (or **No tax**) and type any **Freight / other costs**.
8. Press **Save**. The order gets its number.
9. Press **Email vendor** to send it as a PDF, or **Print or save PDF**.

> Tip: Can't find the product? In the product box press **Add new product** to make it right there.

> Tip: **Copy** makes a new purchase order with the same vendor and lines. Handy for repeat orders.

> Tip: The list on the left shows your other purchase orders. Its search and **Vendor:** box are the same as on the Purchase Order List, so your search stays as you click from order to order. Press **Hide the list** (the small button next to its search) to make more room.

Next: [receive the items](/manual/receive-purchase-order) and [pay the vendor](/manual/pay-purchase-order).`
	},
	{
		slug: "purchase-order-list",
		title: "Find a purchase order",
		section: "Purchasing",
		summary: "Search your purchase orders and see what hasn't arrived or isn't paid.",
		paths: ["/purchase-orders"],
		keywords: [
			"PO list",
			"open orders",
			"unreceived",
			"unpaid",
			"owed to vendor",
			"filter"
		],
		body: `Use this to find an order or see what's still open.

1. Go to **Purchase Orders** in the menu.
2. Press a quick filter at the top: **All orders**, **Unreceived** (items not in stock yet), **Unpaid** (unpaid or partly paid) or **Recent (30 days)**.
3. Type in the search box. It looks at the order #, vendor name and vendor order #.
4. To see one vendor only, type in the **Vendor:** box (it suggests names as you type).
5. Use the three drop-downs to narrow it more: inventory (**Not received** / **Received**), payment (**Unpaid**, **Partial**, **Paid** and more) and date (**Last 30 days**, **Last 90 days**, **Last 12 months**).
6. Click a row to open the order.

Under the filters you see how many orders are shown and how much **we still owe** on them.

> Tip: Your search and filters stay when you open an order and come back, until you close the browser tab.

> Tip: Cancelled orders are hidden. Tick **Show cancelled** to see them.

> Tip: Click a column title (Order #, Order date, Vendor, Total, Balance, Due date) to sort by it. Click again to flip the order.

See also: [Make a purchase order](/manual/make-a-purchase-order).`
	},
	{
		slug: "receive-purchase-order",
		title: "Receive ordered items into stock",
		section: "Purchasing",
		summary: "Add the items from a purchase order to your stock when they arrive.",
		paths: ["/po/"],
		keywords: [
			"receive",
			"receiving",
			"delivery arrived",
			"check in",
			"stock in",
			"Receive Stock"
		],
		body: `Use this when the boxes from a purchase order arrive.

1. Open the purchase order (from **Purchase Orders**).
2. Check the lines match what came. Fix the quantities if needed.
3. In the **Next step:** bar, press **Receive items into stock**.
4. Choose the place in **Put items in…**. It starts on the order's location if you set one.
5. Press **Receive into stock**.

Every stocked item on the order is added to that place. The order now shows **Received**, with the date it came in.

> Tip: This happens once for the whole order. Change the quantities before you press the button.

> Tip: The button only shows when the order has stocked products on it. Services and non-stocked items don't go into stock.

> Tip: Items are added to the place with no shelf. Use [Move to Shelves](/manual/move-to-shelves) to put them on the right shelf.

> Tip: A received order shows up in [Pay Bills](/manual/pay-bills) if you still owe on it.`
	},
	{
		slug: "pay-purchase-order",
		title: "Pay a vendor for a purchase order",
		section: "Purchasing",
		summary: "Record money you paid a vendor on one purchase order.",
		paths: ["/po/"],
		keywords: [
			"pay vendor",
			"payment",
			"deposit to vendor",
			"wire",
			"balance",
			"paid"
		],
		body: `Use this when you paid a vendor for one order (all or part).

1. Open the purchase order.
2. In the **Next step:** bar, press **Pay vendor**.
3. Type the **Amount ($)**. It starts at what you still owe.
4. Set **Date paid**.
5. In **How we paid**, pick or type how (Wire transfer, Check, Credit card, ACH, PayPal…).
6. Add a **Reference** if you have one (check # or wire number).
7. Choose **Paid from**: the bank account or card the money came from.
8. Press **Save payment**.

The payment shows under **Payments to vendor**. **Paid** and **Balance** update, and the order shows **Partial** or **Paid**.

> Tip: When an order is both received and paid, press **Mark as completed** to close it.

> Tip: Paying many vendors at once? Use [Pay Bills](/manual/pay-bills) instead. It makes one check per vendor.

> Tip: Typed a payment wrong? An admin can remove it with the trash button next to it.`
	},
	{
		slug: "cancel-or-copy-purchase-order",
		title: "Cancel, reopen or copy a purchase order",
		section: "Purchasing",
		summary: "Stop an order you no longer need, bring it back, or reuse it.",
		keywords: [
			"cancel PO",
			"void PO",
			"reopen",
			"duplicate",
			"repeat order"
		],
		body: `Use this when an order changes after you made it.

## Cancel an order
1. Open the purchase order.
2. In the **Next step:** bar, press **Cancel this order**.

The order is locked and hidden from the Purchase Order List. To see it, tick **Show cancelled** on the list.

## Bring it back
1. Open the cancelled order.
2. Press **Reopen**.

## Order the same things again
1. Open an old order.
2. Press **Copy**.

You get a new order with today's date, the same vendor and lines, nothing paid and nothing received. Change what you need and press **Save**.

> Tip: Cancel doesn't delete anything. You can always reopen it.

See also: [Find a purchase order](/manual/purchase-order-list).`
	},
	{
		slug: "order-from-sales-order",
		title: "Order an invoice's items from vendors",
		section: "Purchasing",
		summary: "Turn the items on a customer's invoice or order into purchase orders, one per vendor.",
		keywords: [
			"create PO",
			"drop ship",
			"order for customer",
			"special order",
			"back order"
		],
		body: `Use this when a customer orders something you need to buy first.

1. Open the customer's invoice or order.
2. Press **Order from vendor**.
3. Each item starts on the vendor that sells it cheapest. You see how many are in stock under each item.
4. Untick items you don't need to buy. Labor and other services start unticked.
5. Change the quantity or pick another vendor with **Choose vendor**.
6. Press **Make purchase order** (or **Make 2 purchase orders** and so on, one for each vendor).

If only one order is made, it opens. Each new purchase order shows **For** and the invoice number at the top. Click it to go back to the invoice.

> Tip: Every ticked item needs a vendor. The box at the bottom tells you how many still need one.

> Tip: The vendor you pick is remembered for that product, so next time it's chosen for you.

See also: [Make a purchase order](/manual/make-a-purchase-order).`
	},
	{
		slug: "add-a-vendor",
		title: "Add or find a vendor",
		section: "Purchasing",
		summary: "Keep a list of the companies you buy from.",
		paths: ["/vendors"],
		keywords: [
			"supplier",
			"vendor list",
			"new vendor",
			"inactive vendor",
			"contractor"
		],
		body: `Use this to add a company you buy from, or to look one up.

## Add a vendor
1. Go to **Vendors** in the menu.
2. Press **Add vendor**.
3. Type the **Name** and press **Add vendor**.
4. The vendor's page opens. Press the **Details** tab and fill in the contact person, phone, email, address and payment terms.
5. Press **Save vendor**.

## Find a vendor
1. Type in the search box. It looks at the name, contact, phone and email.
2. Click the vendor to open their page.

> Tip: Don't delete vendors you stopped using. On **Details**, turn off **Active** and save. They leave the lists, but their old orders stay.

> Tip: To see inactive vendors, turn on **Show inactive**.

See also: [A vendor's page](/manual/vendor-page).`
	},
	{
		slug: "vendor-page",
		title: "See a vendor's orders and what you owe",
		section: "Purchasing",
		summary: "A vendor's page: their purchase orders, the products you buy from them and their details.",
		paths: ["/vendors/"],
		keywords: [
			"vendor history",
			"supplier",
			"owed",
			"not received",
			"vendor products"
		],
		body: `Use this to see everything about one vendor.

1. Go to **Vendors** and click the vendor.
2. Press **New purchase order** to order from them. The vendor is filled in for you.

The page has three tabs:

- **Purchase orders**: every order from this vendor. Press **All**, **Not received yet** or **Still owed** to filter. Search by PO # or vendor order #. Click a PO # to open it.
- **Products**: items you buy from them, with their code and their price. Click one to open the product.
- **Details**: name, contact, address, payment terms and notes. Press **Save vendor** after changes. Below it is the **Year-end 1099** box.

> Tip: The total at the bottom of the Purchase orders tab adds up the orders shown (cancelled ones don't count).

> Tip: Products show up here after you add the vendor on a product's page. See [Set a product's cost, prices and vendors](/manual/product-prices-and-vendors).

> Tip: The list on the left lets you jump to another vendor.`
	},
	{
		slug: "enter-a-bill",
		title: "Enter a bill to pay later",
		section: "Purchasing",
		summary: "Record a bill you owe, like rent, utilities or a subcontractor.",
		paths: ["/bills/"],
		keywords: [
			"enter bills",
			"accounts payable",
			"AP",
			"invoice from vendor",
			"rent",
			"utility",
			"void bill"
		],
		body: `Use this when you get a bill you'll pay later. For things you buy for stock, use a [purchase order](/manual/make-a-purchase-order) instead.

1. Go to **Bills & Expenses** and press **New bill**.
2. In **From (vendor)**, press **Choose a vendor**. If they aren't a vendor, type the name in **…or type a name (e.g. landlord)**.
3. Type the **Bill # (optional)**, **Bill date** and **Due date**.
4. Add a **Memo** if you like.
5. Under **What it was for**, pick an **Account** (for example Rent), type a **Description** and the amount.
6. Press **Add line** to split the bill across more accounts.
7. Press **Save bill**.

## Pay it
Open the bill, press **Record a payment**, fill in the amount, date, **Paid from** and how you paid, then press **Save payment**. Or pay many at once in [Pay Bills](/manual/pay-bills).

> Tip: Every line needs an account. That's how the books know what the money was for.

> Tip: Wrong bill? Press **Void this bill**. It stays on file but no longer counts in the books. **Undo void** brings it back.`
	},
	{
		slug: "expense-paid-now",
		title: "Record an expense you already paid",
		section: "Purchasing",
		summary: "Enter something you paid on the spot, like gas or office supplies.",
		keywords: [
			"expense paid now",
			"receipt",
			"cash purchase",
			"card purchase",
			"spent"
		],
		body: `Use this when the money is already gone and there's no bill to pay later.

1. Go to **Bills & Expenses**.
2. Press **New expense (already paid)**.
3. In **From (vendor)**, choose the vendor or type a name (for example the store).
4. Type the **Receipt # (optional)** and the **Date paid**.
5. In **Paid from**, pick the bank or credit card you used.
6. In **How paid (optional)**, type the check #, card or ACH.
7. Under **What it was for**, pick the **Account** (for example Fuel), add a **Description** and the amount. Press **Add line** for more.
8. Press **Save expense**.

The expense is saved with its payment, so there is nothing left to pay. Press **All** on the Bills & Expenses list to see it.

> Tip: Have a paper receipt? The **Scan** button at the top of the app can photograph it for the Receipts page.

See also: [Enter a bill to pay later](/manual/enter-a-bill).`
	},
	{
		slug: "bills-list",
		title: "See the bills you owe",
		section: "Purchasing",
		summary: "The Bills & Expenses list: what's due, what's late and what's paid.",
		paths: ["/bills"],
		keywords: [
			"unpaid bills",
			"accounts payable",
			"due",
			"late bills",
			"expenses list"
		],
		body: `Use this to see what you owe on bills.

1. Go to **Bills & Expenses** in the menu.
2. **To pay** shows open bills only. Press **All** to see paid and void ones too.
3. Type in the search box to find a vendor, bill number or memo.
4. Click a row to open the bill.

Next to the search you see the total: **We owe** this much on bills.

Each row shows the date, vendor, bill #, memo, due date, status (**To pay**, **Paid** or **Void**), the total and what's **Still owed**.

> Tip: A due date in red means the bill is late.

> Tip: Purchase orders are not on this list. They are paid from their own page or from [Pay Bills](/manual/pay-bills).

See also: [Enter a bill](/manual/enter-a-bill), [Record an expense you already paid](/manual/expense-paid-now).`
	},
	{
		slug: "pay-bills",
		title: "Pay many bills at once",
		section: "Purchasing",
		summary: "Tick bills and purchase orders to pay. One check or payment is made per vendor.",
		paths: ["/pay-bills"],
		keywords: [
			"pay bills",
			"check run",
			"vendor credit",
			"print checks",
			"ACH",
			"bill payment"
		],
		body: `Use this to pay several bills and purchase orders in one go.

1. Go to **Pay Bills** in the menu.
2. Choose **Pay from** (bank or card) and **How** (Check, Online / ACH, Card, Cash, Other).
3. Set the **Payment date**.
4. For checks: leave **Print the checks** ticked to print them next. Untick it if you write them by hand, then type the **First check number**.
5. Tick each bill or purchase order to pay. To pay part, change the amount on its line.
6. Or press **Tick all**. **Clear** unticks everything.
7. Check the total at the bottom, then press **Pay and go print checks** (or **Pay now**).

One payment is made for each vendor, covering all of their items you ticked.

> Tip: Tick **Only what's due by the payment date** to hide bills that aren't due yet. Late ones show their date in red.

> Tip: Vendor credits show a green **Credit** tag. Tick one with that vendor's bills and it comes off their payment. The credit can't be more than the bills you tick.

> Tip: Purchase orders only show here once their items are received. See [Why isn't my purchase order in Pay Bills?](/manual/po-not-in-pay-bills)`
	},
	{
		slug: "pay-sales-tax",
		title: "Pay sales tax to the state",
		section: "Purchasing",
		summary: "See how much sales tax you owe and record the payment you sent.",
		paths: ["/sales-tax"],
		keywords: [
			"sales tax",
			"tax return",
			"department of revenue",
			"sales tax payable"
		],
		body: `Use this after you file your sales tax return on the state's website.

1. Go to **Pay Sales Tax** in the menu.
2. Look at **You owe the state now**. Click the amount to see the transactions behind it.
3. The table shows each month's sales and tax collected, to help you fill in the return.
4. File and pay on the state's website.
5. Under **Record a sales tax payment**, fill in **Paid to** (for example Illinois Department of Revenue), **Amount**, **Date paid**, **Paid from**, **How** and **For which period** (for example October 2026).
6. Press **Save the payment**.

The payment shows under **Payments made**, and the amount you owe goes down.

> Tip: If you see a yellow note that the books haven't started, the amount owed shows $0. Set the books start date in Settings → Accounting.`
	},
	{
		slug: "make-1099-forms",
		title: "Make 1099 forms for vendors",
		section: "Purchasing",
		summary: "Mark which vendors get a 1099, then print their copies and download the e-file list.",
		paths: ["/forms-1099"],
		keywords: [
			"1099",
			"1099-NEC",
			"W-9",
			"contractor",
			"tax ID",
			"EIN",
			"year-end"
		],
		body: `Use this at year-end for contractors and others you paid for services.

## Mark the vendor first
1. Open the vendor (from **Vendors**) and press the **Details** tab.
2. In **Year-end 1099**, tick **This vendor gets a 1099**.
3. Type their **Tax ID (EIN or SSN, from their W-9)**.
4. Press **Save 1099 details**.

## Make the forms
1. Go to **1099 Forms** in the menu.
2. Pick the year.
3. Fix any yellow notes: a missing Tax ID or address for you or a vendor. Click the vendor's name to open them.
4. Press **Print vendor copies** and mail or email one to each vendor by January 31.
5. Press **Download the e-file list** and give it to your accountant or use it to e-file with the IRS.

> Tip: Only vendors you marked and paid enough show up. Card payments don't count.

> Tip: The IRS copy can't be a plain-paper printout. It must be e-filed or on the official red form.

> Tip: Not sure if a vendor needs a 1099? Ask your accountant.`
	},
	{
		slug: "technician-pay",
		title: "Track technician pay",
		section: "Purchasing",
		summary: "See what technicians asked to be paid, what was paid, and yearly totals for taxes.",
		paths: ["/tech-pay"],
		keywords: [
			"technician",
			"installer",
			"fee",
			"contractor pay",
			"job report"
		],
		body: `Use this to see what you owe your technicians for jobs.

1. Go to **Technician Pay** in the menu.
2. **Waiting to be paid** shows the total technicians asked for and how many requests.
3. **Paid in** shows what you paid in the year you pick.
4. Press **Asked to be paid**, **Paid** or **All** to filter the list.
5. Click a ticket number to open that job.
6. To pay someone, press **Pay a technician on the website**.

At tax time, pick the year and press **Download (year) totals for taxes**. You get a file with each technician's total and every payment. The **Paid per technician** box shows the same totals on screen.

> Tip: Technicians ask for their fee on their job reports. A new request shows here as **Asked to be paid**.

See also: [Make 1099 forms](/manual/make-1099-forms).`
	},
	{
		slug: "product-list",
		title: "Find a product or add a new one",
		section: "Inventory",
		summary: "Search your products, see what's running low, and add new ones.",
		paths: ["/products"],
		keywords: [
			"items",
			"SKU",
			"part",
			"low stock",
			"reorder",
			"new item",
			"barcode search"
		],
		body: `Use this to find a product or add a new one.

## Find a product
1. Go to **Product List** in the menu.
2. Type in the search box. It looks at the name, description and barcode.
3. Use the drop-down to show **Active products**, **Running low**, **Below zero (check count)** or **All, incl. inactive**.
4. Pick a category to narrow it down.
5. Click a product to open it.

## Add a product
1. Press **New product**.
2. Type the **Item name / code**.
3. Pick the **Type**: **Stocked product (we keep count)**, **Non-stocked product** or **Service (labor, shipping…)**.
4. Press **Create product**. Its page opens so you can add the rest.

> Tip: To put many products in one category, tick them, press **Put in a category**, pick it and press **Save category**.

> Tip: A warning sign next to the stock number means it's at or under the "Warn me" amount you set on the product.

See also: [A product's page](/manual/product-page).`
	},
	{
		slug: "product-page",
		title: "Edit a product",
		section: "Inventory",
		summary: "Change a product's name, barcode, category, reorder level and usual place.",
		paths: ["/products/"],
		keywords: [
			"product details",
			"item",
			"barcode",
			"reorder point",
			"shelf",
			"inactive product",
			"copy product"
		],
		body: `Use this to change what you know about a product.

1. Open the product from **Product List**.
2. On the **Details** tab, change the **Name**, **Barcode**, **Description**, **Category** or **Unit (e.g. ea, box)**.
3. Set **Warn me when stock falls to** (your low-stock level) and the **Usual reorder amount**.
4. Set the **Usual place** and **Usual shelf**, and any **Notes**.
5. Press **Save product**.

At the top you see **In stock**, **Price** and **Cost**.

Other buttons at the top:
- **Quote this item** starts a quote with this product.
- **Order more from vendor** starts a purchase order with this product (and its vendor, if you added one).
- **Copy product** makes a copy. Change the name and save.

Other tabs: **Movement history** (every change to its stock), **Order history** (sales and purchase orders it was on) and, with work orders on, **Made from**.

> Tip: To hide a product you no longer sell, turn off **Active (show in lists)** and save.

See also: [Add, take out, count or move stock](/manual/product-stock-buttons), [Set cost, prices and vendors](/manual/product-prices-and-vendors).`
	},
	{
		slug: "product-stock-buttons",
		title: "Add, take out, count or move one product",
		section: "Inventory",
		summary: "Quick stock changes for a single product from its page.",
		paths: ["/products/"],
		keywords: [
			"add stock",
			"remove stock",
			"damaged",
			"lost",
			"quick count",
			"move stock",
			"write off"
		],
		body: `Use this for a quick change to one stocked product.

1. Open the product from **Product List**.
2. Press one of the buttons under the top: **Add stock** (put more in a place), **Take out stock** (damaged, used or lost), **Count stock** (type how many you actually see) or **Move stock** (from one place to another).
3. Choose the **Place** (for Move: **From** and **To**). Type a **Shelf or spot (optional)** if you use shelves.
4. Type **How many?** (for Count: **How many do you see?**).
5. Add a **Note (optional)**, like "damaged in shipping".
6. Press the button at the bottom (**Add to stock**, **Take out of stock**, **Save count** or **Move stock**).

The change shows on the **Movement history** tab.

> Tip: The **Where it is** box on the Details tab shows each place and shelf, and how many are there.

> Tip: Counting many items at once? Use a [Count Sheet](/manual/count-sheet) instead.`
	},
	{
		slug: "product-prices-and-vendors",
		title: "Set a product's cost, prices and vendors",
		section: "Inventory",
		summary: "Change cost and price-list prices, and save which vendors sell it and for how much.",
		paths: ["/products/"],
		keywords: [
			"price",
			"cost",
			"markup",
			"price list",
			"vendor code",
			"supplier price"
		],
		body: `Use this to set what a product costs you and what you sell it for.

## Cost and prices
1. Open the product and stay on the **Details** tab.
2. In **Cost and prices**, type the **Cost** and the prices. The **Markup** shows next to each.
3. Press **Save prices**.

Leave a price list empty to use the normal price for those customers.

## Vendors
1. In the **Vendors** box, press **Add a vendor** and pick one.
2. Type **Their code** (the vendor's product number) and **Their price**.
3. Press the trash button to remove a vendor.

> Tip: When you put this product on a purchase order for that vendor, their code and price fill in by themselves.

> Tip: The vendor also shows this product on its **Products** tab.

See also: [Make a purchase order](/manual/make-a-purchase-order).`
	},
	{
		slug: "current-stock",
		title: "See what's in stock and where",
		section: "Inventory",
		summary: "Current Stock: every product, place and shelf with its quantity and value.",
		paths: ["/stock"],
		keywords: [
			"on hand",
			"inventory value",
			"stock list",
			"where is it",
			"shelf"
		],
		body: `Use this to see what you have and where it is.

1. Go to **Current Stock** in the menu.
2. At the top you see **Items shown**, **Value at cost** and **Spots with stock**.
3. Type in the search box to find a product, place or shelf.
4. Pick a place to see only that place.
5. Pick a shelf filter. **No shelf yet** shows items that still need a shelf.
6. Click a row to open the product.

## Move many spots to a shelf
1. Tick the rows you want to move.
2. Press **Move selected to a shelf**.
3. Choose the place and shelf in **Move to**.
4. Press **Move** (it shows how many items).

Everything in the ticked spots moves.

> Tip: A red number means the count is below zero. See [Why is stock below zero?](/manual/stock-below-zero)

> Tip: Only the first 500 rows show. Search or pick a place to narrow it down.`
	},
	{
		slug: "count-sheet",
		title: "Count your stock",
		section: "Inventory",
		summary: "Use a Count Sheet to check your shelves and fix the numbers in one go.",
		paths: ["/count"],
		keywords: [
			"stock take",
			"stocktake",
			"inventory count",
			"cycle count",
			"physical count",
			"audit"
		],
		body: `Use this to check that the numbers match what's on your shelves.

1. Go to **Count Sheet** in the menu.
2. Press **New count sheet**.
3. Type your name in **Counted by**.
4. Choose a place in **Add every item that is in one place**, then press **Add items by location**. Everything in stock there is added, shelf by shelf.
5. Press **Add line** to add an item that isn't on the list.
6. Press **Save**, then **Print** to count on paper if you like.
7. Count the items. Type each number in **Counted qty**. **Difference** shows how far off it is from **System qty**.
8. Press **Complete and fix stock**.

The stock numbers change to what you counted.

> Tip: You can save and come back later. Nothing changes in stock until you press **Complete and fix stock**.

> Tip: Search old count sheets by number or remarks on the Count Sheet page.

See also: [Open, finish or cancel a stock document](/manual/stock-documents).`
	},
	{
		slug: "adjust-stock",
		title: "Fix stock numbers",
		section: "Inventory",
		summary: "Use Adjust Stock to set new quantities for items in a place.",
		paths: ["/adjust"],
		keywords: [
			"adjustment",
			"correct stock",
			"write off",
			"shrinkage",
			"damaged",
			"fix quantity"
		],
		body: `Use this when you know a number is wrong and want to set the right one.

1. Go to **Adjust Stock** in the menu.
2. Press **New stock adjustment**.
3. Check the **Date**.
4. On each line, press **Choose a product** and pick the item.
5. Pick the **Location** and **Shelf**. **Old qty** shows what the system has now.
6. Type the right number in **New qty**. **Difference** shows the change.
7. Press **Add line** for more items.
8. Write why in **Remarks** (for example "water damage").
9. Press **Save and complete**.

The stock is set to the new numbers.

> Tip: For one product, the **Count stock** button on its page is faster. See [Add, take out, count or move one product](/manual/product-stock-buttons).

> Tip: Counting a whole room? Use a [Count Sheet](/manual/count-sheet).`
	},
	{
		slug: "transfer-stock",
		title: "Move stock between places",
		section: "Inventory",
		summary: "Use Transfer Stock to move many items from one place or shelf to another.",
		paths: ["/transfer"],
		keywords: [
			"transfer",
			"move",
			"warehouse to van",
			"relocate",
			"stock transfer"
		],
		body: `Use this to move items between places, like from the warehouse to a van.

1. Go to **Transfer Stock** in the menu.
2. Press **New stock transfer**.
3. To move everything from one place, choose it in **Add every item that is in one place** and press **Add items by location**.
4. Or add items one by one: press **Add line**, then **Choose a product**.
5. On each line fill in **Quantity**, **From location**, **From shelf**, **To location** and **To shelf**.
6. Add **Remarks** if you like.
7. Press **Save and complete**.

The items leave the "from" place and arrive at the "to" place.

> Tip: Putting things on shelves in the same room? [Move to Shelves](/manual/move-to-shelves) is quicker with a scanner.

> Tip: Only moving one product? Use **Move stock** on its page.`
	},
	{
		slug: "stock-documents",
		title: "Open, finish or cancel a stock document",
		section: "Inventory",
		summary: "How count sheets, adjustments and transfers are saved, completed, printed or cancelled.",
		paths: ["/stock-doc/"],
		keywords: [
			"stock document",
			"open count",
			"unfinished",
			"print count sheet",
			"cancel adjustment"
		],
		body: `Count sheets, stock adjustments and stock transfers all work the same way.

1. Open the list from the menu: **Count Sheet**, **Adjust Stock** or **Transfer Stock**.
2. Click a row to open it. The **Status** column shows **Open**, **Completed** or **Cancelled**.
3. While it's open you can change lines and press **Save**. Nothing changes in stock yet.
4. Press **Print** for a paper copy.
5. When it's right, press **Save and complete** (on a count sheet: **Complete and fix stock**). Now the stock changes.
6. Don't need it? Press **Cancel**.

After it's completed, the document is locked. The **Number** is given when you first save.

> Tip: The list on the left shows your other documents of the same kind, so you can click between them.

> Tip: Every change shows in [Movement History](/manual/movement-history).

See also: [Count your stock](/manual/count-sheet), [Fix stock numbers](/manual/adjust-stock), [Move stock between places](/manual/transfer-stock).`
	},
	{
		slug: "movement-history",
		title: "See every stock change",
		section: "Inventory",
		summary: "Movement History lists every time stock went in, out or moved.",
		paths: ["/movements"],
		keywords: [
			"history",
			"audit trail",
			"who changed stock",
			"stock log",
			"movements"
		],
		body: `Use this to find out why a number changed.

1. Go to **Movement History** in the menu. Newest changes are first.
2. Type in the search box to find an item, order number or shelf.
3. Pick a type to see only that kind of change, like **Sales order picking**, **Purchase order receive**, **Returns / restock**, **Stock adjustment**, **Count sheet**, **Stock transfer** or **Brought over from inFlow**.
4. Pick a place, or leave **All locations**.

Each row shows the item, type, date, location, shelf, order or document number and the quantity (plus or minus).

> Tip: To see the history of one product only, open it and press the **Movement history** tab.

See also: [Why is stock below zero?](/manual/stock-below-zero)`
	},
	{
		slug: "move-to-shelves",
		title: "Put items on shelves",
		section: "Inventory",
		summary: "Pick a shelf, then scan or search each item and move all of it there in one tap.",
		paths: ["/shelve"],
		keywords: [
			"shelving",
			"put away",
			"bin",
			"scan",
			"organize",
			"no shelf"
		],
		body: `Use this to put new or loose items on the right shelf.

1. Go to **Move to Shelves** in the menu.
2. In **Put items on**, choose the place and the shelf. Type a new shelf name to make a new shelf.
3. Scan a barcode or type a name in the search box. Press **Scan** to use your phone camera. It stays on so you can scan item after item.
4. Each item shows where it is now. Press **Move here** to move all of it to your shelf.
5. If only one item matches, pressing Enter moves it.

**Moved just now** lists what you moved. Press **Put back** to undo one. **On (shelf) now** shows what's on that shelf.

## Item not found?
1. Press **Add it as a new product** (or **Add a new product to this shelf**).
2. Fill in **Name**, and if you like **Description**, **Barcode**, **How many here** and **Category**.
3. Press **Take photo** or **Choose photos**.
4. Press **Add product**.

> Tip: Allow camera access in your browser for **Scan** to work.`
	},
	{
		slug: "locations-and-shelves",
		title: "Set up places and shelves",
		section: "Inventory",
		summary: "Add the rooms, vans and warehouses where you keep stock, and the shelves in each.",
		paths: ["/locations"],
		keywords: [
			"warehouse",
			"location",
			"shelf",
			"bin",
			"van",
			"room",
			"site"
		],
		body: `Use this to tell the app where you keep things.

## Add a place
1. Go to **Locations** in the menu.
2. Type a name, like Warehouse 2, Van or Room B.
3. Press **Add place**.

## Add shelves
1. On the place's card, type a name in **New shelf or spot**.
2. Press **Add shelf**.

Each card shows how many items are there and how many shelves it has.

## Change a place
- Press **Rename place**, type the new name and press **Save name**.
- Press **Stop using this place** to hide it from lists. It shows **Not used**.
- Turn on **Show places we stopped using** and press **Use this place again** to bring it back.

> Tip: You can also make a new shelf on the fly in [Move to Shelves](/manual/move-to-shelves) by typing its name.`
	},
	{
		slug: "product-categories",
		title: "Group products into categories",
		section: "Inventory",
		summary: "Make categories and sub-categories, and see the products in each.",
		paths: ["/categories"],
		keywords: [
			"category",
			"group",
			"sub-category",
			"product type",
			"folder"
		],
		body: `Use this to group products so they're easier to find.

## Add a category
1. Go to **Product Categories** in the menu.
2. Press **All categories (top level)**.
3. Type the name in **New category** and press **Add**.

## Add a sub-category
1. Click the category it goes under.
2. Type the name and press **Add**. It goes under the one you picked.

## See products
Click a category. Its products show on the right. Click one to open it.

## Remove a category
1. Click the category.
2. Press **Remove** (with its name).

> Tip: You can only remove a category with no products and no sub-categories in it. Move them first.

> Tip: To put many products in a category at once, tick them on the [Product List](/manual/product-list) and press **Put in a category**.`
	},
	{
		slug: "work-orders",
		title: "Build products from parts",
		section: "Inventory",
		summary: "Use work orders to take parts out of stock and add the finished product.",
		paths: ["/work-orders"],
		keywords: [
			"assembly",
			"build",
			"kit",
			"bill of materials",
			"BOM",
			"manufacture",
			"recipe"
		],
		body: `Use this when you build a product from parts you keep in stock.

## First: list the parts
1. Open the product you build and press the **Made from** tab.
2. Pick a part in **Add a part**, type how many go into ONE, and press **Add part**.
3. Type **Labor and other cost for one** and press **Save labor cost**.

## Make a work order
1. Go to **Work Orders** and press **New work order**.
2. Pick **What to build**, type **How many** and pick **Where** (parts come from and it goes to).
3. Add a **Due** date and **Notes** if you like.
4. Press **Make work order**.

## Finish it
1. Click the work order. Check the parts and the **In stock** column.
2. Press **Mark as being built** when you start (optional).
3. Change part amounts if needed and press **Save changes**.
4. Press **Finish and add to stock**.

The parts come out of stock and the built products go in.

> Tip: Made a mistake? Open it and press **Undo finish**. The parts go back.

> Tip: **To build** shows open work orders. Press **All** to see finished ones.`
	},
	{
		slug: "scan-a-barcode",
		title: "Scan a product barcode",
		section: "Inventory",
		summary: "Use your phone camera or a USB scanner to open a product by its barcode.",
		keywords: [
			"barcode",
			"QR code",
			"scanner",
			"camera",
			"UPC",
			"look up product"
		],
		body: `Use this to open a product fast by scanning it.

1. Press **Scan** at the top of the app.
2. Press **Scan a product barcode**.
3. Point the camera at the barcode or QR code.
4. The product opens by itself.

No camera? Type the code, or scan it with a USB scanner, in the box **…or type / scan with a USB scanner**, then press **Find**.

If no product has that barcode yet, the [Product List](/manual/product-list) opens with the code in the search box.

## Give a product its barcode
1. Open the product.
2. Type or scan the code into the **Barcode** box on the Details tab.
3. Press **Save product**.

> Tip: If the camera won't open, allow camera access in your browser settings.

> Tip: To scan many items onto a shelf, use [Move to Shelves](/manual/move-to-shelves).`
	},
	{
		slug: "stock-below-zero",
		title: "Why is stock below zero?",
		section: "Questions & fixes",
		summary: "What a negative stock number means and how to fix it.",
		keywords: [
			"negative stock",
			"minus",
			"red number",
			"wrong count",
			"oversold"
		],
		body: `A stock number below zero (shown in red) means more went out than the app knew came in.

Common reasons:
- Items were sold before the purchase order was received.
- Items were taken from a different place or shelf than the one recorded.
- A work order was finished without enough parts in stock.
- A count was never done after moving from inFlow.

How to fix it:

1. Go to **Product List** and pick **Below zero (check count)** in the drop-down. You see every product with a negative number.
2. Open a product and press the **Movement history** tab to see what happened.
3. If a purchase order arrived but wasn't received, open it and press **Receive items into stock**. See [Receive ordered items](/manual/receive-purchase-order).
4. If the place or shelf is wrong, use **Move stock** on the product page.
5. Otherwise, count it: press **Count stock** on the product page, or do a [Count Sheet](/manual/count-sheet).

> Tip: Count often for the items that go negative most.`
	},
	{
		slug: "po-not-in-pay-bills",
		title: "Why isn't my purchase order in Pay Bills?",
		section: "Questions & fixes",
		summary: "Pay Bills only lists purchase orders whose items were received.",
		keywords: [
			"missing PO",
			"can't pay PO",
			"pay before receive",
			"deposit",
			"prepay"
		],
		body: `Pay Bills shows a purchase order only when all of these are true:

- Its items were received (or the order is marked received, paid or completed).
- It still has a balance owed.
- It isn't cancelled.

What to do:

1. Open the purchase order from **Purchase Orders**.
2. If the items have arrived, press **Receive items into stock**. It will then show in Pay Bills.
3. If you need to pay before the items arrive (a deposit or prepay), press **Pay vendor** right on the purchase order instead.

> Tip: On the Purchase Order List, press **Unreceived** to see orders still waiting for items, or **Unpaid** to see what you still owe.

See also: [Pay a vendor for a purchase order](/manual/pay-purchase-order), [Pay many bills at once](/manual/pay-bills).`
	}
];
/** Manual: Banking and Accounting pages. */
var articles$1 = [
	{
		slug: "bring-in-bank-statement",
		title: "Bring in a bank or card statement",
		section: "Banking",
		summary: "Load your bank or credit card statement file so you can check each line against the books.",
		paths: ["/banking"],
		keywords: [
			"bank feed",
			"import",
			"statement",
			"CSV",
			"OFX",
			"QFX",
			"QBO",
			"PDF statement",
			"download transactions"
		],
		body: `Use this once a month (or more often) to bring the lines from your bank or credit card statement into Tallkeep.

## Steps

1. Open **Bank Feeds & Reconcile** in the menu (under Banking).
2. In **Choose the account**, pick the bank or card account the statement is for.
3. Make sure the **For review** tab is selected.
4. Press **Bring in a statement file** and pick the file, or drag the file onto the dashed box.
5. Wait a moment. A message tells you how many new lines came in.

## Which files work

- A **PDF** statement. AI reads it for you (up to 40 pages).
- **CSV**, **QBO**, **QFX** or **OFX** files. Most banks let you download these from their website under "Download transactions".

If your CSV shows card charges as positive numbers, tick **CSV shows charges as positive numbers (flip them)** before you bring the file in.

## What happens next

If **Record sure lines automatically** is ticked, Tallkeep records the lines it is sure about right away. Those are lines that match something already in the books, and lines from payees it remembers. You see them under **Done**. Everything else waits under **For review**. See [Match, add or ignore bank lines](/manual/review-bank-lines).

> Tip: Bringing in the same file twice is safe. Lines that are already here are skipped ("were already here").

> Tip: No bank or card account in the list? Add one in the [Chart of Accounts](/manual/chart-of-accounts).`
	},
	{
		slug: "review-bank-lines",
		title: "Match, add or ignore bank lines",
		section: "Banking",
		summary: "Go through each statement line and put it in the books, match it, or skip it.",
		paths: ["/banking"],
		keywords: [
			"bank feed",
			"for review",
			"match",
			"add to the books",
			"ignore",
			"undo",
			"categorize",
			"uncategorized"
		],
		body: `Use this after you bring in a statement, to deal with each line that is waiting under **For review**.

## Steps

1. Open **Bank Feeds & Reconcile**, pick the account, and stay on **For review**.
2. Look at each line. It shows the date, the bank's description and the amount (money in has a plus, money out a minus).
3. If Tallkeep found the same amount in the books within 10 days, you see "Matches …" with the date. Press **Match**. This links the bank line to what is already in the books, so nothing is entered twice.
4. If there is no match, choose an account in the box. For money out it asks **What was it for? (account)**, like Fuel or Office Supplies. For money in it asks **Where did it come from? (account)**.
5. Leave **Always use it for** ticked to remember this payee next time. You can shorten the text next to it, for example to just "SHELL".
6. Press **Add to the books**. This writes the line into the books for you.
7. Press **Ignore** for lines that are already in the books some other way, or are not yours.

Press **Record the N sure lines** to handle every match and remembered payee in one go.

## Fix a mistake

Open the **Done** tab. Each line says if it was matched, added or ignored. Press **Undo** to send it back to **For review**.

> Tip: An "account" is just a bucket in your books, like Rent or Sales. See [Chart of Accounts](/manual/chart-of-accounts).

> Tip: Change or delete what Tallkeep remembers in [Remembered payees](/manual/remembered-payees).`
	},
	{
		slug: "remembered-payees",
		title: "Remembered payees (bank rules)",
		section: "Banking",
		summary: "See, fix or delete the payees Tallkeep remembers, so bank lines get the right account by themselves.",
		paths: ["/banking"],
		keywords: [
			"bank rules",
			"rules",
			"auto categorize",
			"payee",
			"memorized",
			"wrong account"
		],
		body: `Use this when bank lines keep landing in the wrong account, or to clean up what Tallkeep has learned.

A remembered payee is a short piece of text, like "HOME DEPOT", tied to an account, like Supplies. Any bank line whose description contains that text gets that account.

## How payees get remembered

- When you press **Add to the books** with **Always use it for** ticked on the Banking page.
- When you record a receipt with **Always use this account for …** ticked on [Receipts](/manual/record-receipts).
- When you save lines in [Fast Entry](/manual/fast-entry) with a new payee.

## Change or delete one

1. Open **Bank Feeds & Reconcile**.
2. Press **Remembered payees (N)**. The number is how many you have.
3. Type in **Find…** to look for one.
4. To change the text, click in the box on the left, type, then click somewhere else. It saves by itself.
5. To change the account, pick a new one in the box on the right.
6. To remove one, press the trash can.

> Tip: Remembered payees work for every bank and card account, not only the one you have open.

> Tip: Keep the text short and unique. "AMAZON" catches every Amazon line; "AMAZON MKTPL 8812" may catch only one.`
	},
	{
		slug: "reconcile-bank-account",
		title: "Reconcile a bank or card account",
		section: "Banking",
		summary: "Check that your books match the bank statement to the penny, then lock those lines in.",
		paths: ["/banking"],
		keywords: [
			"reconcile",
			"reconciliation",
			"statement",
			"ending balance",
			"cleared",
			"balance owed",
			"bank rec"
		],
		body: `Use this each month when the bank or card statement arrives. To "reconcile" means to make sure the books and the bank agree.

## Steps

1. Open **Bank Feeds & Reconcile** and pick the account.
2. Press the **Reconcile** tab.
3. Type the **Statement end date** from your statement.
4. Type the **Statement ending balance**. For a credit card this box is called **Statement balance owed**.
5. Tick every line that also shows on the statement. Lines you already matched from a bank file are ticked for you.
6. Watch the three numbers at the top: **Beginning**, **Cleared balance** and **Difference**.
7. When **Difference** shows $0.00, press **Finish reconciling**.

The lines you ticked are now marked R (reconciled) in the [register](/manual/check-register). The statement is added to the **Reconciled before** list at the bottom.

## Good to know

- Only lines dated on or before the statement end date are listed.
- **Beginning** is the total of everything reconciled before.
- A line you leave unticked (for example a check not cashed yet) simply waits for next month.

> Tip: Difference won't go to zero? See [Reconcile won't come to $0.00](/manual/reconcile-not-zero).

> Tip: Bring in the statement file first ([how](/manual/bring-in-bank-statement)). Matching ticks most lines for you.`
	},
	{
		slug: "check-register",
		title: "Check Register and Credit Card Register",
		section: "Banking",
		summary: "See every check, deposit, charge and payment in one account, with the running balance.",
		paths: ["/register", "/card-register"],
		keywords: [
			"register",
			"check book",
			"running balance",
			"cleared",
			"C",
			"R",
			"card register",
			"account history",
			"transactions"
		],
		body: `Use the register when you want to see everything that went in or out of one bank or card account, like a paper check book.

## Open it

- **Check Register** (under Banking) shows a bank account.
- **Credit Card Register** shows a credit card.
- In the [Chart of Accounts](/manual/chart-of-accounts), click any account name to see its register.

To switch account, use the **Account** box in the search column on the left.

## The columns

- **Date**.
- **Number · type**: the check or reference number, and what it is (Check / payment, Deposit, Bill payment, Transfer and so on).
- **Payee · memo**: who was paid or who paid you.
- **Account (other side)**: the other account in the same entry, like Rent. "Split" means several accounts.
- **Payment** and **Deposit** for a bank. For a card: **Payment** and **Charge**.
- **✓**: **C** means cleared (the bank has it). **R** means reconciled (locked in by a [reconcile](/manual/reconcile-bank-account)).
- **Balance**: the running balance after each line.

The box at the top right shows the **Ending balance** (or **Balance owed** for a card).

## Steps to look something up

1. Pick the account.
2. Tick or untick **Newest first** to change the order.
3. Click any line to open that transaction.

> Tip: To find one check or amount, use the search column. See [Find a transaction in the register](/manual/register-search).

> Tip: Only the first 1,000 lines show. Search or pick dates to narrow it down.`
	},
	{
		slug: "register-search",
		title: "Find a transaction in the register",
		section: "Banking",
		summary: "Use the search column to find a check, payee, amount or date in one account or all of them.",
		paths: ["/register", "/card-register"],
		keywords: [
			"search",
			"find check",
			"find payment",
			"amount",
			"check number",
			"uncleared",
			"all accounts",
			"filter"
		],
		body: `Use this when you need one check, one deposit or one charge and don't want to scroll.

The search column sits on the left of the register. On a phone it sits above the list.

## Steps

1. In **Account**, pick one account, or **All bank and card accounts** to look everywhere at once.
2. In **Number, payee or memo**, type a check number or a name, like "1042" or "Home Depot".
3. In **Amount**, type the amount, like 250.00. It finds money in and money out.
4. In **Type**, pick a kind of transaction: **Checks & payments**, **Deposits**, **Payments received**, **Bill & PO payments**, **Transfers**, **From the bank feed** or **Journal & opening entries**.
5. Pick dates in **From** and **To**.
6. In **Cleared with the bank**, pick **Not cleared yet** to see what the bank hasn't shown yet, or **Cleared**.
7. The number found shows below. Click a line to open it.

Press **Clear search** to see everything again.

## Hide or show the column

Press the small panel button next to **Search** to hide it and make the register wider. Press it again to bring it back.

> Tip: Your search stays when you come back to the page. Press **Clear search** if the list looks too short.

> Tip: With **All bank and card accounts**, the **Account** column shows which account each line is in.`
	},
	{
		slug: "credit-cards",
		title: "Set up credit cards and enter charges",
		section: "Banking",
		summary: "Add a business credit card, see what you owe, and type in card charges.",
		paths: ["/credit-cards"],
		keywords: [
			"credit card",
			"card charge",
			"Amex",
			"Visa",
			"add card",
			"balance owed",
			"expense"
		],
		body: `Use the **Credit Cards** page as the home for your business cards: what you owe, charges, statements and payments.

## Add a card (admins)

1. Press **Add a credit card**.
2. Type the card's name, like "Amex Blue 1004".
3. Press **Add this card**.

## Enter a card charge

1. Press **New card charge** at the top, or **Charge** on the card.
2. In **Paid from**, check the card is picked. **How** is set to Card.
3. Fill in **Date**, **Pay to (vendor)** (or type a name) and **Memo**.
4. Under **What it pays for**, pick the account (like Meals or Fuel) and type the amount. Press **Add line** to split it.
5. Press **Save**.

The charge shows under **Card charges entered here**.

## The other buttons on each card

- **Statement** opens Banking to [bring in the card statement](/manual/bring-in-bank-statement).
- **Reconcile** opens the [reconcile](/manual/reconcile-bank-account) screen for this card.
- **Pay the card** opens [Pay the credit card bill](/manual/pay-credit-card).

Each card shows **You owe** (or **Card owes you** after a refund) and when it was last reconciled.

> Tip: You don't need to type every charge. Bringing in the card statement and adding the lines there is often faster.

> Tip: Snapping receipts also works. See [Record receipts](/manual/record-receipts).`
	},
	{
		slug: "move-money-transfer",
		title: "Move money between accounts",
		section: "Banking",
		summary: "Record money moved from one of your accounts to another, like checking to savings.",
		paths: ["/bank-transfers"],
		keywords: [
			"transfer",
			"savings",
			"move money",
			"owner",
			"loan payment",
			"between accounts"
		],
		body: `Use this when money moves between two of your own accounts, like checking to savings.

## Steps

1. Open **Transfers** under Banking.
2. In **From**, pick where the money left, like Checking.
3. In **To**, pick where it arrived, like Savings.
4. Type the **Amount**, the **Date** and a **Memo** if you like.
5. Press **Save transfer**.

The transfer shows in the list below with an arrow from one account to the other. It also shows in both [registers](/manual/check-register).

## Delete a transfer

Press the trash can on its line, then confirm.

> Tip: Picking a credit card as **To** turns this into a card payment, and the button says **Save card payment**. See [Pay the credit card bill](/manual/pay-credit-card).

> Tip: Both sides are your money, so a transfer never changes your profit.`
	},
	{
		slug: "pay-credit-card",
		title: "Pay the credit card bill",
		section: "Banking",
		summary: "Record the payment from your bank to your credit card.",
		paths: ["/bank-transfers"],
		keywords: [
			"pay card",
			"credit card payment",
			"card bill",
			"Amex payment"
		],
		body: `Use this when you pay your credit card from your checking account.

Paying a card is a transfer: money leaves the bank and lowers what you owe on the card. It is not an expense, because the charges were already counted.

## Steps

1. Open **Credit Cards** and press **Pay the card** on the card. (Or open **Transfers** under Banking.)
2. In **From**, pick the bank account you paid from.
3. In **To**, check the card is picked.
4. Type the **Amount** and the **Date** you paid.
5. **Memo** fills in as "Credit card payment" if you leave it empty.
6. Press **Save card payment**.

The bank balance goes down and the card's **You owe** goes down by the same amount.

> Tip: When the bank statement comes in, this payment shows as a match on the Banking page. Press **Match** so it isn't entered twice. See [Match, add or ignore bank lines](/manual/review-bank-lines).

> Tip: Paying the card the same amount each month by autopay? Set it up in [Recurring](/manual/recurring-payments) instead.`
	},
	{
		slug: "write-check",
		title: "Write a check or record a payment",
		section: "Banking",
		summary: "Record money you paid out by check, online, card or cash, and split it over accounts.",
		paths: ["/checks", "/checks/"],
		keywords: [
			"write check",
			"payment",
			"ACH",
			"online payment",
			"cash",
			"expense",
			"pay vendor",
			"checks & payments"
		],
		body: `Use this when you pay someone directly, without a bill. Paying bills you entered earlier? Use Pay Bills instead.

## Steps

1. Open **Write Checks** under Banking. You see **Checks & Payments**, the list of money paid out.
2. Press **Write a check**.
3. In **Paid from**, pick the bank (or card).
4. In **How**, pick **Check**, **Online / ACH**, **Card**, **Cash** or **Other**.
5. Type the **Check number** (or a **Reference** for other kinds) and the **Date**.
6. In **Pay to (vendor)**, pick a vendor, or type a name in **…or type a name**.
7. The **Address (printed on the check)** fills in from the vendor. Add a **Memo** if you like.
8. Under **What it pays for**, pick the account (like Rent) and type the amount. Press **Add line** to split one check over several accounts.
9. For a paper check: tick **Print later (it waits in Print Checks)**, or press **Save and print**.
10. Otherwise press **Save**.

## Find a payment

Type in **Search payee, number, memo**, or pick an account in the list next to it. Badges show **Void** and **To print**.

> Tip: The amount is also written out in words below the total, as it will be on the check.

> Tip: Paying the same thing every month? Open it and press **Repeat this**. See [Recurring](/manual/recurring-payments).

> Tip: Made a mistake? See [Void or delete a check](/manual/void-check).`
	},
	{
		slug: "void-check",
		title: "Void or delete a check",
		section: "Banking",
		summary: "Cancel a check or payment and take it out of the books.",
		paths: ["/checks/"],
		keywords: [
			"void",
			"cancel check",
			"delete payment",
			"bounced",
			"lost check",
			"stop payment"
		],
		body: `Use this when a check was lost, torn, written wrong, or a payment was entered by mistake.

## Void (keeps the number on record)

1. Open the check from **Write Checks** (or the card charge from **Credit Cards**).
2. Press **Void** and confirm.

The check stays in the list with its number and a **Void** badge, but it pays nothing and is out of the books. If it paid bills, those bills become unpaid again.

Use **Void** for paper checks, so your check numbers have no gaps.

## Delete (removes it completely)

1. Open the payment.
2. Press **Delete** and confirm.

It is gone from the list and the books.

> Tip: Not sure which one? Use **Void** for anything with a check number. Use **Delete** only for something that never should have been entered.

> Tip: A voided check can't be edited. Write a new one with [Write a check](/manual/write-check).`
	},
	{
		slug: "print-checks",
		title: "Print checks",
		section: "Banking",
		summary: "Print waiting checks on voucher check paper and give them their numbers.",
		paths: ["/print-checks"],
		keywords: [
			"print",
			"check paper",
			"voucher check",
			"check stock",
			"alignment",
			"check number"
		],
		body: `Use this to print checks you marked **Print later**, on voucher check paper (check on top, two stubs below, one per page).

## Steps

1. Open **Print Checks** under Banking (or press **Print checks (N)** on Write Checks).
2. Tick the checks to print. All are ticked to start.
3. In **Number on the first check in the printer**, type the number printed on your first blank check. The others count up from it.
4. Put the check paper in the printer.
5. Press **Print N checks**. In the print window, choose no margins and 100% size.
6. Look at the printed checks. If they are right, press **Yes, mark them printed**. If not, press **No, I'll print again**.

Marked checks get their numbers and leave the waiting list.

## Line it up

If the text sits too far left or too high, change **Move right (1/16 in)** and **Move down (1/16 in)**. Use negative numbers to move left or up. Tallkeep remembers these on this computer.

> Tip: Print one on plain paper first and hold it over a blank check to see if it lines up.

> Tip: Nothing waiting? Tick **Print later** when you [write a check](/manual/write-check), or pay bills by check.`
	},
	{
		slug: "record-deposits",
		title: "Record a bank deposit",
		section: "Banking",
		summary: "Group payments you took to the bank into one deposit, so the books match the bank statement.",
		paths: ["/deposits"],
		keywords: [
			"deposit",
			"undeposited funds",
			"make deposits",
			"bank deposit",
			"cash",
			"checks",
			"deposit slip"
		],
		body: `Use this after you take customer checks or cash to the bank.

When you record a customer payment with "Deposit to" set to **Undeposited Funds**, it waits here. Undeposited Funds is a holding place for money you have received but not yet taken to the bank.

## Steps

1. Open **Record Deposits** under Banking.
2. In **Deposit to**, pick the bank account.
3. Set the **Date** you made the deposit, and a **Memo** if you like.
4. Under **Waiting to be deposited**, tick each payment that went in this deposit. **Tick all** and **Clear** help with long lists.
5. Other money in the same deposit, like a refund from a supplier? Press **Add other money**. Pick the account it comes from, who it was **Received from**, **What for** and the amount.
6. Check the **Deposit total** matches your deposit slip.
7. Press **Save deposit**.

The deposit shows under **Past deposits** and as one line in the [register](/manual/check-register), just like on the bank statement.

## Undo a deposit

Press the trash can on the deposit under **Past deposits**. Its payments go back to waiting.

> Tip: Nothing waiting? Set Undeposited Funds as the usual choice in Settings → Accounting.

> Tip: Scanned checks from [Checks Received](/manual/checks-received) also wait here.`
	},
	{
		slug: "checks-received",
		title: "Take photos of checks from customers",
		section: "Banking",
		summary: "Take a photo of a customer's check; AI reads it and you put it on their invoices.",
		paths: ["/checks-received"],
		keywords: [
			"scan check",
			"customer check",
			"payment received",
			"photo",
			"remote deposit",
			"apply payment"
		],
		body: `Use this when a customer pays by paper check and you want to record it fast.

## Steps

1. Open **Checks Received** under Banking.
2. Press **Take a photo of a check** (on a phone), or **Choose check photos** to pick photos or PDFs. You can do several at once.
3. Wait while "AI is reading the check…". It fills in who paid, the amount, the date, the check number and the memo.
4. In **Customer**, check the right customer is picked. If not, pick one.
5. Under **Put it on these invoices**, Tallkeep spreads the amount over the customer's open invoices. Change the amounts if needed.
6. Press **Record $X as paid**.
7. The check shows "Recorded". Press **Make the deposit** when you take the checks to the bank. See [Record a bank deposit](/manual/record-deposits).

Press **Remove this check** to drop a scan you don't want.

> Tip: Lay the check flat in good light, front side up.

> Tip: Only the part that is on invoices is recorded. If the customer has no open invoices, make the invoice first.

> Tip: Record each check before you leave the page; scans that are not recorded are not kept.`
	},
	{
		slug: "record-receipts",
		title: "Record receipts",
		section: "Banking",
		summary: "Snap or drop receipts; AI reads them and you record them with one click.",
		paths: ["/receipts"],
		keywords: [
			"receipt",
			"photo",
			"scan",
			"expense",
			"store receipt",
			"PDF bill",
			"attach receipt"
		],
		body: `Use this to keep receipts with your books and record small purchases fast.

## Steps

1. Open **Receipts** under Banking.
2. Press **Take a photo** (on a phone) or **Add receipt files**, or drop photos and PDFs on the box.
3. AI reads the store, date and total. Check **Store / vendor**, **Date** and **Total**.
4. In **What was it for?**, pick the account, like Supplies. The AI's guess shows in the box.
5. If a bank or card line has the same amount within 5 days, you see "Matches …". Press **Record with this bank line** (or **Attach to this bank line** if that line is already in the books).
6. If there is no match, pick **Paid with** (the bank or card) and press **Record as a payment**. When the statement comes in later, it will match.
7. The receipt moves to the **Done** tab.

Leave **Always use this account for …** ticked so next time the same store gets the same account.

## Other buttons

- **Read again**: let the AI try again.
- **Ignore**: not needed; it moves to Done. Press **Put back** to bring it back.
- Trash can: delete the receipt and photo. What it recorded in the books stays.

> Tip: The Scan button at the top of the app also sends receipt photos here.

> Tip: Your accountant can open the receipt from the payment later.`
	},
	{
		slug: "fast-entry",
		title: "Type many payments, bills or deposits fast",
		section: "Banking",
		summary: "Enter lots of lines in a row, like a spreadsheet, or paste them from Excel.",
		paths: ["/fast-entry"],
		keywords: [
			"fast entry",
			"batch",
			"bulk",
			"paste from Excel",
			"spreadsheet",
			"catch up",
			"many checks"
		],
		body: `Use this when you have a stack of checks, bills or deposits to catch up on.

## Steps

1. Open **Fast Entry** under Banking.
2. Pick a tab: **Payments & checks**, **Bills**, or **Money in (deposits)**.
3. For payments, choose **Paid from**. For money in, choose **Deposit to**.
4. Type in the grid. **Tab** moves to the next box. **Enter** starts a new line. The arrow keys move up and down.
5. In **Account (what for)**, pick from the list that pops up. The text turns red if it doesn't match an account.
6. Press **Save all (N)**.

Saved lines turn green with an **Open** link. Lines with a problem turn red with a short note, like "Amount?". Fix them and press **Save all** again. Press **Start a new batch** when you're done.

## Good to know

- On **Payments & checks**, filling in **Check #** makes it a check. Without a number it's an online payment (or card).
- When you leave the **Paid to** box, Tallkeep fills the account from [remembered payees](/manual/remembered-payees).
- Dates can be typed like 10/5/2026.

## Paste from Excel

Copy rows in Excel or Google Sheets, click the first box to fill, and paste. Columns must be in the same order as the grid.

> Tip: Switching tabs clears lines you haven't saved. Save first.`
	},
	{
		slug: "recurring-payments",
		title: "Set up a payment that repeats",
		section: "Banking",
		summary: "Make rent, loans, insurance or autopay record themselves every week, month, quarter or year.",
		paths: ["/recurring"],
		keywords: [
			"recurring",
			"autopay",
			"repeat",
			"monthly",
			"memorized transaction",
			"scheduled",
			"subscription"
		],
		body: `Use this for payments or bills that come the same way again and again.

## Steps

1. Open **Recurring** under Banking and press **New recurring**. (Or open a payment in Write Checks and press **Repeat this** to start from it.)
2. Give it a **Name**, like Insurance.
3. In **What it makes**, pick **A payment (autopay, online, card, check)** or **A bill to pay later**.
4. For a payment, pick **Paid from** and **How**.
5. Pick the vendor in **Pay to (vendor)**, or type a name in **…or type a name**.
6. Pick **How often**: **Every week**, **Every month**, **Every 3 months** or **Every year**.
7. Set **Next one on**. Set **Last one on (optional)** if it stops, like a loan.
8. Under **What it pays for**, pick the account and amount. **Add line** to split it.
9. Leave **Make it automatically on its day** ticked, or untick it if the amount changes each time.
10. Press **Save**.

## The list

- Automatic ones are made by themselves early in the morning on their day.
- Ones you make yourself show **Due** when their day comes. Press **Make it now**, then fix the amount on the new payment if needed.
- The pause button stops one for a while (badge **Paused**). Press it again to **Start again**.
- The trash can deletes it. Payments already made stay.

> Tip: Upcoming ones also show on the [Calendar](/manual/money-calendar).`
	},
	{
		slug: "chart-of-accounts",
		title: "Chart of Accounts",
		section: "Accounting",
		summary: "See every account with its balance, add new accounts, and open an account's transactions.",
		paths: ["/accounts/"],
		keywords: [
			"accounts",
			"chart of accounts",
			"COA",
			"categories",
			"expense account",
			"new account",
			"inactive"
		],
		body: `Use this to see or change the list of "accounts" your money moves through. An account is a named bucket in your books, like Checking, Sales, Rent or Fuel.

Accounts are grouped as **Assets** (what you own), **Liabilities** (what you owe), **Equity** (the owner's share), **Income** and **Expenses**. Each group shows its total.

## See an account's transactions

Click the account's name. Its register opens, with every line and a running balance. See [Check Register and Credit Card Register](/manual/check-register).

## Add an account

1. Open **Chart of Accounts** and press **New account**.
2. Type a **Number** (optional) and a **Name**.
3. Pick a **Kind**, like "Expenses · Expense" or "Assets · Bank account". This decides where it shows in your reports.
4. Add a **Note (optional)**.
5. Press **Add account**.

## Change an account

1. Press the pencil next to it.
2. Change the name, number or kind, and press **Save account**.
3. To hide an account you no longer use, untick **Active**. Its history stays. Tick **Show inactive** to see hidden ones.

> Tip: Some accounts are used by Tallkeep itself (like Undeposited Funds). You can rename them, but their kind stays.

> Tip: No accounts at all? Set the books start date in Settings → Accounting to get a ready-made list.`
	},
	{
		slug: "journal-entries",
		title: "Make a journal entry",
		section: "Accounting",
		summary: "Type an entry by hand for things like owner money, loans, depreciation or an accountant's change.",
		paths: ["/journal"],
		keywords: [
			"journal entry",
			"JE",
			"debit",
			"credit",
			"adjustment",
			"depreciation",
			"owner draw",
			"accountant adjustment"
		],
		body: `Use this for anything that isn't an invoice, bill, check or deposit. Most entries write themselves; this is for the rest.

Every entry has **debits** and **credits**. A debit moves money into an account (or raises an expense). A credit moves it out (or raises income or what you owe). The two sides must be equal.

## Steps

1. Open **Journal Entries** (under Company) and press **New journal entry**.
2. Set the **Date** and a **Memo**.
3. On each line, pick the **Account** and type the amount under **Debit** or **Credit**.
4. Press **Add line** for more lines.
5. Check the bottom shows no "off by" amount.
6. Press **Save entry**.

## Accountant adjustment

When your accountant (CPA) sends year-end changes, press **Accountant adjustment** instead. It works the same way, starts on Dec 31 of last year (in the first half of the year), and shows in its own column on the Trial Balance. Press **Save adjustment**.

## See and delete entries

- **Typed by hand** shows your own entries. **All entries** shows everything, including the ones invoices and payments made.
- Use **From** and **To** to pick dates.
- Click an entry to see its lines. Entries typed by hand have **Delete this entry**.

> Tip: Starting your books? Use [Enter opening balances](/manual/opening-balances).`
	},
	{
		slug: "opening-balances",
		title: "Enter opening balances",
		section: "Accounting",
		summary: "Tell Tallkeep what each account held the day before your books start.",
		paths: ["/journal"],
		keywords: [
			"opening balance",
			"starting balance",
			"books start date",
			"beginning balance",
			"Opening Balance Equity",
			"switch from QuickBooks"
		],
		body: `Use this once, when you start your books in Tallkeep, so bank balances, loans and cards start at the right amounts.

Before you start, set the books start date in Settings → Accounting. Have your old system's Balance Sheet for the day before that date.

## Steps

1. Open **Journal Entries** and press **Opening balances**.
2. The date is set for you: the day before your books start.
3. On each line, pick an account and type its balance. Things you own (bank, equipment, inventory) go in **Debit**. Things you owe (loans, credit cards, unpaid bills) go in **Credit**.
4. Accounts Receivable (what customers owe you) is filled in for you, from open invoices dated before the start.
5. Press **Add line** for more accounts.
6. Don't worry if the two sides don't match. The bottom shows how much "goes to Opening Balance Equity". That account holds the difference.
7. Press **Save opening balances**.

Check the result on the Balance Sheet in [Financial Reports](/manual/financial-reports).

> Tip: Use the balance on your bank statement for that day, then [reconcile](/manual/reconcile-bank-account) from there.

> Tip: Your accountant can later move Opening Balance Equity into the right equity accounts.`
	},
	{
		slug: "financial-reports",
		title: "Profit & Loss, Balance Sheet and other financial reports",
		section: "Accounting",
		summary: "See how the business is doing, print it, or download it for your accountant.",
		paths: ["/financials"],
		keywords: [
			"P&L",
			"profit and loss",
			"income statement",
			"balance sheet",
			"trial balance",
			"general ledger",
			"aging",
			"AR",
			"AP",
			"net profit"
		],
		body: `Use this to see your profit, what you own and owe, and the detail behind it. All reports are made from the books by themselves.

## Steps

1. Open **Financial Reports** (under Reports).
2. Pick a report at the top (see the list below).
3. Set the dates: **From** and **To**, or **As of** for reports that are about one day.
4. Click any account amount to see the transactions behind it.

## The reports

- **Profit & Loss** (P&L): income minus costs and expenses, ending in **Net profit**.
- **P&L by month / vs last year**: the same, **By month** or **This vs last year**.
- **Balance Sheet**: what you own, what you owe, and the owner's share, on one day.
- **Trial Balance**: every account's balance as debits and credits. Accountant adjustments get their own columns.
- **General Ledger**: every line in the books, by account. Pick one account in **All accounts** to narrow it.
- **Who owes us** and **What we owe**: unpaid invoices and bills, by how late they are.
- **Sales tax**, **1099 vendors**, **Sales by customer**, **Expenses by vendor**.

## Share it

- **Print or save PDF** prints the report, or saves a PDF from the print window.
- **Download CSV** gives a file that opens in Excel.

> Tip: The Balance Sheet warns you if the two sides differ. Press "Rebuild the books" in Settings → Accounting.

> Tip: For sales and stock reports, see [Sales, purchasing and stock reports](/manual/business-reports).`
	},
	{
		slug: "business-reports",
		title: "Sales, purchasing and stock reports",
		section: "Accounting",
		summary: "Charts and tables for sales, purchases and inventory, ready for Excel.",
		paths: ["/reports"],
		keywords: [
			"reports",
			"sales by month",
			"sales by product",
			"sales rep",
			"stock value",
			"reorder",
			"purchases by vendor",
			"Excel"
		],
		body: `Use this to answer everyday questions like "What sold best this year?" or "What do we need to reorder?".

## Steps

1. Open **Reports** in the menu.
2. Pick a report on the left (see the list below).
3. For reports over time, pick the dates at the top right: **This year**, **Last year**, **Last 12 months** or **All time**.
4. Read the chart and the table. The last row shows the **Total**.
5. Click a name in the first column (where it's a link) to open it.
6. Press **Download for Excel** to save the table.

## The reports

- **Sales**: **Sales by month**, **Sales by customer**, **Sales by product**, **Sales by sales rep**, **Who owes us (unpaid invoices)**.
- **Purchasing**: **Purchases by vendor**, **What we owe vendors**.
- **Inventory**: **Stock value by location**, **Stock value by category**, **Reorder list (running low)**.

> Tip: Sales here are before tax.

> Tip: For Profit & Loss, Balance Sheet and other accounting reports, see [Financial reports](/manual/financial-reports).`
	},
	{
		slug: "year-end-cpa",
		title: "Finish the year and send it to your accountant",
		section: "Accounting",
		summary: "Check the year is ready, download one package for your CPA, then close the books.",
		paths: ["/year-end"],
		keywords: [
			"year end",
			"CPA",
			"accountant",
			"close the books",
			"tax time",
			"lock",
			"reopen",
			"package"
		],
		body: `Use this at tax time to get the year done in three steps.

## Steps

1. Open **Year-End & CPA** (under Company) and pick the year at the top.
2. **Get the year ready**: go through the checklist (see below). A warning sign means something to do.
3. **Send the package to your accountant**: press **Download the (year) package**. You get one .zip file with spreadsheets: Profit & Loss, Balance Sheet, Trial Balance, General Ledger, Chart of Accounts, who owes us, what we owe, sales tax, 1099 vendors and bank reconciliations. Email it to your CPA.
4. **Close the books**: after your accountant is done and you have added their adjustments, press **Close the books through Dec 31**.

## The checklist

- Each bank and card account should be [reconciled](/manual/reconcile-bank-account) through December. **Open Banking** takes you there.
- No bank lines should be waiting. **Review them** opens Banking.
- Debits and credits should match.
- Count your stock on Dec 31 (**Open Count Sheet**).
- Vendors who need a 1099 (**See 1099 vendors**).
- Your accountant's changes (**Add an adjustment**).

Once closed, nothing dated on or before that day can be changed by mistake. Paying old invoices today still works.

> Tip: Only an admin can close or reopen. Press **Reopen the books** if you must fix something.

> Tip: Accountant adjustments go in [Journal Entries](/manual/journal-entries).`
	},
	{
		slug: "record-payroll",
		title: "Record a payroll",
		section: "Accounting",
		summary: "Type the totals from your payroll company's report so the books show wages and taxes.",
		paths: ["/payroll"],
		keywords: [
			"payroll",
			"wages",
			"ADP",
			"Gusto",
			"Paychex",
			"salary",
			"withholding",
			"payroll taxes",
			"401k"
		],
		body: `Use this after each payroll. Your payroll company (ADP, Gusto, Paychex…) makes the paychecks; Tallkeep just records the totals.

## First time: set the accounts

On the right, under **Accounts**, pick where things go. They are remembered.

- **Wages go to**, **Employer taxes go to**, **Fees go to**: expense accounts.
- **Paid from**: the bank.
- **Amounts still owed go to (Payroll Liabilities)**: for money held back that you pay later.

## Each payroll

1. Open **Payroll** (under Company).
2. Fill in from your payroll report: **Pay date**, **Pay period (optional)**, **Gross wages (all employees)**, **Employee taxes withheld**, **Other deductions withheld (401k, insurance)**, **Employer taxes (your share)** and **Payroll company fee**.
3. Leave **The payroll company pays the taxes for us** ticked if they take the taxes from your bank. Untick it if you pay taxes yourself.
4. Check the box below: **Net pay to employees**, **Taken from the bank**, and any amount you still have to pay.
5. Press **Save the payroll**.

It shows under **Payrolls recorded**. Press the trash can to delete one.

> Tip: **Taken from the bank** should match what left your bank. That makes the bank line easy to match on the Banking page.

> Tip: When you later pay what you still owe (like the 401k), [write a check](/manual/write-check) to the Payroll Liabilities account.`
	},
	{
		slug: "money-calendar",
		title: "See what's due on the calendar",
		section: "Accounting",
		summary: "A month calendar of invoices, bills, rent, repeating payments and leases coming due.",
		paths: ["/calendar"],
		keywords: [
			"calendar",
			"due dates",
			"upcoming",
			"cash flow",
			"what's due",
			"schedule"
		],
		body: `Use this to plan your cash: see what money is coming in and going out each day.

## Steps

1. Open **Calendar** (under Company).
2. Each day shows colored tags (see below).
3. Click a day to see everything due that day on the right, with amounts.
4. Click an item to open it.
5. Use the arrow buttons to go to the last or next month. Press **Today** to come back.

## The tags

- **Customer owes**: an invoice is due.
- **Bill due** and **PO due**: you need to pay.
- **Rent due** and **Lease ends**: for properties.
- **Repeats**: a [repeating payment](/manual/recurring-payments) is coming.

> Tip: A day shows up to three tags; "+N more" means there are more. Click the day to see them all.

> Tip: Rent and lease tags only show if you use Properties.`
	},
	{
		slug: "ai-usage",
		title: "Choose the AI and see how much it's used",
		section: "Accounting",
		summary: "Pick which AI reads statements, receipts and checks, set a monthly limit, and see usage.",
		paths: ["/ai"],
		keywords: [
			"AI",
			"OpenAI",
			"Gemini",
			"API key",
			"usage",
			"cost",
			"limit",
			"PDF reading"
		],
		body: `Use this to control the AI that reads PDF bank statements, receipts and customer checks for you.

## See this month's use

Open **AI & Usage** (under Company). **This month** shows how many **times used**, how many **pages read**, and the estimated cost of the built-in AI. **Recent AI use** lists each read below.

## Choose the AI

1. In **AI**, pick **Built-in AI (included)** (nothing to set up), or **My own OpenAI account** or **My own Google Gemini account** (you pay that company directly).
2. For your own account, paste your **API key** (a secret code from that company's website).
3. Leave **Model** empty to use the usual one.
4. For the built-in AI, you can set a **Monthly limit … in $**. Leave it empty for no limit.
5. Press **Save**.

To stop using your own key, press **Remove the saved key**.

> Tip: Keys are kept on the server and never shown again in the app.

> Tip: If you see "The built-in AI isn't turned on yet", connect your own AI account here.`
	},
	{
		slug: "reconcile-not-zero",
		title: "Reconcile won't come to $0.00",
		section: "Questions & fixes",
		summary: "What to check when the Difference on the reconcile screen isn't zero.",
		paths: ["/banking"],
		keywords: [
			"difference",
			"out of balance",
			"reconcile problem",
			"doesn't match",
			"off by",
			"bank doesn't match"
		],
		body: `Use this when **Finish reconciling** stays grey because **Difference** isn't $0.00.

## Check these, in order

1. **The numbers you typed.** Is the **Statement end date** right? Is the **Statement ending balance** typed exactly as on the statement? For a card, use the balance owed.
2. **Ticked lines.** Compare each ticked line with the statement. Untick anything not on this statement. Tick anything that is.
3. **Missing lines.** Is something on the statement but not in the list? Bank fees and interest are easy to miss. Bring in the statement on the **For review** tab and add them. See [Match, add or ignore bank lines](/manual/review-bank-lines).
4. **Doubles.** Is the same payment in the books twice, for example once typed by hand and once added from the bank file? Open the [register](/manual/check-register) and delete or void one. Use **Ignore** on bank lines that were already in the books.
5. **Wrong amounts.** Open the line from the register and fix it.
6. **Beginning is wrong.** If **Beginning** doesn't match the statement's opening balance, something reconciled earlier was changed or deleted, or the [opening balances](/manual/opening-balances) are off.

> Tip: If the difference equals one line's amount, that line is the likely problem. If it's twice a line, that line is probably the wrong way round (money in vs out).

> Tip: In the register, set **Cleared with the bank** to **Not cleared yet** to see what's still open.`
	},
	{
		slug: "bank-line-already-entered",
		title: "A bank line is already in the books",
		section: "Questions & fixes",
		summary: "How to avoid counting a payment twice when it shows up in the bank feed.",
		paths: ["/banking"],
		keywords: [
			"duplicate",
			"twice",
			"double",
			"already entered",
			"no match",
			"doubled expense"
		],
		body: `Use this when a bank line shows under **For review** but you already entered that payment or deposit.

## Why it happens

Tallkeep suggests a **Match** only when the books have the same amount within 10 days that isn't cleared yet. If the date or amount is a bit different, no match shows.

## Fix it

1. Find the entry in the [register](/manual/check-register). Search by amount or payee.
2. If the amount or date is wrong there, open it and fix it. Come back to Banking: the **Match** now shows. Press it.
3. If it is right and you just want the bank line gone, press **Ignore** on the bank line. ("Already in the books some other way, or not ours.")
4. Do not press **Add to the books**. That would count it twice.

## Already added by mistake?

Open the **Done** tab, find the line and press **Undo**. The entry it made is taken out, and the line goes back to **For review**.

> Tip: Deposits of several checks match only if you made one deposit for them. See [Record a bank deposit](/manual/record-deposits).

> Tip: When you [reconcile](/manual/reconcile-bank-account), tick the entry you kept, so it is marked as cleared.`
	},
	{
		slug: "shoebox",
		title: "The Shoebox: drop statements, receipts, bills, checks and loan statements",
		section: "Banking",
		summary: "Drop any paperwork in one place. Tallkeep sorts it and puts it in the books.",
		paths: ["/shoebox"],
		keywords: [
			"drop",
			"upload",
			"inbox",
			"mortgage",
			"loan",
			"escrow",
			"statement",
			"receipt",
			"bill",
			"scan",
			"drag",
			"pdf",
			"automatic"
		],
		body: `Use the Shoebox when you have a pile of paperwork: bank and card statements, receipts, bills, checks, and mortgage or loan statements. Drop them all at once.

1. Open **Shoebox** (right under Home in the menu), or just drag files onto any Tallkeep page.
2. Drop the files, or click **Choose files** (on a phone, **Take a photo**). PDFs, photos, and files from your bank's website (CSV, OFX, QFX, QBO) all work.
3. Tallkeep works out what each file is and puts it where it belongs:
- **Bank or card statement**: the lines go into Bank Feeds. Lines that match something already in your books, or a payee Tallkeep remembers, are entered right away.
- **Receipt**: it goes to Receipts, already read, ready to record with one click.
- **Bill to pay**: entered in Bills when the vendor is known. Pay it later in Pay Bills.
- **Check from a customer**: click **Open in Checks Received** to put it on their invoices.
- **Mortgage or loan statement**: Tallkeep finds the loan's account (Mortgage, Car Loan, Student Loans, or a new one), shows what's still owed in Net Worth, and splits each payment to that lender in Bank Feeds by itself: interest to Mortgage Interest (or Loan Interest), escrow to Home Taxes and Insurance, and the rest pays down the loan. Drop each month's statement and the balance stays right. If the books show a different balance than the statement, click **Make the books match the statement**.
4. Anything Tallkeep isn't sure of waits under **Needs you**. Pick the account for a statement, check a bill's details, or say what the file is. **Skip** leaves it out of the books.

The same file dropped twice is only read once, and statement lines already in Bank Feeds aren't added again.

> Tip: The more payees Tallkeep remembers (in Bank Feeds, tick "Remember" when you add a line), the more of each statement goes in by itself.

> Tip: To find the account for a statement on its own, put the last 4 digits of the account in its name in the Chart of Accounts, like "Chase Checking 4521".`
	},
	{
		slug: "personal-money",
		title: "Use Tallkeep for personal or family money",
		section: "Personal money",
		summary: "Keep your household's bank, cards, bills, budget, net worth and investments in one place.",
		keywords: [
			"personal",
			"family",
			"household",
			"Quicken",
			"home"
		],
		body: `Tallkeep works for your own money too, like Quicken. Make a company for your household and pick **Personal or family money** as the kind.

## What you get

- **My Money** in the menu: [Budget](/manual/budget), [Net Worth](/manual/net-worth) and [Investments](/manual/investments).
- Household categories, like Groceries, Dining Out, Kids and School, Subscriptions and Vacation. Business accounts nobody has used are hidden (turn any back on in Chart of Accounts).
- Banking works the same: the Check Register, Credit Card Register, Transfers, Recurring payments and the [Shoebox](/manual/shoebox) for statements and receipts.
- Business pages like payroll, 1099s, sales tax and customers are hidden.

## Getting started

1. In **Chart of Accounts**, put in what's in each bank account, card, loan and your home on the day you start (the opening balance).
2. Drop your bank and card statements in the **Shoebox**, or add entries in the registers.
3. Open **Budget** and press **Fill empty budgets from the last 3 months**, then change any amounts.
4. Add your stocks and funds in **Investments**.

> Tip: A business can switch to personal (or back) in Settings → Features. Nothing is deleted.`
	},
	{
		slug: "budget",
		title: "Plan a monthly budget",
		section: "Personal money",
		summary: "Set how much to spend in each category each month and see what's left.",
		paths: ["/budget"],
		keywords: [
			"budget",
			"spending",
			"plan",
			"categories",
			"over budget"
		],
		body: `Open **My Money → Budget**.

1. Type how much you plan to spend each month next to each category, then press Enter. It saves by itself.
2. The bar fills as you spend. It turns red when a category goes over.
3. Use the arrows at the top to look at other months.

**Fill empty budgets from the last 3 months** puts in what you spent on average, rounded to $10, for every category without a budget yet.

Spending comes from your checks, card charges and bank entries (and anything the Shoebox recorded). Click a category to see its entries.

> Tip: Only categories with a budget or spending show. Press **Show all categories** to see the rest.`
	},
	{
		slug: "mortgage-loans",
		title: "Mortgage, car loans and other loans at home",
		section: "Personal money",
		summary: "See what you still owe, and split each payment into interest, escrow and what pays down the loan.",
		paths: ["/loans"],
		keywords: [
			"mortgage",
			"loan",
			"loans",
			"house",
			"home",
			"car loan",
			"student loan",
			"escrow",
			"interest",
			"principal",
			"balance",
			"personal",
			"household"
		],
		body: `Open **My Money → Mortgage & Loans**.

**The easy way: drop the statement.**

1. Drop your latest mortgage or loan statement (PDF or photo) in the **Shoebox**.
2. Tallkeep reads it and finds the loan's account (Mortgage, Car Loan, Student Loans, or a new one). What you still owe shows in Net Worth.
3. Each payment to that lender in Bank Feeds is split by itself: interest to **Mortgage Interest** (or Loan Interest), escrow to **Home Taxes and Insurance**, and the rest pays down the loan.
4. Drop each month's statement and the balance stays right. If the books show a different balance, click **Make the books match the statement** in the Shoebox.

**Or type it in.** Click **Add a loan** and fill in what you owe today, the interest rate, the monthly payment and the escrow. Tallkeep works out each month's interest from the rate.

**Word on the bank line**: the word Tallkeep looks for in your bank lines to know a payment is for this loan (like "lakeview"). Click **Change** on the loan to fix it if payments aren't being split.

> Tip: Mortgage interest and property taxes are often tax-deductible. Year-End & CPA → the package for your tax preparer shows both. Ask your tax preparer what applies to you.`
	},
	{
		slug: "rent-bills",
		title: "Rent, utilities and other monthly bills at home",
		section: "Personal money",
		summary: "Add rent and other bills so Tallkeep reminds you before they're due.",
		paths: ["/subscriptions"],
		keywords: [
			"rent",
			"house rent",
			"bills",
			"utilities",
			"power",
			"subscriptions",
			"reminders"
		],
		body: `Open **My Money → Bills, Rent & Subscriptions**.

1. Click **Add a bill**.
2. Type the name (like "Rent"), the amount, how often (monthly), and the next due date.
3. Pick the category (Rent) and the bank account you pay from.
4. Save. Tallkeep reminds you before it's due, and finds the payment in your bank lines.

Subscriptions (streaming, apps) work the same way: click **Add a subscription**. Tallkeep also finds repeating charges in your bank and card lines and offers to add them.

> Tip: Paying a mortgage instead of rent? Use [Mortgage, car loans and other loans](/manual/mortgage-loans), so the interest and escrow are kept apart.`
	},
	{
		slug: "net-worth",
		title: "See your net worth",
		section: "Personal money",
		summary: "Everything you own minus everything you owe, and how it's changed over the year.",
		paths: ["/net-worth"],
		keywords: [
			"net worth",
			"assets",
			"debts",
			"wealth"
		],
		body: `Open **My Money → Net Worth**.

- **You own**: bank accounts, investments, your home, cars and other things of value.
- **You owe**: credit cards, loans, the mortgage and other debts.
- **Net worth** is the first minus the second. The chart shows it at the end of each of the last 12 months.

Investments count at today's prices from [Investments](/manual/investments). Everything else comes from your books.

> Tip: To update what your home or car is worth, add a journal entry between that account and Opening Balance Equity.`
	},
	{
		slug: "investments",
		title: "Track your investments",
		section: "Personal money",
		summary: "Stocks, funds and retirement accounts: shares, what they cost, what they're worth.",
		paths: ["/investments"],
		keywords: [
			"investments",
			"stocks",
			"funds",
			"401k",
			"IRA",
			"brokerage",
			"shares",
			"prices"
		],
		body: `Open **My Money → Investments**.

1. If you need another account (like "Fidelity IRA"), type its name at the bottom and press **Add account**.
2. Press **Add a stock or fund**. Type the symbol, the name, how many shares you have, what they cost altogether and today's price.
3. To change one, press the pencil. To take one out, press the bin.

## Update prices

Press **Update prices** and paste one line per stock: the symbol, then the price (like "VTI 245.10"). You can copy two columns from a spreadsheet or your broker's page.

Money you move in from the bank is a **Transfer**. The page shows what you put in (from your books) next to what it's worth today.`
	},
	{
		slug: "bills-and-subscriptions",
		title: "Keep track of bills and subscriptions",
		section: "Personal money",
		summary: "See what's due, what your subscriptions cost each month, and repeating charges Tallkeep found.",
		paths: ["/subscriptions"],
		keywords: [
			"bills",
			"subscriptions",
			"reminders",
			"due",
			"autopay",
			"Netflix",
			"recurring"
		],
		body: `Open **My Money → Bills, Rent & Subscriptions**.

- **Coming up**: everything due in the next 30 days. Late ones are red. When Tallkeep sees the payment in your bank or card lines, it says so; press **Paid** and the next date moves on.
- **Subscriptions** and **Bills**: the full lists, with what each subscription costs per month and per year.
- **Repeating charges we found**: the same charge, same amount, on a regular schedule in your bank and card lines. Press **Add** to keep an eye on it, or the X if it isn't a repeat.

## Add one by hand

Press **Add a bill** or **Add a subscription**. Type the name, the amount (leave it empty if it changes, like a power bill), how often, and the next date.

**Words on the bank line** (like NETFLIX) let Tallkeep spot that it was paid.

> Tip: This is a reminder list. To have Tallkeep record a payment by itself each month, use [Recurring](/manual/recurring-payments).`
	},
	{
		slug: "monthly-review",
		title: "Review a month",
		section: "Personal money",
		summary: "Once a month: every account in, nothing waiting, transfers paired, bills paid, spending compared.",
		paths: ["/monthly-review"],
		keywords: [
			"monthly review",
			"month end",
			"close",
			"transfers",
			"card payment",
			"pair"
		],
		body: `Open **My Money → Monthly Review**. It starts on last month; use the arrows for others.

1. **Each account**: green means the month's lines are in and recorded. Orange means some are still waiting in Bank Feeds; grey means nothing is in yet. Press the button to go there.
2. **Transfers and card payments to pair**: money leaving one of your accounts and the same amount arriving in another within 4 days. Press **Record as one transfer** so it isn't counted as spending and income.
3. **Bills and subscriptions**: which were paid this month.
4. **Where the money went**: your biggest categories, compared with the 3 months before.`
	},
	{
		slug: "household",
		title: "Add the people in your household",
		section: "Personal money",
		summary: "Say whose each account is, then see everyone's money or one person's.",
		paths: ["/household"],
		keywords: [
			"household",
			"family",
			"spouse",
			"joint",
			"members",
			"people"
		],
		body: `Open **My Money → Household**.

1. Type each person's name and press **Add person**.
2. Under **Whose is each account?**, pick the person for each account. Leave **Joint** for accounts you share.

Budget, Net Worth, Investments, Bills, Rent & Subscriptions and Monthly Review then show buttons at the top: **Everyone**, or one person.

> Tip: Budget for one person shows what was paid from their accounts; the budget amounts stay for the whole household.`
	},
	{
		slug: "crypto-tax",
		title: "Work out crypto taxes",
		section: "Personal money",
		summary: "Bring in exchange history; get short and long-term gains, crypto income and Form 8949 rows.",
		paths: ["/crypto-tax"],
		keywords: [
			"crypto",
			"bitcoin",
			"coinbase",
			"kraken",
			"tax",
			"8949",
			"capital gains",
			"FIFO",
			"HIFO",
			"staking"
		],
		body: `Turn it on in **Settings → Features → Crypto tax** (any company can). Then open **Crypto Tax**.

1. Download your history: Coinbase (Profile → Statements → Transaction history, CSV) or Kraken (History → Export → Trades, CSV). Other exchanges and wallets: a CSV with Date, Type, Asset, Quantity and USD columns.
2. Pick the wallet (or **A new wallet or exchange…**), choose the file and press **Bring them in**. The same file twice won't add copies.
3. Pick the year and the matching method (FIFO, HIFO or LIFO). Each year keeps its own method.

## To look at

Coins received from outside, sent out with no matching receive, or with no dollar value. Say what each was (income, a gift, a move from another wallet…), type the value if needed, and press the check. Moves between your own wallets match up by themselves once both wallets are in.

## For your tax return

- **Sales**: each sale with when it was bought, what it cost and the gain. Short term is a year or less.
- **Form 8949 rows (CSV)**: give this file to your tax preparer or tax software.
- **Income**: staking, rewards and interest, at their value when received.

> Tip: Lots are kept per wallet, as the IRS asks from 2025. This is a worksheet, not tax advice.`
	}
];
/** Manual: Properties, Settings & people, Office computer & backups, Online & phone, Questions & fixes. */
var articles = [
	{
		slug: "properties-and-units",
		title: "Add properties and units",
		section: "Properties",
		summary: "Add each property you own and the units in it, so you can rent them out.",
		paths: ["/properties"],
		keywords: [
			"real estate",
			"building",
			"house",
			"apartment",
			"suite",
			"landlord",
			"rental"
		],
		body: `Use this when you start with Tallkeep, or when you buy a new property.

## Add a property

1. Open **Properties** in the menu.
2. Press **Add property**.
3. Type the **Name** and **Address**. Pick the **Kind** (for example Residential).
4. If you like, fill in **Bought on** and **Price paid**. They help your accountant.
5. Press **Save property**.

## Add a unit

1. Under the property, press **Add unit**.
2. Type a **Name**, like "Apt 2" or "Whole house". A house rented as a whole is one unit.
3. In **How it's rented**, pick **Long-term: a lease and monthly rent**, or **Short-term: stays by the night (Airbnb, VRBO, direct)**.
4. For a short-term unit, fill in the **Nightly rate**, **Cleaning fee per stay** and **Fewest nights**.
5. Save the unit.

Next to each long-term unit, **Rent it out** starts a lease. See [Rent a unit with a lease](/manual/leases-and-tenants). Next to each short-term unit, **Stays** opens its bookings. See [Track short-term stays](/manual/short-term-stays).

> Tip: Sold a property? Press **Edit property** and tick **We no longer have this property (sold) — hide it**. Its history stays. Tick **Show properties we no longer have** to see it again.

> Tip: Don't see Properties in the menu? Turn on **Real estate** in [Turn features on or off](/manual/features-on-off).`
	},
	{
		slug: "leases-and-tenants",
		title: "Rent a unit with a lease",
		section: "Properties",
		summary: "Add a tenant and a lease for a unit, with rent, due day, deposit and late fee.",
		paths: ["/leases"],
		keywords: [
			"tenant",
			"lease",
			"renter",
			"security deposit",
			"late fee",
			"move out",
			"end lease",
			"month to month"
		],
		body: `Use this when a tenant moves into one of your units.

## Start a lease

1. Open **Leases & Tenants** in the menu, and press **New lease**. (Or press **Rent it out** next to a unit on the Properties page.)
2. In **Unit**, pick the vacant unit.
3. Pick the tenant, or press **Add a new tenant** and type their details.
4. Fill in **Starts**. Leave **Ends** empty for month to month.
5. Type the **Monthly rent** and **Due on day (1–28)**.
6. Type the **Security deposit**, the **Late fee** and **Late after how many days**.
7. **First month to charge here** is the first month Tallkeep charges. Earlier months stay in your old system.
8. Leave **Charge the deposit now** ticked, unless they already paid it in your old system.
9. Press **Save lease**.

## End a lease

1. Open the lease and press **End this lease**.
2. Type the last day, like 2027-03-31.

> Tip: Giving the deposit back? Enter it in Bills & Expenses using the **Security Deposits Held** account.

> Tip: Use the search box to find a tenant or unit. Switch to **All, with ended** to see old leases.

Next: [Charge rent and record payments](/manual/charge-and-collect-rent).`
	},
	{
		slug: "charge-and-collect-rent",
		title: "Charge rent and record payments",
		section: "Properties",
		summary: "Charge every lease's monthly rent with one button, add late fees, and record what tenants pay.",
		paths: ["/rent"],
		keywords: [
			"rent due",
			"late fee",
			"tenant payment",
			"collect rent",
			"utilities",
			"pet fee",
			"charge"
		],
		body: `Use this each month to charge rent and to record money from tenants.

## Charge the rent

1. Open **Rent** in the menu.
2. In **Charge rent due up to**, pick a date (usually today).
3. Press **Charge rent and late fees**.

Tallkeep charges each lease's rent for every due day up to that date. It also adds a late fee to rent still unpaid after the grace days. It's safe to press again: a month is never charged twice.

## Record a payment

1. Press **Record rent received** (or **Record payment** next to a charge).
2. Pick the **Tenant** and type the **Amount** and **Date received**.
3. In **Deposit to**, pick the bank account.
4. Fill in **How (check, Zelle, cash…)** and the **Check or reference number**.
5. Press **Save payment**. It pays their oldest charges first.

## Add a one-off charge

For utilities, repairs or a pet fee: press **Add a charge**, pick the tenant, fill in **What for**, **Amount** and **Due**, then press **Add charge**.

> Tip: The **Owed** tab shows who still owes, with the total at the top. **All charges** and **Payments** show the history.

> Tip: Made a mistake? Press **Cancel charge** next to the charge.`
	},
	{
		slug: "rent-roll",
		title: "See the rent roll and profit by property",
		section: "Properties",
		summary: "A list of every unit with its tenant, rent, deposit and what's owed, plus each property's profit.",
		paths: ["/rent-roll"],
		keywords: [
			"rent roll",
			"vacancy",
			"Schedule E",
			"profit and loss",
			"P&L",
			"property report",
			"accountant"
		],
		body: `Use this to see all your units at a glance, or to give your accountant each property's profit.

## Rent roll

1. Open **Rent Roll** in the menu.
2. The **Rent roll** tab lists every unit with its tenant, lease dates, rent, deposit held and what is owed now. Vacant units show "Vacant".
3. Press **Download CSV** to open it in Excel, or **Print or save PDF**.

## Profit by property

1. Press the **Profit by property** tab.
2. Pick the from and to dates (for example the whole tax year).
3. Each property shows its income, its expenses and its **Net profit**.
4. Press **Download CSV** or **Print or save PDF** for your accountant (Schedule E).

> Tip: Rent goes to its property by itself. For expenses, pick the property on each bill line, or they won't show here.`
	},
	{
		slug: "short-term-stays",
		title: "Track short-term stays",
		section: "Properties",
		summary: "Keep Airbnb, VRBO and direct bookings in one calendar, and put payouts in the books.",
		paths: ["/stays"],
		keywords: [
			"Airbnb",
			"VRBO",
			"Booking.com",
			"vacation rental",
			"guest",
			"booking",
			"payout",
			"occupancy",
			"lodging tax"
		],
		body: `Use this for units you rent by the night.

First, set the unit to short-term: on **Properties**, edit the unit and set **How it's rented** to **Short-term**. See [Add properties and units](/manual/properties-and-units).

## Add a stay by hand

1. Open **Short-Term Stays** in the menu.
2. Press **Add a stay**, or click an empty day on the calendar.
3. Pick the **Unit** and **Booked through** (Airbnb, VRBO, Booking.com, Direct or Other).
4. Fill in **Check-in**, **Check-out**, the guest's name and the **Confirmation code**.
5. Check the money: nights, **Cleaning fee**, **Other fees**, **Lodging tax you collect** and **Platform's fee to you**. Copy these from the booking's earnings page.
6. Press **Save stay**.

## When the payout reaches your bank

1. Open the stay (the **Waiting for payout** list shows them).
2. Fill in **Payout received on** and pick the bank in **Into**.
3. Press **Save stay**. The income, cleaning fee, platform fee and any lodging tax go into the books.

> Tip: The boxes at the top show nights booked, average nightly rate and payouts received for the month. Use the arrows to change month.

> Tip: Guest canceled? Open the stay and tick **The guest canceled**. The dates free up.

Save typing: [Sync your Airbnb and VRBO calendars](/manual/stays-calendar-sync) and [Bring in Airbnb earnings](/manual/airbnb-earnings-import).`
	},
	{
		slug: "stays-calendar-sync",
		title: "Sync your Airbnb and VRBO calendars",
		section: "Properties",
		summary: "Bookings come in by themselves from each site's calendar link, and Tallkeep's link blocks the dates elsewhere.",
		keywords: [
			"iCal",
			"ics",
			"calendar link",
			"double booking",
			"Airbnb",
			"VRBO",
			"Booking.com",
			"sync"
		],
		body: `Use this so bookings from Airbnb, VRBO or Booking.com show up in Tallkeep without typing.

## Bring bookings into Tallkeep

1. Open **Short-Term Stays** and press **Calendar sync**.
2. Under the unit, pick the site, then paste that listing's calendar link (it ends in .ics).
3. Press **Add calendar link**. Tallkeep brings in the bookings right away.

Where to find the link:
- **Airbnb:** Calendar → pick the listing → Availability → Connect calendars → Connect to another website → copy the Airbnb link.
- **VRBO:** Calendar → Import & export → Export calendar → copy the link.
- **Booking.com:** Rates & Availability → Sync calendars → Export calendar → copy the link.

Tallkeep reads the calendars each time you open Short-Term Stays. Press **Sync now** to read them right away.

## Block the dates on the other sites

1. In the same window, press **Copy link for Airbnb** (or VRBO, Booking.com).
2. Paste it into that site's calendar settings (Import calendar).

Now a night booked on one site is blocked on the others.

> Tip: On Tallkeep Desktop, Tallkeep's own link works only inside your office network, unless you have [Tallkeep Connect](/manual/tallkeep-connect). Reading Airbnb's calendar into Tallkeep works either way.

> Tip: Calendars don't carry money. Add the amounts with [Bring in Airbnb earnings](/manual/airbnb-earnings-import).`
	},
	{
		slug: "airbnb-earnings-import",
		title: "Bring in Airbnb earnings",
		section: "Properties",
		summary: "Load Airbnb's earnings file so each reservation gets its nights, fees and payout.",
		keywords: [
			"Airbnb CSV",
			"earnings",
			"payout",
			"transaction history",
			"import",
			"host fee"
		],
		body: `Use this to fill in the money for your Airbnb stays without typing each one.

## Get the file from Airbnb

In Airbnb, open **Menu → Earnings**, pick **Paid** or **Upcoming**, and press **Download CSV**.

## Bring it in

1. Open **Short-Term Stays** and press **Bring in Airbnb earnings**.
2. Press **Pick the Airbnb earnings file (.csv)** and choose the file.
3. For each Airbnb listing in the file, pick the matching unit in **Pick a unit…**.
4. If the money is already in your bank, tick **These payouts have reached my bank** and pick the bank in **Into**.
5. Press **Bring in** (it shows how many stays).

Each reservation becomes a stay with its nights, cleaning fee, Airbnb's fee and payout. Stays that came from the calendar are filled in, not added twice.

> Tip: Other lines in the file, like payouts and adjustments, are skipped. Tallkeep tells you how many.

> Tip: Bringing in the same file again is safe. Stays already here are updated.`
	},
	{
		slug: "settings-overview",
		title: "Find your way around Settings",
		section: "Settings & people",
		summary: "What each group in Settings is for, and where to find each option.",
		paths: ["/settings"],
		keywords: [
			"options",
			"preferences",
			"setup",
			"admin",
			"configuration"
		],
		body: `Use this to find the right place in Settings. Only an admin can open Settings.

Open **Settings** in the menu. Pick a group on the left (on a phone, at the top):

- **Company**: company details and logo, the email you send from, card payments, your companies and saved footers. See [Company details and logo](/manual/company-details-and-logo).
- **People**: who can sign in and what they can open. See [Add people and choose what they see](/manual/users-and-access).
- **Features**: turn parts of the app on or off, the support page, and quote follow-ups. See [Turn features on or off](/manual/features-on-off).
- **Accounting**: the books start date, the bank for customer payments, and **Rebuild the books**.
- **Import & backups**: bring data from [QuickBooks](/manual/move-from-quickbooks) or [inFlow](/manual/move-from-inflow), and the [nightly backup](/manual/nightly-backup) on the office computer.
- **Plan & computer**: your plan or [license key](/manual/license-key), this computer's address, [updates](/manual/update-tallkeep), [Tallkeep Connect](/manual/tallkeep-connect) and the [Windows service](/manual/keep-office-computer-running).

> Tip: The top of the Settings page shows whether you use Tallkeep online or on your own computer, and the version number.

> Tip: You can link straight to a group, like /settings#people.`
	},
	{
		slug: "company-details-and-logo",
		title: "Company details and logo",
		section: "Settings & people",
		summary: "Set the name, address, phone and logo printed on your quotes, invoices and purchase orders.",
		paths: ["/settings"],
		keywords: [
			"logo",
			"address",
			"EIN",
			"tax ID",
			"letterhead",
			"company name",
			"reply-to",
			"footer"
		],
		body: `Use this to change what prints at the top of every quote and invoice.

1. Open **Settings** and pick **Company**.
2. Under **Company details**, press **Change logo** and pick a picture file. It saves right away.
3. Fill in **Company name**, **Phone**, **Email**, **Website** and **Address**.
4. If needed, fill in **Legal name, if different**, **Tax ID (EIN)** and **Mailing address for payments, if different**.
5. **Name customers see on emails** is the sender name in your customer's inbox.
6. **Customer email replies go to** is where replies go. Leave it empty to send replies to the person who sent the email.
7. Press **Save company details**.

> Tip: To take the logo off, press **Remove logo**.

> Tip: Further down, **Saved footers** holds notes you can pick at the bottom of each quote, order or invoice (like your bank details or return policy).

> Tip: Each company has its own details and logo. Switch to the company first. See [Run more than one company](/manual/more-companies).`
	},
	{
		slug: "users-and-access",
		title: "Add people and choose what they see",
		section: "Settings & people",
		summary: "Give someone a login, choose what they can open, reset a password, or remove them.",
		paths: ["/settings"],
		keywords: [
			"user",
			"login",
			"staff",
			"employee",
			"admin",
			"permissions",
			"role",
			"reset password",
			"access"
		],
		body: `Use this when someone new needs to sign in, or someone's access should change.

## Add a person

1. Open **Settings** and pick **People**.
2. Press **Add user**.
3. Type their **Name**, their **Email (they sign in with this)** and a **First password (at least 8 characters)**.
4. In **Can do**, pick **Staff — everyday work, all sections**, **Only some sections** (then tick what they can open, for example only Inventory), or **Admin — also settings and deleting**.
5. If you have more than one company, tick the companies they can open.
6. Press **Add this user**. Give them the password you typed.

## Change someone

- Change the box next to their name to switch between Staff, Only some sections and Admin.
- Press **New password**, type it, and press **Save password**.
- Press the trash can to remove them. They can't sign in any more, but their past work stays.

> Tip: The list shows when each person last signed in.

> Tip: Admins open every company. Everyone else opens only the companies ticked for them.`
	},
	{
		slug: "more-companies",
		title: "Run more than one company",
		section: "Settings & people",
		summary: "Set up another company with its own products, customers, invoices and numbers.",
		paths: ["/setup-company"],
		keywords: [
			"new company",
			"second business",
			"multi-company",
			"add company",
			"set up a new company"
		],
		body: `Use this when you run more than one business and want separate books for each.

## Set up a new company

1. Open **Settings**, pick **Company**, and under **Companies** press **Set up a new company**.
2. **Company**: type the name and details. Only the name is needed now. Press **Create the company**.
3. **Email**: how your emails look to customers. Press **Save and continue**.
4. **Numbers**: the first number for quotes, invoices, purchase orders and so on.
5. **Features**: pick what kind of business it is, and which parts it uses.
6. **Your data**: pick **Bring in data from inFlow**, **Bring in data from QuickBooks**, or **Start empty**.

## Switch and share

- Press **Switch to this company** in the Companies list, or switch at the top of the menu.
- Under **Who can open it**, tick the staff who may work in each company.
- Click a company's name to rename it.

> Tip: Each company has its own products, customers, invoices, numbers and settings. Admins can open every company.

> Tip: Your plan or license sets how many companies you can have. See [Your license key](/manual/license-key).`
	},
	{
		slug: "features-on-off",
		title: "Turn features on or off",
		section: "Settings & people",
		summary: "Show only the parts of Tallkeep your company uses, like Real estate or Support Desk.",
		paths: ["/settings"],
		keywords: [
			"add-ons",
			"modules",
			"hide menu",
			"real estate",
			"work orders",
			"support desk",
			"technician pay",
			"business type"
		],
		body: `Use this to show or hide parts of the app for the company you're working in.

1. Open **Settings** and pick **Features**.
2. Under **What kind of business is it?**, pick one: **Sells products and services**, **Makes products**, **Services only**, **Real estate** or **Something else**. This turns on the features it usually needs.
3. Below, tick or untick each feature:
- **Main parts**: Sales, Purchasing, Inventory, Accounting.
- **Work Orders**: build products from parts.
- **Real estate**: properties, leases, rent and short-term stays.
- **Support Desk**: a page where customers open tickets.
- **Website tickets**: service tickets from your website become invoices.
- **Technician pay**: track what you pay technicians.

It saves as you click.

> Tip: Turning a feature off only hides it from the menu. Nothing is deleted. Turn it back on and everything is there.

> Tip: When Support Desk is on, its settings appear on this page too. See [Set up your support page](/manual/support-desk-settings).`
	},
	{
		slug: "email-setup",
		title: "Send email from your own address",
		section: "Settings & people",
		summary: "On the office computer, connect your email account so invoices and quotes come from you.",
		paths: ["/settings"],
		keywords: [
			"SMTP",
			"Gmail",
			"Outlook",
			"Microsoft 365",
			"IONOS",
			"Yahoo",
			"iCloud",
			"Zoho",
			"GoDaddy",
			"app password",
			"email invoices"
		],
		body: `Use this on Tallkeep Desktop, so invoices, quotes, statements and support replies go out from your own email. Customers see them from you, and replies come back to you.

1. Open **Settings** and pick **Company**.
2. In the **Email** box, pick **Your email provider** (Gmail, Outlook, IONOS, Yahoo, iCloud, Zoho, GoDaddy, or other).
3. Type your **Email address**.
4. Type the password. Gmail, Outlook, Yahoo and iCloud need an **app password**. IONOS and GoDaddy use the normal email password. The note under the box says what your provider needs.
5. For "other", also fill in **Outgoing mail server (SMTP)** and **Port**.
6. Press **Check and save**. Tallkeep checks the account with your provider first.
7. Type your own address and press **Send a test email**.

## Making an app password

- **Gmail**: Google Account → Security → 2-Step Verification (turn it on) → App passwords → make one named Tallkeep. Paste the 16 letters.
- **Outlook / Microsoft 365**: Microsoft account → Security → App passwords. On Microsoft 365, your admin may need to allow SMTP sending.
- **Yahoo**: Account Security → Generate app password.
- **iCloud**: appleid.apple.com → Sign-In and Security → App-Specific Passwords.

> Tip: Leave **Send from a different address (optional)** empty unless your provider lets this account send as that address.

> Tip: The password stays on the office computer only. To switch accounts press **Change account**. To stop, press **Stop sending**.

Trouble? See [Email doesn't send](/manual/email-not-sending).`
	},
	{
		slug: "card-payments-stripe",
		title: "Let customers pay by card (Pay now)",
		section: "Settings & people",
		summary: "Connect Stripe so emailed invoices get a Pay now link and paid invoices are marked by themselves.",
		paths: ["/settings"],
		keywords: [
			"Stripe",
			"credit card",
			"pay online",
			"Pay now",
			"payment link",
			"merchant",
			"disconnect Stripe"
		],
		body: `Use this on Tallkeep Desktop to add a "Pay now" link to invoices you email. Customers pay by card on Stripe's secure page. The money goes to your own Stripe account.

You need a license key first. See [Your license key](/manual/license-key).

## Connect Stripe

1. Open **Settings** and pick **Company**.
2. In **Card payments (Pay now)**, press **I have a Stripe account: sign in** to keep your account, payouts and history. New to Stripe? Press **Create a new Stripe account**. It asks for your business details and the bank for payouts (about 10 minutes).
3. Finish on Stripe's page. You come back to Settings.
4. If Stripe still needs details, press **Give Stripe the missing details**. Card payments turn on by themselves when Stripe is done.

## After it's on

Tallkeep marks the invoice paid and records Stripe's fee. Payments go into the **Stripe** account, and the fee into Card Processing Fees. Press **Check for payments now** to look right away.

When Stripe pays out to your bank, record it as a transfer from Stripe to the bank.

## Disconnect

Press **Disconnect Stripe**. Pay now links already sent stop working. Payments already made stay in the books.

> Tip: Each company connects its own Stripe account. Stripe's usual card fee applies.`
	},
	{
		slug: "license-key",
		title: "Your license key: enter, renew or upgrade",
		section: "Settings & people",
		summary: "Enter the license key for Tallkeep Desktop, get updates for another year, or add companies or people.",
		paths: ["/settings"],
		keywords: [
			"license",
			"key",
			"TK1",
			"activate",
			"buy",
			"renew",
			"upgrade",
			"trial",
			"plan",
			"pricing"
		],
		body: `Use this after you buy Tallkeep Desktop, or when you renew or add more.

## Buy

Buy at [app.tallkeep.com/buy](https://app.tallkeep.com/buy). You pay once. Your key arrives by email right after you pay. (On the office computer, **Buy Tallkeep** in Settings shows the prices.)

## Enter the key

1. On the office computer, open **Settings** and pick **Plan & computer**.
2. Under **Your license**, paste the key from your email (it starts with TK1.).
3. Press **Save the license key**. Tallkeep checks it online and saves it.

## Renew updates or add more

1. Under **Your license**, press **Renew updates** or **Add companies or people**. This opens [app.tallkeep.com/upgrade](https://app.tallkeep.com/upgrade) with your license filled in.
2. Pick another year of updates, or how many companies and people to add. Pay by card.
3. Back in Settings, press **Check for my updated key**. Your new key comes in by itself.

> Tip: The license box shows who it's licensed to, and the date updates end. After that date Tallkeep keeps working; you just don't get new versions.

> Tip: To paste a different key, press **Enter a new license key**.

> Tip: A license works on one office computer at a time. See [My books went read-only](/manual/books-read-only).`
	},
	{
		slug: "support-desk-settings",
		title: "Set up your support page",
		section: "Settings & people",
		summary: "Pick your support page address, who gets new tickets, topics, and saved replies.",
		paths: ["/settings"],
		keywords: [
			"support desk",
			"help desk",
			"tickets",
			"canned replies",
			"saved replies",
			"support page",
			"customer support"
		],
		body: `Use this when you turn on Support Desk, so customers can open tickets on your own page.

1. Open **Settings** and pick **Features**. (Support Desk must be ticked. See [Turn features on or off](/manual/features-on-off).)
2. In the **Support Desk** box, type the **Support page address**, like sunrise-led. Use letters, numbers and dashes.
3. In **Email new tickets and replies to**, type one or more emails (separate with commas). Leave it empty to use the company email.
4. In **Topics customers pick from**, type topics like Repair, Installation (separate with commas).
5. In **A line at the top of the page**, type a short welcome.
6. Press **Save the support page**.
7. Press **Copy link** and put it on your website, invoices or email signature. **Open your support page** shows it.

## Saved replies

Answers you send often. Type a name (like "Parts ordered") and the reply, then press **Add saved reply**. Pick one when you answer a ticket.

> Tip: When a ticket is assigned to someone, replies go to that person.`
	},
	{
		slug: "move-from-quickbooks",
		title: "Move from QuickBooks",
		section: "Settings & people",
		summary: "Bring your lists, history and open balances over from QuickBooks Desktop, step by step.",
		paths: ["/settings"],
		keywords: [
			"QuickBooks",
			"QB",
			"IIF",
			"import",
			"switch",
			"convert",
			"migrate",
			"trial balance",
			"estimates",
			"barcodes",
			"cleared",
			"1099"
		],
		body: `Use this when you switch from QuickBooks Desktop (2019 and newer).

1. Open **Settings** and pick **Import & backups**.
2. Find **Bring data over from QuickBooks**. Do the steps in order. Each step says what to export in QuickBooks; then you choose that file here.

## Your lists (do these first)

- **Step 1, Customers, vendors, items, payment terms and sales tax**: in QuickBooks, File → Utilities → Export → Lists to IIF Files. Press **Choose the .IIF file**, then **Bring in these lists**.
- **Step 2, Chart of accounts.**

## Your books and history

- **Step 3**: opening balances (from the Trial Balance report) or the full history (from the Journal report).
- **Steps 4 to 7**: past sales, payments received, what you paid each vendor, and memorized transactions. Big files can come in one year at a time.

## What's open on switch-over day

- **Step 8, Stock on hand**: pick the place to put the stock, then **Set stock to these counts**.
- **Step 9, Open invoices**: what customers still owe. Press **Bring in these invoices**.
- **Step 10, Unpaid bills**: what you still owe vendors.

## Extras (optional, skip any)

- **Step 11, Item details**: barcodes (UPC), part numbers, units, reorder levels and the preferred vendor. In QuickBooks: Lists → Item List → Excel → Export all items, as a .csv file.
- **Step 12, Open estimates, sales orders and purchase orders**: estimates become quotes, sales orders stay open, and purchase orders stay open so you can receive them here. They don't change the books until you act on them. Use Reports → Custom Reports → Transaction Detail, with the columns and filters the step lists.
- **Step 13, Cleared checks and deposits**: marks what already cleared the bank, so your next reconcile starts where QuickBooks left off. Needs the full history from step 3. In QuickBooks: the account's QuickReport, one file per bank or card account.

Vendor tax IDs and the 1099 box come over in step 1, along with second contacts, second phones, customer and vendor types and QuickBooks' own custom fields.

> Tip: Running a step again updates the same records. It won't make copies.

> Tip: Most reports are saved from QuickBooks with Excel → Create New Worksheet → .csv file.`
	},
	{
		slug: "move-from-inflow",
		title: "Move from inFlow",
		section: "Settings & people",
		summary: "Bring your inFlow products, stock, customers, orders and photos into Tallkeep.",
		paths: ["/settings"],
		keywords: [
			"inFlow",
			"import",
			"switch",
			"migrate",
			"product photos",
			"inflow-import.json"
		],
		body: `Use this when you switch from inFlow Inventory.

## Your data

1. Open **Settings** and pick **Import & backups**.
2. Find **Bring data over from inFlow**.
3. Press **Choose the inflow-import.json file** and pick the file from your inFlow export.
4. Tick **I understand stock counts will be set to what inFlow had**.
5. Press **Import inFlow data**. Wait until it says it's done, then open Products.

Products, stock, customers, vendors, quotes, orders, invoices, purchase orders, payments and your next document numbers all come in.

## Product photos

1. In **Bring product photos over from inFlow**, press **Choose the whole product-photos folder**.
2. Click the **product-photos** folder once and press **Upload**. Say yes when the browser asks.
3. Press **Upload product photos**.

> Tip: Running the import again updates the same records. It won't make copies. But it resets stock counts to what inFlow had, so don't run it after you start selling in Tallkeep.`
	},
	{
		slug: "install-office-computer",
		title: "Install Tallkeep on the office computer",
		section: "Office computer & backups",
		summary: "Install Tallkeep Desktop on the Windows computer that will keep your books.",
		keywords: [
			"install",
			"download",
			"setup",
			"Windows",
			"desktop",
			"SmartScreen",
			"Windows protected your PC",
			"first start"
		],
		body: `Use this once, on the main office computer: the one that is on most of the day.

1. Download Tallkeep for Windows (the link is in your email, or on the page after you buy).
2. Open the file Tallkeep-Setup.
3. If Windows says **Windows protected your PC**, click **More info**, then **Run anyway**. Tallkeep is new, so Windows doesn't know it yet. That's normal.
4. Say yes when Windows asks for permission. Press through the installer and leave **Open Tallkeep now** ticked.
5. Tallkeep asks one question. Pick **This computer keeps the books**.
6. Wait while it says **Opening your books…**. The first start takes a minute.
7. On **Welcome to Tallkeep**, type **Your name**, **Company name**, **Your email (your login)** and a password. Press **Set up Tallkeep**.
8. Open **Settings → Plan & computer** and paste your license key. See [Your license key](/manual/license-key).

The installer also lets the office network through Windows Firewall, so other computers can connect.

> Tip: Everyone else gets their login from you in Settings → People. See [Add people and choose what they see](/manual/users-and-access).

> Tip: Next, [connect the other computers](/manual/connect-other-computers) and [set up the nightly backup](/manual/nightly-backup).`
	},
	{
		slug: "connect-other-computers",
		title: "Connect other computers and phones in the office",
		section: "Office computer & backups",
		summary: "Open the office computer's books from other computers and phones on the office network.",
		paths: ["/settings"],
		keywords: [
			"client",
			"workstation",
			"second computer",
			"network",
			"LAN",
			"address",
			"4600",
			"IP address",
			"Connect to the office computer"
		],
		body: `Use this on every computer in the office that is not the office computer.

## Find the office computer's address

On the office computer, open **Settings → Plan & computer**. The **This office computer** box lists the address others type, like http://192.168.1.20:4600. You can also right-click the Tallkeep icon near the clock.

## Another Windows computer

1. Install Tallkeep the same way. See [Install Tallkeep on the office computer](/manual/install-office-computer).
2. When it asks, pick **Connect to the office computer**.
3. Click the office computer in the list. Not listed? Type its address, like 192.168.1.20, and press **Connect**.

## Any computer, Mac or phone

Open the address in a web browser, like Chrome, Edge or Safari. Sign in with your own email and password.

> Tip: Tallkeep must be open on the office computer, and both must be on the same network.

> Tip: To change it later, use the **Tallkeep** menu → **Change how this computer connects…**.

> Tip: When the office computer gets a new version, other computers show **Update now**. Press it so everything works right.

Can't connect? See [Can't reach the office computer](/manual/cant-reach-office-computer).`
	},
	{
		slug: "keep-office-computer-running",
		title: "Keep the office computer running",
		section: "Office computer & backups",
		summary: "Make sure the books stay open for everyone, even when no one is signed in to the office computer.",
		paths: ["/settings"],
		keywords: [
			"sleep",
			"awake",
			"power",
			"service",
			"Windows service",
			"tray",
			"start with Windows",
			"always on",
			"background"
		],
		body: `Use this so others can work even when you close Tallkeep or sign out of the office computer.

## How it works out of the box

- Closing the Tallkeep window only hides it. The books keep running. A Tallkeep icon sits near the clock.
- The books start by themselves when you sign in to Windows (**Start the books when Windows starts**, in the icon's menu).
- Tallkeep keeps the computer from going to sleep. The screen can still turn off.
- To really close it, right-click the icon and pick **Close Tallkeep (others can't work until it's open again)**.

## Keep running without anyone signed in

1. On the office computer, open **Settings → Plan & computer**.
2. In **Keep running without anyone signed in**, press **Turn on the service**.
3. Say yes when Windows asks for permission. Tallkeep closes for a minute while it switches.

Now the books open when the computer starts, before anyone signs in, and stay open when you sign out or Windows restarts for an update. To go back, press **Turn off the service**.

> Tip: With the service on, backups to a Synology may stop, because the service signs in to the network as the computer, not as you. Fix: open Services in Windows → Tallkeep → Log On, and enter your Windows account.

> Tip: Keep the computer plugged in and turned on.`
	},
	{
		slug: "nightly-backup",
		title: "Set up the nightly backup",
		section: "Office computer & backups",
		summary: "Choose where Tallkeep saves a copy of all your books every night, and back up now.",
		paths: ["/settings"],
		keywords: [
			"backup",
			"NAS",
			"Synology",
			"network drive",
			"copy",
			"tkb",
			"back up now",
			"one company"
		],
		body: `Use this on Tallkeep Desktop so a broken computer can't take your books with it.

Every night Tallkeep saves all your books (every company, user and attached file) as one file. The newest 30 are kept.

1. Open **Settings** and pick **Import & backups**.
2. In **Nightly backup**, under **Backup folder**, press **Choose folder…** or type a folder.
3. For a Synology, type its network path, like \\\\SYNOLOGY\\Backups\\Tallkeep.
4. Press **Save folder**.
5. In **Back up every night at**, pick an hour when the computer is on.
6. Press **Back up all companies now** to make the first one, and check that **Last backup** shows it.

## Back up one company

If you have more than one company, pick it in **Pick a company…** and press **Back up only this company**. This makes a file with just that company, to keep or move to another Tallkeep.

> Tip: Leave the folder empty to keep backups on this computer only. A folder on another drive is safer.

> Tip: If the computer is off at backup time, it backs up soon after Tallkeep opens. If a backup fails, the box says why.

To use a backup, see [Put the books back from a backup](/manual/put-books-back).`
	},
	{
		slug: "put-books-back",
		title: "Put the books back from a backup",
		section: "Office computer & backups",
		summary: "Go back to how the books were in a backup: all companies or just one.",
		paths: ["/settings"],
		keywords: [
			"restore",
			"undo",
			"recover",
			"backup",
			"lost data",
			"roll back",
			"tkb"
		],
		body: `Use this if something went badly wrong and you want the books back the way they were.

Everything entered after that backup will be replaced, for everyone. Tallkeep saves a backup of the books as they are now first, so you can undo this.

## On the office computer (Tallkeep window)

1. Open **Settings → Import & backups** and press **Put the books back from a backup…** (or use the **Tallkeep** menu).
2. Pick the backup file (it ends in .tkb).
3. Pick **All companies** or **Only** one company.
4. Press the button to put them back. **Keep the books as they are** cancels.

## From a browser, Synology or Windows service

1. Open **Settings → Import & backups**.
2. Under **Newest backups in the folder**, press **Put back…** next to the one you want.
3. In **What to put back**, pick **All companies** or one company.
4. Press the red button to confirm. **Keep the books as they are** cancels.

> Tip: A one-company backup always puts back just that company. The others stay as they are.

> Tip: After putting back, check a report or two. If one looks wrong, press **Rebuild the books** in Settings → Accounting.`
	},
	{
		slug: "update-tallkeep",
		title: "Update Tallkeep",
		section: "Office computer & backups",
		summary: "Install a new version of Tallkeep Desktop on the office computer and the others.",
		paths: ["/settings"],
		keywords: [
			"update",
			"upgrade",
			"new version",
			"check for updates",
			"version"
		],
		body: `Use this when Tallkeep says a new version is ready.

## On the office computer

Tallkeep looks for a new version every few hours and downloads it by itself. You choose when to install it.

1. When a bar says **Tallkeep … is ready to install**, press **Update now**. (Or open **Settings → Plan & computer** and press **Check for updates**.)
2. Say yes when Windows asks for permission.
3. Tallkeep saves a backup of the books, installs, and opens again.

Pick a quiet time: others can't work for a minute or two.

## On other computers

They follow the office computer. When it has a new version, a bar says **The office computer has Tallkeep …**. Press **Update now**.

## In Docker or on a Synology

Open **Settings → Plan & computer → Updates** and press **Update now**. Tallkeep saves a backup, closes for a minute or two and opens again. The page reloads by itself.

> Tip: Updates come while your license includes them. If it says your updates ended, press **Renew updates**. See [Your license key](/manual/license-key).`
	},
	{
		slug: "docker-synology-install",
		title: "Run Tallkeep on a Synology or Linux server",
		section: "Office computer & backups",
		summary: "Run the office version of Tallkeep in Docker on a Synology NAS or Linux server, day and night.",
		keywords: [
			"Docker",
			"Synology",
			"NAS",
			"Linux",
			"server",
			"Container Manager",
			"docker compose",
			"DSM"
		],
		body: `Use this to keep your books on a Synology or server instead of a Windows computer. It's the same Tallkeep, with the same license and backups, and it runs whether anyone is signed in or not.

You need Docker, a 64-bit processor and 2 GB of memory.

## On a Synology (DSM 7.2 or newer)

1. In **Package Center**, install **Container Manager**.
2. In **File Station**, in the docker shared folder, make a folder named tallkeep. Upload the 5 files from tallkeep-docker.zip into it.
3. Inside tallkeep, make two empty folders: data and backups.
4. In **Container Manager**, open **Project** → **Create**. Name: tallkeep. Path: that folder. Source: **Use existing docker-compose.yml**.
5. Change TALLKEEP_PUBLIC_URL to your Synology's name or address with :4600. Press **Next**, **Next**, **Done**. The first start takes a few minutes.
6. Open http://your-synology:4600 in a browser. Set up the owner's login and your company.
7. Open **Settings → Plan & computer** and paste your license key.

## On a Linux server

Put the files in a folder, set TALLKEEP_PUBLIC_URL and TZ (your time zone) in docker-compose.yml, and run docker compose up -d --build.

> Tip: Your books are in the data folder and the nightly backups in backups. Keep both.

> Tip: If the Synology firewall is on: Control Panel → Security → Firewall → Edit rules → allow port 4600 from your local network.`
	},
	{
		slug: "move-windows-synology",
		title: "Move your books to another computer or Synology",
		section: "Office computer & backups",
		summary: "Move all your books between Windows and a Synology (or a new computer) with a backup file.",
		keywords: [
			"move",
			"migrate",
			"new computer",
			"transfer",
			"Synology",
			"Windows",
			"replace computer",
			"tkb"
		],
		body: `Use this when you replace the office computer, or move between Windows and a Synology.

1. On the old office computer, open **Settings → Import & backups** and press **Back up all companies now**.
2. Find the newest file named Tallkeep-Backup-….tkb in the backup folder.
3. Set up Tallkeep on the new place. See [Install Tallkeep on the office computer](/manual/install-office-computer) or [Run Tallkeep on a Synology](/manual/docker-synology-install).
4. Copy the backup file to the new place. On a Synology, put it in the backups folder next to docker-compose.yml. On Windows, any folder works.
5. On the new place, open **Settings → Import & backups**. On a Synology, press **Put back…** next to that file. On Windows, press **Put the books back from a backup…** and pick the file.
6. Pick **All companies** and confirm.
7. Open **Settings → Plan & computer** and paste your license key.
8. Uninstall Tallkeep on the old computer.

> Tip: A license works on one office computer at a time. It moves by itself 30 days after the old computer stops using it, or contact Tallkeep to move it now.

> Tip: To move just one company, use **Back up only this company** instead.`
	},
	{
		slug: "install-on-phone",
		title: "Put Tallkeep on your phone's home screen",
		section: "Online & phone",
		summary: "Add Tallkeep to your phone's home screen so it opens like an app.",
		keywords: [
			"phone",
			"iPhone",
			"Android",
			"app",
			"home screen",
			"mobile",
			"tablet",
			"iPad"
		],
		body: `Use this to open Tallkeep on your phone with one tap. There is nothing to download from an app store.

Which address to open:
- Tallkeep online: app.tallkeep.com
- In the office: the office computer's address (see [Connect other computers and phones](/manual/connect-other-computers))
- Away from the office: your [Tallkeep Connect](/manual/tallkeep-connect) address

1. Open that address in your phone's browser.
2. Sign in.
3. **iPhone or iPad (Safari)**: tap the Share button, then **Add to Home Screen**, then **Add**.
4. **Android (Chrome)**: tap the three dots menu, then **Add to Home screen** (or **Install app**).

Now Tallkeep has its own icon and opens full screen, like an app.

> Tip: The office address works only on the office Wi-Fi. For use anywhere, add the Tallkeep Connect address instead.`
	},
	{
		slug: "tallkeep-connect",
		title: "Use Tallkeep from home (Tallkeep Connect)",
		section: "Online & phone",
		summary: "Give your office computer its own secure web address, so you can work from home or a phone anywhere.",
		paths: ["/settings"],
		keywords: [
			"remote",
			"work from home",
			"away",
			"web address",
			"outside the office",
			"Connect",
			"subscription",
			"tallkeep.app"
		],
		body: `Use this on Tallkeep Desktop to open your books from anywhere: home, phones away from the office, and links customers or Airbnb open. Your books stay on your computer. Nothing to set up on your router.

You need a license key first. See [Your license key](/manual/license-key).

## Turn it on

1. On the office computer, open **Settings → Plan & computer**.
2. In **Tallkeep Connect**, press **Turn on Tallkeep Connect** (a monthly price).
3. Pay on the card page. You come back to Settings.
4. Wait a minute. It says **On. Open Tallkeep from anywhere at:** with your address.
5. Press **Copy** and send the address to your team.

Sign in there with the same email and password. Keep the office computer on, with Tallkeep open.

## Change the address

1. Press **Change address**.
2. In **Pick a short address**, type letters, numbers and dashes.
3. Press **Save address**.

The old address stops working, so update phones, bookmarks, and the calendar link in Airbnb.

> Tip: **Change card or cancel** opens your subscription. **Check again** refreshes the status.

> Tip: A new address can take a few minutes to open. See [My new Connect address doesn't open](/manual/connect-address-not-opening).`
	},
	{
		slug: "cant-reach-office-computer",
		title: "Can't reach the office computer",
		section: "Questions & fixes",
		summary: "What to check when another computer or phone can't open Tallkeep on the office computer.",
		keywords: [
			"can't connect",
			"couldn't reach",
			"not loading",
			"firewall",
			"network",
			"offline",
			"site can't be reached",
			"4600"
		],
		body: `Use this when you see "Couldn't reach Tallkeep" or the page won't load on another computer or phone.

1. Go to the office computer. Is it on and awake? Is Tallkeep open (the icon near the clock)?
2. Are both on the same network? A phone must be on the office Wi-Fi, not mobile data.
3. Check the address. On the office computer, open **Settings → Plan & computer** and look at **This office computer**. Type it exactly, with :4600 at the end.
4. Did the address change? Office routers sometimes give the computer a new number. Use the new one, and on Windows computers pick **Tallkeep** menu → **Change how this computer connects…**.
5. Install the latest Tallkeep on the office computer. Its installer lets the office network through Windows Firewall.
6. On a Synology, allow port 4600 in the Synology firewall.

> Tip: To stop the address from changing, ask whoever looks after your router to give the office computer a fixed address.

> Tip: So the books don't stop when no one is signed in, see [Keep the office computer running](/manual/keep-office-computer-running).

> Tip: Away from the office, the office address won't work. Use [Tallkeep Connect](/manual/tallkeep-connect).`
	},
	{
		slug: "connect-address-not-opening",
		title: "My new Connect address doesn't open",
		section: "Questions & fixes",
		summary: "Fix a new or changed Tallkeep Connect address that won't open on one computer.",
		keywords: [
			"Connect",
			"DNS",
			"flushdns",
			"address not found",
			"site can't be reached",
			"new address",
			"ipconfig"
		],
		body: `Use this when you just turned on Tallkeep Connect or changed its address, and it won't open.

1. Wait a few minutes. A new address can take a little while to start working.
2. In Settings → Plan & computer, check that **Tallkeep Connect** says **On** (not **Connecting…**). Press **Check again**.
3. Try the address on a phone using mobile data. If it opens there, the address works; your computer just remembers the old answer.

## Clear the old answer on Windows

1. Click Start and type **cmd**.
2. Right-click **Command Prompt** and pick **Run as administrator**. Say yes.
3. Type **ipconfig /flushdns** and press Enter.
4. Close the browser fully, open it again, and try the address.

> Tip: After you change the address, the old one stops working. Update bookmarks, phone icons and the Airbnb calendar link.

> Tip: If Connect shows a red message, the office computer may be offline. Check its internet connection.`
	},
	{
		slug: "email-not-sending",
		title: "Email doesn't send",
		section: "Questions & fixes",
		summary: "What the email error messages mean on Tallkeep Desktop, and how to fix them.",
		keywords: [
			"email error",
			"SMTP",
			"app password",
			"535",
			"550",
			"553",
			"mailbox unavailable",
			"IONOS",
			"Gmail",
			"Microsoft 365",
			"can't send"
		],
		body: `Use this when **Check and save** or **Send a test email** shows an error. Open **Settings → Company → Email**.

- **"Gmail didn't accept the password."** Gmail needs an app password, not your normal one. Google Account → Security → 2-Step Verification → App passwords. Paste the 16 letters.
- **"Microsoft didn't accept the sign-in."** Use an app password. On Microsoft 365, ask your admin to allow SMTP sending (SMTP AUTH) for this mailbox.
- **"The mail server didn't accept the email account or password."** Retype the full email address and password.
- **"Couldn't reach the mail server."** Check the server name, the port and the internet connection.
- **"won't send as … while signed in as …"** Empty **Send from a different address**, or sign in with that address's own email and password.
- **"The mail server refused the address it was sent to."** Check the customer's email address.

## IONOS: "550 mailbox unavailable"

IONOS sends only from the mailbox you signed in with. Press **Change account**, empty **Send from a different address**, and make sure **Email address** is a real IONOS mailbox (not just a forward). Press **Check and save**, then **Send a test email**.

> Tip: The last test result shows next to **Send a test email**.

See [Send email from your own address](/manual/email-setup).`
	},
	{
		slug: "books-read-only",
		title: "My books went read-only",
		section: "Questions & fixes",
		summary: "Why Tallkeep stops letting you change things (trial ended, license problem) and how to fix it.",
		keywords: [
			"read-only",
			"trial ended",
			"expired",
			"license not valid",
			"another computer",
			"elsewhere",
			"can't save",
			"locked"
		],
		body: `Use this when you can open, print and download everything, but can't change anything.

Open **Settings → Plan & computer** and read the box at the top.

## "The free trial ended"

Tallkeep Desktop is free for 30 days. Then the books become read-only until you enter a license key. Buy one at [app.tallkeep.com/buy](https://app.tallkeep.com/buy) and paste it. See [Your license key](/manual/license-key).

Tallkeep online: under **Your plan**, press **Choose a plan**.

## "License not valid"

- **"already used on another office computer"**: a license works on one office computer at a time. Uninstall Tallkeep on the old computer. The license moves here by itself 30 days after that computer stops using it, or contact Tallkeep to move it now.
- **"hasn't been able to check its license … for 30 days"**: connect the office computer to the internet. It checks by itself.
- **"doesn't recognize this license key"**: copy the key again from your Tallkeep email, all of it.
- **"has been switched off"**: contact Tallkeep.

> Tip: Nothing is lost while the books are read-only. Everything comes back the moment the license is fixed.

> Tip: Questions? Email hello@tallkeep.com.`
	},
	{
		slug: "forgot-password",
		title: "I forgot my password",
		section: "Questions & fixes",
		summary: "How to get back in when you forget your Tallkeep password.",
		keywords: [
			"password",
			"reset",
			"locked out",
			"can't sign in",
			"login",
			"forgot"
		],
		body: `Use this when you can't sign in because you forgot your password.

## Tallkeep online (app.tallkeep.com)

1. On the sign-in page, type your email.
2. Tap **Forgot password?**.
3. Open the email from Tallkeep and click the link.
4. Type a **New password** and press **Save password**.

## Tallkeep Desktop (office computer)

There is no reset email. Ask your office admin:

1. The admin opens **Settings** and picks **People**.
2. Next to your name, they press **New password**, type one, and press **Save password**.
3. They tell you the new password.

> Tip: The owner forgot their own password and there's no other admin? Contact Tallkeep at hello@tallkeep.com.

> Tip: Have a second admin, so someone can always reset a password. See [Add people and choose what they see](/manual/users-and-access).`
	},
	{
		slug: "where-are-my-books",
		title: "Where are my books stored?",
		section: "Questions & fixes",
		summary: "Where Tallkeep keeps your data online, on Windows and on a Synology, and how to find it.",
		keywords: [
			"data",
			"database",
			"folder",
			"location",
			"files",
			"AppData",
			"privacy",
			"where is my data"
		],
		body: `Use this when you want to know where your data lives.

## Tallkeep online

Your books are on Tallkeep's servers. You open them at app.tallkeep.com from any computer or phone.

## Tallkeep Desktop on Windows

Your books are on the office computer only, in the Books folder: C:\\Users\\(your name)\\AppData\\Local\\Tallkeep\\Books.

To open it, use the **Tallkeep** menu → **Open the books folder** on the office computer. Don't change files there by hand.

Other computers in the office don't keep a copy. They open the office computer's books.

## Tallkeep in Docker (Synology or server)

Your books are in the data folder next to docker-compose.yml. Nightly backups are in the backups folder.

## Backups

On Desktop, nightly backups go to the folder you pick. See [Set up the nightly backup](/manual/nightly-backup).

> Tip: Your email password and Stripe connection are kept on the office computer, not sent to the browser.

> Tip: Moving to a new computer? See [Move your books to another computer or Synology](/manual/move-windows-synology).`
	},
	{
		slug: "report-a-problem",
		title: "Report a problem",
		section: "Questions & fixes",
		summary: "Tell Tallkeep when something doesn't work right, with a picture of the screen.",
		keywords: [
			"bug",
			"error",
			"broken",
			"not working",
			"feedback",
			"tester"
		],
		body: `Use this when something in Tallkeep doesn't work the way it should.

1. Go to the page where it went wrong.
2. Press **F1** (or **Help** at the bottom of the menu).
3. At the bottom of the Help panel, click **Report a problem**.
4. Under **What went wrong?**, write what you did and what happened. For example: "I pressed Save on the invoice and the total changed to $0."
5. If you can, click **Add a picture of the screen** and pick a screenshot.
6. Click **Send to Tallkeep**.

Tallkeep sees which page you were on and your Tallkeep version, so you don't have to explain that. We answer by email.

> Tip: To take a screenshot on Windows, press **Windows + Shift + S**, drag over the screen, then save the picture. On a phone, press the power and volume-down buttons together.`
	},
	{
		slug: "become-a-tester",
		title: "Early Access: use Tallkeep before launch",
		section: "Getting started",
		summary: "Get early access: use Tallkeep free until January 31, 2027, and get 50% off when you buy.",
		keywords: [
			"beta",
			"tester",
			"free",
			"discount",
			"early access",
			"preview"
		],
		body: `Before Tallkeep opens for sale, businesses can get early access and use it for free.

1. Open [app.tallkeep.com/early-access](https://app.tallkeep.com/early-access).
2. Fill in your name, email and your business, and what you'd use Tallkeep for.
3. Click **Ask for early access**.
4. We look at each business. Within 2 business days you get an email with your free license key and the download link.
5. Install Tallkeep, then paste the key in **Settings → Plan & computer**. See [Install Tallkeep on the office computer](/manual/install-office-computer).

Your early access license works until January 31, 2027. When something doesn't work right, use [Report a problem](/manual/report-a-problem).

## Keep Tallkeep after testing

Your welcome email has a code for 50% off. Buy at [app.tallkeep.com/buy](https://app.tallkeep.com/buy), type the code in **Early access code**, and paste your new key in Settings. Everything you entered stays.`
	}
];
/** The whole manual, search, and "which article helps with this page". */
var ARTICLES = [
	...articles$3,
	...articles$2,
	...articles$1,
	...articles
];
var BY_SLUG = new Map(ARTICLES.map((a) => [a.slug, a]));
var articleBySlug = (slug) => BY_SLUG.get(slug) ?? null;
var bySection = () => SECTIONS.map((s) => ({
	section: s,
	list: ARTICLES.filter((a) => a.section === s)
})).filter((x) => x.list.length);
/** How well an article path fits an app page: an exact page beats a "everything under" path;
*  "/" (Home) only ever fits Home. -1 = doesn't fit. */
function fit(p, path) {
	if (p === path) return 1e4 + p.length;
	if (p === "/" || !p.endsWith("/")) return -1;
	if (path === p.slice(0, -1)) return 5e3 + p.length;
	return path.startsWith(p) ? p.length : -1;
}
/** The help for an app page: the article whose path fits it best (the first one on a tie). */
function articleForPath(path) {
	let best = null;
	let score = -1;
	for (const a of ARTICLES) for (const p of a.paths ?? []) {
		const f = fit(p, path);
		if (f > score) {
			best = a;
			score = f;
		}
	}
	return best;
}
/** Other articles for the same page. */
var alsoForPath = (path, not) => ARTICLES.filter((a) => a.slug !== not && (a.paths ?? []).some((p) => fit(p, path) >= 0));
var plain = (s) => s.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/[*#>`_]/g, " ").toLowerCase();
var INDEX = ARTICLES.map((a) => ({
	a,
	title: a.title.toLowerCase(),
	head: `${a.summary} ${(a.keywords ?? []).join(" ")}`.toLowerCase(),
	body: plain(a.body)
}));
/** Words that don't say what the question is about. */
var STOP = new Set("a an the to of in on at for and or with how do does did can could should i my me we our you your it is are be what where when which who why this that there use using get make set up about from into my need want handle handling deal".split(" "));
/** Other words people use for the same thing. */
var SAME = {
	mortgage: ["loan", "escrow"],
	loan: ["mortgage"],
	house: [
		"home",
		"mortgage",
		"rent"
	],
	home: [
		"house",
		"personal",
		"household"
	],
	personal: [
		"household",
		"family",
		"home"
	],
	family: ["household", "personal"],
	rent: ["bill"],
	subscription: ["subscriptions", "bill"],
	bank: ["banking"],
	statement: ["statements", "shoebox"],
	receipt: ["receipts"],
	invoice: ["invoices"],
	delete: ["remove"],
	remove: ["delete"]
};
/** "payments" → "payment", "splitting" → "split". */
var stem = (w) => w.length > 4 ? w.replace(/(ings?|ies|es|s|ed)$/, (m) => m === "ies" ? "y" : "") : w;
/** Articles for the words typed, best first: the ones with the most of the words, then the
*  ones with them in the title. */
function searchManual(q, max = 30) {
	const raw = q.toLowerCase().split(/[^a-z0-9$#.%-]+/).filter((w) => w.length > 1);
	const words = raw.filter((w) => !STOP.has(w)).map(stem);
	const use = words.length ? words : raw.map(stem);
	if (!use.length) return [];
	const scored = [];
	for (const x of INDEX) {
		let s = 0;
		let n = 0;
		for (const w of use) {
			const alts = [w, ...SAME[w] ?? []];
			const t = alts.some((v) => x.title.includes(v));
			const h = alts.some((v) => x.head.includes(v));
			const b = alts.some((v) => x.body.includes(v));
			if (t || h || b) n++;
			const own = x.title.includes(w) || x.head.includes(w);
			s += (t ? 10 : 0) + (h ? 5 : 0) + (b ? 1 : 0) + (own ? 3 : 0);
		}
		const need = use.length <= 2 ? use.length : Math.ceil(use.length / 2);
		if (n >= need && s >= 5) scored.push({
			a: x.a,
			s,
			n
		});
	}
	return scored.sort((a, b) => b.n - a.n || b.s - a.s).slice(0, max).map((x) => x.a);
}
//#endregion
export { bySection as a, articleForPath as i, alsoForPath as n, searchManual as o, articleBySlug as r, ARTICLES as t };
