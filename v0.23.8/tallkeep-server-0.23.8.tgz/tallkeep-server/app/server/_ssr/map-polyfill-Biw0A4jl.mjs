//#region ../../node_modules/.nitro/vite/services/ssr/assets/map-polyfill-Biw0A4jl.js
function addMapPolyfill() {
	for (const C of [Map, WeakMap]) {
		const p = C.prototype;
		if (!p.getOrInsert) Object.defineProperty(p, "getOrInsert", {
			configurable: true,
			writable: true,
			value(k, v) {
				if (!this.has(k)) this.set(k, v);
				return this.get(k);
			}
		});
		if (!p.getOrInsertComputed) Object.defineProperty(p, "getOrInsertComputed", {
			configurable: true,
			writable: true,
			value(k, f) {
				if (!this.has(k)) this.set(k, f(k));
				return this.get(k);
			}
		});
	}
}
//#endregion
export { addMapPolyfill };
