import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { En as BedDouble, H as Pencil, R as Plus, St as House, _t as KeyRound } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-aFR9SgbK.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { o as refreshRealEstate, r as PROPERTY_KIND, s as useRealEstate } from "./realestate-B7MhUll3.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/properties-Cry9fOCt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Properties() {
	const { data, isLoading } = useRealEstate();
	const [showOld, setShowOld] = (0, import_react.useState)(false);
	const [pEdit, setPEdit] = (0, import_react.useState)(null);
	const [uEdit, setUEdit] = (0, import_react.useState)(null);
	const list = (data?.properties ?? []).filter((p) => showOld || p.is_active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Properties",
			text: "Each property and its units (apartments, suites, or the whole house as one unit). Rent a unit out from here.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setPEdit({
					name: "",
					kind: "residential",
					is_active: true
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add property"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-2 text-sm text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				checked: showOld,
				onChange: (e) => setShowOld(e.target.checked)
			}), "Show properties we no longer have"]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		data && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-8 text-center text-muted-foreground",
			children: "No properties yet. Press \"Add property\" to start."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: data && list.map((p) => {
				const units = data.units.filter((u) => u.property_id === p.id && u.is_active);
				const longUnits = units.filter((u) => u.rental_type !== "short");
				const shortUnits = units.filter((u) => u.rental_type === "short");
				const rented = longUnits.filter((u) => data.current(u.id));
				const monthly = rented.reduce((s, u) => s + (data.current(u.id)?.rent ?? 0), 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-2 border-b p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "flex items-center gap-2 font-display text-lg font-semibold",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "h-4 w-4 text-[var(--section)]" }),
									" ",
									p.name,
									!p.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: "No longer ours"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: [p.address, PROPERTY_KIND[p.kind]].filter(Boolean).join(" · ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm",
								children: [
									longUnits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										rented.length,
										" of ",
										longUnits.length,
										" unit",
										longUnits.length === 1 ? "" : "s",
										" rented · ",
										fmtMoney(monthly),
										" a month"
									] }),
									longUnits.length > 0 && shortUnits.length > 0 && " · ",
									shortUnits.length > 0 && `${shortUnits.length} short-term unit${shortUnits.length === 1 ? "" : "s"}`
								]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setPEdit({ ...p }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" }), " Edit property"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setUEdit({
									name: "",
									property_id: p.id,
									is_active: true
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add unit"]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "divide-y text-sm",
						children: [units.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "p-4 text-muted-foreground",
							children: "No units yet. A house rented as a whole is one unit (for example \"Whole house\")."
						}), units.map((u) => {
							const l = data.current(u.id);
							const t = l ? data.tenant.get(l.tenant_id) : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-3 px-4 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: u.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												u.bedrooms != null ? `${u.bedrooms} bed` : null,
												u.bathrooms != null ? `${u.bathrooms} bath` : null,
												u.sqft ? `${u.sqft} sq ft` : null,
												u.rental_type === "short" ? `short-term${u.nightly_rate ? ` · ${fmtMoney(u.nightly_rate)} a night` : ""}` : u.market_rent ? `asking ${fmtMoney(u.market_rent)}` : null
											].filter(Boolean).join(" · ")
										})]
									}),
									u.rental_type === "short" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/stays",
											search: { unit: u.id },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { className: "h-4 w-4" }), " Stays"]
										})
									}) : l ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/leases",
										search: { lease: l.id },
										className: "text-right hover:underline",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-medium",
											children: t?.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-xs text-muted-foreground",
											children: [fmtMoney(l.rent), " a month"]
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/leases",
											search: { unit: u.id },
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-4 w-4" }), " Rent it out"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										"aria-label": `Edit ${u.name}`,
										onClick: () => setUEdit({ ...u }),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
									})
								]
							}, u.id);
						})]
					})]
				}, p.id);
			})
		}),
		pEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyDialog, {
			draft: pEdit,
			onClose: () => setPEdit(null)
		}),
		uEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnitDialog, {
			draft: uEdit,
			onClose: () => setUEdit(null)
		})
	] });
}
var numOrNull = (v) => v === "" || v == null ? null : Number(v);
function PropertyDialog({ draft, onClose }) {
	const qc = useQueryClient();
	const [d, setD] = (0, import_react.useState)(draft);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	async function save() {
		if (!d.name.trim()) return void toast.error("Type a name for the property.");
		setBusy(true);
		const row = {
			name: d.name.trim(),
			address: d.address?.trim() || null,
			kind: d.kind ?? "residential",
			purchase_date: d.purchase_date || null,
			purchase_price: numOrNull(d.purchase_price),
			notes: d.notes?.trim() || null,
			is_active: d.is_active ?? true
		};
		const { error } = d.id ? await db.from("properties").update(row).eq("id", d.id) : await db.from("properties").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Property saved.");
		refreshRealEstate(qc);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: d.id ? "Edit property" : "Add property" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Purchase date and price help your accountant." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: d.name,
							onChange: (e) => set({ name: e.target.value }),
							placeholder: "Oak St Duplex"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: d.address ?? "",
							onChange: (e) => set({ address: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Kind",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: d.kind ?? "residential",
							onChange: (e) => set({ kind: e.target.value }),
							className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
							children: Object.entries(PROPERTY_KIND).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: v
							}, k))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bought on",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: d.purchase_date ?? "",
							onChange: (e) => set({ purchase_date: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price paid",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							value: d.purchase_price ?? "",
							onChange: (e) => set({ purchase_price: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: d.notes ?? "",
							onChange: (e) => set({ notes: e.target.value })
						})
					}),
					d.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: !(d.is_active ?? true),
							onChange: (e) => set({ is_active: !e.target.checked })
						}), "We no longer have this property (sold) — hide it"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save property"
			})] })
		] })
	});
}
function UnitDialog({ draft, onClose }) {
	const qc = useQueryClient();
	const [d, setD] = (0, import_react.useState)(draft);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	async function save() {
		if (!d.name.trim()) return void toast.error("Type a name for the unit.");
		setBusy(true);
		const row = {
			property_id: d.property_id,
			name: d.name.trim(),
			bedrooms: numOrNull(d.bedrooms),
			bathrooms: numOrNull(d.bathrooms),
			sqft: numOrNull(d.sqft),
			market_rent: numOrNull(d.market_rent),
			notes: d.notes?.trim() || null,
			is_active: d.is_active ?? true,
			rental_type: d.rental_type ?? "long",
			nightly_rate: numOrNull(d.nightly_rate),
			cleaning_fee: numOrNull(d.cleaning_fee),
			min_nights: numOrNull(d.min_nights),
			max_guests: numOrNull(d.max_guests),
			lodging_tax_pct: numOrNull(d.lodging_tax_pct),
			check_in_time: d.check_in_time?.trim() || null,
			check_out_time: d.check_out_time?.trim() || null,
			listing_url: d.listing_url?.trim() || null
		};
		const { error } = d.id ? await db.from("units").update(row).eq("id", d.id) : await db.from("units").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Unit saved.");
		refreshRealEstate(qc);
		onClose();
	}
	const n = (k) => ({
		type: "number",
		value: d[k] ?? "",
		onChange: (e) => set({ [k]: e.target.value })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: d.id ? "Edit unit" : "Add unit" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "An apartment, a suite, or the whole house. Rented with a lease, or by the night." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: d.name,
							onChange: (e) => set({ name: e.target.value }),
							placeholder: "Unit A"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How it's rented",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: d.rental_type ?? "long",
							onChange: (e) => set({ rental_type: e.target.value }),
							className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "long",
								children: "Long-term: a lease and monthly rent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "short",
								children: "Short-term: stays by the night (Airbnb, VRBO, direct)"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bedrooms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							...n("bedrooms"),
							step: "0.5"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bathrooms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							...n("bathrooms"),
							step: "0.5"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Square feet",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...n("sqft") })
					}),
					d.rental_type === "short" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nightly rate",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								...n("nightly_rate"),
								step: "0.01"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Cleaning fee per stay",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								...n("cleaning_fee"),
								step: "0.01"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Fewest nights",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...n("min_nights") })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Most guests",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...n("max_guests") })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Lodging tax you collect (%)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								...n("lodging_tax_pct"),
								step: "0.001",
								placeholder: "0 if the platform pays it"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Check-in / check-out time",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: d.check_in_time ?? "",
									onChange: (e) => set({ check_in_time: e.target.value }),
									placeholder: "4 PM"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: d.check_out_time ?? "",
									onChange: (e) => set({ check_out_time: e.target.value }),
									placeholder: "11 AM"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Listing link",
							wide: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.listing_url ?? "",
								onChange: (e) => set({ listing_url: e.target.value }),
								placeholder: "https://www.airbnb.com/rooms/…"
							})
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Asking rent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							...n("market_rent"),
							step: "0.01"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: d.notes ?? "",
							onChange: (e) => set({ notes: e.target.value })
						})
					}),
					d.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: !(d.is_active ?? true),
							onChange: (e) => set({ is_active: !e.target.checked })
						}), "This unit doesn't exist anymore — hide it"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save unit"
			})] })
		] })
	});
}
//#endregion
export { Properties as component };
