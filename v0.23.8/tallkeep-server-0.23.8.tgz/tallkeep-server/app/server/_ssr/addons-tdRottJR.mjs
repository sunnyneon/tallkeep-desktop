import { n as db } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/addons-tdRottJR.js
/**
* Features a company can turn on or off (Settings → Features). Turning one off only hides it
* from the menu; nothing is deleted. Stored in company_settings.addons (the ones that are on).
*/
var FEATURES = {
	sales: {
		label: "Sales",
		text: "Quotes, invoices, customers and payments received.",
		main: true
	},
	purchasing: {
		label: "Purchasing",
		text: "Purchase orders to vendors, receiving and paying them.",
		main: true
	},
	inventory: {
		label: "Inventory",
		text: "Products, stock in each place, counts, transfers and adjustments.",
		main: true
	},
	accounting: {
		label: "Accounting",
		text: "Chart of accounts, banking, bills, journal, financial reports and year-end.",
		main: true
	},
	work_orders: {
		label: "Work Orders",
		text: "Build products from parts: recipes, work orders that use parts and add finished goods.",
		main: false
	},
	real_estate: {
		label: "Real estate",
		text: "Properties, units, tenants, leases, monthly rent, deposits, a rent roll, and short-term stays (Airbnb, VRBO).",
		main: false
	},
	support: {
		label: "Support Desk",
		text: "Tickets from your customers: a support page they open tickets on, replies by email, internal notes, files, and quotes and invoices made from a ticket.",
		main: false
	},
	tickets: {
		label: "Website tickets",
		text: "Service tickets from your website become invoices; paid and invoiced status go back to the website.",
		main: false
	},
	personal: {
		label: "Personal money",
		text: "For a household: a monthly budget, net worth, investments, and household spending categories. Business pages like payroll, 1099s and sales tax are hidden.",
		main: false
	},
	crypto_tax: {
		label: "Crypto tax",
		text: "Bring in Coinbase, Kraken or other exchange history; Tallkeep works out gains and crypto income for the tax return, with Form 8949 rows.",
		main: false
	},
	tech_pay: {
		label: "Technician pay",
		text: "Track technician pay requests, what's paid, and totals per technician for taxes.",
		main: false
	}
};
var FEATURE_KEYS = Object.keys(FEATURES);
/** Kinds of business, and the features each one starts with. */
var BUSINESS_TYPES = {
	products: {
		label: "Sells products and services",
		text: "Sells goods and keeps stock, and can also sell services like installs or repairs (like a distributor or store).",
		features: [
			"sales",
			"purchasing",
			"inventory",
			"accounting"
		]
	},
	manufacturing: {
		label: "Makes products",
		text: "Builds or customizes what it sells from parts (like a sign shop or factory).",
		features: [
			"sales",
			"purchasing",
			"inventory",
			"accounting",
			"work_orders"
		]
	},
	services: {
		label: "Services only",
		text: "Does jobs for customers with no stock to keep: installs, repairs, consulting.",
		features: [
			"sales",
			"purchasing",
			"accounting",
			"support"
		]
	},
	real_estate: {
		label: "Real estate",
		text: "Owns or manages properties: long-term rentals or short stays like Airbnb.",
		features: ["accounting", "real_estate"]
	},
	personal: {
		label: "Personal or family money",
		text: "Your own money, like Quicken: bank and card accounts, bills, a budget, net worth and investments.",
		features: ["accounting", "personal"]
	},
	other: {
		label: "Something else",
		text: "Start with the basics and turn on what you need.",
		features: ["sales", "accounting"]
	}
};
var BUSINESS_TYPE_KEYS = Object.keys(BUSINESS_TYPES);
/**
* What the license opens (null = everything: trials, online plans, keys from before editions).
* Kept on the account (orgs.licensed_features), written by the office computer from its key.
*/
function useLicensed() {
	return useQuery({
		queryKey: ["licensed-features"],
		staleTime: 3e5,
		queryFn: async () => {
			const { data, error } = await db.from("orgs").select("licensed_features").maybeSingle();
			if (error) return null;
			return data?.licensed_features ?? null;
		}
	});
}
/** Features turned on for the company I'm working in, and paid for (null while loading). */
function useFeatures() {
	const { data: licensed } = useLicensed();
	const q = useQuery({
		queryKey: ["company-addons"],
		staleTime: 3e5,
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("addons").maybeSingle();
			if (error) return [...FEATURE_KEYS];
			return data?.addons ?? [];
		}
	});
	return {
		...q,
		data: q.data && licensed ? q.data.filter((f) => licensed.includes(f)) : q.data
	};
}
/** Older names, still used in a few places. */
var ADDONS = FEATURES;
var useAddons = useFeatures;
//#endregion
export { FEATURE_KEYS as a, useLicensed as c, FEATURES as i, BUSINESS_TYPES as n, useAddons as o, BUSINESS_TYPE_KEYS as r, useFeatures as s, ADDONS as t };
