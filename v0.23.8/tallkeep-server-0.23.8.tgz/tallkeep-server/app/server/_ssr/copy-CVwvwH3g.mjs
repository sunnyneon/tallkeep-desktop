//#region ../../node_modules/.nitro/vite/services/ssr/assets/copy-CVwvwH3g.js
/**
* Copy text to the clipboard. Browsers only allow the modern way on https pages, so on the office
* network (http://192.168…) it falls back to the older way. Returns false if neither worked.
*/
async function copyText(text) {
	try {
		if (typeof navigator !== "undefined" && navigator.clipboard && window.isSecureContext) {
			await navigator.clipboard.writeText(text);
			return true;
		}
	} catch {}
	try {
		const t = document.createElement("textarea");
		t.value = text;
		t.setAttribute("readonly", "");
		t.style.position = "fixed";
		t.style.top = "-1000px";
		document.body.appendChild(t);
		t.select();
		const ok = document.execCommand("copy");
		t.remove();
		return ok;
	} catch {
		return false;
	}
}
//#endregion
export { copyText as t };
