import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as SalesList } from "./SalesList-SEVyxqIk.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/quotes-DDWO1oSv.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesList, {
	title: "Quotes",
	text: "Price quotes for customers.",
	newKind: "quote",
	newLabel: "New sales quote",
	initial: {
		show: "quotes",
		inv: "all",
		pay: "all",
		cancelled: false
	}
});
//#endregion
export { SplitComponent as component };
