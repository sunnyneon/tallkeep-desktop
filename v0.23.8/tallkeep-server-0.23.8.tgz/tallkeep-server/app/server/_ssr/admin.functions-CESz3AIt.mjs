import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C7DN5EUT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/admin.functions-CESz3AIt.js
/** The control panel is for admins of our own group (the Tallkeep owners) only. */
async function requireOwner(userId) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
	const { data: m } = await supabaseAdmin.from("org_members").select("orgs(is_platform)").eq("user_id", userId).maybeSingle();
	if (!data || !m?.orgs?.is_platform) throw new Error("Only Tallkeep owners can open the admin panel.");
	return supabaseAdmin;
}
var listAccounts = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("8c56746723b59acb7fff2062af8cf1b67256fe267c1b064d2d55aadbe60477ad"));
var changeAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const bad = (n) => n != null && (!Number.isInteger(n) || n < 1 || n > 1e3);
	if (bad(d.companies_allowed) || bad(d.users_allowed)) throw new Error("Type a whole number from 1 to 1000, or leave it empty for no limit.");
	if (d.status && ![
		"trial",
		"active",
		"past_due",
		"canceled"
	].includes(d.status)) throw new Error("Pick a status.");
	if (d.edition && !["cloud", "desktop"].includes(d.edition)) throw new Error("Pick a version.");
	return d;
}).handler(createSsrRpc("9423a679c9df2f139cb12313a6efb5e9668960218a0e540c16ac757a25d12b4a"));
/** Is the signed-in person a Tallkeep owner? (Opens the admin panel.) */
var amIOwner = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("52ae71e6cfacb229eefce10e007b4d0a433e4dce525a87615321e3d6b52ab56c"));
/** One customer account: its companies, people and this month's AI use. */
var accountDetail = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("5a54f5d01d810c6d5e874565da0aeb5aadeade5c8114b4385004d9622e252c91"));
/** Tallkeep's price list (also shown on tallkeep.com/pricing). */
async function readPrices() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("platform_settings").select("value,updated_at").eq("key", "prices").maybeSingle();
	const row = data;
	return row ? {
		prices: row.value,
		updated_at: row.updated_at
	} : null;
}
var getPrices = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("ca683ec40b811885e1486d71d87808c320b5bf90f0646637e04e8cfcb4f839b5"));
/** Is Stripe set to real payments or test payments? (Only the kind of key, never the key.) */
var getStripeMode = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("f8a1ed20652c12e2e24874cef1b7a091f0b7173c31ae6a7c2a8b444dc9c4ad4e"));
var savePrices = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const walk = (o) => typeof o === "number" ? Number.isFinite(o) && o >= 0 && o <= 1e5 : typeof o === "object" && o !== null && Object.values(o).every(walk);
	if (!walk(d)) throw new Error("Every price must be a number from 0 to 100,000.");
	if (d.trial_days < 1 || d.trial_days > 365) throw new Error("The free trial must be 1 to 365 days.");
	return d;
}).handler(createSsrRpc("34f565de0ecb973594612848b517ea391eeac0fb71632eadf4ed88a61b35e07a"));
/** The waitlist and contact messages from tallkeep.com (read through the website's locked link). */
var listWaitlist = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("a2d9697780227560abcb1156f5bdea1ac030d03848cf0ea525e850d95e904a84"));
/**
* Delete an ended online account for good: its companies and all their books, its files, and
* its people's sign-ins. Only after the plan ended more than 90 days ago. The owner presses it.
*/
var deleteClosedAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("f2eef172c5bd4f6efbae6f978078f0eb44647d7c3ff761fe3a131e2ba11d28a4"));
//#endregion
export { accountDetail, amIOwner, changeAccount, deleteClosedAccount, getPrices, getStripeMode, listAccounts, listWaitlist, readPrices, requireOwner, savePrices };
