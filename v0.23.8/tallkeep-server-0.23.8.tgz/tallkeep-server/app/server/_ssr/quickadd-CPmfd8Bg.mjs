import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/quickadd-CPmfd8Bg.js
/**
* Make a new customer, vendor, payment term, location or category from just a name, right
* where it's needed (an invoice, a purchase order…). The rest can be filled in later on its page.
*/
var T = (t) => db.from(t);
async function add(table, row, what) {
	const name = String(row["name"] ?? "").trim();
	if (!name) throw new Error(`Type the ${what}'s name.`);
	const { data: had } = await T(table).select("id").ilike("name", name).limit(1).maybeSingle();
	if (had?.id) return had.id;
	const { data, error } = await T(table).insert({
		...row,
		name
	}).select("id").single();
	if (error) throw new Error(error.message);
	return data.id;
}
var addCustomer = (name) => add("customers", { name }, "customer");
var addVendor = (name) => add("vendors", { name }, "vendor");
var addLocation = (name) => add("locations", { name }, "location");
var addCategory = (name) => add("categories", { name }, "category");
/** "Net 30" becomes 30 days; "Due on receipt" 0. */
var addTerms = (name) => {
	const n = /(\d+)/.exec(name);
	const days = /receipt|cod|cash/i.test(name) ? 0 : n ? Number(n[1]) : null;
	return add("payment_terms", {
		name,
		...days != null ? { days_due: days } : {}
	}, "term");
};
function useAdder(make, keys) {
	const qc = useQueryClient();
	return async (name) => {
		const id = await make(name);
		await Promise.all(keys.map((k) => qc.invalidateQueries({ queryKey: k })));
		return id;
	};
}
var useAddVendor = () => useAdder(addVendor, [["vendors"], ["vendors-lite"]]);
var useAddCustomer = () => useAdder(addCustomer, [["customers"], ["customers-lite"]]);
var useAddCategory = () => useAdder(addCategory, [["categories"]]);
//#endregion
export { useAddCategory as a, addVendor as i, addLocation as n, useAddCustomer as o, addTerms as r, useAddVendor as s, addCustomer as t };
