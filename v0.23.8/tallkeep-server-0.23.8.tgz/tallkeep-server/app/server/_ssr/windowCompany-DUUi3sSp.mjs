//#region ../../node_modules/.nitro/vite/services/ssr/assets/windowCompany-DUUi3sSp.js
/**
* Each window works in its own company. The window remembers which company it shows (for this
* tab only) and sends it with every database request, so switching company in another window,
* on another computer or on the phone never moves where this window saves.
* The database checks you may use that company; without it (older database) nothing changes.
*/
var KEY = "tk-window-company";
var HEADER = "x-tallkeep-company";
var current = null;
var installed = false;
var read = () => {
	try {
		return sessionStorage.getItem(KEY);
	} catch {
		return null;
	}
};
/** The company this window shows (null until known). */
var windowCompany = () => current;
/** Remember the company this window works in. */
function setWindowCompany(id) {
	current = id;
	try {
		if (id) sessionStorage.setItem(KEY, id);
		else sessionStorage.removeItem(KEY);
	} catch {}
}
/** Send the window's company with every database request. Call once, in the browser. */
function installWindowCompany() {
	if (installed || typeof window === "undefined") return;
	installed = true;
	current = read();
	const orig = window.fetch.bind(window);
	window.fetch = (input, init) => {
		if (!current) return orig(input, init);
		const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
		if (!/\/rest\/v1\//.test(url)) return orig(input, init);
		const headers = new Headers(init?.headers ?? (typeof input !== "string" && !(input instanceof URL) ? input.headers : void 0));
		headers.set(HEADER, current);
		return orig(input, {
			...init,
			headers
		});
	};
}
//#endregion
export { setWindowCompany as n, windowCompany as r, installWindowCompany as t };
