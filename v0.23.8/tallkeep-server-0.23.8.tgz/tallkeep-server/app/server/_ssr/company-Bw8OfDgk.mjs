import { n as db } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as setWindowCompany, r as windowCompany } from "./windowCompany-DUUi3sSp.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/company-Bw8OfDgk.js
/** The companies I can open; the active one has active = true. */
function useMyCompanies(enabled = true) {
	return useQuery({
		queryKey: ["my-companies"],
		enabled,
		staleTime: 3e5,
		queryFn: async () => {
			const { data, error } = await db.rpc("my_companies");
			if (error) return [];
			const list = data ?? [];
			const active = list.find((c) => c.active)?.id;
			if (active && !windowCompany()) setWindowCompany(active);
			return list;
		}
	});
}
/** Id of the company I'm working in (records are saved to it). */
async function activeCompanyId() {
	const { data, error } = await db.rpc("active_company");
	if (error) return null;
	const id = data ?? null;
	if (id && !windowCompany()) setWindowCompany(id);
	return id;
}
/** Switch company, close the open tabs and start at Home with the new company's records. */
async function switchCompany(id) {
	const { error } = await db.rpc("set_active_company", { _c: id });
	if (error) throw error;
	setWindowCompany(id);
	try {
		localStorage.removeItem("open-tabs");
	} catch {}
	window.location.assign("/");
}
//#endregion
export { switchCompany as n, useMyCompanies as r, activeCompanyId as t };
