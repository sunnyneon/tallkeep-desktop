import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel, s as dayBefore } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { H as Pencil, R as Plus, Rt as FileCheck, g as Trash2, j as Scale } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-aFR9SgbK.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { t as Route } from "./journal-BPKNDP1j.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/journal-CPenFZb5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPE_NAME = {
	invoice: "Invoice",
	invoice_cogs: "Cost of goods",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	stock: "Stock change",
	bill: "Bill",
	bill_payment: "Bill payment",
	manual: "Typed by hand",
	opening: "Opening balance",
	bank: "Bank",
	adjust: "Accountant adjustment",
	history: "From QuickBooks",
	rent_charge: "Rent charge",
	rent_payment: "Rent received",
	work_order: "Work order",
	check: "Check / payment",
	deposit: "Deposit",
	transfer: "Transfer"
};
var HAND = [
	"manual",
	"opening",
	"adjust"
];
function Journal() {
	const search = Route.useSearch();
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const [show, setShow] = (0, import_react.useState)("hand");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [editor, setEditor] = (0, import_react.useState)(search.opening ? "opening" : search.adjust ? "adjust" : null);
	const [open, setOpen] = (0, import_react.useState)(null);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const { data, isLoading } = useQuery({
		queryKey: [
			"journal",
			show,
			from,
			to
		],
		queryFn: async () => {
			let q = db.from("journal_entries").select("id,entry_date,memo,ref,source_type,journal_lines(debit,credit,account_id,memo)").order("entry_date", { ascending: false }).limit(2e3);
			if (show === "hand") q = q.in("source_type", HAND);
			if (from) q = q.gte("entry_date", from);
			if (to) q = q.lte("entry_date", to);
			const { data, error } = await q;
			if (error) throw error;
			return data ?? [];
		}
	});
	const name = (0, import_react.useMemo)(() => {
		const m = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
		return (id) => m.get(id) ?? "";
	}, [accounts]);
	async function del(e) {
		if (!window.confirm("Delete this journal entry?")) return;
		const { error } = await db.from("journal_entries").delete().eq("id", e.id);
		if (error) return void toast.error(error.message);
		toast.success("Entry deleted.");
		qc.invalidateQueries({ queryKey: ["journal"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Journal Entries",
			text: "Invoices, payments, purchase orders, bills and stock changes write their own entries. Type an entry by hand for anything else, like owner money, loans or depreciation.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setEditor("opening"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, { className: "h-4 w-4" }), " Opening balances"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setEditor("adjust"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4" }), " Accountant adjustment"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setEditor("manual"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New journal entry"]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex rounded-lg border p-0.5",
					children: ["hand", "all"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShow(v),
						className: `rounded-md px-3 py-1 ${show === v ? "bg-[var(--section)] text-white" : ""}`,
						children: v === "hand" ? "Typed by hand" : "All entries"
					}, v))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value)
					})]
				})
			]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [(data ?? []).map((e) => {
				const amt = e.journal_lines.reduce((s, l) => s + Number(l.debit), 0);
				const hand = HAND.includes(e.source_type);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex w-full items-center gap-3 px-4 py-2 text-left hover:bg-muted/40",
					onClick: () => setOpen(open === e.id ? null : e.id),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 shrink-0",
							children: fmtDate(e.entry_date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-36 shrink-0 text-muted-foreground",
							children: TYPE_NAME[e.source_type] ?? e.source_type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 shrink-0",
							children: e.ref
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate",
							children: e.memo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-28 text-right font-medium tabular-nums",
							children: fmtMoney(amt)
						})
					]
				}), open === e.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-muted/20 px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Account"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Memo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Debit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Credit"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: e.journal_lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1",
								children: name(l.account_id)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-muted-foreground",
								children: l.memo
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: Number(l.debit) ? fmtMoney(l.debit) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: Number(l.credit) ? fmtMoney(l.credit) : ""
							})
						] }, i)) })]
					}), hand && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setEditing(e),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5" }), " Change this entry"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void del(e),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" }), " Delete this entry"]
						})]
					})]
				})] }, e.id);
			}), data && data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: show === "hand" ? "No entries typed by hand yet." : "No entries yet."
			})]
		}),
		editor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryDialog, {
			mode: editor,
			onClose: () => setEditor(null)
		}),
		editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntryDialog, {
			mode: editing.source_type ?? "manual",
			edit: editing,
			onClose: () => setEditing(null)
		})
	] });
}
var blank = () => ({
	id: crypto.randomUUID(),
	account_id: null,
	debit: 0,
	credit: 0,
	memo: ""
});
function EntryDialog({ mode, edit, onClose }) {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: start } = useQuery({
		queryKey: ["books-start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
	const opening = mode === "opening";
	const adjust = mode === "adjust";
	const [date, setDate] = (0, import_react.useState)(edit ? edit.entry_date : adjust && (/* @__PURE__ */ new Date()).getMonth() < 6 ? `${(/* @__PURE__ */ new Date()).getFullYear() - 1}-12-31` : today());
	const [memo, setMemo] = (0, import_react.useState)(edit ? edit.memo ?? "" : opening ? "Opening balances" : "");
	const [lines, setLines] = (0, import_react.useState)(edit ? edit.journal_lines.map((l) => ({
		...blank(),
		account_id: l.account_id,
		debit: Number(l.debit),
		credit: Number(l.credit),
		memo: l.memo ?? ""
	})) : [blank(), blank()]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const options = (accounts ?? []).filter((a) => a.is_active).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	const equity = accounts?.find((a) => a.key === "opening");
	const dr = lines.reduce((s, l) => s + (Number(l.debit) || 0), 0);
	const cr = lines.reduce((s, l) => s + (Number(l.credit) || 0), 0);
	const diff = Math.round((dr - cr) * 100) / 100;
	const entryDate = opening && start ? dayBefore(start) : date;
	const patch = (i, p) => setLines((ls) => ls.map((l, j) => j === i ? {
		...l,
		...p
	} : l));
	const { data: owedBefore } = useQuery({
		queryKey: ["owed-before", start],
		enabled: opening && !!start,
		queryFn: async () => {
			const { data } = await db.from("sales_orders").select("balance,invoice_date,order_date,status,number").in("status", [
				"invoiced",
				"paid",
				"completed"
			]).gt("balance", 0).limit(1e4);
			return (data ?? []).filter((o) => !o.number.startsWith("RMA-") && (o.invoice_date ?? o.order_date).slice(0, 10) < start).reduce((t, o) => t + Number(o.balance), 0);
		}
	});
	const ar = accounts?.find((a) => a.key === "ar");
	(0, import_react.useEffect)(() => {
		if (!opening || edit || !ar || !owedBefore) return;
		setLines((ls) => ls.some((l) => l.account_id === ar.id) ? ls : [{
			...blank(),
			account_id: ar.id,
			debit: Math.round(owedBefore * 100) / 100,
			memo: "Open invoices"
		}, ...ls.slice(1)]);
	}, [
		opening,
		ar,
		owedBefore
	]);
	async function save() {
		let used = lines.filter((l) => l.account_id && (Number(l.debit) || Number(l.credit)));
		if (opening && diff !== 0 && equity) used = [...used, {
			...blank(),
			account_id: equity.id,
			debit: diff < 0 ? -diff : 0,
			credit: diff > 0 ? diff : 0,
			memo: "Balancing amount"
		}];
		const d2 = used.reduce((s, l) => s + (Number(l.debit) || 0), 0);
		const c2 = used.reduce((s, l) => s + (Number(l.credit) || 0), 0);
		if (!used.length) return void toast.error("Add at least two lines with an account and an amount.");
		if (Math.round((d2 - c2) * 100) !== 0) return void toast.error(`Debits and credits must be equal (off by ${fmtMoney(Math.abs(d2 - c2))}).`);
		if (opening && !start) return void toast.error("Set the books start date in Settings → Accounting first.");
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			if (edit) {
				const a = await db.from("journal_entries").update({
					entry_date: edit.source_type === "opening" ? entryDate : date,
					memo: memo.trim() || null
				}).eq("id", edit.id);
				if (a.error) throw a.error;
				const b = await db.from("journal_lines").delete().eq("entry_id", edit.id);
				if (b.error) throw b.error;
				const c = await db.from("journal_lines").insert(used.map((l) => ({
					entry_id: edit.id,
					account_id: l.account_id,
					debit: Math.round((Number(l.debit) || 0) * 100) / 100,
					credit: Math.round((Number(l.credit) || 0) * 100) / 100,
					memo: l.memo.trim() || null
				})));
				if (c.error) throw c.error;
				toast.success("Entry changed.");
				qc.invalidateQueries({ queryKey: ["journal"] });
				qc.invalidateQueries({ queryKey: ["account-totals"] });
				qc.invalidateQueries({ queryKey: ["account-lines"] });
				onClose();
				return;
			}
			const { data: e, error } = await db.from("journal_entries").insert({
				entry_date: entryDate,
				memo: memo.trim() || null,
				source_type: mode,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("journal_lines").insert(used.map((l) => ({
				entry_id: e.id,
				account_id: l.account_id,
				debit: Math.round((Number(l.debit) || 0) * 100) / 100,
				credit: Math.round((Number(l.credit) || 0) * 100) / 100,
				memo: l.memo.trim() || null
			})));
			if (le) {
				await db.from("journal_entries").delete().eq("id", e.id);
				throw le;
			}
			toast.success(opening ? "Opening balances saved." : adjust ? "Adjustment saved." : "Journal entry saved.");
			qc.invalidateQueries({ queryKey: ["journal"] });
			qc.invalidateQueries({ queryKey: ["account-totals"] });
			onClose();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: edit ? "Change this entry" : opening ? "Opening balances" : adjust ? "Accountant adjustment" : "New journal entry" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: opening ? `What each account held the day before your books start${start ? ` (${fmtDate(dayBefore(start))})` : ""}: bank balances, loans, equipment, credit cards… Take them from your old system's Balance Sheet. Anything left over goes to Opening Balance Equity.` : adjust ? "A change your accountant (CPA) gives you at year-end, like depreciation or a correction. It shows in its own column on the Trial Balance. Debits and credits must be equal." : "Each line moves money into (debit) or out of (credit) an account. Debits and credits must be equal." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-[10rem_1fr]",
					children: [!opening && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Memo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: memo,
							onChange: (e) => setMemo(e.target.value)
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[45vh] divide-y overflow-y-auto rounded-xl border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,2fr)_7rem_7rem_minmax(0,1fr)_2rem] gap-2 bg-muted/40 px-2 py-1 text-xs text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Account" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right",
								children: "Debit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right",
								children: "Credit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Memo" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						]
					}), lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,2fr)_7rem_7rem_minmax(0,1fr)_2rem] gap-2 p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: l.account_id,
								options,
								placeholder: "Account",
								onChange: (v) => patch(i, { account_id: v })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								className: "text-right",
								value: l.debit || "",
								onChange: (e) => patch(i, {
									debit: Number(e.target.value),
									credit: 0
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								className: "text-right",
								value: l.credit || "",
								onChange: (e) => patch(i, {
									credit: Number(e.target.value),
									debit: 0
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: l.memo,
								onChange: (e) => patch(i, { memo: e.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Remove line",
								onClick: () => setLines((ls) => ls.length > 2 ? ls.filter((_, j) => j !== i) : ls),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, l.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setLines((ls) => [...ls, blank()]),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: diff === 0 ? "text-muted-foreground" : opening ? "text-muted-foreground" : "font-medium text-destructive",
						children: [
							"Debits ",
							fmtMoney(dr),
							" · Credits ",
							fmtMoney(cr),
							diff !== 0 && (opening ? ` · ${fmtMoney(Math.abs(diff))} goes to Opening Balance Equity` : ` · off by ${fmtMoney(Math.abs(diff))}`)
						]
					})]
				}),
				opening && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Tip: assets (bank, equipment) go in Debit; what you owe (loans, credit cards, unpaid bills) goes in Credit. Accounts Receivable starts at what customers still owe on invoices from before the start date."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Saving…" : opening ? "Save opening balances" : adjust ? "Save adjustment" : "Save entry"
				})] })
			]
		})
	});
}
//#endregion
export { Journal as component };
