import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { o as balanceOf, u as loadTotals } from "./accounting-BZzWF9St.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/personal-C-Op5nYv.js
/**
* Personal money: monthly budgets, investment holdings, and what accounts are worth today.
* Budgets and holdings live in their own tables (step 43); spending comes from the books.
*/
var table = (t) => db.from(t);
function useBudgets() {
	return useQuery({
		queryKey: ["budgets"],
		queryFn: async () => (await fetchAll("budgets", "id,account_id,amount")).map((b) => ({
			...b,
			amount: Number(b.amount)
		}))
	});
}
function useHoldings() {
	return useQuery({
		queryKey: ["holdings"],
		queryFn: async () => (await fetchAll("holdings", "id,account_id,symbol,name,shares,cost,price,price_date,notes")).map((h) => ({
			...h,
			shares: Number(h.shares),
			cost: Number(h.cost),
			price: Number(h.price)
		})).sort((a, b) => (a.symbol ?? a.name).localeCompare(b.symbol ?? b.name))
	});
}
var holdingValue = (h) => Math.round(h.shares * h.price * 100) / 100;
/** "2026-10" → first and last day of that month. */
function monthRange(ym) {
	const [y, m] = ym.split("-").map(Number);
	const last = new Date(y, m, 0).getDate();
	return {
		from: `${ym}-01`,
		to: `${ym}-${String(last).padStart(2, "0")}`
	};
}
var thisMonth = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA").slice(0, 7);
function addMonths(ym, n) {
	const [y, m] = ym.split("-").map(Number);
	const d = new Date(y, m - 1 + n, 1);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
var monthName = (ym, short = false) => (/* @__PURE__ */ new Date(`${ym}-15T12:00:00`)).toLocaleDateString("en-US", {
	month: short ? "short" : "long",
	year: "numeric"
});
/** Spending (or income) in a category for a set of totals, as a positive number. */
var amountIn = (a, t) => {
	const x = t?.get(a.id);
	return x ? balanceOf(a.type, x.debit, x.credit) : 0;
};
/**
* What each asset or debt is worth: an investment account with holdings is worth its holdings
* (shares × latest price); everything else is its balance in the books.
*/
function worth(accounts, totals, holdings = []) {
	const held = /* @__PURE__ */ new Map();
	for (const h of holdings) held.set(h.account_id, (held.get(h.account_id) ?? 0) + holdingValue(h));
	const value = (a) => held.get(a.id) ?? amountIn(a, totals);
	const have = accounts.filter((a) => a.type === "asset");
	const owe = accounts.filter((a) => a.type === "liability");
	const sum = (l) => l.reduce((s, a) => s + value(a), 0);
	return {
		have,
		owe,
		value,
		totalHave: sum(have),
		totalOwe: sum(owe),
		net: sum(have) - sum(owe)
	};
}
/** Net worth at the end of each of the last n months (from the books). */
async function netWorthByMonth(accounts, n = 12) {
	const now = thisMonth();
	const months = Array.from({ length: n }, (_, i) => addMonths(now, i - n + 1));
	return await Promise.all(months.map(async (ym) => {
		const t = await loadTotals(null, monthRange(ym).to);
		return {
			month: monthName(ym, true),
			net: Math.round(worth(accounts, t).net)
		};
	}));
}
/** Kinds of things you own or owe, in plain words. */
var HAVE_GROUPS = [
	{
		label: "Cash in the bank",
		kinds: ["bank"]
	},
	{
		label: "Investments and retirement",
		kinds: ["other_asset"]
	},
	{
		label: "Home, cars and other things",
		kinds: ["fixed_asset", "inventory"]
	},
	{
		label: "Money owed to you",
		kinds: ["ar"]
	}
];
var OWE_GROUPS = [
	{
		label: "Credit cards",
		kinds: ["credit_card"]
	},
	{
		label: "Loans and mortgage",
		kinds: ["long_term_liability"]
	},
	{
		label: "Other bills you owe",
		kinds: ["ap", "other_liability"]
	}
];
/** Investment and retirement accounts (other current assets the app doesn't use for itself). */
var isInvestment = (a) => a.kind === "other_asset" && (!a.key || a.key === "investments");
/**
* Totals per account for one person: only entries that touch one of their accounts (a card or
* bank account of theirs), so their spending by category shows.
*/
async function loadTotalsFor(from, to, theirs) {
	const rows = [];
	for (let i = 0;; i += 1e3) {
		const { data, error } = await db.from("journal_lines").select("entry_id,account_id,debit,credit,journal_entries!inner(entry_date)").gte("journal_entries.entry_date", from).lte("journal_entries.entry_date", to).range(i, i + 999);
		if (error) throw error;
		rows.push(...data ?? []);
		if (!data || data.length < 1e3) break;
	}
	const mine = new Set(theirs);
	const entries = new Set(rows.filter((r) => mine.has(r.account_id)).map((r) => r.entry_id));
	const m = /* @__PURE__ */ new Map();
	for (const r of rows) {
		if (!entries.has(r.entry_id)) continue;
		const t = m.get(r.account_id) ?? {
			debit: 0,
			credit: 0
		};
		t.debit += Number(r.debit);
		t.credit += Number(r.credit);
		m.set(r.account_id, t);
	}
	return m;
}
//#endregion
export { holdingValue as a, monthName as c, table as d, thisMonth as f, worth as h, amountIn as i, monthRange as l, useHoldings as m, OWE_GROUPS as n, isInvestment as o, useBudgets as p, addMonths as r, loadTotalsFor as s, HAVE_GROUPS as t, netWorthByMonth as u };
