import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { G as Paperclip, n as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as fileSize, o as fileToBase64 } from "./support-Bri7jlNl.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/HelpParts-B_4ECnnO.js
var import_jsx_runtime = require_jsx_runtime();
/** Pieces of the public support pages (/help/…). */
function HelpFrame({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-[#F4F6F9] px-4 py-8 text-slate-900 dark:bg-slate-950 dark:text-slate-100",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-bold sm:text-3xl",
					children: title
				}),
				children,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "pt-4 text-center text-xs text-slate-500",
					children: [
						"Support by",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://tallkeep.com",
							className: "underline",
							target: "_blank",
							rel: "noreferrer",
							children: "Tallkeep"
						})
					]
				})
			]
		})
	});
}
function FilesPicker({ files, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [files.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4 shrink-0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: f.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-xs text-slate-500",
					children: fileSize(f.size)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Remove ${f.name}`,
					onClick: () => onChange(files.filter((_, k) => k !== i)),
					className: "rounded p-0.5 hover:bg-slate-200 dark:hover:bg-slate-800",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})
			]
		}, i)), files.length < 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 text-sm hover:bg-slate-100 dark:hover:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
				" Add photos or files",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					multiple: true,
					className: "hidden",
					onChange: (e) => {
						const picked = [...e.target.files ?? []];
						e.target.value = "";
						if (picked.filter((f) => f.size > 8388608).length) toast.error(`Files must be under 8 MB.`);
						onChange([...files, ...picked.filter((f) => f.size <= 8388608)].slice(0, 4));
					}
				})
			]
		})]
	});
}
var toUpload = (files) => Promise.all(files.map(async (f) => ({
	name: f.name,
	type: f.type,
	base64: await fileToBase64(f)
})));
//#endregion
export { HelpFrame as n, toUpload as r, FilesPicker as t };
