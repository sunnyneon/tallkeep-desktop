import { n as db } from "./db-C-LmScFU.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stockmove-Y4hmnaPQ.js
/** Remember a shelf name so it shows in the pick lists. */
async function ensureShelf(locationId, name) {
	const n = name.trim();
	if (!n) return;
	await db.from("shelves").upsert({
		location_id: locationId,
		name: n
	}, {
		onConflict: "location_id,name",
		ignoreDuplicates: true
	});
}
/** Move everything in these spots to one place/shelf. Skips spots already there or with nothing in them. */
async function moveSpots(spots, toLocation, toShelf, note = "Moved to new shelf") {
	const shelf = toShelf.trim();
	await ensureShelf(toLocation, shelf);
	const done = [];
	for (const s of spots) {
		const qty = Number(s.qty);
		if (qty <= 0 || s.location_id === toLocation && s.shelf === shelf) continue;
		const { error } = await db.rpc("move_stock", {
			_product_id: s.product_id,
			_from_location: s.location_id,
			_from_shelf: s.shelf,
			_to_location: toLocation,
			_to_shelf: shelf,
			_qty: qty,
			_note: note
		});
		if (error) throw new Error(error.message);
		done.push({
			from: s,
			to_location: toLocation,
			to_shelf: shelf,
			qty
		});
	}
	return done;
}
/** Put moved items back where they were. */
async function undoMoves(moves) {
	for (const m of moves) {
		const { error } = await db.rpc("move_stock", {
			_product_id: m.from.product_id,
			_from_location: m.to_location,
			_from_shelf: m.to_shelf,
			_to_location: m.from.location_id,
			_to_shelf: m.from.shelf,
			_qty: m.qty,
			_note: "Undo move"
		});
		if (error) throw new Error(error.message);
	}
}
//#endregion
export { moveSpots as n, undoMoves as r, ensureShelf as t };
