-- 065: Move a quote (or an unpaid, unfulfilled, not-yet-booked invoice) to another company:
-- for one made in the wrong company. It gets that company's next number; its customer is matched
-- by name there, or copied over; its items are matched by name there (or kept as text).
create or replace function public.move_sales_order(_id uuid, _to uuid)
returns text language plpgsql security definer set search_path = public as $$
declare o record; c record; k text; p text; n int; cust uuid; num text; tname text;
begin
  if auth.uid() is null or not public.is_company_admin(auth.uid()) then
    raise exception 'Only an admin can move documents between companies';
  end if;
  select * into o from public.sales_orders where id = _id for update;
  if o.id is null or not public.can_use_company(auth.uid(), o.company_id) then raise exception 'Not found'; end if;
  if not public.can_use_company(auth.uid(), _to) then raise exception 'You can''t use that company'; end if;
  if o.company_id = _to then raise exception 'It is already in that company'; end if;
  if o.stock_taken_at is not null or exists (select 1 from public.sales_order_lines where sales_order_id = _id and qty_fulfilled > 0) then
    raise exception 'Items on it already went out of stock; undo that first';
  end if;
  if exists (select 1 from public.payments where sales_order_id = _id) then
    raise exception 'It has payments; remove them first';
  end if;
  if exists (select 1 from public.journal_entries where source_id = _id) then
    raise exception 'It is already in the books; make it again in the other company and delete this one';
  end if;
  select name into tname from public.companies where id = _to;

  -- The customer: the same name there, or a copy.
  if o.customer_id is not null then
    select * into c from public.customers where id = o.customer_id;
    select id into cust from public.customers
     where company_id = _to and lower(trim(name)) = lower(trim(c.name)) limit 1;
    if cust is null then
      cust := gen_random_uuid();
      insert into public.customers
      select (jsonb_populate_record(null::public.customers,
                to_jsonb(c) || jsonb_build_object('id', cust, 'company_id', _to))).*;
    end if;
  end if;

  -- That company's next number.
  k := case when o.status in ('quote','rma') then case when o.status = 'rma' then 'rma' else 'quote' end else 'sales_order' end;
  update public.doc_counters set next_number = next_number + 1
   where company_id = _to and kind = k returning prefix, next_number - 1 into p, n;
  num := case when p is null then o.number else p || lpad(n::text, 6, '0') end;

  update public.sales_orders set company_id = _to, customer_id = coalesce(cust, customer_id), number = num
   where id = _id;
  -- Items: the same item there by name, otherwise the line keeps its words and price.
  update public.sales_order_lines l set company_id = _to,
    product_id = case when l.product_id is null then null
                      when exists (select 1 from public.products x where x.id = l.product_id and x.company_id = _to) then l.product_id
                      else (select y.id from public.products y join public.products z on z.id = l.product_id
                             where y.company_id = _to and lower(y.name) = lower(z.name) limit 1) end
   where l.sales_order_id = _id;
  return format('Moved to %s as %s.', tname, num);
end $$;
grant execute on function public.move_sales_order(uuid, uuid) to authenticated;
notify pgrst, 'reload schema';
