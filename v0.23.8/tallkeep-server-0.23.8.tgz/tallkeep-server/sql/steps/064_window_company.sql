-- 064: Each window works in its own company.
-- Before: the company you work in was one setting per person, so switching company in one window
-- (or on another computer or the phone) quietly moved where another window saved its records.
-- Now each window sends the company it shows (header x-tallkeep-company) and records go there.
-- Without the header (older app, server jobs) it works as before: the last company you chose.
create or replace function public.active_company()
returns uuid language sql stable security definer set search_path = public as $$
  select coalesce(
    (select h.c from (
        select case when x ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
                    then x::uuid end as c
          from (select coalesce(current_setting('request.headers', true), '{}')::json ->> 'x-tallkeep-company' as x) r
      ) h
      where h.c is not null and public.can_use_company(auth.uid(), h.c)),
    (select uc.company_id from public.user_company uc
      where uc.user_id = auth.uid() and public.can_use_company(auth.uid(), uc.company_id)),
    (select c.id from public.companies c
      where public.can_use_company(auth.uid(), c.id) order by c.created_at, c.name limit 1)
  )
$$;
grant execute on function public.active_company() to authenticated;
notify pgrst, 'reload schema';
