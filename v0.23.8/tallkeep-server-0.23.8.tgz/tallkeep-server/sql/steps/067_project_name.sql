-- 067: Project name on quotes and invoices (printed on them).
alter table public.sales_orders add column if not exists project_name text;
notify pgrst, 'reload schema';
