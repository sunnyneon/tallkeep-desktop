-- 058: Count product photos in an account's storage too (they're kept as products/<id>/…).
create or replace function public.org_storage_used(_org uuid)
returns bigint language sql stable security definer set search_path = public, storage as $$
  select coalesce(sum((o.metadata->>'size')::bigint), 0)::bigint
    from storage.objects o
   where (o.bucket_id in ('receipts', 'ticket-files')
          and split_part(o.name, '/', 1) in (select c.id::text from public.companies c where c.org_id = _org))
      or (o.bucket_id = 'product-photos'
          and public.photo_company(o.name) in (select c.id from public.companies c where c.org_id = _org))
$$;
revoke all on function public.org_storage_used(uuid) from public, anon, authenticated;
grant execute on function public.org_storage_used(uuid) to service_role;
