-- 055: The Shoebox list stays short. "Remove from the list" hides an item (the file is kept and
-- can still be found); search and "show older" find everything.
alter table public.shoebox_items add column if not exists archived_at timestamptz;
create index if not exists shoebox_items_list_idx
  on public.shoebox_items (company_id, status, created_at desc);
