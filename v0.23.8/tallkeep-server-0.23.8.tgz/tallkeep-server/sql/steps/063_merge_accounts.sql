-- 063: Merge two accounts. Everything that points at one account (its entries, bank lines,
-- reconciliations, payee rules, loan details…) moves to the other; then the first one is removed.
-- For things an account can only have one of (like loan details), the kept account's own wins.
create or replace function public.merge_accounts(_from uuid, _into uuid)
returns text language plpgsql security definer set search_path = public as $$
declare a record; b record; r record; n int; moved int := 0; rows tid[]; t tid;
begin
  if auth.uid() is null or not public.is_company_admin(auth.uid()) then
    raise exception 'Only an admin can merge accounts';
  end if;
  if _from = _into then raise exception 'Choose two different accounts'; end if;
  select * into a from public.accounts where id = _from and company_id = public.active_company() for update;
  select * into b from public.accounts where id = _into and company_id = public.active_company() for update;
  if a.id is null or b.id is null then raise exception 'Account not found'; end if;
  if a.key is not null then raise exception '% is one of Tallkeep''s own accounts; merge the other one into it instead', a.name; end if;
  if a.type <> b.type then
    raise exception 'They are different kinds of account (% and %); only the same kind can be merged', a.type, b.type;
  end if;
  for r in
    select c.conrelid::regclass as tbl, att.attname as col
      from pg_constraint c
      join pg_attribute att on att.attrelid = c.conrelid and att.attnum = c.conkey[1]
     where c.contype = 'f' and c.confrelid = 'public.accounts'::regclass and array_length(c.conkey, 1) = 1
  loop
    begin
      execute format('update %s set %I = $1 where %I = $2', r.tbl, r.col, r.col) using _into, _from;
      get diagnostics n = row_count;
      moved := moved + n;
    exception when unique_violation then
      -- Some rows clash with the kept account's own (one per account, or the same bank line):
      -- move them one by one; a row that clashes is a duplicate and is dropped.
      execute format('select array_agg(ctid) from %s where %I = $1', r.tbl, r.col) into rows using _from;
      foreach t in array coalesce(rows, '{}') loop
        begin
          execute format('update %s set %I = $1 where ctid = $2', r.tbl, r.col) using _into, t;
          moved := moved + 1;
        exception when unique_violation then
          execute format('delete from %s where ctid = $1', r.tbl) using t;
        end;
      end loop;
    end;
  end loop;
  delete from public.accounts where id = _from;
  -- A loan on the kept account: bring its balance back in line with its last statement.
  for r in select id from public.loans where account_id = _into loop
    perform public.set_loan_balance(r.id);
  end loop;
  return format('%s merged into %s (%s records moved).', a.name, b.name, moved);
end $$;
grant execute on function public.merge_accounts(uuid, uuid) to authenticated;
notify pgrst, 'reload schema';
