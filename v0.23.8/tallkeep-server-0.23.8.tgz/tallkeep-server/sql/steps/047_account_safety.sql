-- 047: Keep every account's books apart (before the online version opens to the public).
--  1. Internal posting and setup functions can't be called from the app or the web.
--  2. Stock, purchase order, stock document and bill functions check the company.
--  3. Product photos and logos: only the company they belong to can open them.

-- ===== 1. Only the database itself uses these =====
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public'
       and p.prorettype <> 'trigger'::regtype
       and (p.proname like 'post\_%' or p.proname like 'seed\_%'
            or p.proname in ('write_entry', 'books_open', 'closed_totals', 'refresh_rent_charge',
                             'org_can_write', 'make_recurring', 'make_company',
                             'generate_rent_company', 'apply_late_fees_company',
                             'run_recurring_company', 'rebuild_books_company'))
  loop
    execute format('revoke execute on function %s from public, anon, authenticated', f.sig);
  end loop;
end $$;

-- ===== 2. Company checks =====
create or replace function public.change_stock(_product_id uuid, _location_id uuid, _shelf text,
  _qty_change numeric, _reason text, _note text default null, _ref_type text default null,
  _ref_id uuid default null)
returns numeric language plpgsql security definer set search_path = public as $$
declare new_qty numeric; co uuid := public.active_company();
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  if not exists (select 1 from public.products where id = _product_id and company_id = co)
     or not exists (select 1 from public.locations where id = _location_id and company_id = co) then
    raise exception 'That item or place isn''t in this company';
  end if;
  insert into public.stock (product_id, location_id, shelf, qty)
    values (_product_id, _location_id, coalesce(_shelf,''), _qty_change)
  on conflict (product_id, location_id, shelf)
    do update set qty = public.stock.qty + excluded.qty, updated_at = now()
  returning qty into new_qty;
  insert into public.stock_moves (product_id, location_id, shelf, qty_change, reason, note, ref_type, ref_id, user_id)
    values (_product_id, _location_id, coalesce(_shelf,''), _qty_change, _reason, _note, _ref_type, _ref_id, auth.uid());
  return new_qty;
end $$;

-- Add "and it's in this company" to the "not found" checks.
do $$
declare
  fixes text[][] := array[
    ['receive_po_stock', 'if o.id is null then', 'if o.id is null or o.company_id is distinct from public.active_company() then'],
    ['complete_stock_doc', 'if d.id is null then', 'if d.id is null or d.company_id is distinct from public.active_company() then'],
    ['take_order_stock', 'if o.id is null then', 'if o.id is null or o.company_id is distinct from public.active_company() then'],
    ['return_order_stock', 'if o.id is null then', 'if o.id is null or o.company_id is distinct from public.active_company() then'],
    ['refresh_bill', E'begin\n  select coalesce(sum(amount), 0) into t',
      E'begin\n  if auth.uid() is not null and not exists (select 1 from public.bills where id = _id and company_id = public.active_company()) then return; end if;\n  select coalesce(sum(amount), 0) into t']
  ];
  i int; def text; fixed text;
begin
  for i in 1 .. array_length(fixes, 1) loop
    select pg_get_functiondef(p.oid) into def from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.proname = fixes[i][1];
    if def like '%' || fixes[i][3] || '%' then continue; end if;  -- already done
    fixed := replace(def, fixes[i][2], fixes[i][3]);
    if fixed = def then raise exception 'Could not add the company check to %', fixes[i][1]; end if;
    execute fixed;
  end loop;
end $$;

-- ===== 3. Photos and logos =====
-- Which company a file in product-photos belongs to:
--   products/<product id>...   → that product's company
--   company/<company id>/...   → that company
--   company/logo-...  (older)  → the company whose logo it is
create or replace function public.photo_company(_name text)
returns uuid language sql stable security definer set search_path = public as $$
  select coalesce(
    (select p.company_id from public.products p
      where p.id = (substring(_name from '^products/([0-9a-fA-F-]{36})'))::uuid),
    (select c.id from public.companies c
      where c.id = (substring(_name from '^company/([0-9a-fA-F-]{36})/'))::uuid),
    (select s.company_id from public.company_settings s where s.logo_path = _name limit 1)
  )
$$;
grant execute on function public.photo_company(text) to authenticated;

do $$
declare p record;
begin
  for p in select policyname from pg_policies
            where schemaname = 'storage' and tablename = 'objects'
              and coalesce(qual, '') || coalesce(with_check, '') like '%product-photos%'
  loop
    execute format('drop policy %I on storage.objects', p.policyname);
  end loop;
end $$;

create policy "Photos: staff of the company can see" on storage.objects for select to authenticated
  using (bucket_id = 'product-photos' and public.is_staff(auth.uid())
         and public.photo_company(name) = (select public.active_company()));
create policy "Photos: staff of the company can add" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-photos' and public.is_staff(auth.uid())
              and public.photo_company(name) = (select public.active_company()));
create policy "Photos: staff of the company can change" on storage.objects for update to authenticated
  using (bucket_id = 'product-photos' and public.is_staff(auth.uid())
         and public.photo_company(name) = (select public.active_company()))
  with check (bucket_id = 'product-photos' and public.is_staff(auth.uid())
              and public.photo_company(name) = (select public.active_company()));
create policy "Photos: admins of the company can delete" on storage.objects for delete to authenticated
  using (bucket_id = 'product-photos' and public.is_company_admin(auth.uid())
         and public.photo_company(name) = (select public.active_company()));
