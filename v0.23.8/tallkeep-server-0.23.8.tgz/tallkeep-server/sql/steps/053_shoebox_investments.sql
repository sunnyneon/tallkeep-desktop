-- 053: The Shoebox knows investment and retirement statements (they update Investments).
alter table public.shoebox_items drop constraint if exists shoebox_items_kind_check;
alter table public.shoebox_items add constraint shoebox_items_kind_check
  check (kind in ('statement','receipt','bill','check','loan','investment','unknown'));
