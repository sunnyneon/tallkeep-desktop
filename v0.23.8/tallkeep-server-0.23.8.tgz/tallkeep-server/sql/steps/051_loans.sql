-- 051: Loans and mortgages. A loan statement dropped in the Shoebox is remembered here: who the
-- lender is, the words on the bank line that mean "a payment on this loan", the interest rate,
-- the escrow, and the balance on the statement. Then:
--   - the loan's balance in the books is set to the statement's (only while Tallkeep made all of
--     the loan account's entries itself: an opening balance and bank payments);
--   - each monthly payment in Bank Feeds is split by itself: interest (worked out from the balance
--     and the rate), escrow (taxes and insurance), and the rest pays down the loan.

create table if not exists public.loans (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  lender text,
  match text,                 -- a word on the bank line, lowercase (e.g. "lakeview")
  loan_kind text,             -- mortgage, car, student, personal, heloc, other
  last4 text,
  rate numeric,               -- interest rate a year, in percent (4.625)
  interest_account_id uuid references public.accounts(id) on delete set null,
  escrow_account_id uuid references public.accounts(id) on delete set null,
  payment numeric,            -- the monthly payment on the statement
  principal numeric,
  interest numeric,
  escrow numeric,
  fees numeric,
  balance numeric,            -- what's still owed, on the statement date
  statement_date date,
  due_date date,
  updated_at timestamptz not null default now(),
  unique (company_id, account_id)
);

alter table public.loans enable row level security;
drop policy if exists "Staff can use" on public.loans;
create policy "Staff can use" on public.loans for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()));
grant select, insert, update, delete on public.loans to authenticated;
grant select, insert, update, delete on public.loans to service_role;

-- What's owed on a loan account in the books, through a day (liability: credits minus debits).
-- Uses the reader's access rules.
create or replace function public.loan_balance(_account uuid, _to date)
returns numeric language sql stable set search_path = public as $$
  select coalesce(sum(l.credit - l.debit), 0)
    from public.journal_lines l
    join public.journal_entries e on e.id = l.entry_id
   where l.account_id = _account and (_to is null or e.entry_date <= _to)
$$;
grant execute on function public.loan_balance(uuid, date) to authenticated;

-- Make the books agree with the loan statement's balance. Only while every entry on the loan
-- account is Tallkeep's own (its opening balance for this loan, and bank payments); otherwise the
-- difference is only reported, unless _force: then one adjusting entry on the statement date
-- (against Opening Balance Equity) makes them agree. Returns: 'set', 'same', or 'differs:<amount>'.
drop function if exists public.set_loan_balance(uuid);
create or replace function public.set_loan_balance(_loan uuid, _force boolean default false)
returns text language plpgsql set search_path = public as $$
declare
  n record; opening uuid; others int; open_amt numeric; book numeric; diff numeric; d date; e uuid;
begin
  select * into n from public.loans where id = _loan;
  if n.id is null then raise exception 'Loan not found'; end if;
  if n.balance is null or n.statement_date is null then return 'same'; end if;
  book := public.loan_balance(n.account_id, n.statement_date);
  diff := round(n.balance - book, 2);
  if abs(diff) < 0.01 then return 'same'; end if;

  select count(*) into others
    from public.journal_lines l join public.journal_entries x on x.id = l.entry_id
   where l.account_id = n.account_id
     and not (x.source_type = 'bank' or (x.source_type = 'opening' and x.source_id = n.id));
  select id into opening from public.accounts
   where company_id = n.company_id and key = 'opening' limit 1;
  if opening is null or (others > 0 and not _force) then return 'differs:' || diff::text; end if;

  if others > 0 then
    insert into public.journal_entries (entry_date, memo, source_type, created_by)
    values (n.statement_date, 'Loan balance set to the loan statement', 'adjust', auth.uid()) returning id into e;
    insert into public.journal_lines (entry_id, account_id, debit, credit, memo) values
      (e, n.account_id, greatest(-diff, 0), greatest(diff, 0), coalesce(n.lender, 'Loan')),
      (e, opening, greatest(diff, 0), greatest(-diff, 0), coalesce(n.lender, 'Loan'));
    return 'set';
  end if;

  -- The opening balance moves by the difference (it's dated before every payment).
  select coalesce(sum(l.credit - l.debit), 0), min(x.entry_date) into open_amt, d
    from public.journal_lines l join public.journal_entries x on x.id = l.entry_id
   where l.account_id = n.account_id and x.source_type = 'opening' and x.source_id = n.id;
  -- Dated before every payment on this loan: the ones in the books, and the ones still waiting
  -- in Bank Feeds (so their interest is worked out on the right balance).
  select least(n.statement_date, min(x.entry_date)) into d
    from public.journal_lines l join public.journal_entries x on x.id = l.entry_id
   where l.account_id = n.account_id and not (x.source_type = 'opening' and x.source_id = n.id);
  if coalesce(n.match, '') <> '' then
    select least(coalesce(d, n.statement_date), min(t.txn_date)) into d
      from public.bank_transactions t join public.accounts a on a.id = t.account_id
     where a.company_id = n.company_id and t.status = 'new' and t.amount < 0
       and lower(coalesce(t.description, '')) like '%' || n.match || '%';
  end if;
  d := coalesce(d, n.statement_date);
  delete from public.journal_entries where source_type = 'opening' and source_id = n.id;
  open_amt := round(open_amt + diff, 2);
  if open_amt <> 0 then
    insert into public.journal_entries (entry_date, memo, source_type, source_id, created_by)
    values (d - 1, 'Loan balance (from the loan statement)', 'opening', n.id, auth.uid()) returning id into e;
    insert into public.journal_lines (entry_id, account_id, debit, credit, memo) values
      (e, n.account_id, greatest(-open_amt, 0), greatest(open_amt, 0), coalesce(n.lender, 'Loan')),
      (e, opening, greatest(open_amt, 0), greatest(-open_amt, 0), coalesce(n.lender, 'Loan'));
  end if;
  return 'set';
end $$;
grant execute on function public.set_loan_balance(uuid, boolean) to authenticated;

-- Split the loan payments waiting in Bank Feeds for one bank account: interest from the balance
-- and the rate (or the statement's interest when the rate isn't known), the escrow from the
-- statement, and the rest pays down the loan. Payments of a very different size wait for a person.
-- Returns how many lines were recorded.
create or replace function public.record_loan_payments(_bank uuid)
returns int language plpgsql set search_path = public as $$
declare
  n record; t record; bal numeric; i numeric; esc numeric; prin numeric; paid numeric; e uuid;
  done int := 0; nm text;
begin
  for n in select * from public.loans
            where company_id = public.active_company() and coalesce(match, '') <> ''
              and coalesce(payment, 0) > 0 loop
    select name into nm from public.accounts where id = n.account_id;
    for t in select * from public.bank_transactions
              where account_id = _bank and status = 'new' and amount < 0
                and lower(coalesce(description, '')) like '%' || n.match || '%'
                and -amount between n.payment * 0.9 and n.payment * 3
              order by txn_date loop
      paid := -t.amount;
      esc := case when n.escrow_account_id is null then 0 else coalesce(n.escrow, 0) end;
      if n.due_date is not null and n.interest is not null
         and t.txn_date between n.due_date - 15 and n.due_date + 20 then
        -- The payment this statement is for: its own split (anything extra pays down the loan).
        i := n.interest;
      else
        bal := public.loan_balance(n.account_id, t.txn_date - 1);
        i := case when coalesce(n.rate, 0) > 0 and bal > 0 then round(bal * n.rate / 1200, 2)
                  else coalesce(n.interest, 0) end;
      end if;
      prin := round(paid - i - esc, 2);
      if prin < 0 or (i > 0 and n.interest_account_id is null) then continue; end if;
      insert into public.journal_entries (entry_date, memo, source_type, ref, created_by)
      values (t.txn_date, 'Payment on ' || coalesce(nm, 'the loan'), 'bank', t.ref, auth.uid())
      returning id into e;
      insert into public.journal_lines (entry_id, account_id, debit, credit, memo)
      select e, x.acct, x.dr, x.cr, x.memo from (values
        (t.account_id, 0::numeric, paid, t.description),
        (n.account_id, prin, 0::numeric, 'Pays down the loan'),
        (n.interest_account_id, i, 0::numeric, 'Interest'),
        (n.escrow_account_id, esc, 0::numeric, 'Escrow (taxes and insurance)')
      ) as x(acct, dr, cr, memo)
       where x.acct is not null and (x.dr <> 0 or x.cr <> 0);
      update public.bank_transactions set status = 'added', source_type = 'bank', source_id = e where id = t.id;
      insert into public.cleared_items (account_id, item_key) values (t.account_id, e) on conflict do nothing;
      done := done + 1;
    end loop;
  end loop;
  return done;
end $$;
grant execute on function public.record_loan_payments(uuid) to authenticated;

-- The Shoebox knows loan statements now.
alter table public.shoebox_items drop constraint if exists shoebox_items_kind_check;
alter table public.shoebox_items add constraint shoebox_items_kind_check
  check (kind in ('statement','receipt','bill','check','loan','unknown'));
