-- Tallkeep — step 46: editions and add-ons.
--
-- Tallkeep is sold as Personal, Service Business or Full Business, with add-ons (Real Estate,
-- Crypto Tax). A license key names its edition and add-ons; the office computer writes the parts
-- of the app they open into orgs.licensed_features, and the app shows only those.
-- Keys made before editions have no edition: they open everything, as before.

alter table public.desktop_licenses add column if not exists edition text;
alter table public.desktop_licenses add column if not exists addons text[];
-- Which license an upgrade was paid for (the key keeps its number; it's signed again).
alter table public.desktop_licenses add column if not exists upgrades jsonb not null default '[]'::jsonb;

-- null = every part of the app (trials, online plans, older keys).
alter table public.orgs add column if not exists licensed_features text[];
