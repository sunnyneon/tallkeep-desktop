-- 054: Personal books are always open. A business picks the day its books start (often the
-- day it leaves QuickBooks); a household doesn't, and without that day checks, deposits and bills
-- weren't put in the books. Personal companies without a start day get 2000-01-01, and their
-- books are built again so what was already entered shows up.
create or replace function public.trg_seed_personal()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.business_type = 'personal'
     and (tg_op = 'INSERT' or old.business_type is distinct from new.business_type) then
    perform public.seed_personal_accounts(new.company_id);
    if new.books_start_date is null then
      update public.company_settings set books_start_date = date '2000-01-01'
       where company_id = new.company_id;
    end if;
  end if;
  return new;
end $$;

do $$
declare r record;
begin
  for r in select company_id from public.company_settings
            where business_type = 'personal' and books_start_date is null loop
    update public.company_settings set books_start_date = date '2000-01-01' where company_id = r.company_id;
    perform public.rebuild_books_company(r.company_id);
  end loop;
end $$;
