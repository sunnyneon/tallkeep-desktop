-- 052: A backup AI. When the first AI doesn't answer (overloaded, limit reached, key not
-- accepted), Tallkeep asks the backup AI instead. Its key is server only, like ai_keys.
alter table public.ai_settings add column if not exists backup_provider text;
alter table public.ai_settings drop constraint if exists ai_settings_backup_provider_check;
alter table public.ai_settings add constraint ai_settings_backup_provider_check
  check (backup_provider is null or backup_provider in ('openai','google','anthropic'));

create table if not exists public.ai_backup_keys (
  company_id uuid primary key references public.companies(id) on delete cascade,
  api_key text not null,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.ai_backup_keys to service_role;
alter table public.ai_backup_keys enable row level security;
-- No policies: only the server (service role) reads or writes keys.
