-- 060: Stock reliability.
-- 1) Stock adjustments, transfers and count sheets failed with "Unknown document type stock_adjust":
--    new companies copy their document numbers from another company, and those three were only
--    added by the set-up page. Add them to every company, and let a missing number start by itself.
-- 2) The same stock change can't be saved twice: a quick double press or a retry after a dropped
--    connection sends the same key, and the second one does nothing.

-- ===== 1. Document numbers =====
insert into public.doc_counters (company_id, kind, prefix, next_number)
select c.id, d.kind, d.prefix, d.start
  from public.companies c
  cross join (values
    ('quote', 'SQ-', 1001), ('sales_order', 'INV-', 1001), ('purchase_order', 'PO-', 1001),
    ('rma', 'RMA-', 100001), ('stock_adjust', 'SA-', 1001), ('stock_transfer', 'ST-', 1001),
    ('stock_count', 'CS-', 1001), ('work_order', 'WO-', 1001)
  ) as d(kind, prefix, start)
on conflict (company_id, kind) do nothing;

create or replace function public.next_doc_number(_kind text)
returns text language plpgsql security definer set search_path = public as $$
declare p text; n int; co uuid := public.active_company();
begin
  if not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  -- A company missing one of the usual numbers starts it now.
  insert into public.doc_counters (company_id, kind, prefix, next_number)
  select co, d.kind, d.prefix, d.start
    from (values
      ('quote', 'SQ-', 1001), ('sales_order', 'INV-', 1001), ('purchase_order', 'PO-', 1001),
      ('rma', 'RMA-', 100001), ('stock_adjust', 'SA-', 1001), ('stock_transfer', 'ST-', 1001),
      ('stock_count', 'CS-', 1001), ('work_order', 'WO-', 1001)
    ) as d(kind, prefix, start)
   where d.kind = _kind and co is not null
  on conflict (company_id, kind) do nothing;
  update public.doc_counters set next_number = next_number + 1
   where kind = _kind and company_id = co
   returning prefix, next_number - 1 into p, n;
  if p is null then raise exception 'Unknown document type %', _kind; end if;
  return p || lpad(n::text, 6, '0');
end $$;

-- ===== 2. Save each stock change once =====
create table if not exists public.stock_requests (
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  user_id uuid,
  created_at timestamptz not null default now(),
  primary key (company_id, key)
);
alter table public.stock_requests enable row level security;
-- Only the functions below write here; nobody reads it from the app.

-- True the first time a key is seen in this company; false after that.
create or replace function public.claim_stock_key(_key text)
returns boolean language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if _key is null or length(_key) < 8 then return true; end if;  -- no key: old behaviour
  insert into public.stock_requests (company_id, key, user_id)
  values (public.active_company(), _key, auth.uid())
  on conflict do nothing;
  get diagnostics n = row_count;
  return n = 1;
end $$;
revoke execute on function public.claim_stock_key(text) from public, anon, authenticated;

create or replace function public.change_stock_once(_key text, _product_id uuid, _location_id uuid,
  _shelf text, _qty_change numeric, _reason text, _note text default null)
returns numeric language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  if not public.claim_stock_key(_key) then return null; end if;  -- already saved
  return public.change_stock(_product_id, _location_id, _shelf, _qty_change, _reason, _note);
end $$;

create or replace function public.move_stock_once(_key text, _product_id uuid, _from_location uuid,
  _from_shelf text, _to_location uuid, _to_shelf text, _qty numeric, _note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  if not public.claim_stock_key(_key) then return; end if;
  perform public.move_stock(_product_id, _from_location, _from_shelf, _to_location, _to_shelf, _qty, _note);
end $$;

create or replace function public.set_stock_count_once(_key text, _product_id uuid,
  _location_id uuid, _shelf text, _counted numeric, _note text default null)
returns numeric language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  if not public.claim_stock_key(_key) then return null; end if;
  return public.set_stock_count(_product_id, _location_id, _shelf, _counted, _note);
end $$;

grant execute on function public.change_stock_once(text, uuid, uuid, text, numeric, text, text) to authenticated;
grant execute on function public.move_stock_once(text, uuid, uuid, text, uuid, text, numeric, text) to authenticated;
grant execute on function public.set_stock_count_once(text, uuid, uuid, text, numeric, text) to authenticated;

notify pgrst, 'reload schema';
