-- 057: Documents: every file kept for a company in one list (Shoebox drops and receipts), and
-- how much space an account's files take (online plans have a limit).

-- Every file, newest first. Reads with the reader's own access (the tables' rules apply).
create or replace view public.documents with (security_invoker = true) as
  select 'shoebox'::text as source, s.id, s.company_id, s.created_at, s.file_name, s.file_path,
         s.mime, s.kind, s.status, s.summary, s.target_type, s.target_id, s.account_id,
         coalesce(s.size::bigint, (select (o.metadata->>'size')::bigint from storage.objects o
                                    where o.bucket_id = 'receipts' and o.name = s.file_path)) as size,
         s.archived_at
    from public.shoebox_items s
   where s.file_path is not null
  union all
  select 'receipt', r.id, r.company_id, r.created_at, r.file_name, r.file_path, r.mime, 'receipt',
         r.status, concat_ws(' · ', r.vendor_name, case when r.total is not null then '$' || to_char(r.total, 'FM999,999,990.00') end),
         'receipt', r.id, r.account_id,
         (select (o.metadata->>'size')::bigint from storage.objects o
           where o.bucket_id = 'receipts' and o.name = r.file_path),
         null::timestamptz
    from public.receipts r
   where r.file_path is not null
     and not exists (select 1 from public.shoebox_items s where s.file_path = r.file_path);
grant select on public.documents to authenticated;

-- Space used by all of an account's (org's) companies: kept files, product photos, ticket files.
create or replace function public.org_storage_used(_org uuid)
returns bigint language sql stable security definer set search_path = public, storage as $$
  select coalesce(sum((o.metadata->>'size')::bigint), 0)::bigint
    from storage.objects o
    join public.companies c on c.org_id = _org
   where (o.bucket_id in ('receipts', 'ticket-files') and o.name like c.id::text || '/%')
      or (o.bucket_id = 'product-photos' and o.name like 'company/' || c.id::text || '/%')
$$;
revoke all on function public.org_storage_used(uuid) from public, anon, authenticated;
grant execute on function public.org_storage_used(uuid) to service_role;
