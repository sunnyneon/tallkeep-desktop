-- 061: Fulfil part of an invoice, receive part of a purchase order.
-- Each line keeps how many went out (qty_fulfilled) or came in (qty_received, already there).
-- Every partial fulfilment/receipt is one "batch" with its date and lines, so it shows on the
-- document and the last one can be undone. "Fulfil all" / "Receive all" keep working as before.

-- ===== Columns =====
alter table public.sales_order_lines add column if not exists qty_fulfilled numeric(14,4) not null default 0;
alter table public.stock_moves add column if not exists batch_id uuid;

-- Invoices already fulfilled: their stocked lines are fully out.
update public.sales_order_lines l set qty_fulfilled = l.qty
  from public.sales_orders o, public.products p
 where o.id = l.sales_order_id and o.stock_taken_at is not null
   and p.id = l.product_id and p.item_type = 'stocked' and l.qty_fulfilled = 0;

create table if not exists public.stock_batches (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  doc_type text not null check (doc_type in ('sales_order', 'purchase_order')),
  doc_id uuid not null,
  location_id uuid,
  lines jsonb not null default '[]',      -- [{ "line": uuid, "qty": number }]
  created_at timestamptz not null default now(),
  created_by uuid default auth.uid(),
  undone_at timestamptz
);
create index if not exists stock_batches_doc_idx on public.stock_batches (doc_id, created_at);
alter table public.stock_batches enable row level security;
drop policy if exists "Staff can read" on public.stock_batches;
create policy "Staff can read" on public.stock_batches for select to authenticated
  using (public.is_staff(auth.uid()) and company_id = (select public.active_company()));
grant select on public.stock_batches to authenticated;
-- Written only by the functions below.

-- Tag this transaction's new movements for a document with the batch.
create or replace function public.tag_batch(_ref_type text, _ref_id uuid, _batch uuid)
returns void language sql security definer set search_path = public as $$
  update public.stock_moves set batch_id = _batch
   where ref_type = _ref_type and ref_id = _ref_id and batch_id is null and created_at = now();
$$;
revoke execute on function public.tag_batch(text, uuid, uuid) from public, anon, authenticated;

-- ===== Sales: fulfil some or all =====
-- _lines: [{ "line": <sales_order_lines.id>, "qty": n }]; null = everything still to go.
create or replace function public.fulfil_order_lines(_order_id uuid, _location_id uuid, _lines jsonb default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare o record; l record; s record; want numeric; need numeric; take numeric; loc uuid; spot text;
  b uuid := gen_random_uuid(); done jsonb := '[]'; left_over numeric;
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.sales_orders where id = _order_id and company_id = public.active_company() for update;
  if o.id is null then raise exception 'Order not found'; end if;
  if o.stock_taken_at is not null then raise exception 'Everything on this order was already fulfilled'; end if;
  for l in
    select sol.id, sol.product_id, sol.qty, sol.qty_fulfilled, p.default_location_id,
           coalesce(p.default_shelf, '') as default_shelf
      from public.sales_order_lines sol
      join public.products p on p.id = sol.product_id and p.item_type = 'stocked'
     where sol.sales_order_id = _order_id
     order by sol.line_no
  loop
    left_over := greatest(l.qty - l.qty_fulfilled, 0);
    if _lines is null then want := left_over;
    else
      select coalesce(sum((x->>'qty')::numeric), 0) into want
        from jsonb_array_elements(_lines) x where (x->>'line')::uuid = l.id;
    end if;
    want := least(greatest(coalesce(want, 0), 0), left_over);  -- never more than is still to go
    continue when want <= 0;
    need := want;
    -- Take from spots that have stock: the chosen place first, then the rest, biggest first.
    for s in
      select location_id, shelf, qty from public.stock
       where product_id = l.product_id and qty > 0
       order by (location_id = _location_id) desc nulls last, qty desc
    loop
      exit when need <= 0;
      take := least(need, s.qty);
      perform public.change_stock(l.product_id, s.location_id, s.shelf, -take, 'sold', o.number, 'sales_order', _order_id);
      need := need - take;
    end loop;
    -- Not enough: the rest comes off one spot and goes below zero.
    if need > 0 then
      loc := null; spot := null;
      select st.location_id, st.shelf into loc, spot from public.stock st
       where st.product_id = l.product_id
       order by (st.location_id = _location_id) desc nulls last, st.qty desc limit 1;
      if loc is null then
        loc := coalesce(_location_id, l.default_location_id,
                        (select id from public.locations where is_active and company_id = o.company_id order by name limit 1));
        spot := case when loc = l.default_location_id then l.default_shelf else '' end;
      end if;
      perform public.change_stock(l.product_id, loc, coalesce(spot, ''), -need, 'sold', o.number, 'sales_order', _order_id);
    end if;
    update public.sales_order_lines set qty_fulfilled = qty_fulfilled + want where id = l.id;
    done := done || jsonb_build_array(jsonb_build_object('line', l.id, 'qty', want));
  end loop;
  if jsonb_array_length(done) = 0 then raise exception 'Nothing to fulfil: choose how many go out'; end if;
  insert into public.stock_batches (id, company_id, doc_type, doc_id, location_id, lines)
  values (b, o.company_id, 'sales_order', _order_id, _location_id, done);
  perform public.tag_batch('sales_order', _order_id, b);
  -- All stocked lines out: the order is fulfilled.
  if not exists (
    select 1 from public.sales_order_lines sol join public.products p on p.id = sol.product_id and p.item_type = 'stocked'
     where sol.sales_order_id = _order_id and sol.qty_fulfilled < sol.qty) then
    update public.sales_orders set stock_taken_at = now(), location_id = coalesce(_location_id, location_id) where id = _order_id;
  end if;
  return b;
end $$;
grant execute on function public.fulfil_order_lines(uuid, uuid, jsonb) to authenticated;

-- "Fulfil all" keeps its name: everything still to go.
create or replace function public.take_order_stock(_order_id uuid, _location_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.fulfil_order_lines(_order_id, _location_id, null);
end $$;
grant execute on function public.take_order_stock(uuid, uuid) to authenticated;

-- Undo: one batch (_batch) or everything (_batch null).
drop function if exists public.return_order_stock(uuid);
create or replace function public.return_order_stock(_order_id uuid, _batch uuid default null)
returns int language plpgsql security definer set search_path = public as $$
declare o record; m record; n int := 0; bt record; x jsonb;
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.sales_orders where id = _order_id and company_id = public.active_company() for update;
  if o.id is null then raise exception 'Order not found'; end if;
  if _batch is not null then
    select * into bt from public.stock_batches where id = _batch and doc_id = _order_id and undone_at is null for update;
    if bt.id is null then raise exception 'That fulfilment was already undone'; end if;
    for m in
      select product_id, location_id, shelf, sum(qty_change) as net from public.stock_moves
       where batch_id = _batch group by product_id, location_id, shelf having sum(qty_change) < 0
    loop
      perform public.change_stock(m.product_id, m.location_id, m.shelf, -m.net, 'returned', o.number || ' unfulfilled', 'sales_order', _order_id);
      n := n + 1;
    end loop;
    for x in select * from jsonb_array_elements(bt.lines) loop
      update public.sales_order_lines set qty_fulfilled = greatest(qty_fulfilled - (x->>'qty')::numeric, 0)
       where id = (x->>'line')::uuid;
    end loop;
    update public.stock_batches set undone_at = now() where id = _batch;
  else
    -- Net amount taken per spot for this order (taken minus already put back).
    for m in
      select product_id, location_id, shelf, sum(qty_change) as net
        from public.stock_moves
       where ref_type = 'sales_order' and ref_id = _order_id and reason in ('sold','returned')
       group by product_id, location_id, shelf
      having sum(qty_change) < 0
    loop
      perform public.change_stock(m.product_id, m.location_id, m.shelf, -m.net, 'returned', o.number || ' unfulfilled', 'sales_order', _order_id);
      n := n + 1;
    end loop;
    update public.sales_order_lines set qty_fulfilled = 0 where sales_order_id = _order_id;
    update public.stock_batches set undone_at = now() where doc_id = _order_id and undone_at is null;
  end if;
  update public.sales_orders set stock_taken_at = null where id = _order_id;
  return n;
end $$;
grant execute on function public.return_order_stock(uuid, uuid) to authenticated;

-- ===== Purchasing: receive some or all =====
-- _lines: [{ "line": <purchase_order_lines.id>, "qty": n }]; null = everything still to come.
-- More than ordered is refused unless _allow_more.
create or replace function public.receive_po_lines(_po_id uuid, _location_id uuid, _lines jsonb default null,
  _allow_more boolean default false)
returns uuid language plpgsql security definer set search_path = public as $$
declare o record; l record; want numeric; left_over numeric; b uuid := gen_random_uuid(); done jsonb := '[]';
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.purchase_orders where id = _po_id and company_id = public.active_company() for update;
  if o.id is null then raise exception 'Purchase order not found'; end if;
  if o.stock_received_at is not null then raise exception 'Everything on this order was already received'; end if;
  if _location_id is null then raise exception 'Choose where it goes'; end if;
  for l in
    select pol.id, pol.product_id, pol.qty, pol.qty_received, p.item_type
      from public.purchase_order_lines pol
      left join public.products p on p.id = pol.product_id
     where pol.purchase_order_id = _po_id
     order by pol.line_no
  loop
    left_over := greatest(l.qty - l.qty_received, 0);
    if _lines is null then want := left_over;
    else
      select sum((x->>'qty')::numeric) into want
        from jsonb_array_elements(_lines) x where (x->>'line')::uuid = l.id;
    end if;
    want := greatest(coalesce(want, 0), 0);
    continue when want <= 0;
    if want > left_over and not _allow_more then
      raise exception 'More than ordered on line %: % ordered, % already received', l.id, l.qty, l.qty_received;
    end if;
    if l.item_type = 'stocked' then
      perform public.change_stock(l.product_id, _location_id, '', want, 'received', o.number, 'purchase_order', _po_id);
    end if;
    update public.purchase_order_lines set qty_received = qty_received + want where id = l.id;
    done := done || jsonb_build_array(jsonb_build_object('line', l.id, 'qty', want));
  end loop;
  if jsonb_array_length(done) = 0 then raise exception 'Nothing to receive: choose how many came in'; end if;
  insert into public.stock_batches (id, company_id, doc_type, doc_id, location_id, lines)
  values (b, o.company_id, 'purchase_order', _po_id, _location_id, done);
  perform public.tag_batch('purchase_order', _po_id, b);
  update public.purchase_orders set location_id = _location_id where id = _po_id;
  if not exists (select 1 from public.purchase_order_lines where purchase_order_id = _po_id and qty_received < qty) then
    update public.purchase_orders set stock_received_at = now(),
      status = case when status in ('draft','open') then 'received' else status end
     where id = _po_id;
  end if;
  perform public.post_po(_po_id);
  return b;
end $$;
grant execute on function public.receive_po_lines(uuid, uuid, jsonb, boolean) to authenticated;

-- "Receive all" keeps its name.
create or replace function public.receive_po_stock(_po_id uuid, _location_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  perform public.receive_po_lines(_po_id, _location_id, null, false);
end $$;
grant execute on function public.receive_po_stock(uuid, uuid) to authenticated;

-- Undo the last receipt (or one chosen batch).
create or replace function public.undo_po_receipt(_po_id uuid, _batch uuid)
returns int language plpgsql security definer set search_path = public as $$
declare o record; bt record; m record; x jsonb; n int := 0;
begin
  if auth.uid() is null or not public.is_staff(auth.uid()) then raise exception 'Please sign in'; end if;
  select * into o from public.purchase_orders where id = _po_id and company_id = public.active_company() for update;
  if o.id is null then raise exception 'Purchase order not found'; end if;
  select * into bt from public.stock_batches where id = _batch and doc_id = _po_id and undone_at is null for update;
  if bt.id is null then raise exception 'That receipt was already undone'; end if;
  for m in
    select product_id, location_id, shelf, sum(qty_change) as net from public.stock_moves
     where batch_id = _batch group by product_id, location_id, shelf having sum(qty_change) > 0
  loop
    perform public.change_stock(m.product_id, m.location_id, m.shelf, -m.net, 'received', o.number || ' receipt undone', 'purchase_order', _po_id);
    n := n + 1;
  end loop;
  for x in select * from jsonb_array_elements(bt.lines) loop
    update public.purchase_order_lines set qty_received = greatest(qty_received - (x->>'qty')::numeric, 0)
     where id = (x->>'line')::uuid;
  end loop;
  update public.stock_batches set undone_at = now() where id = _batch;
  update public.purchase_orders set stock_received_at = null,
    status = case when status = 'received' then 'open' else status end
   where id = _po_id;
  perform public.post_po(_po_id);
  return n;
end $$;
grant execute on function public.undo_po_receipt(uuid, uuid) to authenticated;

-- ===== The books for a part-received purchase order =====
-- Fully received (or marked received/paid): the whole order, as before. Part received: only what
-- came in so far (each line's share), so the cost isn't counted before it arrives or twice.
create or replace function public.post_po(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare o record; stocked numeric; other numeric; total numeric; d date; part boolean;
begin
  delete from public.journal_entries where source_type = 'po' and source_id = _id;
  select * into o from public.purchase_orders where id = _id;
  if o.id is null or o.status = 'cancelled' then return; end if;
  part := o.stock_received_at is null and o.status not in ('received','paid','completed');
  if part and not exists (select 1 from public.purchase_order_lines where purchase_order_id = o.id and qty_received > 0) then
    return;
  end if;
  d := coalesce(o.stock_received_at,
                (select max(created_at) from public.stock_batches where doc_id = o.id and undone_at is null),
                o.order_date)::date;
  if not public.books_open(o.company_id, d) then return; end if;
  if part then
    select coalesce(sum(case when p.item_type = 'stocked'
                             then l.line_total * least(l.qty_received / nullif(l.qty, 0), 1) else 0 end), 0),
           coalesce(sum(case when p.item_type is distinct from 'stocked'
                             then l.line_total * least(l.qty_received / nullif(l.qty, 0), 1) else 0 end), 0)
      into stocked, other
      from public.purchase_order_lines l left join public.products p on p.id = l.product_id
     where l.purchase_order_id = o.id;
    stocked := round(stocked, 2); other := round(other, 2); total := stocked + other;
    if total = 0 then return; end if;
    perform public.write_entry(o.company_id, d, 'po', o.id, o.number, 'Purchase order ' || o.number || ' (part received)',
      jsonb_build_array(
        jsonb_build_object('account', public.acct(o.company_id, 'inventory'), 'debit', stocked, 'vendor', o.vendor_id),
        jsonb_build_object('account', public.acct(o.company_id, 'cogs'), 'debit', other, 'vendor', o.vendor_id),
        jsonb_build_object('account', public.acct(o.company_id, 'ap'), 'credit', total, 'vendor', o.vendor_id)));
    return;
  end if;
  select coalesce(sum(l.line_total), 0) into stocked
    from public.purchase_order_lines l join public.products p on p.id = l.product_id
   where l.purchase_order_id = o.id and p.item_type = 'stocked';
  perform public.write_entry(o.company_id, d, 'po', o.id, o.number, 'Purchase order ' || o.number,
    jsonb_build_array(
      jsonb_build_object('account', public.acct(o.company_id, 'inventory'), 'debit', least(stocked, o.total), 'vendor', o.vendor_id),
      jsonb_build_object('account', public.acct(o.company_id, 'cogs'), 'debit', o.total - least(stocked, o.total), 'vendor', o.vendor_id),
      jsonb_build_object('account', public.acct(o.company_id, 'ap'), 'credit', o.total, 'vendor', o.vendor_id)));
end $$;

notify pgrst, 'reload schema';
