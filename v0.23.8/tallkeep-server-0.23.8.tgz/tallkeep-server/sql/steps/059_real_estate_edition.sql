-- 059: Real Estate is its own plan now (Personal, Real Estate, Service Business, Full Business).
-- Online plans may be 'real_estate'.
alter table public.orgs drop constraint if exists orgs_plan_check;
alter table public.orgs add constraint orgs_plan_check
  check (plan is null or plan in ('personal', 'real_estate', 'service', 'full'));
