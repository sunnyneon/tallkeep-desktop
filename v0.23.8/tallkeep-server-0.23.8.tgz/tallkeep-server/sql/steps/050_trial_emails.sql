-- 050: Short emails during the free trial (online accounts and people who downloaded Tallkeep).
-- email_log keeps which email went to whom, so each is sent once; email_optout keeps people who
-- pressed "Stop these emails". Only Tallkeep's server reads and writes these.

create table if not exists public.email_log (
  kind text not null,            -- 'online' (an account) or 'download'
  ref text not null,             -- the account id, or the email address
  step text not null,            -- which email
  sent_at timestamptz not null default now(),
  primary key (kind, ref, step)
);
alter table public.email_log enable row level security;
grant select, insert, update, delete on public.email_log to service_role;

create table if not exists public.email_optout (
  email text primary key,
  created_at timestamptz not null default now()
);
alter table public.email_optout enable row level security;
grant select, insert, update, delete on public.email_optout to service_role;
