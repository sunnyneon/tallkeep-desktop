-- 049: Who downloads Tallkeep (the short form before the download), and how many office
-- computers actually run it (each install says hello once a day, trial or licensed).
-- Only Tallkeep's server reads and writes these (no rules for signed-in people).

create table if not exists public.downloads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  email text not null,
  business text,
  platform text not null check (platform in ('windows', 'linux', 'mac')),
  source text
);
create index if not exists downloads_created_idx on public.downloads (created_at desc);
create index if not exists downloads_email_idx on public.downloads (lower(email));
alter table public.downloads enable row level security;
grant select, insert, update, delete on public.downloads to service_role;

create table if not exists public.installs (
  machine text primary key,          -- a random code for the computer (not its name)
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now(),
  version text,
  platform text,
  trial_started timestamptz,
  licensed boolean not null default false
);
alter table public.installs enable row level security;
grant select, insert, update, delete on public.installs to service_role;

