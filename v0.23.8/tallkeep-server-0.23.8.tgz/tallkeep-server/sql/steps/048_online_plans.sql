-- 048: Online plans (app.tallkeep.com). An account picks a plan (Personal, Service Business,
-- Full Business, plus add-ons) and pays monthly or yearly through Stripe. Stripe tells us when
-- it starts, changes or ends; the server then sets the account's status, limits and features.

alter table public.orgs add column if not exists plan text;
alter table public.orgs add column if not exists plan_addons text[] not null default '{}';
alter table public.orgs add column if not exists billing text;          -- 'month' or 'year'
alter table public.orgs add column if not exists stripe_customer text;
alter table public.orgs add column if not exists stripe_subscription text;
alter table public.orgs add column if not exists paid_until timestamptz;
alter table public.orgs add column if not exists ends_at timestamptz;   -- canceled: works until then
alter table public.orgs add column if not exists closed_at timestamptz; -- plan ended (books kept 90 days)
alter table public.orgs add column if not exists ai_pages_month int;    -- built-in AI pages a month (null = no limit)

alter table public.orgs drop constraint if exists orgs_plan_check;
alter table public.orgs add constraint orgs_plan_check
  check (plan is null or plan in ('personal', 'service', 'full'));
alter table public.orgs drop constraint if exists orgs_billing_check;
alter table public.orgs add constraint orgs_billing_check
  check (billing is null or billing in ('month', 'year'));

create index if not exists orgs_stripe_subscription_idx on public.orgs (stripe_subscription);

-- Emails Tallkeep sends for a company (quotes, invoices…): counted, so one account can't send
-- without limit. Only the server writes here.
create table if not exists public.email_sends (
  id bigserial primary key,
  company_id uuid not null references public.companies(id) on delete cascade,
  recipients int not null default 1,
  created_at timestamptz not null default now()
);
create index if not exists email_sends_company_idx on public.email_sends (company_id, created_at);
alter table public.email_sends enable row level security;
grant select, insert, update, delete on public.email_sends to service_role;
grant usage, select on sequence public.email_sends_id_seq to service_role;
