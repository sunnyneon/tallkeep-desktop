-- 062: Backups include the history of part fulfilments and receipts (stock_batches, step 061).
grant select, insert, update, delete on public.stock_batches to service_role;
notify pgrst, 'reload schema';
