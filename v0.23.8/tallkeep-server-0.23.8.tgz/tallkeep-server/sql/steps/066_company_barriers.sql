-- 066: Each company only gets the records its parts are on for.
-- A company with Sales off (a personal one) can't get new customers, quotes or invoices; one with
-- Purchasing off can't get purchase orders; one with Inventory, Sales and Purchasing all off
-- can't get products. Checked by the database on every new record, whatever made it.
-- Existing records aren't touched, so anything already in the wrong place can still be removed.
-- Also removes the one-off "move a quote to another company" from step 065.
drop function if exists public.move_sales_order(uuid, uuid);

create or replace function public.company_has(_co uuid, _features text[])
returns boolean language sql stable security definer set search_path = public as $$
  -- No settings or no parts chosen yet (an older or half-set-up company): don't block.
  select coalesce((select cardinality(s.addons) = 0 or s.addons && _features
                     from public.company_settings s where s.company_id = _co limit 1), true)
$$;

create or replace function public.company_barrier()
returns trigger language plpgsql security definer set search_path = public as $$
declare need text[]; what text; co text;
begin
  need := tg_argv[0]::text[];
  what := tg_argv[1];
  if public.company_has(new.company_id, need) then return new; end if;
  select name into co from public.companies where id = new.company_id;
  raise exception '% can''t have %: that part is off for it. Switch to the right company, or turn the part on in Settings → Features.',
    coalesce(co, 'This company'), what;
end $$;

drop trigger if exists company_barrier on public.customers;
create trigger company_barrier before insert on public.customers
  for each row execute function public.company_barrier('{sales,support,tickets}', 'customers');
drop trigger if exists company_barrier on public.sales_orders;
create trigger company_barrier before insert on public.sales_orders
  for each row execute function public.company_barrier('{sales,support,tickets}', 'quotes or invoices');
drop trigger if exists company_barrier on public.purchase_orders;
create trigger company_barrier before insert on public.purchase_orders
  for each row execute function public.company_barrier('{purchasing}', 'purchase orders');
drop trigger if exists company_barrier on public.products;
create trigger company_barrier before insert on public.products
  for each row execute function public.company_barrier('{inventory,sales,purchasing,work_orders}', 'products');
drop trigger if exists company_barrier on public.stock_docs;
create trigger company_barrier before insert on public.stock_docs
  for each row execute function public.company_barrier('{inventory}', 'stock adjustments or transfers');

notify pgrst, 'reload schema';
