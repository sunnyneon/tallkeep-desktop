-- 056: What each investment statement says, kept month by month: the value, money put in and
-- taken out, fees, dividends and interest, realized gains (short and long term) and the change
-- in value, for the statement's period and the year so far. This is what taxes need (the gains
-- on what was sold and the income), next to the paper gain on what's held now.
create table if not exists public.investment_statements (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null default public.active_company() references public.companies(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete cascade,
  period_start date,
  period_end date not null,
  beginning_value numeric(16,2),
  ending_value numeric(16,2),
  period jsonb not null default '{}',   -- this period: deposits, withdrawals, fees, dividends…
  ytd jsonb not null default '{}',      -- the year so far, the same names
  shoebox_item_id uuid references public.shoebox_items(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (account_id, period_end)
);
create index if not exists investment_statements_company_idx
  on public.investment_statements (company_id, period_end desc);
alter table public.investment_statements enable row level security;
drop policy if exists "Staff can use" on public.investment_statements;
create policy "Staff can use" on public.investment_statements for all to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()))
  with check (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting') and company_id = (select public.active_company()));
grant select, insert, update, delete on public.investment_statements to authenticated;
grant select, insert, update, delete on public.investment_statements to service_role;
