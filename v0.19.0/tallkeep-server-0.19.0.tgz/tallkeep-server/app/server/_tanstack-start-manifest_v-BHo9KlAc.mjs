//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BHo9KlAc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-DyTOXmi4.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BOnD92nf.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CPMf25U9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DyTOXmi4.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BqGj6RSL.js",
			"/assets/log-out-CCPTStgy.js",
			"/assets/testers.functions-CcUfofpR.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-pPcpZu3e.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Cul7mF7Q.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-BpVYXn_T.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/label-D_SeduZC.js",
			"/assets/textarea-ClRfQCJS.js",
			"/assets/dist-CC3KK9DX.js",
			"/assets/dialog-DjF9u058.js",
			"/assets/shoebox-qFTYfTDP.js",
			"/assets/company-CJ01NU37.js",
			"/assets/reports-gi3P3Ahh.js",
			"/assets/access-D6we0P59.js",
			"/assets/UpdateBar-CXnQjBDY.js",
			"/assets/Logo-DJiCFUU_.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-gbFbiV1Q.js",
			"/assets/log-out-CCPTStgy.js",
			"/assets/admin.functions-BS2xWjBm.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DJiCFUU_.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BxX6Aj23.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/label-D_SeduZC.js",
			"/assets/Logo-DJiCFUU_.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DafzmSyn.js",
			"/assets/testers.functions-CcUfofpR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/buy.functions-CW2MnG2o.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-g8ws5TWI.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/downloads.functions-DxuD6E3c.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-C0xP4QvY.js",
			"/assets/testers.functions-CcUfofpR.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/textarea-ClRfQCJS.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DJO3vgIE.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/label-D_SeduZC.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CHbGZOCC.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/label-D_SeduZC.js",
			"/assets/Logo-DJiCFUU_.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-D_w_lXSt.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/upgrade.functions-B5EwfAnd.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-HQnTjzT1.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/label-D_SeduZC.js",
			"/assets/Logo-DJiCFUU_.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-2lIi6ILX.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Dg5V2yLD.js", "/assets/StockDocList-BAKAk16g.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CbVkwBO4.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/ai.functions-BR76m7Dd.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-DVUnviGC.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BwujM-OD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/ai.functions-BR76m7Dd.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Cvhob9ss.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-D7kK11Ip.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-DUAC1_xX.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CJdMvL_Y.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-4kY_6Hvb.js", "/assets/AccountRegister-BKstbEPJ.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-B7BqbJIe.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-Ce5n2WBk.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-Ly3TIOWS.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-BR76m7Dd.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BMoxvjWb.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BSJazdvb.js", "/assets/StockDocList-BAKAk16g.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CvM9hwJr.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-Dz5_Rkov.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BbwacfAV.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-sH0EUm4v.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-SwD8k7EZ.js", "/assets/PartyList-D8uzRb3Y.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-C1AbD9kg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Dom_6FU3.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/storage.functions-D-Wptlo2.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-C5p_spG-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CTjxOZWx.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DW2Kuur8.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-KP4JgrRf.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/members-BbwacfAV.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-FVK8cLBM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-DUAC1_xX.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DLpw815p.js", "/assets/SalesList-CZl4FaW7.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CWM4Q8Oi.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-D5uA_HcT.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-C1zm2lQe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-C0qt7SRe.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DgO-MIiF.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-C4x5qPSg.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BkD-fJJm.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-DUAC1_xX.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BXdjmbvV.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-C8gXnWw3.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-DUAC1_xX.js",
			"/assets/generateCategoricalChart-CNPoZUNR.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DwUFibgB.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-CNPoZUNR.js",
			"/assets/BarChart-BRK0SR6Z.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-Bb-N-HB1.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-HEam5b1J.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DyZUuO9h.js",
			"/assets/createServerFn-D0VFZtgE.js",
			"/assets/auth-middleware-DWHYtA8G.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/storage.functions-D-Wptlo2.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-GMLc1vIx.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-C5wgqjEY.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/badge-Cseo8RIt.js",
			"/assets/checkbox-Ctx9O0IK.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CJFzbe1-.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BmghrDaR.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DFm0scF7.js", "/assets/SalesList-CZl4FaW7.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-yAMntklR.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/ai.functions-BR76m7Dd.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-D-Wptlo2.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-p4mX1Zx0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-Cseo8RIt.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DTLG6m8B.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-onM5ijhx.js", "/assets/AccountRegister-BKstbEPJ.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-QX1egZGL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-Cseo8RIt.js",
			"/assets/MoneyAccountPick-CR4s3WLI.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-0-ixHRdG.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CWzeVjIa.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-CNPoZUNR.js",
			"/assets/BarChart-BRK0SR6Z.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BS_AJ-rG.js", "/assets/SalesList-CZl4FaW7.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CK3IF-YH.js", "/assets/SalesList-CZl4FaW7.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-DdaYIZnt.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CThaoKx1.js",
			"/assets/createServerFn-D0VFZtgE.js",
			"/assets/auth-middleware-DWHYtA8G.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/dist-30T8rRWZ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/QuickBooksImport-sH0EUm4v.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-Ctx9O0IK.js",
			"/assets/users.functions-Bo7Yh-iH.js",
			"/assets/FeaturePicker-JbNPvxP7.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-uOSHDGOH.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/FeaturePicker-JbNPvxP7.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-bwkuZ_7V.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Dg44yo1Y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DUEErJsd.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/loans-DhR1zMtS.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-D-Wptlo2.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DdPLJRt-.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/DocPdf-DUwO5QSk.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-C189tn58.js",
			"/assets/createServerFn-D0VFZtgE.js",
			"/assets/auth-middleware-DWHYtA8G.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-Cseo8RIt.js",
			"/assets/MoneyAccountPick-CR4s3WLI.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CkcWbjfc.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/StockDialogs-Dg44yo1Y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/checkbox-Ctx9O0IK.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Bi4Vso5n.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-DUAC1_xX.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-B6zKL8nM.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/tickets.functions-BNcfDlLy.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-KQBlkeQ4.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CJwOvjcd.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-yzh7055Z.js", "/assets/StockDocList-BAKAk16g.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-B8Zvyqu6.js", "/assets/PartyList-D8uzRb3Y.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-VxQAexnI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/tickets.functions-BNcfDlLy.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-RnUmvxYZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/badge-Cseo8RIt.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BxaooOi7.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BHLZF12d.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/AdminAccount-BJY5R1-c.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-Bd8KIO4i.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/downloads.functions-DxuD6E3c.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B8ZaT8Cd.js",
			"/assets/createServerFn-D0VFZtgE.js",
			"/assets/auth-middleware-DWHYtA8G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DGzz4uJ6.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Cr4_FVcN.js",
			"/assets/testers.functions-CcUfofpR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C5sRybmm.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-B-zfKbFF.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-DHU962e4.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C5sRybmm.js",
			"/assets/buy.functions-CW2MnG2o.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BOidGw6_.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/textarea-ClRfQCJS.js",
			"/assets/support.functions-CJwOvjcd.js",
			"/assets/HelpParts-CZdxmwNN.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-3DclioDj.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DOR3vxtC.js",
			"/assets/manual._slug-BV-mdbk1.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-bB_NkSN1.js",
			"/assets/createServerFn-D0VFZtgE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C5sRybmm.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CAPfQw5X.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C5sRybmm.js",
			"/assets/upgrade.functions-B5EwfAnd.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-xZsMVQAR.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-mh8oijb3.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/AdminAccount-BJY5R1-c.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index--Mc0zO9t.js", "/assets/ManualFrame-DOR3vxtC.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DicAd-vi.js", "/assets/AccountRegister-BKstbEPJ.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CRMAYYZ7.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/OriginalLink-O5dQL_gy.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-BnRKjuPm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CEaZo6sW.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-DB5jdnAb.js",
			"/assets/PartyHistory-CdzvTGI9.js",
			"/assets/tabs-DwP9ybd5.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-yjS4Ee3j.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-DB5jdnAb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/MoneyAccountPick-CR4s3WLI.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DWprlexp.js",
			"/assets/PrintFrame-DdqbEiyY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-1IvCba1j.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Dg44yo1Y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-C4x5qPSg.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/badge-Cseo8RIt.js",
			"/assets/SideList-DB5jdnAb.js",
			"/assets/tabs-DwP9ybd5.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DQXF9QpW.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-DB5jdnAb.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/MoneyAccountPick-CR4s3WLI.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DWprlexp.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-Ctx9O0IK.js",
			"/assets/workorders-B0SB58LO.js",
			"/assets/tickets.functions-BNcfDlLy.js",
			"/assets/users.functions-Bo7Yh-iH.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CV3qKwfM.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/select-Dxr-0FUd.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-DB5jdnAb.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-SMJ6S6Zf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CJwOvjcd.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CmdzXwzQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BtyzPD4v.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/SideList-DB5jdnAb.js",
			"/assets/PartyHistory-CdzvTGI9.js",
			"/assets/tabs-DwP9ybd5.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CPvuo9_G.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/tickets.functions-BNcfDlLy.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BdBlC2Vg.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C5sRybmm.js",
			"/assets/input-B2KLuwFU.js",
			"/assets/skeleton-CP8e3q4L.js",
			"/assets/AdminAccount-BJY5R1-c.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-B0oYLefc.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-C5sRybmm.js",
			"/assets/textarea-ClRfQCJS.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CJwOvjcd.js",
			"/assets/HelpParts-CZdxmwNN.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-C4k5DHGS.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CP8e3q4L.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
