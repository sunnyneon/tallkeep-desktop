import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/checks_._id-Du7mg1f8.js
var $$splitComponentImporter = () => import("./checks_._id-C9hzQjUm.mjs");
var Route = createFileRoute("/_authenticated/checks_/$id")({
	validateSearch: (s) => ({
		...s["card"] ? { card: 1 } : {},
		...typeof s["account"] === "string" ? { account: s["account"] } : {}
	}),
	head: () => ({ meta: [{ title: "Check · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
