import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-8tQCpcOj.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { n as fileToPages } from "./ai-DoFpV1D-.mjs";
import { t as aiRead } from "./ai.functions-CYx4S8OH.mjs";
import { u as queueShoebox } from "./shoebox-BDad9XHD.mjs";
import { A as ScanBarcode, En as Banknote, Pt as FileUp, R as Plus, Y as PackagePlus, k as ScanLine, ln as Camera, lt as LoaderCircle, n as X, x as Sparkles } from "../_libs/lucide-react.mjs";
import { o as useLocations } from "./queries-CUGyjerL.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { s as useAddVendor } from "./quickadd-Xo4-V0Jo.mjs";
import { t as queueScans } from "./scanQueue-C9-xAAQ0.mjs";
import { n as shrinkImage, r as uploadExtraPhoto } from "./photos-PwQoyCNs.mjs";
import { t as ensureShelf } from "./stockmove-CB-XlxV_.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ScanAdd-D3i-gopf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Start the camera and call onCode once a barcode / QR code is read. */
async function startScan(video, onCode) {
	const W = window;
	const formats = W.BarcodeDetector ? await W.BarcodeDetector.getSupportedFormats?.().catch(() => []) : [];
	if (W.BarcodeDetector && (formats?.length ?? 1) > 0) {
		const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
		video.srcObject = stream;
		await video.play();
		const det = new W.BarcodeDetector();
		let live = true;
		const tick = async () => {
			if (!live) return;
			try {
				const r = await det.detect(video);
				if (r[0]?.rawValue) onCode(r[0].rawValue);
			} catch {}
			requestAnimationFrame(tick);
		};
		tick();
		return () => {
			live = false;
			stream.getTracks().forEach((t) => t.stop());
		};
	}
	const { BrowserMultiFormatReader } = await import("../_libs/@zxing/browser+[...].mjs").then((n) => n.t);
	const controls = await new BrowserMultiFormatReader().decodeFromConstraints({ video: { facingMode: "environment" } }, video, (result) => {
		if (result) onCode(result.getText());
	});
	return () => controls.stop();
}
/** Scan button: snap a receipt or bill (AI reads it on the Receipts page), or scan a product barcode. */
function ScanButton({ compact }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	const [addPhoto, setAddPhoto] = (0, import_react.useState)(void 0);
	const navigate = useNavigate();
	const { data: features } = useFeatures();
	const items = !features || features.includes("inventory") || features.includes("sales");
	const send = (list, kind = "shoebox") => {
		const files = [...list ?? []];
		if (!files.length) return;
		setOpen(null);
		if (kind === "check") {
			queueScans(files, "check");
			navigate({ to: "/checks-received" });
		} else {
			queueShoebox(files);
			navigate({ to: "/shoebox" });
		}
	};
	const option = "flex w-full cursor-pointer items-center gap-4 rounded-xl border p-4 text-left hover:bg-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: compact ? "icon" : "sm",
			variant: "secondary",
			onClick: () => setOpen("menu"),
			"aria-label": "Take a photo of a receipt, bill or check, or scan a barcode",
			title: "Take a photo of a receipt, bill or check, or scan a barcode",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "h-4 w-4" }), !compact && " Scan"]
		}),
		open === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: true,
			onOpenChange: (v) => !v && setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Photos and files go to the Shoebox: Tallkeep works out if it's a receipt, a bill, a statement or a check, and puts it where it belongs." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Take a photo for the Shoebox"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "A receipt, bill or statement. Lay it flat in good light, fill the screen with it."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									className: "hidden",
									onChange: (e) => send(e.target.files)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Take a photo of a check you received"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "AI reads who paid and how much, and applies it to their invoices."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									multiple: true,
									className: "hidden",
									onChange: (e) => send(e.target.files, "check")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Send files to the Shoebox"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "Photos, PDFs or bank files from your phone or computer; several at once is fine."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*,.pdf,application/pdf,.csv,.ofx,.qfx,.qbo",
									multiple: true,
									className: "hidden",
									onChange: (e) => send(e.target.files)
								})
							]
						}),
						items && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: option,
							onClick: () => setOpen("barcode"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanBarcode, { className: "h-6 w-6 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: "Scan a product barcode"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted-foreground",
								children: "Opens that product. A new code? Give it to an item, or add a new item."
							})] })]
						}),
						items && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackagePlus, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Add a new item to inventory"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "Take a photo of it, scan its barcode, type the name and how many. AI can name it from the photo."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									className: "hidden",
									onChange: (e) => {
										setAddPhoto(e.target.files?.[0]);
										e.target.value = "";
										setOpen("add");
									}
								})
							]
						})
					]
				})]
			})
		}),
		open === "barcode" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanDialog, { onClose: () => setOpen(null) }),
		open === "add" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAddItem, {
			...addPhoto ? { photo: addPhoto } : {},
			onClose: () => {
				setOpen(null);
				setAddPhoto(void 0);
			},
			onSaved: (p) => navigate({
				to: "/products/$id",
				params: { id: p.id }
			})
		})
	] });
}
function ScanDialog({ onClose }) {
	const [video, setVideo] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	const [error, setError] = (0, import_react.useState)("");
	const [typed, setTyped] = (0, import_react.useState)("");
	const [unknown, setUnknown] = (0, import_react.useState)("");
	const done = (0, import_react.useRef)(false);
	async function lookup(code) {
		const c = code.trim();
		if (!c || done.current) return;
		done.current = true;
		if (navigator.vibrate) navigator.vibrate(80);
		const { data } = await db.from("products").select("id,name").or(`barcode.eq."${c.replace(/"/g, "")}",name.eq."${c.replace(/"/g, "")}"`).limit(2);
		const hit = data?.length === 1 ? data[0] : void 0;
		if (hit) {
			onClose();
			navigate({
				to: "/products/$id",
				params: { id: hit.id }
			});
		} else if (data?.length) {
			onClose();
			toast("More than one product matches.");
			navigate({
				to: "/products",
				search: { q: c }
			});
		} else setUnknown(c);
	}
	(0, import_react.useEffect)(() => {
		if (!video) return;
		let stop;
		let gone = false;
		startScan(video, (c) => void lookup(c)).then((s) => {
			if (gone) s();
			else stop = s;
		}).catch(() => setError("Can't open the camera. Allow the camera for this site in the browser's settings, or type the code below."));
		return () => {
			gone = true;
			stop?.();
		};
	}, [video]);
	if (unknown) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnknownCode, {
		code: unknown,
		onClose,
		onProduct: (p) => navigate({
			to: "/products/$id",
			params: { id: p.id }
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan a barcode" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Point the camera at the product's barcode or QR code and hold still. It opens the product by itself." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-xl bg-black",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: setVideo,
						className: "aspect-[4/3] w-full object-cover",
						muted: true,
						playsInline: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-8 top-1/2 h-0.5 -translate-y-1/2 bg-red-500/80" })]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						lookup(typed);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "…or type / scan with a USB scanner",
						value: typed,
						onChange: (e) => setTyped(e.target.value),
						autoFocus: !!error
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Find"
					})]
				})
			]
		})
	});
}
/**
* Scanning products, everywhere it helps:
*  - CameraBox: the camera, reading barcodes (or a USB scanner typing into the box).
*  - findByBarcode: the product with that barcode.
*  - QuickAddItem: a new item from a photo and/or a barcode: name (AI can read it off the
*    photo), vendor, how many and where. Makes the product, its photo, the vendor's item and the
*    stock.
*  - UnknownCode: a code no product has yet: give it to a product, or make a new item.
*  - ScanAddButton: on a page (count sheet, invoice, purchase order…): scan item after item.
*/
var clean = (c) => c.trim().replace(/"/g, "");
/** The product with this barcode ("many" when more than one has it). */
async function findByBarcode(code) {
	const c = clean(code);
	if (!c) return null;
	const { data } = await db.from("products").select("id,name").eq("barcode", c).limit(2);
	if (!data?.length) return null;
	return data.length > 1 ? "many" : data[0];
}
/** The camera reading barcodes, plus a box for a USB scanner or typing. Calls onCode for each
*  new code (the same code again within 2 seconds is ignored). */
function CameraBox({ onCode, hint }) {
	const [video, setVideo] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [typed, setTyped] = (0, import_react.useState)("");
	const last = (0, import_react.useRef)({
		code: "",
		at: 0
	});
	const fire = (raw) => {
		const c = raw.trim();
		if (!c) return;
		const now = Date.now();
		if (c === last.current.code && now - last.current.at < 2e3) return;
		last.current = {
			code: c,
			at: now
		};
		if (navigator.vibrate) navigator.vibrate(60);
		onCode(c);
	};
	const fireRef = (0, import_react.useRef)(fire);
	fireRef.current = fire;
	(0, import_react.useEffect)(() => {
		if (!video) return;
		let stop;
		let gone = false;
		startScan(video, (c) => fireRef.current(c)).then((s) => {
			if (gone) s();
			else stop = s;
		}).catch(() => setError("Can't open the camera. Allow the camera for this site, or type the code / use a USB scanner below."));
		return () => {
			gone = true;
			stop?.();
		};
	}, [video]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-xl bg-black",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: setVideo,
					className: "aspect-[4/3] w-full object-cover",
					muted: true,
					playsInline: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-8 top-1/2 h-0.5 -translate-y-1/2 bg-red-500/80" })]
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					fire(typed);
					setTyped("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "…or type the code / scan with a USB scanner",
					value: typed,
					onChange: (e) => setTyped(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "outline",
					children: "OK"
				})]
			})
		]
	});
}
/** A camera button next to a Barcode box: scan once, fill the box. */
function ScanIntoField({ onCode }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		size: "icon",
		variant: "outline",
		title: "Scan the barcode with the camera",
		onClick: () => setOpen(true),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanBarcode, { className: "h-4 w-4" })
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan the barcode" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraBox, { onCode: (c) => {
				onCode(c);
				setOpen(false);
			} })]
		})
	})] });
}
/** A new item from a photo and/or a barcode. */
function QuickAddItem({ barcode: barcode0 = "", photo: photo0, onClose, onSaved }) {
	const addVendorNow = useAddVendor();
	const qc = useQueryClient();
	const { data: locs } = useLocations();
	const { data: vendors } = useQuery({
		queryKey: ["vendors-lite"],
		queryFn: () => fetchAll("vendors", "id,name")
	});
	const [photos, setPhotos] = (0, import_react.useState)(photo0 ? [photo0] : []);
	const [preview, setPreview] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!photos[0]) return setPreview("");
		const u = URL.createObjectURL(photos[0]);
		setPreview(u);
		return () => URL.revokeObjectURL(u);
	}, [photos]);
	const [f, setF] = (0, import_react.useState)({
		name: "",
		barcode: barcode0,
		vendor: "",
		vendorCode: "",
		cost: "",
		price: "",
		qty: "",
		loc: "",
		shelf: "",
		description: ""
	});
	(0, import_react.useEffect)(() => {
		if (!f.loc && locs?.length) {
			const first = locs.find((l) => l.is_active) ?? locs[0];
			if (first) setF((x) => ({
				...x,
				loc: first.id
			}));
		}
	}, [locs, f.loc]);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	/** AI reads the photo: a name (and the barcode digits when they show). */
	async function nameFromPhoto() {
		if (!photos[0]) return;
		setBusy("Reading the photo…");
		try {
			const r = JSON.parse(await aiRead({ data: {
				feature: "product",
				images: await fileToPages(photos[0], 1)
			} }));
			set({
				...r.name ? { name: r.name } : {},
				...r.description && !f.description ? { description: r.description } : {},
				...r.barcode && !f.barcode ? { barcode: String(r.barcode).replace(/\s/g, "") } : {}
			});
			if (!r.name) toast.message("Couldn't read a name from the photo. Type it.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	async function save() {
		const name = f.name.trim();
		if (!name) return void toast.error("Type the item's name.");
		const code = clean(f.barcode);
		if (code) {
			const had = await findByBarcode(code);
			if (had) return void toast.error(had === "many" ? `More than one product already has barcode ${code}.` : `${had.name} already has barcode ${code}.`);
		}
		setBusy("Saving…");
		try {
			const num = (v) => v.trim() === "" ? null : Number(v.replace(/[$,\s]/g, ""));
			const { data, error } = await db.from("products").insert({
				name,
				description: f.description.trim() || null,
				barcode: code || null,
				item_type: "stocked",
				cost: num(f.cost) ?? 0,
				price: num(f.price) ?? 0,
				default_location_id: f.loc || null,
				default_shelf: f.shelf.trim() || null
			}).select("id").single();
			if (error) throw new Error(error.message);
			const id = data.id;
			let main = false;
			for (const ph of photos) {
				const path = await uploadExtraPhoto(id, await shrinkImage(ph));
				if (!main) {
					main = true;
					await db.from("products").update({ picture_path: path }).eq("id", id);
				}
			}
			if (f.vendor) {
				const v = await db.from("vendor_items").insert({
					vendor_id: f.vendor,
					product_id: id,
					vendor_code: f.vendorCode.trim() || null,
					cost: num(f.cost) ?? 0
				});
				if (v.error) throw new Error(v.error.message);
			}
			const qty = num(f.qty) ?? 0;
			if (f.loc && qty > 0) {
				await ensureShelf(f.loc, f.shelf);
				const { error: e2 } = await db.rpc("change_stock", {
					_product_id: id,
					_location_id: f.loc,
					_shelf: f.shelf.trim(),
					_qty_change: qty,
					_reason: "adjust",
					_note: "New item added with Scan"
				});
				if (e2) throw new Error(e2.message);
			}
			toast.success(`${name} added${qty > 0 ? ` (${qty} in stock)` : ""}.`);
			qc.invalidateQueries({ queryKey: ["products"] });
			qc.invalidateQueries({ queryKey: ["stock"] });
			onSaved?.({
				id,
				name
			});
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const label = "space-y-1 text-sm";
	const small = "block text-xs text-muted-foreground";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[92vh] max-w-lg overflow-y-auto",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add a new item" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "A photo, the barcode and a name is enough. The rest you can fill in later." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: preview,
							alt: "",
							className: "h-28 w-28 rounded-xl border object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute -right-2 -top-2 rounded-full bg-background p-0.5 shadow",
							onClick: () => setPhotos((p) => p.slice(1)),
							"aria-label": "Remove the photo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})]
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
								" ",
								photos.length ? "Another photo" : "Take a photo",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									className: "hidden",
									onChange: (e) => {
										const fl = e.target.files?.[0];
										if (fl) setPhotos((p) => [...p, fl]);
										e.target.value = "";
									}
								})
							]
						}), photos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: !!busy,
							onClick: () => void nameFromPhoto(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }), " Name it from the photo (AI)"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: `${label} sm:col-span-2`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: f.name,
								onChange: (e) => set({ name: e.target.value }),
								placeholder: "Mean Well 12V 150W power supply"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `${label} sm:col-span-2`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Barcode"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.barcode,
									onChange: (e) => set({ barcode: e.target.value }),
									placeholder: "Scan the box, or leave empty"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "icon",
									variant: "outline",
									onClick: () => setScanning(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanBarcode, { className: "h-4 w-4" })
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "How many you have"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.qty,
								onChange: (e) => set({ qty: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Where"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								value: f.loc,
								onChange: (e) => set({ loc: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "No location"
								}), (locs ?? []).filter((l) => l.is_active).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: l.id,
									children: l.name
								}, l.id))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Shelf or bin (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.shelf,
								onChange: (e) => set({ shelf: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Vendor (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: f.vendor || null,
								onChange: (v) => set({ vendor: v }),
								options: (vendors ?? []).map((v) => ({
									value: v.id,
									label: v.name
								})),
								placeholder: "Who you buy it from",
								onAdd: addVendorNow,
								addLabel: "Add new vendor"
							})]
						}),
						f.vendor && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Vendor's part number (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.vendorCode,
								onChange: (e) => set({ vendorCode: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Cost each (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.cost,
								onChange: (e) => set({ cost: e.target.value })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: small,
								children: "Selling price (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.price,
								onChange: (e) => set({ price: e.target.value })
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						disabled: !!busy,
						onClick: () => void save(),
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), busy || "Add the item"]
					})]
				}),
				scanning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
					open: true,
					onOpenChange: (v) => !v && setScanning(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-w-md",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan the barcode" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraBox, { onCode: (c) => {
							set({ barcode: c });
							setScanning(false);
						} })]
					})
				})
			]
		})
	});
}
/** A code no product has yet: give it to a product, or make a new item with it. */
function UnknownCode({ code, onClose, onProduct }) {
	const { data: products } = useQuery({
		queryKey: ["products-lite"],
		queryFn: () => fetchAll("products", "id,name,barcode")
	});
	const [pick, setPick] = (0, import_react.useState)("");
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const qc = useQueryClient();
	async function give() {
		const p = products?.find((x) => x.id === pick);
		if (!p) return;
		if (p.barcode && !window.confirm(`${p.name} has barcode ${p.barcode}. Replace it with ${code}?`)) return;
		setBusy(true);
		const { error } = await db.from("products").update({ barcode: clean(code) }).eq("id", p.id);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(`${p.name} now has barcode ${code}. Next time a scan finds it.`);
		qc.invalidateQueries({ queryKey: ["products"] });
		qc.invalidateQueries({ queryKey: ["products-lite"] });
		onProduct({
			id: p.id,
			name: p.name
		});
		onClose();
	}
	if (adding) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAddItem, {
		barcode: code,
		onClose,
		onSaved: (p) => {
			onProduct(p);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["New barcode: ", code] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "No item has this barcode yet. Give it to the item it belongs to, or add a new item." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "It's on an item you already have:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: pick || null,
							onChange: setPick,
							options: (products ?? []).map((p) => ({
								value: p.id,
								label: p.name
							})),
							placeholder: "Pick the item"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: !pick || busy,
							onClick: () => void give(),
							children: "Give it this barcode"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t pt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setAdding(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " It's a new item: add it"]
					})
				})
			]
		})
	});
}
/** "Scan" on a page: scan item after item; each found product goes to onProduct. */
function ScanAddButton({ onProduct, label = "Scan items", hint }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [unknown, setUnknown] = (0, import_react.useState)("");
	const [lastName, setLastName] = (0, import_react.useState)("");
	async function got(code) {
		const p = await findByBarcode(code);
		if (p === "many") return void toast.error(`More than one item has barcode ${code}.`);
		if (!p) {
			setUnknown(code);
			return;
		}
		onProduct(p);
		setLastName(p.name);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			onClick: () => setOpen(true),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanBarcode, { className: "h-4 w-4" }),
				" ",
				label
			]
		}),
		open && !unknown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: true,
			onOpenChange: (v) => !v && setOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: hint ?? "Scan one item after another. Each scan adds one." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraBox, { onCode: (c) => void got(c) }),
					lastName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: ["Last: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: lastName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setOpen(false),
						children: "Done"
					})
				]
			})
		}),
		unknown && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnknownCode, {
			code: unknown,
			onClose: () => setUnknown(""),
			onProduct: (p) => {
				onProduct(p);
				setLastName(p.name);
			}
		})
	] });
}
//#endregion
export { startScan as i, ScanButton as n, ScanIntoField as r, ScanAddButton as t };
