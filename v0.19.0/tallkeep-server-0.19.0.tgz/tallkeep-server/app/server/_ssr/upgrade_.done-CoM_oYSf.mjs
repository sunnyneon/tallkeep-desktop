import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade_.done-CoM_oYSf.js
var $$splitComponentImporter = () => import("./upgrade_.done-D0Ic89f2.mjs");
/** After paying for a renewal or upgrade: the new key. */
var Route = createFileRoute("/upgrade_/done")({
	ssr: false,
	validateSearch: (s) => ({ session: String(s["session"] ?? "") }),
	head: () => ({ meta: [{ title: "Thank you · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
