import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DSfKvNSS.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { an as Check, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as EDITION_KEYS, n as ADDON_KEYS, r as EDITIONS } from "./editions-Ccs--JHP.mjs";
import { n as getStorage, t as fmtBytes } from "./storage.functions-DyxGCjuH.mjs";
import { t as Route } from "./plan-C3G8Zm4C.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/plan-D_svs08O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Plan & billing for online accounts: see the plan, pick one and pay (Stripe Checkout), change
* it, and open Stripe's billing page (card, invoices, cancel). Needs STRIPE_SECRET_KEY.
*/
var getMyPlan = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("b168eb565a3c4c37801f615d46b1b01ff96ab06ee481f6e9aa59fd2226349aca"));
/** Start paying: Stripe's checkout page. Back to /plan when done. */
var startPlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("933c1ca8d375ab289a5dfd5976fb3f49a00e899e5cf12e5fab59401ca0776648"));
/** Back from checkout: record the plan now (don't wait for Stripe's message). */
var confirmPlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^cs_[A-Za-z0-9_]+$/.test(d.session)) throw new Error("Bad request");
	return d;
}).handler(createSsrRpc("7f27d5ec54cebdfb5629c9cd0bc5f278a3edf0eda72aaee7f43bdad2dd29802e"));
/** Change the plan of a running subscription (Stripe works out the difference). */
var changePlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("e6ad388e4f4d689ee36066da5516f97d165c190e2072efb91cd8bedf5f8a581f"));
/** Stripe's own page for the card, invoices and canceling. */
var billingPage = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("83d5228d9d2f21cc7666fad6650ccbd34fb718c930a17044834da3eee01e2c62"));
/** Online accounts: pick a plan, pay monthly or yearly, change it, or manage the card. */
var usd = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: n % 1 ? 2 : 0
});
var day = (d) => d ? new Date(d).toLocaleDateString(void 0, {
	month: "short",
	day: "numeric",
	year: "numeric"
}) : "";
function PlanPage() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { session } = Route.useSearch();
	const q = useQuery({
		queryKey: ["my-plan"],
		queryFn: () => getMyPlan()
	});
	const [confirming, setConfirming] = (0, import_react.useState)(!!session);
	(0, import_react.useEffect)(() => {
		if (!session) return;
		confirmPlan({ data: { session } }).then((r) => {
			if (r.active) toast.success("Thank you! Your plan is on.");
			qc.invalidateQueries({ queryKey: ["my-plan"] });
			qc.invalidateQueries({ queryKey: ["my-account"] });
		}).catch((e) => toast.error(e.message)).finally(() => {
			setConfirming(false);
			navigate({
				to: "/plan",
				search: {},
				replace: true
			});
		});
	}, [
		session,
		qc,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Plan & billing",
			text: "Pay monthly or yearly. Change or cancel any time."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StorageBar, {}),
		q.isLoading || confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64 w-full" }) : q.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-destructive",
			children: q.error.message
		}) : q.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanBody, { info: q.data }) : null
	] });
}
function PlanBody({ info }) {
	const qc = useQueryClient();
	const cat = info.catalog;
	const [plan, setPlan] = (0, import_react.useState)(info.plan ?? "full");
	const [addons, setAddons] = (0, import_react.useState)(info.addons);
	const base = info.plan ? cat.editions[info.plan] : null;
	const [xu, setXu] = (0, import_react.useState)(info.plan && info.usersAllowed ? Math.max(0, info.usersAllowed - (base?.users ?? 0)) : 0);
	const [xc, setXc] = (0, import_react.useState)(() => {
		if (!info.plan || info.companiesAllowed == null) return 0;
		const inc = cat.editions[info.plan].companies + info.addons.reduce((s, a) => s + (cat.addons[a]?.companies ?? 0), 0);
		return Math.max(0, info.companiesAllowed - inc);
	});
	const [yearly, setYearly] = (0, import_react.useState)(info.billing === "year");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const e = cat.editions[plan];
	const month = e.month + addons.reduce((s, a) => s + cat.addons[a].month, 0) + xu * cat.extra.user + xc * cat.extra.company;
	const total = yearly ? month * info.yearlyMonths : month;
	const companies = e.companies + addons.reduce((s, a) => s + cat.addons[a].companies, 0) + xc;
	const same = (0, import_react.useMemo)(() => info.subscribed && info.plan === plan && info.billing === "year" === yearly && [...info.addons].sort().join() === [...addons].sort().join() && info.usersAllowed === e.users + xu && info.companiesAllowed === companies, [
		info,
		plan,
		yearly,
		addons,
		e.users,
		xu,
		companies
	]);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["my-plan"] });
		qc.invalidateQueries({ queryKey: ["my-account"] });
	};
	const pick = {
		plan,
		addons,
		extraUsers: xu,
		extraCompanies: xc,
		yearly
	};
	async function pay() {
		setBusy(true);
		try {
			const { url } = await startPlan({ data: {
				...pick,
				origin: window.location.origin
			} });
			window.location.href = url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	async function change() {
		setBusy(true);
		try {
			const resume = !!info.endsAt && same;
			await changePlan({ data: {
				...pick,
				resume
			} });
			toast.success(resume ? "Your plan keeps going." : "Plan changed. Stripe charges or credits the difference.");
			refresh();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function manage() {
		setBusy(true);
		try {
			const { url } = await billingPage({ data: { origin: window.location.origin } });
			window.location.href = url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Standing, { info }),
			info.subscribed && info.admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: manage,
				disabled: busy,
				children: "Change card, see invoices or cancel"
			}),
			!info.admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Only an admin of your account can choose or change the plan."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Pay"
					}), ["month", "year"].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setYearly(b === "year"),
						className: cn("rounded-full border px-3 py-1", yearly === (b === "year") && "border-primary bg-primary text-primary-foreground"),
						children: b === "month" ? "Monthly" : `Yearly (${12 - info.yearlyMonths} months free)`
					}, b))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-3",
					children: EDITION_KEYS.map((k) => {
						const x = cat.editions[k];
						const on = plan === k;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPlan(k),
							className: cn("rounded-2xl border p-4 text-left transition-shadow hover:shadow-md", on && "border-primary ring-2 ring-primary"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: x.label
									}), on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-2xl font-semibold",
									children: [usd(yearly ? x.month * info.yearlyMonths : x.month), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-normal text-muted-foreground",
										children: yearly ? " a year" : " a month"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: x.text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: [
										x.companies,
										" compan",
										x.companies === 1 ? "y" : "ies",
										" · ",
										x.users,
										" people ·",
										" ",
										x.aiPages,
										" AI pages a month · ",
										EDITIONS[k].storageGb,
										" GB for files"
									]
								})
							]
						}, k);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Add-ons"
					}), ADDON_KEYS.map((a) => {
						const x = cat.addons[a];
						const on = addons.includes(a);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 rounded-xl border p-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1",
								checked: on,
								onChange: () => setAddons((l) => on ? l.filter((y) => y !== a) : [...l, a])
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: x.label
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											"+",
											usd(yearly ? x.month * info.yearlyMonths : x.month),
											yearly ? " a year" : " a month"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-muted-foreground",
										children: x.text
									})
								]
							})]
						}, a);
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid max-w-md grid-cols-2 gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "More people"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 0,
								value: xu,
								onChange: (ev) => setXu(Math.max(0, Math.floor(Number(ev.target.value) || 0)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									usd(yearly ? cat.extra.user * info.yearlyMonths : cat.extra.user),
									" ",
									yearly ? "a year" : "a month",
									" each"
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "More companies"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 0,
								value: xc,
								onChange: (ev) => setXc(Math.max(0, Math.floor(Number(ev.target.value) || 0)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [
									usd(yearly ? cat.extra.company * info.yearlyMonths : cat.extra.company),
									" ",
									yearly ? "a year" : "a month",
									" each"
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-4 rounded-2xl border bg-muted/40 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-2xl font-semibold",
							children: [usd(total), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm font-normal text-muted-foreground",
								children: yearly ? " a year" : " a month"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								companies,
								" compan",
								companies === 1 ? "y" : "ies",
								" · ",
								e.users + xu,
								" people. Cancel any time; your books stay yours to download."
							]
						})]
					}), !info.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Online payments aren't open yet."
					}) : info.subscribed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: change,
						disabled: busy || same && !info.endsAt,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }), info.endsAt ? same ? "Keep my plan" : "Keep my plan, with these changes" : same ? "This is your plan" : "Change to this plan"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: pay,
						disabled: busy,
						children: [
							busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
							"Pay ",
							usd(total),
							" and start"
						]
					})]
				})
			] })
		]
	});
}
function Standing({ info }) {
	const cat = info.catalog;
	let text;
	if (info.status === "trial") {
		const d = info.trialEndsAt ? Math.max(0, Math.ceil((Date.parse(info.trialEndsAt) - Date.now()) / 864e5)) : null;
		text = d === 0 ? "Your free trial has ended. Your books are read-only until you pick a plan." : `Free trial${d != null ? `, ${d} day${d === 1 ? "" : "s"} left` : ""}. Pick a plan any time; nothing is lost.`;
	} else if (info.status === "canceled") {
		const until = info.closedAt ? day(new Date(Date.parse(info.closedAt) + 7776e6).toISOString()) : "";
		text = `Your plan has ended. Your books are read-only${until ? ` and can be downloaded until ${until}` : ""}. Pick a plan to keep going.`;
	} else {
		const name = info.plan ? cat.editions[info.plan].label : "Your plan";
		const extras = info.addons.map((a) => cat.addons[a]?.label).filter(Boolean);
		text = `${name}${extras.length ? ` + ${extras.join(" + ")}` : ""}, paid ${info.billing === "year" ? "yearly" : "monthly"}.`;
		if (info.status === "past_due") text += " The last payment didn't go through: please update your card.";
		else if (info.endsAt) text = `Your plan is canceled. It's paid for, so everything keeps working until ${day(info.endsAt)}. After that your books turn read-only (you can still open and download them). Changed your mind? Press "Keep my plan" below.`;
		else if (info.paidUntil) text += ` Next payment ${day(info.paidUntil)}.`;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-2xl border p-4 text-sm", info.status === "past_due" || info.status === "canceled" || info.endsAt ? "border-amber-300 bg-amber-50 text-amber-900" : "bg-card"),
		children: text
	});
}
/** Space used by kept files (statements, receipts, photos) and what the plan includes. */
function StorageBar() {
	const s = useQuery({
		queryKey: ["storage"],
		queryFn: () => getStorage()
	}).data;
	if (!s?.limit) return null;
	const pct = Math.min(100, s.used / s.limit * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap justify-between gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: "Files stored"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				fmtBytes(s.used),
				" of ",
				fmtBytes(s.limit),
				" used"
			] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-2 overflow-hidden rounded-full bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-full rounded-full", pct > 90 ? "bg-destructive" : pct > 75 ? "bg-amber-500" : "bg-[#0E7C74]"),
				style: { width: `${Math.max(pct, s.used ? 1 : 0)}%` }
			})
		})]
	});
}
//#endregion
export { PlanPage as component };
