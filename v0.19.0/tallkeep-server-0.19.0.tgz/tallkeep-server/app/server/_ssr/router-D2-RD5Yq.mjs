import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C9I0PyVu.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { C as useRouter, J as redirect, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$88 } from "../_authenticated-BRLPBfX7.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$89 } from "./accounts_._id-CDIbzrb5.mjs";
import { t as Route$90 } from "./bank-transfers-Bnd6mqf_.mjs";
import { t as Route$91 } from "./banking-BW_LfSJs.mjs";
import { t as Route$92 } from "./bills_._id-BHs0FrTs.mjs";
import { n as Route$93 } from "./buy-y5WnaEHs.mjs";
import { t as Route$94 } from "./buy_.done-_UuiXv4S.mjs";
import { t as Route$95 } from "./card-register-tb0SyKfO.mjs";
import { t as Route$96 } from "./products-B47Z8Lbk.mjs";
import { t as Route$97 } from "./checks_._id-Du7mg1f8.mjs";
import { t as Route$98 } from "./customers_._id-SEFHxHLF.mjs";
import { t as Route$99 } from "./customers_._id-T2fBETco.mjs";
import { t as Route$100 } from "./download-BW9IdQIx.mjs";
import { t as Route$101 } from "./financials-CideDR94.mjs";
import { t as Route$102 } from "./go._kind._id-CsXFG32d.mjs";
import { t as Route$103 } from "./help._slug-CxOwnR-Q.mjs";
import { t as Route$104 } from "./help.t._key-DNro1KiY.mjs";
import { t as Route$105 } from "./journal-Dmn8Xykn.mjs";
import { t as Route$106 } from "./leases-hT_rQe8_.mjs";
import { t as Route$107 } from "./manual._slug-DKRlK4AS.mjs";
import { t as Route$108 } from "./pay._token-C68naoUR.mjs";
import { t as Route$109 } from "./plan-C3G8Zm4C.mjs";
import { t as Route$110 } from "./po._id-D_I3T-_m.mjs";
import { t as Route$111 } from "./print-checks-Hil8pnyK.mjs";
import { t as Route$112 } from "./products_._id-B8FQVyQx.mjs";
import { t as Route$113 } from "./recurring-NK6S9nCq.mjs";
import { t as Route$114 } from "./register-DU6IqEkm.mjs";
import { t as Route$115 } from "./route-NGdTtx4c.mjs";
import { t as Route$116 } from "./route-DdRCZFam.mjs";
import { t as Route$117 } from "./signup-BHUaC5c-.mjs";
import { t as Route$118 } from "./upgrade-k254oglz.mjs";
import { t as Route$119 } from "./stays-CJhpRua1.mjs";
import { r as Route$120 } from "./website-tickets-D6VwqnLp.mjs";
import { t as Route$121 } from "./work-orders-Bs9x4sMe.mjs";
import { t as Route$122 } from "./upgrade_.done-CoM_oYSf.mjs";
import { t as Route$123 } from "./sales._id-B9Mc0XgO.mjs";
import { t as Route$124 } from "./stock-doc._id-C0RcDyT5.mjs";
import { t as Route$125 } from "./tickets_._id-CV-fD-eG.mjs";
import { t as Route$126 } from "./vendors_._id-CLvrzj9V.mjs";
import { t as Route$127 } from "./website-tickets_._id-BFjsshh_.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/router-D2-RD5Yq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-x7hBw5hS.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var BLANK_SCREEN_GUARD = `
(function () {
  var failed = false;

  function noteFailure() {
    failed = true;
  }

  window.addEventListener("error", noteFailure, true);
  window.addEventListener("unhandledrejection", noteFailure, true);

  function show() {
    if (window.__sunriseReady || document.getElementById("sunrise-load-card")) return;
    if (!document.body) return;

    var card = document.createElement("div");
    card.id = "sunrise-load-card";
    card.setAttribute("role", "alert");
    card.style.cssText =
      "position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;" +
      "justify-content:center;background:#ffffff;padding:24px;color:#111111;" +
      "font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;";

    card.innerHTML =
      '<div style="max-width:420px;text-align:center">' +
      '<h1 style="font-size:20px;font-weight:700;margin:0 0 8px">This page didn\\'t load</h1>' +
      '<p style="font-size:14px;line-height:1.5;margin:0 0 20px;color:#555555">' +
      "Something went wrong while opening this page. Try again — if it keeps " +
      "happening, go home and open it again.</p>" +
      '<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">' +
      '<button id="sunrise-load-retry" style="background:#0E7C78;color:#ffffff;border:0;' +
      'border-radius:6px;padding:10px 16px;font-size:14px;font-weight:600;cursor:pointer">' +
      "Try again</button>" +
      '<a href="/" style="border:1px solid #d4d4d4;background:#ffffff;color:#111111;' +
      'border-radius:6px;padding:10px 16px;font-size:14px;font-weight:600;text-decoration:none">' +
      "Go home</a>" +
      "</div></div>";

    document.body.appendChild(card);

    var retry = document.getElementById("sunrise-load-retry");
    if (retry) {
      retry.addEventListener("click", function () {
        window.location.reload();
      });
    }
  }

  // Something already failed to load: show the card quickly.
  setTimeout(function () {
    if (failed) show();
  }, 3000);

  // Nothing rendered at all: show it anyway.
  setTimeout(show, 15000);
})();
`;
/**
* Browsers only give crypto.randomUUID to "secure" pages (https or localhost). The office
* (desktop) version is opened over the office network as plain http://192.168.x.x, so phones and
* other computers need this stand-in. Same random ids, made from crypto.getRandomValues.
*/
function installPolyfills() {
	if (typeof crypto === "undefined" || typeof crypto.randomUUID === "function") return;
	Object.defineProperty(crypto, "randomUUID", {
		configurable: true,
		value: () => {
			const b = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
			b[6] = b[6] & 15 | 64;
			b[8] = b[8] & 63 | 128;
			const h = [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
			return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
		}
	});
}
installPolyfills();
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$87 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: "Tallkeep" },
			{
				name: "description",
				content: "Tallkeep: inventory, sales and books for your companies. Own your books."
			},
			{
				property: "og:title",
				content: "Tallkeep"
			},
			{
				property: "og:description",
				content: "Tallkeep: inventory, sales and books for your companies. Own your books."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "theme-color",
				content: "#0F2A44"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Tallkeep"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "default"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;700;800&family=Manrope:wght@400;500;600;700&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			},
			{
				rel: "apple-touch-icon",
				type: "image/png",
				href: "/apple-touch-icon.png"
			},
			{
				rel: "manifest",
				href: "/manifest.webmanifest"
			}
		],
		scripts: [{ children: BLANK_SCREEN_GUARD }]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$87.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event === "SIGNED_IN" || event === "SIGNED_OUT") router.invalidate();
		});
		return () => data.subscription.unsubscribe();
	}, [router]);
	(0, import_react.useEffect)(() => {
		window.__sunriseReady = true;
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "top-center" })]
	});
}
var $$splitComponentImporter$63 = () => import("./auth-SkXUYVT3.mjs");
/** The office (desktop) version: no email and no free trials; the office admin adds people. */
var Route$86 = createFileRoute("/auth")({
	ssr: false,
	head: () => ({ meta: [
		{ title: "Sign in · Tallkeep" },
		{
			name: "description",
			content: "Sign in to Tallkeep."
		},
		{
			property: "og:title",
			content: "Sign in · Tallkeep"
		},
		{
			property: "og:description",
			content: "Sign in to Tallkeep."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$63, "component")
});
var $$splitComponentImporter$62 = () => import("./early-access-Di9hNExz.mjs");
/** Ask to test Tallkeep before launch (no sign-in). Tallkeep checks each request. */
var Route$85 = createFileRoute("/early-access")({
	ssr: false,
	head: () => ({ meta: [{ title: "Tallkeep Early Access" }, {
		name: "description",
		content: "Get early access to Tallkeep: use it free until January 31, 2027, help us make it better, and get 50% off when you buy."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$62, "component")
});
var $$splitComponentImporter$61 = () => import("./reset-password-DHb_Cj0O.mjs");
var Route$84 = createFileRoute("/reset-password")({
	ssr: false,
	head: () => ({ meta: [
		{ title: "New password · Tallkeep" },
		{
			name: "description",
			content: "Set a new password for Tallkeep."
		},
		{
			property: "og:title",
			content: "New password · Tallkeep"
		},
		{
			property: "og:description",
			content: "Set a new password for Tallkeep."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$61, "component")
});
/** The old address: the page is now Early Access. */
var Route$83 = createFileRoute("/testers")({ beforeLoad: () => {
	throw redirect({ to: "/early-access" });
} });
var $$splitComponentImporter$60 = () => import("./welcome-D8aatyVs.mjs");
/** First stop for someone who signed up but has no company yet. */
var Route$82 = createFileRoute("/welcome")({
	ssr: false,
	head: () => ({ meta: [{ title: "Set up your company · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$60, "component")
});
var $$splitComponentImporter$59 = () => import("./accounts-BqQ86BVC.mjs");
var Route$81 = createFileRoute("/_authenticated/accounts")({
	head: () => ({ meta: [{ title: "Chart of Accounts · Tallkeep" }, {
		name: "description",
		content: "Bank, income, expense and other accounts with balances."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$59, "component")
});
var $$splitComponentImporter$58 = () => import("./adjust-sLduhvS6.mjs");
var Route$80 = createFileRoute("/_authenticated/adjust")({
	head: () => ({ meta: [{ title: "Adjust Stock · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$58, "component")
});
var $$splitComponentImporter$57 = () => import("./ai-C4oERVkm.mjs");
var Route$79 = createFileRoute("/_authenticated/ai")({
	head: () => ({ meta: [{ title: "AI & Usage · Tallkeep" }, {
		name: "description",
		content: "Which AI reads your statements and receipts, and how much it's used."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$57, "component")
});
var $$splitComponentImporter$56 = () => import("./bills-vwXxZWW1.mjs");
var Route$78 = createFileRoute("/_authenticated/bills")({
	head: () => ({ meta: [{ title: "Bills & Expenses · Tallkeep" }, {
		name: "description",
		content: "Bills to pay and expenses already paid."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$56, "component")
});
var $$splitComponentImporter$55 = () => import("./budget-lrw-BqVB.mjs");
var Route$77 = createFileRoute("/_authenticated/budget")({
	head: () => ({ meta: [{ title: "Budget · Tallkeep" }, {
		name: "description",
		content: "What you plan to spend each month, what you've spent and what's left."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$55, "component")
});
var $$splitComponentImporter$54 = () => import("./calendar-OqrO_5x2.mjs");
var Route$76 = createFileRoute("/_authenticated/calendar")({
	head: () => ({ meta: [{ title: "Calendar · Tallkeep" }, {
		name: "description",
		content: "What's due each day: invoices, bills, rent, repeating payments."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$54, "component")
});
var $$splitComponentImporter$53 = () => import("./categories-CveVMtup.mjs");
var Route$75 = createFileRoute("/_authenticated/categories")({
	head: () => ({ meta: [{ title: "Product Categories · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$53, "component")
});
var $$splitComponentImporter$52 = () => import("./checks-BhJSU-TZ.mjs");
var Route$74 = createFileRoute("/_authenticated/checks")({
	head: () => ({ meta: [{ title: "Checks & Payments · Tallkeep" }, {
		name: "description",
		content: "Checks, card charges and other money paid out."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$52, "component")
});
var $$splitComponentImporter$51 = () => import("./checks-received-D3M0VcAh.mjs");
var Route$73 = createFileRoute("/_authenticated/checks-received")({
	head: () => ({ meta: [{ title: "Checks Received · Tallkeep" }, {
		name: "description",
		content: "Take photos of checks from customers; AI reads them and applies them to their invoices."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$51, "component")
});
/** The customer whose name best matches the name printed on the check. */
/** Spread the check over open invoices: an invoice named in the memo or owing exactly the
* amount first, then oldest first. */
var $$splitComponentImporter$50 = () => import("./count-h96sf4pu.mjs");
var Route$72 = createFileRoute("/_authenticated/count")({
	head: () => ({ meta: [{ title: "Count Sheet · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$50, "component")
});
var $$splitComponentImporter$49 = () => import("./credit-cards-H6SDjgJ5.mjs");
var Route$71 = createFileRoute("/_authenticated/credit-cards")({
	head: () => ({ meta: [{ title: "Credit Cards · Tallkeep" }, {
		name: "description",
		content: "Business credit cards: charges, statements, reconciling and paying the card."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$49, "component")
});
/** One place for the business's credit cards. */
var $$splitComponentImporter$48 = () => import("./crypto-tax-CTnQrIOl.mjs");
var Route$70 = createFileRoute("/_authenticated/crypto-tax")({
	head: () => ({ meta: [{ title: "Crypto Tax · Tallkeep" }, {
		name: "description",
		content: "Gains and income from crypto, worked out for the tax return, with Form 8949 rows."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$48, "component")
});
var $$splitComponentImporter$47 = () => import("./customers-CvxkSshZ.mjs");
var Route$69 = createFileRoute("/_authenticated/customers")({
	head: () => ({ meta: [{ title: "Customers · Tallkeep" }, {
		name: "description",
		content: "People and companies you sell to."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$47, "component")
});
var $$splitComponentImporter$46 = () => import("./deposits-Bmjb3CSw.mjs");
var Route$68 = createFileRoute("/_authenticated/deposits")({
	head: () => ({ meta: [{ title: "Record Deposits · Tallkeep" }, {
		name: "description",
		content: "Put received payments into the bank as one deposit."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$46, "component")
});
/**
* Documents: every file Tallkeep keeps (Shoebox drops and receipts) in one list, newest first.
* Find one, see it, see what it became, download a whole year as a zip (for the CPA), delete.
* The bar on top shows the space used (online plans have a limit).
*/
var $$splitComponentImporter$45 = () => import("./documents-CIz0LP87.mjs");
var Route$67 = createFileRoute("/_authenticated/documents")({
	head: () => ({ meta: [{ title: "Documents · Tallkeep" }, {
		name: "description",
		content: "Every statement, receipt, bill and check Tallkeep keeps, in one place."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$45, "component")
});
/** Where a file went, as a link. */
var $$splitComponentImporter$44 = () => import("./fast-entry-Ne-funv4.mjs");
var Route$66 = createFileRoute("/_authenticated/fast-entry")({
	head: () => ({ meta: [{ title: "Fast Entry · Tallkeep" }, {
		name: "description",
		content: "Type many payments, bills or deposits in a row, like a spreadsheet."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$44, "component")
});
var $$splitComponentImporter$43 = () => import("./forms-1099--QblHeFU.mjs");
var Route$65 = createFileRoute("/_authenticated/forms-1099")({
	head: () => ({ meta: [{ title: "1099 Forms · Tallkeep" }, {
		name: "description",
		content: "1099-NEC copies for your vendors and a file for e-filing."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$43, "component")
});
/** "Chicago, IL 60601" from the last line of an address. */
var $$splitComponentImporter$42 = () => import("./household-daQ8BAmg.mjs");
var Route$64 = createFileRoute("/_authenticated/household")({
	head: () => ({ meta: [{ title: "Household · Tallkeep" }, {
		name: "description",
		content: "The people in your household and whose each account is."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$42, "component")
});
var $$splitComponentImporter$41 = () => import("./investments-CuNCvsHw.mjs");
var Route$63 = createFileRoute("/_authenticated/investments")({
	head: () => ({ meta: [{ title: "Investments · Tallkeep" }, {
		name: "description",
		content: "Stocks, funds and retirement accounts: shares, what they cost and what they're worth."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$41, "component")
});
/** Paste "VTI 245.10" lines (or two columns from a spreadsheet) to update many prices at once. */
var $$splitComponentImporter$40 = () => import("./invoices-DUpYDPYt.mjs");
var Route$62 = createFileRoute("/_authenticated/invoices")({
	head: () => ({ meta: [{ title: "Invoice List · Tallkeep" }, {
		name: "description",
		content: "Every order and what is still owed."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$40, "component")
});
/**
* Print barcode labels: pick items, give a barcode to the ones without one, pick the label size
* (Avery sheets or a label printer), print. Each label: the name, the barcode and its number
* (and the price, if wanted). Scanning a label opens the item, counts it, or adds it to an order.
*/
var $$splitComponentImporter$39 = () => import("./labels-BauVMpQv.mjs");
var Route$61 = createFileRoute("/_authenticated/labels")({
	head: () => ({ meta: [{ title: "Barcode Labels · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$39, "component")
});
var $$splitComponentImporter$38 = () => import("./loans-Dg_k6pMY.mjs");
var Route$60 = createFileRoute("/_authenticated/loans")({
	head: () => ({ meta: [{ title: "Mortgage & Loans · Tallkeep" }, {
		name: "description",
		content: "Your mortgage, car loan and other loans: what's owed and where each payment goes."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$38, "component")
});
var $$splitComponentImporter$37 = () => import("./locations-DsP8thjw.mjs");
var Route$59 = createFileRoute("/_authenticated/locations")({
	head: () => ({ meta: [{ title: "Locations · Tallkeep" }, {
		name: "description",
		content: "Rooms, shelves and every place you keep things."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$37, "component")
});
var $$splitComponentImporter$36 = () => import("./monthly-review-BfY4vuxt.mjs");
var Route$58 = createFileRoute("/_authenticated/monthly-review")({
	head: () => ({ meta: [{ title: "Monthly Review · Tallkeep" }, {
		name: "description",
		content: "One month at a glance: what's in from each account, what still needs you, transfers to pair, bills and spending."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$36, "component")
});
var $$splitComponentImporter$35 = () => import("./movements-nAUZkq2t.mjs");
var Route$57 = createFileRoute("/_authenticated/movements")({
	head: () => ({ meta: [{ title: "Movement History · Tallkeep" }, {
		name: "description",
		content: "Every time stock went in, out or moved."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$35, "component")
});
var $$splitComponentImporter$34 = () => import("./net-worth-epPiOwdm.mjs");
var Route$56 = createFileRoute("/_authenticated/net-worth")({
	head: () => ({ meta: [{ title: "Net Worth · Tallkeep" }, {
		name: "description",
		content: "What you own, what you owe, and how it's changed."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$34, "component")
});
var Route$55 = createFileRoute("/_authenticated/new-invoice")({ beforeLoad: () => {
	throw redirect({
		to: "/sales/$id",
		params: { id: "new" },
		search: { kind: "order" }
	});
} });
var Route$54 = createFileRoute("/_authenticated/new-quote")({ beforeLoad: () => {
	throw redirect({
		to: "/sales/$id",
		params: { id: "new" },
		search: { kind: "quote" }
	});
} });
var $$splitComponentImporter$33 = () => import("./overview-C0OlvN5r.mjs");
var Route$53 = createFileRoute("/_authenticated/overview")({
	head: () => ({ meta: [{ title: "Overview · Tallkeep" }, {
		name: "description",
		content: "Your day at a glance: numbers, to-dos and recent work."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$33, "component")
});
var $$splitComponentImporter$32 = () => import("./pay-bills-D6ECMp82.mjs");
var Route$52 = createFileRoute("/_authenticated/pay-bills")({
	head: () => ({ meta: [{ title: "Pay Bills · Tallkeep" }, {
		name: "description",
		content: "Pay several bills and purchase orders at once."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$32, "component")
});
var $$splitComponentImporter$31 = () => import("./payroll-Bgge2d8v.mjs");
var Route$51 = createFileRoute("/_authenticated/payroll")({
	head: () => ({ meta: [{ title: "Payroll · Tallkeep" }, {
		name: "description",
		content: "Record each payroll from your payroll company's report into the books."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$31, "component")
});
var $$splitComponentImporter$30 = () => import("./properties-Bn_6uJPf.mjs");
var Route$50 = createFileRoute("/_authenticated/properties")({
	head: () => ({ meta: [{ title: "Properties · Tallkeep" }, {
		name: "description",
		content: "Your properties and their units, who rents each one."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$30, "component")
});
var $$splitComponentImporter$29 = () => import("./purchase-orders-89zJZHnb.mjs");
var Route$49 = createFileRoute("/_authenticated/purchase-orders")({
	head: () => ({ meta: [{ title: "Purchase Order List · Tallkeep" }, {
		name: "description",
		content: "What you ordered from vendors."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./quotes-DyUqKSPl.mjs");
var Route$48 = createFileRoute("/_authenticated/quotes")({
	head: () => ({ meta: [{ title: "Quotes · Tallkeep" }, {
		name: "description",
		content: "Price quotes for customers."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./receipts-C7D2vyal.mjs");
var Route$47 = createFileRoute("/_authenticated/receipts")({
	head: () => ({ meta: [{ title: "Receipts · Tallkeep" }, {
		name: "description",
		content: "Snap or drop receipts; AI reads them and they are matched to the bank."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./refunds-C309Zjlc.mjs");
var Route$46 = createFileRoute("/_authenticated/refunds")({
	head: () => ({ meta: [{ title: "Refunds & Credits · Tallkeep" }, {
		name: "description",
		content: "Give a customer a credit, or pay money back."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
/** A credit from a vendor (they owe us): taken off their next payment in Pay Bills. */
var $$splitComponentImporter$25 = () => import("./rent-CCzsVIV-.mjs");
var Route$45 = createFileRoute("/_authenticated/rent")({
	head: () => ({ meta: [{ title: "Rent · Tallkeep" }, {
		name: "description",
		content: "Charge monthly rent and late fees, record rent received."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
/** Money from a tenant: goes to their oldest charges first. */
/** A one-off charge: utilities, repairs the tenant pays for, pet fee… */
var $$splitComponentImporter$24 = () => import("./rent-roll-B_ssADJE.mjs");
var Route$44 = createFileRoute("/_authenticated/rent-roll")({
	head: () => ({ meta: [{ title: "Rent Roll · Tallkeep" }, {
		name: "description",
		content: "Every unit, its tenant and rent; profit for each property."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./reports-BmXlBXPK.mjs");
var Route$43 = createFileRoute("/_authenticated/reports")({
	head: () => ({ meta: [{ title: "Reports · Tallkeep" }, {
		name: "description",
		content: "Sales, purchasing and inventory reports."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./rma-CAUaoUYM.mjs");
var Route$42 = createFileRoute("/_authenticated/rma")({
	head: () => ({ meta: [{ title: "RMAs · Tallkeep" }, {
		name: "description",
		content: "Return Merchandise Authorizations for customers."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./sales-list-CwLQue0X.mjs");
var Route$41 = createFileRoute("/_authenticated/sales-list")({
	head: () => ({ meta: [{ title: "Sales List · Tallkeep" }, {
		name: "description",
		content: "All quotes, invoices and RMAs in one list."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var Route$40 = createFileRoute("/_authenticated/sales-orders")({ beforeLoad: () => {
	throw redirect({ to: "/invoices" });
} });
var Route$39 = createFileRoute("/_authenticated/sales-receipt")({ beforeLoad: () => {
	throw redirect({
		to: "/sales/$id",
		params: { id: "new" },
		search: {
			kind: "order",
			paid: 1
		}
	});
} });
var $$splitComponentImporter$20 = () => import("./sales-tax-Bkp0nipn.mjs");
var Route$38 = createFileRoute("/_authenticated/sales-tax")({
	head: () => ({ meta: [{ title: "Pay Sales Tax · Tallkeep" }, {
		name: "description",
		content: "Sales tax collected, what you owe the state, and paying it."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./settings-BLZf7C3r.mjs");
var Route$37 = createFileRoute("/_authenticated/settings")({
	head: () => ({ meta: [{ title: "Settings · Tallkeep" }, {
		name: "description",
		content: "Company info, users and options."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
/** Desktop: a copy of all the books every night, in a folder the office picks. */
var $$splitComponentImporter$18 = () => import("./setup-company-CF34HqIH.mjs");
var Route$36 = createFileRoute("/_authenticated/setup-company")({
	head: () => ({ meta: [{ title: "Set up a new company · Tallkeep" }, {
		name: "description",
		content: "Step-by-step setup of a new company."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./shelve--nA8B5_r.mjs");
var Route$35 = createFileRoute("/_authenticated/shelve")({
	head: () => ({ meta: [{ title: "Move to Shelves · Tallkeep" }, {
		name: "description",
		content: "Put items on a shelf with one tap — scan or search."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
/** Keeps the camera on so you can scan item after item. */
/** Add a product that isn't in the list yet, put it on this shelf and take its photos — one step. */
var $$splitComponentImporter$16 = () => import("./shoebox-BMHNW_ZQ.mjs");
var Route$34 = createFileRoute("/_authenticated/shoebox")({
	head: () => ({ meta: [{ title: "Shoebox · Tallkeep" }, {
		name: "description",
		content: "Drop statements, receipts, bills and checks: Tallkeep sorts them and puts them in the books."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./statements-BZZCk49S.mjs");
var Route$33 = createFileRoute("/_authenticated/statements")({
	head: () => ({ meta: [{ title: "Statements · Tallkeep" }, {
		name: "description",
		content: "Customer statements: what each customer still owes."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
/** The statement as a PDF (same layout as invoices). */
var $$splitComponentImporter$14 = () => import("./stock-DsxhB4uA.mjs");
var Route$32 = createFileRoute("/_authenticated/stock")({
	head: () => ({ meta: [{ title: "Stock · Tallkeep" }, {
		name: "description",
		content: "What you have and where it is."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./subscriptions-C8yvR4tW.mjs");
var Route$31 = createFileRoute("/_authenticated/subscriptions")({
	head: () => ({ meta: [{ title: "Bills, Rent & Subscriptions · Tallkeep" }, {
		name: "description",
		content: "Bills coming up, what your subscriptions cost, and repeating charges found in your bank."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./tech-pay-D3zWQL1d.mjs");
var Route$30 = createFileRoute("/_authenticated/tech-pay")({
	head: () => ({ meta: [{ title: "Technician Pay · Tallkeep" }, {
		name: "description",
		content: "What technicians asked to be paid, what was paid, and yearly totals."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./tickets-C4NEohFJ.mjs");
var Route$29 = createFileRoute("/_authenticated/tickets")({
	head: () => ({ meta: [{ title: "Tickets · Tallkeep" }, {
		name: "description",
		content: "Support tickets from your customers."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./transfer-Ci_6h469.mjs");
var Route$28 = createFileRoute("/_authenticated/transfer")({
	head: () => ({ meta: [{ title: "Transfer Stock · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./vendors-Ci_yA3zb.mjs");
var Route$27 = createFileRoute("/_authenticated/vendors")({
	head: () => ({ meta: [{ title: "Vendors · Tallkeep" }, {
		name: "description",
		content: "Companies you buy from."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./year-end-DB241kdW.mjs");
var Route$26 = createFileRoute("/_authenticated/year-end")({
	head: () => ({ meta: [{ title: "Year-End & CPA · Tallkeep" }, {
		name: "description",
		content: "Get the year ready, download the package for your accountant, close the books."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
/** Jan–Jun: last year is the one to finish. Jul–Dec: this year. */
var $$splitComponentImporter$7 = () => import("./admin-Dy8E9Xm5.mjs");
var Route$25 = createFileRoute("/admin/")({
	head: () => ({ meta: [{ title: "Overview · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./customers-I_BSeI4i.mjs");
var Route$24 = createFileRoute("/admin/customers")({
	head: () => ({ meta: [{ title: "Customers · Tallkeep Admin" }, {
		name: "description",
		content: "Every Tallkeep customer: trials, plans and usage."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./downloads-DpXTbC1N.mjs");
var Route$23 = createFileRoute("/admin/downloads")({
	head: () => ({ meta: [{ title: "Downloads · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./licenses-5QP_tEpw.mjs");
var Route$22 = createFileRoute("/admin/licenses")({
	head: () => ({ meta: [{ title: "Desktop licenses · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
/** Keys made outside this panel (like the owner's own): record them so office computers accept them. */
var $$splitComponentImporter$3 = () => import("./prices-DOGIzjWA.mjs");
var Route$21 = createFileRoute("/admin/prices")({
	head: () => ({ meta: [{ title: "Prices · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./testers-d_pUvPfF.mjs");
var Route$20 = createFileRoute("/admin/testers")({
	head: () => ({ meta: [{ title: "Early access & problems · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./waitlist-DiHiLgkw.mjs");
var Route$19 = createFileRoute("/admin/waitlist")({
	head: () => ({ meta: [{ title: "Waitlist · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
/** app.tallkeep.com/help opens the manual. (Support pages are /help/<company>.) */
var Route$18 = createFileRoute("/help/")({ beforeLoad: () => {
	throw redirect({ to: "/manual" });
} });
var $$splitComponentImporter = () => import("./manual.index-CY6I8Ekc.mjs");
/** The Tallkeep manual, open to everyone (tallkeep.com/help comes here). */
var Route$17 = createFileRoute("/manual/")({
	head: () => ({ meta: [{ title: "Tallkeep Manual" }, {
		name: "description",
		content: "How to do everything in Tallkeep, in plain words: sales, purchasing, inventory, banking and more."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var bad$1 = (message, status = 400) => Response.json({ message }, { status });
var okUrl$1 = (u) => typeof u === "string" && /^https?:\/\/[^\s]+$/.test(u);
var Route$16 = createFileRoute("/api/public/connect-api")({ server: { handlers: { POST: async ({ request }) => {
	let b;
	try {
		b = await request.json();
	} catch {
		return bad$1("Bad request");
	}
	const c = await import("./connect.server-B4rXGSDY.mjs");
	const lic = await c.licenseFromKey(String(b.licenseKey ?? ""));
	if (!lic) return bad$1("Tallkeep Connect needs a valid Tallkeep license.", 403);
	try {
		const { data: found } = await (await c.admin()).from("connect_subscriptions").select("*").eq("license_id", lic.id).maybeSingle();
		let row = found;
		if (b.action === "status") {
			const stale = !!row && (Date.now() - Date.parse(row.updated_at ?? "") > 432e5 || !!row.current_period_end && Date.parse(row.current_period_end) < Date.now());
			if (row?.stripe_subscription && (!c.isActive(row.status) || stale)) row = await c.syncSubscription(row.stripe_subscription).catch(() => row) ?? row;
			const { readPrices } = await import("./admin.functions-ClA-IMQf.mjs");
			const price = ((await readPrices().catch(() => null))?.prices)?.desktop?.connect_monthly ?? 0;
			if (!row || !c.isActive(row.status)) return Response.json({
				active: false,
				status: row?.status ?? "none",
				price
			});
			let problem = null;
			try {
				row = await c.provision(row, lic.to_name);
			} catch (e) {
				problem = e.message;
			}
			return Response.json({
				active: true,
				status: row.status,
				price,
				until: row.current_period_end,
				hostname: row.hostname,
				tunnelToken: problem ? null : row.tunnel_token,
				problem
			});
		}
		if (b.action === "subscribe") {
			if (!okUrl$1(b.returnUrl)) return bad$1("Bad request");
			if (row && c.isActive(row.status)) return bad$1("Tallkeep Connect is already on.");
			const { readPrices } = await import("./admin.functions-ClA-IMQf.mjs");
			const price = ((await readPrices())?.prices)?.desktop?.connect_monthly ?? 0;
			if (!(price > 0)) return bad$1("Tallkeep Connect's price isn't set yet.");
			const { stripe } = await import("./pay.server-YCWvjRs-.mjs");
			const back = new URL(b.returnUrl);
			const hash = back.hash;
			back.hash = "";
			back.searchParams.set("connect", "done");
			const success = `${back.toString()}&session={CHECKOUT_SESSION_ID}${hash}`;
			const s = await stripe("checkout/sessions", {
				mode: "subscription",
				"line_items[0][price_data][currency]": "usd",
				"line_items[0][price_data][product_data][name]": `Tallkeep Connect (license ${lic.id})`,
				"line_items[0][price_data][unit_amount]": Math.round(price * 100),
				"line_items[0][price_data][recurring][interval]": "month",
				"line_items[0][quantity]": 1,
				...row?.stripe_customer ? { customer: row.stripe_customer } : lic.email ? { customer_email: lic.email } : {},
				"metadata[product]": "tallkeep_connect",
				"metadata[license]": lic.id,
				"subscription_data[metadata][product]": "tallkeep_connect",
				"subscription_data[metadata][license]": lic.id,
				allow_promotion_codes: "true",
				success_url: success,
				cancel_url: b.returnUrl
			});
			return Response.json({ url: s.url });
		}
		if (b.action === "confirm") {
			const session = String(b.session ?? "");
			if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return bad$1("Bad request");
			const { stripe } = await import("./pay.server-YCWvjRs-.mjs");
			const s = await stripe(`checkout/sessions/${session}`);
			if (s.metadata?.["license"] !== lic.id || !s.subscription) return Response.json({ active: false });
			const synced = await c.syncSubscription(s.subscription);
			return Response.json({ active: c.isActive(synced?.status) });
		}
		if (b.action === "rename") {
			if (!row || !c.isActive(row.status)) return bad$1("Tallkeep Connect isn't on for this license.");
			const ready = await c.provision(row, lic.to_name);
			const moved = await c.rename(ready, String(b.name ?? ""));
			return Response.json({ hostname: moved.hostname });
		}
		if (b.action === "manage") {
			if (!okUrl$1(b.returnUrl)) return bad$1("Bad request");
			if (!row?.stripe_customer) return bad$1("Tallkeep Connect isn't on for this license.");
			const { stripe } = await import("./pay.server-YCWvjRs-.mjs");
			const p = await stripe("billing_portal/sessions", {
				customer: row.stripe_customer,
				return_url: b.returnUrl
			});
			return Response.json({ url: p.url });
		}
		return bad$1("Unknown action");
	} catch (e) {
		console.error("[connect-api]", e);
		return bad$1(e.message, 500);
	}
} } } });
/**
* Download the newest Tallkeep. ?for=server (or linux, synology, docker) gives the Synology/Linux
* (Docker) files as a .zip; otherwise Tallkeep for Windows.
* The Windows installer The installer is kept in parts (GitHub keeps files
* under 100 MB); this joins them into one file on the way to the customer.
*/
var RAW = "https://raw.githubusercontent.com/sunnyneon/tallkeep-desktop/main";
var Route$15 = createFileRoute("/api/public/download")({ server: { handlers: { GET: async ({ request }) => {
	const kind = new URL(request.url).searchParams.get("for") ?? "";
	if (/^(server|linux|synology|docker)$/i.test(kind)) {
		const z = await fetch(`${RAW}/tallkeep-docker.zip`, { cache: "no-store" });
		if (!z.ok || !z.body) return new Response("Download isn't available right now.", { status: 502 });
		return new Response(z.body, { headers: {
			"content-type": "application/zip",
			"content-disposition": "attachment; filename=\"tallkeep-docker.zip\"",
			"cache-control": "no-store"
		} });
	}
	const res = await fetch(`${RAW}/latest.json`, { cache: "no-store" });
	if (!res.ok) return new Response("Download isn't available right now.", { status: 502 });
	const info = await res.json();
	const urls = (info.parts?.length ? info.parts : [{ name: info.file }]).map((p) => `${RAW}/v${info.version}/${p.name}`);
	const stream = new ReadableStream({ async start(ctl) {
		try {
			for (const u of urls) {
				const r = await fetch(u);
				if (!r.ok || !r.body) throw new Error(`part ${r.status}`);
				const reader = r.body.getReader();
				for (;;) {
					const { done, value } = await reader.read();
					if (done) break;
					ctl.enqueue(value);
				}
			}
			ctl.close();
		} catch (e) {
			ctl.error(e);
		}
	} });
	return new Response(stream, { headers: {
		"content-type": "application/octet-stream",
		"content-disposition": `attachment; filename="${info.file}"`,
		...info.size ? { "content-length": String(info.size) } : {},
		"cache-control": "no-store"
	} });
} } } });
/**
* A file on a support ticket, for the customer: /api/public/help-file?key=<ticket key>&path=<file>.
* Only files on that ticket's messages (never on internal notes).
*/
var Route$14 = createFileRoute("/api/public/help-file")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const key = url.searchParams.get("key") ?? "";
	const path = url.searchParams.get("path") ?? "";
	if (!/^[a-f0-9]{32,80}$/.test(key) || !path) return new Response("Not found", { status: 404 });
	const s = await import("./support.server-Bv8yioBw.mjs");
	const { data: t } = await s.admin.from("tickets").select("id,company_id").eq("public_key", key).maybeSingle();
	if (!t || !path.startsWith(`${t.company_id}/${t.id}/`)) return new Response("Not found", { status: 404 });
	const { data: msgs } = await s.admin.from("ticket_messages").select("files").eq("ticket_id", t.id).in("kind", ["customer", "staff"]);
	const file = (msgs ?? []).flatMap((m) => m.files ?? []).find((f) => f.path === path);
	if (!file) return new Response("Not found", { status: 404 });
	const { data, error } = await s.admin.storage.from(s.BUCKET).download(path);
	if (error || !data) return new Response("Not found", { status: 404 });
	const name = (file.name || "file").replace(/["\r\n]/g, "");
	const type = String(file.type || "").toLowerCase();
	const safe = /^image\/(png|jpe?g|gif|webp|heic|heif)$/.test(type) || type === "application/pdf";
	return new Response(data, { headers: {
		"content-type": safe ? type : "application/octet-stream",
		"content-disposition": `${safe ? "inline" : "attachment"}; filename="${name}"`,
		"x-content-type-options": "nosniff",
		"cache-control": "private, max-age=300"
	} });
} } } });
/**
* Tallkeep Desktop says hello once a day (trial or licensed), so we know how many computers
* actually run it. It sends only a random code for the computer, the version, Windows or Linux,
* when its trial started, and whether it has a license. No names, no books.
*/
var Route$13 = createFileRoute("/api/public/install-ping")({ server: { handlers: { POST: async ({ request }) => {
	let b;
	try {
		b = await request.json();
	} catch {
		return new Response("Bad request", { status: 400 });
	}
	const machine = String(b.machine ?? "");
	if (!/^[a-f0-9]{32,64}$/.test(machine)) return new Response("Bad request", { status: 400 });
	const started = b.trialStarted ? Date.parse(b.trialStarted) : NaN;
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.from("installs").upsert({
		machine,
		last_seen: (/* @__PURE__ */ new Date()).toISOString(),
		version: String(b.version ?? "").slice(0, 40) || null,
		platform: b.platform === "windows" ? "windows" : b.platform === "linux" ? "linux" : null,
		trial_started: Number.isFinite(started) ? new Date(started).toISOString() : null,
		licensed: !!b.licensed
	}, { onConflict: "machine" }).then(() => null, () => null);
	return Response.json({ ok: true });
} } } });
/**
* Tallkeep Desktop asks here whether its license key is good: one we made, still on, and on this
* computer (or there's room for it). Answers:
*   { status: "ok", token }      the token (signed by us) lets the computer work offline for 45 days
*   { status: "unknown" }        we didn't make this key
*   { status: "off" }            the key was switched off (refund, leak)
*   { status: "elsewhere", computers: ["NAME", …] }   the key is in use on other computers
*/
var DAY = 864e5;
var TOKEN_DAYS = 45;
var STALE_DAYS = 30;
var Route$12 = createFileRoute("/api/public/license-check")({ server: { handlers: { POST: async ({ request }) => {
	let body;
	try {
		body = await request.json();
	} catch {
		return Response.json({
			status: "error",
			message: "Bad request"
		}, { status: 400 });
	}
	const key = String(body.key ?? "").replace(/\s+/g, "");
	const machine = String(body.machine ?? "");
	if (!key.startsWith("TK1.") || !/^[a-f0-9]{32,64}$/.test(machine)) return Response.json({
		status: "error",
		message: "Bad request"
	}, { status: 400 });
	const pem = (await import("./license-pem-Bul1iZky.mjs")).licensePem();
	if (!pem.includes("PRIVATE KEY")) return Response.json({
		status: "error",
		message: "Not set up"
	}, { status: 503 });
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { keyId } = await import("./license.server-Bu3IQdFy.mjs");
	const id = await keyId(key);
	const { data: lic } = id ? await db.from("desktop_licenses").select("id,revoked,computers,license_key").eq("id", id).maybeSingle() : { data: null };
	if (!lic) return Response.json({ status: "unknown" });
	const newKey = lic.license_key !== key ? lic.license_key : void 0;
	if (lic.revoked) return Response.json({ status: "off" });
	const now = Date.now();
	const { data: acts } = await db.from("desktop_activations").select("id,machine,machine_name,last_seen,released_at").eq("license_id", lic.id);
	const all = acts ?? [];
	const mine = all.find((a) => a.machine === machine);
	const others = all.filter((a) => a.machine !== machine && !a.released_at && now - Date.parse(a.last_seen) < STALE_DAYS * DAY);
	if (!(mine && !mine.released_at) && others.length >= (lic.computers ?? 1)) return Response.json({
		status: "elsewhere",
		computers: others.map((a) => a.machine_name ?? "another computer")
	});
	const row = {
		license_id: lic.id,
		machine,
		machine_name: String(body.name ?? "").slice(0, 80) || null,
		app_version: String(body.version ?? "").slice(0, 20) || null,
		last_seen: new Date(now).toISOString(),
		released_at: null
	};
	const { error } = mine ? await db.from("desktop_activations").update(row).eq("id", mine.id) : await db.from("desktop_activations").insert(row);
	if (error) return Response.json({
		status: "error",
		message: "Try again later"
	}, { status: 500 });
	const crypto = await import("node:crypto");
	const payload = {
		v: 1,
		lic: lic.id,
		m: machine,
		until: new Date(now + TOKEN_DAYS * DAY).toISOString()
	};
	const head = `TKA1.${Buffer.from(JSON.stringify(payload)).toString("base64url")}`;
	const sig = crypto.sign(null, Buffer.from(head), pem).toString("base64url");
	return Response.json({
		status: "ok",
		token: `${head}.${sig}`,
		...newKey ? { newKey } : {}
	});
} } } });
var bad = (message, status = 400) => Response.json({ message }, { status });
var okUrl = (u) => typeof u === "string" && /^https?:\/\/[^\s]+$/.test(u);
var Route$11 = createFileRoute("/api/public/pay-api")({ server: { handlers: { POST: async ({ request }) => {
	let b;
	try {
		b = await request.json();
	} catch {
		return bad("Bad request");
	}
	const p = await import("./pay.server-YCWvjRs-.mjs");
	const origin = new URL(request.url).origin;
	try {
		const db = await p.admin();
		if (b.action === "connect") {
			const key = String(b.licenseKey ?? "").replace(/\s+/g, "");
			if (!key.startsWith("TK1.")) return bad("Enter your Tallkeep license key first.");
			const { data: lic } = await db.from("desktop_licenses").select("id,revoked").eq("license_key", key).maybeSingle();
			if (!lic || lic.revoked) return bad("Card payments need a valid Tallkeep license.", 403);
			const companyRef = String(b.companyRef ?? "");
			const name = String(b.businessName ?? "").trim().slice(0, 100) || "Business";
			if (!/^[0-9a-f-]{36}$/.test(companyRef)) return bad("Bad request");
			if (!okUrl(b.returnUrl)) return bad("Bad request");
			let { data: m } = await db.from("pay_merchants").select("*").eq("license_id", lic.id).eq("company_ref", companyRef).maybeSingle();
			if (!m) {
				const ins = await db.from("pay_merchants").insert({
					license_id: lic.id,
					company_ref: companyRef,
					business_name: name,
					email: b.email || null,
					merchant_key: p.randomToken(24)
				}).select("*").single();
				if (ins.error) throw new Error(ins.error.message);
				m = ins.data;
			}
			if (b.existing) {
				const clientId = process.env["STRIPE_CONNECT_CLIENT_ID"];
				if (!clientId) return bad("Connecting an existing Stripe account isn't open yet. Use Create a new Stripe account.");
				const state = p.randomToken(24);
				await db.from("pay_merchants").update({
					oauth_state: state,
					oauth_return: b.returnUrl
				}).eq("id", m.id);
				const q = new URLSearchParams({
					response_type: "code",
					client_id: clientId,
					scope: "read_write",
					state,
					redirect_uri: `${origin}/api/public/stripe-oauth`,
					...b.email ? { "stripe_user[email]": b.email } : {},
					"stripe_user[business_name]": name
				});
				const base = process.env["STRIPE_CONNECT_BASE"] || "https://connect.stripe.com";
				return Response.json({
					merchantKey: m.merchant_key,
					url: `${base}/oauth/authorize?${q}`
				});
			}
			if (m.stripe_account) m = await p.refreshMerchant(m);
			if (!m.stripe_account) {
				const acct = await p.stripe("accounts", {
					type: "standard",
					email: b.email || void 0,
					"business_profile[name]": name,
					"metadata[tallkeep_license]": lic.id,
					"metadata[tallkeep_company]": companyRef
				});
				await db.from("pay_merchants").update({ stripe_account: acct.id }).eq("id", m.id);
				m.stripe_account = acct.id;
			}
			const url = await p.onboardingLink(m, b.returnUrl);
			return Response.json({
				merchantKey: m.merchant_key,
				url
			});
		}
		const m = await p.merchantByKey(String(b.merchantKey ?? ""));
		if (!m) return bad("Not connected", 401);
		if (b.action === "status") {
			const fresh = await p.refreshMerchant(m);
			const url = fresh.stripe_account && !fresh.charges_enabled && okUrl(b.returnUrl) ? await p.onboardingLink(fresh, b.returnUrl) : null;
			const st = p.stripeState(fresh);
			return Response.json({
				connected: fresh.charges_enabled,
				submitted: st?.submitted ?? false,
				needs: st?.needs ?? [],
				why: st?.why ?? null,
				businessName: fresh.business_name,
				onboardingUrl: url,
				appFeePct: await p.appFeePct()
			});
		}
		if (b.action === "request") {
			if (!m.charges_enabled) {
				if (!(await p.refreshMerchant(m)).charges_enabled) return bad("Finish setting up Stripe first (Settings → Company → Card payments).");
			}
			const invoiceRef = String(b.invoiceRef ?? "");
			const cents = Math.round(Number(b.amountCents));
			if (!invoiceRef || !(cents > 0)) return bad("Nothing is owed on this invoice.");
			const row = {
				number: String(b.number ?? "").slice(0, 60) || null,
				customer_name: String(b.customerName ?? "").slice(0, 120) || null,
				customer_email: String(b.customerEmail ?? "").slice(0, 200) || null,
				amount_cents: cents,
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			};
			const { data: open } = await db.from("pay_requests").select("id,token").eq("merchant_id", m.id).eq("invoice_ref", invoiceRef).eq("status", "open").maybeSingle();
			let token;
			if (open) {
				await db.from("pay_requests").update(row).eq("id", open.id);
				token = open.token;
			} else {
				token = p.randomToken(15);
				const ins = await db.from("pay_requests").insert({
					...row,
					token,
					merchant_id: m.id,
					invoice_ref: invoiceRef
				});
				if (ins.error) throw new Error(ins.error.message);
			}
			return Response.json({ url: `${origin}/pay/${token}` });
		}
		if (b.action === "disconnect") {
			await db.from("pay_requests").update({
				status: "canceled",
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("merchant_id", m.id).eq("status", "open");
			await db.from("pay_merchants").update({
				stripe_account: null,
				charges_enabled: false
			}).eq("id", m.id);
			return Response.json({ ok: true });
		}
		if (b.action === "cancel") {
			await db.from("pay_requests").update({
				status: "canceled",
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("merchant_id", m.id).eq("invoice_ref", String(b.invoiceRef ?? "")).eq("status", "open");
			return Response.json({ ok: true });
		}
		if (b.action === "updates") {
			const ack = (b.ack ?? []).filter((x) => /^[0-9a-f-]{36}$/.test(x)).slice(0, 500);
			if (ack.length) await db.from("pay_requests").update({ picked_up_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("merchant_id", m.id).in("id", ack);
			const { data: paid } = await db.from("pay_requests").select("id,invoice_ref,number,paid_cents,fee_cents,paid_at,payment_intent,customer_name").eq("merchant_id", m.id).eq("status", "paid").is("picked_up_at", null).limit(200);
			return Response.json({ payments: paid ?? [] });
		}
		return bad("Unknown action");
	} catch (e) {
		console.error("[pay-api]", e);
		return bad(e.message, 500);
	}
} } } });
var CORS = {
	"access-control-allow-origin": "*",
	"access-control-allow-methods": "GET, OPTIONS",
	"cache-control": "public, max-age=300"
};
/** Tallkeep's price list for tallkeep.com/pricing. Public: prices are no secret. */
var Route$10 = createFileRoute("/api/public/prices")({ server: { handlers: {
	OPTIONS: () => new Response(null, {
		status: 204,
		headers: CORS
	}),
	GET: async () => {
		const { readPrices } = await import("./admin.functions-ClA-IMQf.mjs");
		try {
			const row = await readPrices();
			if (!row) return new Response("Not set", {
				status: 404,
				headers: CORS
			});
			return Response.json(row, { headers: CORS });
		} catch (e) {
			console.error("[prices]", e);
			return new Response("Failed", {
				status: 500,
				headers: CORS
			});
		}
	}
} } });
/**
* "Report a problem" from Tallkeep on an office computer (the office computer adds its license
* key, version and edition). Kept for Tallkeep and emailed to hello@tallkeep.com.
*/
var Route$9 = createFileRoute("/api/public/report")({ server: { handlers: { POST: async ({ request }) => {
	try {
		const raw = await request.text();
		if (raw.length > 8e6) return Response.json({ message: "Too big." }, { status: 413 });
		const body = JSON.parse(raw);
		const { saveProblem } = await import("./testers.functions-B2bSimrA.mjs").then((n) => n.c);
		return Response.json(await saveProblem(body));
	} catch (e) {
		return Response.json({ message: e.message }, { status: 400 });
	}
} } } });
/**
* A unit's booked nights as a calendar (.ics), for Airbnb/VRBO/Booking.com to read so they block
* nights booked elsewhere. The link carries the unit's secret calendar token; it shows only
* "Booked" and the dates, never guests' names.
*/
var Route$8 = createFileRoute("/api/public/stay-calendar")({ server: { handlers: { GET: async ({ request }) => {
	const q = new URL(request.url).searchParams;
	const t = q.get("t") ?? "";
	const not = q.get("not") ?? "";
	if (!/^[0-9a-f-]{36}$/i.test(t)) return new Response("Not found", { status: 404 });
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { data: unit } = await db.from("units").select("id,name,rental_type").eq("calendar_token", t).maybeSingle();
	if (!unit) return new Response("Not found", { status: 404 });
	const since = (/* @__PURE__ */ new Date(Date.now() - 5184e6)).toISOString().slice(0, 10);
	const { data: stays } = await db.from("stays").select("id,check_in,check_out,channel").eq("unit_id", unit.id).neq("status", "canceled").gte("check_out", since).order("check_in").limit(2e3);
	const d = (s) => s.replace(/-/g, "");
	const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
	const lines = [
		"BEGIN:VCALENDAR",
		"VERSION:2.0",
		"PRODID:-//Tallkeep//Stays//EN",
		"CALSCALE:GREGORIAN",
		`X-WR-CALNAME:${String(unit.name).replace(/[\r\n,;]/g, " ")} (Tallkeep)`
	];
	const list = (stays ?? []).filter((s) => s.channel !== not);
	for (const s of list) lines.push("BEGIN:VEVENT", `UID:${s.id}@tallkeep`, `DTSTAMP:${stamp}`, `DTSTART;VALUE=DATE:${d(s.check_in)}`, `DTEND;VALUE=DATE:${d(s.check_out)}`, "SUMMARY:Booked (Tallkeep)", "END:VEVENT");
	lines.push("END:VCALENDAR");
	return new Response(`${lines.join("\r\n")}\r\n`, { headers: {
		"content-type": "text/calendar; charset=utf-8",
		"cache-control": "no-store"
	} });
} } } });
/**
* Back from Stripe after a business signed in to its existing Stripe account (Connect OAuth).
* Swap Stripe's one-time code for the account id, remember it, and send the person back to
* Tallkeep (the office computer's Settings page).
*/
var Route$7 = createFileRoute("/api/public/stripe-oauth")({ server: { handlers: { GET: async ({ request }) => {
	const q = new URL(request.url).searchParams;
	const state = q.get("state") ?? "";
	const p = await import("./pay.server-YCWvjRs-.mjs");
	const db = await p.admin();
	const page = (title, text) => new Response(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${title}</title><body style="font-family:Arial,sans-serif;max-width:480px;margin:60px auto;padding:0 16px"><h2>${title}</h2><p>${text}</p></body>`, {
		status: 400,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
	if (!/^[A-Za-z0-9_-]{20,}$/.test(state)) return page("Link expired", "Go back to Tallkeep and press Connect again.");
	const { data: m } = await db.from("pay_merchants").select("*").eq("oauth_state", state).maybeSingle();
	if (!m) return page("Link expired", "Go back to Tallkeep and press Connect again.");
	const back = (extra) => {
		const u = new URL(m.oauth_return);
		u.searchParams.set("card", extra);
		return Response.redirect(u.toString(), 302);
	};
	await db.from("pay_merchants").update({ oauth_state: null }).eq("id", m.id);
	if (q.get("error") || !q.get("code")) return back("canceled");
	try {
		const base = process.env["STRIPE_CONNECT_BASE"] || "https://connect.stripe.com";
		const res = await fetch(`${base}/oauth/token`, {
			method: "POST",
			headers: {
				Authorization: `Bearer ${process.env["STRIPE_SECRET_KEY"] ?? ""}`,
				"Content-Type": "application/x-www-form-urlencoded"
			},
			body: new URLSearchParams({
				grant_type: "authorization_code",
				code: q.get("code")
			})
		});
		const out = await res.json();
		if (!res.ok || !out.stripe_user_id) throw new Error(out.error_description ?? `${res.status}`);
		await db.from("pay_merchants").update({
			stripe_account: out.stripe_user_id,
			charges_enabled: false
		}).eq("id", m.id);
		await p.refreshMerchant({
			...m,
			stripe_account: out.stripe_user_id
		}).catch(() => null);
		return back("connected");
	} catch (e) {
		console.error("[stripe-oauth]", e);
		return back("failed");
	}
} } } });
/**
* Stripe tells us here when a checkout is paid, so the key is made and emailed even if the
* customer closes the page before coming back. We don't trust what's sent: fulfill() asks Stripe
* itself whether that checkout is paid.
*/
var Route$6 = createFileRoute("/api/public/stripe-webhook")({ server: { handlers: { POST: async ({ request }) => {
	let ev;
	try {
		ev = await request.json();
	} catch {
		return new Response("Bad request", { status: 400 });
	}
	const id = ev.data?.object?.id;
	const obj = ev.data?.object;
	if (!ev.account && obj?.metadata?.["product"] === "tallkeep_online") {
		const subId = obj.object === "subscription" ? obj.id : obj.subscription;
		if (subId) {
			const { syncOnline } = await import("./online.server-iztHCltD.mjs");
			try {
				await syncOnline(subId);
			} catch (e) {
				console.error("[stripe-webhook online]", e);
				return new Response("Try again", { status: 500 });
			}
		}
		return Response.json({ received: true });
	}
	if (!ev.account && obj?.metadata?.["product"] === "tallkeep_connect") {
		const subId = obj.object === "subscription" ? obj.id : obj.subscription;
		if (subId) {
			const { syncSubscription } = await import("./connect.server-B4rXGSDY.mjs");
			try {
				await syncSubscription(subId);
			} catch (e) {
				console.error("[stripe-webhook connect]", e);
				return new Response("Try again", { status: 500 });
			}
		}
		return Response.json({ received: true });
	}
	const payReq = ev.data?.object?.metadata?.["pay_request"];
	if (ev.account && payReq && id && ev.type?.startsWith("checkout.session.")) {
		const { fulfillPay } = await import("./pay.server-YCWvjRs-.mjs");
		try {
			await fulfillPay(payReq, id);
		} catch (e) {
			console.error("[stripe-webhook pay]", e);
			return new Response("Try again", { status: 500 });
		}
		return Response.json({ received: true });
	}
	if ((ev.type === "checkout.session.completed" || ev.type === "checkout.session.async_payment_succeeded") && id) {
		const { fulfill } = await import("./buy.functions-bxK2SnPK.mjs");
		const { fulfillUpgrade } = await import("./upgrade.functions-VhVHts_7.mjs");
		try {
			if (ev.data?.object?.metadata?.["product"] === "tallkeep_upgrade") await fulfillUpgrade(id);
			else await fulfill(id);
		} catch (e) {
			console.error("[stripe-webhook]", e);
			return new Response("Try again", { status: 500 });
		}
	}
	return Response.json({ received: true });
} } } });
/** "Stop these emails" from a trial email: no more trial emails to this address. */
var Route$5 = createFileRoute("/api/public/unsubscribe")({ server: { handlers: { GET: async ({ request }) => {
	const u = new URL(request.url);
	const email = (u.searchParams.get("e") ?? "").trim().toLowerCase();
	const code = u.searchParams.get("c") ?? "";
	const page = (msg, status = 200) => new Response(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Tallkeep</title><body style="font-family:system-ui,sans-serif;max-width:480px;margin:80px auto;padding:0 20px;color:#14202b"><h1 style="font-size:22px">Tallkeep</h1><p>${msg}</p></body>`, {
		status,
		headers: { "content-type": "text/html; charset=utf-8" }
	});
	const { optoutCode } = await import("./trialmail.server-DD0g_RsZ.mjs");
	if (!/^\S+@\S+\.\S+$/.test(email) || code !== optoutCode(email)) return page("This link isn't right. Write to hello@tallkeep.com and we'll stop the emails.", 400);
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.from("email_optout").upsert({ email }, { onConflict: "email" });
	return page("Done. We won't send you any more of these emails. (Receipts and messages you ask for still come.)");
} } } });
async function authenticateCronRequest(request) {
	const currentSecret = process.env["LOVABLE_CRON_SECRET"];
	const previousSecret = process.env["LOVABLE_CRON_SECRET_PREVIOUS"];
	if (!currentSecret) return new Response("Server configuration error", { status: 500 });
	const token = /^Bearer ([^\s,]+)$/.exec(request.headers.get("authorization") ?? "")?.[1];
	if (!token) return new Response("Unauthorized", { status: 401 });
	const { createHash, timingSafeEqual } = await import("node:crypto");
	const digest = (value) => createHash("sha256").update(value, "utf8").digest();
	const providedDigest = digest(token);
	const currentMatches = timingSafeEqual(providedDigest, digest(currentSecret));
	const previousMatches = timingSafeEqual(providedDigest, digest(previousSecret ?? currentSecret));
	if (!currentMatches && !previousMatches) return new Response("Unauthorized", { status: 401 });
	return null;
}
/**
* Daily job (scheduled in Lovable, early morning):
* - makes payments and bills that repeat (Recurring page) when their day comes;
* - for every company with the Real estate feature on, charges rent that is due today or
*   earlier, and adds late fees for rent still unpaid after the grace days.
* Nothing is ever made twice.
*/
var Route$4 = createFileRoute("/api/public/cron/daily-rent")({ server: { handlers: { POST: async ({ request }) => {
	const denied = await authenticateCronRequest(request);
	if (denied) return denied;
	try {
		const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
		const db = supabaseAdmin;
		const today = new Intl.DateTimeFormat("en-CA", { timeZone: "America/Chicago" }).format(/* @__PURE__ */ new Date());
		const { data, error } = await db.from("company_settings").select("company_id,addons");
		if (error) throw new Error(error.message);
		const out = {};
		const made = {};
		for (const c of data ?? []) {
			const r = await db.rpc("run_recurring_company", {
				_co: c.company_id,
				_today: today
			});
			if (r.error && !/does not exist|could not find/i.test(r.error.message)) throw new Error(r.error.message);
			made[c.company_id] = r.data ?? 0;
			if (!(c.addons ?? []).includes("real_estate")) continue;
			const a = await db.rpc("generate_rent_company", {
				_co: c.company_id,
				_through: today
			});
			if (a.error) throw new Error(a.error.message);
			const b = await db.rpc("apply_late_fees_company", {
				_co: c.company_id,
				_asof: today
			});
			if (b.error) throw new Error(b.error.message);
			out[c.company_id] = {
				charged: a.data,
				late_fees: b.data
			};
		}
		return Response.json({
			day: today,
			companies: out,
			recurring: made
		});
	} catch (e) {
		console.error("[daily-rent]", e);
		return new Response("Failed", { status: 500 });
	}
} } } });
/** Nightly job (scheduled in Lovable): save a full backup of the office data. */
var Route$3 = createFileRoute("/api/public/cron/nightly-backup")({ server: { handlers: { POST: async ({ request }) => {
	const denied = await authenticateCronRequest(request);
	if (denied) return denied;
	const { makeBackup } = await import("./backup.server-CZzlxvQy.mjs");
	try {
		return Response.json(await makeBackup("nightly"));
	} catch (e) {
		console.error("[nightly-backup]", e);
		return new Response("Failed", { status: 500 });
	}
} } } });
/** Daily job (scheduled in Lovable): quote follow-ups and closing old quotes. */
var Route$2 = createFileRoute("/api/public/cron/quote-followups")({ server: { handlers: { POST: async ({ request }) => {
	const denied = await authenticateCronRequest(request);
	if (denied) return denied;
	const { runQuoteFollowups } = await import("./followups.server-DkN3NZxb.mjs");
	try {
		return Response.json(await runQuoteFollowups());
	} catch (e) {
		console.error("[quote-followups]", e);
		return new Response("Failed", { status: 500 });
	}
} } } });
/** Daily job (scheduled in Lovable): the short free-trial emails. */
var Route$1 = createFileRoute("/api/public/cron/trial-emails")({ server: { handlers: { POST: async ({ request }) => {
	const denied = await authenticateCronRequest(request);
	if (denied) return denied;
	const { runTrialEmails } = await import("./trialmail.server-DD0g_RsZ.mjs");
	try {
		return Response.json(await runTrialEmails());
	} catch (e) {
		console.error("[trial-emails]", e);
		return new Response("Failed", { status: 500 });
	}
} } } });
/**
* For the Synology: download the newest backup file.
* Needs the header  x-backup-key: <BACKUP_KEY secret>.
*/
var Route = createFileRoute("/api/public/office/backup-latest")({ server: { handlers: { GET: async ({ request }) => {
	const key = process.env["BACKUP_KEY"];
	const sent = request.headers.get("x-backup-key") ?? "";
	if (!key || key.length < 20 || sent !== key) return new Response("Not allowed", { status: 401 });
	const { listBackupFiles, readBackup } = await import("./backup.server-CZzlxvQy.mjs");
	const latest = (await listBackupFiles())[0];
	if (!latest) return new Response("No backup yet", { status: 404 });
	const blob = await readBackup(latest.name);
	return new Response(blob, { headers: {
		"Content-Type": "application/gzip",
		"Content-Disposition": `attachment; filename="${latest.name}"`,
		"Cache-Control": "no-store"
	} });
} } } });
var AuthenticatedRouteRoute = Route$116.update({
	id: "/_authenticated",
	getParentRoute: () => Route$87
});
var AdminRouteRoute = Route$115.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$87
});
var AuthRoute = Route$86.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$87
});
var BuyRoute = Route$93.update({
	id: "/buy",
	path: "/buy",
	getParentRoute: () => Route$87
});
var DownloadRoute = Route$100.update({
	id: "/download",
	path: "/download",
	getParentRoute: () => Route$87
});
var EarlyAccessRoute = Route$85.update({
	id: "/early-access",
	path: "/early-access",
	getParentRoute: () => Route$87
});
var ResetPasswordRoute = Route$84.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$87
});
var SignupRoute = Route$117.update({
	id: "/signup",
	path: "/signup",
	getParentRoute: () => Route$87
});
var TestersRoute = Route$83.update({
	id: "/testers",
	path: "/testers",
	getParentRoute: () => Route$87
});
var UpgradeRoute = Route$118.update({
	id: "/upgrade",
	path: "/upgrade",
	getParentRoute: () => Route$87
});
var WelcomeRoute = Route$82.update({
	id: "/welcome",
	path: "/welcome",
	getParentRoute: () => Route$87
});
var AuthenticatedIndexRoute = Route$88.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAccountsRoute = Route$81.update({
	id: "/accounts",
	path: "/accounts",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAdjustRoute = Route$80.update({
	id: "/adjust",
	path: "/adjust",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedAiRoute = Route$79.update({
	id: "/ai",
	path: "/ai",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBankTransfersRoute = Route$90.update({
	id: "/bank-transfers",
	path: "/bank-transfers",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBankingRoute = Route$91.update({
	id: "/banking",
	path: "/banking",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBillsRoute = Route$78.update({
	id: "/bills",
	path: "/bills",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBudgetRoute = Route$77.update({
	id: "/budget",
	path: "/budget",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCalendarRoute = Route$76.update({
	id: "/calendar",
	path: "/calendar",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCardRegisterRoute = Route$95.update({
	id: "/card-register",
	path: "/card-register",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCategoriesRoute = Route$75.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedChecksRoute = Route$74.update({
	id: "/checks",
	path: "/checks",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedChecksReceivedRoute = Route$73.update({
	id: "/checks-received",
	path: "/checks-received",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCountRoute = Route$72.update({
	id: "/count",
	path: "/count",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCreditCardsRoute = Route$71.update({
	id: "/credit-cards",
	path: "/credit-cards",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCryptoTaxRoute = Route$70.update({
	id: "/crypto-tax",
	path: "/crypto-tax",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCustomersRoute = Route$69.update({
	id: "/customers",
	path: "/customers",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDepositsRoute = Route$68.update({
	id: "/deposits",
	path: "/deposits",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDocumentsRoute = Route$67.update({
	id: "/documents",
	path: "/documents",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedFastEntryRoute = Route$66.update({
	id: "/fast-entry",
	path: "/fast-entry",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedFinancialsRoute = Route$101.update({
	id: "/financials",
	path: "/financials",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedForms1099Route = Route$65.update({
	id: "/forms-1099",
	path: "/forms-1099",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedHouseholdRoute = Route$64.update({
	id: "/household",
	path: "/household",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedInvestmentsRoute = Route$63.update({
	id: "/investments",
	path: "/investments",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedInvoicesRoute = Route$62.update({
	id: "/invoices",
	path: "/invoices",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedJournalRoute = Route$105.update({
	id: "/journal",
	path: "/journal",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLabelsRoute = Route$61.update({
	id: "/labels",
	path: "/labels",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLeasesRoute = Route$106.update({
	id: "/leases",
	path: "/leases",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLoansRoute = Route$60.update({
	id: "/loans",
	path: "/loans",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedLocationsRoute = Route$59.update({
	id: "/locations",
	path: "/locations",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMonthlyReviewRoute = Route$58.update({
	id: "/monthly-review",
	path: "/monthly-review",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedMovementsRoute = Route$57.update({
	id: "/movements",
	path: "/movements",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNetWorthRoute = Route$56.update({
	id: "/net-worth",
	path: "/net-worth",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNewInvoiceRoute = Route$55.update({
	id: "/new-invoice",
	path: "/new-invoice",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedNewQuoteRoute = Route$54.update({
	id: "/new-quote",
	path: "/new-quote",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedOverviewRoute = Route$53.update({
	id: "/overview",
	path: "/overview",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPayBillsRoute = Route$52.update({
	id: "/pay-bills",
	path: "/pay-bills",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPayrollRoute = Route$51.update({
	id: "/payroll",
	path: "/payroll",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPlanRoute = Route$109.update({
	id: "/plan",
	path: "/plan",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPrintChecksRoute = Route$111.update({
	id: "/print-checks",
	path: "/print-checks",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProductsRoute = Route$96.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPropertiesRoute = Route$50.update({
	id: "/properties",
	path: "/properties",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPurchaseOrdersRoute = Route$49.update({
	id: "/purchase-orders",
	path: "/purchase-orders",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedQuotesRoute = Route$48.update({
	id: "/quotes",
	path: "/quotes",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedReceiptsRoute = Route$47.update({
	id: "/receipts",
	path: "/receipts",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRecurringRoute = Route$113.update({
	id: "/recurring",
	path: "/recurring",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRefundsRoute = Route$46.update({
	id: "/refunds",
	path: "/refunds",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRegisterRoute = Route$114.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRentRoute = Route$45.update({
	id: "/rent",
	path: "/rent",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRentRollRoute = Route$44.update({
	id: "/rent-roll",
	path: "/rent-roll",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedReportsRoute = Route$43.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRmaRoute = Route$42.update({
	id: "/rma",
	path: "/rma",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalesListRoute = Route$41.update({
	id: "/sales-list",
	path: "/sales-list",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalesOrdersRoute = Route$40.update({
	id: "/sales-orders",
	path: "/sales-orders",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalesReceiptRoute = Route$39.update({
	id: "/sales-receipt",
	path: "/sales-receipt",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalesTaxRoute = Route$38.update({
	id: "/sales-tax",
	path: "/sales-tax",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSettingsRoute = Route$37.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSetupCompanyRoute = Route$36.update({
	id: "/setup-company",
	path: "/setup-company",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedShelveRoute = Route$35.update({
	id: "/shelve",
	path: "/shelve",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedShoeboxRoute = Route$34.update({
	id: "/shoebox",
	path: "/shoebox",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedStatementsRoute = Route$33.update({
	id: "/statements",
	path: "/statements",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedStaysRoute = Route$119.update({
	id: "/stays",
	path: "/stays",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedStockRoute = Route$32.update({
	id: "/stock",
	path: "/stock",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSubscriptionsRoute = Route$31.update({
	id: "/subscriptions",
	path: "/subscriptions",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTechPayRoute = Route$30.update({
	id: "/tech-pay",
	path: "/tech-pay",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTicketsRoute = Route$29.update({
	id: "/tickets",
	path: "/tickets",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTransferRoute = Route$28.update({
	id: "/transfer",
	path: "/transfer",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVendorsRoute = Route$27.update({
	id: "/vendors",
	path: "/vendors",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedWebsiteTicketsRoute = Route$120.update({
	id: "/website-tickets",
	path: "/website-tickets",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedWorkOrdersRoute = Route$121.update({
	id: "/work-orders",
	path: "/work-orders",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedYearEndRoute = Route$26.update({
	id: "/year-end",
	path: "/year-end",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AdminIndexRoute = Route$25.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRouteRoute
});
var AdminCustomersRoute = Route$24.update({
	id: "/customers",
	path: "/customers",
	getParentRoute: () => AdminRouteRoute
});
var AdminDownloadsRoute = Route$23.update({
	id: "/downloads",
	path: "/downloads",
	getParentRoute: () => AdminRouteRoute
});
var AdminLicensesRoute = Route$22.update({
	id: "/licenses",
	path: "/licenses",
	getParentRoute: () => AdminRouteRoute
});
var AdminPricesRoute = Route$21.update({
	id: "/prices",
	path: "/prices",
	getParentRoute: () => AdminRouteRoute
});
var AdminTestersRoute = Route$20.update({
	id: "/testers",
	path: "/testers",
	getParentRoute: () => AdminRouteRoute
});
var AdminWaitlistRoute = Route$19.update({
	id: "/waitlist",
	path: "/waitlist",
	getParentRoute: () => AdminRouteRoute
});
var BuyDoneRoute = Route$94.update({
	id: "/buy_/done",
	path: "/buy/done",
	getParentRoute: () => Route$87
});
var HelpIndexRoute = Route$18.update({
	id: "/help/",
	path: "/help/",
	getParentRoute: () => Route$87
});
var HelpSlugRoute = Route$103.update({
	id: "/help/$slug",
	path: "/help/$slug",
	getParentRoute: () => Route$87
});
var ManualIndexRoute = Route$17.update({
	id: "/manual/",
	path: "/manual/",
	getParentRoute: () => Route$87
});
var ManualSlugRoute = Route$107.update({
	id: "/manual/$slug",
	path: "/manual/$slug",
	getParentRoute: () => Route$87
});
var PayTokenRoute = Route$108.update({
	id: "/pay/$token",
	path: "/pay/$token",
	getParentRoute: () => Route$87
});
var UpgradeDoneRoute = Route$122.update({
	id: "/upgrade_/done",
	path: "/upgrade/done",
	getParentRoute: () => Route$87
});
var AuthenticatedAccountsIdRoute = Route$89.update({
	id: "/accounts_/$id",
	path: "/accounts/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedBillsIdRoute = Route$92.update({
	id: "/bills_/$id",
	path: "/bills/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedChecksIdRoute = Route$97.update({
	id: "/checks_/$id",
	path: "/checks/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCustomersIdRoute = Route$98.update({
	id: "/customers_/$id",
	path: "/customers/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedPoIdRoute = Route$110.update({
	id: "/po/$id",
	path: "/po/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedProductsIdRoute = Route$112.update({
	id: "/products_/$id",
	path: "/products/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedSalesIdRoute = Route$123.update({
	id: "/sales/$id",
	path: "/sales/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedStockDocIdRoute = Route$124.update({
	id: "/stock-doc/$id",
	path: "/stock-doc/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedTicketsIdRoute = Route$125.update({
	id: "/tickets_/$id",
	path: "/tickets/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedVendorsIdRoute = Route$126.update({
	id: "/vendors_/$id",
	path: "/vendors/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedWebsiteTicketsIdRoute = Route$127.update({
	id: "/website-tickets_/$id",
	path: "/website-tickets/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AdminCustomersIdRoute = Route$99.update({
	id: "/customers_/$id",
	path: "/customers/$id",
	getParentRoute: () => AdminRouteRoute
});
var ApiPublicConnectApiRoute = Route$16.update({
	id: "/api/public/connect-api",
	path: "/api/public/connect-api",
	getParentRoute: () => Route$87
});
var ApiPublicDownloadRoute = Route$15.update({
	id: "/api/public/download",
	path: "/api/public/download",
	getParentRoute: () => Route$87
});
var ApiPublicHelpFileRoute = Route$14.update({
	id: "/api/public/help-file",
	path: "/api/public/help-file",
	getParentRoute: () => Route$87
});
var ApiPublicInstallPingRoute = Route$13.update({
	id: "/api/public/install-ping",
	path: "/api/public/install-ping",
	getParentRoute: () => Route$87
});
var ApiPublicLicenseCheckRoute = Route$12.update({
	id: "/api/public/license-check",
	path: "/api/public/license-check",
	getParentRoute: () => Route$87
});
var ApiPublicPayApiRoute = Route$11.update({
	id: "/api/public/pay-api",
	path: "/api/public/pay-api",
	getParentRoute: () => Route$87
});
var ApiPublicPricesRoute = Route$10.update({
	id: "/api/public/prices",
	path: "/api/public/prices",
	getParentRoute: () => Route$87
});
var ApiPublicReportRoute = Route$9.update({
	id: "/api/public/report",
	path: "/api/public/report",
	getParentRoute: () => Route$87
});
var ApiPublicStayCalendarRoute = Route$8.update({
	id: "/api/public/stay-calendar",
	path: "/api/public/stay-calendar",
	getParentRoute: () => Route$87
});
var ApiPublicStripeOauthRoute = Route$7.update({
	id: "/api/public/stripe-oauth",
	path: "/api/public/stripe-oauth",
	getParentRoute: () => Route$87
});
var ApiPublicStripeWebhookRoute = Route$6.update({
	id: "/api/public/stripe-webhook",
	path: "/api/public/stripe-webhook",
	getParentRoute: () => Route$87
});
var ApiPublicUnsubscribeRoute = Route$5.update({
	id: "/api/public/unsubscribe",
	path: "/api/public/unsubscribe",
	getParentRoute: () => Route$87
});
var HelpTKeyRoute = Route$104.update({
	id: "/help/t/$key",
	path: "/help/t/$key",
	getParentRoute: () => Route$87
});
var AuthenticatedGoKindIdRoute = Route$102.update({
	id: "/go/$kind/$id",
	path: "/go/$kind/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var ApiPublicCronDailyRentRoute = Route$4.update({
	id: "/api/public/cron/daily-rent",
	path: "/api/public/cron/daily-rent",
	getParentRoute: () => Route$87
});
var ApiPublicCronNightlyBackupRoute = Route$3.update({
	id: "/api/public/cron/nightly-backup",
	path: "/api/public/cron/nightly-backup",
	getParentRoute: () => Route$87
});
var ApiPublicCronQuoteFollowupsRoute = Route$2.update({
	id: "/api/public/cron/quote-followups",
	path: "/api/public/cron/quote-followups",
	getParentRoute: () => Route$87
});
var ApiPublicCronTrialEmailsRoute = Route$1.update({
	id: "/api/public/cron/trial-emails",
	path: "/api/public/cron/trial-emails",
	getParentRoute: () => Route$87
});
var ApiPublicOfficeBackupLatestRoute = Route.update({
	id: "/api/public/office/backup-latest",
	path: "/api/public/office/backup-latest",
	getParentRoute: () => Route$87
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAccountsRoute,
	AuthenticatedAdjustRoute,
	AuthenticatedAiRoute,
	AuthenticatedBankTransfersRoute,
	AuthenticatedBankingRoute,
	AuthenticatedBillsRoute,
	AuthenticatedBudgetRoute,
	AuthenticatedCalendarRoute,
	AuthenticatedCardRegisterRoute,
	AuthenticatedCategoriesRoute,
	AuthenticatedChecksRoute,
	AuthenticatedChecksReceivedRoute,
	AuthenticatedCountRoute,
	AuthenticatedCreditCardsRoute,
	AuthenticatedCryptoTaxRoute,
	AuthenticatedCustomersRoute,
	AuthenticatedDepositsRoute,
	AuthenticatedDocumentsRoute,
	AuthenticatedFastEntryRoute,
	AuthenticatedFinancialsRoute,
	AuthenticatedForms1099Route,
	AuthenticatedHouseholdRoute,
	AuthenticatedInvestmentsRoute,
	AuthenticatedInvoicesRoute,
	AuthenticatedJournalRoute,
	AuthenticatedLabelsRoute,
	AuthenticatedLeasesRoute,
	AuthenticatedLoansRoute,
	AuthenticatedLocationsRoute,
	AuthenticatedMonthlyReviewRoute,
	AuthenticatedMovementsRoute,
	AuthenticatedNetWorthRoute,
	AuthenticatedNewInvoiceRoute,
	AuthenticatedNewQuoteRoute,
	AuthenticatedOverviewRoute,
	AuthenticatedPayBillsRoute,
	AuthenticatedPayrollRoute,
	AuthenticatedPlanRoute,
	AuthenticatedPrintChecksRoute,
	AuthenticatedProductsRoute,
	AuthenticatedPropertiesRoute,
	AuthenticatedPurchaseOrdersRoute,
	AuthenticatedQuotesRoute,
	AuthenticatedReceiptsRoute,
	AuthenticatedRecurringRoute,
	AuthenticatedRefundsRoute,
	AuthenticatedRegisterRoute,
	AuthenticatedRentRoute,
	AuthenticatedRentRollRoute,
	AuthenticatedReportsRoute,
	AuthenticatedRmaRoute,
	AuthenticatedSalesListRoute,
	AuthenticatedSalesOrdersRoute,
	AuthenticatedSalesReceiptRoute,
	AuthenticatedSalesTaxRoute,
	AuthenticatedSettingsRoute,
	AuthenticatedSetupCompanyRoute,
	AuthenticatedShelveRoute,
	AuthenticatedShoeboxRoute,
	AuthenticatedStatementsRoute,
	AuthenticatedStaysRoute,
	AuthenticatedStockRoute,
	AuthenticatedSubscriptionsRoute,
	AuthenticatedTechPayRoute,
	AuthenticatedTicketsRoute,
	AuthenticatedTransferRoute,
	AuthenticatedVendorsRoute,
	AuthenticatedWebsiteTicketsRoute,
	AuthenticatedWorkOrdersRoute,
	AuthenticatedYearEndRoute,
	AuthenticatedIndexRoute,
	AuthenticatedAccountsIdRoute,
	AuthenticatedBillsIdRoute,
	AuthenticatedChecksIdRoute,
	AuthenticatedCustomersIdRoute,
	AuthenticatedPoIdRoute,
	AuthenticatedProductsIdRoute,
	AuthenticatedSalesIdRoute,
	AuthenticatedStockDocIdRoute,
	AuthenticatedTicketsIdRoute,
	AuthenticatedVendorsIdRoute,
	AuthenticatedWebsiteTicketsIdRoute,
	AuthenticatedGoKindIdRoute
};
var AuthenticatedRouteRouteWithChildren = AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren);
var AdminRouteRouteChildren = {
	AdminCustomersRoute,
	AdminDownloadsRoute,
	AdminLicensesRoute,
	AdminPricesRoute,
	AdminTestersRoute,
	AdminWaitlistRoute,
	AdminIndexRoute,
	AdminCustomersIdRoute
};
var rootRouteChildren = {
	AuthenticatedRouteRoute: AuthenticatedRouteRouteWithChildren,
	AdminRouteRoute: AdminRouteRoute._addFileChildren(AdminRouteRouteChildren),
	AuthRoute,
	BuyRoute,
	DownloadRoute,
	EarlyAccessRoute,
	ResetPasswordRoute,
	SignupRoute,
	TestersRoute,
	UpgradeRoute,
	WelcomeRoute,
	BuyDoneRoute,
	HelpSlugRoute,
	ManualSlugRoute,
	PayTokenRoute,
	UpgradeDoneRoute,
	HelpIndexRoute,
	ManualIndexRoute,
	ApiPublicConnectApiRoute,
	ApiPublicDownloadRoute,
	ApiPublicHelpFileRoute,
	ApiPublicInstallPingRoute,
	ApiPublicLicenseCheckRoute,
	ApiPublicPayApiRoute,
	ApiPublicPricesRoute,
	ApiPublicReportRoute,
	ApiPublicStayCalendarRoute,
	ApiPublicStripeOauthRoute,
	ApiPublicStripeWebhookRoute,
	ApiPublicUnsubscribeRoute,
	HelpTKeyRoute,
	ApiPublicCronDailyRentRoute,
	ApiPublicCronNightlyBackupRoute,
	ApiPublicCronQuoteFollowupsRoute,
	ApiPublicCronTrialEmailsRoute,
	ApiPublicOfficeBackupLatestRoute
};
var routeTree = Route$87._addFileChildren(rootRouteChildren)._addFileTypes();
/**
* When a new version of the app is published while a tab is open, the old page
* asks for script files that no longer exist ("Failed to fetch dynamically
* imported module"). The router turns that into a route error and the screen
* goes blank. Recognize it and reload once — the fresh page loads the new
* files and everything works again. The 30s window stops reload loops.
*/
var CHUNK_ERROR = /failed to fetch dynamically imported module|importing a module script failed|error loading dynamically imported module|dynamically imported module/i;
var RELOAD_KEY = "sunrise-stale-chunk-reload";
function isStaleChunkError(error) {
	const msg = error instanceof Error ? error.message : String(error ?? "");
	return CHUNK_ERROR.test(msg);
}
function ReloadableErrorPage({ error }) {
	const stale = isStaleChunkError(error);
	(0, import_react.useEffect)(() => {
		if (!stale) return;
		const last = Number(sessionStorage.getItem(RELOAD_KEY) ?? 0);
		if (Date.now() - last > 3e4) {
			sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
			window.location.reload();
		}
	}, [stale]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-background p-6 text-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-sm text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mb-2 text-xl font-bold",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-5 text-sm text-muted-foreground",
					children: stale ? "A new version of the app just arrived. One more try should fix it." : "Something went wrong while opening this page."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground",
						onClick: () => window.location.reload(),
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-md border border-border bg-background px-4 py-2 text-sm font-semibold",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0,
		defaultErrorComponent: ({ error }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReloadableErrorPage, { error })
	});
};
//#endregion
export { getRouter };
