import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DhlwgD8n.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as AI_PROVIDERS } from "./ai-DoFpV1D-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai.functions-D6lXeTYL.js
/**
* Whose AI settings a company uses: its own, or, when it has none, the AI set up in another
* company on the same account (one key serves all your companies; any company can still pick
* its own).
*/
/** What this company's AI looks like right now (never the key itself). */
var aiStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("eb2ee64070a95f5ca231302b02ebc4033bc4338affec0d905e7b745c92a76c32"));
/** The backup AI and its key (none before database step 52). */
/** Choose the AI for this company. Admins or staff with the Accounting section. */
var aiSave = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!(d.provider in AI_PROVIDERS)) throw new Error("Unknown AI.");
	if (d.cap != null && !(d.cap >= 0)) throw new Error("The monthly limit must be 0 or more.");
	if (d.key && d.key.length > 400) throw new Error("That key is too long.");
	if (d.backupKey && d.backupKey.length > 400) throw new Error("That key is too long.");
	if (d.backupProvider && (!(d.backupProvider in AI_PROVIDERS) || d.backupProvider === "vooska")) throw new Error("Pick your own AI account as the backup.");
	return d;
}).handler(createSsrRpc("cf6f48d63d7d776519762389066263927129c6ba829b48eeab381d2ca77616fa"));
var PROMPTS = {
	categorize: `You are a careful bookkeeper. For each bank or credit card line, pick the best account
from the chart of accounts given (use the exact account name from the list). Return JSON only:
{"picks":[{"id":"the line id","account":"exact account name"|null,"why":"a few plain words"}]}
Rules: money out for a business cost goes to an expense or cost account that fits; money in from
customers goes to an income account. Personal spending (groceries, pharmacy, restaurants for
the family, clothing, personal subscriptions) in a business's books goes to the owner's draws or
withdrawals account when there is one. Paying a credit card from the bank goes to that credit
card account; moving money between the company's own accounts goes to the other account. If a
note says what someone uses the card for, follow it. When unsure, use null rather than guess.`,
	sort: `You sort business and household paperwork. Look at the first page(s) and say what it is,
and read the key facts. Return JSON only:
{"kind":"bank_statement"|"card_statement"|"loan_statement"|"investment_statement"|"receipt"|"bill"|"check"|"other",
 "issuer":"bank, card company, store or vendor name"|null,
 "account_last4":"last 4 digits of the bank or card account on a statement"|null,
 "period_end":"YYYY-MM-DD"|null,
 "vendor":"…"|null,"date":"YYYY-MM-DD"|null,"due_date":"YYYY-MM-DD"|null,"total":number|null,
 "tax":number|null,"bill_number":"…"|null,"category":"short guess like Supplies, Utilities, Rent"|null,
 "payer":"…"|null,"amount":number|null,"check_number":"…"|null,"memo":"…"|null,
 "loan_kind":"mortgage"|"car"|"student"|"personal"|"heloc"|"other"|null,
 "payment":number|null,"principal":number|null,"interest":number|null,"escrow":number|null,
 "fees":number|null,"balance":number|null,"rate":number|null,
 "invest_kind":"retirement"|"brokerage"|"other"|null,"account_type":"Roth IRA, 401k, Brokerage…"|null,
 "ending_value":number|null,"total_invested":number|null,
 "holdings":[{"name":"fund or stock name","symbol":"ticker"|null,"shares":number|null,"price":number|null,"value":number|null}],
 "description":"one short line saying what it is"}
kind: bank_statement = a bank account statement with many transactions; card_statement = a credit
card statement; receipt = proof of something already paid (store or online receipt, paid
invoice); bill = an invoice or bill that still has to be paid (shows an amount due or a due date);
check = a paper check someone wrote to this business; loan_statement = a monthly mortgage, car
loan, student loan, personal loan or home equity statement from a lender; other = anything else.
For a loan_statement: issuer = the lender (servicer) name as printed; account_last4 = last 4 of
the loan number; period_end = the statement date; due_date = when the payment is due;
payment = the regular monthly payment (not past-due amounts); principal, interest, escrow (taxes
and insurance) and fees = how this payment splits; balance = the unpaid principal balance;
rate = the interest rate in percent (4.625 for 4.625%).
investment_statement = a brokerage, mutual fund, IRA, Roth IRA, 401k or other investment or
retirement account statement. For it: issuer = the company (Primerica, Fidelity…);
account_last4 = last 4 of the account number; period_end = the statement's end date;
ending_value = the account's total value on that date; holdings = each fund or stock with its
shares, price and value on that date (an empty list when the pages shown don't list them).
total_invested = the money put in since the account opened (purchases or contributions, plus
rollovers and transfers in) minus withdrawals, when the statement shows it; otherwise null.
total = the amount paid (receipt) or the amount due (bill). Never return full account, card or
routing numbers: only the last 4 digits.`,
	product: `You look at a photo of a product or part (often a box, label or the item itself) for a
business's inventory. Return JSON only:
{"name":"a short, clear inventory name, like a store would use (brand, what it is, size or
 model), e.g. 'Mean Well LRS-150-12 12V 150W power supply'","brand":"…"|null,"model":"…"|null,
 "description":"one short line"|null,"barcode":"the UPC/EAN digits printed under a barcode"|null}
Use only what you can read or clearly see. Never invent a model number.`,
	investment: `You read investment and retirement account statements (Fidelity, Schwab, Vanguard,
Primerica, 401k, IRA, Roth IRA, brokerage). Return JSON only:
{"kind":"investment_statement","issuer":"the company (Fidelity…)","account_last4":"1234"|null,
 "invest_kind":"retirement"|"brokerage"|"other","account_type":"Roth IRA, 401k, Brokerage…"|null,
 "period_start":"YYYY-MM-DD"|null,"period_end":"YYYY-MM-DD","beginning_value":number|null,
 "ending_value":number|null,"total_invested":number|null,
 "period":{"deposits":n,"withdrawals":n,"fees":n,"dividends":n,"interest":n,
   "realized_short":n,"realized_long":n,"change_in_value":n},
 "ytd":{ the same names, for the year to date },
 "holdings":[{"name":"…","symbol":"ticker"|null,"shares":number|null,"price":number|null,
   "value":number|null,"cost":number|null}]}
(n = a number, or null when the statement doesn't show it)
Rules: ending_value = the account's total value at the end of the period. Holdings come from the
detailed Holdings section (the table with Quantity, Price Per Unit, Ending Market Value and Total
Cost Basis), one entry per position, including the core / cash / money market position. Never use
a "Top Holdings" or summary list, and never add subtotals or totals ("Total Common Stock…").
shares = Quantity, price = Price Per Unit, value = Ending Market Value, cost = Total Cost Basis
(for cash and money market funds, cost = value; null when the statement says unavailable or not
applicable for anything else). symbol = the ticker in parentheses, like (MRVL). Use the
statement's numbers exactly; don't round. total_invested = money put in since the account opened
(contributions, purchases, deposits, rollovers in, minus withdrawals) only when the statement shows
it since the account opened; a year-to-date figure is not it (then null). account_last4 = the last
4 digits or characters of the account number.
period and ytd come from the summary pages ("This Period" and "Year-to-Date" columns):
deposits = Additions / Deposits / Contributions; withdrawals = money taken out (not fees), as a
positive number; fees = Transaction Costs, Fees & Charges, as a positive number; dividends and
interest = from the Income Summary; realized_short and realized_long = Net Short-term and Net
Long-term Gain/Loss from the Realized Gains and Losses section (a loss is negative);
change_in_value = Change in Investment Value (or Investment gain/decline).`,
	statement: `You read bank and credit card statements. Return JSON only:
{"account_kind":"bank"|"credit_card","period_end":"YYYY-MM-DD"|null,"ending_balance":number|null,
 "lines":[{"date":"YYYY-MM-DD","description":"…","amount":number,"ref":"check number or null"}]}
Rules: one entry per transaction line, in statement order. Money INTO the account is positive,
money OUT is negative (for a credit card: purchases and fees negative, payments and refunds
positive). Skip balances, subtotals, headers and summaries. Use the statement's year for dates.
Copy descriptions as printed (no card numbers).`,
	receipt: `You read store receipts and vendor invoices. Return JSON only:
{"vendor":"…"|null,"date":"YYYY-MM-DD"|null,"total":number|null,"tax":number|null,
 "payment":"card"|"cash"|"check"|"other"|null,"card_last4":"1234"|null,
 "category":"short guess like Supplies, Fuel, Meals, Repairs"|null,"items":"one short line"|null}
total = the amount actually paid, including tax and tip.`,
	check: `You read a paper check that a business RECEIVED from its customer. Return JSON only:
{"payer":"…"|null,"amount":number|null,"date":"YYYY-MM-DD"|null,"check_number":"…"|null,
 "memo":"…"|null,"bank":"…"|null}
payer = the person or company that wrote the check (printed top left), not the bank and not who it
is paid to. amount = the number in the amount box. check_number = the number at the top right.
memo = the memo line, often an invoice number. Never return account or routing numbers.`
};
/** Pages the built-in AI may read in a month during the free trial (online). */
/** Stop when the account's built-in AI pages for this month are used up. */
/** Read statement pages or a receipt with AI. Logs the use; stops at the monthly limit. */
var aiRead = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!PROMPTS[d.feature]) throw new Error("Unknown job.");
	if (d.feature === "categorize") {
		if (d.images.length || !d.hint || d.hint.length > 6e4) throw new Error("Nothing to sort.");
		return d;
	}
	if (!d.images.length) throw new Error("Nothing to read.");
	if (d.images.length > 12) throw new Error("Too many pages at once (12 at most).");
	if (d.hint && d.hint.length > 2e3) throw new Error("The note for the AI is too long.");
	if (d.images.reduce((t, i) => t + i.length, 0) > 18e6) throw new Error("These pages are too big. Try fewer pages at a time.");
	if (!d.images.every((i) => /^data:image\/(jpeg|png|webp);base64,/.test(i))) throw new Error("Pages must be images.");
	return d;
}).handler(createSsrRpc("add849362d949ebbc4eb83205c60058bb0fff83a0b7d10809a072293a387221a"));
//#endregion
export { aiSave as n, aiStatus as r, aiRead as t };
