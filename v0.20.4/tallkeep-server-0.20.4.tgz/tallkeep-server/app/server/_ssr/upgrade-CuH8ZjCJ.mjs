import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade-CuH8ZjCJ.js
var $$splitComponentImporter = () => import("./upgrade-D73Q_bop.mjs");
/** Renew updates or add companies/people to a Tallkeep Desktop license. No sign-in. */
var Route = createFileRoute("/upgrade")({
	ssr: false,
	validateSearch: (s) => ({
		...typeof s["license"] === "string" ? { license: s["license"] } : {},
		...typeof s["email"] === "string" ? { email: s["email"] } : {}
	}),
	head: () => ({ meta: [{ title: "Renew or upgrade Tallkeep" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
