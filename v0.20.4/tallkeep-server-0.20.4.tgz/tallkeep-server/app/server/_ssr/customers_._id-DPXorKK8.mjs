import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { accountDetail, deleteClosedAccount, listAccounts } from "./admin.functions-DOyLKZBJ.mjs";
import { r as standing, t as ChangeDialog } from "./AdminAccount-CAD10CA4.mjs";
import { t as Route } from "./customers_._id-Cxbj0u1b.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers_._id-DPXorKK8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FEATURE = {
	statement: "Bank statements",
	receipt: "Receipts"
};
function CustomerPage() {
	const { id } = Route.useParams();
	const accounts = useQuery({
		queryKey: ["admin-accounts"],
		queryFn: () => listAccounts()
	});
	const detail = useQuery({
		queryKey: ["admin-account", id],
		queryFn: () => accountDetail({ data: { id } })
	});
	const [changing, setChanging] = (0, import_react.useState)(false);
	const a = accounts.data?.find((x) => x.id === id);
	if (accounts.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-64" }) });
	if (!a) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Customer not found" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/admin/customers",
		className: "text-primary underline",
		children: "Back to customers"
	})] });
	const s = standing(a);
	const of = (n, max) => max == null ? `${n}` : `${n} of ${max}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/admin/customers",
			className: "text-sm text-primary hover:underline",
			children: "← All customers"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: a.name,
			text: `${a.owner_email} · signed up ${fmtDate(a.created_at)}`,
			actions: !a.is_platform && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setChanging(true),
				children: "Change plan"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-5",
			children: [
				["Standing", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full px-2 py-0.5 text-sm ${s.tone}`,
					children: s.text
				})],
				["Version", a.edition === "desktop" ? "Desktop" : "Cloud"],
				["Companies", of(a.companies, a.companies_allowed)],
				["People", of(a.people, a.users_allowed)],
				["AI this month", `${fmtMoney(a.ai_cost_month)} · ${a.ai_pages_month} pages`]
			].map(([label, value], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 font-semibold",
					children: value
				})]
			}, i))
		}),
		a.status === "canceled" && a.closed_at && Date.now() - Date.parse(a.closed_at) > 7776e6 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteBooks, { a }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "border-b p-4 font-display text-lg font-semibold",
					children: "Companies"
				}), detail.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "m-4 h-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: (detail.data?.companies ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between border-b p-4 text-sm last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: c.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: ["added ", fmtDate(c.created_at)]
					})]
				}, c.id)) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "border-b p-4 font-display text-lg font-semibold",
					children: "People"
				}), detail.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "m-4 h-6" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: (detail.data?.people ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3 border-b p-4 text-sm last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate font-medium",
							children: p.name || p.email
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "truncate text-xs text-muted-foreground",
							children: [
								p.email,
								" · ",
								p.role === "admin" ? "Admin" : "Staff"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 text-muted-foreground",
						children: p.last_sign_in ? `last in ${fmtDate(p.last_sign_in)}` : "never signed in"
					})]
				}, p.id)) })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "border-b p-4 font-display text-lg font-semibold",
				children: "AI use this month"
			}), (detail.data?.ai ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-4 text-sm text-muted-foreground",
				children: "No AI use this month."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: (detail.data?.ai ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex justify-between border-b p-4 text-sm last:border-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: FEATURE[r.feature] ?? r.feature }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					r.pages,
					" pages · ",
					fmtMoney(r.cost)
				] })]
			}, r.feature)) })]
		}),
		changing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeDialog, {
			account: a,
			onClose: () => setChanging(false)
		})
	] });
}
/** The plan ended more than 90 days ago: the owner may delete the account and its books. */
function DeleteBooks({ a }) {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function go() {
		setBusy(true);
		try {
			const r = await deleteClosedAccount({ data: {
				id: a.id,
				name
			} });
			toast.success(`Deleted: ${r.companies} companies, ${r.people} people.`);
			qc.invalidateQueries({ queryKey: ["admin-accounts"] });
			navigate({ to: "/admin/customers" });
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-2xl border border-red-300 bg-red-50 p-4 text-sm text-red-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "Delete this account and all its books"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"The plan ended more than ",
				90,
				" days ago. This deletes its companies, books, files and sign-ins for good. It can't be undone."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-xs bg-white",
					placeholder: `Type ${a.name} to confirm`,
					value: name,
					onChange: (e) => setName(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					disabled: busy || name.trim() !== a.name.trim(),
					onClick: go,
					children: "Delete for good"
				})]
			})
		]
	});
}
//#endregion
export { CustomerPage as component };
