import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { i as deleteItem, t as BUCKET } from "./shoebox-B-JKp9s9.mjs";
import { Bt as Eye, D as Search, Mt as FolderOpen, Ut as Download, g as Trash2, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as getStorage, t as fmtBytes } from "./storage.functions-DN162cJd.mjs";
import { r as makeZip, t as downloadBlob } from "./csv-D0ewwTlm.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/documents-CTGutSV8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Documents: every file Tallkeep keeps (Shoebox drops and receipts) in one list, newest first.
* Find one, see it, see what it became, download a whole year as a zip (for the CPA), delete.
* The bar on top shows the space used (online plans have a limit).
*/
var KIND = {
	statement: "Bank or card statement",
	receipt: "Receipt",
	bill: "Bill",
	check: "Check",
	loan: "Loan statement",
	investment: "Investment statement",
	unknown: "Not sure yet"
};
var T = (t) => db.from(t);
var PAGE = 100;
/** Where a file went, as a link. */
function Became({ d }) {
	const c = "text-primary underline";
	switch (d.target_type) {
		case "receipt": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/receipts",
			className: c,
			children: "Receipts"
		});
		case "bill": return d.target_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/bills/$id",
			params: { id: d.target_id },
			search: {},
			className: c,
			children: "The bill"
		}) : null;
		case "bank_import": return d.account_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/banking",
			search: { account: d.account_id },
			className: c,
			children: "Bank Feeds"
		}) : null;
		case "deposit": return d.account_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/register",
			search: { account: d.account_id },
			className: c,
			children: "Check register"
		}) : null;
		case "investment": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/investments",
			className: c,
			children: "Investments"
		});
		case "loan": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/loans",
			className: c,
			children: "Mortgage & Loans"
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: "Not filed yet"
		});
	}
}
function DocumentsPage() {
	const qc = useQueryClient();
	const [typed, setTyped] = (0, import_react.useState)("");
	const [q, setQ] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)("");
	const [limit, setLimit] = (0, import_react.useState)(PAGE);
	const [zipping, setZipping] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setQ(typed), 300);
		return () => clearTimeout(t);
	}, [typed]);
	(0, import_react.useEffect)(() => setLimit(PAGE), [
		q,
		kind,
		year
	]);
	const storage = useQuery({
		queryKey: ["storage"],
		queryFn: () => getStorage()
	});
	const years = useQuery({
		queryKey: ["documents-years"],
		queryFn: async () => {
			const { data } = await T("documents").select("created_at").order("created_at", { ascending: true }).limit(1);
			const first = data?.[0]?.created_at ? new Date(data[0].created_at).getFullYear() : null;
			const now = (/* @__PURE__ */ new Date()).getFullYear();
			return first ? Array.from({ length: now - first + 1 }, (_, i) => now - i) : [now];
		}
	});
	const docs = useQuery({
		queryKey: [
			"documents",
			q,
			kind,
			year,
			limit
		],
		placeholderData: (prev) => prev,
		queryFn: async () => {
			let x = T("documents").select("*", { count: "exact" }).order("created_at", { ascending: false }).limit(limit);
			if (kind) x = x.eq("kind", kind);
			if (year) x = x.gte("created_at", `${year}-01-01`).lt("created_at", `${Number(year) + 1}-01-01`);
			const w = q.replace(/[,()*%"\\]/g, " ").trim();
			if (w) {
				const n = /^\$?[\d.]+$/.test(w.replace(/,/g, "")) ? Number(w.replace(/[$,]/g, "")) : NaN;
				const alts = [w];
				if (Number.isFinite(n) && n >= 1e3) alts.push(n.toLocaleString("en-US", { maximumFractionDigits: 2 }));
				x = x.or(alts.flatMap((v) => [`file_name.ilike."*${v}*"`, `summary.ilike."*${v}*"`]).join(","));
			}
			const { data, error, count } = await x;
			if (error) throw new Error(error.message);
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	const see = async (d, download = false) => {
		const { data, error } = await db.storage.from(BUCKET).createSignedUrl(d.file_path, 300, download ? { download: d.file_name } : void 0);
		if (error || !data) return void toast.error(error?.message ?? "Couldn't open the file.");
		window.open(data.signedUrl, "_blank");
	};
	async function remove(d) {
		if (!window.confirm(`Delete ${d.file_name} for good? What it already put in the books stays (change or delete that where it went).`)) return;
		try {
			if (d.source === "shoebox") await deleteItem(d);
			else {
				await db.storage.from(BUCKET).remove([d.file_path]);
				const r = await T("receipts").delete().eq("id", d.id);
				if (r.error) throw r.error;
			}
			toast.success("Deleted.");
			qc.invalidateQueries({ queryKey: ["documents"] });
			qc.invalidateQueries({ queryKey: ["storage"] });
			qc.invalidateQueries({ queryKey: ["shoebox"] });
		} catch (e) {
			toast.error(e.message);
		}
	}
	/** Every file of a year in one .zip, in folders by kind (for the CPA). */
	async function zipYear(y) {
		setZipping("Finding the files…");
		try {
			const all = [];
			for (let from = 0;; from += 1e3) {
				const { data, error } = await T("documents").select("*").gte("created_at", `${y}-01-01`).lt("created_at", `${Number(y) + 1}-01-01`).order("created_at").range(from, from + 999);
				if (error) throw new Error(error.message);
				all.push(...data ?? []);
				if (!data || data.length < 1e3) break;
			}
			if (!all.length) return void toast.message(`No files from ${y}.`);
			const files = [];
			const used = /* @__PURE__ */ new Set();
			for (const [i, d] of all.entries()) {
				setZipping(`Adding ${i + 1} of ${all.length}…`);
				const { data } = await db.storage.from(BUCKET).download(d.file_path);
				if (!data) continue;
				let name = `${y} ${(KIND[d.kind] ?? "Other").replace(/[^\w ]+/g, "")}/${d.created_at.slice(0, 10)} ${d.file_name}`.replace(/[\\:*?"<>|]+/g, "_");
				for (let n = 2; used.has(name); n++) name = name.replace(/(\.\w+)?$/, ` (${n})$1`);
				used.add(name);
				files.push({
					name,
					bytes: new Uint8Array(await data.arrayBuffer())
				});
			}
			downloadBlob(`Tallkeep documents ${y}.zip`, makeZip(files));
			toast.success(`${files.length} files from ${y} downloaded.`);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setZipping("");
		}
	}
	const s = storage.data;
	const pct = s?.limit ? Math.min(100, s.used / s.limit * 100) : 0;
	const rows = docs.data?.rows ?? [];
	const count = docs.data?.count ?? 0;
	const zipYearPick = year || String((/* @__PURE__ */ new Date()).getFullYear());
	const yearList = (0, import_react.useMemo)(() => years.data ?? [], [years.data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Documents",
			text: "Every statement, receipt, bill and check you've put in Tallkeep, in one place. Find one, see what it became, or download a whole year for your CPA.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				disabled: !!zipping,
				onClick: () => void zipYear(zipYearPick),
				children: [zipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), zipping || `Download ${zipYearPick} as a zip`]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl border bg-card p-4",
			children: !s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8" }) : s.limit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-between gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Storage"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						fmtBytes(s.used),
						" of ",
						fmtBytes(s.limit),
						" used"
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 h-2 overflow-hidden rounded-full bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("h-full rounded-full", pct > 90 ? "bg-destructive" : pct > 75 ? "bg-amber-500" : "bg-[#0E7C74]"),
						style: { width: `${Math.max(pct, s.used ? 1 : 0)}%` }
					})
				}),
				pct > 90 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-destructive",
					children: "Almost full. Delete files you don't need, or pick a bigger plan in Plan & billing."
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Storage:"
					}),
					" ",
					fmtBytes(s.used),
					" used",
					s.desktop ? ", on your office computer (no limit). It's in the nightly backups." : "."
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-w-[220px] flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-8",
						placeholder: "Find a file: Fidelity, a name, an amount like 6974…",
						value: typed,
						onChange: (e) => setTyped(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Year",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: year,
					onChange: (e) => setYear(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Every year"
					}), yearList.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: y,
						children: y
					}, y))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "What it is",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: kind,
					onChange: (e) => setKind(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Every kind"
					}), Object.entries(KIND).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: v
					}, k))]
				})
			]
		}),
		docs.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) : !rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-8 text-center text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "mx-auto h-8 w-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: q || kind || year ? "Nothing found." : "No files yet. Drop some in the Shoebox."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-2xl border bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-semibold",
							children: "Date"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-semibold",
							children: "File"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-semibold",
							children: "What it is"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-semibold",
							children: "Went to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-right font-semibold",
							children: "Size"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-32" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y",
					children: rows.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "align-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap px-3 py-2",
								children: fmtDate(d.created_at.slice(0, 10))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "max-w-[340px] px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: d.file_name
								}), d.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "line-clamp-2 text-xs text-muted-foreground",
									children: d.summary
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap px-3 py-2",
								children: KIND[d.kind] ?? d.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Became, { d })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap px-3 py-2 text-right tabular-nums",
								children: d.size != null ? fmtBytes(Number(d.size)) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "whitespace-nowrap px-2 py-1 text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										title: "See it",
										onClick: () => void see(d),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										title: "Download",
										onClick: () => void see(d, true),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "icon",
										variant: "ghost",
										title: "Delete the file",
										className: "text-destructive",
										onClick: () => void remove(d),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									})
								]
							})
						]
					}, `${d.source}-${d.id}`))
				})]
			})
		}),
		rows.length < count && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => setLimit((n) => n + PAGE),
				children: [
					"Show more (",
					count - rows.length,
					" more)"
				]
			})
		})
	] });
}
//#endregion
export { DocumentsPage as component };
