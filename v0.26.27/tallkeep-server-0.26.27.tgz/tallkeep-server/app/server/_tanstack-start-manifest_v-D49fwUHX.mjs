//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D49fwUHX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BkGP2Tn2.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-5r1lSt2Z.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BHUOQKAG.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BkGP2Tn2.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-RpmlVJZz.js",
			"/assets/log-out-D8AQi81N.js",
			"/assets/testers.functions-KJJr0LJn.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CzFWKVQD.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BmkhMGm-.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CL65Wxsr.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-CIk4-7Fz.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/dist-BpV3MQJj.js",
			"/assets/dialog-9GmpPn2d.js",
			"/assets/queries-Dgkw9Zkz.js",
			"/assets/input-Dhtijynd.js",
			"/assets/label-C8mgYS_J.js",
			"/assets/textarea-CGMAzPAd.js",
			"/assets/shoebox-Be1iQv_i.js",
			"/assets/company-RUYfl6Ha.js",
			"/assets/reports-DARrqw_p.js",
			"/assets/access-C4BoRxs6.js",
			"/assets/LicenseCard-Du1dGRUg.js",
			"/assets/Logo-BJzr2nO_.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-C5efpulq.js",
			"/assets/log-out-D8AQi81N.js",
			"/assets/admin.functions-Blfb5Zpj.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-BJzr2nO_.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-PCtdt7sg.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/label-C8mgYS_J.js",
			"/assets/Logo-BJzr2nO_.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-F0KmCYR7.js",
			"/assets/testers.functions-KJJr0LJn.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/coupons.functions-Cet98wwB.js",
			"/assets/buy.functions-aWMhbf9J.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DO8X2k41.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/downloads.functions-BBoxTPBx.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-z-FJpkZ5.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/label-C8mgYS_J.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-Pv_L76jL.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/label-C8mgYS_J.js",
			"/assets/Logo-BJzr2nO_.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BsZo6Jyq.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/upgrade.functions-C7MtFYym.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CgZJ36Fh.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/label-C8mgYS_J.js",
			"/assets/Logo-BJzr2nO_.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-K2lEerhI.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BSPK7JPi.js", "/assets/StockDocList-ykOfYTWU.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CoKvcufX.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/ai-Byyg9H1Y.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-CEXJxBLd.js",
			"/assets/BankConnections-eQkxtCy1.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BtfTi9YQ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CiogGnAI.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-eQkxtCy1.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/ai-Byyg9H1Y.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DLoxJo6G.js",
			"/assets/TxnEditor-6XlHLhii.js",
			"/assets/feedWaiting-VVnH6iFh.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-PzsORzcm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DNtpQuXn.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/personal-D60nvJrW.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/WhoPicker-BH8y33bX.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BJ5HkfZn.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DyDw74hf.js", "/assets/AccountRegister-Coy-BIut.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BV3WzTKt.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DiCO9FjW.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/money-Bp_7BEDW.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CV_6EUFS.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Byyg9H1Y.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DnB2mSg-.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BcsHtCnw.js", "/assets/StockDocList-ykOfYTWU.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Dc6henmc.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-FSABi2Da.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BXBDgrej.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-HHGvglNK.js", "/assets/PartyList-DiXNwozV.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-o5nOdWtg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-JKK6Vgsh.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/storage.functions-DSB48lqk.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Ctv5dUdK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CkxJyLqB.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-B7GS5vv1.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DJ2Iai9h.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-C-h-KqOM.js", "/assets/ChangeHistory-BLJ8ogvh.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-B5DfLJ8S.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/members-XUhgVKgO.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BhFypFtZ.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/personal-D60nvJrW.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/WhoPicker-BH8y33bX.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-Dancy8eH.js", "/assets/SalesList--HnKouJM.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-myVCIs-G.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CUIXy6hF.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CUYFRu0z.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-Dq_fbCr-.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/loans-DLoxJo6G.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CcKw_cOy.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-rc7wOuiC.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-C9DsYjkV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/personal-D60nvJrW.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/WhoPicker-BH8y33bX.js",
			"/assets/reminders-D-t_g4oV.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-_2P6Niqd.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DDmgLhy7.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/personal-D60nvJrW.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/WhoPicker-BH8y33bX.js",
			"/assets/generateCategoricalChart-Chh1nvCD.js",
			"/assets/Area-DJQNOq88.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-N_jxjveU.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/generateCategoricalChart-Chh1nvCD.js",
			"/assets/PlCharts-B7GS5vv1.js",
			"/assets/BarChart-Dm_glUUf.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CVdZWyD7.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DYf6WGaL.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-B8GBiF_K.js",
			"/assets/createServerFn-B3lySGFN.js",
			"/assets/auth-middleware-DjvhXdoV.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/storage.functions-DSB48lqk.js",
			"/assets/coupons.functions-Cet98wwB.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-B8FLjLD5.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BOgBFCF3.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/checkbox-mSvFlwdm.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-HSLcOc8T.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BtCOn-QQ.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-C6PxNqdX.js", "/assets/SalesList--HnKouJM.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-D96X3lWy.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/ai-Byyg9H1Y.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DSB48lqk.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-xpzvwKW6.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/money-Bp_7BEDW.js",
			"/assets/badge-BrWAjiwv.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DeV84qfr.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CLpayppA.js", "/assets/AccountRegister-Coy-BIut.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DEgklF-m.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/MoneyAccountPick-Blo7jYvQ.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-jiHdlt_P.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BcEnDrFx.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/RepeatInvoice-eddwdPj2.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CzkYxpKU.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-Chh1nvCD.js",
			"/assets/BarChart-Dm_glUUf.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CCvQkMFB.js", "/assets/SalesList--HnKouJM.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-Db8m__8n.js", "/assets/SalesList--HnKouJM.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BQ50qbS-.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-C_aP8qeK.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/serials-BFeOAwCi.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-B6VBWrHw.js",
			"/assets/createServerFn-B3lySGFN.js",
			"/assets/auth-middleware-DjvhXdoV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/emailWording-OHxAUYFx.js",
			"/assets/scan-barcode-i-o7I6qZ.js",
			"/assets/send-BwSadvej.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-WtGSDVTM.js",
			"/assets/switch-rc7wOuiC.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/bankfeed.functions-BlNL_Age.js",
			"/assets/QuickBooksImport-BXBDgrej.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BAMpqnBU.js",
			"/assets/footers-DrhuXKE8.js",
			"/assets/PrintFrame-BluVTMCW.js",
			"/assets/checkbox-mSvFlwdm.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-BO__zv9E.js",
			"/assets/FeaturePicker-ByKZMN_o.js",
			"/assets/support-DuXPSXx2.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CtjauC2w.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/FeaturePicker-ByKZMN_o.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BCr-JB5o.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DJLy4tMF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/photos-BAMpqnBU.js",
			"/assets/stockmove-D0-HjNhp.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-Bi6LEYTp.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/loans-DLoxJo6G.js",
			"/assets/feedWaiting-VVnH6iFh.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DSB48lqk.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Dn_33cmW.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/PrintFrame-BluVTMCW.js",
			"/assets/DocPdf-yX_35gvL.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-0_Te8GMW.js",
			"/assets/createServerFn-B3lySGFN.js",
			"/assets/auth-middleware-DjvhXdoV.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/MoneyAccountPick-Blo7jYvQ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DuXPSXx2.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-eWeo_Mky.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/StockDialogs-DJLy4tMF.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/stockmove-D0-HjNhp.js",
			"/assets/checkbox-mSvFlwdm.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Bf4gHbq7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/members-XUhgVKgO.js",
			"/assets/WhoPicker-BH8y33bX.js",
			"/assets/reminders-D-t_g4oV.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BAdrIcFK.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/tickets.functions-DYthJx2q.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-XB8VY6E_.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DuXPSXx2.js",
			"/assets/support.functions-NBpE0aAM.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DbeMQBFp.js", "/assets/StockDocList-ykOfYTWU.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DdUtRPyh.js", "/assets/PartyList-DiXNwozV.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BtZldIqF.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/tickets.functions-DYthJx2q.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-C2vscDVF.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/workorders-BEN__cdz.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-Cnclvtpy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-CzazBcJW.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/coupons.functions-Cet98wwB.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-B6f-LgxP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/AdminAccount-CH7zwSGQ.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BVE93Nyb.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/downloads.functions-BBoxTPBx.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-i80JYpSA.js",
			"/assets/createServerFn-B3lySGFN.js",
			"/assets/auth-middleware-DjvhXdoV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-37hqUJaB.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Dqa7fn1t.js",
			"/assets/testers.functions-KJJr0LJn.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-Dl5Fv0Bp.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-Bcb_8IhE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-aWMhbf9J.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-xsDIQyWg.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/textarea-CGMAzPAd.js",
			"/assets/support.functions-NBpE0aAM.js",
			"/assets/HelpParts-DMCsWPfI.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-DeIgqgrl.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DqIYJK9D.js",
			"/assets/manual._slug-w3i3IFzQ.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BG7hdzL_.js",
			"/assets/createServerFn-B3lySGFN.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done--D90eno0.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-C7MtFYym.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-tjSqQobK.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Byyg9H1Y.js",
			"/assets/personal-D60nvJrW.js",
			"/assets/reminders-D-t_g4oV.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B0ZGvTmP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/AdminAccount-CH7zwSGQ.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BC3eUVoM.js", "/assets/ManualFrame-DqIYJK9D.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-vphyXBMq.js", "/assets/AccountRegister-Coy-BIut.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BadkcJcP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/OriginalLink-rYFM2wje.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/realestate-txZgVoWn.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-abpD665T.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DPTgb6v3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/realestate-txZgVoWn.js",
			"/assets/money-Bp_7BEDW.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BNO2XCzT.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/SideList-D13I_yop.js",
			"/assets/PartyHistory-CszYjMMJ.js",
			"/assets/tabs-C0HD9Otg.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CyU3xD5m.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-OHxAUYFx.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLJ8ogvh.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/SideList-D13I_yop.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-DUzE3NTC.js",
			"/assets/MoneyAccountPick-Blo7jYvQ.js",
			"/assets/footers-DrhuXKE8.js",
			"/assets/PrintFrame-BluVTMCW.js",
			"/assets/serials-BFeOAwCi.js",
			"/assets/SerialsBox-BWHIdcDu.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CBJI-pKV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DJLy4tMF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLJ8ogvh.js",
			"/assets/switch-rc7wOuiC.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BrWAjiwv.js",
			"/assets/SideList-D13I_yop.js",
			"/assets/tabs-C0HD9Otg.js",
			"/assets/photos-BAMpqnBU.js",
			"/assets/stockmove-D0-HjNhp.js",
			"/assets/serials-BFeOAwCi.js",
			"/assets/SerialsBox-BWHIdcDu.js",
			"/assets/workorders-BEN__cdz.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DUF_-LSA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-OHxAUYFx.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLJ8ogvh.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/SideList-D13I_yop.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-DUzE3NTC.js",
			"/assets/MoneyAccountPick-Blo7jYvQ.js",
			"/assets/footers-DrhuXKE8.js",
			"/assets/PrintFrame-BluVTMCW.js",
			"/assets/checkbox-mSvFlwdm.js",
			"/assets/serials-BFeOAwCi.js",
			"/assets/workorders-BEN__cdz.js",
			"/assets/RepeatInvoice-eddwdPj2.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DYthJx2q.js",
			"/assets/users.functions-BO__zv9E.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-Dkls4XgU.js",
			"/assets/select-C3j4Oqmc.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/SideList-D13I_yop.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BM_Iz5M4.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/quickadd-CM3nxHrE.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DuXPSXx2.js",
			"/assets/support.functions-NBpE0aAM.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-twtKS3SO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CJPD5QQp.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/SideList-D13I_yop.js",
			"/assets/PartyHistory-CszYjMMJ.js",
			"/assets/tabs-C0HD9Otg.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-B6Cda5wQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/sales-DnB2mSg-.js",
			"/assets/footers-DrhuXKE8.js",
			"/assets/tickets.functions-DYthJx2q.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DziMk7wC.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/input-Dhtijynd.js",
			"/assets/skeleton-2qyCj0Nh.js",
			"/assets/AdminAccount-CH7zwSGQ.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-wycXN9VP.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CK3cvG3C.js",
			"/assets/textarea-CGMAzPAd.js",
			"/assets/support-DuXPSXx2.js",
			"/assets/support.functions-NBpE0aAM.js",
			"/assets/HelpParts-DMCsWPfI.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CNqyxlPp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-2qyCj0Nh.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
