//#region ../../node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-6GsvPBoE.js
var manifest = {
	"00611f6528b281a5c3872f2e4bc5790e9e151ff9e66a0d314caa44bf6b1514d9": {
		functionName: "askToTest_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"019a423964e1dad1bd104e3a9a51f9a9b938bc4dbfc1395567fb46023a4c414a": {
		functionName: "recordDownload_createServerFn_handler",
		importer: () => import("./_ssr/downloads.functions-DERybm2w.mjs")
	},
	"059a3c99824bb5684bd30d408e4be244c5916b85e8f697267342e19e20e6a210": {
		functionName: "getUpgradeOrder_createServerFn_handler",
		importer: () => import("./_ssr/upgrade.functions-BFZ9PtPA.mjs")
	},
	"12384f99b5b064dc9d8791957ad225d3e81cc320063f1a7f3a36680e2d998e01": {
		functionName: "checkTesterCode_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"1451e52a03e1d052f3d1a13763407804acbc263dab8122da9b78e14acc3f6c68": {
		functionName: "startPayCheckout_createServerFn_handler",
		importer: () => import("./_ssr/pay.functions-DBgDZXAy.mjs")
	},
	"1acd810adfe8cc90c5543dff8b075033311630f73f88b295ecf5aa9bfb29a954": {
		functionName: "getStorage_createServerFn_handler",
		importer: () => import("./_ssr/storage.functions-BuLqHBkc.mjs")
	},
	"1c07c766055e3d99b4ce098f5bad7d8d0756bbe632b9e9d2384ee4f72ef8ecfc": {
		functionName: "runFollowupsNow_createServerFn_handler",
		importer: () => import("./_ssr/followups.functions-ClCKxEdm.mjs")
	},
	"222764ceb133430e5ba744ea2a49ff737733dc9183d46b15301b1c7e2ef2bb4a": {
		functionName: "getBuyInfo_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	},
	"2b55125109e43275df9d428a1a815dc1fc4a26ae3c1c4a252977a8c23afab6c6": {
		functionName: "reportProblem_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"2c5a14efae666c66f9050e983d7ee7530c86790708cd112a473bd68c78ed1c0e": {
		functionName: "restoreFromBackup_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"3337e16a1ca5d14776fbffb6ab88d8c08897b5c663e19c0a5445cc769c12e08f": {
		functionName: "staffReply_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"3428c6d6ad7cd8fa7491ab7411d6d8472cd18aba914aa7ac7fd3b8eec2fb01e4": {
		functionName: "setCompanyAccess_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"34f565de0ecb973594612848b517ea391eeac0fb71632eadf4ed88a61b35e07a": {
		functionName: "savePrices_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"40f995acabc3d24a380ab7d182bbf46b853bb07eb89be8ccb844a7b7012a806d": {
		functionName: "openTicket_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"42c096807572ac95bb24b4bd4c91a75b9435bd09acd83552f994694d9c8870d5": {
		functionName: "quoteUpgrade_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	},
	"43ed8732e31f6b7059578c4384ff3dc669315e2dcbc0ceef914318206731cc1b": {
		functionName: "setLicenseOn_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"46cc758b5b42e5b4c6456feb57bf9342a9a5cd96381845478fe01d1e281ecc64": {
		functionName: "startUpgrade_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	},
	"487a6c1ba9a7b71ab5ed23fb488dba33912c2df9640f2ac290d7ad153199a3a7": {
		functionName: "releaseComputer_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"52ae71e6cfacb229eefce10e007b4d0a433e4dce525a87615321e3d6b52ab56c": {
		functionName: "amIOwner_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"57ddaa5e4421dbf7df4d9f414643f1bb27a4c291bf5708d6c31cd31cadffedf0": {
		functionName: "addUser_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"5a54f5d01d810c6d5e874565da0aeb5aadeade5c8114b4385004d9622e252c91": {
		functionName: "accountDetail_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"5e3f2155d8f79d4f9c40c121fe96e1948d07bb54af205475ce054a65585c1bfd": {
		functionName: "makeLicenseKey_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"63062885b1d5ebe758cd8e6e4fcc209bf4492aacb2eaf6de2d83d140038ea485": {
		functionName: "markTicket_createServerFn_handler",
		importer: () => import("./_ssr/tickets.functions-O-DRWBZe.mjs")
	},
	"64019a9e45f7e8b0375e3d14f1984dc6e6493f506a342471c10221dced5b5d46": {
		functionName: "listRepNames_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"65167bf74740ab17c0fbab7a39a651e64108b27c734b7bc92f51ab7af27647c0": {
		functionName: "getPayPage_createServerFn_handler",
		importer: () => import("./_ssr/pay.functions-DBgDZXAy.mjs")
	},
	"68245375509608cf53f821532abc75914db1edaec535ba1975049ebadeb65f05": {
		functionName: "backupNow_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"6bff944da1ec056947accb2562117e32d4a984b372336f1ff590ca9320773259": {
		functionName: "lookUpLicense_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	},
	"724d38f1c752f08b3df6330bde3f49cb5f5e4cc51e2a7909d81ced3a8bd86e60": {
		functionName: "startUpgrade_createServerFn_handler",
		importer: () => import("./_ssr/upgrade.functions-BFZ9PtPA.mjs")
	},
	"7eaf5dbf89412f42ebd190a5a5b2b70b9bb5443150881549323022ab87ce003c": {
		functionName: "listTechFees_createServerFn_handler",
		importer: () => import("./_ssr/tickets.functions-O-DRWBZe.mjs")
	},
	"7f27d5ec54cebdfb5629c9cd0bc5f278a3edf0eda72aaee7f43bdad2dd29802e": {
		functionName: "confirmPlan_createServerFn_handler",
		importer: () => import("./_ssr/online.functions-BBvat-st.mjs")
	},
	"83d5228d9d2f21cc7666fad6650ccbd34fb718c930a17044834da3eee01e2c62": {
		functionName: "billingPage_createServerFn_handler",
		importer: () => import("./_ssr/online.functions-BBvat-st.mjs")
	},
	"85f1fef7a0411d309d5893fece878801f90949dbde3de658a2916053fd00a251": {
		functionName: "listLicenseKeys_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"889f4f23e0f328174ed54f2f0fbd7ecb2330a920d633a86ed599a3a931c44695": {
		functionName: "setProblem_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"8c56746723b59acb7fff2062af8cf1b67256fe267c1b064d2d55aadbe60477ad": {
		functionName: "listAccounts_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"8e3e903a2c7b9dc8b4ebb470802f7497971688c5226db897ef3dcc22517c0996": {
		functionName: "getTicket_createServerFn_handler",
		importer: () => import("./_ssr/tickets.functions-O-DRWBZe.mjs")
	},
	"933c1ca8d375ab289a5dfd5976fb3f49a00e899e5cf12e5fab59401ca0776648": {
		functionName: "startPlan_createServerFn_handler",
		importer: () => import("./_ssr/online.functions-BBvat-st.mjs")
	},
	"9361df1a94e7b3318a7f52ef7419757434e15b7dead8b1cb6636b5adf3d5a46d": {
		functionName: "removeUser_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"9423a679c9df2f139cb12313a6efb5e9668960218a0e540c16ac757a25d12b4a": {
		functionName: "changeAccount_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"983bd78fdde0496a70eac804f7e75ce9364b7de2107c5e0370f4fa96bfe9fad1": {
		functionName: "fetchCalendar_createServerFn_handler",
		importer: () => import("./_ssr/stays.functions-BQCiGsL7.mjs")
	},
	"9c23602d2497e87db527c2f51f96da388bc05788ddb83ab0c420cfc762bcd869": {
		functionName: "getOrder_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	},
	"9d0066a13f2c073e0ecdd9f1dd3f644b1b5340b2bbe255f787f7eaf97c1d5ddd": {
		functionName: "listTickets_createServerFn_handler",
		importer: () => import("./_ssr/tickets.functions-O-DRWBZe.mjs")
	},
	"a0fe38d0ee0bb219de28cfe57f964c6a21fe31a49f0ec1912afe2e12dbe0c9df": {
		functionName: "listProblems_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"a2d9697780227560abcb1156f5bdea1ac030d03848cf0ea525e850d95e904a84": {
		functionName: "listWaitlist_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"a3cdd7c9324ad5eab526048b501809bed2b6d4ed00f1862b877dbd2ec9fe2fba": {
		functionName: "emailLicenseKey_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"a7f32f276406e2d7206bbca2e8c5fc871d65fb4425fcac828b84b5aae9eb123f": {
		functionName: "sendDocEmail_createServerFn_handler",
		importer: () => import("./_ssr/email.functions-Ewn5cQL4.mjs")
	},
	"aab17122cc1986c06006ca74c6e3931f6572464fb86f3077a1ed4f46448288f6": {
		functionName: "uploadBackup_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"add849362d949ebbc4eb83205c60058bb0fff83a0b7d10809a072293a387221a": {
		functionName: "aiRead_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-XVyDNpVc.mjs")
	},
	"b168eb565a3c4c37801f615d46b1b01ff96ab06ee481f6e9aa59fd2226349aca": {
		functionName: "getMyPlan_createServerFn_handler",
		importer: () => import("./_ssr/online.functions-BBvat-st.mjs")
	},
	"b3d9b550fd57f1619d6614223abb41699073a11378cef344750801aba49c44e7": {
		functionName: "getUpgradeInfo_createServerFn_handler",
		importer: () => import("./_ssr/upgrade.functions-BFZ9PtPA.mjs")
	},
	"b8ba26946ba21d048bed7a9b47519e0bd6e1457294f097774b028d2543b4a032": {
		functionName: "reviewTester_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"bf7e244e8d039b3b242642889b54fe2c274ff956811728d8b7818fd4aa2b3bd6": {
		functionName: "changeUser_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"c0a9351fdf5fec73b82f254d09bc44ec7e4d5613560f4b5995f36d4118bc6a9c": {
		functionName: "listSupportStaff_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"c3cb615a6833d9c11d076131e61d553f76bf27f094f99d46dcd824156aa301fa": {
		functionName: "addExistingKey_createServerFn_handler",
		importer: () => import("./_ssr/license.functions-D95ZS7Sb.mjs")
	},
	"ca683ec40b811885e1486d71d87808c320b5bf90f0646637e04e8cfcb4f839b5": {
		functionName: "getPrices_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"cf6f48d63d7d776519762389066263927129c6ba829b48eeab381d2ca77616fa": {
		functionName: "aiSave_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-XVyDNpVc.mjs")
	},
	"d1de4cd6c5fed7ab6d4819651136ceb161a48b3ea783c0171bce0c384b4914f4": {
		functionName: "listBackups_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"d96fc76850779782acfe0d57c8df91435fcd2dbdbbe157b34f6d9842c0ffc4b6": {
		functionName: "listUsers_createServerFn_handler",
		importer: () => import("./_ssr/users.functions-CkjDmXpA.mjs")
	},
	"d977603f5bbf94db864ead1e021883062b18ace6c6570fb34ac0f34bc925208b": {
		functionName: "summarizeBackup_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"dbbb396530bca0dd8e8e455c118509c777c88ea9fb7ca04effe9f4459aa5d083": {
		functionName: "backupLink_createServerFn_handler",
		importer: () => import("./_ssr/backup.functions-B_VVsv8e.mjs")
	},
	"e48180cae480f45ad9db96730afc03d85cbfe3d41e37c5b8d5887cd9d838dd38": {
		functionName: "listDownloads_createServerFn_handler",
		importer: () => import("./_ssr/downloads.functions-DERybm2w.mjs")
	},
	"e494d86b25d6cb1e5b47bb29942a09b5106938cc3713eabb435e0244de7fe085": {
		functionName: "listTesters_createServerFn_handler",
		importer: () => import("./_ssr/testers.functions-D67l52NW.mjs")
	},
	"e6ad388e4f4d689ee36066da5516f97d165c190e2072efb91cd8bedf5f8a581f": {
		functionName: "changePlan_createServerFn_handler",
		importer: () => import("./_ssr/online.functions-BBvat-st.mjs")
	},
	"eb2ee64070a95f5ca231302b02ebc4033bc4338affec0d905e7b745c92a76c32": {
		functionName: "aiStatus_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-XVyDNpVc.mjs")
	},
	"edd227bdb9a1f3153ddfc027e2f64c788faedc6d7a2198167ff802f227dbcb5f": {
		functionName: "getTicketByKey_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"f2eef172c5bd4f6efbae6f978078f0eb44647d7c3ff761fe3a131e2ba11d28a4": {
		functionName: "deleteClosedAccount_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"f3dd04a2849ca3168bd7a7a323490b6df9b1b99564396df67070a7832cdacde3": {
		functionName: "supportEmailReady_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"f4a3843ba5b275a7d0f9497fd6e3748d8da5db0d4783dfa53e26efdbece5ca69": {
		functionName: "replyByKey_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"f8465b5a6844a72aa64a56949439349602aaa2860cac1d67442dfe948e025036": {
		functionName: "getSupportPage_createServerFn_handler",
		importer: () => import("./_ssr/support.functions-B5fMFuRQ.mjs")
	},
	"f8a1ed20652c12e2e24874cef1b7a091f0b7173c31ae6a7c2a8b444dc9c4ad4e": {
		functionName: "getStripeMode_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-iW8Ju9Vf.mjs")
	},
	"f9954db22f4c3a8f70b27c51d850a744ed1538ae448929e6afd51e15b23278e7": {
		functionName: "startCheckout_createServerFn_handler",
		importer: () => import("./_ssr/buy.functions-BnHdTgpW.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
