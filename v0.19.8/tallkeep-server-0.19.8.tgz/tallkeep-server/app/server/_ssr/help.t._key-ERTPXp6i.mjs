import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/help.t._key-ERTPXp6i.js
var $$splitComponentImporter = () => import("./help.t._key-D0KQDxOy.mjs");
/** A customer's ticket: the conversation, quotes and invoices, and a reply box. No sign-in. */
var Route = createFileRoute("/help/t/$key")({
	ssr: false,
	head: () => ({ meta: [{ title: "Your support ticket" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
