//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ce1BS6V6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BkHcBpzc.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DZr8tJfS.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BsSTYjV4.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BkHcBpzc.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-B_6t8lez.js",
			"/assets/log-out-UZGVGffv.js",
			"/assets/testers.functions-B6cyv-96.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DL6K1eG6.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CXrDDr2r.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-8zVO79Re.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/dist-DLMQJ5yU.js",
			"/assets/dialog-BxOuZ2CX.js",
			"/assets/queries-DstHERN8.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/label-CGo8LoN6.js",
			"/assets/textarea-BKdmOV11.js",
			"/assets/shoebox-mwYgNfKd.js",
			"/assets/company-HHEaEmvq.js",
			"/assets/reports-BOFPaiuK.js",
			"/assets/access-BF_mfDAN.js",
			"/assets/LicenseCard-BdITCH_W.js",
			"/assets/Logo-C0IcagFh.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-ByQS730-.js",
			"/assets/log-out-UZGVGffv.js",
			"/assets/admin.functions-DNkK07tw.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-C0IcagFh.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BhGwC6wn.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/label-CGo8LoN6.js",
			"/assets/Logo-C0IcagFh.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-qZo2i1iv.js",
			"/assets/testers.functions-B6cyv-96.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/buy.functions-BE296Fcg.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-uIxi8ZIv.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/downloads.functions-DpcJD31O.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-HSYTx0Jh.js",
			"/assets/testers.functions-B6cyv-96.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/textarea-BKdmOV11.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DPz3zORC.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/label-CGo8LoN6.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DkvhPZMP.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/label-CGo8LoN6.js",
			"/assets/Logo-C0IcagFh.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-B_7jmYOL.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/upgrade.functions-DGN03b7T.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-6wANDNyU.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/label-CGo8LoN6.js",
			"/assets/Logo-C0IcagFh.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-Cq_I81f3.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-CIB517mR.js", "/assets/StockDocList-BOZ_R-Y9.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DDhKEMhG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/ai-BYu3ZuPU.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BukPHvgh.js",
			"/assets/BankConnections-Pi1aYDlq.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BGQTmWyV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BV332P4_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-Pi1aYDlq.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/ai-BYu3ZuPU.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DVOrmP1z.js",
			"/assets/TxnEditor-DrvBw7Rd.js",
			"/assets/feedWaiting-B5dg7sLR.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DCXQyYHy.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CWyUO48l.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/personal-Yo7QvezD.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/WhoPicker-B4biSK_s.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CNNh8kRF.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DoSfHQLm.js", "/assets/AccountRegister-tCLAsoee.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BMplX4I5.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-HSJBf-oJ.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/money-Mpp_yXTy.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CZ4OiBWT.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BYu3ZuPU.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-B7hIWGrS.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BjfP9aOF.js", "/assets/StockDocList-BOZ_R-Y9.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-C76JB03o.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BLHI5ZVU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-izKce5O7.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CCTZ09yc.js", "/assets/PartyList-Dq_EYMR1.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-qfHZPRl8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DGJGizAl.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/storage.functions-ClTKqlSZ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BR0j8F5Y.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BwWXZl5y.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-Cx6yQnMG.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Bz6m17Hj.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BQt-iCJF.js", "/assets/ChangeHistory-DXhzqk9G.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-B1f-k5Be.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/members-NwdRJEDr.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BrtrlrzW.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/personal-Yo7QvezD.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/WhoPicker-B4biSK_s.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CIxI-e3Z.js", "/assets/SalesList-DpLqlN2C.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-Col1ax49.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-ZytOl-Vk.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BJ_6uDu5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-F0m2W_kO.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/loans-DVOrmP1z.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CfEIT6Ic.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-D_4WpYfA.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Dm47OqGH.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/personal-Yo7QvezD.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/WhoPicker-B4biSK_s.js",
			"/assets/reminders-Y_Kd8p7a.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-UUiadQCu.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-EBCAA5Mb.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/personal-Yo7QvezD.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/WhoPicker-B4biSK_s.js",
			"/assets/generateCategoricalChart-j58vMQYj.js",
			"/assets/Area-j16i-NYu.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-k1RKZocU.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/generateCategoricalChart-j58vMQYj.js",
			"/assets/PlCharts-Cx6yQnMG.js",
			"/assets/BarChart-DcDzSPEb.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BtdeQ8jn.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DHLNnKHv.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-Ein_evZq.js",
			"/assets/createServerFn-3bAvYucf.js",
			"/assets/auth-middleware-Du-OSj1i.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/storage.functions-ClTKqlSZ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BGZ1K2iC.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BC4492vz.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/checkbox-CkwZhxFw.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-4BaEeFP0.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BXn80QQw.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DiZn2XHC.js", "/assets/SalesList-DpLqlN2C.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DCgvDmFO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/ai-BYu3ZuPU.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-ClTKqlSZ.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-D_MKv_k3.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/money-Mpp_yXTy.js",
			"/assets/badge-zLgKSKE6.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-D5NCk6HE.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-tYM265Qd.js", "/assets/AccountRegister-tCLAsoee.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BYWVoeNQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/MoneyAccountPick-DcEI1_47.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-D3bshaQr.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-B3MKyMBs.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/RepeatInvoice-rtLV30ni.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-NEGaUpVT.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-j58vMQYj.js",
			"/assets/BarChart-DcDzSPEb.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-cLB_3rDQ.js", "/assets/SalesList-DpLqlN2C.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CX0YQZjz.js", "/assets/SalesList-DpLqlN2C.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BXm4Ml23.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BKFBjXhi.js",
			"/assets/createServerFn-3bAvYucf.js",
			"/assets/auth-middleware-Du-OSj1i.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-ClnDt3yV.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DChkUGen.js",
			"/assets/switch-D_4WpYfA.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-izKce5O7.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-D9iKFIN2.js",
			"/assets/footers-DqNBTYBk.js",
			"/assets/PrintFrame-BGlBIij1.js",
			"/assets/checkbox-CkwZhxFw.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DM3PKv3i.js",
			"/assets/FeaturePicker-CmD3GsCA.js",
			"/assets/support-Bd4W1hCT.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BCmfQsqX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/FeaturePicker-CmD3GsCA.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BUqF_wGk.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DbhWT3V5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/photos-D9iKFIN2.js",
			"/assets/stockmove-CTeiAFmI.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DYYqp8WJ.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/loans-DVOrmP1z.js",
			"/assets/feedWaiting-B5dg7sLR.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-ClTKqlSZ.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CxR7c4iK.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/PrintFrame-BGlBIij1.js",
			"/assets/DocPdf-Bgj-W704.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-RkaiUB_Y.js",
			"/assets/createServerFn-3bAvYucf.js",
			"/assets/auth-middleware-Du-OSj1i.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/MoneyAccountPick-DcEI1_47.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Bd4W1hCT.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C4tZ-0Nq.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/StockDialogs-DbhWT3V5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/stockmove-CTeiAFmI.js",
			"/assets/checkbox-CkwZhxFw.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-7Am2HqDk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/members-NwdRJEDr.js",
			"/assets/WhoPicker-B4biSK_s.js",
			"/assets/reminders-Y_Kd8p7a.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-B5fYfRIt.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/tickets.functions-DrA3j-Nl.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-MhuomErQ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Bd4W1hCT.js",
			"/assets/support.functions-CHKnlL4O.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-f9d-9T6M.js", "/assets/StockDocList-BOZ_R-Y9.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-Cva2l0wf.js", "/assets/PartyList-Dq_EYMR1.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-uM0eKd4m.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/tickets.functions-DrA3j-Nl.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-Bn4gfpyH.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/workorders-BxAseIea.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-3keFOi_D.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DDw9sBSH.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/AdminAccount-BcjtGljD.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BSacn2TI.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/downloads.functions-DpcJD31O.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-uW-3D3y-.js",
			"/assets/createServerFn-3bAvYucf.js",
			"/assets/auth-middleware-Du-OSj1i.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CM2Y5XQ0.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DMzdEuar.js",
			"/assets/testers.functions-B6cyv-96.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-lydVAOKt.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BOF9EYFW.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BE296Fcg.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BVIWFixh.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/textarea-BKdmOV11.js",
			"/assets/support.functions-CHKnlL4O.js",
			"/assets/HelpParts-Dr-pQSK5.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-7KZ2fm7n.js",
			"/assets/ManualFrame-CSTwI4Cx.js",
			"/assets/manual._slug-BqirsJM7.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DqRU1mWS.js",
			"/assets/createServerFn-3bAvYucf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-gr6lYSf3.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DGN03b7T.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-heinWenJ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BYu3ZuPU.js",
			"/assets/personal-Yo7QvezD.js",
			"/assets/reminders-Y_Kd8p7a.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Gyj9sGfm.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/AdminAccount-BcjtGljD.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-0JHj90VR.js", "/assets/ManualFrame-CSTwI4Cx.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-ODHXu7T1.js", "/assets/AccountRegister-tCLAsoee.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CNiYjhwl.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/OriginalLink-Bdp5V7oI.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/realestate-u1XxApKx.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C4YZFiPK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CKg-R9VG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/realestate-u1XxApKx.js",
			"/assets/money-Mpp_yXTy.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-ClH2w06X.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/SideList-s3WxrVxh.js",
			"/assets/PartyHistory-B8G6YZTU.js",
			"/assets/tabs-CnIS96Al.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-9tlMIqgk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-ClnDt3yV.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DXhzqk9G.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/SideList-s3WxrVxh.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-DeuM-Tsi.js",
			"/assets/MoneyAccountPick-DcEI1_47.js",
			"/assets/footers-DqNBTYBk.js",
			"/assets/PrintFrame-BGlBIij1.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CNggZgW9.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DbhWT3V5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DXhzqk9G.js",
			"/assets/switch-D_4WpYfA.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/badge-zLgKSKE6.js",
			"/assets/SideList-s3WxrVxh.js",
			"/assets/tabs-CnIS96Al.js",
			"/assets/photos-D9iKFIN2.js",
			"/assets/stockmove-CTeiAFmI.js",
			"/assets/workorders-BxAseIea.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BcXoAAVT.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-ClnDt3yV.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DXhzqk9G.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/SideList-s3WxrVxh.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-DeuM-Tsi.js",
			"/assets/MoneyAccountPick-DcEI1_47.js",
			"/assets/footers-DqNBTYBk.js",
			"/assets/PrintFrame-BGlBIij1.js",
			"/assets/checkbox-CkwZhxFw.js",
			"/assets/workorders-BxAseIea.js",
			"/assets/RepeatInvoice-rtLV30ni.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DrA3j-Nl.js",
			"/assets/users.functions-DM3PKv3i.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D_SMJ5zC.js",
			"/assets/select-BSuqbmmV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/SideList-s3WxrVxh.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-D4xMJobl.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/quickadd-Bt_MklQZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Bd4W1hCT.js",
			"/assets/support.functions-CHKnlL4O.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DhJZ2TCg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DttXdRDF.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/SideList-s3WxrVxh.js",
			"/assets/PartyHistory-B8G6YZTU.js",
			"/assets/tabs-CnIS96Al.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CGCgNICf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/sales-B7hIWGrS.js",
			"/assets/footers-DqNBTYBk.js",
			"/assets/tickets.functions-DrA3j-Nl.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DOsekePQ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/input-Bxw7Z06K.js",
			"/assets/skeleton-B0Bo84op.js",
			"/assets/AdminAccount-BcjtGljD.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CvbxY4MH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-B_zCC5u3.js",
			"/assets/textarea-BKdmOV11.js",
			"/assets/support-Bd4W1hCT.js",
			"/assets/support.functions-CHKnlL4O.js",
			"/assets/HelpParts-Dr-pQSK5.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-7Jq1scDW.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-B0Bo84op.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
