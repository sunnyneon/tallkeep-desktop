//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C7AWk9pK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-HuHbkfdy.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bw20J02D.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuWl1-_-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-HuHbkfdy.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-C48jv0Dt.js",
			"/assets/log-out-DpcPcH3J.js",
			"/assets/testers.functions--ujBHgju.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CviQ49OJ.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CStDlPO7.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-D8sg-IzW.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/dist-BIxDrg62.js",
			"/assets/dialog-BfCfe_Wh.js",
			"/assets/queries-CoTwIZGh.js",
			"/assets/input-Chq-REnW.js",
			"/assets/label-CzAn8Tw7.js",
			"/assets/textarea-CJytqjTK.js",
			"/assets/shoebox-CPgCQqFD.js",
			"/assets/company-BNWhyLPf.js",
			"/assets/reports-DU1m_pTa.js",
			"/assets/access-BkoQ7Z8P.js",
			"/assets/LicenseCard-C2jKa_qM.js",
			"/assets/Logo-CBmqB0nC.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-KtSHfAQs.js",
			"/assets/log-out-DpcPcH3J.js",
			"/assets/admin.functions-S8OHWKL5.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CBmqB0nC.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-fFonjZAP.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/label-CzAn8Tw7.js",
			"/assets/Logo-CBmqB0nC.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-QmAJbT5i.js",
			"/assets/testers.functions--ujBHgju.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/buy.functions-CBY3l9YB.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-Dmd8bw_i.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/downloads.functions-vNwYvTLI.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-DmEvzLqi.js",
			"/assets/testers.functions--ujBHgju.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/textarea-CJytqjTK.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Cj7_SS6f.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/label-CzAn8Tw7.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CKRMHir3.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/label-CzAn8Tw7.js",
			"/assets/Logo-CBmqB0nC.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-nJ0AN7E5.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/upgrade.functions-BW7PFuCZ.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-ChixgqxO.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/label-CzAn8Tw7.js",
			"/assets/Logo-CBmqB0nC.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-OjesaqO9.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-E7SHS5M_.js", "/assets/StockDocList-BJiBWvAi.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-B0eqxR5B.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/ai-Dn0PY9Ml.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-haqeawgG.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-D4zbh_6n.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/ai-Dn0PY9Ml.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/TxnEditor-BDuoTxtZ.js",
			"/assets/feedWaiting-DLL1S0nn.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BRFu0KD1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-omiXx0-L.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CVWticor.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-OI0RlKfS.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BkkKx623.js", "/assets/AccountRegister-BZLOq40w.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-C2C-WLR4.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-uKP_HWwP.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-JrUIK8-d.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Dn0PY9Ml.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-D0gD1-Vz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Bpo9Uv4k.js", "/assets/StockDocList-BJiBWvAi.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CY1da1_8.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-C2EJZbPv.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DzqKU49j.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-ViyhuXBl.js", "/assets/PartyList-D9_12j-p.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CqUzMX2N.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-lb2itiED.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/storage.functions-DhKadlkr.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CtkiEbP1.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CsixI1Q1.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-B3HUdHT8.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-B2XN1anX.js", "/assets/ChangeHistory-BylOupPQ.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-B4jevxfb.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/members-B1ktLCoR.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-7yihEASP.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CVWticor.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DmW7Nq96.js", "/assets/SalesList-B2CTeYny.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-DU6G9do_.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-D_51U9-y.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BNta9vRZ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-B4abTfmc.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/loans-DlX_C_YK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-bJ7nNlt_.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BtrOaBzN.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BiUqLG8B.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CVWticor.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Y8bnUc2p.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-E7Ce95MR.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CVWticor.js",
			"/assets/generateCategoricalChart-DWT8Fx6M.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CZEX25Qr.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-DWT8Fx6M.js",
			"/assets/BarChart-BUIL6OVn.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BdQo9SKs.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-I4Hpwqnn.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-Dn9o9-4g.js",
			"/assets/createServerFn-DprWOOsv.js",
			"/assets/auth-middleware-gSMh0XAx.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/storage.functions-DhKadlkr.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DG9wfvXu.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DvT1XFHQ.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/checkbox-BTqYCxRa.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-Df-wZC_O.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DKcViKV1.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CK4ZM5sO.js", "/assets/SalesList-B2CTeYny.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DDs90gdF.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/ai-Dn0PY9Ml.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DhKadlkr.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DLxLNcdX.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-CBwtCHzw.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Q_d6epwZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CTCdIVm3.js", "/assets/AccountRegister-BZLOq40w.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DM2Sr8S8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/MoneyAccountPick-CzEvprYr.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DTgHIi6M.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BHAm4LD6.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/RepeatInvoice-D6RN3bKG.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CBrLfi0K.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DWT8Fx6M.js",
			"/assets/BarChart-BUIL6OVn.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-D8M8CNam.js", "/assets/SalesList-B2CTeYny.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-BSrOnLHu.js", "/assets/SalesList-B2CTeYny.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-TnXgb9jU.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CWUUuh3C.js",
			"/assets/createServerFn-DprWOOsv.js",
			"/assets/auth-middleware-gSMh0XAx.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-Brx8u3gR.js",
			"/assets/switch-BtrOaBzN.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/QuickBooksImport-DzqKU49j.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-BTqYCxRa.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DOI3B34R.js",
			"/assets/FeaturePicker-DV16wt01.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-PQ96HvCT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/FeaturePicker-DV16wt01.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BlkmeVSp.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BAfc0S9j.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-Dwqk5FQ0.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/feedWaiting-DLL1S0nn.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DhKadlkr.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-P9F_3vAu.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/DocPdf-CLeVzmNm.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DeuS1rx2.js",
			"/assets/createServerFn-DprWOOsv.js",
			"/assets/auth-middleware-gSMh0XAx.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/MoneyAccountPick-CzEvprYr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DnM1-x9C.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/StockDialogs-BAfc0S9j.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/checkbox-BTqYCxRa.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DlptJs5J.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CVWticor.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-iEwaBLm6.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/tickets.functions-BQZMnPrc.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-58qgB-Ca.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DbAOMC3t.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DaJuJbh_.js", "/assets/StockDocList-BJiBWvAi.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DHnRDbhz.js", "/assets/PartyList-D9_12j-p.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-8kmH7Zuz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/tickets.functions-BQZMnPrc.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CWWZYTdu.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-Cj5P8bpl.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DlBvGwZL.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/AdminAccount-DQOZgxeR.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CO7E-Jzh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/downloads.functions-vNwYvTLI.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-vZeki5E0.js",
			"/assets/createServerFn-DprWOOsv.js",
			"/assets/auth-middleware-gSMh0XAx.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BF9VA9Q8.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DtYESVrG.js",
			"/assets/testers.functions--ujBHgju.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-D9wOeZEV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-B_kXl-kI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CBY3l9YB.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-c08ebuPp.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/textarea-CJytqjTK.js",
			"/assets/support.functions-DbAOMC3t.js",
			"/assets/HelpParts-gVRFPNIb.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-DHMV5vUR.js",
			"/assets/ManualFrame-CCwtrLKd.js",
			"/assets/manual._slug-wsE95niZ.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Dx-mgzqz.js",
			"/assets/createServerFn-DprWOOsv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Cwgr6COx.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-BW7PFuCZ.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BIBd-alR.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Dn0PY9Ml.js",
			"/assets/personal-DMq024VV.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DmH8A3bh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/AdminAccount-DQOZgxeR.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-pYLcctp9.js", "/assets/ManualFrame-CCwtrLKd.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-BHZ437w0.js", "/assets/AccountRegister-BZLOq40w.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Drt_LnwH.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/OriginalLink-0iKUD-sF.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-BqiXqXy6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DmW2783k.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-BW5mWXfW.js",
			"/assets/PartyHistory-rzP1kPLi.js",
			"/assets/tabs-8yOwpvKJ.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BnvsTEEN.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BylOupPQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-BW5mWXfW.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-QZnRQbcG.js",
			"/assets/MoneyAccountPick-CzEvprYr.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-ra0VSma_.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BAfc0S9j.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BylOupPQ.js",
			"/assets/switch-BtrOaBzN.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/badge-CBwtCHzw.js",
			"/assets/SideList-BW5mWXfW.js",
			"/assets/tabs-8yOwpvKJ.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BMvEVO6Z.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BylOupPQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-BW5mWXfW.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-QZnRQbcG.js",
			"/assets/MoneyAccountPick-CzEvprYr.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-BTqYCxRa.js",
			"/assets/workorders-CiTNPjMt.js",
			"/assets/RepeatInvoice-D6RN3bKG.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BQZMnPrc.js",
			"/assets/users.functions-DOI3B34R.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-5QRQ0HNP.js",
			"/assets/select-JDRUf4WI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-BW5mWXfW.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-1F_wE-K6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DbAOMC3t.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CPqiqawu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BfDSC3cn.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/SideList-BW5mWXfW.js",
			"/assets/PartyHistory-rzP1kPLi.js",
			"/assets/tabs-8yOwpvKJ.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BVZpzgCh.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/footers-C066M_rV.js",
			"/assets/tickets.functions-BQZMnPrc.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DyuKG_a4.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/input-Chq-REnW.js",
			"/assets/skeleton-CEFinrNd.js",
			"/assets/AdminAccount-DQOZgxeR.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CT3aJpVa.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-5eiYOfBl.js",
			"/assets/textarea-CJytqjTK.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DbAOMC3t.js",
			"/assets/HelpParts-gVRFPNIb.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-B7mB6I57.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CEFinrNd.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
