import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B1fqQSoo.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets.functions-CFEXk2Fy.js
/** A support ticket from sunriseled.com (Admin → Tickets). */
var listTickets = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("9d0066a13f2c073e0ecdd9f1dd3f644b1b5340b2bbe255f787f7eaf97c1d5ddd"));
var getTicket = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((d) => ({ id: Number(d.id) })).handler(createSsrRpc("8e3e903a2c7b9dc8b4ebb470802f7497971688c5226db897ef3dcc22517c0996"));
var markTicket = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("63062885b1d5ebe758cd8e6e4fcc209bf4492aacb2eaf6de2d83d140038ea485"));
/** "T-00037" -> 37 */
var ticketId = (number) => Number((number ?? "").replace(/\D/g, "")) || 0;
var listTechFees = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("7eaf5dbf89412f42ebd190a5a5b2b70b9bb5443150881549323022ab87ce003c"));
//#endregion
export { ticketId as a, markTicket as i, listTechFees as n, listTickets as r, getTicket as t };
