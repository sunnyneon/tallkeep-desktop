import { a as TSS_SERVER_FUNCTION } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-ArF6j-2A.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-B1fqQSoo.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
export { createSsrRpc as t };
