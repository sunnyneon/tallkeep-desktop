import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel, l as loadAccounts, s as dayBefore, t as KINDS, u as loadTotals } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { _ as parseVendorExpenses, a as num, c as parseInvoicePayments, d as parseMemorized, f as parseOpenDocs, g as parseUnpaidBills, h as parseTrialBalance, i as lines, l as parseItemList, m as parseSalesDetail, n as accountFinder, o as parseCsv, p as parseRegisterReport, r as findHeader, s as parseIif, t as QB_ACCOUNT_KIND, u as parseJournal, v as qbDate, y as splitName } from "./quickbooks-DDZqKZVM.mjs";
import { t as activeCompanyId } from "./company-tZQlC9nr.mjs";
import { d as Upload, en as CircleCheck, lt as LoaderCircle, m as TriangleAlert } from "../_libs/lucide-react.mjs";
import { o as useLocations } from "./queries-Chjya1cy.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/QuickBooksImport-53iw_Gp6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Moving the books from QuickBooks Desktop: chart of accounts (IIF), then either opening
* balances (Trial Balance) or the full history (Journal report), and unpaid bills.
*/
var lc$3 = (s) => (s ?? "").toLowerCase().replace(/\s+/g, " ").trim();
var uuid$4 = () => crypto.randomUUID();
var r2$3 = (n) => Math.round(n * 100) / 100;
function Done$2({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-sm text-emerald-700",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
			" ",
			text
		]
	});
}
function Warn$1({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2 rounded-lg bg-amber-50 p-2 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children })]
	});
}
async function insertChunks$3(table, rows, step) {
	for (let i = 0; i < rows.length; i += 500) {
		const { error } = await db.from(table).insert(rows.slice(i, i + 500));
		if (error) throw new Error(`${table}: ${error.message}`);
		step?.(Math.min(i + 500, rows.length));
	}
}
/** QuickBooks' special accounts → our built-in ones (so invoices and bills post to them). */
var SPECIAL = [
	{
		key: "ar",
		match: (_n, t) => t === "AR"
	},
	{
		key: "ap",
		match: (_n, t) => t === "AP"
	},
	{
		key: "undeposited",
		match: (n) => n === "undeposited funds"
	},
	{
		key: "inventory",
		match: (n) => n === "inventory asset" || n === "inventory"
	},
	{
		key: "sales_tax",
		match: (n) => n === "sales tax payable"
	},
	{
		key: "opening",
		match: (n) => n === "opening balance equity" || n === "opening bal equity"
	},
	{
		key: "retained",
		match: (n) => n === "retained earnings"
	},
	{
		key: "cogs",
		match: (n) => n === "cost of goods sold"
	}
];
function AccountsStep() {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [hideOthers, setHideOthers] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!rows) return;
		setBusy(true);
		try {
			const mine = await loadAccounts();
			const used = await loadTotals(null, null);
			const taken = /* @__PURE__ */ new Set();
			const updates = [];
			const inserts = [];
			for (const r of rows) {
				const name = (r["NAME"] ?? "").trim();
				const type = (r["ACCNTTYPE"] ?? "").trim();
				const kind = QB_ACCOUNT_KIND[type];
				if (!name || !kind) continue;
				const accType = KINDS.find((k) => k.kind === kind).type;
				const number = (r["ACCNUM"] ?? "").trim() || null;
				const special = SPECIAL.find((x) => x.match(lc$3(name), type))?.key;
				const free = mine.filter((a) => !taken.has(a.id));
				const match = number && free.find((a) => a.number === number) || free.find((a) => lc$3(a.name) === lc$3(name)) || special && free.find((a) => a.key === special) || null;
				const row = {
					name,
					number,
					type: accType,
					kind,
					description: (r["DESC"] ?? "").trim() || null,
					is_active: (r["HIDDEN"] ?? "N") !== "Y"
				};
				if (match) {
					taken.add(match.id);
					updates.push({
						id: match.id,
						...row,
						number: number ?? match.number
					});
				} else inserts.push({
					id: uuid$4(),
					...row
				});
			}
			for (const u of updates) {
				const { id, ...rest } = u;
				const { error } = await db.from("accounts").update(rest).eq("id", id);
				if (error) throw error;
			}
			await insertChunks$3("accounts", inserts);
			let hidden = 0;
			if (hideOthers) {
				const keep = [
					"ar",
					"ap",
					"opening",
					"retained",
					"undeposited",
					"sales_tax"
				];
				const brought = new Set([...updates, ...inserts].map((x) => String(x["type"])));
				const extra = mine.filter((a) => !taken.has(a.id) && !used.has(a.id) && a.is_active && !(a.key && keep.includes(a.key)) && brought.has(a.type));
				for (const a of extra) {
					const { error } = await db.from("accounts").update({ is_active: false }).eq("id", a.id);
					if (error) throw error;
				}
				hidden = extra.length;
				const co = await activeCompanyId();
				const { data: st } = await db.from("company_settings").select("default_bank_account_id").maybeSingle();
				const def = st?.default_bank_account_id;
				const qbBank = [...updates, ...inserts].find((x) => x["kind"] === "bank");
				if (qbBank && (!def || extra.some((a) => a.id === def)) && co) await db.from("company_settings").update({ default_bank_account_id: qbBank["id"] }).eq("company_id", co);
			}
			setDone(`Updated ${updates.length} accounts, added ${inserts.length}` + (hidden ? `, hid ${hidden} ready-made accounts QuickBooks doesn't have` : "") + ".");
			toast.success("Chart of accounts brought in.");
			qc.invalidateQueries({ queryKey: ["accounts"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const count = (rows ?? []).filter((r) => QB_ACCOUNT_KIND[r["ACCNTTYPE"] ?? ""]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 2,
		title: "Chart of accounts",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: File → Utilities → Export → Lists to IIF Files." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tick Chart of Accounts (you can tick it with the lists in step 1), press OK and save." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose the file here. Accounts with the same number or name are updated, not doubled." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".iif,.txt",
				label: rows ? "Choose a different IIF file" : "Choose the .IIF file",
				onText: (t) => {
					const list = parseIif(t)["ACCNT"] ?? [];
					if (!list.length) return void toast.error("No Chart of Accounts in this file.");
					setRows(list);
					setDone("");
				}
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"In this file: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: count }),
						" accounts."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: hideOthers,
						onChange: (e) => setHideOthers(e.target.checked)
					}), "Hide our ready-made accounts that QuickBooks doesn't have (only unused ones; you can run this again)"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void run(),
					disabled: busy,
					children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Bringing in…" : "Bring in the chart of accounts"]
				})
			] }),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$2, { text: done })
		]
	});
}
function useBooksStart() {
	return useQuery({
		queryKey: ["books-settings", "start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").eq("company_id", await activeCompanyId() ?? "").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
}
async function countEntries(type) {
	const { count } = await db.from("journal_entries").select("id", {
		count: "exact",
		head: true
	}).eq("source_type", type);
	return count ?? 0;
}
function BalancesStep() {
	const qc = useQueryClient();
	const { data: start, refetch } = useBooksStart();
	const [newStart, setNewStart] = (0, import_react.useState)("");
	const [how, setHow] = (0, import_react.useState)("opening");
	const [savingStart, setSavingStart] = (0, import_react.useState)(false);
	async function saveStart() {
		if (!newStart) return;
		setSavingStart(true);
		const { error } = await db.from("company_settings").update({ books_start_date: newStart }).eq("company_id", await activeCompanyId() ?? "");
		if (!error) await db.rpc("rebuild_books");
		setSavingStart(false);
		if (error) return void toast.error(error.message);
		toast.success(`Books start on ${fmtDate(newStart)}.`);
		refetch();
		qc.invalidateQueries({ queryKey: ["books-settings"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 3,
		title: "Your books: opening balances or the full history",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "From the books start date, everything you do here writes itself into the books. Before that date, bring in what QuickBooks has, in one of two ways."
			}),
			start ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Books start on ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(start) }),
					" (change it in Settings → Accounting)."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "First day of the books here (for example Jan 1, 2027)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: newStart,
						onChange: (e) => setNewStart(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void saveStart(),
					disabled: !newStart || savingStart,
					children: savingStart ? "Saving…" : "Save start date"
				})]
			}),
			start && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: [["opening", "Opening balances only (simple)"], ["history", "Full history (every transaction)"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setHow(k),
					className: `rounded-md px-3 py-1 ${how === k ? "bg-[var(--section)] text-white" : ""}`,
					children: label
				}, k))
			}), how === "opening" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpeningFromTb, { start }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryFromJournal, { start })] })
		]
	});
}
function OpeningFromTb({ start }) {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)("");
	const asOf = dayBefore(start);
	async function read(text) {
		const tb = parseTrialBalance(parseCsv(text));
		if (!tb) return void toast.error("This doesn't look like the Trial Balance report.");
		const find = accountFinder(await loadAccounts());
		setRows(tb.map((r) => ({
			...r,
			id: find(r.account)
		})));
		setDone("");
	}
	const missing = (rows ?? []).filter((r) => !r.id);
	const dr = r2$3((rows ?? []).reduce((s, r) => s + r.debit, 0));
	const cr = r2$3((rows ?? []).reduce((s, r) => s + r.credit, 0));
	async function run() {
		if (!rows || missing.length || dr !== cr) return;
		setBusy(true);
		try {
			if (await countEntries("history") > 0) throw new Error("Full history from QuickBooks is already here. Use one or the other.");
			const old = await countEntries("opening");
			if (old && !window.confirm("Replace the opening balances that are already here?")) return;
			if (old) {
				const { error } = await db.from("journal_entries").delete().eq("source_type", "opening");
				if (error) throw error;
			}
			const { data: u } = await db.auth.getUser();
			const id = uuid$4();
			const { error } = await db.from("journal_entries").insert({
				id,
				entry_date: asOf,
				memo: "Opening balances from the QuickBooks Trial Balance",
				source_type: "opening",
				created_by: u.user?.id
			});
			if (error) throw error;
			await insertChunks$3("journal_lines", rows.map((r) => ({
				entry_id: id,
				account_id: r.id,
				debit: r2$3(r.debit),
				credit: r2$3(r.credit)
			})));
			setDone(`Opening balances saved for ${fmtDate(asOf)}: ${rows.length} accounts.`);
			toast.success("Opening balances saved.");
			qc.invalidateQueries({ queryKey: ["account-totals"] });
			qc.invalidateQueries({ queryKey: ["journal"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Accountant & Taxes → Trial Balance." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Set both dates to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(asOf) }),
					" (the day before your books start), then Excel → Create New Worksheet → .csv file."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose the file here. Every account starts with its QuickBooks balance on that day." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Trial Balance .CSV file",
				onText: (t) => void read(t)
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length }),
					" accounts · debits ",
					fmtMoney(dr),
					" · credits ",
					fmtMoney(cr)
				]
			}),
			dr !== cr && rows && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warn$1, { children: "Debits and credits don't match. Export the report again." }),
			missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Warn$1, { children: [
				"These accounts aren't here yet: ",
				missing.map((m) => m.account).join(", "),
				". Do step 2 first (or add them in Chart of Accounts), then choose the file again."
			] }),
			rows && !missing.length && dr === cr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Saving…" : "Save these opening balances"]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$2, { text: done })
		]
	});
}
function HistoryFromJournal({ start }) {
	const qc = useQueryClient();
	const [txns, setTxns] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)([]);
	const [find, setFind] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function read(text) {
		const list = parseJournal(parseCsv(text));
		if (!list) return void toast.error("This doesn't look like the Journal report.");
		const f = accountFinder(await loadAccounts());
		const miss = /* @__PURE__ */ new Set();
		for (const t of list) for (const l of t.lines) if (!f(l.account)) miss.add(l.account);
		setTxns(list);
		setMissing([...miss]);
		setFind(() => f);
		setDone("");
	}
	const before = (txns ?? []).filter((t) => t.date < start);
	const after = (txns ?? []).length - before.length;
	const balanced = before.filter((t) => r2$3(t.lines.reduce((s, l) => s + l.debit - l.credit, 0)) === 0);
	const off = before.length - balanced.length;
	const byType = Object.entries(before.reduce((m, t) => {
		const k = t.type || "Other";
		m[k] = (m[k] ?? 0) + 1;
		return m;
	}, {})).sort((a, b) => b[1] - a[1]).slice(0, 6);
	const first = before.reduce((m, t) => t.date < m ? t.date : m, "9999");
	const last = before.reduce((m, t) => t.date > m ? t.date : m, "0000");
	async function run() {
		if (!find || !balanced.length || missing.length) return;
		try {
			setBusy("Checking…");
			if (await countEntries("opening") > 0) throw new Error("Opening balances are already here. Full history replaces them: delete them in Journal Entries first.");
			const inRange = () => db.from("journal_entries").select("id", {
				count: "exact",
				head: true
			}).eq("source_type", "history").gte("entry_date", first).lte("entry_date", last);
			const { count: old } = await inRange();
			if (old && !window.confirm(`${old} transactions from ${fmtDate(first)} to ${fmtDate(last)} are already here. Replace them with this file?`)) return;
			if (old) {
				setBusy("Removing the old copy of these dates…");
				for (;;) {
					const { data, error } = await db.from("journal_entries").select("id").eq("source_type", "history").gte("entry_date", first).lte("entry_date", last).limit(500);
					if (error) throw error;
					const ids = (data ?? []).map((r) => r.id);
					if (!ids.length) break;
					const del = await db.from("journal_entries").delete().in("id", ids);
					if (del.error) throw del.error;
				}
			}
			setBusy("Matching customers and vendors…");
			const custs = await fetchAll("customers", "id,name");
			const vends = await fetchAll("vendors", "id,name");
			const custId = new Map(custs.map((c) => [lc$3(c.name), c.id]));
			const vendId = new Map(vends.map((v) => [lc$3(v.name), v.id]));
			const party = (name) => {
				const k = lc$3(name.split(":")[0]);
				return k ? {
					customer_id: custId.get(k) ?? null,
					vendor_id: custId.has(k) ? null : vendId.get(k) ?? null
				} : {
					customer_id: null,
					vendor_id: null
				};
			};
			const { data: u } = await db.auth.getUser();
			const entries = [];
			const lines = [];
			for (const t of balanced) {
				const id = uuid$4();
				const who = t.lines.find((l) => l.name)?.name ?? "";
				entries.push({
					id,
					entry_date: t.date,
					ref: t.num || null,
					memo: [t.type, who].filter(Boolean).join(" · ") || "From QuickBooks",
					source_type: "history",
					created_by: u.user?.id
				});
				for (const l of t.lines) lines.push({
					entry_id: id,
					account_id: find(l.account),
					debit: r2$3(l.debit),
					credit: r2$3(l.credit),
					memo: [l.name, l.memo].filter(Boolean).join(" · ") || null,
					...party(l.name)
				});
			}
			await insertChunks$3("journal_entries", entries, (n) => setBusy(`Adding transactions… ${n} of ${entries.length}`));
			await insertChunks$3("journal_lines", lines, (n) => setBusy(`Adding lines… ${n} of ${lines.length}`));
			setDone(`Brought in ${entries.length} transactions (${lines.length} lines).`);
			toast.success("History brought in.");
			qc.invalidateQueries({ queryKey: ["account-totals"] });
			qc.invalidateQueries({ queryKey: ["journal"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Accountant & Taxes → Journal." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Dates: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					" (or from the first day you want), up to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(dayBefore(start)) }),
					". A big file? Do one year at a time: each file replaces only its own dates."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Customize Report → Display: make sure Trans #, Type, Date, Num, Name, Memo, Account, Debit and Credit are ticked." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Excel → Create New Worksheet → .csv file, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Journal .CSV file",
				onText: (t) => void read(t)
			}),
			txns && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: before.length }),
					" transactions from ",
					fmtDate(first),
					" to ",
					fmtDate(last),
					byType.length > 0 && ` (${byType.map(([t, k]) => `${k} ${t}`).join(", ")})`,
					".",
					after > 0 && ` ${after} dated on or after the books start are left out (they come from your documents here).`
				]
			}),
			off > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Warn$1, { children: [off, " transactions don't balance and will be left out."] }),
			missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Warn$1, { children: [
				"These accounts aren't here yet: ",
				missing.slice(0, 20).join(", "),
				missing.length > 20 ? ` and ${missing.length - 20} more` : "",
				". Do step 2 first, then choose the file again."
			] }),
			txns && !missing.length && balanced.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || `Bring in ${balanced.length} transactions`]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$2, { text: done })
		]
	});
}
function BillsStep() {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!rows) return;
		setBusy(true);
		try {
			const vendors = await fetchAll("vendors", "id,name");
			const vid = new Map(vendors.map((v) => [lc$3(v.name), v.id]));
			const newV = [...new Set(rows.map((r) => r.vendor))].filter((n) => n && !vid.has(lc$3(n))).map((n) => ({
				id: uuid$4(),
				name: n
			}));
			await insertChunks$3("vendors", newV);
			newV.forEach((v) => vid.set(lc$3(v.name), v.id));
			const existing = await fetchAll("bills", "id,vendor_name,ref,bill_date,memo,total");
			const have = new Map(existing.map((b) => [`${lc$3(b.vendor_name)}|${b.ref ?? ""}|${b.bill_date}`, b]));
			const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
			let reopened = 0;
			for (const r of rows) {
				const b = have.get(`${lc$3(r.vendor)}|${r.num}|${r.date ?? today}`);
				if (!b || !/^From QuickBooks/.test(b.memo ?? "")) continue;
				const del = await db.from("bill_payments").delete().eq("bill_id", b.id);
				if (del.error) throw del.error;
				const paid = r2$3(Number(b.total) - r.balance);
				if (paid > 0) {
					const { error } = await db.from("bill_payments").insert({
						bill_id: b.id,
						amount: paid,
						paid_on: b.bill_date,
						method: "QuickBooks",
						reference: "Paid in QuickBooks"
					});
					if (error) throw error;
				}
				reopened++;
			}
			const todo = rows.filter((r) => !have.has(`${lc$3(r.vendor)}|${r.num}|${r.date ?? today}`));
			const bills = todo.map((r) => ({
				id: uuid$4(),
				vendor_id: vid.get(lc$3(r.vendor)) ?? null,
				vendor_name: r.vendor,
				ref: r.num || null,
				bill_date: r.date ?? today,
				due_date: r.due,
				memo: `Open balance brought over from QuickBooks${r.num ? ` bill ${r.num}` : ""}`
			}));
			await insertChunks$3("bills", bills);
			await insertChunks$3("bill_lines", bills.map((b, i) => ({
				bill_id: b.id,
				line_no: 1,
				description: "Balance from QuickBooks",
				amount: todo[i].balance
			})));
			setDone(`Added ${bills.length} unpaid bills` + (reopened ? `, marked ${reopened} past bills as still owed` : "") + (rows.length > bills.length + reopened ? ` (${rows.length - bills.length - reopened} were already here)` : "") + ".");
			toast.success("Unpaid bills brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const total = (rows ?? []).reduce((s, r) => s + r.balance, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 10,
		title: "Unpaid bills (what you still owe vendors)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Vendors & Payables → Unpaid Bills Detail." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Set the date to the day before your books start, then Excel → .csv file." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose the file here. They show in Bills & Expenses so you can pay them; they're already in your opening balances, so they don't count twice." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the .CSV file",
				onText: (t) => {
					const r = parseUnpaidBills(parseCsv(t));
					if (!r) return void toast.error("This doesn't look like the Unpaid Bills Detail report.");
					setRows(r);
					setDone("");
				}
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length }),
					" unpaid bills, owed in total ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(total) }),
					"."
				]
			}),
			rows && rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Adding…" : "Bring in these bills"]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$2, { text: done })
		]
	});
}
/**
* Past sales from QuickBooks Desktop as real invoices and sales receipts, with their items, so
* every customer's page shows what they bought over the years and sales reports by item work.
*
* They are dated before the books start, so they never post to the books (the books' history
* comes from the Journal report or the opening balances). Running it again skips what is here.
*/
var lc$2 = (s) => (s ?? "").toLowerCase().replace(/\s+/g, " ").trim();
var uuid$3 = () => crypto.randomUUID();
var r2$2 = (n) => Math.round(n * 100) / 100;
/** Our document number for a QuickBooks sale. Invoices keep the QB- numbers of step 6 (open invoices). */
var qbDocNumber = (s) => {
	if (s.kind === "invoice") return `QB-${s.num}`;
	const tag = s.kind === "credit" ? "CM" : "SR";
	return `QB-${tag}-${s.num.replace(new RegExp(`^${tag}-?`, "i"), "") || `${s.date.replace(/-/g, "")}-${s.customer.slice(0, 12)}`}`;
};
async function insertChunks$2(table, rows, step) {
	for (let i = 0; i < rows.length; i += 500) {
		const { error } = await db.from(table).insert(rows.slice(i, i + 500));
		if (error) throw new Error(`${table}: ${error.message}`);
		step?.(Math.min(i + 500, rows.length));
	}
}
function SalesHistoryStep({ n }) {
	const qc = useQueryClient();
	const { data: start } = useBooksStart();
	const [sales, setSales] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const before = (sales ?? []).filter((s) => !start || s.date < start);
	const credits = before.filter((s) => s.kind === "credit").length;
	const later = (sales ?? []).filter((s) => start && s.date >= start).length;
	const first = before.reduce((m, s) => s.date < m ? s.date : m, "9999");
	const last = before.reduce((m, s) => s.date > m ? s.date : m, "0000");
	const total = before.reduce((t, s) => t + s.lines.reduce((x, l) => x + l.amount, 0), 0);
	async function run() {
		if (!before.length) return;
		try {
			setBusy("Checking what's here…");
			const customers = await fetchAll("customers", "id,name");
			const custId = new Map(customers.map((c) => [lc$2(c.name), c.id]));
			const newC = [...new Set(before.map((s) => s.customer))].filter((c) => c && !custId.has(lc$2(c))).map((c) => ({
				id: uuid$3(),
				name: c
			}));
			await insertChunks$2("customers", newC);
			newC.forEach((c) => custId.set(lc$2(c.name), c.id));
			const products = await fetchAll("products", "id,name,custom");
			const byQb = new Map(products.filter((p) => p.custom?.["qb_name"]).map((p) => [lc$2(String(p.custom["qb_name"])), p.id]));
			const byName = new Map(products.map((p) => [lc$2(p.name), p.id]));
			const productFor = (item) => byQb.get(lc$2(item)) ?? byName.get(lc$2(item)) ?? byName.get(lc$2(item.split(":").at(-1))) ?? null;
			const existing = await fetchAll("sales_orders", "id,number,status,balance,remarks");
			const have = new Map(existing.map((o) => [o.number, o]));
			const orders = [];
			const lines = [];
			let filled = 0;
			for (const s of before) {
				const number = qbDocNumber(s);
				const old = have.get(number);
				const sum = r2$2(s.lines.reduce((t, l) => t + l.amount, 0));
				const docLines = (orderId) => s.lines.map((l, i) => ({
					id: uuid$3(),
					sales_order_id: orderId,
					line_no: i + 1,
					product_id: l.item ? productFor(l.item) : null,
					description: [l.item.split(":").at(-1), l.memo].filter(Boolean).join(" — ") || null,
					qty: l.qty,
					unit_price: l.price,
					taxable: false,
					line_total: r2$2(l.amount)
				}));
				if (old) {
					if (old.status === "invoiced" && /^Open balance brought over/.test(old.remarks ?? "")) {
						const del = await db.from("sales_order_lines").delete().eq("sales_order_id", old.id);
						if (del.error) throw del.error;
						lines.push(...docLines(old.id));
						const up = await db.from("sales_orders").update({
							subtotal: sum,
							total: sum,
							amount_paid: r2$2(Math.max(0, sum - Number(old.balance))),
							remarks: `QuickBooks invoice ${s.num}; ${fmtMoney(Number(old.balance))} was still owed at the switch`
						}).eq("id", old.id);
						if (up.error) throw up.error;
						filled++;
					}
					continue;
				}
				const id = uuid$3();
				const when = `${s.date}T12:00:00`;
				orders.push({
					id,
					number,
					status: s.kind === "invoice" ? "paid" : "completed",
					customer_id: custId.get(lc$2(s.customer)) ?? null,
					customer_name: s.customer,
					order_date: when,
					invoice_date: when,
					subtotal: sum,
					total: sum,
					amount_paid: sum,
					balance: 0,
					stock_taken_at: when,
					remarks: `From QuickBooks ${s.kind === "invoice" ? "invoice" : s.kind === "credit" ? "credit memo" : "sales receipt"}${s.num ? ` ${s.num}` : ""}`,
					custom: { source: "quickbooks" }
				});
				lines.push(...docLines(id));
			}
			await insertChunks$2("sales_orders", orders, (k) => setBusy(`Adding sales… ${k} of ${orders.length}`));
			await insertChunks$2("sales_order_lines", lines, (k) => setBusy(`Adding lines… ${k} of ${lines.length}`));
			const skipped = before.length - orders.length - filled;
			setDone(`Added ${orders.length} past sales` + (filled ? `, filled in the items on ${filled} open invoices` : "") + (skipped ? ` (${skipped} were already here)` : "") + ".");
			toast.success("Sales history brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Past sales (what each customer bought)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do steps 1 and 2 first, so customers and items are here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Sales → Sales by Customer Detail." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Dates: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					" (or the years you want)",
					start ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", up to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(dayBefore(start)) })] }) : "",
					". A big file? Do one year at a time; running it again skips what's here."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Excel → Create New Worksheet → .csv file, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Each invoice and sales receipt comes in with its items, as paid, so customer pages and sales-by-item reports show your history. They don't change your books or your stock."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Sales by Customer Detail .CSV file",
				onText: (t) => {
					const list = parseSalesDetail(parseCsv(t));
					if (!list) return void toast.error("This doesn't look like the Sales by Customer Detail report.");
					setSales(list);
					setDone("");
				}
			}),
			sales && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: before.length }),
					" sales from ",
					fmtDate(first),
					" to ",
					fmtDate(last),
					", items worth",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(total) }),
					" (before sales tax)."
				]
			}),
			credits > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Includes ",
					credits,
					" credit memo",
					credits === 1 ? "" : "s",
					" (numbers starting QB-CM-, shown as minus amounts)."
				]
			}),
			later > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 rounded-lg bg-amber-50 p-2 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					"Left out: ",
					later,
					" dated on or after the books start (make those here)."
				] })]
			}),
			before.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || `Bring in ${before.length} past sales`]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-emerald-700",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
					" ",
					done
				]
			})
		]
	});
}
/**
* More history from QuickBooks Desktop: payments received on past invoices, vendor bills and
* checks, and memorized transactions (as Recurring, waiting for a look).
*
* Everything is dated before the books start, so none of it posts to the books (the books'
* history comes from the Journal report or the opening balances). Running a step again skips
* what is already here.
*/
var lc$1 = (s) => (s ?? "").toLowerCase().replace(/\s+/g, " ").trim();
var uuid$2 = () => crypto.randomUUID();
var r2$1 = (n) => Math.round(n * 100) / 100;
async function insertChunks$1(table, rows, step) {
	for (let i = 0; i < rows.length; i += 500) {
		const { error } = await db.from(table).insert(rows.slice(i, i + 500));
		if (error) throw new Error(`${table}: ${error.message}`);
		step?.(Math.min(i + 500, rows.length));
	}
}
function Done$1({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-sm text-emerald-700",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
			" ",
			text
		]
	});
}
function Warn({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2 rounded-lg bg-amber-50 p-2 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children })]
	});
}
function Go({ busy, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick,
		disabled: !!busy,
		children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || label]
	});
}
var upTo = (start) => start ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [", up to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(dayBefore(start)) })] }) : null;
function PaymentsHistoryStep({ n }) {
	const qc = useQueryClient();
	const { data: start } = useBooksStart();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const before = (rows ?? []).filter((p) => !start || p.date < start);
	async function run() {
		try {
			setBusy("Finding the invoices…");
			const orders = await fetchAll("sales_orders", "id,number,status,amount_paid,balance");
			const byNum = new Map(orders.map((o) => [o.number, o]));
			const have = new Set((await fetchAll("payments", "sales_order_id,paid_on,amount,reference")).map((p) => `${p.sales_order_id}|${p.paid_on.slice(0, 10)}|${r2$1(Number(p.amount))}|${p.reference ?? ""}`));
			const touched = /* @__PURE__ */ new Map();
			const add = [];
			let noInvoice = 0;
			for (const p of before) {
				const o = byNum.get(`QB-${p.invoice}`);
				if (!o) {
					noInvoice++;
					continue;
				}
				const reference = p.num ? `QuickBooks payment ${p.num}` : "QuickBooks payment";
				const k = `${o.id}|${p.date}|${r2$1(p.amount)}|${reference}`;
				if (have.has(k)) continue;
				have.add(k);
				touched.set(o.id, o);
				add.push({
					id: uuid$2(),
					sales_order_id: o.id,
					amount: r2$1(p.amount),
					paid_on: `${p.date}T12:00:00`,
					method: "QuickBooks",
					reference,
					remarks: "From QuickBooks"
				});
			}
			await insertChunks$1("payments", add, (k) => setBusy(`Adding payments… ${k} of ${add.length}`));
			setBusy("Keeping invoices as they were…");
			for (const o of touched.values()) {
				const { error } = await db.from("sales_orders").update({
					status: o.status,
					amount_paid: o.amount_paid,
					balance: o.balance
				}).eq("id", o.id);
				if (error) throw error;
			}
			setDone(`Added ${add.length} payments to ${touched.size} invoices` + (noInvoice ? `. ${noInvoice} were for invoices not here (do step 4 first for those)` : "") + ".");
			toast.success("Payments brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const total = before.reduce((t, p) => t + p.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Payments received on past invoices",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do step 4 first, so the invoices are here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Customers & Receivables → Invoices and Received Payments." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Dates: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					" (or the years you want)",
					upTo(start),
					". Excel → Create New Worksheet → .csv file, then choose it here."
				] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Each invoice shows when and how it was paid. They don't change your books."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Invoices and Received Payments .CSV file",
				onText: (t) => {
					const r = parseInvoicePayments(parseCsv(t));
					if (!r) return void toast.error("This doesn't look like the Invoices and Received Payments report.");
					setRows(r);
					setDone("");
				}
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: before.length }),
					" payments, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(total) }),
					" in total."
				]
			}),
			before.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
				busy,
				label: `Bring in ${before.length} payments`,
				onClick: () => void run()
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$1, { text: done })
		]
	});
}
function VendorHistoryStep({ n }) {
	const qc = useQueryClient();
	const { data: start } = useBooksStart();
	const [txns, setTxns] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const before = (txns ?? []).filter((t) => !start || t.date < start);
	async function read(text) {
		const list = parseVendorExpenses(parseCsv(text));
		if (!list) return void toast.error("This doesn't look like the Expenses by Vendor Detail report.");
		const find = accountFinder(await loadAccounts());
		const miss = /* @__PURE__ */ new Set();
		for (const t of list) for (const l of t.lines) if (!find(l.account)) miss.add(l.account);
		setTxns(list);
		setMissing([...miss]);
		setDone("");
	}
	async function run() {
		try {
			setBusy("Checking what's here…");
			const accounts = await loadAccounts();
			const find = accountFinder(accounts);
			const firstOf = (kind) => accounts.find((a) => a.is_active && a.kind === kind)?.id ?? null;
			const vendors = await fetchAll("vendors", "id,name");
			const vid = new Map(vendors.map((v) => [lc$1(v.name), v.id]));
			const newV = [...new Set(before.map((t) => t.vendor))].filter((v) => v && !vid.has(lc$1(v))).map((v) => ({
				id: uuid$2(),
				name: v
			}));
			await insertChunks$1("vendors", newV);
			newV.forEach((v) => vid.set(lc$1(v.name), v.id));
			const oldBills = await fetchAll("bills", "id,vendor_name,ref,bill_date,memo,balance");
			const billKey = (v, ref, d) => `${lc$1(v)}|${ref ?? ""}|${d}`;
			const haveBill = new Map(oldBills.map((b) => [billKey(b.vendor_name, b.ref, b.bill_date), b]));
			const oldChecks = await fetchAll("checks", "payee,number,check_date");
			const haveCheck = new Set(oldChecks.map((c) => `${lc$1(c.payee)}|${c.number ?? ""}|${c.check_date}`));
			const bills = [];
			const billLines = [];
			const billPays = [];
			const checks = [];
			const checkLines = [];
			let filled = 0;
			let skipped = 0;
			for (const t of before) {
				const total = r2$1(t.lines.reduce((s, l) => s + l.amount, 0));
				const lineRows = (parent, field) => t.lines.map((l, i) => ({
					id: uuid$2(),
					[field]: parent,
					line_no: i + 1,
					account_id: find(l.account),
					description: l.memo || null,
					amount: r2$1(l.amount)
				}));
				if (t.type === "bill") {
					const old = haveBill.get(billKey(t.vendor, t.num || null, t.date));
					if (old) {
						if (/^Open balance brought over/.test(old.memo ?? "")) {
							const del = await db.from("bill_lines").delete().eq("bill_id", old.id);
							if (del.error) throw del.error;
							billLines.push(...lineRows(old.id, "bill_id"));
							const paid = r2$1(total - Number(old.balance));
							if (paid > 0) billPays.push({
								id: uuid$2(),
								bill_id: old.id,
								amount: paid,
								paid_on: t.date,
								method: "QuickBooks",
								reference: "Paid in QuickBooks"
							});
							filled++;
						} else skipped++;
						continue;
					}
					const id = uuid$2();
					bills.push({
						id,
						vendor_id: vid.get(lc$1(t.vendor)) ?? null,
						vendor_name: t.vendor,
						ref: t.num || null,
						bill_date: t.date,
						memo: `From QuickBooks${t.num ? ` bill ${t.num}` : ""}`
					});
					billLines.push(...lineRows(id, "bill_id"));
					billPays.push({
						id: uuid$2(),
						bill_id: id,
						amount: total,
						paid_on: t.date,
						method: "QuickBooks",
						reference: "Paid in QuickBooks"
					});
				} else {
					if (haveCheck.has(`${lc$1(t.vendor)}|${t.num}|${t.date}`)) {
						skipped++;
						continue;
					}
					const from = find(t.paidFrom) ?? firstOf(t.type === "card" ? "credit_card" : "bank") ?? firstOf("bank");
					if (!from) throw new Error("Add a bank account first (Chart of Accounts).");
					const id = uuid$2();
					checks.push({
						id,
						account_id: from,
						method: t.type === "card" ? "card" : "check",
						number: t.num || null,
						check_date: t.date,
						vendor_id: vid.get(lc$1(t.vendor)) ?? null,
						payee: t.vendor,
						memo: "From QuickBooks"
					});
					checkLines.push(...lineRows(id, "check_id"));
				}
			}
			await insertChunks$1("bills", bills, (k) => setBusy(`Adding bills… ${k} of ${bills.length}`));
			await insertChunks$1("bill_lines", billLines, (k) => setBusy(`Adding bill lines… ${k} of ${billLines.length}`));
			await insertChunks$1("bill_payments", billPays, (k) => setBusy(`Marking bills paid… ${k} of ${billPays.length}`));
			await insertChunks$1("checks", checks, (k) => setBusy(`Adding checks and charges… ${k} of ${checks.length}`));
			await insertChunks$1("check_lines", checkLines, (k) => setBusy(`Adding lines… ${k} of ${checkLines.length}`));
			setDone(`Added ${bills.length} bills and ${checks.length} checks and card charges` + (filled ? `, filled in the lines on ${filled} unpaid bills` : "") + (skipped ? ` (${skipped} were already here)` : "") + ".");
			toast.success("Vendor history brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const counts = {
		bill: before.filter((t) => t.type === "bill").length,
		other: before.filter((t) => t.type !== "bill").length
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Past bills, checks and card charges (what you paid each vendor)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do steps 1 and 2 first, so vendors and accounts are here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Company & Financial → Expenses by Vendor Detail." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Dates: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					" (or the years you want)",
					upTo(start),
					". Excel → Create New Worksheet → .csv file, then choose it here."
				] })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Each vendor's page shows what you paid them and for what. They don't change your books."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Expenses by Vendor Detail .CSV file",
				onText: (t) => void read(t)
			}),
			txns && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: counts.bill }),
					" bills and ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: counts.other }),
					" checks and card charges."
				]
			}),
			missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Warn, { children: [
				"These accounts aren't here yet: ",
				missing.slice(0, 15).join(", "),
				missing.length > 15 ? ` and ${missing.length - 15} more` : "",
				". Do step 2 first, then choose the file again."
			] }),
			before.length > 0 && !missing.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
				busy,
				label: `Bring in ${before.length} bills, checks and charges`,
				onClick: () => void run()
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$1, { text: done })
		]
	});
}
function MemorizedStep({ n }) {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!rows?.length) return;
		try {
			setBusy("Adding…");
			const accounts = await loadAccounts();
			const find = accountFinder(accounts);
			const firstOf = (kind) => accounts.find((a) => a.is_active && a.kind === kind)?.id ?? null;
			const spare = firstOf("other_expense") ?? firstOf("expense");
			const vendors = await fetchAll("vendors", "id,name");
			const vid = new Map(vendors.map((v) => [lc$1(v.name), v.id]));
			const have = new Set((await fetchAll("recurring", "name")).map((r) => lc$1(r.name)));
			const lastLines = async (vendorId) => {
				if (!vendorId) return null;
				const lines = (await db.from("checks").select("id,check_lines(account_id,description,amount)").eq("vendor_id", vendorId).order("check_date", { ascending: false }).limit(1).maybeSingle()).data?.check_lines;
				if (lines?.length) return lines[0].account_id;
				return (await db.from("bills").select("id,bill_lines(account_id)").eq("vendor_id", vendorId).order("bill_date", { ascending: false }).limit(1).maybeSingle()).data?.bill_lines?.[0]?.account_id ?? null;
			};
			const add = [];
			for (const m of rows) {
				if (have.has(lc$1(m.name))) continue;
				const vendorId = vid.get(lc$1(m.name)) ?? null;
				const lineAccount = await lastLines(vendorId) ?? spare;
				add.push({
					id: uuid$2(),
					name: m.name,
					kind: m.type,
					account_id: m.type === "check" ? find(m.account) ?? firstOf("bank") : null,
					method: m.type === "check" ? "check" : "ach",
					vendor_id: vendorId,
					payee: m.name,
					memo: "From a QuickBooks memorized transaction",
					lines: [{
						account_id: lineAccount,
						description: m.name,
						amount: m.amount
					}],
					every: m.every,
					next_date: m.next && m.next >= today() ? m.next : today(),
					auto: false,
					active: true
				});
			}
			await insertChunks$1("recurring", add);
			setDone(`Added ${add.length} to Recurring. They wait for you: check each one, then tick "Make it automatically on its day" if you like.`);
			toast.success("Memorized transactions brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Memorized transactions (bills and payments that repeat)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do steps 1 and 2 first." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Lists → Memorized Transaction List → Reports button (bottom) → Listing." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Excel → Create New Worksheet → .csv file, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Repeating checks and bills come into Banking → Recurring, switched to wait for you, so nothing is paid without a look. Other kinds (invoices, deposits) are left out."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Memorized Transaction Listing .CSV file",
				onText: (t) => {
					const r = parseMemorized(parseCsv(t));
					if (!r) return void toast.error("This doesn't look like the Memorized Transaction Listing.");
					setRows(r);
					setDone("");
				}
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length }), " repeating checks and bills."]
			}),
			!!rows?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Go, {
				busy,
				label: `Bring in ${rows.length}`,
				onClick: () => void run()
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done$1, { text: done })
		]
	});
}
/**
* More from QuickBooks Desktop (all optional): item details (barcodes, part numbers, units,
* reorder levels), open estimates / sales orders / purchase orders, and which checks and deposits
* already cleared the bank (so reconciling carries on where QuickBooks left off).
* Running a step again skips or updates what is already here.
*/
var lc = (s) => (s ?? "").toLowerCase().replace(/\s+/g, " ").trim();
var uuid$1 = () => crypto.randomUUID();
var r2 = (n) => Math.round(n * 100) / 100;
var T = (t) => db.from(t);
async function insertChunks(table, rows) {
	for (let i = 0; i < rows.length; i += 500) {
		const { error } = await T(table).insert(rows.slice(i, i + 500));
		if (error) throw new Error(`${table}: ${error.message}`);
	}
}
/** Find our product for a QuickBooks item name (full "Parent:Child" name, then the short one). */
async function productFinder() {
	const products = await fetchAll("products", "id,name,custom");
	const byQb = new Map(products.filter((p) => p.custom?.["qb_name"]).map((p) => [lc(String(p.custom["qb_name"])), p]));
	const byName = new Map(products.map((p) => [lc(p.name), p]));
	return (item) => byQb.get(lc(item)) ?? byName.get(lc(item)) ?? byName.get(lc(item.split(":").at(-1))) ?? null;
}
function Done({ text }) {
	return text ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 text-sm text-emerald-700",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
			" ",
			text
		]
	}) : null;
}
function ItemDetailsStep({ n }) {
	const qc = useQueryClient();
	const [items, setItems] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!items) return;
		try {
			setBusy("Matching items…");
			const find = await productFinder();
			const vendors = await fetchAll("vendors", "id,name");
			const vendorId = new Map(vendors.map((v) => [lc(v.name), v.id]));
			const links = await fetchAll("vendor_items", "vendor_id,product_id");
			let updated = 0;
			let missing = 0;
			const newLinks = [];
			for (const [k, it] of items.entries()) {
				const p = find(it.item);
				if (!p) {
					missing++;
					continue;
				}
				const change = {};
				if (it.upc) change["barcode"] = it.upc;
				if (it.unit) change["unit"] = it.unit;
				if (it.reorderPoint != null && it.reorderPoint > 0) change["reorder_point"] = it.reorderPoint;
				if (it.max != null && it.reorderPoint != null && it.max > it.reorderPoint) change["reorder_qty"] = it.max - it.reorderPoint;
				if (it.cost != null && it.cost > 0) change["cost"] = it.cost;
				if (it.price != null && it.price > 0) change["price"] = it.price;
				if (it.mpn || it.purchaseDesc) change["custom"] = {
					...p.custom ?? {},
					...it.mpn ? { "Part number (MPN)": it.mpn } : {},
					...it.purchaseDesc ? { "Purchase description": it.purchaseDesc } : {}
				};
				if (Object.keys(change).length) {
					const { error } = await T("products").update(change).eq("id", p.id);
					if (error) throw new Error(error.message);
					updated++;
				}
				const v = it.vendor ? vendorId.get(lc(it.vendor)) : void 0;
				if (v && !links.some((l) => l.vendor_id === v && l.product_id === p.id)) {
					newLinks.push({
						vendor_id: v,
						product_id: p.id,
						cost: it.cost ?? 0
					});
					links.push({
						vendor_id: v,
						product_id: p.id
					});
				}
				if (k % 25 === 0) setBusy(`Items… ${k + 1} of ${items.length}`);
			}
			if (newLinks.length) await insertChunks("vendor_items", newLinks);
			setDone(`Updated ${updated} items${newLinks.length ? `, linked ${newLinks.length} to their preferred vendor` : ""}${missing ? ` (${missing} weren't found here: do step 1 first)` : ""}.`);
			toast.success("Item details brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const withUpc = (items ?? []).filter((i) => i.upc).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Item details: barcodes, part numbers, units and reorder levels (optional)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do step 1 first, so your items are here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Lists → Item List → Excel (bottom of the list) → Export all items." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose \"Create a comma separated values (.csv) file\", save it, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Item List .CSV file",
				onText: (t) => {
					const list = parseItemList(parseCsv(t));
					if (!list?.length) return void toast.error("This doesn't look like the Item List.");
					setItems(list);
					setDone("");
				}
			}),
			items && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: items.length }),
					" items",
					withUpc ? `, ${withUpc} with a barcode` : "",
					"."
				]
			}),
			items && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || `Update ${items.length} items`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, { text: done })
		]
	});
}
var DOC_NAME = {
	estimate: "estimate",
	sales_order: "sales order",
	purchase_order: "purchase order"
};
var docNumber = (d) => `QB-${d.kind === "estimate" ? "EST" : d.kind === "sales_order" ? "SO" : "PO"}-${d.num || `${d.date.replace(/-/g, "")}-${d.name.slice(0, 12)}`}`;
function OpenDocsStep({ n }) {
	const qc = useQueryClient();
	const [docs, setDocs] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!docs?.length) return;
		try {
			setBusy("Checking what's here…");
			const find = await productFinder();
			const [customers, vendors, sales, pos] = await Promise.all([
				fetchAll("customers", "id,name"),
				fetchAll("vendors", "id,name"),
				fetchAll("sales_orders", "number"),
				fetchAll("purchase_orders", "number")
			]);
			const custId = new Map(customers.map((c) => [lc(c.name), c.id]));
			const vendId = new Map(vendors.map((v) => [lc(v.name), v.id]));
			const have = new Set([...sales, ...pos].map((x) => x.number));
			const newC = [];
			const newV = [];
			for (const d of docs) {
				if (!d.name) continue;
				if (d.kind === "purchase_order") {
					if (!vendId.has(lc(d.name))) {
						const id = uuid$1();
						vendId.set(lc(d.name), id);
						newV.push({
							id,
							name: d.name
						});
					}
				} else if (!custId.has(lc(d.name))) {
					const id = uuid$1();
					custId.set(lc(d.name), id);
					newC.push({
						id,
						name: d.name
					});
				}
			}
			await insertChunks("customers", newC);
			await insertChunks("vendors", newV);
			const so = [];
			const soLines = [];
			const po = [];
			const poLines = [];
			let skipped = 0;
			for (const d of docs) {
				const number = docNumber(d);
				if (have.has(number)) {
					skipped++;
					continue;
				}
				const id = uuid$1();
				const total = r2(d.lines.reduce((t, l) => t + l.amount, 0));
				const when = `${d.date}T12:00:00`;
				const remarks = [`From QuickBooks ${DOC_NAME[d.kind]} ${d.num}`.trim(), d.memo].filter(Boolean).join(" · ");
				if (d.kind === "purchase_order") {
					po.push({
						id,
						number,
						status: "open",
						vendor_id: vendId.get(lc(d.name)) ?? null,
						vendor_name: d.name || null,
						order_date: when,
						subtotal: total,
						tax: 0,
						freight: 0,
						total,
						amount_paid: 0,
						balance: total,
						remarks,
						custom: { source: "quickbooks" }
					});
					d.lines.forEach((l, i) => poLines.push({
						id: uuid$1(),
						purchase_order_id: id,
						line_no: i + 1,
						product_id: find(l.item)?.id ?? null,
						description: [l.item.split(":").at(-1), l.memo].filter(Boolean).join(" — ") || null,
						qty: l.qty,
						qty_received: Math.min(l.received, l.qty),
						unit_cost: r2(l.price),
						line_total: r2(l.amount)
					}));
				} else {
					so.push({
						id,
						number,
						status: d.kind === "estimate" ? "quote" : "open",
						customer_id: custId.get(lc(d.name)) ?? null,
						customer_name: d.name || null,
						order_date: when,
						subtotal: total,
						total,
						amount_paid: 0,
						balance: total,
						remarks,
						custom: { source: "quickbooks" }
					});
					d.lines.forEach((l, i) => soLines.push({
						id: uuid$1(),
						sales_order_id: id,
						line_no: i + 1,
						product_id: find(l.item)?.id ?? null,
						description: [l.item.split(":").at(-1), l.memo].filter(Boolean).join(" — ") || null,
						qty: l.qty,
						unit_price: r2(l.price),
						taxable: false,
						line_total: r2(l.amount)
					}));
				}
			}
			setBusy("Adding them…");
			await insertChunks("sales_orders", so);
			await insertChunks("sales_order_lines", soLines);
			await insertChunks("purchase_orders", po);
			await insertChunks("purchase_order_lines", poLines);
			const est = so.filter((x) => x["status"] === "quote").length;
			setDone(`Added ${est} quotes, ${so.length - est} sales orders and ${po.length} purchase orders${skipped ? ` (${skipped} were already here)` : ""}.`);
			toast.success("Open documents brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const count = (k) => (docs ?? []).filter((d) => d.kind === k).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Open estimates, sales orders and purchase orders (optional)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do step 1 first, so customers, vendors and items are here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Custom Reports → Transaction Detail." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Display: Dates ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					". Columns: tick",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Type, Date, Num, Name, Memo, Item, Qty, Sales Price, Cost Price, Amount" }),
					" (untick the rest)."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Filters: Transaction Type → ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Multiple Transaction Types" }),
					" → Estimate, Sales Order, Purchase Order. Then add ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Estimate Active = Yes" }),
					" and ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Received = No" }),
					" so only open ones come."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Excel → Create New Worksheet → .csv file, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Estimates become quotes, sales orders stay open orders, and purchase orders stay open so you can receive them here. They don't change your books or stock until you act on them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the Transaction Detail .CSV file",
				onText: (t) => {
					const list = parseOpenDocs(parseCsv(t));
					if (!list) return void toast.error("This doesn't look like a Transaction Detail report with an Item column.");
					if (!list.length) return void toast.error("No estimates, sales orders or purchase orders found in this file.");
					setDocs(list);
					setDone("");
				}
			}),
			docs && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: count("estimate") }),
					" estimates, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: count("sales_order") }),
					" sales orders,",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: count("purchase_order") }),
					" purchase orders."
				]
			}),
			docs && docs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || `Bring in ${docs.length}`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, { text: done })
		]
	});
}
function ClearedStep({ n }) {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const regs = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	const [acct, setAcct] = (0, import_react.useState)("");
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function run() {
		if (!rows || !acct) return;
		try {
			setBusy("Matching…");
			const { data, error } = await db.rpc("account_lines", {
				_account: acct,
				_to: null
			});
			if (error) throw new Error(error.message);
			const lines = data ?? [];
			const used = /* @__PURE__ */ new Set();
			const marks = [];
			let notFound = 0;
			for (const r of rows.filter((x) => x.cleared)) {
				const pick = (sign) => lines.find((l) => !used.has(l.item_key) && l.entry_date === r.date && Math.abs(Number(l.amount) - sign * r.amount) < .005 && (!r.num || !l.ref || l.ref === r.num || l.ref.endsWith(r.num))) ?? lines.find((l) => !used.has(l.item_key) && l.entry_date === r.date && Math.abs(Number(l.amount) - sign * r.amount) < .005);
				const hit = pick(1) ?? pick(-1);
				if (!hit) {
					notFound++;
					continue;
				}
				used.add(hit.item_key);
				if (!hit.cleared) marks.push({
					account_id: acct,
					item_key: hit.item_key
				});
			}
			for (let i = 0; i < marks.length; i += 500) {
				const { error: e2 } = await T("cleared_items").upsert(marks.slice(i, i + 500), {
					onConflict: "account_id,item_key",
					ignoreDuplicates: true
				});
				if (e2) throw new Error(e2.message);
			}
			const name = regs.find((a) => a.id === acct)?.name ?? "the account";
			setDone(`Marked ${marks.length} lines in ${name} as cleared${notFound ? `; ${notFound} cleared lines weren't found here (bring in the full history in step 3 first)` : ""}.`);
			toast.success("Cleared marks brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const cleared = (rows ?? []).filter((r) => r.cleared).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n,
		title: "Cleared checks and deposits, to keep reconciling (optional)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "This needs the full history (step 3, Journal report), so each check and deposit is here one by one." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"In QuickBooks: Lists → Chart of Accounts → click the bank or card account → Reports (bottom) → QuickReport: Account. Dates: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "All" }),
					"."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Excel → Create New Worksheet → .csv file. Do one file per account." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pick the same account here, then choose the file." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				"aria-label": "Account",
				className: "h-9 w-full max-w-sm rounded-md border bg-background px-2 text-sm",
				value: acct,
				onChange: (e) => setAcct(e.target.value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "Which bank or card account?"
				}), regs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: a.id,
					children: accountLabel(a)
				}, a.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the QuickReport .CSV file",
				onText: (t) => {
					const list = parseRegisterReport(parseCsv(t));
					if (!list) return void toast.error("This doesn't look like a QuickReport with a Clr column.");
					setRows(list);
					setDone("");
				}
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length }),
					" lines from ",
					fmtDate(rows[0]?.date ?? null),
					" to",
					" ",
					fmtDate(rows.at(-1)?.date ?? null),
					"; ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: cleared }),
					" cleared the bank (",
					fmtMoney(rows.filter((r) => !r.cleared).reduce((s, r) => s + r.amount, 0)),
					" not yet)."
				]
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy || !acct || !cleared,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy || (acct ? `Mark ${cleared} as cleared` : "Pick the account first")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, { text: done })
		]
	});
}
/** Optional QuickBooks fields kept as custom fields (also CUSTFLD1-15, QuickBooks' own custom fields). */
function qbExtras(r, names) {
	const out = {};
	for (const [k, label] of Object.entries(names)) if (r[k]?.trim()) out[label] = r[k].trim();
	for (let i = 1; i <= 15; i++) {
		const v = r[`CUSTFLD${i}`]?.trim();
		if (v) out[`QuickBooks custom field ${i}`] = v;
	}
	return out;
}
var key = (s) => (s ?? "").trim().toLowerCase();
var uuid = () => crypto.randomUUID();
var orNull = (v) => v && v.trim() ? v.trim() : null;
async function upsertAll(table, rows, onStep) {
	for (let i = 0; i < rows.length; i += 500) {
		const { error } = await db.from(table).upsert(rows.slice(i, i + 500), { onConflict: "id" });
		if (error) throw new Error(`${table}: ${error.message}`);
		onStep?.(Math.min(i + 500, rows.length));
	}
}
/**
* Moving from QuickBooks Desktop: export each part from QuickBooks, upload it here.
* Running a step again updates the same records instead of making copies.
*/
function QuickBooksImport() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring data over from QuickBooks"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "For QuickBooks Desktop (2019 and newer). Do the steps in order: each one says what to export in QuickBooks, then you choose that file here. Running a step again updates the same records; it won't make copies."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
				title: "Your lists",
				text: "Customers, vendors, items, payment terms and the chart of accounts. Do these first.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListsStep, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountsStep, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
				title: "Your books and history",
				text: "Every past transaction (or just the balances), what each customer bought and paid, what you paid each vendor, and what repeats. Big files can come in one year at a time.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalancesStep, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesHistoryStep, { n: 4 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentsHistoryStep, { n: 5 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VendorHistoryStep, { n: 6 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemorizedStep, { n: 7 })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
				title: "What's open on switch-over day",
				text: "Stock on hand, what customers still owe you and what you still owe vendors, so you can carry on here.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockStep, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoicesStep, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillsStep, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, {
				title: "Extras (optional)",
				text: "Skip any you don't need. Barcodes and reorder levels for items, open quotes and orders, and which checks already cleared the bank.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDetailsStep, { n: 11 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenDocsStep, { n: 12 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClearedStep, { n: 13 })
				]
			})
		]
	});
}
function Group({ title, text, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-sm font-semibold uppercase tracking-wide text-[var(--section)]",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: text
		})] }), children]
	});
}
function Step({ n, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-xl border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "font-medium",
			children: [
				n,
				". ",
				title
			]
		}), children]
	});
}
function FilePick({ accept, label, onText }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex cursor-pointer items-center gap-3 rounded-lg border-2 border-dashed p-3 text-sm hover:bg-muted/40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
			" ",
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				accept,
				className: "hidden",
				onChange: async (e) => {
					const f = e.target.files?.[0];
					e.target.value = "";
					if (f) onText(await readQbFile(f), f.name);
				}
			})
		]
	});
}
function How({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "list-decimal space-y-0.5 pl-5 text-sm text-muted-foreground",
		children
	});
}
var ITEM_TYPE = {
	INVENTORY: "stocked",
	ASSEMBLY: "stocked",
	PART: "non_stocked",
	SERV: "service",
	OTHC: "service"
};
function ListsStep() {
	const qc = useQueryClient();
	const [iif, setIif] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const customers = (iif?.["CUST"] ?? []).filter((r) => r["NAME"] && !r["NAME"].includes(":"));
	const jobs = (iif?.["CUST"] ?? []).length - customers.length;
	const vendors = (iif?.["VEND"] ?? []).filter((r) => r["NAME"]);
	const items = (iif?.["INVITEM"] ?? []).filter((r) => ITEM_TYPE[r["INVITEMTYPE"] ?? ""]);
	const taxes = (iif?.["INVITEM"] ?? []).filter((r) => r["INVITEMTYPE"] === "COMPTAX" && r["NAME"] && Number.isFinite(num((r["PRICE"] ?? "").replace("%", ""))));
	const terms = (iif?.["TERMS"] ?? []).filter((r) => r["NAME"]);
	async function run() {
		if (!iif) return;
		try {
			setBusy("Payment terms…");
			const oldTerms = await fetchAll("payment_terms", "id,name");
			const termRows = terms.map((t) => ({
				id: oldTerms.find((o) => key(o.name) === key(t["NAME"]))?.id ?? uuid(),
				name: t["NAME"].trim(),
				days_due: Number.isFinite(num(t["DUEDAYS"])) ? num(t["DUEDAYS"]) : 0,
				is_active: t["HIDDEN"] !== "Y"
			}));
			await upsertAll("payment_terms", termRows);
			const termId = new Map([...oldTerms, ...termRows].map((t) => [key(t.name), t.id]));
			const tid = (n) => n ? termId.get(key(n)) ?? null : null;
			setBusy("Customers…");
			const oldC = await fetchAll("customers", "id,name,custom");
			await upsertAll("customers", customers.map((c) => ({
				id: oldC.find((o) => key(o.name) === key(c["NAME"]))?.id ?? uuid(),
				name: c["NAME"].trim(),
				contact_name: orNull(c["CONT1"]),
				phone: orNull(c["PHONE1"]),
				fax: orNull(c["FAXNUM"]),
				email: orNull(c["EMAIL"]),
				address: lines(c, "BADDR"),
				billing_address: lines(c, "BADDR"),
				shipping_address: lines(c, "SADDR"),
				payment_terms_id: tid(c["TERMS"]),
				tax_exempt_number: orNull(c["RESALENUM"]),
				sales_rep: orNull(c["REP"]),
				remarks: orNull(c["NOTE"]),
				is_active: c["HIDDEN"] !== "Y",
				custom: {
					...oldC.find((o) => key(o.name) === key(c["NAME"]))?.custom ?? {},
					...qbExtras(c, {
						CONT2: "Other contact",
						PHONE2: "Other phone",
						CTYPE: "Customer type"
					})
				}
			})), (n) => setBusy(`Customers… ${n} of ${customers.length}`));
			setBusy("Vendors…");
			const oldV = await fetchAll("vendors", "id,name,custom");
			const vendorRows = vendors.map((v) => {
				const old = oldV.find((o) => key(o.name) === key(v["NAME"]));
				return {
					id: old?.id ?? uuid(),
					name: v["NAME"].trim(),
					contact_name: orNull(v["CONT1"]),
					phone: orNull(v["PHONE1"]),
					fax: orNull(v["FAXNUM"]),
					email: orNull(v["EMAIL"]),
					address: lines(v, "ADDR"),
					payment_terms_id: tid(v["TERMS"]),
					remarks: orNull(v["NOTE"]),
					is_active: v["HIDDEN"] !== "Y",
					tax_id: orNull(v["TAXID"]),
					is_1099: v["1099"] === "Y",
					custom: {
						...old?.custom ?? {},
						...qbExtras(v, {
							ACCNUM: "Our account number",
							VTYPE: "Vendor type",
							CONT2: "Other contact",
							PHONE2: "Other phone"
						})
					}
				};
			});
			await upsertAll("vendors", vendorRows);
			const vendorId = new Map([...oldV, ...vendorRows].map((v) => [key(v.name), v.id]));
			setBusy("Categories…");
			const oldCat = await fetchAll("categories", "id,name");
			const catRows = [...new Set(items.map((i) => splitName(i["NAME"]).parent).filter(Boolean))].filter((p) => !oldCat.some((o) => key(o.name) === key(p))).map((p) => ({
				id: uuid(),
				name: p
			}));
			await upsertAll("categories", catRows);
			const catId = new Map([...oldCat, ...catRows].map((c) => [key(c.name), c.id]));
			setBusy("Items…");
			const oldP = await fetchAll("products", "id,name,custom");
			const lastNames = items.map((i) => key(splitName(i["NAME"]).name));
			const productRows = items.map((i) => {
				const full = i["NAME"].trim();
				const { name, parent } = splitName(full);
				const shown = parent && lastNames.filter((n) => n === key(name)).length > 1 ? `${name} (${parent})` : name;
				const old = oldP.find((o) => o.custom?.qb_name === full) ?? oldP.find((o) => !o.custom?.qb_name && key(o.name) === key(shown));
				const reorder = num(i["REORDERPOINT"]);
				return {
					id: old?.id ?? uuid(),
					name: shown,
					description: orNull(i["DESC"]) ?? orNull(i["PURCHASEDESC"]),
					item_type: ITEM_TYPE[i["INVITEMTYPE"]],
					category_id: parent ? catId.get(key(parent)) ?? null : null,
					cost: Number.isFinite(num(i["COST"])) ? num(i["COST"]) : 0,
					price: Number.isFinite(num(i["PRICE"])) ? num(i["PRICE"]) : 0,
					reorder_point: Number.isFinite(reorder) && reorder > 0 ? reorder : null,
					is_active: i["HIDDEN"] !== "Y",
					custom: {
						...old?.custom ?? {},
						qb_name: full
					}
				};
			});
			await upsertAll("products", productRows, (n) => setBusy(`Items… ${n} of ${productRows.length}`));
			const links = await fetchAll("vendor_items", "vendor_id,product_id");
			const newLinks = items.map((i, k) => ({
				vendor_id: vendorId.get(key(i["PREFVEND"])),
				product_id: productRows[k].id,
				cost: productRows[k].cost
			})).filter((l) => l.vendor_id && !links.some((x) => x.vendor_id === l.vendor_id && x.product_id === l.product_id));
			if (newLinks.length) await db.from("vendor_items").insert(newLinks);
			if (taxes.length) {
				setBusy("Sales tax rates…");
				const oldT = await fetchAll("tax_rates", "id,name");
				await upsertAll("tax_rates", taxes.map((t) => ({
					id: oldT.find((o) => key(o.name) === key(t["NAME"]))?.id ?? uuid(),
					name: t["NAME"].trim(),
					rate: num((t["PRICE"] ?? "").replace("%", "")),
					is_active: t["HIDDEN"] !== "Y"
				})));
			}
			setDone(`Brought in ${customers.length} customers, ${vendors.length} vendors, ${items.length} items, ${terms.length} payment terms and ${taxes.length} sales tax rates.`);
			toast.success("QuickBooks lists brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 1,
		title: "Customers, vendors, items, payment terms and sales tax",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: File → Utilities → Export → Lists to IIF Files." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tick Customer List, Vendor List, Item List (it has your sales tax items too) and Terms List, then press OK." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Save the file, then choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".iif,.txt",
				label: iif ? "Choose a different IIF file" : "Choose the .IIF file",
				onText: (t) => {
					setIif(parseIif(t));
					setDone("");
				}
			}),
			iif && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"In this file: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: customers.length }),
					" customers",
					jobs > 0 ? ` (and ${jobs} jobs, which stay with their customer)` : "",
					",",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: vendors.length }),
					" vendors, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: items.length }),
					" items, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: terms.length }),
					" ",
					"payment terms, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: taxes.length }),
					" sales tax rates."
				]
			}),
			iif && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, busy || "Bring in these lists"]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-emerald-700",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
					" ",
					done
				]
			})
		]
	});
}
function StockStep() {
	const qc = useQueryClient();
	const { data: locations } = useLocations();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [loc, setLoc] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	async function read(text) {
		const csv = parseCsv(text);
		const h = findHeader(csv, ["On Hand"]);
		if (!h) return void toast.error("This doesn't look like the Inventory Valuation Summary.");
		const onCol = h.col("On Hand");
		const costCol = h.col("Avg Cost");
		const products = await fetchAll("products", "id,name,custom");
		const out = [];
		for (const r of csv.slice(h.index + 1)) {
			const qty = num(r[onCol]);
			const name = r.slice(0, onCol).find((c) => c) ?? "";
			if (!Number.isFinite(qty) || !name || /^total/i.test(name)) continue;
			const short = splitName(name).name;
			const p = products.find((x) => x.custom?.qb_name === name) ?? products.find((x) => x.custom?.qb_name && splitName(x.custom.qb_name).name === short) ?? products.find((x) => key(x.name) === key(short));
			out.push({
				name,
				qty,
				cost: num(r[costCol]),
				productId: p?.id ?? null
			});
		}
		setRows(out);
		setDone("");
	}
	async function run() {
		if (!rows || !loc) return;
		const ok = rows.filter((r) => r.productId);
		try {
			for (let i = 0; i < ok.length; i++) {
				const r = ok[i];
				setBusy(`Setting stock… ${i + 1} of ${ok.length}`);
				const { error } = await db.rpc("set_stock_count", {
					_product_id: r.productId,
					_location_id: loc,
					_shelf: "",
					_counted: r.qty,
					_note: "Opening stock from QuickBooks"
				});
				if (error) throw error;
				if (Number.isFinite(r.cost) && r.cost > 0) await db.from("products").update({ cost: r.cost }).eq("id", r.productId);
			}
			setDone(`Stock set for ${ok.length} items.`);
			toast.success("Opening stock brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const missing = (rows ?? []).filter((r) => !r.productId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 8,
		title: "Stock on hand",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Do step 1 first, so the items exist here." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Inventory → Inventory Valuation Summary." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Set the date to your switch-over day, then Excel → Create New Worksheet." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose \"Create a comma separated values (.csv) file\", save it, choose it here." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the .CSV file",
				onText: (t) => void read(t)
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length - missing.length }),
						" items found here",
						missing.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							"; ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: missing.length }),
							" not found (",
							missing.slice(0, 5).map((m) => m.name).join(", "),
							missing.length > 5 ? "…" : "",
							")"
						] }) : null,
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: loc,
						onValueChange: setLoc,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-60",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Put the stock in which place?" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (locations ?? []).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: l.id,
							children: l.name
						}, l.id)) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void run(),
						disabled: !!busy || !loc,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, busy || "Set stock to these counts"]
					})]
				}),
				!(locations ?? []).length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Add a place first under Inventory → Locations."
				})
			] }),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-emerald-700",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
					" ",
					done
				]
			})
		]
	});
}
function InvoicesStep() {
	const qc = useQueryClient();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	function read(text) {
		const csv = parseCsv(text);
		const h = findHeader(csv, [
			"Type",
			"Num",
			"Open Balance"
		]);
		if (!h) return void toast.error("This doesn't look like the Open Invoices report.");
		const c = {
			type: h.col("Type"),
			num: h.col("Num"),
			date: h.col("Date"),
			due: h.col("Due Date"),
			po: h.col("P. O. #"),
			name: h.col("Name"),
			bal: h.col("Open Balance")
		};
		const out = [];
		let current = "";
		for (const r of csv.slice(h.index + 1)) {
			const type = r[c.type] ?? "";
			if (!type) {
				const head = r.slice(0, c.type).find((x) => x) ?? "";
				if (head && !/^total/i.test(head)) current = head;
				continue;
			}
			if (!/invoice/i.test(type)) continue;
			const balance = num(r[c.bal]);
			if (!(balance > 0)) continue;
			const who = c.name >= 0 && r[c.name] || current;
			out.push({
				customer: who.split(":")[0].trim(),
				num: r[c.num] ?? "",
				date: qbDate(r[c.date]),
				due: c.due >= 0 ? qbDate(r[c.due]) : null,
				po: c.po >= 0 ? orNull(r[c.po]) : null,
				balance
			});
		}
		setRows(out);
		setDone("");
	}
	async function run() {
		if (!rows) return;
		try {
			setBusy("Checking…");
			const customers = await fetchAll("customers", "id,name");
			const existing = await fetchAll("sales_orders", "id,number,status,total,custom");
			const have = new Set(existing.map((o) => o.number));
			const fromHistory = new Map(existing.filter((o) => o.custom?.source === "quickbooks" && o.status !== "invoiced").map((o) => [o.number, o]));
			let reopened = 0;
			for (const r of rows) {
				const o = fromHistory.get(`QB-${r.num}`);
				if (!o) continue;
				const total = Number(o.total);
				const { error } = await db.from("sales_orders").update({
					status: "invoiced",
					balance: r.balance,
					amount_paid: Math.max(0, Math.round((total - r.balance) * 100) / 100),
					due_date: r.due
				}).eq("id", o.id);
				if (error) throw error;
				reopened++;
			}
			const custId = new Map(customers.map((c) => [key(c.name), c.id]));
			const newCustomers = [...new Set(rows.map((r) => r.customer))].filter((n) => n && !custId.has(key(n))).map((n) => ({
				id: uuid(),
				name: n
			}));
			await upsertAll("customers", newCustomers);
			newCustomers.forEach((c) => custId.set(key(c.name), c.id));
			const orders = rows.filter((r) => !have.has(`QB-${r.num}`)).map((r) => ({
				id: uuid(),
				number: `QB-${r.num}`,
				status: "invoiced",
				customer_id: custId.get(key(r.customer)) ?? null,
				customer_name: r.customer,
				order_date: r.date ?? (/* @__PURE__ */ new Date()).toISOString(),
				invoice_date: r.date ?? (/* @__PURE__ */ new Date()).toISOString(),
				due_date: r.due,
				po_number: r.po,
				subtotal: r.balance,
				total: r.balance,
				balance: r.balance,
				amount_paid: 0,
				stock_taken_at: r.date ?? (/* @__PURE__ */ new Date()).toISOString(),
				remarks: `Open balance brought over from QuickBooks invoice ${r.num}`
			}));
			setBusy("Adding invoices…");
			await upsertAll("sales_orders", orders);
			await upsertAll("sales_order_lines", orders.map((o) => ({
				id: uuid(),
				sales_order_id: o.id,
				line_no: 1,
				description: `Balance from QuickBooks invoice ${o.number.slice(3)}`,
				qty: 1,
				unit_price: o.balance,
				taxable: false,
				line_total: o.balance
			})));
			setDone(`Added ${orders.length} open invoices` + (reopened ? `, marked ${reopened} past sales as still owed` : "") + (rows.length > orders.length + reopened ? ` (${rows.length - orders.length - reopened} were already here)` : "") + ".");
			toast.success("Open invoices brought in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	const total = (rows ?? []).reduce((s, r) => s + r.balance, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
		n: 9,
		title: "Open invoices (what customers still owe)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(How, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In QuickBooks: Reports → Customers & Receivables → Open Invoices." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Set the date to your switch-over day, then Excel → Create New Worksheet → .csv file." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose the file here. Each open invoice comes in with what is still owed on it." })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePick, {
				accept: ".csv",
				label: "Choose the .CSV file",
				onText: read
			}),
			rows && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: rows.length }),
					" open invoices, owed in total",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: total.toLocaleString("en-US", {
						style: "currency",
						currency: "USD"
					}) }),
					". They come in as numbers starting with QB-."
				]
			}),
			rows && rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void run(),
				disabled: !!busy,
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, busy || "Bring in these invoices"]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-emerald-700",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
					" ",
					done
				]
			})
		]
	});
}
/**
* QuickBooks Desktop saves IIF and CSV files in the Windows character set, not UTF-8: the "·"
* between an account number and its name (and accents, dashes) would come through broken.
* Read as UTF-8 when the file really is UTF-8, otherwise as Windows-1252.
*/
async function readQbFile(f) {
	const bytes = new Uint8Array(await f.arrayBuffer());
	try {
		return new TextDecoder("utf-8", { fatal: true }).decode(bytes).replace(/^\uFEFF/, "");
	} catch {
		return new TextDecoder("windows-1252").decode(bytes);
	}
}
//#endregion
export { QuickBooksImport as n, FilePick as t };
