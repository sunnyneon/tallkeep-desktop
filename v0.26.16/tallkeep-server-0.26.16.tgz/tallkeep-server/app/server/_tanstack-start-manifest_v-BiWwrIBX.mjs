//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BiWwrIBX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-O0lHWIb8.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-epos2Zbt.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-C7Enk3_k.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-O0lHWIb8.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BfBwg1HT.js",
			"/assets/log-out-fRS2QY9C.js",
			"/assets/testers.functions-B2vQ9rhj.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CxPyTFyN.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CwIwYXOY.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-CrmclSTJ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/dist-DeTtdXdl.js",
			"/assets/dialog-DysliNV8.js",
			"/assets/queries-BZNXGAxU.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/label-ClETWQa5.js",
			"/assets/textarea-BE0RxzMp.js",
			"/assets/shoebox--77eer8G.js",
			"/assets/company-El5Coijm.js",
			"/assets/reports-F-N8jZb5.js",
			"/assets/access-P152FyLC.js",
			"/assets/LicenseCard-BVJl62U4.js",
			"/assets/Logo-BBx0JKqZ.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-ByMF3Eo0.js",
			"/assets/log-out-fRS2QY9C.js",
			"/assets/admin.functions-BsrsURsh.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-BBx0JKqZ.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CyhqZ1Rg.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/label-ClETWQa5.js",
			"/assets/Logo-BBx0JKqZ.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-B2sEzuSU.js",
			"/assets/testers.functions-B2vQ9rhj.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/buy.functions-CSpzcnIF.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CsLFhRU_.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/downloads.functions-BUdVp25s.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-p7sZjXh2.js",
			"/assets/testers.functions-B2vQ9rhj.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/textarea-BE0RxzMp.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-B0NeHSym.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/label-ClETWQa5.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-XRZnF6Mn.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/label-ClETWQa5.js",
			"/assets/Logo-BBx0JKqZ.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-DRF95fLI.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/upgrade.functions-zIEy_TZm.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-DsYkEG9E.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/label-ClETWQa5.js",
			"/assets/Logo-BBx0JKqZ.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BloIcyPo.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Di3IX3ky.js", "/assets/StockDocList-dE0jn5up.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BlWX4Cpo.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/ai-Cy-lGQPi.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-CvGvercN.js",
			"/assets/BankConnections-DlCQFVal.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-C83ZJjWY.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DjKcLX5g.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DlCQFVal.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/ai-Cy-lGQPi.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-4bQDJ2l4.js",
			"/assets/TxnEditor-B_5DkOBL.js",
			"/assets/feedWaiting-DmF1LRg7.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DjiW5lmA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-C0pIspfu.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/personal-B8gyS-IQ.js",
			"/assets/members-CansJhFt.js",
			"/assets/WhoPicker-CTtDvI3n.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BkRVGjuy.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CcCNq0dr.js", "/assets/AccountRegister-DrwxNKyZ.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Bu2Iy9F_.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-MVEey4jo.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/money-BdSIY61T.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BuRFK3mr.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Cy-lGQPi.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-Cy3cAEzE.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-DnlEehm3.js", "/assets/StockDocList-dE0jn5up.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-BpcLNS3D.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BP84ksj4.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-CansJhFt.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-0FzV7zbG.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DOWQyS2D.js", "/assets/PartyList-DpKK96z-.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Co2GFZm_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DT23Cd4q.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/storage.functions-Dv6A38Ra.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-C8kNPB_c.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-Lt3ER8Bt.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-zqOozY2z.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-D-khdvl3.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BfrK5pGy.js", "/assets/ChangeHistory-DY2md2oC.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CLZyt-zP.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/members-CansJhFt.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-D5DHmaDF.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/personal-B8gyS-IQ.js",
			"/assets/members-CansJhFt.js",
			"/assets/WhoPicker-CTtDvI3n.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-XlQcGVcj.js", "/assets/SalesList-BvMdv-mt.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BxBPh2Pf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-C9aU9JMv.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-Q0uyblZw.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-gBKo5Itb.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/loans-4bQDJ2l4.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-IIRf1lQl.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Bf2bwOz2.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Do4WKPrn.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/personal-B8gyS-IQ.js",
			"/assets/members-CansJhFt.js",
			"/assets/WhoPicker-CTtDvI3n.js",
			"/assets/reminders-C33Wvbws.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-CVibwAu8.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BYuWmnHa.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/personal-B8gyS-IQ.js",
			"/assets/members-CansJhFt.js",
			"/assets/WhoPicker-CTtDvI3n.js",
			"/assets/generateCategoricalChart-CO0iekS0.js",
			"/assets/Area-BZdUDU4C.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-B5XBHrjq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/generateCategoricalChart-CO0iekS0.js",
			"/assets/PlCharts-zqOozY2z.js",
			"/assets/BarChart-BocD845a.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DDyFC-KY.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-t81W5vXW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-JvmrZg-A.js",
			"/assets/createServerFn-BbzKVwjy.js",
			"/assets/auth-middleware-uIB0GS6V.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/storage.functions-Dv6A38Ra.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BXihADyT.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DjfNtXCd.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/checkbox-D8-FtBm9.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CK-PPXZ_.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-Bvn6AoOZ.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-Duo2URLd.js", "/assets/SalesList-BvMdv-mt.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-C4ImfoKO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/ai-Cy-lGQPi.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Dv6A38Ra.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DnL5qMhX.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/money-BdSIY61T.js",
			"/assets/badge-DBUTpt1P.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-B3MswluA.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-Blj5TO-j.js", "/assets/AccountRegister-DrwxNKyZ.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DsG5iIIh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/MoneyAccountPick-CTepQ92K.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-D3Nqj-b8.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-C5ZXBNT-.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/RepeatInvoice-BfWl2iCm.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Bq6aJZxj.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-CO0iekS0.js",
			"/assets/BarChart-BocD845a.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CBH-8NL0.js", "/assets/SalesList-BvMdv-mt.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-j5q7d_pC.js", "/assets/SalesList-BvMdv-mt.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-lGUUoFms.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-B4L_eJdH.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/serials-CPap6YaU.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-D_20I_ps.js",
			"/assets/createServerFn-BbzKVwjy.js",
			"/assets/auth-middleware-uIB0GS6V.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-B0XgIbo_.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CW1ntt4B.js",
			"/assets/switch-Bf2bwOz2.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-0FzV7zbG.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-D4E5dJN8.js",
			"/assets/footers-WJfM0Vhv.js",
			"/assets/PrintFrame-BO8QkkwC.js",
			"/assets/checkbox-D8-FtBm9.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-CXLfUx72.js",
			"/assets/FeaturePicker-CA6QLcBY.js",
			"/assets/support-Br0i_9Xl.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BLkDn5k2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/FeaturePicker-CA6QLcBY.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-C3L9Kk6M.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-37uddf2_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/photos-D4E5dJN8.js",
			"/assets/stockmove-3G6Bvr_X.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-vI8jPtiX.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/loans-4bQDJ2l4.js",
			"/assets/feedWaiting-DmF1LRg7.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Dv6A38Ra.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-BWx_zozX.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/PrintFrame-BO8QkkwC.js",
			"/assets/DocPdf-Cg8vNrhC.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-CQ5DEDQ4.js",
			"/assets/createServerFn-BbzKVwjy.js",
			"/assets/auth-middleware-uIB0GS6V.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/MoneyAccountPick-CTepQ92K.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Br0i_9Xl.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-Bd_wADZV.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/StockDialogs-37uddf2_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/stockmove-3G6Bvr_X.js",
			"/assets/checkbox-D8-FtBm9.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-CVECV23E.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/members-CansJhFt.js",
			"/assets/WhoPicker-CTtDvI3n.js",
			"/assets/reminders-C33Wvbws.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-QkesGDpy.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/tickets.functions-DeZctR49.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DUzolvnU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Br0i_9Xl.js",
			"/assets/support.functions-BXzNRvDt.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BYr3QpLt.js", "/assets/StockDocList-dE0jn5up.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-VZRNdEyg.js", "/assets/PartyList-DpKK96z-.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-bUTdO2NB.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/tickets.functions-DeZctR49.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-B7820kYQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/workorders-DgKQaBDZ.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BgspAFFA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-D5Hgmy4T.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/AdminAccount-B5bH8ARB.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-D9FgLZeQ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/downloads.functions-BUdVp25s.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B361xHb2.js",
			"/assets/createServerFn-BbzKVwjy.js",
			"/assets/auth-middleware-uIB0GS6V.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-33po7mAV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-5jwX6kQo.js",
			"/assets/testers.functions-B2vQ9rhj.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-B4sX8Rk6.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-DouWlC-H.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CSpzcnIF.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-uOhMkJNM.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/textarea-BE0RxzMp.js",
			"/assets/support.functions-BXzNRvDt.js",
			"/assets/HelpParts-BH_NqTju.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BsxvgXLW.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DOGi0FCq.js",
			"/assets/manual._slug-IH9TGeOo.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CfK1YFEi.js",
			"/assets/createServerFn-BbzKVwjy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-vmjfA4H2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-zIEy_TZm.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DPGa4On8.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-Cy-lGQPi.js",
			"/assets/personal-B8gyS-IQ.js",
			"/assets/reminders-C33Wvbws.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-JLbrxi3s.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/AdminAccount-B5bH8ARB.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-C6zJ8RKS.js", "/assets/ManualFrame-DOGi0FCq.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-3mpucQVw.js", "/assets/AccountRegister-DrwxNKyZ.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-B3FSl5AN.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/OriginalLink-9mbMKDXO.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/realestate-tmXOm_RP.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CMUS_Oqz.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BH99kPFC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/realestate-tmXOm_RP.js",
			"/assets/money-BdSIY61T.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BeQw8tRH.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/SideList-GiYX2-xQ.js",
			"/assets/PartyHistory-DXWv5VC1.js",
			"/assets/tabs-BLCnW1Zk.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-GVDMB-i2.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-B0XgIbo_.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DY2md2oC.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/SideList-GiYX2-xQ.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BS6l6Yel.js",
			"/assets/MoneyAccountPick-CTepQ92K.js",
			"/assets/footers-WJfM0Vhv.js",
			"/assets/PrintFrame-BO8QkkwC.js",
			"/assets/serials-CPap6YaU.js",
			"/assets/SerialsBox-C_kaRMvB.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-mPTIWLn3.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-37uddf2_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DY2md2oC.js",
			"/assets/switch-Bf2bwOz2.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/badge-DBUTpt1P.js",
			"/assets/SideList-GiYX2-xQ.js",
			"/assets/tabs-BLCnW1Zk.js",
			"/assets/photos-D4E5dJN8.js",
			"/assets/stockmove-3G6Bvr_X.js",
			"/assets/serials-CPap6YaU.js",
			"/assets/SerialsBox-C_kaRMvB.js",
			"/assets/workorders-DgKQaBDZ.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BwvRL-EO.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-B0XgIbo_.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DY2md2oC.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/SideList-GiYX2-xQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BS6l6Yel.js",
			"/assets/MoneyAccountPick-CTepQ92K.js",
			"/assets/footers-WJfM0Vhv.js",
			"/assets/PrintFrame-BO8QkkwC.js",
			"/assets/checkbox-D8-FtBm9.js",
			"/assets/serials-CPap6YaU.js",
			"/assets/workorders-DgKQaBDZ.js",
			"/assets/RepeatInvoice-BfWl2iCm.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DeZctR49.js",
			"/assets/users.functions-CXLfUx72.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-b938dLLd.js",
			"/assets/select-CY0aeV-J.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/SideList-GiYX2-xQ.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BkPRaUcH.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/quickadd-CfbigXSo.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Br0i_9Xl.js",
			"/assets/support.functions-BXzNRvDt.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-C-NslSSE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BMZDXlS6.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/SideList-GiYX2-xQ.js",
			"/assets/PartyHistory-DXWv5VC1.js",
			"/assets/tabs-BLCnW1Zk.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CkPo1gJ4.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/sales-Cy3cAEzE.js",
			"/assets/footers-WJfM0Vhv.js",
			"/assets/tickets.functions-DeZctR49.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CvAQUqZ-.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/input-CEGXMF1b.js",
			"/assets/skeleton-DQsxVGD-.js",
			"/assets/AdminAccount-B5bH8ARB.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-DAqGD1li.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-HkogQQ_Y.js",
			"/assets/textarea-BE0RxzMp.js",
			"/assets/support-Br0i_9Xl.js",
			"/assets/support.functions-BXzNRvDt.js",
			"/assets/HelpParts-BH_NqTju.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-D5_3dUjF.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DQsxVGD-.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
