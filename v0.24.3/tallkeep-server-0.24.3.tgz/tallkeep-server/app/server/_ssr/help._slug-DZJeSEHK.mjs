import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { en as CircleCheck, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Route } from "./help._slug-DbRPEVbe.mjs";
import { i as openTicket, t as getSupportPage } from "./support.functions-DBoabR4U.mjs";
import { n as HelpFrame, r as toUpload, t as FilesPicker } from "./HelpParts-B_4ECnnO.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/help._slug-DZJeSEHK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** A business's support page: customers open a ticket here, no sign-in. */
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: label
		}), children]
	});
}
function SupportPage() {
	const { slug } = Route.useParams();
	const { data: page, isLoading } = useQuery({
		queryKey: ["support-page", slug],
		queryFn: () => getSupportPage({ data: { slug } })
	});
	const [f, setF] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		company: "",
		topic: "",
		subject: "",
		message: "",
		address: "",
		website: ""
	});
	const [files, setFiles] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(null);
	const set = (k) => (e) => setF({
		...f,
		[k]: e.target.value
	});
	async function send(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const r = await openTicket({ data: {
				slug,
				origin: window.location.origin,
				...f,
				files: await toUpload(files)
			} });
			setDone(r);
			window.scrollTo(0, 0);
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpFrame, {
		title: "Support",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin" })
	});
	if (!page) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpFrame, {
		title: "Support",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-white p-6 dark:bg-slate-900",
			children: "This support page isn't open. Check the address, or contact the business directly."
		})
	});
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpFrame, {
		title: `${page.name} support`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 rounded-2xl border bg-white p-6 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 text-lg font-semibold text-emerald-700 dark:text-emerald-400",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-6 w-6" }),
						" We got your request",
						done.number ? ` (${done.number})` : "",
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "We'll get back to you soon. Keep the link below to see our replies and add more. We also emailed it to you."
				}),
				done.key && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/help/t/$key",
						params: { key: done.key },
						children: "See your ticket"
					})
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HelpFrame, {
		title: `${page.name} support`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-slate-600 dark:text-slate-400",
			children: page.intro || "Tell us what you need and we'll get back to you."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: send,
			className: "grid gap-4 rounded-2xl border bg-white p-5 sm:grid-cols-2 sm:p-6 dark:bg-slate-900",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Your name *",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: f.name,
						onChange: set("name"),
						autoComplete: "name"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email *",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						type: "email",
						value: f.email,
						onChange: set("email"),
						autoComplete: "email"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Phone",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.phone,
						onChange: set("phone"),
						autoComplete: "tel"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Company",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.company,
						onChange: set("company"),
						autoComplete: "organization"
					})
				}),
				page.topics.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "What is it about?",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: f.topic,
						onChange: set("topic"),
						className: "h-9 w-full rounded-md border bg-transparent px-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Choose…"
						}), page.topics.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: t,
							children: t
						}, t))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Where (address), if it's on site",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.address,
						onChange: set("address"),
						autoComplete: "street-address"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Subject *",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: f.subject,
							onChange: set("subject"),
							maxLength: 200
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What's going on? *",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							required: true,
							rows: 6,
							value: f.message,
							onChange: set("message")
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					tabIndex: -1,
					autoComplete: "off",
					value: f.website,
					onChange: set("website"),
					className: "hidden",
					"aria-hidden": "true",
					name: "website"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPicker, {
						files,
						onChange: setFiles
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						size: "lg",
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Sending…" : "Send my request"]
					})
				})
			]
		})]
	});
}
//#endregion
export { SupportPage as component };
