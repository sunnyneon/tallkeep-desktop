import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bills_._id-RzHUFPL5.js
var $$splitComponentImporter = () => import("./bills_._id-CtNDacsT.mjs");
var Route = createFileRoute("/_authenticated/bills_/$id")({
	validateSearch: (s) => s["paid"] ? { paid: Number(s["paid"]) || 1 } : {},
	head: () => ({ meta: [{ title: "Bill · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
