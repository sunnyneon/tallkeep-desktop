import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/products_._id-Duf8RBrV.js
var $$splitComponentImporter = () => import("./products_._id-BqdyVlny.mjs");
var Route = createFileRoute("/_authenticated/products_/$id")({
	head: () => ({ meta: [{ title: "Product · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
