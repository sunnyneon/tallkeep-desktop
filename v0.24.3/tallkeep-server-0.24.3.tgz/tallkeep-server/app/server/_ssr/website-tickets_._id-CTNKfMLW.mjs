import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/website-tickets_._id-CTNKfMLW.js
var $$splitComponentImporter = () => import("./website-tickets_._id-Cby91NTi.mjs");
var Route = createFileRoute("/_authenticated/website-tickets_/$id")({
	head: () => ({ meta: [{ title: "Ticket · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
