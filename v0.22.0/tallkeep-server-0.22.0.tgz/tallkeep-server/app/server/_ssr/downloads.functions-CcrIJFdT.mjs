import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-m1XYXZz0.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/downloads.functions-CcrIJFdT.js
/**
* The download page: a short form (name, email), then the download starts and we email the
* link and setup steps. The owner panel lists downloads, and how many installs run Tallkeep.
*/
/** Downloads per internet address in the last hour (kept in this server's memory). */
var clean = (v, n) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, n);
var recordDownload = createServerFn({ method: "POST" }).inputValidator((d) => {
	const name = clean(d.name, 120);
	const email = clean(d.email, 200).toLowerCase();
	if (!name) throw new Error("Type your name.");
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Type a valid email.");
	if (![
		"windows",
		"linux",
		"mac"
	].includes(d.platform)) throw new Error("Pick a version.");
	return {
		name,
		email,
		business: clean(d.business, 80) || null,
		platform: d.platform,
		source: clean(d.source, 200) || null
	};
}).handler(createSsrRpc("019a423964e1dad1bd104e3a9a51f9a9b938bc4dbfc1395567fb46023a4c414a"));
var listDownloads = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("e48180cae480f45ad9db96730afc03d85cbfe3d41e37c5b8d5887cd9d838dd38"));
//#endregion
export { recordDownload as n, listDownloads as t };
