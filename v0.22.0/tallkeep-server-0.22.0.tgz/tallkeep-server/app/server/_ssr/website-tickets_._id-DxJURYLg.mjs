import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ht as ExternalLink, I as Receipt, Nn as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { f as totals, l as lineTotal, u as nextNumber } from "./sales-CAB3s83f.mjs";
import { a as defaultsFor, s as useFooters } from "./footers-BNGmbiMB.mjs";
import { n as BILLING_STYLE, t as BILLING_LABEL } from "./website-tickets-CY7FSc8t.mjs";
import { t as Route } from "./website-tickets_._id-DeP8nVi1.mjs";
import { t as getTicket } from "./tickets.functions-9mc84jEO.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/website-tickets_._id-DxJURYLg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The customer's PO number, saved in the ticket notes as "[PO received: 12345 — date]". */
function ticketPo(notes) {
	return (notes ?? "").match(/\[PO received:\s*([^\]—]+?)\s*—/i)?.[1]?.trim() || null;
}
var money = (cents) => Math.round(Number(cents ?? 0)) / 100;
/** The office invoice already made for this ticket, if any. */
async function invoiceForTicket(number) {
	const { data } = await db.from("sales_orders").select("id, number, status, total, balance").eq("custom->>Ticket", number).neq("status", "cancelled").limit(1);
	return data?.[0] ?? null;
}
/**
* Make the final invoice for a finished ticket: customer, quoted work, add-on charges,
* parts from the technician's report, and the card payments already made on the website.
*/
async function invoiceFromTicket(t, footers) {
	const existing = await invoiceForTicket(t.number);
	if (existing) return existing.id;
	let cust = null;
	if (t.email) {
		const { data } = await db.from("customers").select("id,name,billing_address,address,payment_terms_id").ilike("email", t.email.trim()).limit(1);
		cust = data?.[0] ?? null;
	}
	const custName = (t.company || t.name || "Customer").trim();
	if (!cust) {
		const { data } = await db.from("customers").select("id,name,billing_address,address,payment_terms_id").ilike("name", custName).limit(1);
		cust = data?.[0] ?? null;
	}
	if (!cust) {
		const { data, error } = await db.from("customers").insert({
			name: custName,
			contact_name: t.name,
			email: t.email,
			phone: t.phone,
			address: t.job_site_address,
			billing_address: t.job_site_address,
			shipping_address: t.job_site_address,
			remarks: `Added from website ticket ${t.number}`
		}).select("id,name,billing_address,address,payment_terms_id").single();
		if (error) throw new Error(error.message);
		cust = data;
	}
	const lines = [];
	const add = (description, qty, amount) => lines.push({
		description,
		qty,
		unit_price: qty ? Math.round(amount / qty * 100) / 100 : amount,
		discount: 0,
		discount_is_percent: true,
		taxable: false
	});
	if (t.quoted_amount_cents) {
		const hrs = Number(t.quoted_hours) || 0;
		add(`Service ${t.number}: ${t.subject ?? t.issue_type ?? "support"}${hrs ? ` (${hrs} hr)` : ""}`, hrs || 1, money(t.quoted_amount_cents));
	}
	for (const c of t.charges.filter((x) => x.status !== "cancelled")) {
		const hrs = Number(c.hours) || 0;
		add(`Additional work${c.scope ? `: ${c.scope}` : ""}${hrs ? ` (${hrs} hr)` : ""}`, hrs || 1, money(c.amount_cents));
	}
	const parts = t.reports.map((r) => r.parts_used?.trim()).filter(Boolean).join("; ");
	if (parts) add(`Parts used: ${parts}`, 1, 0);
	if (!lines.length) add(`Service ${t.number}: ${t.subject ?? "support"}`, 1, 0);
	const work = t.reports.map((r) => r.work_performed?.trim()).filter(Boolean).join("\n");
	const sums = totals(lines, 0, 0);
	const now = /* @__PURE__ */ new Date();
	let days = 0;
	if (cust.payment_terms_id) {
		const { data: pt } = await db.from("payment_terms").select("days_due").eq("id", cust.payment_terms_id).maybeSingle();
		days = Number(pt?.days_due ?? 0);
	}
	const number = await nextNumber("sales_order");
	const { data: u } = await db.auth.getUser();
	const { data: so, error } = await db.from("sales_orders").insert({
		number,
		status: "invoiced",
		customer_id: cust.id,
		customer_name: cust.name,
		contact_name: t.name,
		phone: t.phone,
		email: t.email,
		billing_address: cust.billing_address || cust.address || t.job_site_address,
		shipping_address: t.job_site_address,
		payment_terms_id: cust.payment_terms_id,
		order_date: now.toISOString(),
		invoice_date: now.toISOString(),
		due_date: new Date(now.getTime() + days * 864e5).toISOString(),
		tax_rate: 0,
		subtotal: sums.subtotal,
		tax: sums.tax,
		total: sums.total,
		balance: sums.total,
		remarks: [
			`Support ticket ${t.number}`,
			t.resolution,
			work
		].filter(Boolean).join("\n"),
		po_number: ticketPo(t.payment_notes),
		custom: { Ticket: t.number },
		created_by: u.user?.id,
		...defaultsFor(footers, "invoice")
	}).select("id").single();
	if (error) throw new Error(error.message);
	const id = so.id;
	const { error: e2 } = await db.from("sales_order_lines").insert(lines.map((l, i) => ({
		...l,
		sales_order_id: id,
		line_no: i + 1,
		line_total: lineTotal(l)
	})));
	if (e2) throw new Error(e2.message);
	const pays = [];
	if (t.paid_at && t.quoted_amount_cents) pays.push({
		amount: money(t.quoted_amount_cents),
		paid_on: t.paid_at,
		remarks: "Quote paid online"
	});
	for (const c of t.charges.filter((x) => x.status === "paid")) pays.push({
		amount: money(c.amount_cents),
		paid_on: c.paid_at ?? now.toISOString(),
		remarks: "Add-on paid online"
	});
	if (pays.length) {
		const { error: e3 } = await db.from("payments").insert(pays.map((p) => ({
			...p,
			sales_order_id: id,
			method: "Card (website)",
			reference: t.number,
			created_by: u.user?.id
		})));
		if (e3) throw new Error(e3.message);
	}
	return id;
}
function TicketPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { data: footers } = useFooters();
	const { data: t, isLoading, error } = useQuery({
		queryKey: ["ticket", id],
		queryFn: () => getTicket({ data: { id: Number(id) } })
	});
	const { data: inv } = useQuery({
		queryKey: ["ticket-invoice", t?.number],
		enabled: !!t,
		queryFn: () => invoiceForTicket(t.number)
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function make() {
		if (!t) return;
		setBusy(true);
		try {
			const sid = await invoiceFromTicket(t, footers);
			toast.success("Final invoice made. Check it, then press Email customer.");
			qc.invalidateQueries({ queryKey: ["sales"] });
			navigate({
				to: "/sales/$id",
				params: { id: sid }
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) });
	if (error || !t) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-destructive",
		children: error?.message ?? "Ticket not found."
	}) });
	const paidOnline = (t.paid_at ? Number(t.quoted_amount_cents ?? 0) : 0) + t.charges.filter((c) => c.status === "paid").reduce((s, c) => s + Number(c.amount_cents), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/website-tickets",
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " All tickets"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "border-l-4 border-[var(--section)] pl-3 font-display text-3xl font-bold",
						children: t.number
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `rounded-full px-2.5 py-1 text-xs font-medium ${BILLING_STYLE[t.billing_status ?? ""] ?? "bg-muted"}`,
						children: BILLING_LABEL[t.billing_status ?? ""] ?? t.billing_status
					}),
					t.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted-foreground",
						children: ["Job done ", fmtDate(t.completed_at)]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "https://sunriseled.com/admin/tickets",
						target: "_blank",
						rel: "noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" }), " Open on the website"]
					})
				}), inv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sales/$id",
						params: { id: inv.id },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-4 w-4" }),
							" Open invoice ",
							inv.number
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void make(),
					disabled: busy,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-4 w-4" }),
						" ",
						busy ? "Making invoice…" : "Make final invoice"
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-2xl border bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase text-muted-foreground",
						children: "Customer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: t.company || t.name
					}),
					t.company && t.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.name }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: [t.email, t.phone].filter(Boolean).join(" · ") }),
					t.job_site_address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-line text-muted-foreground",
						children: t.job_site_address
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-2xl border bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase text-muted-foreground",
						children: "Money"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Quoted: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: t.quoted_amount_cents ? fmtMoney(t.quoted_amount_cents / 100) : "—" }),
						t.quoted_hours ? ` (${t.quoted_hours} hr)` : ""
					] }),
					t.charges.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Add-on: ",
						fmtMoney(c.amount_cents / 100),
						" ",
						c.scope ? `— ${c.scope}` : "",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								"(",
								c.status,
								")"
							]
						})
					] }, c.id)),
					ticketPo(t.payment_notes) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Customer PO: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: ticketPo(t.payment_notes) })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Paid online: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(paidOnline / 100) })] })
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase text-muted-foreground",
					children: "The job"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: t.subject
				}),
				t.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line text-muted-foreground",
					children: t.message
				}),
				t.reports.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-muted/40 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Technician report",
								r.submitted_at ? `, ${fmtDate(r.submitted_at)}` : "",
								r.hours_on_site ? ` · ${r.hours_on_site} hr on site` : ""
							]
						}),
						r.work_performed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-line",
							children: r.work_performed
						}),
						r.parts_used && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "whitespace-pre-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Parts:" }),
								" ",
								r.parts_used
							]
						})
					]
				}, i)),
				t.resolution && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "whitespace-pre-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Resolution:" }),
						" ",
						t.resolution
					]
				}),
				t.payment_notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line text-xs text-muted-foreground",
					children: t.payment_notes
				})
			]
		})
	] });
}
//#endregion
export { TicketPage as component };
