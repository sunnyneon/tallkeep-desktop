import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { A as ScanBarcode, Pt as FileUp, cn as Camera, k as ScanLine, wn as Banknote } from "../_libs/lucide-react.mjs";
import { c as queueShoebox } from "./shoebox-CW5ooBDi.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as queueScans } from "./scanQueue-C9-xAAQ0.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/BarcodeScanner-mWDVQ6jq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Start the camera and call onCode once a barcode / QR code is read. */
async function startScan(video, onCode) {
	const W = window;
	const formats = W.BarcodeDetector ? await W.BarcodeDetector.getSupportedFormats?.().catch(() => []) : [];
	if (W.BarcodeDetector && (formats?.length ?? 1) > 0) {
		const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
		video.srcObject = stream;
		await video.play();
		const det = new W.BarcodeDetector();
		let live = true;
		const tick = async () => {
			if (!live) return;
			try {
				const r = await det.detect(video);
				if (r[0]?.rawValue) onCode(r[0].rawValue);
			} catch {}
			requestAnimationFrame(tick);
		};
		tick();
		return () => {
			live = false;
			stream.getTracks().forEach((t) => t.stop());
		};
	}
	const { BrowserMultiFormatReader } = await import("../_libs/@zxing/browser+[...].mjs").then((n) => n.t);
	const controls = await new BrowserMultiFormatReader().decodeFromConstraints({ video: { facingMode: "environment" } }, video, (result) => {
		if (result) onCode(result.getText());
	});
	return () => controls.stop();
}
/** Scan button: snap a receipt or bill (AI reads it on the Receipts page), or scan a product barcode. */
function ScanButton({ compact }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	const send = (list, kind = "shoebox") => {
		const files = [...list ?? []];
		if (!files.length) return;
		setOpen(null);
		if (kind === "check") {
			queueScans(files, "check");
			navigate({ to: "/checks-received" });
		} else {
			queueShoebox(files);
			navigate({ to: "/shoebox" });
		}
	};
	const option = "flex w-full cursor-pointer items-center gap-4 rounded-xl border p-4 text-left hover:bg-muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: compact ? "icon" : "sm",
			variant: "secondary",
			onClick: () => setOpen("menu"),
			"aria-label": "Take a photo of a receipt, bill or check, or scan a barcode",
			title: "Take a photo of a receipt, bill or check, or scan a barcode",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanLine, { className: "h-4 w-4" }), !compact && " Scan"]
		}),
		open === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: true,
			onOpenChange: (v) => !v && setOpen(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Photos and files go to the Shoebox: Tallkeep works out if it's a receipt, a bill, a statement or a check, and puts it where it belongs." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Take a photo for the Shoebox"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "A receipt, bill or statement. Lay it flat in good light, fill the screen with it."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									className: "hidden",
									onChange: (e) => send(e.target.files)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Take a photo of a check you received"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "AI reads who paid and how much, and applies it to their invoices."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									capture: "environment",
									multiple: true,
									className: "hidden",
									onChange: (e) => send(e.target.files, "check")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: option,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "h-6 w-6 shrink-0 text-primary" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: "Send files to the Shoebox"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: "Photos, PDFs or bank files from your phone or computer; several at once is fine."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*,.pdf,application/pdf,.csv,.ofx,.qfx,.qbo",
									multiple: true,
									className: "hidden",
									onChange: (e) => send(e.target.files)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: option,
							onClick: () => setOpen("barcode"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanBarcode, { className: "h-6 w-6 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold",
								children: "Scan a product barcode"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-muted-foreground",
								children: "Opens that product."
							})] })]
						})
					]
				})]
			})
		}),
		open === "barcode" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanDialog, { onClose: () => setOpen(null) })
	] });
}
function ScanDialog({ onClose }) {
	const [video, setVideo] = (0, import_react.useState)(null);
	const navigate = useNavigate();
	const [error, setError] = (0, import_react.useState)("");
	const [typed, setTyped] = (0, import_react.useState)("");
	const done = (0, import_react.useRef)(false);
	async function lookup(code) {
		const c = code.trim();
		if (!c || done.current) return;
		done.current = true;
		if (navigator.vibrate) navigator.vibrate(80);
		const { data } = await db.from("products").select("id,name").or(`barcode.eq."${c.replace(/"/g, "")}",name.eq."${c.replace(/"/g, "")}"`).limit(2);
		onClose();
		const hit = data?.length === 1 ? data[0] : void 0;
		if (hit) navigate({
			to: "/products/$id",
			params: { id: hit.id }
		});
		else {
			toast(data?.length ? "More than one product matches." : `No product has barcode ${c} yet. Open a product and type it in its Barcode box.`);
			navigate({
				to: "/products",
				search: { q: c }
			});
		}
	}
	(0, import_react.useEffect)(() => {
		if (!video) return;
		let stop;
		let gone = false;
		startScan(video, (c) => void lookup(c)).then((s) => {
			if (gone) s();
			else stop = s;
		}).catch(() => setError("Can't open the camera. Allow the camera for this site in the browser's settings, or type the code below."));
		return () => {
			gone = true;
			stop?.();
		};
	}, [video]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Scan a barcode" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Point the camera at the product's barcode or QR code and hold still. It opens the product by itself." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-xl bg-black",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						ref: setVideo,
						className: "aspect-[4/3] w-full object-cover",
						muted: true,
						playsInline: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-8 top-1/2 h-0.5 -translate-y-1/2 bg-red-500/80" })]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex gap-2",
					onSubmit: (e) => {
						e.preventDefault();
						lookup(typed);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "…or type / scan with a USB scanner",
						value: typed,
						onChange: (e) => setTyped(e.target.value),
						autoFocus: !!error
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Find"
					})]
				})
			]
		})
	});
}
//#endregion
export { startScan as n, ScanButton as t };
