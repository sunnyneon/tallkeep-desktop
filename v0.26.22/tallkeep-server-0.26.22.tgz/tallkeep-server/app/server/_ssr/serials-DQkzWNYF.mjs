import { n as db } from "./db-BWTfJWfB.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/serials-DQkzWNYF.js
/** Serial numbers: one per unit of a product that tracks them (step 077). */
var STATUS_LABEL = {
	in_stock: "In stock",
	out: "Not in stock",
	sold: "Sold",
	returned: "Returned",
	scrapped: "Scrapped"
};
/** The serials typed or scanned into a box: one per line (or separated by commas), no doubles. */
function parseSerials(text) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const raw of text.split(/[\n,;\t]+/)) {
		const s = raw.trim();
		if (s && !seen.has(s.toLowerCase())) {
			seen.add(s.toLowerCase());
			out.push(s);
		}
	}
	return out;
}
/** n new serials made up by Tallkeep (the company's prefix and running number). */
async function makeSerials(n) {
	const { data, error } = await db.rpc("make_serials", { _n: n });
	if (error) throw new Error(error.message);
	return data ?? [];
}
/** Which of these products track serial numbers. */
async function trackedOf(productIds) {
	const ids = [...new Set(productIds.filter(Boolean))];
	if (!ids.length) return /* @__PURE__ */ new Set();
	const { data } = await db.from("products").select("id,track_serials").in("id", ids);
	return new Set((data ?? []).filter((p) => p.track_serials).map((p) => p.id));
}
/** Serials already saved for this product, of those given (to stop doubles before saving). */
async function existing(productId, serials) {
	if (!serials.length) return [];
	const { data } = await db.from("serial_numbers").select("serial").eq("product_id", productId).in("serial", serials);
	return (data ?? []).map((r) => r.serial);
}
/** Put serials into stock (a new unit came in). Returns the new rows' ids. */
async function addSerials(productId, serials, from = {}) {
	if (!serials.length) return [];
	const twice = await existing(productId, serials);
	if (twice.length) throw new Error(`Already saved for this product: ${twice.slice(0, 5).join(", ")}${twice.length > 5 ? "…" : ""}`);
	const { data, error } = await db.from("serial_numbers").insert(serials.map((serial) => ({
		product_id: productId,
		serial,
		location_id: from.locationId ?? null,
		status: "in_stock",
		received_from: from.receivedFrom ?? null,
		received_doc: from.doc ?? null,
		purchase_order_id: from.poId ?? null,
		notes: from.notes ?? null
	}))).select("id");
	if (error) throw new Error(error.message);
	return (data ?? []).map((r) => r.id);
}
/** Mark serials sold on an order line, and write the line's printed list. */
async function sellSerials(orderId, lineId, ids, batch) {
	if (!ids.length) return;
	const { error } = await db.from("serial_numbers").update({
		status: "sold",
		sales_order_id: orderId,
		sales_order_line_id: lineId,
		sold_at: (/* @__PURE__ */ new Date()).toISOString(),
		sold_batch_id: batch ?? null
	}).in("id", ids).eq("status", "in_stock");
	if (error) throw new Error(error.message);
	await fixOrder(orderId);
}
/** After an undo: serials beyond what's still out go back into stock (and the lists follow). */
async function fixOrder(orderId) {
	const { error } = await db.rpc("fix_order_serials", { _order: orderId });
	if (error && !/could not find the function/i.test(error.message)) throw new Error(error.message);
}
/** Serials that came in on a receipt: tie them to it, so undoing that receipt takes them off. */
async function tagReceived(ids, batch) {
	if (ids.length && batch) await db.from("serial_numbers").update({ batch_id: batch }).in("id", ids);
}
/** Undo of one receipt or fulfilment: its serials follow. */
async function undoBatch(batch) {
	const { error } = await db.rpc("undo_batch_serials", { _batch: batch });
	if (error && !/could not find the function/i.test(error.message)) throw new Error(error.message);
}
//#endregion
export { parseSerials as a, trackedOf as c, makeSerials as i, undoBatch as l, addSerials as n, sellSerials as o, fixOrder as r, tagReceived as s, STATUS_LABEL as t };
