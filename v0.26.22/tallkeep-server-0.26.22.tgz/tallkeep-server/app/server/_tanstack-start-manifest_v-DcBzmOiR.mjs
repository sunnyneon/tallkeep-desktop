//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DcBzmOiR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-Dfj5zbSy.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-FjcWVYIc.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CWKa52kG.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dfj5zbSy.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BQ3qnFIp.js",
			"/assets/log-out-C-yFe0hs.js",
			"/assets/testers.functions-C4Rsln7Q.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DD1dBa6S.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DFI0Uoe_.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-BEJSlvlX.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/dist-DDi8ODPV.js",
			"/assets/dialog-BLfWDGOh.js",
			"/assets/queries-CTX1YXNg.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/label-Ko09GwXh.js",
			"/assets/textarea-CF0hg9eD.js",
			"/assets/shoebox-oyrSuq-B.js",
			"/assets/company-D64c8cj1.js",
			"/assets/reports-D0klh_9r.js",
			"/assets/access-CPQNrKop.js",
			"/assets/LicenseCard-DSkGHYwq.js",
			"/assets/Logo-CFlKsImd.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Bq-ltksx.js",
			"/assets/log-out-C-yFe0hs.js",
			"/assets/admin.functions-CrKgLTYZ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CFlKsImd.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-D2UMs6Ip.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/label-Ko09GwXh.js",
			"/assets/Logo-CFlKsImd.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BlmcNzQn.js",
			"/assets/testers.functions-C4Rsln7Q.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/coupons.functions-B2KsaPty.js",
			"/assets/buy.functions-JwJTXfl4.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-pgKSHUtZ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/downloads.functions-CTOZn4Qc.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-esYLxp9O.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/label-Ko09GwXh.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-oikQgaPB.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/label-Ko09GwXh.js",
			"/assets/Logo-CFlKsImd.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-Br95jwYk.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/upgrade.functions-Q_8gCyTD.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-INkvP7cv.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/label-Ko09GwXh.js",
			"/assets/Logo-CFlKsImd.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DSC-HYyx.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-SehsBESf.js", "/assets/StockDocList-v_rrKFyy.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CfJP4kHg.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/ai-SKa6APTT.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-l9FYnp5L.js",
			"/assets/BankConnections-DHHNH1DB.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CqN6jNOm.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-Bh2efjXE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DHHNH1DB.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/ai-SKa6APTT.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BrhoA2RO.js",
			"/assets/TxnEditor-BnnPQZPB.js",
			"/assets/feedWaiting-BIChgw8x.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-T6r8ChVD.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-K1HwKamP.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/personal-BdmVWea3.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/WhoPicker-HwLfU4nZ.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BpjTJo7B.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-y0Hw8vXz.js", "/assets/AccountRegister-9Y-VhaFn.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BA5oD92B.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BD9X7GUI.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/money-C98xcaJf.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CWEOLb7j.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-SKa6APTT.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-CAstpMaz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CQ0HFTiq.js", "/assets/StockDocList-v_rrKFyy.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DKFIwva2.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-B31DbUUp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BwyBy2qt.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D7my2kUd.js", "/assets/PartyList-B41wI-Ik.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BsFyUQ9X.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CjIZ_J3n.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/storage.functions-SEj9eNhh.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-B2f8ehOD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-pfFfaj89.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-C59ZvEUq.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-0UsWKvMn.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-ChLgIQOz.js", "/assets/ChangeHistory-BYBGfEjC.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CJaIViSV.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/members-CT8eS8uj.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-CIUGtnDT.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/personal-BdmVWea3.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/WhoPicker-HwLfU4nZ.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-FUYQxtGt.js", "/assets/SalesList-Dfx-dmLz.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-ypyEKF_h.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Bnd7nfbT.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-D_BIGa1w.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-DPeBDR0u.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/loans-BrhoA2RO.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-iw7vdiVr.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BXPPXW0p.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BHi6JmRL.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/personal-BdmVWea3.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/WhoPicker-HwLfU4nZ.js",
			"/assets/reminders-B21FcbME.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-CVyuM3t_.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-Ds9XgxFz.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/personal-BdmVWea3.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/WhoPicker-HwLfU4nZ.js",
			"/assets/generateCategoricalChart-B_kk0Zrn.js",
			"/assets/Area-Ddgl_LeW.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-Ri_eBW7T.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/generateCategoricalChart-B_kk0Zrn.js",
			"/assets/PlCharts-C59ZvEUq.js",
			"/assets/BarChart-Dm-yvWut.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DXPwTXio.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-Z8fUUrui.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BsNvRNDl.js",
			"/assets/createServerFn-CceZFe_6.js",
			"/assets/auth-middleware-D2I8zof0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/storage.functions-SEj9eNhh.js",
			"/assets/coupons.functions-B2KsaPty.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DF44xNbT.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-t4qhHHnE.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/checkbox-CFZzHNtd.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CkZKdYqF.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DztVk_a0.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DY7_IVka.js", "/assets/SalesList-Dfx-dmLz.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BCqS18PO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/ai-SKa6APTT.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-SEj9eNhh.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DRmTfTEG.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/money-C98xcaJf.js",
			"/assets/badge-6XOwzuEI.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Cc-ZT6y2.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-Blhs8JDh.js", "/assets/AccountRegister-9Y-VhaFn.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BD8IcKC-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/MoneyAccountPick-CfCePYEH.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-CxSTZVxd.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-CHq9jESi.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/RepeatInvoice-C239f8j3.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Dlc-Q3-7.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-B_kk0Zrn.js",
			"/assets/BarChart-Dm-yvWut.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CH2XrIuL.js", "/assets/SalesList-Dfx-dmLz.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-D4S37d1l.js", "/assets/SalesList-Dfx-dmLz.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BLZUgdch.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-C3LEd3NF.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/serials-BHcNJqUY.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CLnoEEhu.js",
			"/assets/createServerFn-CceZFe_6.js",
			"/assets/auth-middleware-D2I8zof0.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-YKpqxmwv.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-B1-gZZJn.js",
			"/assets/switch-BXPPXW0p.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-BwyBy2qt.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-zgtMzHuh.js",
			"/assets/footers-CBI4e_XN.js",
			"/assets/PrintFrame-PRAwoLwX.js",
			"/assets/checkbox-CFZzHNtd.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-QKcXuTBV.js",
			"/assets/FeaturePicker-BH4M-q0a.js",
			"/assets/support-WNwpPW9P.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-XmlFPyD2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/FeaturePicker-BH4M-q0a.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CQDG4_SV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-eD9NBNgJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/photos-zgtMzHuh.js",
			"/assets/stockmove-KiZvZT0G.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CtPOPPHo.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/loans-BrhoA2RO.js",
			"/assets/feedWaiting-BIChgw8x.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-SEj9eNhh.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Cs35gH-1.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/PrintFrame-PRAwoLwX.js",
			"/assets/DocPdf-B860DK-1.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-tjP8-ISY.js",
			"/assets/createServerFn-CceZFe_6.js",
			"/assets/auth-middleware-D2I8zof0.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/MoneyAccountPick-CfCePYEH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-WNwpPW9P.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-Cayj1L04.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/StockDialogs-eD9NBNgJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/stockmove-KiZvZT0G.js",
			"/assets/checkbox-CFZzHNtd.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BOjXvhjS.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/members-CT8eS8uj.js",
			"/assets/WhoPicker-HwLfU4nZ.js",
			"/assets/reminders-B21FcbME.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DSL75Ntl.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/tickets.functions-DytELPv1.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-BPkcg3yu.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-WNwpPW9P.js",
			"/assets/support.functions-blpskEaq.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CWjB_M5r.js", "/assets/StockDocList-v_rrKFyy.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CUWGao0L.js", "/assets/PartyList-B41wI-Ik.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-CWd64eFU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/tickets.functions-DytELPv1.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders--GUd4H_9.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/workorders-Bnj1-P2D.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-D1CdvGgo.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-vSGuda8_.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/coupons.functions-B2KsaPty.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CIz9mzbb.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/AdminAccount-BTuYbrb8.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BayQm5gp.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/downloads.functions-CTOZn4Qc.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-CxMQRfBu.js",
			"/assets/createServerFn-CceZFe_6.js",
			"/assets/auth-middleware-D2I8zof0.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DgjuG46C.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-B6I0DWwN.js",
			"/assets/testers.functions-C4Rsln7Q.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-zhXSYrXz.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BuqxjlVw.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-JwJTXfl4.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BL2Yv_F5.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/textarea-CF0hg9eD.js",
			"/assets/support.functions-blpskEaq.js",
			"/assets/HelpParts-Dew2hJV1.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-JJRjIQlK.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BhJmOVDQ.js",
			"/assets/manual._slug-ssEVhiPO.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DTha9oi2.js",
			"/assets/createServerFn-CceZFe_6.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DxAqtJhr.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-Q_8gCyTD.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-B3REUrqm.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-SKa6APTT.js",
			"/assets/personal-BdmVWea3.js",
			"/assets/reminders-B21FcbME.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CQu8HWxE.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/AdminAccount-BTuYbrb8.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DCskQMPt.js", "/assets/ManualFrame-BhJmOVDQ.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-Bs1F7756.js", "/assets/AccountRegister-9Y-VhaFn.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BpxtWibB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/OriginalLink-Czt7cbtz.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/realestate-CX64tCFp.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-wk_vAhrc.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-cyFFX_36.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/realestate-CX64tCFp.js",
			"/assets/money-C98xcaJf.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-4GB3r8s7.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/SideList-BlOJ-7c2.js",
			"/assets/PartyHistory-N44Ajq8I.js",
			"/assets/tabs-BVsAC4XJ.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-S2L8KoWW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-YKpqxmwv.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BYBGfEjC.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/SideList-BlOJ-7c2.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-o1G6WE3i.js",
			"/assets/MoneyAccountPick-CfCePYEH.js",
			"/assets/footers-CBI4e_XN.js",
			"/assets/PrintFrame-PRAwoLwX.js",
			"/assets/serials-BHcNJqUY.js",
			"/assets/SerialsBox-9nXIVdHZ.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BCZ5J1jh.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-eD9NBNgJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BYBGfEjC.js",
			"/assets/switch-BXPPXW0p.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-6XOwzuEI.js",
			"/assets/SideList-BlOJ-7c2.js",
			"/assets/tabs-BVsAC4XJ.js",
			"/assets/photos-zgtMzHuh.js",
			"/assets/stockmove-KiZvZT0G.js",
			"/assets/serials-BHcNJqUY.js",
			"/assets/SerialsBox-9nXIVdHZ.js",
			"/assets/workorders-Bnj1-P2D.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-D_tbrD6j.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-YKpqxmwv.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BYBGfEjC.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/SideList-BlOJ-7c2.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-o1G6WE3i.js",
			"/assets/MoneyAccountPick-CfCePYEH.js",
			"/assets/footers-CBI4e_XN.js",
			"/assets/PrintFrame-PRAwoLwX.js",
			"/assets/checkbox-CFZzHNtd.js",
			"/assets/serials-BHcNJqUY.js",
			"/assets/workorders-Bnj1-P2D.js",
			"/assets/RepeatInvoice-C239f8j3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DytELPv1.js",
			"/assets/users.functions-QKcXuTBV.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-B53ogcwS.js",
			"/assets/select-BOaQiYsJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/SideList-BlOJ-7c2.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-qTNWhb8m.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/quickadd-z7rDVUHI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-WNwpPW9P.js",
			"/assets/support.functions-blpskEaq.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-UICGubx-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-C9MQQfC3.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/SideList-BlOJ-7c2.js",
			"/assets/PartyHistory-N44Ajq8I.js",
			"/assets/tabs-BVsAC4XJ.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C-TnCNEz.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/sales-CAstpMaz.js",
			"/assets/footers-CBI4e_XN.js",
			"/assets/tickets.functions-DytELPv1.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BTAlwikF.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/input-BGVqpY1W.js",
			"/assets/skeleton-E974zaCK.js",
			"/assets/AdminAccount-BTuYbrb8.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BMhfPFlN.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CHI-UtMZ.js",
			"/assets/textarea-CF0hg9eD.js",
			"/assets/support-WNwpPW9P.js",
			"/assets/support.functions-blpskEaq.js",
			"/assets/HelpParts-Dew2hJV1.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CURaaCIC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-E974zaCK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
