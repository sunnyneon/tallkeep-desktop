//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CWRbAX0k.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-DV1CwiAl.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bk07vw6e.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CdPZWB6a.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DV1CwiAl.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-x5e3cxrs.js",
			"/assets/log-out-D2EAYL9_.js",
			"/assets/testers.functions-D3WsqUt5.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DL6K1eG6.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Cx-tv4BY.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-wWblJbUK.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/dist-DgxePhB9.js",
			"/assets/dialog-Dz2RElKB.js",
			"/assets/queries-W-c38eZ8.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/label-Cwz_E64f.js",
			"/assets/textarea-DjzPtW33.js",
			"/assets/shoebox-1MqXIsfw.js",
			"/assets/company-EOpaOC1v.js",
			"/assets/reports-T6b-YJnP.js",
			"/assets/access-C1i717Cp.js",
			"/assets/LicenseCard-ComwUYXU.js",
			"/assets/Logo-ZW2TsOUw.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Bgfszg0c.js",
			"/assets/log-out-D2EAYL9_.js",
			"/assets/admin.functions-DOlSHZFY.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-ZW2TsOUw.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-U5cO3ED8.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/label-Cwz_E64f.js",
			"/assets/Logo-ZW2TsOUw.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-C7QgpR7G.js",
			"/assets/testers.functions-D3WsqUt5.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/buy.functions-CdJ8qup2.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DJErL0LV.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/downloads.functions-34KzTK2-.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-Cp79NRjz.js",
			"/assets/testers.functions-D3WsqUt5.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/textarea-DjzPtW33.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CBv0c6QN.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/label-Cwz_E64f.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-OLTISS9d.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/label-Cwz_E64f.js",
			"/assets/Logo-ZW2TsOUw.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-DgAaBM_G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/upgrade.functions-CiIAqYJy.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-bhhNQ6TA.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/label-Cwz_E64f.js",
			"/assets/Logo-ZW2TsOUw.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BPSKE6I8.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BmR-mOXA.js", "/assets/StockDocList-D5pZDPCx.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-5kn_CgOO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/ai-BZjH_VTt.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-DeYPdvb8.js",
			"/assets/BankConnections-DxQq_u4W.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-Dog3U7JT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-7qL_BUUa.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DxQq_u4W.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/ai-BZjH_VTt.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DdOtPDXp.js",
			"/assets/TxnEditor-CYT9eUtV.js",
			"/assets/feedWaiting-DvaHJdAp.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Kvgz6t-c.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-BidY9eJd.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/personal-CPbOZGGy.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/WhoPicker-GlYX3igO.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CaVh_nmk.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-B2yC_QCb.js", "/assets/AccountRegister-Cb9fq5Hm.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Cf5_caFb.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DT0Q5gZQ.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/money-Bfr5hdQa.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BmCKtS7b.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BZjH_VTt.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BTHm8K4_.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Bt3SDOHf.js", "/assets/StockDocList-D5pZDPCx.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Bn0z1XVI.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-X9ce1roo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CPAEf3UN.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CVx-cW-y.js", "/assets/PartyList-DU4dbERU.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BWZ4ybfn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DGcWX-TA.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/storage.functions-BUgjWQeG.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CQQCrLrd.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DeXnrHsm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-DjM3wMra.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-XM-0W8Tz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BfAG_EUH.js", "/assets/ChangeHistory-Bej2QpxM.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CHu_TJ_w.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/members-CYJBkvQq.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-C0qgkkL4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/personal-CPbOZGGy.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/WhoPicker-GlYX3igO.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DNteJl5i.js", "/assets/SalesList-D8O8dun1.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CTbWw83l.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Du4Z2F_t.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BCHd_5ER.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-D9v85WNh.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/loans-DdOtPDXp.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DwkmqRmM.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BH7zjq8B.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BkY71kWv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/personal-CPbOZGGy.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/WhoPicker-GlYX3igO.js",
			"/assets/reminders-Dw2QYqQ5.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-tciPkdq3.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CqfTUKN3.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/personal-CPbOZGGy.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/WhoPicker-GlYX3igO.js",
			"/assets/generateCategoricalChart-C9cmanww.js",
			"/assets/Area-Dg_0w2aN.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-Dpo59jA4.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/generateCategoricalChart-C9cmanww.js",
			"/assets/PlCharts-DjM3wMra.js",
			"/assets/BarChart-B3xkwpD2.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BVyubJkF.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BasjQQV6.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-C9KeyZKR.js",
			"/assets/createServerFn-CTcnDWt0.js",
			"/assets/auth-middleware-_oTWgMzu.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/storage.functions-BUgjWQeG.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-Cul1kLiG.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BByqlmwd.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/checkbox-C0scw9pV.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CrEvB92X.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DAndqRK_.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-D8j-aXu5.js", "/assets/SalesList-D8O8dun1.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CbfV-Uok.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/ai-BZjH_VTt.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BUgjWQeG.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CzH6kv9i.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/money-Bfr5hdQa.js",
			"/assets/badge-RwC8L4yu.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-CQPzNAgN.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-B8ky7hEn.js", "/assets/AccountRegister-Cb9fq5Hm.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-mBuvhLt6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/MoneyAccountPick-LffjUR83.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-B6ro-MwK.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BxFNEa27.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/RepeatInvoice-D-o-oEv-.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-B_my2L9h.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-C9cmanww.js",
			"/assets/BarChart-B3xkwpD2.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CGLz2CUP.js", "/assets/SalesList-D8O8dun1.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-D0orf86t.js", "/assets/SalesList-D8O8dun1.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-M6oEy2Cv.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-ejn6FKi2.js",
			"/assets/createServerFn-CTcnDWt0.js",
			"/assets/auth-middleware-_oTWgMzu.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-BNzSG3K3.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BAM26I3G.js",
			"/assets/switch-BH7zjq8B.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-CPAEf3UN.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-qWzVcpYP.js",
			"/assets/footers-DpY6IP4W.js",
			"/assets/PrintFrame-DZeHdcBk.js",
			"/assets/checkbox-C0scw9pV.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-pfWVxu37.js",
			"/assets/FeaturePicker-AIiGwEoh.js",
			"/assets/support-C8UmLp3u.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-dN2fIoN7.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/FeaturePicker-AIiGwEoh.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BY2RbbOZ.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Cu2cbEDR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/photos-qWzVcpYP.js",
			"/assets/stockmove--PCHuUgV.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-izJDDEqv.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/loans-DdOtPDXp.js",
			"/assets/feedWaiting-DvaHJdAp.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BUgjWQeG.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-cS_LTRoJ.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/PrintFrame-DZeHdcBk.js",
			"/assets/DocPdf-BWC8OENM.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-D15Slv41.js",
			"/assets/createServerFn-CTcnDWt0.js",
			"/assets/auth-middleware-_oTWgMzu.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/MoneyAccountPick-LffjUR83.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C8UmLp3u.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BaerJOH3.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/StockDialogs-Cu2cbEDR.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/stockmove--PCHuUgV.js",
			"/assets/checkbox-C0scw9pV.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DdzkVJ3Z.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/members-CYJBkvQq.js",
			"/assets/WhoPicker-GlYX3igO.js",
			"/assets/reminders-Dw2QYqQ5.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BPb0NDGY.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/tickets.functions-BrJwN1T_.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DAjoNLuE.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C8UmLp3u.js",
			"/assets/support.functions-DWfnEqIk.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-uEtUWBgj.js", "/assets/StockDocList-D5pZDPCx.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-C49DxfHG.js", "/assets/PartyList-DU4dbERU.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-D1cq3nEH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/tickets.functions-BrJwN1T_.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DGztXTy1.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/workorders-DEPoVR6z.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CouBgHHv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CD29yBQh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/AdminAccount-BTMrUX38.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-Beo8irzz.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/downloads.functions-34KzTK2-.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B93X8CNx.js",
			"/assets/createServerFn-CTcnDWt0.js",
			"/assets/auth-middleware-_oTWgMzu.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-B4pqWe1k.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BZ2EdHR_.js",
			"/assets/testers.functions-D3WsqUt5.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-hcqwtbP4.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BdKO5Dx-.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CdJ8qup2.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug--v-ieek3.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/textarea-DjzPtW33.js",
			"/assets/support.functions-DWfnEqIk.js",
			"/assets/HelpParts-BNtvEP8n.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BP64ZX22.js",
			"/assets/ManualFrame-B_lctIgx.js",
			"/assets/manual._slug-Cnt9kru_.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CdU-kHG5.js",
			"/assets/createServerFn-CTcnDWt0.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-GpwhCg8B.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-CiIAqYJy.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CozHA2rr.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BZjH_VTt.js",
			"/assets/personal-CPbOZGGy.js",
			"/assets/reminders-Dw2QYqQ5.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DqcizwFt.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/AdminAccount-BTMrUX38.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CBJcd-UQ.js", "/assets/ManualFrame-B_lctIgx.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DyyfffF_.js", "/assets/AccountRegister-Cb9fq5Hm.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Cty8GtcG.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/OriginalLink-DG5BY8lB.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/realestate-BwJcn5SL.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-BIPEPoGz.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-D-ps-aD6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/realestate-BwJcn5SL.js",
			"/assets/money-Bfr5hdQa.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-D6aap1Xq.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/SideList-DIul1uo8.js",
			"/assets/PartyHistory-CzWozwUl.js",
			"/assets/tabs-DOUhMaMq.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BPOrMR5s.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-BNzSG3K3.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bej2QpxM.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/SideList-DIul1uo8.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BOtHlfpN.js",
			"/assets/MoneyAccountPick-LffjUR83.js",
			"/assets/footers-DpY6IP4W.js",
			"/assets/PrintFrame-DZeHdcBk.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BUnaKfRH.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Cu2cbEDR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bej2QpxM.js",
			"/assets/switch-BH7zjq8B.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/badge-RwC8L4yu.js",
			"/assets/SideList-DIul1uo8.js",
			"/assets/tabs-DOUhMaMq.js",
			"/assets/photos-qWzVcpYP.js",
			"/assets/stockmove--PCHuUgV.js",
			"/assets/workorders-DEPoVR6z.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BNhlLIYp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-BNzSG3K3.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bej2QpxM.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/SideList-DIul1uo8.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BOtHlfpN.js",
			"/assets/MoneyAccountPick-LffjUR83.js",
			"/assets/footers-DpY6IP4W.js",
			"/assets/PrintFrame-DZeHdcBk.js",
			"/assets/checkbox-C0scw9pV.js",
			"/assets/workorders-DEPoVR6z.js",
			"/assets/RepeatInvoice-D-o-oEv-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BrJwN1T_.js",
			"/assets/users.functions-pfWVxu37.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-T3BXUIMH.js",
			"/assets/select-AtqwWG_U.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/SideList-DIul1uo8.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-Ddtt1agQ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/quickadd-Bj5iAn_o.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C8UmLp3u.js",
			"/assets/support.functions-DWfnEqIk.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-6Res-1Pf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BbkgezMt.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/SideList-DIul1uo8.js",
			"/assets/PartyHistory-CzWozwUl.js",
			"/assets/tabs-DOUhMaMq.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BSJa_rS0.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/sales-BTHm8K4_.js",
			"/assets/footers-DpY6IP4W.js",
			"/assets/tickets.functions-BrJwN1T_.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-a9kzDy4C.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/input-DLtOFyNG.js",
			"/assets/skeleton-j7IIjTDW.js",
			"/assets/AdminAccount-BTMrUX38.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-DMqoU-sI.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CyNHpFxq.js",
			"/assets/textarea-DjzPtW33.js",
			"/assets/support-C8UmLp3u.js",
			"/assets/support.functions-DWfnEqIk.js",
			"/assets/HelpParts-BNtvEP8n.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Xmu_CtXH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-j7IIjTDW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
