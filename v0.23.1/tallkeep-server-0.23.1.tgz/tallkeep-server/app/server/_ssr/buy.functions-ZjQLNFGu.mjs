import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
import { a as addonFits, i as EDITION_KEYS, n as ADDON_KEYS, o as bundle, r as EDITIONS, s as catalog } from "./editions-CIhnK_Ff.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy.functions-ZjQLNFGu.js
/**
* Buying Tallkeep Desktop online: the Buy page (no sign-in) works out the price, sends the
* customer to Stripe to pay, and once Stripe says it's paid, makes the license key and emails it.
* Needs the STRIPE_SECRET_KEY secret (and LICENSE_PRIVATE_KEY, RESEND_API_KEY).
*/
var FOUNDERS_UNTIL = "2027-01-30";
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
async function buyInfo() {
	const { readPrices } = await import("./admin.functions-bCWtxbEK.mjs");
	const d = (await readPrices())?.prices ?? null;
	const { count } = await (await admin()).from("desktop_licenses").select("id", {
		count: "exact",
		head: true
	}).not("stripe_session", "is", null);
	const limit = d?.founders?.limit ?? 0;
	const foundersLeft = Math.max(0, limit - (count ?? 0));
	const foundersUntil = (d?.founders)?.until ?? FOUNDERS_UNTIL;
	const ended = Date.now() > (/* @__PURE__ */ new Date(`${foundersUntil}T23:59:59-06:00`)).getTime();
	const founders = !!d?.founders?.desktop && foundersLeft > 0 && !ended;
	const regularBase = d?.desktop.base ?? 0;
	return {
		ready: !!process.env["STRIPE_SECRET_KEY"] && regularBase > 0,
		base: founders ? d.founders.desktop : regularBase,
		founders,
		foundersUntil,
		regularBase,
		foundersLeft,
		baseCompanies: d?.desktop.base_companies ?? 1,
		baseUsers: d?.desktop.base_users ?? 1,
		extraCompany: d?.desktop.extra_company ?? 0,
		extraUser: d?.desktop.extra_user ?? 0,
		updatesYearly: d?.desktop.updates_yearly ?? 0,
		catalog: catalog(d)
	};
}
var getBuyInfo_createServerFn_handler = createServerRpc({
	id: "222764ceb133430e5ba744ea2a49ff737733dc9183d46b15301b1c7e2ef2bb4a",
	name: "getBuyInfo",
	filename: "src/lib/buy.functions.ts"
}, (opts) => getBuyInfo.__executeServer(opts));
var getBuyInfo = createServerFn({ method: "GET" }).handler(getBuyInfo_createServerFn_handler, async () => ({
	...await buyInfo(),
	foundersLeft: 0
}));
async function stripe(path, form) {
	const key = process.env["STRIPE_SECRET_KEY"];
	if (!key) throw new Error("Buying online isn't open yet.");
	const base = process.env["STRIPE_API_BASE"] || "https://api.stripe.com";
	let res;
	try {
		res = await fetch(`${base}/v1/${path}`, {
			method: form ? "POST" : "GET",
			headers: {
				Authorization: `Bearer ${key}`,
				...form ? { "Content-Type": "application/x-www-form-urlencoded" } : {}
			},
			body: form ?? null
		});
	} catch {
		throw new Error("Couldn't reach the payment service. Try again in a minute.");
	}
	const body = await res.json();
	if (!res.ok) throw new Error(body.error?.message ?? `Stripe said ${res.status}`);
	return body;
}
var cleanAddons = (a) => [...new Set((Array.isArray(a) ? a : []).filter((x) => ADDON_KEYS.includes(x)))];
function form() {
	const f = new URLSearchParams();
	let i = 0;
	const line = (name, dollars, qty) => {
		if (qty <= 0 || dollars <= 0) return;
		f.set(`line_items[${i}][price_data][currency]`, "usd");
		f.set(`line_items[${i}][price_data][product_data][name]`, name);
		f.set(`line_items[${i}][price_data][unit_amount]`, String(Math.round(dollars * 100)));
		f.set(`line_items[${i}][quantity]`, String(qty));
		i++;
	};
	return {
		f,
		line,
		count: () => i
	};
}
var startCheckout_createServerFn_handler = createServerRpc({
	id: "f9954db22f4c3a8f70b27c51d850a744ed1538ae448929e6afd51e15b23278e7",
	name: "startCheckout",
	filename: "src/lib/buy.functions.ts"
}, (opts) => startCheckout.__executeServer(opts));
var startCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	const to = String(d.to ?? "").trim().slice(0, 100);
	const email = String(d.email ?? "").trim().slice(0, 200);
	if (!to) throw new Error("Type your name or your business name.");
	if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Type your email address.");
	if (!EDITION_KEYS.includes(d.edition)) throw new Error("Pick Personal, Real Estate, Service or Full.");
	const extraCompanies = Math.floor(Number(d.extraCompanies) || 0);
	const extraUsers = Math.floor(Number(d.extraUsers) || 0);
	if (!(extraCompanies >= 0 && extraCompanies <= 100)) throw new Error("Extra companies: 0 to 100.");
	if (!(extraUsers >= 0 && extraUsers <= 500)) throw new Error("Extra people: 0 to 500.");
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	const code = String(d.code ?? "").trim().toUpperCase().slice(0, 20);
	return {
		to,
		email,
		edition: d.edition,
		addons: cleanAddons(d.addons).filter((a) => addonFits(a, d.edition)),
		extraCompanies,
		extraUsers,
		origin: d.origin,
		code
	};
}).handler(startCheckout_createServerFn_handler, async ({ data }) => {
	const info = await buyInfo();
	if (!info.ready) throw new Error("Buying online isn't open yet. Email hello@tallkeep.com.");
	const { testerCode } = await import("./testers.functions-B4p8yy_p.mjs").then((n) => n.c);
	const tc = data.code ? await testerCode(data.code) : null;
	if (data.code && !tc) throw new Error("That early access code isn't right, or it was already used. Check your welcome email.");
	if (tc?.code_session) {
		const prev = await stripe(`checkout/sessions/${tc.code_session}`).catch(() => null);
		if (prev?.status === "open") throw new Error("This early access code is in another checkout right now. Finish that one, or try again in 30 minutes.");
		if (prev?.status === "complete") throw new Error("That early access code was already used.");
	}
	const off = tc ? 1 - 50 / 100 : 1;
	const cat = info.catalog;
	const founders = info.founders && !tc;
	const price = (x) => tc ? Math.floor(x.price * off) : founders ? x.founders : x.price;
	const b = bundle(cat, data.edition, data.addons, founders);
	const note = tc ? ` (early access, 50% off)` : founders ? " (founders price)" : "";
	const { f, line } = form();
	const e = cat.editions[data.edition];
	line(`Tallkeep ${e.label}${note}: ${e.companies} ${e.companies === 1 ? "company" : "companies"}, ${e.users} people, 1 year of updates`, price(e), 1);
	for (const a of data.addons) line(`${cat.addons[a].label} add-on${note}`, price(cat.addons[a]), 1);
	line("Extra company", Math.floor(info.extraCompany * off), data.extraCompanies);
	line("Extra person", Math.floor(info.extraUser * off), data.extraUsers);
	f.set("mode", "payment");
	f.set("billing_address_collection", "required");
	f.set("customer_email", data.email);
	f.set("allow_promotion_codes", "true");
	f.set("success_url", `${data.origin}/buy/done?session={CHECKOUT_SESSION_ID}`);
	f.set("cancel_url", `${data.origin}/buy`);
	f.set("metadata[product]", "tallkeep_desktop");
	f.set("metadata[to]", data.to);
	f.set("metadata[edition]", data.edition);
	f.set("metadata[addons]", data.addons.join(","));
	f.set("metadata[companies]", String(b.companies + data.extraCompanies));
	f.set("metadata[users]", String(b.users + data.extraUsers));
	f.set("metadata[origin]", data.origin);
	if (tc) {
		f.set("metadata[tester_code]", tc.code);
		f.set("expires_at", String(Math.floor(Date.now() / 1e3) + 1860));
	}
	const s = await stripe("checkout/sessions", f);
	if (tc) {
		const { holdTesterCode } = await import("./testers.functions-B4p8yy_p.mjs").then((n) => n.c);
		await holdTesterCode(tc.code, String(s["id"]));
	}
	return { url: String(s["url"]) };
});
async function ownedLicense(key) {
	const { keyId } = await import("./license.server-Bu3IQdFy.mjs");
	const id = await keyId(key.trim());
	if (!id) throw new Error("That isn't a Tallkeep license key. Copy it from Settings → Plan & computer.");
	const { data } = await (await admin()).from("desktop_licenses").select("id,to_name,edition,addons,companies,users,revoked").eq("id", id).maybeSingle();
	const r = data;
	if (!r) throw new Error("We can't find that license. Email hello@tallkeep.com.");
	if (r.revoked) throw new Error("That license is turned off. Email hello@tallkeep.com.");
	return {
		id: r.id,
		to: r.to_name,
		edition: EDITION_KEYS.includes(r.edition) ? r.edition : null,
		addons: cleanAddons(r.addons),
		companies: r.companies,
		users: r.users,
		revoked: r.revoked
	};
}
/** What a license has now (for the Upgrade form). */
var lookUpLicense_createServerFn_handler = createServerRpc({
	id: "6bff944da1ec056947accb2562117e32d4a984b372336f1ff590ca9320773259",
	name: "lookUpLicense",
	filename: "src/lib/buy.functions.ts"
}, (opts) => lookUpLicense.__executeServer(opts));
var lookUpLicense = createServerFn({ method: "POST" }).inputValidator((d) => ({ key: String(d.key ?? "").slice(0, 4e3) })).handler(lookUpLicense_createServerFn_handler, async ({ data }) => {
	const o = await ownedLicense(data.key);
	return {
		id: o.id,
		to: o.to,
		edition: o.edition,
		addons: o.addons,
		companies: o.companies,
		users: o.users
	};
});
/** Price of moving from what's owned to the new edition and add-ons (today's prices). */
function upgradePrice(info, o, edition, addons) {
	const cat = info.catalog;
	if (!o.edition) return {
		total: 0,
		companies: o.companies,
		users: o.users,
		all: [.../* @__PURE__ */ new Set([...addons])]
	};
	const keep = o.edition === "real_estate" && !EDITIONS[edition].features.includes("real_estate") ? ["real_estate"] : [];
	const allAddons = [.../* @__PURE__ */ new Set([
		...o.addons,
		...addons,
		...keep
	])].filter((a) => addonFits(a, edition) || o.addons.includes(a) || keep.includes(a));
	const now = bundle(cat, o.edition, o.addons, info.founders);
	const next = bundle(cat, edition, allAddons, info.founders);
	const extraC = Math.max(0, (o.companies ?? now.companies) - now.companies);
	const extraU = Math.max(0, (o.users ?? now.users) - now.users);
	return {
		total: Math.max(0, next.total - now.total),
		companies: next.companies + extraC,
		users: next.users + extraU,
		all: allAddons
	};
}
var startUpgrade_createServerFn_handler = createServerRpc({
	id: "46cc758b5b42e5b4c6456feb57bf9342a9a5cd96381845478fe01d1e281ecc64",
	name: "startUpgrade",
	filename: "src/lib/buy.functions.ts"
}, (opts) => startUpgrade.__executeServer(opts));
var startUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!EDITION_KEYS.includes(d.edition)) throw new Error("Pick Personal, Real Estate, Service or Full.");
	if (!/^\S+@\S+\.\S+$/.test(String(d.email ?? ""))) throw new Error("Type your email address.");
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	return {
		key: String(d.key ?? "").slice(0, 4e3),
		email: String(d.email).trim(),
		edition: d.edition,
		addons: cleanAddons(d.addons),
		origin: d.origin
	};
}).handler(startUpgrade_createServerFn_handler, async ({ data }) => {
	const info = await buyInfo();
	if (!info.ready) throw new Error("Buying online isn't open yet. Email hello@tallkeep.com.");
	const o = await ownedLicense(data.key);
	const order = EDITION_KEYS.indexOf(data.edition);
	if (o.edition && order < EDITION_KEYS.indexOf(o.edition)) throw new Error("That's a step down. To change your plan, email hello@tallkeep.com.");
	const p = upgradePrice(info, o, data.edition, data.addons);
	if (p.total <= 0) throw new Error("Your license already has all of that.");
	const cat = info.catalog;
	const { f, line } = form();
	line(`Tallkeep upgrade for license ${o.id}: ${cat.editions[data.edition].label}${p.all.length ? ` + ${p.all.map((a) => cat.addons[a].label).join(" + ")}` : ""}${info.founders ? " (founders price)" : ""}`, p.total, 1);
	f.set("mode", "payment");
	f.set("billing_address_collection", "required");
	f.set("customer_email", data.email);
	f.set("allow_promotion_codes", "true");
	f.set("success_url", `${data.origin}/buy/done?session={CHECKOUT_SESSION_ID}`);
	f.set("cancel_url", `${data.origin}/buy?upgrade=1`);
	f.set("metadata[product]", "tallkeep_edition_upgrade");
	f.set("metadata[license]", o.id);
	f.set("metadata[edition]", data.edition);
	f.set("metadata[addons]", p.all.join(","));
	f.set("metadata[companies]", String(p.companies ?? ""));
	f.set("metadata[users]", String(p.users ?? ""));
	f.set("metadata[origin]", data.origin);
	const s = await stripe("checkout/sessions", f);
	return { url: String(s["url"]) };
});
var quoteUpgrade_createServerFn_handler = createServerRpc({
	id: "42c096807572ac95bb24b4bd4c91a75b9435bd09acd83552f994694d9c8870d5",
	name: "quoteUpgrade",
	filename: "src/lib/buy.functions.ts"
}, (opts) => quoteUpgrade.__executeServer(opts));
var quoteUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => ({
	key: String(d.key ?? "").slice(0, 4e3),
	edition: EDITION_KEYS.includes(d.edition) ? d.edition : "full",
	addons: cleanAddons(d.addons)
})).handler(quoteUpgrade_createServerFn_handler, async ({ data }) => {
	return { total: upgradePrice(await buyInfo(), await ownedLicense(data.key), data.edition, data.addons).total };
});
async function fulfill(session) {
	if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return { status: "unpaid" };
	const db = await admin();
	const existing = async () => {
		const { data } = await db.from("desktop_licenses").select("id,license_key,email,notes").eq("stripe_session", session).maybeSingle();
		return data;
	};
	const { wasMailed } = await import("./license.server-Bu3IQdFy.mjs");
	const had = await existing();
	if (had) return {
		status: "paid",
		id: had.id,
		key: had.license_key,
		email: had.email,
		mailed: wasMailed(had.notes)
	};
	const s = await stripe(`checkout/sessions/${session}`);
	if (s.payment_status !== "paid") return { status: "unpaid" };
	if (s.metadata?.["product"] === "tallkeep_edition_upgrade") return fulfillUpgrade(session, s);
	if (s.metadata?.["product"] !== "tallkeep_desktop") return { status: "unpaid" };
	const m = s.metadata;
	const email = s.customer_details?.email || s.customer_email || null;
	const until = /* @__PURE__ */ new Date();
	until.setFullYear(until.getFullYear() + 1);
	const { createLicense, mailLicense, mailNote } = await import("./license.server-Bu3IQdFy.mjs");
	const lic = {
		to: m["to"] || s.customer_details?.name || "Tallkeep customer",
		email,
		companies: Number(m["companies"]) || 1,
		users: Number(m["users"]) || 1,
		updatesUntil: until.toISOString().slice(0, 10),
		computers: 1,
		notes: `Paid online $${((s.amount_total ?? 0) / 100).toFixed(2)}`,
		stripeSession: session,
		paidCents: s.amount_total ?? null,
		edition: EDITION_KEYS.includes(m["edition"]) ? m["edition"] : null,
		addons: m["edition"] ? cleanAddons((m["addons"] ?? "").split(",").filter(Boolean)) : null
	};
	let made;
	try {
		made = await createLicense(db, lic);
	} catch (e) {
		const again = await existing();
		if (again) return {
			status: "paid",
			id: again.id,
			key: again.license_key,
			email: again.email,
			mailed: wasMailed(again.notes)
		};
		throw e;
	}
	const sent = email ? await mailLicense({
		to: email,
		name: lic.to,
		id: made.id,
		key: made.key,
		companies: lic.companies,
		users: lic.users,
		updatesUntil: lic.updatesUntil,
		origin: m["origin"] || "https://app.tallkeep.com"
	}) : {
		ok: false,
		why: "no email address"
	};
	if (!sent.ok) console.error("[buy] license email", sent.why);
	if (m["tester_code"]) {
		const { markTesterCodeUsed } = await import("./testers.functions-B4p8yy_p.mjs").then((n) => n.c);
		await markTesterCodeUsed(m["tester_code"], session).catch(() => null);
	}
	await db.from("desktop_licenses").update({ notes: `${lic.notes} · ${mailNote(sent)}` }).eq("id", made.id);
	const mailed = sent.ok;
	return {
		status: "paid",
		id: made.id,
		key: made.key,
		email,
		mailed
	};
}
async function fulfillUpgrade(session, s) {
	const db = await admin();
	const m = s.metadata ?? {};
	const id = m["license"] ?? "";
	const { data: done } = await db.from("desktop_licenses").select("id,license_key,email,upgrades").eq("id", id).maybeSingle();
	const row = done;
	if (!row) return { status: "unpaid" };
	if ((row.upgrades ?? []).some((u) => u.session === session)) return {
		status: "paid",
		id: row.id,
		key: row.license_key,
		email: row.email,
		mailed: true
	};
	const { upgradeLicense, mailLicense } = await import("./license.server-Bu3IQdFy.mjs");
	const num = (x) => x ? Number(x) || null : null;
	const up = await upgradeLicense(db, id, {
		edition: m["edition"] ?? "full",
		addons: cleanAddons((m["addons"] ?? "").split(",").filter(Boolean)),
		companies: num(m["companies"]),
		users: num(m["users"]),
		paidCents: s.amount_total ?? null,
		session
	});
	const email = s.customer_details?.email || s.customer_email || up.email;
	const sent = email ? await mailLicense({
		to: email,
		name: up.to,
		id: up.id,
		key: up.key,
		companies: num(m["companies"]),
		users: num(m["users"]),
		updatesUntil: up.updatesUntil,
		origin: m["origin"] || "https://app.tallkeep.com"
	}) : {
		ok: false,
		why: "no email address"
	};
	return {
		status: "paid",
		id: up.id,
		key: up.key,
		email,
		mailed: sent.ok
	};
}
var getOrder_createServerFn_handler = createServerRpc({
	id: "9c23602d2497e87db527c2f51f96da388bc05788ddb83ab0c420cfc762bcd869",
	name: "getOrder",
	filename: "src/lib/buy.functions.ts"
}, (opts) => getOrder.__executeServer(opts));
var getOrder = createServerFn({ method: "GET" }).inputValidator((d) => ({ session: String(d.session ?? "") })).handler(getOrder_createServerFn_handler, async ({ data }) => fulfill(data.session));
//#endregion
export { getBuyInfo_createServerFn_handler, getOrder_createServerFn_handler, lookUpLicense_createServerFn_handler, quoteUpgrade_createServerFn_handler, startCheckout_createServerFn_handler, startUpgrade_createServerFn_handler };
