import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, i as accountLabel, l as loadAccounts, u as loadTotals } from "./accounting-QuDdqtoA.mjs";
import { n as fmtDateTime, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ut as Download, ct as LockOpen, en as CircleCheck, m as TriangleAlert, st as Lock, vt as Info } from "../_libs/lucide-react.mjs";
import { i as useIsAdmin } from "./queries-Chjya1cy.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as work, n as form8949 } from "./cryptotax-BvfRzjXT.mjs";
import { i as toCsv, r as makeZip, t as downloadBlob } from "./csv-D0ewwTlm.mjs";
import { _ as v1099Csv, a as chartCsv, c as load1099, d as loadSplit, f as loadTaxRows, g as trialBalance, h as threshold1099, i as balanceSheet, l as loadLedger, m as salesTax, o as ledger, p as profitLoss, r as aging, u as loadOpen } from "./reports-Ba6xoNML.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/year-end-D5Ngp3QO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Year-end: investments and crypto for taxes, in one place. From the investment statements
* dropped in the Shoebox (the last one of the year for each account): realized gains, dividends,
* interest and fees. From Crypto Tax: gains on what was sold (short and long term) and crypto
* income, with the Form 8949 rows. Both go in the CPA package too.
*/
var r2 = (n) => Math.round(n * 100) / 100;
/** What the year's statements and crypto history say (empty parts when there's nothing). */
async function loadInvestTaxes(year) {
	const T = (t) => db.from(t);
	const [st, accts] = await Promise.all([T("investment_statements").select("account_id,period_end,ytd").gte("period_end", `${year}-01-01`).lte("period_end", `${year}-12-31`).order("period_end", { ascending: false }), T("accounts").select("id,name")]);
	const names = new Map((accts.data ?? []).map((a) => [a.id, a.name]));
	const seen = /* @__PURE__ */ new Set();
	const rows = [];
	for (const s of st.error ? [] : st.data ?? []) {
		if (seen.has(s.account_id)) continue;
		seen.add(s.account_id);
		rows.push({
			account: names.get(s.account_id) ?? "Account",
			asOf: s.period_end,
			y: s.ytd ?? {}
		});
	}
	let crypto = null;
	try {
		const [records, methods] = await Promise.all([fetchAll("tax_records", "id,wallet_id,happened_at,kind,asset,qty,usd,fee_usd,note,source_id,needs_review"), fetchAll("tax_methods", "year,method")]);
		if (records.length) {
			const m = new Map(methods.map((x) => [x.year, x.method]));
			crypto = work(records.map((r) => ({
				...r,
				qty: Number(r.qty),
				usd: r.usd == null ? null : Number(r.usd),
				fee_usd: Number(r.fee_usd)
			})), (y) => m.get(y) ?? "fifo");
		}
	} catch {
		crypto = null;
	}
	const inYear = (d) => d.slice(0, 4) === String(year);
	const sales = crypto ? crypto.sales.filter((s) => inYear(s.sold)) : [];
	const income = crypto ? crypto.income.filter((i) => inYear(i.date)) : [];
	return {
		rows,
		crypto: crypto ? {
			sales,
			short: r2(sales.filter((s) => !s.long).reduce((t, s) => t + s.gain, 0)),
			long: r2(sales.filter((s) => s.long).reduce((t, s) => t + s.gain, 0)),
			income: r2(income.reduce((t, i) => t + i.usd, 0))
		} : null
	};
}
/** The files for the CPA package (none when there's nothing for the year). */
async function investTaxFiles(year) {
	const d = await loadInvestTaxes(year);
	const out = [];
	if (d.rows.length) out.push({
		name: `11 Investments ${year} (from statements).csv`,
		text: toCsv(investCsv(d.rows))
	});
	if (d.crypto && (d.crypto.sales.length || d.crypto.income)) out.push({
		name: `12 Crypto Form 8949 rows ${year}.csv`,
		text: form8949(d.crypto.sales, year)
	});
	return out;
}
function investCsv(rows) {
	const n = (v) => v == null ? "" : v.toFixed(2);
	return [[
		"Account",
		"Statement date",
		"Realized short-term gain/loss",
		"Realized long-term gain/loss",
		"Dividends",
		"Interest",
		"Fees",
		"Put in",
		"Taken out",
		"Change in value"
	], ...rows.map((r) => [
		r.account,
		r.asOf,
		n(r.y.realized_short),
		n(r.y.realized_long),
		n(r.y.dividends),
		n(r.y.interest),
		n(r.y.fees),
		n(r.y.deposits),
		n(r.y.withdrawals),
		n(r.y.change_in_value)
	])];
}
function InvestTaxes({ year }) {
	const d = useQuery({
		queryKey: ["invest-taxes", year],
		queryFn: () => loadInvestTaxes(year)
	}).data;
	if (!d || !d.rows.length && !d.crypto) return null;
	const sum = (k) => d.rows.reduce((t, r) => t + (r.y[k] ?? 0), 0);
	const m = (v) => v == null ? "—" : fmtMoney(v);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			d.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/40 text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 text-left font-semibold",
									children: "Account (latest statement)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Realized short-term"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Realized long-term"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Dividends"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Interest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-semibold",
									children: "Fees"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [d.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-right tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2 text-left",
									children: [r.account, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-muted-foreground",
										children: ["to ", fmtDate(r.asOf)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: m(r.y.realized_short)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: m(r.y.realized_long)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: m(r.y.dividends)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: m(r.y.interest)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: m(r.y.fees)
								})
							]
						}, r.account + r.asOf)), d.rows.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "text-right font-semibold tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-left",
									children: "Total"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: fmtMoney(sum("realized_short"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: fmtMoney(sum("realized_long"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: fmtMoney(sum("dividends"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: fmtMoney(sum("interest"))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: fmtMoney(sum("fees"))
								})
							]
						})]
					})]
				})
			}),
			d.crypto && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: [
							"Crypto in ",
							year,
							":"
						]
					}),
					" gains on what was sold",
					" ",
					fmtMoney(d.crypto.short),
					" short-term, ",
					fmtMoney(d.crypto.long),
					" long-term (",
					d.crypto.sales.length,
					" sale",
					d.crypto.sales.length === 1 ? "" : "s",
					") · crypto income",
					" ",
					fmtMoney(d.crypto.income),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [d.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => downloadBlob(`Investments ${year}.csv`, new Blob([toCsv(investCsv(d.rows))], { type: "text/csv" })),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }),
						" Investments ",
						year,
						" (CSV)"
					]
				}), d.crypto && d.crypto.sales.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => downloadBlob(`Form-8949-crypto-${year}.csv`, new Blob([form8949(d.crypto.sales, year)], { type: "text/csv" })),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Crypto Form 8949 rows (CSV)"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "From your statements and exchange history. Your broker's and exchange's 1099 forms (early next year) are what the tax return uses; compare them with these. Ask your CPA what applies to you."
			})
		]
	});
}
/** Jan–Jun: last year is the one to finish. Jul–Dec: this year. */
var defaultYear = () => {
	const d = /* @__PURE__ */ new Date();
	return d.getMonth() < 6 ? d.getFullYear() - 1 : d.getFullYear();
};
function YearEnd() {
	const [year, setYear] = (0, import_react.useState)(defaultYear());
	const from = `${year}-01-01`;
	const to = `${year}-12-31`;
	const years = Array.from({ length: 4 }, (_, i) => (/* @__PURE__ */ new Date()).getFullYear() - i);
	const { data: isAdmin } = useIsAdmin();
	const { data: s } = useQuery({
		queryKey: ["company-settings", "year-end"],
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("name,books_start_date,books_closed_through,books_closed_at").maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const { data: check, isLoading } = useQuery({
		queryKey: [
			"account-totals",
			"year-end-check",
			year
		],
		queryFn: async () => {
			const [accounts, split, recons, waiting, adj, v1099] = await Promise.all([
				loadAccounts(),
				loadSplit(null, to),
				db.from("reconciliations").select("account_id,statement_date,completed_at").not("completed_at", "is", null).limit(5e3),
				db.from("bank_transactions").select("id", {
					count: "exact",
					head: true
				}).eq("status", "new").lte("txn_date", to),
				db.from("journal_entries").select("id", {
					count: "exact",
					head: true
				}).eq("source_type", "adjust").gte("entry_date", from).lte("entry_date", to),
				load1099(from, to)
			]);
			const last = /* @__PURE__ */ new Map();
			for (const r of recons.data ?? []) if (!last.has(r.account_id) || r.statement_date > last.get(r.account_id)) last.set(r.account_id, r.statement_date);
			const money = accounts.filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
			const tb = trialBalance(accounts, split);
			const limit = threshold1099(year);
			return {
				money: money.map((a) => ({
					a,
					last: last.get(a.id) ?? null
				})),
				waiting: waiting.count ?? 0,
				adjustments: adj.count ?? 0,
				off: Math.round((tb.total("after", "dr") - tb.total("after", "cr")) * 100) / 100,
				needs1099: v1099.filter((v) => v.is_1099 && v.counted >= limit),
				missingId: v1099.filter((v) => v.is_1099 && v.counted >= limit && !v.tax_id),
				unmarked: v1099.filter((v) => !v.is_1099 && v.counted >= limit)
			};
		}
	});
	const closed = s?.books_closed_through ?? null;
	const yearClosed = !!closed && closed >= to;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Year-End & CPA",
			text: "Get the year ready, download everything your accountant needs in one file, then close the books so nothing in that year changes by mistake.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				value: year,
				onChange: (e) => setYear(Number(e.target.value)),
				className: "h-9 rounded-md border bg-background px-2 text-sm",
				children: years.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: y,
					children: ["Year ", y]
				}, y))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			n: 1,
			title: `Get ${year} ready`,
			children: isLoading || !check ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "space-y-3",
				children: [
					check.money.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						state: "info",
						children: "No bank or credit card accounts in the Chart of Accounts."
					}),
					check.money.map(({ a, last }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						state: last && last >= to ? "ok" : "todo",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: accountLabel(a) }),
							":",
							" ",
							last && last >= to ? `reconciled through ${fmtDate(last)}.` : last ? `last reconciled ${fmtDate(last)}. Reconcile the December statement.` : "never reconciled. Reconcile the December statement.",
							" ",
							!(last && last >= to) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/banking",
								className: "underline",
								children: "Open Banking"
							})
						]
					}, a.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						state: check.waiting ? "todo" : "ok",
						children: [check.waiting ? `${check.waiting} bank line${check.waiting > 1 ? "s" : ""} waiting for review. ` : "No bank lines waiting for review.", check.waiting > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/banking",
							className: "underline",
							children: "Review them"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						state: check.off ? "todo" : "ok",
						children: check.off ? `The books are off by ${fmtMoney(check.off)}. Press "Rebuild the books" in Settings → Accounting.` : "Debits and credits match."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						state: "info",
						children: [
							"Count your stock on Dec 31 so the inventory value is right.",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/count",
								className: "underline",
								children: "Open Count Sheet"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						state: check.missingId.length || check.unmarked.length ? "todo" : "ok",
						children: [
							check.needs1099.length,
							" vendor",
							check.needs1099.length === 1 ? "" : "s",
							" need a 1099",
							check.missingId.length ? `, ${check.missingId.length} missing a Tax ID` : "",
							check.unmarked.length ? `. ${check.unmarked.length} paid ${fmtMoney(threshold1099(year))}+ but not marked; check with your accountant` : "",
							".",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/financials",
								search: {
									tab: "v1099",
									from,
									to
								},
								className: "underline",
								children: "See 1099 vendors"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						state: "info",
						children: [
							check.adjustments ? `${check.adjustments} accountant adjustment${check.adjustments > 1 ? "s" : ""} in ${year}.` : "No accountant adjustments yet. Add them when your accountant sends them.",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/journal",
								search: { adjust: 1 },
								className: "underline",
								children: "Add an adjustment"
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			n: 2,
			title: `Investments and crypto for ${year} taxes`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvestTaxes, { year }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Drop your brokerage and retirement statements in the Shoebox, and bring in exchange history in Crypto Tax (My Money). What they show for ",
					year,
					" appears here and goes in the package."
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			n: 3,
			title: "Send the package to your accountant",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "One .zip file with spreadsheets (CSV) your accountant can open in Excel: Profit & Loss, Balance Sheet, Trial Balance (with adjustments), General Ledger, Chart of Accounts, who owes us, what we owe, sales tax, 1099 vendors and bank reconciliations."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageButton, {
				year,
				company: s?.name ?? "Company",
				closed: yearClosed
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			n: 4,
			title: "Close the books",
			children: [closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-start gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mt-0.5 h-4 w-4 text-[var(--section)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Closed through ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtDate(closed) }),
					s?.books_closed_at ? ` (on ${fmtDateTime(s.books_closed_at)})` : "",
					". Nothing dated on or before that day can be changed. Paying old invoices today still works."
				] })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "The books are open. Close them after your accountant is done with the year (and you added their adjustments)."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseButtons, {
				year,
				closed,
				isAdmin: !!isAdmin,
				before: s?.books_start_date ?? null
			})]
		})
	] });
}
function Card({ n, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 font-display text-lg font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-7 w-7 place-items-center rounded-full bg-[var(--section)] text-sm text-white",
				children: n
			}), title]
		}), children]
	});
}
function Item({ state, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start gap-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(state === "ok" ? CircleCheck : state === "todo" ? TriangleAlert : Info, { className: `mt-0.5 h-4 w-4 shrink-0 ${state === "ok" ? "text-emerald-600" : state === "todo" ? "text-amber-600" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children })]
	});
}
function PackageButton({ year, company, closed }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function build() {
		setBusy(true);
		try {
			const from = `${year}-01-01`;
			const to = `${year}-12-31`;
			const prevEnd = `${year - 1}-12-31`;
			const [accounts, totYear, totAll, split, lines, openAll, ar, ap, tax, v1099, recons] = await Promise.all([
				loadAccounts(),
				loadTotals(from, to),
				loadTotals(null, to),
				loadSplit(null, to),
				loadLedger(from, to),
				loadTotals(null, prevEnd),
				loadOpen("ar"),
				loadOpen("ap"),
				loadTaxRows(),
				load1099(from, to),
				db.from("reconciliations").select("account_id,statement_date,ending_balance,completed_at").gte("statement_date", from).lte("statement_date", to).order("statement_date").limit(5e3)
			]);
			const balYear = balFrom(totYear);
			const balAll = balFrom(totAll);
			const name = new Map(accounts.map((a) => [a.id, accountLabel(a)]));
			const limit = threshold1099(year);
			const reconRows = (recons.data ?? []).map((r) => [
				name.get(r.account_id) ?? "",
				r.statement_date,
				Number(r.ending_balance),
				r.completed_at ? "Finished" : "Not finished"
			]);
			const tb = trialBalance(accounts, split);
			const files = [
				{
					name: `01 Profit and Loss ${year}.csv`,
					rows: profitLoss(accounts, balYear).csv()
				},
				{
					name: `02 Balance Sheet ${to}.csv`,
					rows: balanceSheet(accounts, balAll, balYear).csv()
				},
				{
					name: `03 Trial Balance ${to}.csv`,
					rows: tb.csv()
				},
				{
					name: `04 General Ledger ${year}.csv`,
					rows: ledger(accounts, lines, openAll, /* @__PURE__ */ new Map()).csv()
				},
				{
					name: `05 Chart of Accounts.csv`,
					rows: chartCsv(accounts, balAll)
				},
				{
					name: `06 Who owes us ${to}.csv`,
					rows: aging("ar", ar, to).csv()
				},
				{
					name: `07 What we owe ${to}.csv`,
					rows: aging("ap", ap, to).csv()
				},
				{
					name: `08 Sales tax ${year}.csv`,
					rows: salesTax(tax, from, to).csv()
				},
				{
					name: `09 1099 vendors ${year}.csv`,
					rows: v1099Csv(v1099, limit)
				},
				{
					name: `10 Bank reconciliations ${year}.csv`,
					rows: [[
						"Account",
						"Statement date",
						"Ending balance",
						"Status"
					], ...reconRows]
				}
			];
			const readme = [
				`${company} — books for ${year}`,
				`Made by Tallkeep on ${(/* @__PURE__ */ new Date()).toLocaleString("en-US")}.`,
				closed ? `The books are closed through ${to}.` : `The books for ${year} are not closed yet.`,
				tb.hasAdj ? "The Trial Balance includes accountant adjustments in their own columns." : "No accountant adjustments have been entered yet.",
				"",
				"Files:",
				...files.map((f) => `  ${f.name}`),
				"",
				"Notes:",
				"  Who owes us and What we owe show what is still open today, for items dated by Dec 31.",
				`  1099: vendors marked for a 1099 and paid ${limit} or more, not counting credit card payments.`
			].join("\r\n");
			const extra = await investTaxFiles(year).catch(() => []);
			const blob = makeZip([
				{
					name: "README.txt",
					text: readme + (extra.length ? `\r\n${extra.map((f) => `  ${f.name}`).join("\r\n")}\r\n` : "")
				},
				...files.map((f) => ({
					name: f.name,
					text: toCsv(f.rows)
				})),
				...extra
			]);
			const safe = company.replace(/[^\w\- ]+/g, "").trim() || "Company";
			downloadBlob(`${safe} - CPA package ${year}.zip`, blob);
			toast.success("Package downloaded.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick: () => void build(),
		disabled: busy,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }),
			" ",
			busy ? "Making the package…" : `Download the ${year} package`
		]
	});
}
function CloseButtons({ year, closed, isAdmin, before }) {
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const to = `${year}-12-31`;
	async function run(through) {
		const ask = through ? `Close the books through ${fmtDate(through)}?\n\nNothing dated on or before that day can be changed until an admin reopens them.` : "Reopen the books? Old documents and entries can be changed again.";
		if (!window.confirm(ask)) return;
		setBusy(true);
		const { error } = await db.rpc("close_books", { _through: through });
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(through ? `Books closed through ${fmtDate(through)}.` : "Books reopened.");
		qc.invalidateQueries({ queryKey: ["company-settings"] });
	}
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: "Only an admin can close or reopen."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [(!closed || closed < to) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			onClick: () => void run(to),
			disabled: busy || !!before && before > to,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
				" Close the books through Dec 31, ",
				year
			]
		}), closed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			onClick: () => void run(null),
			disabled: busy,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { className: "h-4 w-4" }), " Reopen the books"]
		})]
	});
}
//#endregion
export { YearEnd as component };
