//#region ../../node_modules/.nitro/vite/services/ssr/assets/statementDates-DmwBfxD6.js
/**
* Statement dates that cross New Year. A January statement often lists December lines, and the
* AI gives them the statement's year (Dec 17, 2026 on a statement that ends Jan 17, 2026). A line
* can't be after the statement ends, so those go back a year.
*/
var DAY = 864e5;
var t = (d) => Date.parse(`${d}T12:00:00Z`);
/** The statement's end date: what the AI read, else the newest line not in the future. */
function statementEnd(periodEnds, dates) {
	const ok = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v.slice(0, 10));
	const pe = periodEnds.filter(ok).map((v) => String(v).slice(0, 10));
	if (pe.length) return pe.sort().at(-1);
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return dates.filter((d) => d <= today).sort().at(-1) ?? today;
}
/** The line's date, moved back a year (or more) while it's after the statement's end. */
function fixLineYear(date, end) {
	let d = date;
	for (let i = 0; i < 3 && t(d) > t(end) + 5 * DAY; i++) d = `${Number(d.slice(0, 4)) - 1}${d.slice(4)}`;
	return d;
}
//#endregion
export { statementEnd as n, fixLineYear as t };
