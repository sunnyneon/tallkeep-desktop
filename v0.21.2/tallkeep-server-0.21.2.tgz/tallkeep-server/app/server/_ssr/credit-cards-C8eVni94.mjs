import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, f as useAccounts, i as accountLabel, p as useTotals } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Kt as CreditCard, N as Repeat, R as Plus, cn as CheckCheck, d as Upload } from "../_libs/lucide-react.mjs";
import { i as useIsAdmin } from "./queries-Chjya1cy.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/credit-cards-C8eVni94.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** One place for the business's credit cards. */
function CreditCards() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: totals } = useTotals(null, null);
	const { data: isAdmin } = useIsAdmin();
	const cards = (accounts ?? []).filter((a) => a.is_active && a.kind === "credit_card");
	const owed = balFrom(totals);
	const ids = new Set(cards.map((c) => c.id));
	const { data: recons } = useQuery({
		queryKey: ["card-reconciliations"],
		queryFn: async () => {
			const { data } = await db.from("reconciliations").select("account_id,statement_date,completed_at").not("completed_at", "is", null);
			return data ?? [];
		}
	});
	const lastRecon = (id) => (recons ?? []).filter((r) => r.account_id === id).map((r) => r.statement_date).sort().at(-1);
	const { data: checks } = useQuery({
		queryKey: ["checks"],
		queryFn: async () => (await fetchAll("checks")).map((c) => ({
			...c,
			total: Number(c.total)
		}))
	});
	const charges = (0, import_react.useMemo)(() => (checks ?? []).filter((c) => ids.has(c.account_id)).sort((a, b) => b.check_date.localeCompare(a.check_date)).slice(0, 30), [checks, cards.length]);
	const name = new Map(cards.map((a) => [a.id, accountLabel(a)]));
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)("");
	async function addCard(e) {
		e.preventDefault();
		if (!newName.trim()) return void toast.error("Type the card's name, like Amex Blue 1004.");
		const { error } = await db.from("accounts").insert({
			name: newName.trim(),
			kind: "credit_card",
			type: "liability",
			number: null
		});
		if (error) return void toast.error(error.message);
		toast.success("Card added.");
		setNewName("");
		setAdding(false);
		qc.invalidateQueries({ queryKey: ["accounts"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Credit Cards",
			text: "Enter card charges, bring in the card statement (PDF works), reconcile it, and pay the card.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setAdding(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a credit card"]
				}), cards.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/checks/$id",
						params: { id: "new" },
						search: { card: 1 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-4 w-4" }), " New card charge"]
					})
				})]
			})
		}),
		adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: addCard,
			className: "flex flex-wrap items-center gap-2 rounded-2xl border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					autoFocus: true,
					className: "min-w-0 flex-1",
					placeholder: "Card name, like Amex Blue 1004",
					value: newName,
					onChange: (e) => setNewName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Add this card"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: () => setAdding(false),
					children: "Cancel"
				})
			]
		}),
		accounts && cards.length === 0 && !adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "rounded-2xl border bg-card p-6 text-sm text-muted-foreground",
			children: [
				"No credit cards yet.",
				" ",
				isAdmin ? "Press \"Add a credit card\" to start." : "Ask an admin to add one."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: cards.map((a) => {
				const due = owed(a);
				const rec = lastRecon(a.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-lg bg-[var(--section)]/10 p-2 text-[var(--section)]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-5 w-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: accountLabel(a)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: rec ? `Reconciled through ${fmtDate(rec)}` : "Not reconciled yet"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: due >= 0 ? "You owe" : "Card owes you"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold",
								children: fmtMoney(Math.abs(due))
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/checks/$id",
									params: { id: "new" },
									search: {
										card: 1,
										account: a.id
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Charge"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/banking",
									search: { account: a.id },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }), " Statement"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/banking",
									search: {
										account: a.id,
										tab: "reconcile"
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-4 w-4" }), " Reconcile"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/bank-transfers",
									search: { to: a.id },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-4 w-4" }), " Pay the card"]
								})
							})
						]
					})]
				}, a.id);
			})
		}),
		cards.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "Card charges entered here"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [checks && charges.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-muted-foreground",
					children: "No card charges yet. Lines from a card statement show in Bank Feeds once you bring it in."
				}), charges.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/checks/$id",
					params: { id: c.id },
					search: { card: 1 },
					className: "flex flex-wrap items-center gap-3 px-4 py-3 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-24 text-xs",
							children: fmtDate(c.check_date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: c.payee
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: [name.get(c.account_id), c.memo ? ` · ${c.memo}` : ""]
							})]
						}),
						c.status === "void" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Void"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-28 text-right font-semibold",
							children: fmtMoney(c.total)
						})
					]
				}, c.id))]
			})]
		})
	] });
}
//#endregion
export { CreditCards as component };
