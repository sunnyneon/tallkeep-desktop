import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as bySection } from "./manual-C1hviOEM.mjs";
import { t as ManualFrame } from "./ManualFrame-3AiM67ri.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/manual.index-CYE-IaZ2.js
var import_jsx_runtime = require_jsx_runtime();
/** The Tallkeep manual, open to everyone (tallkeep.com/help comes here). */
function ManualHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold",
			children: "Tallkeep Manual"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-muted-foreground",
			children: [
				"How to do each job in Tallkeep, step by step. Search above, or pick a topic. In Tallkeep, press ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "F1" }),
				" or ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Help" }),
				" for the page you're on."
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-6 sm:grid-cols-2",
			children: bySection().map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-display text-lg font-semibold",
					children: s.section
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-1",
					children: s.list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/manual/$slug",
						params: { slug: a.slug },
						className: "text-primary hover:underline",
						children: a.title
					}) }, a.slug))
				})]
			}, s.section))
		})]
	}) });
}
//#endregion
export { ManualHome as component };
