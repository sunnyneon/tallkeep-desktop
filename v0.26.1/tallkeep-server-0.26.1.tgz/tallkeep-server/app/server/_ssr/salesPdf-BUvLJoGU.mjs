import { i as fmtQty, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { a as docName, c as isRmaDoc, l as lineTotal, s as isQuoteLike } from "./sales-DLuHnKkT.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/salesPdf-BUvLJoGU.js
/** The quote / invoice / RMA as PDF content — same as the printed page. */
function salesPdf(order, lines, company, logo, terms, payments, extra = {}) {
	const rma = isRmaDoc(order);
	const name = rma ? "RMA" : docName(order.status === "cancelled" ? "quote" : order.status);
	const endFooter = order.footer_id || order.footer_text ? order.footer_text : rma ? null : order.status === "quote" ? company?.quote_footer : company?.invoice_footer;
	const date = isQuoteLike(order.status) || order.status === "open" ? order.order_date : order.invoice_date ?? order.order_date;
	const facts = [["No.", order.number ?? ""], ["Date", fmtDate(date)]];
	if (order.project_name) facts.push(["Project", order.project_name]);
	if (order.po_number && !isQuoteLike(order.status)) facts.push(["Your PO", order.po_number]);
	if (terms) facts.push(["Terms", terms]);
	if (order.sales_rep) facts.push(["Sales rep", order.sales_rep]);
	if (order.due_date && !isQuoteLike(order.status)) facts.push(["Due", fmtDate(order.due_date)]);
	const totals = [{
		label: "Subtotal",
		value: fmtMoney(order.subtotal)
	}, {
		label: `${order.tax_name || "Sales tax"} (${Number(order.tax_rate)}%)`,
		value: fmtMoney(order.tax)
	}];
	if (Number(order.shipping) !== 0) totals.push({
		label: "Shipping",
		value: fmtMoney(order.shipping)
	});
	totals.push({
		label: "Total",
		value: fmtMoney(order.total),
		big: true
	});
	if (order.status !== "quote" && !rma) [...payments].filter((p) => Number(p.amount) !== 0).sort((a, b) => a.paid_on.localeCompare(b.paid_on)).forEach((p) => totals.push({
		label: `Paid ${fmtDate(p.paid_on)}`,
		value: `– ${fmtMoney(p.amount)}`
	}));
	if (!isQuoteLike(order.status) && !rma) totals.push({
		label: "Balance due",
		value: fmtMoney(Number(order.total) - Number(order.amount_paid || 0)),
		big: true
	});
	if (extra.deposit && extra.deposit > 0) totals.push({
		label: "Deposit due now",
		value: fmtMoney(extra.deposit),
		big: true
	});
	return {
		payUrl: extra.payUrl,
		title: name.toUpperCase(),
		subtitle: rma ? "Return Merchandise Authorization" : void 0,
		logo,
		company: {
			name: company?.name ?? "",
			address: company?.mailing_address || company?.address || null,
			addressLabel: isQuoteLike(order.status) || order.status === "cancelled" ? "MAILING ADDRESS" : "MAIL PAYMENTS TO",
			phone: company?.phone ?? null,
			email: company?.email ?? null,
			website: company?.website ?? null
		},
		facts,
		leftTitle: "BILL TO",
		left: [
			order.customer_name,
			order.contact_name ? `Attn: ${order.contact_name}` : null,
			order.billing_address,
			[order.phone, order.email].filter(Boolean).join(" · ") || null
		].filter(Boolean).join("\n"),
		rightTitle: "SHIP TO",
		right: order.shipping_address ?? "",
		lines: lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l) => ({
			desc: l.description ?? "",
			qty: fmtQty(l.qty),
			price: fmtMoney(l.unit_price),
			disc: Number(l.discount) ? `${Number(l.discount)}%` : "",
			total: fmtMoney(lineTotal(l))
		})),
		remarks: order.remarks,
		totals,
		endFooter,
		pageFooter: order.page_footer_text,
		attach: order.attach_text
	};
}
//#endregion
export { salesPdf };
