import { Z as notFound, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as articleBySlug } from "./manual-C1hviOEM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/manual._slug-BOLRSX06.js
var $$splitComponentImporter = () => import("./manual._slug-iD2xxwBB.mjs");
var $$splitNotFoundComponentImporter = () => import("./manual._slug-D7bXT3lM.mjs");
/** One manual article, open to everyone. */
var Route = createFileRoute("/manual/$slug")({
	loader: ({ params }) => {
		const a = articleBySlug(params.slug);
		if (!a) throw notFound();
		return { slug: a.slug };
	},
	head: ({ params }) => {
		const a = articleBySlug(params.slug);
		return { meta: [{ title: a ? `${a.title} · Tallkeep Manual` : "Tallkeep Manual" }, {
			name: "description",
			content: a?.summary ?? ""
		}] };
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
