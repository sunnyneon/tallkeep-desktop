import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as BUSINESS_TYPES } from "./addons-8tQCpcOj.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Nn as ArrowLeft, jn as ArrowRight, sn as Check } from "../_libs/lucide-react.mjs";
import { a as useIsOwner } from "./queries-Chjya1cy.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-C_XVL5mk.mjs";
import { t as FeaturePicker } from "./FeaturePicker-BQFuZqjk.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/setup-company-5gpu4c0p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BUSINESS_STEPS = [
	"kind",
	"details",
	"email",
	"numbers",
	"data"
];
var PERSONAL_STEPS = [
	"kind",
	"details",
	"data"
];
/** Document numbers each company keeps; label = what people call it. */
var COUNTERS = [
	{
		kind: "quote",
		label: "Quotes",
		prefix: "SQ-"
	},
	{
		kind: "sales_order",
		label: "Invoices",
		prefix: "INV-"
	},
	{
		kind: "purchase_order",
		label: "Purchase orders",
		prefix: "PO-"
	},
	{
		kind: "rma",
		label: "Returns (RMA)",
		prefix: "RMA-"
	},
	{
		kind: "stock_adjust",
		label: "Stock adjustments",
		prefix: "SA-"
	},
	{
		kind: "stock_transfer",
		label: "Stock transfers",
		prefix: "ST-"
	},
	{
		kind: "stock_count",
		label: "Count sheets",
		prefix: "CS-"
	}
];
function SetupCompany() {
	const { data: isAdmin, isLoading } = useIsOwner();
	const [step, setStep] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [companyId, setCompanyId] = (0, import_react.useState)(null);
	const [info, setInfo] = (0, import_react.useState)({
		name: "",
		legal_name: "",
		tax_id: "",
		phone: "",
		email: "",
		website: "",
		address: "",
		mailing_address: ""
	});
	const [mail, setMail] = (0, import_react.useState)({
		from: "",
		replyTo: ""
	});
	const [start, setStart] = (0, import_react.useState)(`${(/* @__PURE__ */ new Date()).getFullYear()}-01-01`);
	const startField = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		label: "Books start on",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			type: "date",
			value: start,
			onChange: (e) => setStart(e.target.value)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted-foreground",
			children: "The first day you want in these books, usually January 1. Statements from before this day give the opening balances."
		})]
	});
	const [numbers, setNumbers] = (0, import_react.useState)(COUNTERS.map((c) => ({
		...c,
		next: 1001
	})));
	const [bizType, setBizType] = (0, import_react.useState)(null);
	const [addons, setAddons] = (0, import_react.useState)([]);
	const personal = bizType === "personal";
	const steps = personal ? PERSONAL_STEPS : BUSINESS_STEPS;
	const at = steps[step] ?? "kind";
	const last = steps.length - 1;
	const label = {
		kind: "Kind",
		details: personal ? "About you" : "Company",
		email: "Email",
		numbers: "Numbers",
		data: personal ? "Get started" : "Your data"
	};
	if (isLoading) return null;
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6 text-muted-foreground",
		children: "Only an admin of every company can set up a new company."
	}) });
	const text = (k) => ({
		value: info[k],
		onChange: (e) => setInfo((x) => ({
			...x,
			[k]: e.target.value
		}))
	});
	const orNull = (v) => v.trim() || null;
	async function settings(patch) {
		const { error } = await db.from("company_settings").update(patch).eq("company_id", companyId);
		if (error) throw error;
	}
	async function next() {
		setBusy(true);
		try {
			if (at === "kind") {
				if (!bizType) throw new Error("Pick what kind of company it is.");
			}
			if (at === "details") {
				if (!info.name.trim()) throw new Error(personal ? "Type a name for these books." : "Type the company name.");
				let id = companyId;
				if (!id) {
					const { data, error } = await db.rpc("create_company", { _name: info.name.trim() });
					if (error) throw error;
					id = data;
					setCompanyId(id);
					const sw = await db.rpc("set_active_company", { _c: id });
					if (sw.error) throw sw.error;
				}
				const { error } = await db.from("company_settings").update({
					name: info.name.trim(),
					legal_name: orNull(info.legal_name),
					tax_id: orNull(info.tax_id),
					phone: orNull(info.phone),
					email: orNull(info.email),
					website: orNull(info.website),
					address: orNull(info.address),
					mailing_address: orNull(info.mailing_address),
					business_type: bizType,
					addons,
					books_start_date: start || null
				}).eq("company_id", id);
				if (error) throw error;
				if (start) await db.rpc("rebuild_books");
				await db.from("companies").update({ name: info.name.trim() }).eq("id", id);
				setMail((m) => ({
					from: m.from || info.name.trim(),
					replyTo: m.replyTo || info.email.trim()
				}));
			}
			if (at === "email") await settings({
				email_from_name: orNull(mail.from),
				email_reply_to: orNull(mail.replyTo)
			});
			if (at === "numbers") {
				const rows = numbers.map((n) => ({
					company_id: companyId,
					kind: n.kind,
					prefix: n.prefix.trim(),
					next_number: Math.max(1, Math.floor(Number(n.next) || 1))
				}));
				const { error } = await db.from("doc_counters").upsert(rows, { onConflict: "company_id,kind" });
				if (error) throw error;
			}
			setStep((s) => s + 1);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	function finish(to) {
		window.location.href = to;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Set up a new company",
			text: "A few short steps. You can change any of this later in Settings."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-wrap gap-2",
			children: steps.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: `flex items-center gap-1.5 rounded-full px-3 py-1 text-sm ${i === step ? "bg-[var(--section)] font-medium text-white" : i < step ? "bg-muted text-foreground" : "bg-muted/50 text-muted-foreground"}`,
				children: [
					i < step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [i + 1, "."] }),
					" ",
					label[k]
				]
			}, k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
			children: [
				at === "kind" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "What is this company for?",
					text: "Pick one. Tallkeep sets up only what it needs; you can change it any time in Settings → Features.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturePicker, {
						type: bizType,
						features: addons,
						onType: (t) => {
							setBizType(t);
							setAddons([...BUSINESS_TYPES[t].features]);
						},
						onToggle: (k, on) => setAddons((a) => on ? [...a, k] : a.filter((x) => x !== k))
					})
				}),
				at === "details" && personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "About you",
					text: "A name for these books, and how to reach you. Only the name is needed.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name for these books",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									autoFocus: true,
									placeholder: "e.g. Kalyani Family",
									...text("name")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									...text("email")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Address",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("address")
								})
							}),
							startField
						]
					})
				}),
				at === "details" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "Company details",
					text: "Printed on quotes, invoices and purchase orders. Only the name is required now.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Company name (as customers know it)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									autoFocus: true,
									placeholder: "e.g. Sunny Neon Inc.",
									...text("name")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Legal name, if different",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("legal_name") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Tax ID (EIN)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "12-3456789",
									...text("tax_id")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									...text("email")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Website",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Address",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("address")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mailing address for payments, if different",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("mailing_address")
								})
							}),
							startField
						]
					})
				}),
				at === "email" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "Email",
					text: "How quotes, invoices and follow-ups look in your customers' inbox.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name customers see as the sender",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: mail.from,
								onChange: (e) => setMail({
									...mail,
									from: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Customer replies go to",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								value: mail.replyTo,
								onChange: (e) => setMail({
									...mail,
									replyTo: e.target.value
								})
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Emails are sent from our shared address for now; when this company has its own email domain, we can send from it."
					})]
				}),
				at === "numbers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "Document numbers",
					text: "Start where your old system left off, so numbers continue without gaps or repeats.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y rounded-xl border",
						children: numbers.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 px-4 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-40 font-medium",
									children: n.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs text-muted-foreground",
									children: ["Starts with", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-20",
										value: n.prefix,
										onChange: (e) => setNumbers((ns) => ns.map((x, j) => j === i ? {
											...x,
											prefix: e.target.value
										} : x))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs text-muted-foreground",
									children: ["Next number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-28",
										type: "number",
										min: 1,
										value: n.next,
										onChange: (e) => setNumbers((ns) => ns.map((x, j) => j === i ? {
											...x,
											next: Number(e.target.value)
										} : x))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										"first one: ",
										n.prefix,
										String(Math.max(1, Math.floor(Number(n.next) || 1))).padStart(6, "0")
									]
								})
							]
						}, n.kind))
					})
				}),
				at === "data" && personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: `${info.name.trim() || "Your books"} ${info.name.trim() ? "is" : "are"} ready`,
					text: "You're now working in these books. Where would you like to start?",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Drop in bank and card statements",
								text: "Drag PDFs or photos into the Shoebox; Tallkeep reads them and records each line.",
								onClick: () => finish("/shoebox")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Put in what you have today",
								text: "The balance of each bank account, card, loan and your home, from the Chart of Accounts.",
								onClick: () => finish("/accounts")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Start with a budget",
								text: "Plan what to spend each month in each category.",
								onClick: () => finish("/budget")
							})
						]
					})
				}),
				at === "data" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: `${info.name.trim() || "Your company"} is ready`,
					text: "You're now working in this company. Bring in your data, or start with an empty company.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Bring in data from inFlow",
								text: "Products, customers, vendors, orders and stock from an inFlow export.",
								onClick: () => finish("/settings#import")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Bring in data from QuickBooks",
								text: "Customers, vendors, items, stock on hand and open invoices, step by step.",
								onClick: () => finish("/settings#quickbooks")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Start empty",
								text: "Add products and customers as you go.",
								onClick: () => finish("/")
							})
						]
					})
				}),
				step < last && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between gap-2 border-t pt-4",
					children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => setStep((s) => s - 1),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							children: "Cancel"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void next(),
						disabled: busy,
						children: [busy ? "Saving…" : at === "details" && !companyId ? personal ? "Create my books" : "Create the company" : at === "kind" ? "Next" : "Save and continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
					})]
				})
			]
		})
	] });
}
function Section({ title, text, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: text
		})] }), children]
	});
}
function Choice({ title, text, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		disabled,
		className: "rounded-xl border p-4 text-left text-sm transition-colors hover:border-[var(--section)] disabled:cursor-not-allowed disabled:opacity-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-xs text-muted-foreground",
			children: text
		})]
	});
}
//#endregion
export { SetupCompany as component };
