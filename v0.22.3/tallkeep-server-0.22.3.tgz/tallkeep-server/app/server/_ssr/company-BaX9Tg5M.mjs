import { n as db } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/company-BaX9Tg5M.js
/** The companies I can open; the active one has active = true. */
function useMyCompanies(enabled = true) {
	return useQuery({
		queryKey: ["my-companies"],
		enabled,
		staleTime: 3e5,
		queryFn: async () => {
			const { data, error } = await db.rpc("my_companies");
			if (error) return [];
			return data ?? [];
		}
	});
}
/** Id of the company I'm working in (records are saved to it). */
async function activeCompanyId() {
	const { data, error } = await db.rpc("active_company");
	if (error) return null;
	return data ?? null;
}
/** Switch company, close the open tabs and start at Home with the new company's records. */
async function switchCompany(id) {
	const { error } = await db.rpc("set_active_company", { _c: id });
	if (error) throw error;
	try {
		localStorage.removeItem("open-tabs");
	} catch {}
	window.location.assign("/");
}
//#endregion
export { switchCompany as n, useMyCompanies as r, activeCompanyId as t };
