//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-bSKLOva0.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-Bb44SEtm.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-LVtAISTC.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BrjDlS89.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bb44SEtm.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-pi0Eec1O.js",
			"/assets/log-out-BWA77Run.js",
			"/assets/testers.functions-B27tcQCD.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CXSm5rGc.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DWq1KWxP.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-Dmzh2Pcf.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/dist-DDu20rl0.js",
			"/assets/dialog-BNWwI7Es.js",
			"/assets/queries-B9a3foPz.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/label-3XPqiBaf.js",
			"/assets/textarea-BBV9LbMv.js",
			"/assets/shoebox-BBVprHs9.js",
			"/assets/company-H8hjoRMq.js",
			"/assets/reports-LJScO8sR.js",
			"/assets/access-CvYHmr3a.js",
			"/assets/LicenseCard-D61TAivt.js",
			"/assets/Logo-CD2DE7Wh.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-hc05FGLM.js",
			"/assets/log-out-BWA77Run.js",
			"/assets/admin.functions-M6n1KrHl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CD2DE7Wh.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CC0b0zlv.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/label-3XPqiBaf.js",
			"/assets/Logo-CD2DE7Wh.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-D3YPOdzq.js",
			"/assets/testers.functions-B27tcQCD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/coupons.functions-B0CiGxcL.js",
			"/assets/buy.functions-CnBEYLj3.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CTPjry2D.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/downloads.functions-DWR27oei.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BlG6ND4F.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/label-3XPqiBaf.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CPHRIduB.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/label-3XPqiBaf.js",
			"/assets/Logo-CD2DE7Wh.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-LNCn1iy-.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/upgrade.functions-BIrxxVva.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CClRAtAv.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/label-3XPqiBaf.js",
			"/assets/Logo-CD2DE7Wh.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CsIzxhzR.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BhTqlrL4.js", "/assets/StockDocList-B8FPw0QR.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BZ2MNj0b.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/ai-IFG1_cF3.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Dgc-UDBe.js",
			"/assets/BankConnections-Cx1Y8WPs.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CeaFd2fN.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DjByEq4a.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-Cx1Y8WPs.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/ai-IFG1_cF3.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DLHxU4iQ.js",
			"/assets/TxnEditor-Bv-gIfve.js",
			"/assets/feedWaiting-BkujtR38.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DtO3EdYr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DBsflIA2.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/personal-B1yAK_Gd.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/WhoPicker-2ck5I7cz.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CwfzzaeA.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-D51RmEID.js", "/assets/AccountRegister-BBo6GTou.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Dp11UDGM.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DjxjD803.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/money-yvYV797q.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-B9OYo0SH.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-IFG1_cF3.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DB-CbEDR.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BAl2EMxV.js", "/assets/StockDocList-B8FPw0QR.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-m54YDAJH.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CkrdpaYk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DxoO2nFl.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CKYGST-1.js", "/assets/PartyList-C9wno_h3.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BxEEE-N-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DEbYps_v.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/storage.functions-DUlVRTyl.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BBJeRWSs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BDRnwGoL.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-CeNdflL6.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BKMHkkRw.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-D1QVXoBP.js", "/assets/ChangeHistory-DxuipliJ.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BO-qbGID.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/members-CiWn-AHq.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-CcE2DAK7.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/personal-B1yAK_Gd.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/WhoPicker-2ck5I7cz.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-1mrcrvMn.js", "/assets/SalesList-DZ7lhlqc.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BtDEuDWO.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-DAvOerEq.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CufuW52L.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-C0JpKhq8.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/loans-DLHxU4iQ.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DCe-pu-p.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-7xQmF6N9.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-rSaEKL4f.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/personal-B1yAK_Gd.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/WhoPicker-2ck5I7cz.js",
			"/assets/reminders-DZUQPWzM.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BhrHLDq4.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-LtCyoK7W.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/personal-B1yAK_Gd.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/WhoPicker-2ck5I7cz.js",
			"/assets/generateCategoricalChart-ajFJs-wS.js",
			"/assets/Area-qSNo9odL.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-BbJo-8ex.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/generateCategoricalChart-ajFJs-wS.js",
			"/assets/PlCharts-CeNdflL6.js",
			"/assets/BarChart-zmdxooD3.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DolghxX9.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BylGqzdM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BBATaSb4.js",
			"/assets/createServerFn-DOKaFF-4.js",
			"/assets/auth-middleware-BtEyCCI3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/storage.functions-DUlVRTyl.js",
			"/assets/coupons.functions-B0CiGxcL.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BRLHSIfV.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BpojtIjo.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/checkbox-BYwPxhxs.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-h1YHGqz5.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BW0p0X-r.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BuppWZ5d.js", "/assets/SalesList-DZ7lhlqc.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BA8zvbz3.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/ai-IFG1_cF3.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DUlVRTyl.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BmZyUw-R.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/money-yvYV797q.js",
			"/assets/badge-BZrFXDDo.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-h745HNws.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BmrTuMUB.js", "/assets/AccountRegister-BBo6GTou.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-ChAq0qwD.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/MoneyAccountPick-yw8kgAB3.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-fwdTTXvg.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-CXUeC1DQ.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/RepeatInvoice-CUkKfsLM.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BZ_yqh6s.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-ajFJs-wS.js",
			"/assets/BarChart-zmdxooD3.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-C0kX8W4y.js", "/assets/SalesList-DZ7lhlqc.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DJBIz_8j.js", "/assets/SalesList-DZ7lhlqc.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CW6l55aK.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-DPyBYNZr.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/serials-B4_hsOfk.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-D7rPvnBM.js",
			"/assets/createServerFn-DOKaFF-4.js",
			"/assets/auth-middleware-BtEyCCI3.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-Cck003gh.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-Ddcakblb.js",
			"/assets/switch-7xQmF6N9.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-DxoO2nFl.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-aRfkINtW.js",
			"/assets/footers-DHTw0TRi.js",
			"/assets/PrintFrame-ecAuUuDR.js",
			"/assets/checkbox-BYwPxhxs.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DDxFQAjp.js",
			"/assets/FeaturePicker-C7pid5I-.js",
			"/assets/support-CXkyr_7V.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-B2BLw8Et.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/FeaturePicker-C7pid5I-.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BQiSBeyW.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ikZ0gGQh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/photos-aRfkINtW.js",
			"/assets/stockmove-cpUg8MaX.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BV09cIL5.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/loans-DLHxU4iQ.js",
			"/assets/feedWaiting-BkujtR38.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DUlVRTyl.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CxnKQIQk.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/PrintFrame-ecAuUuDR.js",
			"/assets/DocPdf-BiM0ISEz.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays--jr4blAu.js",
			"/assets/createServerFn-DOKaFF-4.js",
			"/assets/auth-middleware-BtEyCCI3.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/MoneyAccountPick-yw8kgAB3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CXkyr_7V.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CUw_aNOO.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/StockDialogs-ikZ0gGQh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/stockmove-cpUg8MaX.js",
			"/assets/checkbox-BYwPxhxs.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-CsGxLbMr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/members-CiWn-AHq.js",
			"/assets/WhoPicker-2ck5I7cz.js",
			"/assets/reminders-DZUQPWzM.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BElNYUFy.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/tickets.functions-Cas53yrF.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DJe05Ifn.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CXkyr_7V.js",
			"/assets/support.functions-ShxpQRmm.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BnvSGHHV.js", "/assets/StockDocList-B8FPw0QR.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-LEaBhPr9.js", "/assets/PartyList-C9wno_h3.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BXQ5wbxk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/tickets.functions-Cas53yrF.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DRTKggXy.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/workorders-CTjbOw0c.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-B9Muj6Sx.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-CKjeOQ5I.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/coupons.functions-B0CiGxcL.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CYwQP4lY.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/AdminAccount-DzB4gURa.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-UOhMTS4O.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/downloads.functions-DWR27oei.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BYYnn50V.js",
			"/assets/createServerFn-DOKaFF-4.js",
			"/assets/auth-middleware-BtEyCCI3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CtWOjWdj.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Bg9g9LIQ.js",
			"/assets/testers.functions-B27tcQCD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CAU_f7br.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BWN6DKPW.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CnBEYLj3.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BJz7q8w9.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/textarea-BBV9LbMv.js",
			"/assets/support.functions-ShxpQRmm.js",
			"/assets/HelpParts-BaHuBMHA.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CI7Sibt2.js",
			"/assets/ManualFrame-BVYOg1pk.js",
			"/assets/manual._slug-CxbBLEoh.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Cj6h5qMz.js",
			"/assets/createServerFn-DOKaFF-4.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-f5yO8hAe.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-BIrxxVva.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Ch3KSHNC.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-IFG1_cF3.js",
			"/assets/personal-B1yAK_Gd.js",
			"/assets/reminders-DZUQPWzM.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BKXZkd5G.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/AdminAccount-DzB4gURa.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DdAcmLZL.js", "/assets/ManualFrame-BVYOg1pk.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-UAjwshfa.js", "/assets/AccountRegister-BBo6GTou.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BydRahSE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/OriginalLink-DdTaQ1iG.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/realestate-Leg3AnZO.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-y2H0yYSQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-GaUNFRJI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/realestate-Leg3AnZO.js",
			"/assets/money-yvYV797q.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-_sAbDefv.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/SideList-BDo8z8HJ.js",
			"/assets/PartyHistory-ClAMQtlc.js",
			"/assets/tabs-BUpfxAGe.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BkFnhvMg.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-Cck003gh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DxuipliJ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/SideList-BDo8z8HJ.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-PWcOv-2q.js",
			"/assets/MoneyAccountPick-yw8kgAB3.js",
			"/assets/footers-DHTw0TRi.js",
			"/assets/PrintFrame-ecAuUuDR.js",
			"/assets/serials-B4_hsOfk.js",
			"/assets/SerialsBox-C1-pkQRw.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-KZ-FQiDz.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ikZ0gGQh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DxuipliJ.js",
			"/assets/switch-7xQmF6N9.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BZrFXDDo.js",
			"/assets/SideList-BDo8z8HJ.js",
			"/assets/tabs-BUpfxAGe.js",
			"/assets/photos-aRfkINtW.js",
			"/assets/stockmove-cpUg8MaX.js",
			"/assets/serials-B4_hsOfk.js",
			"/assets/SerialsBox-C1-pkQRw.js",
			"/assets/workorders-CTjbOw0c.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-CJPCBaJx.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-Cck003gh.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DxuipliJ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/SideList-BDo8z8HJ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-PWcOv-2q.js",
			"/assets/MoneyAccountPick-yw8kgAB3.js",
			"/assets/footers-DHTw0TRi.js",
			"/assets/PrintFrame-ecAuUuDR.js",
			"/assets/checkbox-BYwPxhxs.js",
			"/assets/serials-B4_hsOfk.js",
			"/assets/workorders-CTjbOw0c.js",
			"/assets/RepeatInvoice-CUkKfsLM.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-Cas53yrF.js",
			"/assets/users.functions-DDxFQAjp.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BeTqpHTu.js",
			"/assets/select-zp_0_u9n.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/SideList-BDo8z8HJ.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-B4rx_oQB.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/quickadd-Ca7yxj-7.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CXkyr_7V.js",
			"/assets/support.functions-ShxpQRmm.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DxUOUGNM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-0fttpRYS.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/SideList-BDo8z8HJ.js",
			"/assets/PartyHistory-ClAMQtlc.js",
			"/assets/tabs-BUpfxAGe.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CuGlH5Kh.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/sales-DB-CbEDR.js",
			"/assets/footers-DHTw0TRi.js",
			"/assets/tickets.functions-Cas53yrF.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-VEDchWY_.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/input-Du7jcsTp.js",
			"/assets/skeleton-C9-tCDgQ.js",
			"/assets/AdminAccount-DzB4gURa.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CZr4reXf.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-BLf9rFFU.js",
			"/assets/textarea-BBV9LbMv.js",
			"/assets/support-CXkyr_7V.js",
			"/assets/support.functions-ShxpQRmm.js",
			"/assets/HelpParts-BaHuBMHA.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BRdry8pC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-C9-tCDgQ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
