import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/leases-DbZ7NLF7.js
var $$splitComponentImporter = () => import("./leases-BvaIcNzk.mjs");
var Route = createFileRoute("/_authenticated/leases")({
	validateSearch: (s) => {
		const out = {};
		if (typeof s["unit"] === "string") out.unit = s["unit"];
		if (typeof s["lease"] === "string") out.lease = s["lease"];
		return out;
	},
	head: () => ({ meta: [{ title: "Leases & Tenants · Tallkeep" }, {
		name: "description",
		content: "Who rents which unit, for how much, and what they owe."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
