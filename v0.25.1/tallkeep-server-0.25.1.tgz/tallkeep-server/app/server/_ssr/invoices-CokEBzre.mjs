import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as SalesList } from "./SalesList-Djtky38j.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/invoices-CokEBzre.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesList, {
	title: "Invoice List",
	text: "Every invoice and sales order — what shipped and what is still owed.",
	newKind: "order",
	newLabel: "New invoice",
	initial: {
		show: "orders",
		inv: "all",
		pay: "all",
		cancelled: false
	}
});
//#endregion
export { SplitComponent as component };
