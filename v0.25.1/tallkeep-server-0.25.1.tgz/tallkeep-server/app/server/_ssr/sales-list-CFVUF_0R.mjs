import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as SalesList } from "./SalesList-Djtky38j.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-list-CFVUF_0R.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesList, {
	title: "Sales List",
	text: "All quotes, invoices and RMAs. Use the buttons to show just one kind.",
	newKind: "quote",
	newLabel: "New quote",
	initial: {
		show: "all",
		inv: "all",
		pay: "all",
		cancelled: false
	}
});
//#endregion
export { SplitComponent as component };
