import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll, t as REASON_LABEL } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-tdRottJR.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, n as fmtDateTime, r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { $ as MoveRight, Ft as FileText, Nn as ArrowLeft, Qt as ClipboardCheck, R as Plus, S as ShoppingCart, b as Star, bt as ImagePlus, dn as Camera, g as Trash2, n as X, nt as Minus, qt as Copy, xt as ImageOff } from "../_libs/lucide-react.mjs";
import { l as usePriceLists, o as useLocations, r as useCategories, t as byId, u as useShelves } from "./queries-DKvOnwaZ.mjs";
import { n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { n as HistoryButton } from "./ChangeHistory-CpHJor6l.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { t as Switch } from "./switch-Cn1w-cIH.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as CommandItem, c as PopoverContent, i as CommandInput, l as PopoverTrigger, n as CommandEmpty, o as CommandList, r as CommandGroup, s as Popover, t as Command$1, u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { a as useAddCategory } from "./quickadd-CPmfd8Bg.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as SideLayout } from "./SideList-CxhSC804.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CCJRliUM.mjs";
import { a as useProductPhotos, i as usePhotoUrl, n as shrinkImage, r as uploadExtraPhoto, t as PHOTO_BUCKET } from "./photos-cgxXGXuX.mjs";
import { t as ensureShelf } from "./stockmove-Y4hmnaPQ.mjs";
import { r as ScanIntoField } from "./ScanAdd-C305n933.mjs";
import { t as Route } from "./products_._id-CZtbJPVh.mjs";
import { i as stockOnce, n as StockDialog, r as newStockKey } from "./StockDialogs-00ObvYd8.mjs";
import { i as useRecipes, r as useLiteProducts } from "./workorders-CuzhTmEg.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/products_._id-BFBRAAv5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Product photos. On a phone, "Take photo" opens the camera and the picture is saved
* straight away — take as many as you like. The first one becomes the main photo.
*/
function ProductPhoto({ productId, path, size = "lg" }) {
	const qc = useQueryClient();
	const { data: mainUrl } = usePhotoUrl(size === "sm" ? path : null);
	const { data: photos } = useProductPhotos(productId, path);
	const camera = (0, import_react.useRef)(null);
	const gallery = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(0);
	const [view, setView] = (0, import_react.useState)(null);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["photos", productId] });
		qc.invalidateQueries({ queryKey: ["product", productId] });
	};
	async function upload(files) {
		const list = Array.from(files ?? []);
		if (!list.length) return;
		setBusy(list.length);
		let main = path;
		let ok = 0;
		for (const f of list) {
			try {
				const p = await uploadExtraPhoto(productId, await shrinkImage(f));
				if (!main) {
					await db.from("products").update({ picture_path: p }).eq("id", productId);
					main = p;
				}
				ok++;
			} catch (e) {
				toast.error(e.message);
			}
			setBusy((n) => n - 1);
		}
		if (ok) toast.success(ok === 1 ? "Photo saved." : `${ok} photos saved.`);
		refresh();
	}
	async function makeMain(p) {
		if (path && !path.startsWith(`products/${productId}/`)) await db.storage.from(PHOTO_BUCKET).move(path, `products/${productId}/0-main-${Date.now()}.jpg`);
		const { error } = await db.from("products").update({ picture_path: p }).eq("id", productId);
		if (error) toast.error(error.message);
		else {
			toast.success("Main photo changed.");
			refresh();
		}
	}
	async function remove(p) {
		if (!window.confirm("Delete this photo?")) return;
		if (p === path) {
			const next = photos?.find((x) => x.path !== p)?.path ?? null;
			const { error } = await db.from("products").update({ picture_path: next }).eq("id", productId);
			if (error) {
				toast.error(error.message);
				return;
			}
		}
		await db.storage.from(PHOTO_BUCKET).remove([p]);
		setView(null);
		refresh();
	}
	if (size === "sm") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-lg bg-muted text-muted-foreground",
		children: mainUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: mainUrl,
			alt: "",
			className: "h-full w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "h-4 w-4" })
	});
	const main = photos?.[0];
	const shown = view != null ? photos?.[view] : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full space-y-2 sm:w-56",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => main ? setView(0) : camera.current?.click(),
				className: "grid aspect-square w-full place-items-center overflow-hidden rounded-2xl border bg-card",
				children: main ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: main.url,
					alt: "Product",
					className: "h-full w-full object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-col items-center gap-1 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "h-8 w-8" }), " No photo yet"]
				})
			}),
			photos && photos.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 overflow-x-auto pb-1",
				children: photos.map((ph, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setView(i),
					className: `h-12 w-12 shrink-0 overflow-hidden rounded-lg border ${i === 0 ? "ring-2 ring-[var(--section)]" : ""}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: ph.url,
						alt: "",
						className: "h-full w-full object-cover"
					})
				}, ph.path))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: camera,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => {
					upload(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: gallery,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "hidden",
				onChange: (e) => {
					upload(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					disabled: busy > 0,
					onClick: () => camera.current?.click(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
						" ",
						busy > 0 ? `Saving ${busy}…` : "Take photo"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					disabled: busy > 0,
					onClick: () => gallery.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" }), " Choose photos"]
				})]
			}),
			shown && view != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: true,
				onOpenChange: (v) => !v && setView(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-2xl p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "sr-only",
							children: "Photo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: shown.url,
							alt: "Product",
							className: "max-h-[70vh] w-full rounded-lg object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap justify-between gap-2",
							children: [view === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "self-center text-sm text-muted-foreground",
								children: "Main photo"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => void makeMain(shown.path),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4" }), " Make main photo"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void remove(shown.path),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete photo"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => setView(null),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), " Close"]
								})]
							})]
						})
					]
				})
			})
		]
	});
}
var fromRows = (rows) => rows.map((r) => ({
	key: r.id,
	orig: {
		loc: r.location_id,
		shelf: r.shelf,
		qty: Number(r.qty)
	},
	loc: r.location_id,
	shelf: r.shelf,
	qty: String(Number(r.qty))
}));
/** What pressing the row's button will do. */
function actionOf(r) {
	if (!r.orig) return r.loc && Number(r.qty) > 0 ? "add" : null;
	if (r.loc !== r.orig.loc || r.shelf.trim() !== r.orig.shelf) return "move";
	if (r.qty.trim() !== "" && Number(r.qty) !== r.orig.qty) return "count";
	return null;
}
var LABEL = {
	add: "Add here",
	move: "Move",
	count: "Save count"
};
/**
* Like inFlow's Inventory grid: each row is a place + shelf + quantity.
* Change the place or shelf and press Move; change the number and press Save count;
* use "Add another place" when the same item sits in more than one spot.
*/
function WhereItIs({ productId, rows }) {
	const qc = useQueryClient();
	const { data: locations } = useLocations();
	const { data: shelves } = useShelves();
	const [list, setList] = (0, import_react.useState)(() => fromRows(rows));
	const [busy, setBusy] = (0, import_react.useState)(null);
	const sig = rows.map((r) => `${r.id}|${r.location_id}|${r.shelf}|${r.qty}`).join(",");
	(0, import_react.useEffect)(() => setList(fromRows(rows)), [sig]);
	const shelfNames = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(shelves ?? []).forEach((s) => m.set(s.location_id, [...m.get(s.location_id) ?? [], s.name]));
		m.forEach((v) => v.sort((a, b) => a.localeCompare(b, void 0, { numeric: true })));
		return m;
	}, [shelves]);
	const set = (key, p) => setList((l) => l.map((r) => r.key === key ? {
		...r,
		...p
	} : r));
	const keys = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	let step = 0;
	async function rpc(name, args, row) {
		const k = `${row}:${step++}`;
		if (!keys.current.has(k)) keys.current.set(k, newStockKey());
		const { error } = await stockOnce(name, keys.current.get(k), args);
		if (error) throw new Error(error.message);
	}
	async function run(r) {
		const what = actionOf(r);
		if (!what) return;
		const shelf = r.shelf.trim();
		const qty = Number(r.qty);
		if (!Number.isFinite(qty) || qty < 0) {
			toast.error("Type a number.");
			return;
		}
		if (busy) return;
		setBusy(r.key);
		step = 0;
		try {
			await ensureShelf(r.loc, shelf);
			if (what === "add") {
				await rpc("change_stock", {
					_product_id: productId,
					_location_id: r.loc,
					_shelf: shelf,
					_qty_change: qty,
					_reason: "adjust",
					_note: "Added on product page"
				}, r.key);
				toast.success("Added.");
			} else if (what === "count" && r.orig) {
				await rpc("set_stock_count", {
					_product_id: productId,
					_location_id: r.orig.loc,
					_shelf: r.orig.shelf,
					_counted: qty
				}, r.key);
				toast.success("Count saved.");
			} else if (what === "move" && r.orig) {
				const have = r.orig.qty;
				if (have > 0) {
					const n = Math.min(qty, have);
					if (n > 0) await rpc("move_stock", {
						_product_id: productId,
						_from_location: r.orig.loc,
						_from_shelf: r.orig.shelf,
						_to_location: r.loc,
						_to_shelf: shelf,
						_qty: n,
						_note: "Moved on product page"
					}, r.key);
					if (qty > have) await rpc("change_stock", {
						_product_id: productId,
						_location_id: r.loc,
						_shelf: shelf,
						_qty_change: qty - have,
						_reason: "count",
						_note: "Found more while moving"
					}, r.key);
				} else {
					await rpc("set_stock_count", {
						_product_id: productId,
						_location_id: r.orig.loc,
						_shelf: r.orig.shelf,
						_counted: 0
					}, r.key);
					if (qty > 0) await rpc("change_stock", {
						_product_id: productId,
						_location_id: r.loc,
						_shelf: shelf,
						_qty_change: qty,
						_reason: "count",
						_note: "Counted while moving"
					}, r.key);
				}
				toast.success("Moved.");
			}
			for (const k of [...keys.current.keys()]) if (k.startsWith(`${r.key}:`)) keys.current.delete(k);
			qc.invalidateQueries({ queryKey: ["product", productId] });
			qc.invalidateQueries({ queryKey: ["stock"] });
			qc.invalidateQueries({ queryKey: ["products"] });
			qc.invalidateQueries({ queryKey: ["shelves"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(null);
		}
	}
	const total = list.reduce((s, r) => s + (r.orig ? r.orig.qty : 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_72px_96px] gap-2 border-b bg-muted/40 px-3 py-1.5 text-xs font-semibold text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Place" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shelf" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: "Qty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			}),
			list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-3 text-sm text-muted-foreground",
				children: "None in stock. Add a place below."
			}),
			list.map((r) => {
				const what = actionOf(r);
				const listId = `sh-${r.key}`;
				const moving = what === "move" && r.orig;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_72px_96px] items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: r.loc,
									onValueChange: (v) => set(r.key, { loc: v }),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "h-9",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a place" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (locations ?? []).filter((l) => l.is_active || l.id === r.loc).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: l.id,
										children: l.name
									}, l.id)) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									list: listId,
									className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
									placeholder: "No shelf",
									value: r.shelf,
									onChange: (e) => set(r.key, { shelf: e.target.value })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
									id: listId,
									children: (shelfNames.get(r.loc) ?? []).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: n }, n))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: `h-9 min-w-0 rounded-md border bg-background px-2 text-right text-sm font-semibold ${Number(r.qty) < 0 ? "text-destructive" : ""}`,
									inputMode: "decimal",
									value: r.qty,
									onChange: (e) => set(r.key, { qty: e.target.value })
								}),
								what ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => void run(r),
									disabled: busy === r.key,
									children: busy === r.key ? "Saving…" : LABEL[what]
								}) : r.orig ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									"aria-label": "Remove this row",
									onClick: () => setList((l) => l.filter((x) => x.key !== r.key)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
								})
							]
						}),
						moving && r.orig && r.orig.qty > 0 && Number(r.qty) < r.orig.qty && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								"Moves ",
								fmtQty(Number(r.qty) || 0),
								"; ",
								fmtQty(r.orig.qty - (Number(r.qty) || 0)),
								" stay in the old spot."
							]
						}),
						r.orig && what && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "mt-1 text-xs text-muted-foreground underline",
							onClick: () => set(r.key, {
								loc: r.orig.loc,
								shelf: r.orig.shelf,
								qty: String(r.orig.qty)
							}),
							children: "Undo changes"
						})
					]
				}, r.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => setList((l) => [...l, {
						key: `new-${Date.now()}`,
						orig: null,
						loc: l[0]?.loc ?? "",
						shelf: "",
						qty: ""
					}]),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add another place"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-muted-foreground",
					children: ["Total ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-foreground",
						children: fmtQty(total)
					})]
				})]
			})
		]
	});
}
/** What goes into ONE of this product, and the labor added per one. */
function RecipeCard({ productId }) {
	const qc = useQueryClient();
	const { data: products } = useLiteProducts();
	const { data: recipes } = useRecipes();
	const parts = recipes?.get(productId) ?? [];
	const me = products?.find((p) => p.id === productId);
	const [part, setPart] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("1");
	const [extra, setExtra] = (0, import_react.useState)(null);
	const name = new Map((products ?? []).map((p) => [p.id, p]));
	const options = (products ?? []).filter((p) => p.is_active && p.id !== productId && !parts.some((x) => x.part_id === p.id)).map((p) => ({
		value: p.id,
		label: p.name,
		hint: fmtMoney(p.cost)
	}));
	const partsCost = parts.reduce((s, x) => s + x.qty * (name.get(x.part_id)?.cost ?? 0), 0);
	const extraNow = extra ?? String(me?.build_extra_cost ?? 0);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["recipes"] });
		qc.invalidateQueries({ queryKey: ["products-lite"] });
	};
	async function add() {
		if (!part) return void toast.error("Pick a part.");
		if (!(Number(qty) > 0)) return void toast.error("How many go into one?");
		const { error } = await db.from("product_parts").insert({
			product_id: productId,
			part_id: part,
			qty: Number(qty)
		});
		if (error) return void toast.error(error.message);
		setPart("");
		setQty("1");
		refresh();
	}
	async function change(id, q) {
		if (!(q > 0)) return;
		const { error } = await db.from("product_parts").update({ qty: q }).eq("id", id);
		if (error) return void toast.error(error.message);
		refresh();
	}
	async function remove(id) {
		const { error } = await db.from("product_parts").delete().eq("id", id);
		if (error) return void toast.error(error.message);
		refresh();
	}
	async function saveExtra() {
		const { error } = await db.from("products").update({ build_extra_cost: Number(extraNow) || 0 }).eq("id", productId);
		if (error) return void toast.error(error.message);
		toast.success("Saved.");
		setExtra(null);
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "Made from"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "The parts that go into ONE of these. A work order uses them and adds the finished product to stock."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y rounded-xl border text-sm",
				children: [parts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-muted-foreground",
					children: "No parts yet. Add the first one below."
				}), parts.map((x) => {
					const p = name.get(x.part_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: p?.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "any",
								className: "w-24 text-right",
								defaultValue: x.qty,
								onBlur: (e) => Number(e.target.value) !== x.qty && void change(x.id, Number(e.target.value))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24 text-right text-muted-foreground tabular-nums",
								children: fmtMoney(x.qty * (p?.cost ?? 0))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "Remove part",
								onClick: () => void remove(x.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, x.id);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_6rem_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: part,
						onChange: setPart,
						options,
						placeholder: "Add a part"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						step: "any",
						value: qty,
						onChange: (e) => setQty(e.target.value),
						"aria-label": "How many in one"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void add(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add part"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: "Labor and other cost for one"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							className: "w-32",
							value: extraNow,
							onChange: (e) => setExtra(e.target.value)
						})]
					}),
					extra !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => void saveExtra(),
						children: "Save labor cost"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "ml-auto text-right",
						children: [
							"Parts ",
							fmtMoney(partsCost),
							" + labor ",
							fmtMoney(Number(extraNow) || 0),
							" =",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(partsCost + (Number(extraNow) || 0)) }),
							" to build one",
							parts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [
									parts.length,
									" part",
									parts.length === 1 ? "" : "s",
									",",
									" ",
									fmtQty(parts.reduce((s, x) => s + x.qty, 0)),
									" pieces"
								]
							})
						]
					})
				]
			})
		]
	});
}
function ProductPage() {
	const { id } = Route.useParams();
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const { data: cats } = useCategories();
	const catName = byId(cats);
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [copying, setCopying] = (0, import_react.useState)(false);
	const { data: features } = useFeatures();
	const builds = !!features?.includes("work_orders");
	const { data: p, isLoading, error } = useQuery({
		queryKey: ["product", id],
		queryFn: async () => {
			const { data, error } = await db.from("products").select("*, stock(*), product_prices(price, price_list_id, price_lists(name)), vendor_items(id, vendor_code, cost, vendor_id, vendors(id,name))").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: moves } = useQuery({
		queryKey: [
			"product",
			id,
			"moves"
		],
		queryFn: async () => {
			const { data, error } = await db.from("stock_moves").select("*").eq("product_id", id).order("created_at", { ascending: false }).limit(100);
			if (error) throw error;
			return data ?? [];
		}
	});
	const [dialog, setDialog] = (0, import_react.useState)(null);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-2/3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })] });
	if (error || !p) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-destructive",
		children: "Could not load this product."
	}) });
	const rows = (p.stock ?? []).filter((r) => Number(r.qty) !== 0).sort((a, b) => (locName.get(a.location_id) ?? "").localeCompare(locName.get(b.location_id) ?? "") || a.shelf.localeCompare(b.shelf));
	const onHand = rows.reduce((s, r) => s + Number(r.qty), 0);
	const stocked = p.item_type === "stocked";
	const firstVendor = p.vendor_items.find((v) => v.vendors)?.vendors?.id;
	async function copyProduct() {
		if (!p) return;
		setCopying(true);
		const { id: _id, stock: _s, product_prices: prices, vendor_items: _v, picture_path: _pic, created_at: _c, updated_at: _u, inflow_id: _i, ...rest } = p;
		const { data, error } = await db.from("products").insert({
			...rest,
			name: `${p.name} (copy)`,
			barcode: null
		}).select("id").single();
		if (error) {
			toast.error(error.message);
			setCopying(false);
			return;
		}
		if (prices.length) await db.from("product_prices").insert(prices.map((x) => ({
			product_id: data.id,
			price_list_id: x.price_list_id,
			price: x.price
		})));
		setCopying(false);
		toast.success("Copied. Change the name and save.");
		qc.invalidateQueries({ queryKey: ["products"] });
		qc.invalidateQueries({ queryKey: ["side-list"] });
		navigate({
			to: "/products/$id",
			params: { id: data.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
		kind: { type: "product" },
		currentId: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/products",
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " All products"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductPhoto, {
						productId: p.id,
						path: p.picture_path
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
								children: p.name
							}),
							p.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted-foreground",
								children: p.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									!p.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										children: "Inactive"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryButton, {
										id: p.id,
										size: "sm"
									}),
									p.item_type !== "stocked" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: p.item_type === "service" ? "Service" : "Not stocked"
									}),
									p.track_serials && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: "Serial numbers"
									}),
									p.category_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										children: catName.get(p.category_id)
									}),
									p.barcode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										children: ["Barcode ", p.barcode]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/sales/$id",
											params: { id: "new" },
											search: {
												kind: "quote",
												product: p.id
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }), " Quote this item"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/po/$id",
											params: { id: "new" },
											search: {
												product: p.id,
												...firstVendor ? { vendor: firstVendor } : {}
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, { className: "h-4 w-4" }), " Order more from vendor"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => void copyProduct(),
										disabled: copying,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }),
											" ",
											copying ? "Copying…" : "Copy product"
										]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "In stock",
								value: stocked ? fmtQty(onHand) : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Price",
								value: fmtMoney(p.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Cost",
								value: fmtMoney(p.cost)
							})
						]
					})
				]
			}),
			stocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setDialog({ action: "add" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add stock"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setDialog({ action: "remove" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-4 w-4" }), " Take out stock"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setDialog({ action: "count" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-4 w-4" }), " Count stock"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setDialog({ action: "move" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveRight, { className: "h-4 w-4" }), " Move stock"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "details",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "details",
							children: "Details"
						}),
						stocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "history",
							children: "Movement history"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "orders",
							children: "Order history"
						}),
						builds && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "recipe",
							children: "Made from"
						})
					] }),
					builds && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "recipe",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeCard, { productId: p.id })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "details",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid items-start gap-4 lg:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailsForm, { product: p }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									stocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold",
											children: "Where it is"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhereItIs, {
											productId: p.id,
											rows
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PricesCard, { product: p }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VendorsCard, { product: p })
								]
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderHistory, { productId: p.id })
					}),
					stocked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "history",
						children: !moves?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "No changes recorded yet." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "divide-y overflow-hidden rounded-2xl border bg-card",
							children: moves.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-4 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-medium",
										children: [
											REASON_LABEL[m.reason] ?? m.reason,
											" · ",
											locName.get(m.location_id),
											m.shelf ? ` · ${m.shelf}` : ""
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [fmtDateTime(m.created_at), m.note ? ` — ${m.note}` : ""]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: Number(m.qty_change) < 0 ? "font-semibold text-destructive" : "font-semibold text-emerald-600",
									children: [Number(m.qty_change) > 0 ? "+" : "", fmtQty(m.qty_change)]
								})]
							}, m.id))
						})
					})
				]
			}),
			dialog && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockDialog, {
				open: true,
				action: dialog.action,
				preset: dialog.preset,
				productId: p.id,
				productName: p.name,
				rows: p.stock ?? [],
				onOpenChange: (v) => !v && setDialog(null)
			}, `${dialog.action}-${dialog.preset?.location_id ?? ""}-${dialog.preset?.shelf ?? ""}`)
		] })
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border bg-card px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg font-bold",
			children: value
		})]
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border border-dashed bg-card p-8 text-center text-muted-foreground",
		children: text
	});
}
function DetailsForm({ product }) {
	const addCategoryNow = useAddCategory();
	const qc = useQueryClient();
	const { data: cats } = useCategories();
	const { data: locations } = useLocations();
	const [f, setF] = (0, import_react.useState)(product);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setF(product), [product]);
	const set = (k, v) => setF((x) => ({
		...x,
		[k]: v
	}));
	const numOrNull = (v) => v.trim() === "" ? null : Number(v);
	async function save(e) {
		e.preventDefault();
		if (!f.name.trim()) {
			toast.error("Name can't be empty.");
			return;
		}
		setBusy(true);
		const { error } = await db.from("products").update({
			name: f.name.trim(),
			description: f.description,
			barcode: f.barcode,
			unit: f.unit,
			category_id: f.category_id,
			reorder_point: f.reorder_point,
			reorder_qty: f.reorder_qty,
			default_location_id: f.default_location_id,
			default_shelf: f.default_shelf,
			remarks: f.remarks,
			is_active: f.is_active
		}).eq("id", product.id);
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Product saved.");
		qc.invalidateQueries({ queryKey: ["product", product.id] });
		qc.invalidateQueries({ queryKey: ["products"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.name,
							onChange: (e) => set("name", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Barcode",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.barcode ?? "",
								onChange: (e) => set("barcode", e.target.value || null)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanIntoField, { onCode: (c) => set("barcode", c) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Description",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							value: f.description ?? "",
							onChange: (e) => set("description", e.target.value || null)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: f.category_id ?? "none",
							onChange: (v) => set("category_id", v === "none" ? null : v),
							options: [{
								value: "none",
								label: "No category"
							}, ...(cats ?? []).map((c) => ({
								value: c.id,
								label: c.name
							}))],
							placeholder: "Choose a category",
							searchText: "Type a category",
							onAdd: addCategoryNow,
							addLabel: "Add new category"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Unit (e.g. ea, box)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.unit ?? "",
							onChange: (e) => set("unit", e.target.value || null)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Warn me when stock falls to",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: f.reorder_point ?? "",
							onChange: (e) => set("reorder_point", numOrNull(e.target.value))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Usual reorder amount",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: f.reorder_qty ?? "",
							onChange: (e) => set("reorder_qty", numOrNull(e.target.value))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Usual place",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: f.default_location_id ?? "none",
							onValueChange: (v) => set("default_location_id", v === "none" ? null : v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "none",
								children: "Not set"
							}), (locations ?? []).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: l.id,
								children: l.name
							}, l.id))] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Usual shelf",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.default_shelf ?? "",
							onChange: (e) => set("default_shelf", e.target.value || null)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							value: f.remarks ?? "",
							onChange: (e) => set("remarks", e.target.value || null)
						})
					})
				]
			}),
			Object.keys(f.custom ?? {}).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-muted/50 p-3 text-sm",
				children: Object.entries(f.custom).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [k, ":"]
					}),
					" ",
					v
				] }, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: f.is_active,
						onCheckedChange: (v) => set("is_active", v)
					}), " Active (show in lists)"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "Saving…" : "Save product"
				})]
			})
		]
	});
}
function Field({ label, wide, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: wide ? "space-y-1.5 sm:col-span-2" : "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function OrderHistory({ productId }) {
	const { data } = useQuery({
		queryKey: [
			"product",
			productId,
			"orders"
		],
		queryFn: async () => {
			const [so, po] = await Promise.all([db.from("sales_order_lines").select("id,qty,unit_price,sales_orders(id,number,status,order_date,customer_name)").eq("product_id", productId).limit(1e3), db.from("purchase_order_lines").select("id,qty,unit_cost,purchase_orders(id,number,status,order_date,vendor_name)").eq("product_id", productId).limit(1e3)]);
			return [...(so.data ?? []).filter((r) => r.sales_orders).map((r) => ({
				id: r.id,
				kind: "sale",
				docId: r.sales_orders.id,
				number: r.sales_orders.number,
				status: r.sales_orders.status,
				date: r.sales_orders.order_date,
				who: r.sales_orders.customer_name,
				qty: Number(r.qty),
				price: Number(r.unit_price)
			})), ...(po.data ?? []).filter((r) => r.purchase_orders).map((r) => ({
				id: r.id,
				kind: "buy",
				docId: r.purchase_orders.id,
				number: r.purchase_orders.number,
				status: r.purchase_orders.status,
				date: r.purchase_orders.order_date,
				who: r.purchase_orders.vendor_name,
				qty: Number(r.qty),
				price: Number(r.unit_cost)
			}))].sort((a, b) => b.date.localeCompare(a.date));
		}
	});
	if (!data?.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Not on any order yet." });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-2xl border bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2",
						children: "Date"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2",
						children: "Order #"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2",
						children: "Customer / vendor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2 text-right",
						children: "Qty"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2 text-right",
						children: "Price"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
				className: "divide-y",
				children: data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: r.status === "cancelled" ? "text-muted-foreground line-through" : "",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap px-3 py-2",
							children: fmtDateTime(r.date).split(",").slice(0, 2).join(",")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap px-3 py-2",
							children: r.kind === "sale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/sales/$id",
								params: { id: r.docId },
								search: {},
								className: "text-primary",
								children: r.number
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/po/$id",
								params: { id: r.docId },
								search: {},
								className: "text-primary",
								children: r.number
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "max-w-[300px] truncate px-3 py-2",
							children: r.who
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: `px-3 py-2 text-right font-semibold ${r.kind === "sale" ? "" : "text-emerald-700"}`,
							children: [r.kind === "sale" ? "−" : "+", fmtQty(r.qty)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 text-right",
							children: fmtMoney(r.price)
						})
					]
				}, r.id))
			})]
		})
	});
}
/** Normal price and every price list, with markup over cost — like inFlow. */
function PricesCard({ product }) {
	const qc = useQueryClient();
	const { data: lists } = usePriceLists();
	const start = () => {
		const m = { normal: String(Number(product.price) || 0) };
		product.product_prices.forEach((x) => {
			if (Number(x.price) > 0) m[x.price_list_id] = String(Number(x.price));
		});
		return m;
	};
	const [vals, setVals] = (0, import_react.useState)(start);
	const [cost, setCost] = (0, import_react.useState)(String(Number(product.cost) || 0));
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setVals(start());
		setCost(String(Number(product.cost) || 0));
	}, [product]);
	const c = Number(cost) || 0;
	const markup = (v) => {
		const n = Number(v);
		if (!c || !v || !Number.isFinite(n)) return "";
		return `${Math.round((n - c) / c * 100)}%`;
	};
	const rows = [{
		key: "normal",
		name: "Normal price"
	}, ...(lists ?? []).filter((l) => !l.is_default && (l.is_active || vals[l.id] != null)).map((l) => ({
		key: l.id,
		name: l.name === "Cost" ? "Cost price list" : l.name
	}))];
	async function save() {
		setBusy(true);
		try {
			const { error } = await db.from("products").update({
				price: Number(vals["normal"]) || 0,
				cost: c
			}).eq("id", product.id);
			if (error) throw error;
			const keep = rows.filter((r) => r.key !== "normal" && (vals[r.key] ?? "").trim() !== "");
			const drop = rows.filter((r) => r.key !== "normal" && (vals[r.key] ?? "").trim() === "");
			if (keep.length) {
				const { error: e2 } = await db.from("product_prices").upsert(keep.map((r) => ({
					product_id: product.id,
					price_list_id: r.key,
					price: Number(vals[r.key]) || 0
				})), { onConflict: "product_id,price_list_id" });
				if (e2) throw e2;
			}
			if (drop.length) await db.from("product_prices").delete().eq("product_id", product.id).in("price_list_id", drop.map((r) => r.key));
			toast.success("Prices saved.");
			qc.invalidateQueries({ queryKey: ["product", product.id] });
			qc.invalidateQueries({ queryKey: ["products"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b px-4 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Cost and prices"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Saving…" : "Save prices"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[minmax(0,1fr)_120px_70px] items-center gap-2 px-4 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Cost"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "h-8 rounded-md border bg-background px-2 text-right",
						inputMode: "decimal",
						value: cost,
						onChange: (e) => setCost(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right text-xs text-muted-foreground",
						children: "Markup"
					}),
					rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceRow, {
						name: r.name,
						value: vals[r.key] ?? "",
						markup: markup(vals[r.key]),
						onChange: (v) => setVals((x) => ({
							...x,
							[r.key]: v
						}))
					}, r.key))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-t px-4 py-2 text-xs text-muted-foreground",
				children: "Leave a price list empty to use the normal price for those customers."
			})
		]
	});
}
function PriceRow({ name, value, markup, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: name }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "h-8 rounded-md border bg-background px-2 text-right",
			inputMode: "decimal",
			placeholder: "—",
			value,
			onChange: (e) => onChange(e.target.value)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-right text-xs text-muted-foreground",
			children: markup
		})
	] });
}
/** Who we buy this from, their code for it and what they charge. */
function VendorsCard({ product }) {
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "pick"],
		queryFn: () => fetchAll("vendors", "id,name,is_active")
	});
	const refresh = () => void qc.invalidateQueries({ queryKey: ["product", product.id] });
	const have = new Set(product.vendor_items.map((v) => v.vendor_id));
	async function add(vendorId) {
		setOpen(false);
		const { error } = await db.from("vendor_items").insert({
			vendor_id: vendorId,
			product_id: product.id,
			cost: Number(product.cost) || 0
		});
		if (error) toast.error(error.message);
		else {
			toast.success("Vendor added.");
			refresh();
		}
	}
	async function update(id, patch) {
		const { error } = await db.from("vendor_items").update(patch).eq("id", id);
		if (error) toast.error(error.message);
		else refresh();
	}
	async function remove(id) {
		const { error } = await db.from("vendor_items").delete().eq("id", id);
		if (error) toast.error(error.message);
		else refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between border-b px-4 py-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold",
				children: "Vendors"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
				open,
				onOpenChange: setOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a vendor"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
					className: "w-72 p-0",
					align: "end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: "Search vendors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No vendor found." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, { children: (vendors ?? []).filter((v) => v.is_active !== false && !have.has(v.id)).sort((a, b) => a.name.localeCompare(b.name)).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
						value: `${v.name} ${v.id}`,
						onSelect: () => void add(v.id),
						children: v.name
					}, v.id)) })] })] })
				})]
			})]
		}), product.vendor_items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-4 py-3 text-sm text-muted-foreground",
			children: "No vendors yet. Press Add a vendor."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[minmax(0,1fr)_110px_100px_36px] gap-2 px-4 py-1.5 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Vendor" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Their code" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: "Their price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				}),
				product.vendor_items.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[minmax(0,1fr)_110px_100px_36px] items-center gap-2 px-4 py-1.5 text-sm",
					children: [
						v.vendors ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/vendors/$id",
							params: { id: v.vendors.id },
							className: "truncate hover:underline",
							children: v.vendors.name
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "?" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-8 rounded-md border bg-background px-2",
							defaultValue: v.vendor_code ?? "",
							placeholder: "—",
							onBlur: (e) => {
								const val = e.target.value.trim() || null;
								if (val !== v.vendor_code) update(v.id, { vendor_code: val });
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-8 rounded-md border bg-background px-2 text-right",
							inputMode: "decimal",
							defaultValue: String(Number(v.cost)),
							onBlur: (e) => {
								const n = Number(e.target.value) || 0;
								if (n !== Number(v.cost)) update(v.id, { cost: n });
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							"aria-label": "Remove this vendor",
							onClick: () => void remove(v.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, v.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 py-2 text-xs text-muted-foreground",
					children: "Changes save when you click away."
				})
			]
		})]
	});
}
//#endregion
export { ProductPage as component };
