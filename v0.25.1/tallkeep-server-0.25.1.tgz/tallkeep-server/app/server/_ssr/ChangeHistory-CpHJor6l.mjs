import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { wt as History } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ChangeHistory-CpHJor6l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Change history: who changed what, when, and what it was before. Read-only; written by the
* database on every save (step 069).
*/
var THING = {
	sales_orders: "Quote / invoice",
	sales_order_lines: "Line",
	payments: "Payment",
	purchase_orders: "Purchase order",
	purchase_order_lines: "PO line",
	bills: "Bill",
	bill_lines: "Bill line",
	bill_payments: "Bill payment",
	journal_entries: "Journal entry",
	journal_lines: "Journal line",
	bank_transactions: "Bank line",
	accounts: "Account",
	customers: "Customer",
	vendors: "Vendor",
	products: "Product",
	stock_docs: "Stock document",
	tax_rates: "Sales tax",
	company_settings: "Company settings"
};
var thingName = (t) => THING[t] ?? t.replace(/_/g, " ");
var HIDE = /* @__PURE__ */ new Set([
	"id",
	"company_id",
	"created_by",
	"inflow_id",
	"custom"
]);
var field = (k) => k.replace(/_id$/, "").replace(/_/g, " ");
var show = (v) => v === null || v === void 0 || v === "" ? "(empty)" : typeof v === "object" ? JSON.stringify(v).slice(0, 80) : String(v).slice(0, 120);
/** One change in words: "Phone: (214) 555-0101 → 555-9999". */
function ChangeLines({ c }) {
	if (c.action === "update") {
		const keys = Object.keys(c.after ?? {}).filter((k) => !HIDE.has(k));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-0.5",
			children: keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [field(k), ":"]
				}),
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "line-through decoration-muted-foreground/60",
					children: show(c.before?.[k])
				}),
				" ",
				"→ ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: show(c.after?.[k]) })
			] }, k))
		});
	}
	const row = (c.action === "insert" ? c.after : c.before) ?? {};
	const bits = [
		"number",
		"name",
		"description",
		"amount",
		"qty",
		"unit_price",
		"total",
		"debit",
		"credit",
		"status"
	].filter((k) => row[k] !== void 0 && row[k] !== null && row[k] !== "" && Number(row[k]) !== 0).map((k) => `${field(k)} ${show(row[k])}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: bits.join(" · ")
	});
}
function ChangeRow({ c, showThing = true }) {
	const verb = c.action === "insert" ? "added" : c.action === "delete" ? "deleted" : "changed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "space-y-1 p-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: new Date(c.at).toLocaleString(void 0, {
					dateStyle: "medium",
					timeStyle: "short"
				})
			}),
			" ",
			"· ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: c.user_email ?? "Tallkeep" }),
			" ",
			verb,
			" ",
			showThing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [thingName(c.table_name).toLowerCase(), " "] }),
			c.label && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: c.label
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeLines, { c })]
	});
}
/** "History" on a document or record: its changes, and its lines' and payments'. */
function HistoryButton({ id, size = "default" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const { data, error } = useQuery({
		queryKey: ["change-log", id],
		enabled: open,
		queryFn: async () => {
			const { data, error } = await db.from("change_log").select("*").or(`doc_id.eq.${id},row_id.eq.${id}`).order("at", { ascending: false }).limit(300);
			if (error) throw error;
			return data ?? [];
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size,
		onClick: () => setOpen(true),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "h-4 w-4" }), " History"]
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && setOpen(false),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "History" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Every change, who made it and what it was before. Nobody can edit this list." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-[60vh] overflow-auto rounded-xl border",
				children: error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-3 text-sm text-muted-foreground",
					children: "History isn't available yet (the database needs its next update) or you don't have the Accounting section."
				}) : !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-3 text-sm text-muted-foreground",
					children: "Loading…"
				}) : data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-3 text-sm text-muted-foreground",
					children: "No changes recorded yet. Changes are recorded from this version on."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y",
					children: data.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeRow, { c }, c.id))
				})
			})]
		})
	})] });
}
//#endregion
export { HistoryButton as n, thingName as r, ChangeRow as t };
