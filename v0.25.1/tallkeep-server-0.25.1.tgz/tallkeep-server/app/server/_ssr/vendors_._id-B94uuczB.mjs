import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Nn as ArrowLeft, R as Plus } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PartyForm } from "./PartyForm-Dzs1bcSX.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as SideLayout } from "./SideList-CxhSC804.mjs";
import { n as VendorHistory, r as nameMatch } from "./PartyHistory-BDTAuLVd.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-CCJRliUM.mjs";
import { t as Route } from "./vendors_._id-Dr91UBPq.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/vendors_._id-B94uuczB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VendorPage() {
	const { id } = Route.useParams();
	const { data: v, isLoading } = useQuery({
		queryKey: ["vendor", id],
		queryFn: async () => {
			const { data, error } = await db.from("vendors").select("*").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: pos } = useQuery({
		queryKey: [
			"vendor",
			id,
			"pos",
			v?.name
		],
		enabled: !!v,
		queryFn: async () => {
			const { data, error } = await db.from("purchase_orders").select("id,number,status,order_date,total,amount_paid,balance,stock_received_at,vendor_order_number").or(`vendor_id.eq.${id},and(vendor_id.is.null,${nameMatch("vendor_name", v.name)})`).order("order_date", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: items } = useQuery({
		queryKey: [
			"vendor",
			id,
			"items"
		],
		queryFn: async () => {
			const { data, error } = await db.from("vendor_items").select("id,vendor_code,cost,products(id,name)").eq("vendor_id", id);
			if (error) throw error;
			return data ?? [];
		}
	});
	if (isLoading || !v) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
			kind: { type: "vendor" },
			currentId: id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })] })
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
		kind: { type: "vendor" },
		currentId: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/vendors",
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " All vendors"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-bold sm:text-3xl",
				children: v.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: [
					v.contact_name,
					v.phone,
					v.email
				].filter(Boolean).join(" · ")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/po/$id",
						params: { id: "new" },
						search: { vendor: v.id },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New purchase order"]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "pos",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "pos",
							children: [
								"Purchase orders (",
								pos?.length ?? 0,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "items",
							children: [
								"Products (",
								items?.length ?? 0,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "details",
							children: "Details"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "pos",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VendorHistory, {
							pos: pos ?? [],
							vendorId: id
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "items",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "divide-y overflow-hidden rounded-2xl border bg-card",
							children: [(items ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "p-6 text-center text-muted-foreground",
								children: "No products saved for this vendor."
							}), (items ?? []).map((i) => i.products && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/products/$id",
								params: { id: i.products.id },
								className: "flex items-center gap-3 px-4 py-3 hover:bg-muted/50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "min-w-0 flex-1 truncate",
									children: [i.products.name, i.vendor_code ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [" · ", i.vendor_code]
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: fmtMoney(i.cost)
								})]
							}, i.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "details",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyForm, {
							kind: "vendors",
							record: v
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tax1099, { v })]
					})
				]
			})
		] })
	});
}
/** Does this vendor get a 1099 at year-end, and their Tax ID (EIN or SSN) for it. */
function Tax1099({ v }) {
	const qc = useQueryClient();
	const [on, setOn] = (0, import_react.useState)(!!v.is_1099);
	const [taxId, setTaxId] = (0, import_react.useState)(v.tax_id ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const changed = on !== !!v.is_1099 || taxId.trim() !== (v.tax_id ?? "");
	async function save() {
		setBusy(true);
		const { error } = await db.from("vendors").update({
			is_1099: on,
			tax_id: taxId.trim() || null
		}).eq("id", v.id);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Saved.");
		qc.invalidateQueries({ queryKey: ["vendor", v.id] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 space-y-3 rounded-2xl border bg-card p-4 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "Year-end 1099"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-start gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "mt-1",
					checked: on,
					onChange: (e) => setOn(e.target.checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["This vendor gets a 1099", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: "Usually people and companies that do services for you (contractors, installers, landlords, lawyers) and aren't corporations. Ask your accountant if unsure."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block max-w-xs space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: "Tax ID (EIN or SSN, from their W-9)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: taxId,
					onChange: (e) => setTaxId(e.target.value),
					placeholder: "12-3456789"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				onClick: () => void save(),
				disabled: !changed || busy,
				children: busy ? "Saving…" : "Save 1099 details"
			})
		]
	});
}
//#endregion
export { VendorPage as component };
