import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, p as useTotals } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { a as holdingValue, d as table, i as amountIn, m as useHoldings, o as isInvestment } from "./personal-C-Op5nYv.mjs";
import { H as Pencil, R as Plus, Xt as ClipboardPaste, g as Trash2 } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as useWho, r as useAccountOwners } from "./members-BvdxHr68.mjs";
import { t as WhoPicker } from "./WhoPicker-DLJRzcvg.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/investments-Bo_1fzZ9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var num = (s) => Number(s.replace(/[$,\s]/g, "") || 0);
function Investments() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: totals } = useTotals(null, today());
	const { data: everyHolding } = useHoldings();
	const [who] = useWho();
	const { data: owners } = useAccountOwners();
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [paste, setPaste] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)("");
	const [renaming, setRenaming] = (0, import_react.useState)(null);
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const stmts = useQuery({
		queryKey: ["investment-statements", year],
		queryFn: async () => {
			const { data, error } = await db.from("investment_statements").select("account_id,period_end,ending_value,ytd").gte("period_end", `${year}-01-01`).order("period_end", { ascending: false });
			if (error) return /* @__PURE__ */ new Map();
			const m = /* @__PURE__ */ new Map();
			for (const r of data ?? []) if (!m.has(r.account_id)) m.set(r.account_id, r);
			return m;
		}
	});
	if (!accounts || !everyHolding) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	const invest = accounts.filter((a) => a.is_active && isInvestment(a) && (!who || owners?.get(a.id) === who));
	const holdings = everyHolding.filter((h) => invest.some((a) => a.id === h.account_id));
	const refresh = () => void qc.invalidateQueries({ queryKey: ["holdings"] });
	async function addAccount() {
		const name = newName.trim();
		if (!name) return void toast.error("Type a name, like Fidelity IRA.");
		const { error } = await db.from("accounts").insert({
			name,
			type: "asset",
			kind: "other_asset"
		});
		if (error) return void toast.error(error.message);
		setNewName("");
		await qc.invalidateQueries({ queryKey: ["accounts"] });
		toast.success(`Added ${name}.`);
	}
	async function rename(a) {
		const name = renaming?.name.trim();
		setRenaming(null);
		if (!name || name === a.name) return;
		const { error } = await db.from("accounts").update({ name }).eq("id", a.id);
		if (error) return void toast.error(error.message);
		await qc.invalidateQueries({ queryKey: ["accounts"] });
	}
	/** Take an account out of Investments (its funds are deleted; its book entries stay). */
	async function removeAccount(a) {
		if (!window.confirm(`Remove ${a.name} from Investments? What it holds is deleted. Anything in your books for it stays (it's hidden, not deleted).`)) return;
		const h = await table("holdings").delete().eq("account_id", a.id);
		if (h.error) return void toast.error(h.error.message);
		const { error } = await db.from("accounts").update({ is_active: false }).eq("id", a.id);
		if (error) return void toast.error(error.message);
		await qc.invalidateQueries({ queryKey: ["accounts"] });
		refresh();
		toast.success(`Removed ${a.name}.`);
	}
	async function remove(h) {
		const { error } = await table("holdings").delete().eq("id", h.id);
		if (error) return void toast.error(error.message);
		refresh();
	}
	const all = holdings.reduce((s, h) => s + holdingValue(h), 0);
	const allCost = holdings.reduce((s, h) => s + h.cost, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Investments",
			text: "What's in each investment or retirement account. Type the latest prices (or paste a list) and Net Worth uses them.",
			actions: holdings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => setPaste(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, { className: "h-4 w-4" }), " Update prices"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoPicker, {}),
		(() => {
			const latest = [...stmts.data?.values() ?? []].filter((x) => invest.some((a) => a.id === x.account_id));
			if (!latest.length) return null;
			const sum = (k) => latest.reduce((t, x) => t + (x.ytd?.[k] ?? 0), 0);
			const realized = sum("realized_short") + sum("realized_long");
			const income = sum("dividends") + sum("interest");
			const change = sum("change_in_value");
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "This year, from your statements"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Gain or loss this year (change in value)",
								value: change,
								good: change >= 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Realized gains (from sales; for taxes)",
								value: realized,
								good: realized >= 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Dividends and interest (for taxes)",
								value: income
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "As the statements show them. For your tax return, your CPA uses the 1099 your broker sends early next year; these numbers let you see it coming."
					})
				]
			});
		})(),
		holdings.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Worth today",
					value: all
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "What it cost",
					value: allCost
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: all >= allCost ? "Paper gain on what you hold now" : "Paper loss on what you hold now",
					value: all - allCost,
					good: all >= allCost
				})
			]
		}),
		invest.map((a) => {
			const rows = holdings.filter((h) => h.account_id === a.id);
			const value = rows.reduce((s, h) => s + holdingValue(h), 0);
			const putIn = amountIn(a, totals);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border bg-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [renaming?.id === a.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoFocus: true,
							className: "h-8",
							value: renaming.name,
							onChange: (e) => setRenaming({
								id: a.id,
								name: e.target.value
							}),
							onKeyDown: (e) => {
								if (e.key === "Enter") rename(a);
								if (e.key === "Escape") setRenaming(null);
							},
							onBlur: () => void rename(a)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-semibold",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: rows.length ? `Worth ${fmtMoney(value)} · put in ${fmtMoney(putIn)} (from your books)` : `${fmtMoney(putIn)} in your books. Add what it holds to see today's value.`
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => setEdit({
										account: a,
										h: {}
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a stock or fund"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => setRenaming({
										id: a.id,
										name: a.name
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" }), " Rename"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void removeAccount(a),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Remove"]
								})
							]
						})]
					}),
					(() => {
						const st = stmts.data?.get(a.id);
						if (!st) return null;
						const y = st.ytd ?? {};
						const shown = [
							["Put in", y.deposits],
							["Taken out", y.withdrawals],
							["Fees", y.fees],
							["Dividends", y.dividends],
							["Interest", y.interest],
							["Realized short-term", y.realized_short],
							["Realized long-term", y.realized_long],
							["Change in value", y.change_in_value]
						].filter(([, v]) => v != null && v !== 0);
						if (!shown.length) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b px-4 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"This year, from the ",
									fmtDate(st.period_end),
									" statement"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 flex flex-wrap gap-x-5 gap-y-1",
								children: shown.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: k
									}),
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium tabular-nums",
										children: fmtMoney(v)
									})
								] }, k))
							})]
						});
					})(),
					rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-xs text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 text-left font-normal",
											children: "Name"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 font-normal",
											children: "Shares"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 font-normal",
											children: "Price"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 font-normal",
											children: "Worth"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 font-normal",
											children: "Cost"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 font-normal",
											children: "Paper gain"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-20" })
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((h) => {
								const v = holdingValue(h);
								const g = v - h.cost;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t text-right tabular-nums",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-2 text-left",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: h.symbol || h.name
											}), h.symbol && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "ml-2 text-muted-foreground",
												children: h.name
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2",
											children: Number(h.shares.toFixed(6))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-2 py-2",
											children: [fmtMoney(h.price), h.price_date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-xs text-muted-foreground",
												children: fmtDate(h.price_date)
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2 font-medium",
											children: fmtMoney(v)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2",
											children: fmtMoney(h.cost)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: cn("px-2 py-2", g < 0 ? "text-destructive" : "text-emerald-700"),
											children: [fmtMoney(g), h.cost > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-xs",
												children: [(g / h.cost * 100).toFixed(1), "%"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-end gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													variant: "ghost",
													size: "icon",
													"aria-label": `Change ${h.name}`,
													onClick: () => setEdit({
														account: a,
														h
													}),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													variant: "ghost",
													size: "icon",
													"aria-label": `Remove ${h.name}`,
													onClick: () => void remove(h),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
												})]
											})
										})
									]
								}, h.id);
							}) })]
						})
					})
				]
			}, a.id);
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "space-y-2 rounded-2xl border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Add an investment or retirement account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex max-w-lg gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						"aria-label": "Account name",
						placeholder: "Like Fidelity IRA or Robinhood",
						value: newName,
						onChange: (e) => setNewName(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && void addAccount()
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void addAccount(),
						children: "Add account"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Money you move into it from the bank is a Transfer. Its value comes from the stocks and funds you add here."
				})
			]
		}),
		edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoldingDialog, {
			edit,
			onClose: () => setEdit(null),
			onSaved: refresh
		}),
		paste && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasteDialog, {
			holdings,
			onClose: () => setPaste(false),
			onSaved: refresh
		})
	] });
}
function Tile({ label, value, good }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-2xl font-semibold tabular-nums", good === true && "text-emerald-700", good === false && "text-destructive"),
			children: fmtMoney(value)
		})]
	});
}
function HoldingDialog({ edit, onClose, onSaved }) {
	const h = edit.h;
	const [symbol, setSymbol] = (0, import_react.useState)(h.symbol ?? "");
	const [name, setName] = (0, import_react.useState)(h.name ?? "");
	const [shares, setShares] = (0, import_react.useState)(h.shares != null ? String(h.shares) : "");
	const [cost, setCost] = (0, import_react.useState)(h.cost != null ? String(h.cost) : "");
	const [price, setPrice] = (0, import_react.useState)(h.price != null ? String(h.price) : "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		const row = {
			account_id: edit.account.id,
			symbol: symbol.trim().toUpperCase() || null,
			name: name.trim() || symbol.trim().toUpperCase(),
			shares: num(shares),
			cost: num(cost),
			price: num(price),
			price_date: price !== String(h.price ?? "") ? today() : h.price_date ?? today(),
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		};
		if (!row.name) return void toast.error("Type the name or the symbol.");
		if (![
			row.shares,
			row.cost,
			row.price
		].every(Number.isFinite)) return void toast.error("Shares, cost and price must be numbers.");
		setBusy(true);
		const { error } = h.id ? await table("holdings").update(row).eq("id", h.id) : await table("holdings").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		onSaved();
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: h.id ? `Change ${h.symbol || h.name}` : `Add a stock or fund to ${edit.account.name}` }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Symbol (if it has one)",
						value: symbol,
						set: setSymbol,
						placeholder: "VTI"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						value: name,
						set: setName,
						placeholder: "Vanguard Total Stock Market"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Shares",
						value: shares,
						set: setShares,
						placeholder: "10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What all the shares cost",
						value: cost,
						set: setCost,
						placeholder: "2,000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Price of one share today",
						value: price,
						set: setPrice,
						placeholder: "245.10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end text-sm text-muted-foreground",
						children: ["Worth: ", fmtMoney(num(shares) * num(price))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: "Save"
			})] })
		] })
	});
}
function Field({ label, value, set, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value,
			onChange: (e) => set(e.target.value),
			placeholder
		})]
	});
}
/** Paste "VTI 245.10" lines (or two columns from a spreadsheet) to update many prices at once. */
function PasteDialog({ holdings, onClose, onSaved }) {
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const pairs = text.split(/\r?\n/).map((l) => l.trim().match(/^([A-Za-z0-9.\-^]+)[\s,\t]+\$?([\d,]+(?:\.\d+)?)/)).filter((m) => !!m).map((m) => ({
		symbol: m[1].toUpperCase(),
		price: num(m[2])
	}));
	const hits = pairs.flatMap((p) => holdings.filter((h) => h.symbol === p.symbol).map((h) => ({
		h,
		price: p.price
	})));
	const unknown = pairs.filter((p) => !holdings.some((h) => h.symbol === p.symbol)).map((p) => p.symbol);
	async function save() {
		setBusy(true);
		try {
			for (const { h, price } of hits) {
				const { error } = await table("holdings").update({
					price,
					price_date: today(),
					updated_at: (/* @__PURE__ */ new Date()).toISOString()
				}).eq("id", h.id);
				if (error) throw new Error(error.message);
			}
			toast.success(`Updated ${hits.length === 1 ? "1 price" : `${hits.length} prices`}.`);
			onSaved();
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const symbols = [...new Set(holdings.map((h) => h.symbol).filter(Boolean))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Update prices" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "One per line: the symbol, then today's price. You can copy two columns from a spreadsheet or your broker's page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				rows: 8,
				value: text,
				onChange: (e) => setText(e.target.value),
				placeholder: symbols.slice(0, 3).map((s, i) => `${s} ${[
					245.1,
					88.2,
					410
				][i]}`).join("\n") || "VTI 245.10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					hits.length === 1 ? "1 price" : `${hits.length} prices`,
					" to update",
					unknown.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [" · not found here: ", unknown.join(", ")]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void save(),
				disabled: busy || !hits.length,
				children: ["Update ", hits.length === 1 ? "1 price" : `${hits.length} prices`]
			})] })
		] })
	});
}
//#endregion
export { Investments as component };
