import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { g as Trash2, jn as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-Dzs1bcSX.mjs";
import { t as Route } from "./bank-transfers-C9uhtyOy.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bank-transfers-CEnDjoUJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Transfers() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: list } = useQuery({
		queryKey: ["transfers"],
		queryFn: async () => {
			const { data, error } = await db.from("transfers").select("*").order("transfer_date", { ascending: false }).limit(500);
			if (error) throw error;
			return data ?? [];
		}
	});
	const money = (accounts ?? []).filter((a) => a.is_active && [
		"bank",
		"credit_card",
		"other_asset",
		"other_liability",
		"long_term_liability",
		"equity"
	].includes(a.kind));
	const opts = money.map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)(Route.useSearch().to ?? "");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today());
	const [memo, setMemo] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const name = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
	const toCard = money.find((a) => a.id === to)?.kind === "credit_card";
	async function save() {
		if (!from || !to) return void toast.error("Choose both accounts.");
		if (from === to) return void toast.error("Choose two different accounts.");
		if (!(Number(amount) > 0)) return void toast.error("Type the amount.");
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const { error } = await db.from("transfers").insert({
			from_account_id: from,
			to_account_id: to,
			amount: Math.round(Number(amount) * 100) / 100,
			transfer_date: date,
			memo: memo.trim() || (toCard ? "Credit card payment" : null),
			created_by: u.user?.id
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Transfer saved.");
		setAmount("");
		setMemo("");
		qc.invalidateQueries({ queryKey: ["transfers"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	}
	async function remove(t) {
		if (!window.confirm(`Delete this transfer of ${fmtMoney(Number(t.amount))}?`)) return;
		const { error } = await db.from("transfers").delete().eq("id", t.id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["transfers"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Transfers",
			text: "Move money between your accounts: checking to savings, or paying the credit card bill from checking (pick the card as To)."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "From",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: from,
						options: opts,
						onChange: setFrom,
						placeholder: "Checking"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "To",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: to,
						options: opts,
						onChange: setTo,
						placeholder: "Savings or credit card"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Amount",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						step: "0.01",
						value: amount,
						onChange: (e) => setAmount(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Memo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: memo,
						onChange: (e) => setMemo(e.target.value),
						placeholder: toCard ? "Credit card payment" : ""
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2 lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy,
						children: busy ? "Saving…" : toCard ? "Save card payment" : "Save transfer"
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [(list ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-6 text-center text-muted-foreground",
				children: "No transfers yet."
			}), (list ?? []).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 text-xs",
						children: fmtDate(t.transfer_date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex min-w-0 flex-1 items-center gap-2",
						children: [
							name.get(t.from_account_id),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3 w-3" }),
							" ",
							name.get(t.to_account_id),
							t.memo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: ["· ", t.memo]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: fmtMoney(Number(t.amount))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Delete transfer",
						onClick: () => void remove(t),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})
				]
			}, t.id))]
		})
	] });
}
//#endregion
export { Transfers as component };
