import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/card-register-XNF4Fjfd.js
var $$splitComponentImporter = () => import("./card-register-BB64aH_c.mjs");
var Route = createFileRoute("/_authenticated/card-register")({
	validateSearch: (s) => typeof s["account"] === "string" ? { account: s["account"] } : {},
	head: () => ({ meta: [{ title: "Credit Card Register · Tallkeep" }, {
		name: "description",
		content: "Every charge and payment on a credit card, with the balance owed."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
