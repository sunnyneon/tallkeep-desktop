import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { r as thingName, t as ChangeRow } from "./ChangeHistory-CpHJor6l.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/history-Bv6qe2iw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Everything changed in this company: who, when, what it was before. */
function HistoryPage() {
	const [who, setWho] = (0, import_react.useState)("");
	const [what, setWhat] = (0, import_react.useState)("");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [q, setQ] = (0, import_react.useState)("");
	const { data, error } = useQuery({
		queryKey: [
			"change-log",
			"all",
			from,
			to
		],
		queryFn: async () => {
			let r = db.from("change_log").select("*").order("at", { ascending: false }).limit(1e3);
			if (from) r = r.gte("at", `${from}T00:00:00`);
			if (to) r = r.lte("at", `${to}T23:59:59`);
			const { data, error } = await r;
			if (error) throw error;
			return data ?? [];
		}
	});
	const people = (0, import_react.useMemo)(() => [...new Set((data ?? []).map((c) => c.user_email ?? "Tallkeep"))].sort(), [data]);
	const kinds = (0, import_react.useMemo)(() => [...new Set((data ?? []).map((c) => c.table_name))].sort(), [data]);
	const shown = (data ?? []).filter((c) => (!who || (c.user_email ?? "Tallkeep") === who) && (!what || c.table_name === what) && (!q || JSON.stringify([
		c.label,
		c.before,
		c.after
	]).toLowerCase().includes(q.toLowerCase())));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-4 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
				children: "Change history"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every change to invoices, payments, bills, purchase orders, journal entries, bank lines, accounts, customers, vendors and products: who made it, when, and what it was before. Nobody can edit or delete this list."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						value: who,
						onChange: (e) => setWho(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Everyone"
						}), people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						value: what,
						onChange: (e) => setWhat(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Every kind"
						}), kinds.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: thingName(k)
						}, k))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "w-40",
						value: from,
						onChange: (e) => setFrom(e.target.value),
						"aria-label": "From"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "w-40",
						value: to,
						onChange: (e) => setTo(e.target.value),
						"aria-label": "To"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "min-w-0 flex-1",
						placeholder: "Find a number, name or amount",
						value: q,
						onChange: (e) => setQ(e.target.value)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border bg-card",
				children: error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-muted-foreground",
					children: "Change history isn't available: the database needs its next update, or you don't have the Accounting section."
				}) : !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-muted-foreground",
					children: "Loading…"
				}) : shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-muted-foreground",
					children: "No changes found."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y",
					children: shown.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeRow, { c }, c.id))
				})
			}),
			data && data.length >= 1e3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Showing the latest 1,000. Pick dates to see older ones."
			})
		]
	});
}
//#endregion
export { HistoryPage as component };
