import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as fmtQty, i as fmtMoney, n as fmtDate, t as axisMoney } from "./format-CgElbAz-.mjs";
import { r as fetchAll } from "./db-BX_skO2M.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { Gt as Download } from "../_libs/lucide-react.mjs";
import { t as GROUP_COLOR } from "./nav-BIrQ7OjK.mjs";
import { o as useLocations, r as useCategories, t as byId } from "./queries-B-dcxB_N.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { m as payStatus } from "./sales-BM-objxA.mjs";
import { i as poPayStatus } from "./purchasing-C4qcHG46.mjs";
import { a as YAxis, i as BarChart, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, u as Bar } from "../_libs/recharts+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/reports-Do1N-gwM.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var MONTH_END = [
	{
		title: "Reconcile the bank",
		text: "Match the statement so the cash is right.",
		link: { to: "/banking" }
	},
	{
		title: "Who owes us",
		text: "Follow up on unpaid invoices.",
		link: {
			to: "/financials",
			search: { tab: "ar" }
		}
	},
	{
		title: "What we owe",
		text: "Bills and received orders to pay.",
		link: {
			to: "/financials",
			search: { tab: "ap" }
		}
	},
	{
		title: "Sales tax",
		text: "What to file and pay for the month.",
		link: {
			to: "/financials",
			search: { tab: "tax" }
		}
	},
	{
		title: "Profit & Loss and Balance Sheet",
		text: "How the month went, and where you stand.",
		link: {
			to: "/financials",
			search: { tab: "pl" }
		}
	}
];
/** The financial reports (Financial Reports page), listed here too so Reports is one home (UX-05). */
var BOOK_REPORTS = [
	["pl", "Profit & Loss"],
	["bs", "Balance Sheet"],
	["tax", "Sales tax"],
	["ar", "Who owes us (aging)"],
	["ap", "What we owe (aging)"],
	["tb", "Trial Balance"],
	["gl", "General Ledger"],
	["ebv", "Expenses by vendor"]
];
var REPORTS = [
	{
		group: "Sales",
		id: "sales-month",
		title: "Sales by month"
	},
	{
		group: "Sales",
		id: "sales-customer",
		title: "Sales by customer"
	},
	{
		group: "Sales",
		id: "sales-product",
		title: "Sales by product"
	},
	{
		group: "Sales",
		id: "sales-rep",
		title: "Sales by sales rep"
	},
	{
		group: "Sales",
		id: "ar-aging",
		title: "Who owes us (unpaid invoices)"
	},
	{
		group: "Purchasing",
		id: "buy-vendor",
		title: "Purchases by vendor"
	},
	{
		group: "Purchasing",
		id: "ap-unpaid",
		title: "What we owe vendors"
	},
	{
		group: "Inventory",
		id: "inv-value",
		title: "Stock value by location"
	},
	{
		group: "Inventory",
		id: "inv-category",
		title: "Stock value by category"
	},
	{
		group: "Inventory",
		id: "reorder",
		title: "Reorder list (running low)"
	}
];
var RANGE_LABEL = {
	ytd: "This year",
	"last-year": "Last year",
	"12m": "Last 12 months",
	all: "All time"
};
function inRange(d, r) {
	const t = new Date(d), now = /* @__PURE__ */ new Date();
	if (r === "all") return true;
	if (r === "ytd") return t.getFullYear() === now.getFullYear();
	if (r === "last-year") return t.getFullYear() === now.getFullYear() - 1;
	return t.getTime() >= now.getTime() - 31536e6;
}
function downloadCsv(name, t) {
	const esc = (v) => {
		const s = String(v ?? "");
		return /[",\n]/.test(s) ? `"${s.replace(/"/g, "\"\"")}"` : s;
	};
	const csv = [t.cols, ...t.rows].map((r) => r.map(esc).join(",")).join("\n");
	const a = document.createElement("a");
	a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
	a.download = `${name}.csv`;
	a.click();
}
function Reports() {
	const [rid, setRid] = (0, import_react.useState)("sales-month");
	const [range, setRange] = (0, import_react.useState)("ytd");
	const { data: locations } = useLocations();
	const { data: cats } = useCategories();
	const locName = byId(locations);
	const catName = byId(cats);
	const { data: sos } = useQuery({
		queryKey: ["rep", "so"],
		queryFn: () => fetchAll("sales_orders", "id,number,status,order_date,invoice_date,due_date,customer_id,customer_name,sales_rep,subtotal,total,amount_paid,balance")
	});
	const { data: pos } = useQuery({
		queryKey: ["rep", "po"],
		queryFn: () => fetchAll("purchase_orders", "id,number,status,order_date,due_date,vendor_name,total,amount_paid,balance")
	});
	const { data: lines } = useQuery({
		queryKey: ["rep", "lines"],
		enabled: rid === "sales-product",
		queryFn: () => fetchAll("sales_order_lines", "qty,line_total,product_id,description,sales_order_id")
	});
	const { data: stock } = useQuery({
		queryKey: ["rep", "stock"],
		enabled: rid.startsWith("inv") || rid === "reorder",
		queryFn: () => fetchAll("stock", "qty,location_id,products(id,name,cost,category_id)")
	});
	const { data: products } = useQuery({
		queryKey: ["rep", "products"],
		enabled: rid === "reorder" || rid === "sales-product",
		queryFn: () => fetchAll("products", "id,name,item_type,reorder_point,reorder_qty,is_active,cost")
	});
	const { data: lastVendor } = useQuery({
		queryKey: ["rep", "vendor-items"],
		enabled: rid === "reorder",
		queryFn: async () => {
			const rows = await fetchAll("vendor_items", "product_id,cost,vendors(name)");
			const m = /* @__PURE__ */ new Map();
			rows.forEach((r) => r.vendors && m.set(r.product_id, r.vendors.name));
			return m;
		}
	});
	const sold = (0, import_react.useMemo)(() => (sos ?? []).filter((o) => ![
		"quote",
		"rma",
		"cancelled",
		"open"
	].includes(o.status) && inRange(o.invoice_date ?? o.order_date, range)), [sos, range]);
	const report = (0, import_react.useMemo)(() => {
		const money = (n) => Math.round(n * 100) / 100;
		const group = (rows, key, val) => {
			const m = /* @__PURE__ */ new Map();
			rows.forEach((r) => {
				const k = key(r) || "(none)";
				const x = m.get(k) ?? {
					n: 0,
					v: 0
				};
				x.n++;
				x.v += val(r);
				m.set(k, x);
			});
			return [...m.entries()].sort((a, b) => b[1].v - a[1].v);
		};
		switch (rid) {
			case "sales-month": {
				if (!sos) return null;
				const m = /* @__PURE__ */ new Map();
				sold.forEach((o) => {
					const d = (o.invoice_date ?? o.order_date).slice(0, 7);
					m.set(d, (m.get(d) ?? 0) + Number(o.subtotal));
				});
				const found = [...m.keys()].sort();
				const keys = [];
				if (found.length) {
					let [y, mo] = found[0].split("-").map(Number);
					const last = found.at(-1);
					for (let k = found[0]; k <= last;) {
						keys.push(k);
						mo += 1;
						if (mo > 12) {
							mo = 1;
							y += 1;
						}
						k = `${y}-${String(mo).padStart(2, "0")}`;
					}
				}
				const label = (k) => (/* @__PURE__ */ new Date(`${k}-15T12:00:00`)).toLocaleDateString(void 0, {
					month: "short",
					year: "numeric"
				});
				return {
					chart: keys.map((k) => ({
						name: label(k),
						value: money(m.get(k) ?? 0)
					})),
					table: {
						cols: ["Month", "Sales (before tax)"],
						rows: keys.map((k) => [label(k), money(m.get(k) ?? 0)]),
						right: [1]
					}
				};
			}
			case "sales-customer":
				if (!sos) return null;
				return { table: {
					cols: [
						"Customer",
						"Orders",
						"Sales (before tax)"
					],
					rows: group(sold, (o) => o.customer_name ?? "", (o) => Number(o.subtotal)).map(([k, x]) => [
						k,
						x.n,
						money(x.v)
					]),
					right: [1, 2]
				} };
			case "sales-rep": {
				if (!sos) return null;
				const g = group(sold, (o) => o.sales_rep ?? "", (o) => Number(o.subtotal));
				return {
					chart: g.map(([k, x]) => ({
						name: k,
						value: money(x.v)
					})),
					table: {
						cols: [
							"Sales rep",
							"Orders",
							"Sales (before tax)"
						],
						rows: g.map(([k, x]) => [
							k,
							x.n,
							money(x.v)
						]),
						right: [1, 2]
					}
				};
			}
			case "sales-product": {
				if (!sos || !lines) return null;
				const ok = new Set(sold.map((o) => o.id));
				const pn = byId(products);
				const m = /* @__PURE__ */ new Map();
				lines.filter((l) => ok.has(l.sales_order_id)).forEach((l) => {
					const k = l.product_id ? pn.get(l.product_id) ?? "?" : (l.description ?? "(no product)").split("\n")[0];
					const x = m.get(k) ?? {
						q: 0,
						v: 0
					};
					x.q += Number(l.qty);
					x.v += Number(l.line_total);
					m.set(k, x);
				});
				return { table: {
					cols: [
						"Product",
						"Qty sold",
						"Sales"
					],
					rows: [...m.entries()].sort((a, b) => b[1].v - a[1].v).map(([k, x]) => [
						k,
						Math.round(x.q * 100) / 100,
						money(x.v)
					]),
					right: [1, 2]
				} };
			}
			case "ar-aging": {
				if (!sos) return null;
				const now = Date.now();
				const open = (sos ?? []).filter((o) => ["Unpaid", "Partial"].includes(payStatus(o)) && Number(o.balance) > 0);
				const bucket = (o) => {
					const due = new Date(o.due_date ?? o.invoice_date ?? o.order_date).getTime();
					const days = Math.floor((now - due) / 864e5);
					return days <= 0 ? "Not due yet" : days <= 30 ? "1–30 days late" : days <= 60 ? "31–60 days late" : days <= 90 ? "61–90 days late" : "Over 90 days late";
				};
				const rows = open.sort((a, b) => Number(b.balance) - Number(a.balance)).map((o) => [
					o.number,
					o.customer_name ?? "",
					fmtDate(o.due_date),
					bucket(o),
					money(Number(o.balance))
				]);
				return {
					chart: [
						"Not due yet",
						"1–30 days late",
						"31–60 days late",
						"61–90 days late",
						"Over 90 days late"
					].map((b) => ({
						name: b,
						value: money(open.filter((o) => bucket(o) === b).reduce((s, o) => s + Number(o.balance), 0))
					})),
					table: {
						cols: [
							"Invoice #",
							"Customer",
							"Due",
							"How late",
							"Owed"
						],
						rows,
						right: [4],
						links: open.map((o) => `/sales/${o.id}`)
					}
				};
			}
			case "buy-vendor":
				if (!pos) return null;
				return { table: {
					cols: [
						"Vendor",
						"Orders",
						"Total"
					],
					rows: group(pos.filter((p) => p.status !== "cancelled" && inRange(p.order_date, range)), (p) => p.vendor_name ?? "", (p) => Number(p.total)).map(([k, x]) => [
						k,
						x.n,
						money(x.v)
					]),
					right: [1, 2]
				} };
			case "ap-unpaid": {
				if (!pos) return null;
				const open = pos.filter((p) => ["Unpaid", "Partial"].includes(poPayStatus(p)) && Number(p.balance) > 0).sort((a, b) => Number(b.balance) - Number(a.balance));
				return { table: {
					cols: [
						"PO #",
						"Vendor",
						"Order date",
						"Total",
						"Paid",
						"We owe"
					],
					rows: open.map((p) => [
						p.number,
						p.vendor_name ?? "",
						fmtDate(p.order_date),
						money(Number(p.total)),
						money(Number(p.amount_paid)),
						money(Number(p.balance))
					]),
					right: [
						3,
						4,
						5
					],
					links: open.map((p) => `/po/${p.id}`)
				} };
			}
			case "inv-value":
			case "inv-category": {
				if (!stock) return null;
				const byLoc = rid === "inv-value";
				const m = /* @__PURE__ */ new Map();
				stock.filter((s) => Number(s.qty) > 0 && s.products).forEach((s) => {
					const k = byLoc ? locName.get(s.location_id) ?? "?" : (s.products.category_id ? catName.get(s.products.category_id) : null) ?? "(no category)";
					const x = m.get(k) ?? {
						q: 0,
						v: 0
					};
					x.q += Number(s.qty);
					x.v += Number(s.qty) * Number(s.products.cost);
					m.set(k, x);
				});
				const g = [...m.entries()].sort((a, b) => b[1].v - a[1].v);
				return {
					chart: g.slice(0, 15).map(([k, x]) => ({
						name: k,
						value: money(x.v)
					})),
					table: {
						cols: [
							byLoc ? "Location" : "Category",
							"Items",
							"Value at cost"
						],
						rows: g.map(([k, x]) => [
							k,
							Math.round(x.q * 100) / 100,
							money(x.v)
						]),
						right: [1, 2]
					}
				};
			}
			case "reorder": {
				if (!stock || !products) return null;
				const on = /* @__PURE__ */ new Map();
				stock.forEach((s) => s.products && on.set(s.products.id, (on.get(s.products.id) ?? 0) + Number(s.qty)));
				const low = products.filter((p) => p.is_active && p.item_type === "stocked" && Number(p.reorder_point) > 0 && (on.get(p.id) ?? 0) <= Number(p.reorder_point)).sort((a, b) => a.name.localeCompare(b.name));
				return { table: {
					cols: [
						"Product",
						"In stock",
						"Reorder at",
						"Order this many",
						"Usual vendor"
					],
					rows: low.map((p) => [
						p.name,
						on.get(p.id) ?? 0,
						Number(p.reorder_point),
						Number(p.reorder_qty ?? 0) || Math.max(0, Number(p.reorder_point) * 2 - (on.get(p.id) ?? 0)),
						lastVendor?.get(p.id) ?? ""
					]),
					right: [
						1,
						2,
						3
					],
					links: low.map((p) => `/products/${p.id}`)
				} };
			}
		}
	}, [
		rid,
		sos,
		pos,
		lines,
		stock,
		products,
		sold,
		range,
		locName,
		catName,
		lastVendor
	]);
	const meta = REPORTS.find((r) => r.id === rid);
	const usesRange = [
		"sales-month",
		"sales-customer",
		"sales-product",
		"sales-rep",
		"buy-vendor"
	].includes(rid);
	const color = GROUP_COLOR[meta.group].main;
	const moneyCols = (i) => report?.table.cols[i]?.match(/Sales|Total|Owed|Value|owe|Paid/) != null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Reports",
				text: "Every report in one place. Start with the month-end list; the business reports are below, and every report can be downloaded for Excel."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				"aria-label": "Month-end",
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Month-end, in order"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-5",
					children: MONTH_END.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						...m.link,
						className: "flex h-full gap-3 rounded-xl border p-3 text-sm transition-colors hover:bg-muted/50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold text-white",
							style: { background: GROUP_COLOR.Reports.main },
							children: i + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "block",
							children: m.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: m.text
						})] })]
					}) }, m.title))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-[260px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "space-y-4 rounded-2xl border bg-card p-3",
					children: [[
						"Sales",
						"Purchasing",
						"Inventory"
					].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 pb-1 text-[11px] font-bold uppercase tracking-wider",
						style: { color: GROUP_COLOR[g].main },
						children: g
					}), REPORTS.filter((r) => r.group === g).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setRid(r.id),
						className: `block w-full rounded-md px-2 py-1.5 text-left text-sm ${rid === r.id ? "text-white" : "hover:bg-muted"}`,
						style: rid === r.id ? { backgroundColor: GROUP_COLOR[g].main } : void 0,
						children: r.title
					}, r.id))] }, g)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 pb-1 text-[11px] font-bold uppercase tracking-wider",
						style: { color: GROUP_COLOR.Reports.main },
						children: "From the books"
					}), BOOK_REPORTS.map(([tab, title]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/financials",
						search: { tab },
						className: "block w-full rounded-md px-2 py-1.5 text-left text-sm hover:bg-muted",
						children: title
					}, tab))] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-semibold",
								children: meta.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [usesRange && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: range,
									onValueChange: (v) => setRange(v),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "w-44",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: Object.keys(RANGE_LABEL).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: r,
										children: RANGE_LABEL[r]
									}, r)) })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									disabled: !report,
									onClick: () => report && downloadCsv(meta.title, report.table),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download for Excel"]
								})]
							})]
						}),
						!report && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-72" }),
						report?.chart && report.chart.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-72 rounded-2xl border bg-card p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: report.chart,
									margin: { left: 12 },
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											strokeDasharray: "3 3",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "name",
											tick: { fontSize: 11 },
											interval: "preserveStartEnd"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: { fontSize: 11 },
											tickFormatter: axisMoney
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (v) => fmtMoney(v) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: "value",
											fill: color,
											radius: [
												4,
												4,
												0,
												0
											]
										})
									]
								})
							})
						}),
						report && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-2xl border bg-card",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "border-b bg-muted/40 text-xs text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: report.table.cols.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: `px-3 py-2 ${report.table.right?.includes(i) ? "text-right" : "text-left"}`,
											children: c
										}, c)) })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
										className: "divide-y",
										children: [report.table.rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: report.table.cols.length,
											className: "p-8 text-center text-muted-foreground",
											children: "Nothing to show."
										}) }), report.table.rows.slice(0, 1e3).map((r, ri) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "hover:bg-muted/40",
											children: r.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: `px-3 py-2 ${report.table.right?.includes(i) ? "text-right" : ""} ${i === 0 ? "font-medium" : ""}`,
												children: i === 0 && report.table.links?.[ri] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: report.table.links[ri],
													className: "hover:underline",
													style: { color },
													children: v
												}) : typeof v === "number" ? moneyCols(i) ? fmtMoney(v) : fmtQty(v) : v
											}, i))
										}, ri))]
									}),
									report.table.rows.length > 1 && report.table.right?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
										className: "border-t bg-muted/40 font-semibold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: report.table.cols.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `px-3 py-2 ${report.table.right?.includes(i) ? "text-right" : ""}`,
											children: i === 0 ? "Total" : report.table.right?.includes(i) && moneyCols(i) ? fmtMoney(report.table.rows.reduce((s, r) => s + Number(r[i] ?? 0), 0)) : ""
										}, i)) })
									}) : null
								]
							})
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { Reports as component };
