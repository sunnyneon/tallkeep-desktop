import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { G as Paperclip, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as replyByKey, n as getTicketByKey } from "./support.functions-B1K8toje.mjs";
import { a as fileSize, n as TICKET_STATUS } from "./support-Bri7jlNl.mjs";
import { n as HelpFrame, r as toUpload, t as FilesPicker } from "./HelpParts-B_4ECnnO.mjs";
import { t as Route } from "./help.t._key-B9SrB3iZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/help.t._key-CpiJbE4g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** A customer's ticket: the conversation, quotes and invoices, and a reply box. No sign-in. */
var when = (iso) => new Date(iso).toLocaleString([], {
	dateStyle: "medium",
	timeStyle: "short"
});
function TicketPage() {
	const { key } = Route.useParams();
	const qc = useQueryClient();
	const { data: t, isLoading } = useQuery({
		queryKey: ["help-ticket", key],
		queryFn: () => getTicketByKey({ data: { key } }),
		refetchInterval: 6e4
	});
	const [body, setBody] = (0, import_react.useState)("");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function send(e) {
		e.preventDefault();
		setBusy(true);
		try {
			await replyByKey({ data: {
				key,
				origin: window.location.origin,
				body,
				files: await toUpload(files)
			} });
			setBody("");
			setFiles([]);
			toast.success("Sent. We'll get back to you.");
			qc.invalidateQueries({ queryKey: ["help-ticket", key] });
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpFrame, {
		title: "Your ticket",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin" })
	});
	if (!t) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpFrame, {
		title: "Your ticket",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-white p-6 dark:bg-slate-900",
			children: "This ticket link doesn't work. Check that you copied the whole link from the email."
		})
	});
	const st = TICKET_STATUS[t.status] ?? TICKET_STATUS.open;
	const fileUrl = (path) => `/api/public/help-file?key=${encodeURIComponent(key)}&path=${encodeURIComponent(path)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HelpFrame, {
		title: `${t.company} support`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-2xl border bg-white p-5 dark:bg-slate-900",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-slate-500",
							children: ["Ticket ", t.number]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2.5 py-0.5 text-xs font-medium", st.tone),
							children: st.customer
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-semibold",
						children: t.subject
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-500",
						children: ["Opened ", when(t.created_at)]
					})
				]
			}),
			t.docs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-2xl border bg-white p-5 dark:bg-slate-900",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Quotes and invoices"
				}), t.docs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-between gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						d.kind === "quote" ? "Quote" : "Invoice",
						" ",
						d.number
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fmtMoney(d.total), d.kind === "invoice" && (d.balance > 0 ? ` · ${fmtMoney(d.balance)} still owed` : " · paid")] })]
				}, d.number))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: t.messages.map((m) => m.kind === "event" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-center text-xs text-slate-500",
					children: [
						m.body,
						" · ",
						when(m.created_at)
					]
				}, m.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("max-w-[90%] space-y-2 rounded-2xl border p-4", m.kind === "customer" ? "ml-auto bg-sky-50 dark:bg-sky-950/40" : "bg-white dark:bg-slate-900"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-500",
							children: [
								m.kind === "customer" ? "You" : m.author_name ?? t.company,
								" ·",
								" ",
								when(m.created_at)
							]
						}),
						m.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-wrap text-sm",
							children: m.body
						}),
						m.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: fileUrl(f.path),
							target: "_blank",
							rel: "noreferrer",
							className: "flex items-center gap-2 text-sm underline",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
								" ",
								f.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-slate-500 no-underline",
									children: fileSize(f.size)
								})
							]
						}, f.path))
					]
				}, m.id))
			}),
			t.status !== "closed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: send,
				className: "space-y-3 rounded-2xl border bg-white p-5 dark:bg-slate-900",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Add a message"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 4,
						value: body,
						onChange: (e) => setBody(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesPicker, {
						files,
						onChange: setFiles
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Sending…" : "Send"]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-slate-500",
				children: "This ticket is closed. Need more help? Open a new one from the support page."
			})
		]
	});
}
//#endregion
export { TicketPage as component };
