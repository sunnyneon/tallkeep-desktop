import { i as __toESM } from "../_runtime.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-sss9hg5u.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { o as useAddons } from "./addons-tdRottJR.mjs";
import { C as useRouter, S as useNavigate, b as Link, g as Outlet, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { p as queueShoebox } from "./shoebox-BnjgLrlL.mjs";
import { n as switchCompany, r as useMyCompanies } from "./company-Bw8OfDgk.mjs";
import { $t as CircleQuestionMark, D as Search, Ht as ExternalLink, Nn as ArrowLeft, Sn as BookOpen, Yt as Clock, at as Mail, bt as ImagePlus, et as Moon, kn as Ban, n as X, o as VolumeX, on as ChevronDown, ot as LogOut, rt as Menu, s as Volume2, tn as CircleArrowUp, v as Sun, x as Sparkles, yn as Bug, yt as Inbox } from "../_libs/lucide-react.mjs";
import { c as navItems, d as sectionName, f as sectionOf, i as colorOfItem, l as pathIn, n as SECTION_ICON, r as colorForPath, s as itemTitle, u as sectionForPath } from "./nav-Dwe5Hxek.mjs";
import { s as useMyAccess } from "./queries-DKvOnwaZ.mjs";
import { a as featureOn, i as canSeePath, n as addonOffForPath, o as firstAllowedUrl, r as canSeeGroup, s as useAccess } from "./access-8NB_PwPE.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent$1, o as DialogTitle$1, r as DialogDescription$1, t as Dialog$1 } from "./dialog-CwLzEEob.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
import { n as siteKind, r as versionLabel } from "./version-DO4-tGEC.mjs";
import { a as CommandItem, i as CommandInput, n as CommandEmpty, o as CommandList, r as CommandGroup, t as Command$1 } from "./SearchSelect-BLD0hN-C.mjs";
import { r as EDITIONS } from "./editions-CIhnK_Ff.mjs";
import { a as reportProblem } from "./testers.functions-tMZCwMDE.mjs";
import { n as SOURCE_NAME } from "./reports-BrTLGjes.mjs";
import { a as bySection, i as articleForPath, n as alsoForPath, o as searchManual, r as articleBySlug } from "./manual-C1hviOEM.mjs";
import { t as ManualText } from "./ManualText-DsNAkNOQ.mjs";
import { n as ScanButton } from "./ScanAdd-fYbhgwDi.mjs";
import { t as Route } from "./route-mlceTKPz.mjs";
import { a as canWrite, c as sentence, d as useMyAccount, f as useUpdateStatus, l as trialDaysLeft, o as installUpdate, p as waitAndReload, r as PLANS_URL, s as post, u as useDesktopLicense } from "./LicenseCard-CPYIPPOe.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/route-jU7JLANO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var s = (v) => v == null ? "" : String(v);
var n = (v) => Number(v ?? 0);
/** "$1,234.50" → 1234.5; null when it isn't an amount. */
function asAmount(q) {
	const t = q.replace(/[$,\s]/g, "");
	if (!/^-?\d+(\.\d{1,2})?$/.test(t)) return null;
	const v = Math.abs(Number(t));
	return v > 0 ? v : null;
}
async function find(q) {
	const t = q.replace(/[,()%*\\"]/g, " ").trim();
	const like = `%${t}%`;
	const amt = asAmount(t);
	const any = (cols, money = []) => [...cols.map((c) => `${c}.ilike.${like}`), ...amt != null ? money.map((m) => `${m}.eq.${amt}`) : []].join(",");
	const get = async (table, cols, filter, order) => {
		let qb = db.from(table).select(cols).or(filter).limit(8);
		if (order) qb = qb.order(order, { ascending: false });
		const { data, error } = await qb;
		return error ? [] : data ?? [];
	};
	const [cust, vend, prod, sales, pos, bills, checks, pays, bpays, deps, trs, accts, props, tenants, entries, lines] = await Promise.all([
		get("customers", "id,name,email,phone", any([
			"name",
			"email",
			"phone",
			"contact_name"
		])),
		get("vendors", "id,name,email,phone", any([
			"name",
			"email",
			"phone",
			"contact_name"
		])),
		get("products", "id,name,description,price", any([
			"name",
			"description",
			"barcode"
		], ["price"])),
		get("sales_orders", "id,number,customer_name,total,balance,status,order_date", any([
			"number",
			"customer_name",
			"po_number"
		], ["total", "balance"]), "order_date"),
		get("purchase_orders", "id,number,vendor_name,total,status,order_date", any([
			"number",
			"vendor_name",
			"vendor_order_number"
		], ["total", "balance"]), "order_date"),
		get("bills", "id,ref,vendor_name,total,bill_date", any([
			"ref",
			"vendor_name",
			"memo"
		], ["total", "balance"]), "bill_date"),
		get("checks", "id,number,payee,total,check_date", any([
			"number",
			"payee",
			"memo"
		], ["total"]), "check_date"),
		get("payments", "id,amount,reference,method,paid_on", any(["reference"], ["amount"]), "paid_on"),
		get("bill_payments", "id,amount,reference,method,paid_on", any(["reference"], ["amount"]), "paid_on"),
		get("deposits", "id,memo,total,deposit_date", any(["memo"], ["total"]), "deposit_date"),
		get("transfers", "id,memo,amount,transfer_date", any(["memo"], ["amount"]), "transfer_date"),
		get("accounts", "id,number,name", any(["name", "number"])),
		get("properties", "id,name,address", any(["name", "address"])),
		get("tenants", "id,name,email,phone", any([
			"name",
			"email",
			"phone"
		])),
		get("journal_entries", "id,entry_date,ref,memo,source_type", any(["ref", "memo"]), "entry_date"),
		amt == null ? Promise.resolve([]) : (async () => {
			const { data } = await db.from("journal_lines").select("entry_id,debit,credit,journal_entries!inner(entry_date,ref,memo,source_type)").or(`debit.eq.${amt},credit.eq.${amt}`).limit(30);
			return data ?? [];
		})()
	]);
	const date = (v) => v ? fmtDate(s(v)) : "";
	const groups = [
		{
			title: "Customers",
			hits: cust.map((r) => ({
				key: `c${s(r["id"])}`,
				label: s(r["name"]),
				sub: [r["email"], r["phone"]].filter(Boolean).join(" · "),
				href: `/customers/${s(r["id"])}`
			}))
		},
		{
			title: "Vendors",
			hits: vend.map((r) => ({
				key: `v${s(r["id"])}`,
				label: s(r["name"]),
				sub: [r["email"], r["phone"]].filter(Boolean).join(" · "),
				href: `/vendors/${s(r["id"])}`
			}))
		},
		{
			title: "Sales (quotes, orders, invoices)",
			hits: sales.map((r) => ({
				key: `s${s(r["id"])}`,
				label: `${s(r["number"])} · ${s(r["customer_name"])}`,
				sub: `${date(r["order_date"])} · ${s(r["status"])}${n(r["balance"]) ? ` · owes ${fmtMoney(n(r["balance"]))}` : ""}`,
				amount: n(r["total"]),
				href: `/sales/${s(r["id"])}`
			}))
		},
		{
			title: "Purchase orders",
			hits: pos.map((r) => ({
				key: `p${s(r["id"])}`,
				label: `${s(r["number"])} · ${s(r["vendor_name"])}`,
				sub: `${date(r["order_date"])} · ${s(r["status"])}`,
				amount: n(r["total"]),
				href: `/po/${s(r["id"])}`
			}))
		},
		{
			title: "Bills",
			hits: bills.map((r) => ({
				key: `b${s(r["id"])}`,
				label: `${s(r["vendor_name"])}${r["ref"] ? ` · ${s(r["ref"])}` : ""}`,
				sub: date(r["bill_date"]),
				amount: n(r["total"]),
				href: `/bills/${s(r["id"])}`
			}))
		},
		{
			title: "Checks & payments made",
			hits: checks.map((r) => ({
				key: `k${s(r["id"])}`,
				label: `${r["number"] ? `#${s(r["number"])} · ` : ""}${s(r["payee"])}`,
				sub: date(r["check_date"]),
				amount: n(r["total"]),
				href: `/checks/${s(r["id"])}`
			}))
		},
		{
			title: "Payments received",
			hits: pays.map((r) => ({
				key: `y${s(r["id"])}`,
				label: `${s(r["method"])}${r["reference"] ? ` · ${s(r["reference"])}` : ""}`,
				sub: date(r["paid_on"]),
				amount: n(r["amount"]),
				href: `/go/payment/${s(r["id"])}`
			}))
		},
		{
			title: "Bill payments",
			hits: bpays.map((r) => ({
				key: `z${s(r["id"])}`,
				label: `${s(r["method"])}${r["reference"] ? ` · ${s(r["reference"])}` : ""}`,
				sub: date(r["paid_on"]),
				amount: n(r["amount"]),
				href: `/go/bill_payment/${s(r["id"])}`
			}))
		},
		{
			title: "Deposits & transfers",
			hits: [...deps.map((r) => ({
				key: `d${s(r["id"])}`,
				label: s(r["memo"]) || "Deposit",
				sub: date(r["deposit_date"]),
				amount: n(r["total"]),
				href: "/deposits"
			})), ...trs.map((r) => ({
				key: `t${s(r["id"])}`,
				label: s(r["memo"]) || "Transfer",
				sub: date(r["transfer_date"]),
				amount: n(r["amount"]),
				href: "/bank-transfers"
			}))]
		},
		{
			title: "Products",
			hits: prod.map((r) => ({
				key: `i${s(r["id"])}`,
				label: s(r["name"]),
				sub: s(r["description"]).slice(0, 80),
				amount: n(r["price"]),
				href: `/products/${s(r["id"])}`
			}))
		},
		{
			title: "Accounts",
			hits: accts.map((r) => ({
				key: `a${s(r["id"])}`,
				label: [r["number"], r["name"]].filter(Boolean).join(" · "),
				href: `/accounts/${s(r["id"])}`
			}))
		},
		{
			title: "Properties & tenants",
			hits: [...props.map((r) => ({
				key: `r${s(r["id"])}`,
				label: s(r["name"]),
				sub: s(r["address"]),
				href: "/properties"
			})), ...tenants.map((r) => ({
				key: `n${s(r["id"])}`,
				label: s(r["name"]),
				sub: [r["email"], r["phone"]].filter(Boolean).join(" · "),
				href: "/leases"
			}))]
		}
	];
	const seen = /* @__PURE__ */ new Set();
	const books = [];
	for (const l of lines) {
		const id = s(l["entry_id"]);
		if (seen.has(id)) continue;
		seen.add(id);
		const e = l["journal_entries"] ?? {};
		books.push({
			key: `e${id}`,
			label: `${SOURCE_NAME[s(e["source_type"])] ?? s(e["source_type"])}${e["ref"] ? ` · ${s(e["ref"])}` : ""}`,
			sub: `${date(e["entry_date"])}${e["memo"] ? ` · ${s(e["memo"])}` : ""}`,
			amount: n(l["debit"]) || n(l["credit"]),
			href: `/go/entry/${id}`
		});
	}
	for (const e of entries) {
		const id = s(e["id"]);
		if (seen.has(id)) continue;
		seen.add(id);
		books.push({
			key: `e${id}`,
			label: `${SOURCE_NAME[s(e["source_type"])] ?? s(e["source_type"])}${e["ref"] ? ` · ${s(e["ref"])}` : ""}`,
			sub: `${date(e["entry_date"])}${e["memo"] ? ` · ${s(e["memo"])}` : ""}`,
			href: `/go/entry/${id}`
		});
	}
	groups.push({
		title: "In the books",
		hits: books.slice(0, 15)
	});
	return groups.filter((g) => g.hits.length);
}
/** Search box for the whole app. Opens with Ctrl+K (⌘K on Mac) or "/". */
function GlobalSearch({ className, compact }) {
	const router = useRouter();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [term, setTerm] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setTerm(q.trim()), 250);
		return () => clearTimeout(t);
	}, [q]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const typing = e.target instanceof HTMLElement && e.target.closest("input,textarea,select,[contenteditable=true]");
			if (e.key === "k" && (e.metaKey || e.ctrlKey) || e.key === "/" && !typing) {
				e.preventDefault();
				setOpen(true);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const { data, isFetching } = useQuery({
		queryKey: ["global-search", term],
		enabled: open && term.length >= 2,
		queryFn: () => find(term),
		staleTime: 15e3
	});
	const go = (href) => {
		setOpen(false);
		router.history.push(href);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => setOpen(true),
		title: "Search everything (Ctrl+K)",
		className: cn("flex items-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/40 px-3 py-2 text-sm text-sidebar-foreground/70 hover:text-sidebar-foreground", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-4 w-4 shrink-0" }), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden flex-1 text-left lg:inline",
			children: "Search…"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("kbd", {
			className: "hidden text-[10px] opacity-60 lg:inline",
			children: "Ctrl K"
		})] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "max-w-2xl overflow-hidden p-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
				className: "sr-only",
				children: "Search everything"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				shouldFilter: false,
				className: "[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]]:px-2 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
					value: q,
					onValueChange: setQ,
					placeholder: "Name, invoice #, check #, $ amount, phone, email…"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, {
					className: "max-h-[70vh]",
					children: [term.length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "Type at least 2 letters or an amount like 1250 or $1,250.00"
					}) : isFetching && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "Searching…"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandEmpty, { children: [
						"Nothing found for \"",
						term,
						"\"."
					] }), term.length >= 2 && data?.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandGroup, {
						heading: g.title,
						children: g.hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
							value: h.key,
							onSelect: () => go(h.href),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate",
									children: h.label
								}), h.sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate text-xs text-muted-foreground",
									children: h.sub
								})]
							}), h.amount != null && h.amount !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-sm",
								children: fmtMoney(h.amount)
							})]
						}, h.key))
					}, g.title))]
				})]
			})]
		})
	})] });
}
var KEY$1 = "sound-on";
var ctx = null;
var last = 0;
function soundOn() {
	try {
		return localStorage.getItem(KEY$1) !== "off";
	} catch {
		return true;
	}
}
function setSoundOn(on) {
	try {
		localStorage.setItem(KEY$1, on ? "on" : "off");
	} catch {}
	if (on) play("saved", true);
}
/** The sounds, written against any audio context (the app's, or one that renders a preview). */
function drawSound(ac, kind, t) {
	const master = ac.createGain();
	master.gain.value = .22;
	master.connect(ac.destination);
	const tone = (freq, start, len, vol, partials) => {
		for (const [mult, v] of partials) {
			const o = ac.createOscillator();
			const g = ac.createGain();
			o.type = "sine";
			o.frequency.value = freq * mult;
			g.gain.setValueAtTime(0, t + start);
			g.gain.linearRampToValueAtTime(vol * v, t + start + .006);
			g.gain.exponentialRampToValueAtTime(1e-4, t + start + len);
			o.connect(g).connect(master);
			o.start(t + start);
			o.stop(t + start + len + .05);
		}
	};
	const bell = [
		[1, 1],
		[2, .18],
		[3, .06]
	];
	if (kind === "saved") {
		tone(659.3, 0, .45, .9, bell);
		tone(987.8, .1, .7, .8, bell);
	} else if (kind === "out") {
		tone(880, 0, .35, .7, bell);
		tone(659.3, .09, .4, .7, bell);
		tone(440, .18, .7, .8, bell);
	} else {
		const src = ac.createBufferSource();
		src.buffer = coinBuffer(ac);
		const g = ac.createGain();
		g.gain.value = 2.2;
		src.connect(g).connect(master);
		src.start(t);
	}
}
/** Coins poured into a bucket, built sample by sample (the same every time). */
var coinCache = /* @__PURE__ */ new Map();
function coinBuffer(ac) {
	const sr = ac.sampleRate;
	const hit = coinCache.get(sr);
	if (hit) return hit;
	const n = Math.round(sr * 1.8);
	const out = new Float32Array(n);
	let seed = 12345;
	const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
	const partials = [
		1,
		2.41,
		3.88,
		5.33
	];
	for (let c = 0; c < 350; c++) {
		const at = 1.3 * Math.pow(rnd(), 2.2) + .01;
		const f = 1100 + 1500 * rnd();
		const vol = (.25 + .75 * rnd()) * Math.exp(-at * 2.2);
		const start = Math.round(at * sr);
		const clen = Math.round(.2 * sr);
		for (let p = 0; p < partials.length; p++) {
			const w = 2 * Math.PI * f * partials[p] * (1 + (rnd() - .5) * .02) / sr;
			const amp = vol / (1 + p * 1.4);
			const d = .05 / (1 + p * .6);
			const ph = rnd() * 6.28;
			for (let i = 0; i < clen && start + i < n; i++) out[start + i] += amp * Math.exp(-i / sr / d) * Math.sin(w * i + ph);
		}
	}
	for (let i = 0; i < n; i++) {
		const t = i / sr;
		out[i] += .15 * (Math.sin(2 * Math.PI * 260 * t) + .5 * Math.sin(2 * Math.PI * 702 * t)) * Math.exp(-t / .35) * Math.min(1, t / .005) + .18 * (rnd() * 2 - 1) * Math.exp(-t / .65);
	}
	let peak = 0;
	for (const v of out) peak = Math.max(peak, Math.abs(v));
	for (let i = 0; i < n; i++) out[i] = out[i] / peak * .9 * Math.min(1, (n - i) / (sr * .05));
	const buf = ac.createBuffer(1, n, sr);
	buf.copyToChannel(out, 0);
	coinCache.set(sr, buf);
	return buf;
}
function play(kind = "saved", force = false) {
	if (!force && !soundOn()) return;
	const now = Date.now();
	if (now - last < 600) return;
	last = now;
	try {
		ctx ??= new AudioContext();
		if (ctx.state === "suspended") ctx.resume();
		drawSound(ctx, kind, ctx.currentTime);
	} catch {}
}
/** Which sound a green message gets, from its words. Deletes and undos stay quiet. */
function soundFor(message) {
	const m = message.toLowerCase();
	if (/deleted|removed|undone|cancel|voided|reopened|unpaid again|put back|copied/.test(m)) return null;
	if (/deposit|payment recorded|payment received|rent received|sales receipt|marked paid/.test(m)) return "coins";
	if (/payment of|payment made|payment to vendor|bill paid|bills paid|payroll|check|paid with/.test(m)) return "out";
	return "saved";
}
/** Play a sound on every green "saved" message in the app. Call once. */
var wired$1 = false;
function wireSavedSound() {
	if (wired$1 || typeof window === "undefined") return;
	wired$1 = true;
	setTimeout(() => {
		try {
			ctx ??= new AudioContext();
			coinBuffer(ctx);
		} catch {}
	}, 3e3);
	const original = toast.success.bind(toast);
	toast.success = ((...args) => {
		const kind = soundFor(typeof args[0] === "string" ? args[0] : "");
		if (kind) play(kind);
		return original(...args);
	});
}
/**
* When a trial ends or an account is canceled, the books are read-only. The database already
* refuses changes; this stops the app before it tries, so people see a clear message instead of
* a "saved" that didn't save.
*/
var READ_ONLY_MSG = "Your account is read-only. Choose a plan to keep working.";
var readOnly = false;
function setReadOnly(v) {
	readOnly = v;
}
var ALWAYS_OK = /* @__PURE__ */ new Set(["user_company"]);
/** A stand-in query that can be chained like a real one and ends in the read-only error. */
function refused(throwing = false) {
	const result = {
		data: null,
		error: {
			message: READ_ONLY_MSG,
			code: "read_only",
			details: "",
			hint: ""
		},
		count: null,
		status: 403,
		statusText: "Read-only"
	};
	const stub = new Proxy(function() {}, {
		get(_t, key) {
			if (key === "then") return (ok, bad) => (throwing ? Promise.reject(/* @__PURE__ */ new Error(READ_ONLY_MSG)) : Promise.resolve(result)).then(ok, bad);
			if (key === "throwOnError") return () => refused(true);
			return () => stub;
		},
		apply: () => stub
	});
	return stub;
}
var wired = false;
function wireReadOnly() {
	if (wired) return;
	wired = true;
	const client = supabase;
	const from = client.from.bind(client);
	client.from = (table) => {
		const q = from(table);
		if (!readOnly || ALWAYS_OK.has(table)) return q;
		return new Proxy(q, { get(target, key) {
			if (key === "insert" || key === "update" || key === "upsert" || key === "delete") return () => refused();
			const v = Reflect.get(target, key);
			return typeof v === "function" ? v.bind(target) : v;
		} });
	};
}
/**
* "Report a problem" (in the Help panel): tells Tallkeep what went wrong, with the page you were
* on, the version, and a picture if you add one.
*/
var DESKTOP$1 = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1"
}["VITE_TALLKEEP_DESKTOP"];
var toBase64 = (f) => new Promise((ok, no) => {
	const r = new FileReader();
	r.onload = () => ok(String(r.result).replace(/^data:[^,]*,/, ""));
	r.onerror = () => no(/* @__PURE__ */ new Error("Couldn't read the picture."));
	r.readAsDataURL(f);
});
function ReportProblem({ page, onClose }) {
	const [message, setMessage] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [pic, setPic] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)("");
	const { data: companies } = useMyCompanies();
	const company = companies?.find((c) => c.active)?.name ?? companies?.[0]?.name ?? "";
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => setEmail(data.session?.user.email ?? ""));
	}, []);
	async function send() {
		if (!message.trim()) {
			setFailed("Tell us what went wrong.");
			return;
		}
		if (pic && pic.size > 5e6) {
			setFailed("The picture is bigger than 5 MB. Take a smaller screenshot.");
			return;
		}
		setBusy(true);
		setFailed("");
		try {
			const body = {
				message: message.trim(),
				page: `${page}${typeof window !== "undefined" ? ` (${window.location.href})` : ""}`,
				version: versionLabel(),
				email,
				company,
				picture: pic ? {
					name: pic.name,
					type: pic.type,
					base64: await toBase64(pic)
				} : null
			};
			if (DESKTOP$1) {
				const { data } = await supabase.auth.getSession();
				const r = await fetch("/tallkeep/report", {
					method: "POST",
					headers: {
						authorization: `Bearer ${data.session?.access_token ?? ""}`,
						"content-type": "application/json"
					},
					body: JSON.stringify(body)
				});
				const out = await r.json().catch(() => ({}));
				if (!r.ok) throw new Error(out.message ?? "That didn't go.");
			} else await reportProblem({ data: body });
			toast.success("Thank you! We got it and will look at it.");
			onClose();
		} catch (e) {
			setFailed(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog$1, {
		open: true,
		onOpenChange: (v) => !v && !busy && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, { children: "Report a problem" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: "Tell us what you did and what went wrong. We see which page you were on and your Tallkeep version." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "report-what",
								children: "What went wrong?"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "report-what",
								rows: 5,
								value: message,
								onChange: (e) => setMessage(e.target.value),
								placeholder: "For example: I pressed Save on the invoice and the total changed to $0."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "report-email",
								children: "Your email (for our answer)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "report-email",
								value: email,
								onChange: (e) => setEmail(e.target.value)
							})]
						}),
						pic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg border px-3 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: pic.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setPic(null),
								"aria-label": "Remove the picture",
								className: "text-muted-foreground hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex cursor-pointer items-center gap-2 rounded-lg border border-dashed px-3 py-2 text-sm text-muted-foreground hover:bg-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" }),
								" Add a picture of the screen (optional)",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: (e) => setPic(e.target.files?.[0] ?? null)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Screenshot on Windows: press Windows + Shift + S, then save the picture."
						}),
						failed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-900 dark:border-red-900 dark:bg-red-950/40 dark:text-red-100",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Not sent." }),
								" ",
								failed
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					disabled: busy,
					children: "Don't send"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void send(),
					disabled: busy,
					children: busy ? "Sending…" : "Send to Tallkeep"
				})] })
			]
		})
	});
}
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
/**
* Help: the Help button (and F1) opens the manual on the side, at the article for the page
* you're on. Search the whole manual from there, or open it full size (/manual).
*/
var EVENT = "tallkeep-help";
/** Open the Help panel from anywhere (optionally at one article). */
function openHelp(slug) {
	window.dispatchEvent(new CustomEvent(EVENT, { detail: slug ?? null }));
}
function HelpCenter() {
	const path = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	const [slug, setSlug] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [reporting, setReporting] = (0, import_react.useState)(false);
	const show = (0, import_react.useCallback)((s) => {
		setSlug(s);
		setQ("");
		setOpen(true);
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "F1") {
				e.preventDefault();
				setOpen((v) => {
					if (!v) {
						setSlug(null);
						setQ("");
					}
					return !v;
				});
			}
		};
		const onOpen = (e) => show(e.detail);
		window.addEventListener("keydown", onKey);
		window.addEventListener(EVENT, onOpen);
		return () => {
			window.removeEventListener("keydown", onKey);
			window.removeEventListener(EVENT, onOpen);
		};
	}, [show]);
	const forPage = (0, import_react.useMemo)(() => articleForPath(path), [path]);
	const article = slug ? articleBySlug(slug) : forPage;
	const results = (0, import_react.useMemo)(() => searchManual(q), [q]);
	const also = (0, import_react.useMemo)(() => article ? alsoForPath(path, article.slug).slice(0, 6) : [], [path, article]);
	const item = (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => show(a.slug),
		className: "block w-full rounded-lg px-3 py-2 text-left hover:bg-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: a.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: a.summary
		})]
	}, a.slug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "flex w-full flex-col gap-0 p-0 sm:max-w-xl print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
					className: "space-y-3 border-b p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "h-5 w-5" }), " Help"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							autoFocus: true,
							className: "pl-9",
							placeholder: "Search the manual, e.g. bounced check",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto p-4",
					children: q.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1",
						children: results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "p-3 text-sm text-muted-foreground",
							children: "Nothing found. Try other words, or email us below."
						}) : results.map(item)
					}) : article ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "space-y-4",
						children: [
							slug && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setSlug(null),
								className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), forPage ? "Help for this page" : "All help"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
								children: article.section
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-bold",
								children: article.title
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualText, {
								body: article.body,
								onOpen: (s) => show(s)
							}),
							also.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1 border-t pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 text-sm font-semibold",
									children: "More help for this page"
								}), also.map(item)]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-5",
						children: bySection().map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-3 text-sm font-semibold",
								children: s.section
							}), s.list.map(item)]
						}, s.section))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2 border-t p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: article && !q ? `/manual/${article.slug}` : "/manual",
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex items-center gap-1 font-medium text-primary hover:underline",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" }), " Open the full manual"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "mailto:hello@tallkeep.com?subject=Tallkeep%20help",
							className: "inline-flex items-center gap-1 text-muted-foreground hover:text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email us"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setOpen(false);
								setReporting(true);
							},
							className: "inline-flex items-center gap-1 rounded-full bg-[var(--section,#0F766E)] px-3 py-1 text-xs font-semibold text-white hover:opacity-90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bug, { className: "h-3.5 w-3.5" }), " Report a problem"]
						})]
					})]
				})
			]
		})
	}), reporting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportProblem, {
		page: path,
		onClose: () => setReporting(false)
	})] });
}
/**
* Drop files anywhere in Tallkeep: they go to the Shoebox. (Pages with their own drop area, like
* Bank Feeds or Receipts, still take files dropped on that area.)
*/
var hasFiles = (e) => !!e.dataTransfer && [...e.dataTransfer.types].includes("Files");
function ShoeboxDrop() {
	const navigate = useNavigate();
	const path = useRouterState({ select: (s) => s.location.pathname });
	const [over, setOver] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let depth = 0;
		const enter = (e) => {
			if (!hasFiles(e)) return;
			depth++;
			setOver(true);
		};
		const leave = (e) => {
			if (!hasFiles(e)) return;
			depth = Math.max(0, depth - 1);
			if (!depth) setOver(false);
		};
		const overFn = (e) => {
			if (hasFiles(e) && !e.defaultPrevented) e.preventDefault();
		};
		const drop = (e) => {
			depth = 0;
			setOver(false);
			if (e.defaultPrevented || !hasFiles(e)) return;
			e.preventDefault();
			const files = [...e.dataTransfer?.files ?? []];
			if (!files.length || path === "/shoebox") return;
			queueShoebox(files);
			navigate({ to: "/shoebox" });
		};
		window.addEventListener("dragenter", enter);
		window.addEventListener("dragleave", leave);
		window.addEventListener("dragover", overFn);
		window.addEventListener("drop", drop);
		return () => {
			window.removeEventListener("dragenter", enter);
			window.removeEventListener("dragleave", leave);
			window.removeEventListener("dragover", overFn);
			window.removeEventListener("drop", drop);
		};
	}, [navigate, path]);
	if (!over || path === "/shoebox") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 top-4 z-50 flex justify-center print:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 rounded-full bg-[var(--section,#0F766E)] px-5 py-2.5 text-sm font-semibold text-white shadow-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-5 w-5" }), " Drop to put it in the Shoebox"]
		})
	});
}
var KEY = "open-tabs";
var MAX = 12;
function load() {
	try {
		const t = JSON.parse(localStorage.getItem(KEY) ?? "[]");
		return Array.isArray(t) ? t.slice(0, MAX) : [];
	} catch {
		return [];
	}
}
/** A short name for a page: its menu name, or the page title. */
function titleFor(path) {
	const fromTitle = document.title.replace(/\s*·\s*Tallkeep.*$/, "").trim();
	const exact = navItems.find((i) => i.url === path);
	if (exact) return exact.title;
	if (fromTitle && fromTitle !== "Tallkeep") return fromTitle;
	return navItems.filter((i) => i.url !== "/" && pathIn(path, i.url)).sort((a, b) => b.url.length - a.url.length)[0]?.title ?? "Page";
}
function PageTabs() {
	const loc = useRouterState({ select: (s) => s.location });
	const navigate = useNavigate();
	const [tabs, setTabs] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => setTabs(load()), []);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => {
			const path = loc.pathname;
			const href = loc.href;
			const title = titleFor(path);
			setTabs((list) => {
				const i = list.findIndex((x) => x.path === path);
				let next;
				if (i >= 0) next = list.map((x, j) => j === i ? {
					path,
					href,
					title
				} : x);
				else {
					next = [...list, {
						path,
						href,
						title
					}];
					if (next.length > MAX) next = next.slice(next.length - MAX);
				}
				try {
					localStorage.setItem(KEY, JSON.stringify(next));
				} catch {}
				return next;
			});
		}, 250);
		return () => clearTimeout(t);
	}, [loc.href, loc.pathname]);
	const save = (next) => {
		setTabs(next);
		try {
			localStorage.setItem(KEY, JSON.stringify(next));
		} catch {}
	};
	const close = (path) => {
		const i = tabs.findIndex((x) => x.path === path);
		const next = tabs.filter((x) => x.path !== path);
		save(next);
		if (path === loc.pathname) {
			const go = next[Math.min(i, next.length - 1)];
			navigate({ href: go?.href ?? "/" });
		}
	};
	(0, import_react.useEffect)(() => {
		let typed = false;
		const onInput = () => typed = true;
		const onKey = (e) => {
			if (e.key !== "Escape" || e.defaultPrevented || e.repeat) return;
			if (e.ctrlKey || e.altKey || e.metaKey || e.shiftKey) return;
			if (document.querySelector("[role=\"dialog\"], [role=\"alertdialog\"], [role=\"menu\"], [role=\"listbox\"], [data-radix-popper-content-wrapper], [data-state=\"open\"][data-vaul-drawer]")) return;
			const el = document.activeElement;
			if (el && (el.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName))) {
				el.blur();
				return;
			}
			if (tabs.length <= 1 && loc.pathname === "/") return;
			if (typed && !window.confirm("Close this page? Anything you haven't saved will be lost.")) return;
			close(loc.pathname);
		};
		document.addEventListener("input", onInput, true);
		window.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("input", onInput, true);
			window.removeEventListener("keydown", onKey);
		};
	}, [tabs, loc.pathname]);
	if (tabs.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "hidden items-end gap-1 overflow-x-auto border-b bg-muted/70 px-2 pt-1.5 md:flex print:hidden",
		children: [tabs.map((t) => {
			const on = t.path === loc.pathname;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("group flex max-w-[13rem] shrink-0 items-center gap-1 rounded-t-lg border border-b-0 px-3 py-1.5 text-sm", on ? "bg-background font-semibold text-foreground shadow-sm" : "bg-transparent text-muted-foreground hover:bg-background/60"),
				style: on ? { borderTop: "2px solid var(--section)" } : void 0,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "truncate",
					title: t.title,
					onClick: () => !on && void navigate({ href: t.href }),
					children: t.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Close ${t.title}`,
					title: `Close ${t.title}`,
					onClick: () => close(t.path),
					className: "rounded p-0.5 opacity-60 hover:bg-muted hover:opacity-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3.5 w-3.5" })
				})]
			}, t.path);
		}), tabs.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => save(tabs.filter((t) => t.path === loc.pathname)),
			className: "mb-1 ml-auto shrink-0 rounded-full bg-[var(--section)] px-3 py-1 text-xs font-semibold text-white shadow-sm hover:opacity-90",
			children: "Close the other tabs"
		})]
	});
}
/**
* "New version" on the main screen: a small green pill in the menu, and a card in the corner with
* what's new, Update now, Remind me later and Skip this version. Covers both the server (Tallkeep
* in Docker, for admins) and the Tallkeep app on this computer. The server goes first.
*/
var LATER = "tk-update-later";
var SKIP = "tk-update-skip";
var read = (k) => {
	try {
		return localStorage.getItem(k);
	} catch {
		return null;
	}
};
var write = (k, v) => {
	try {
		localStorage.setItem(k, v);
	} catch {}
};
/** The update to offer now, if any. */
function useOffer() {
	const [app] = useUpdateStatus();
	const { data: me } = useMyAccess();
	const { data: server } = useQuery({
		queryKey: ["docker-updates"],
		refetchInterval: (q) => q.state.dataUpdateCount < 2 ? 2e4 : 6e5,
		refetchOnWindowFocus: true,
		queryFn: async () => {
			const r = await fetch("/tallkeep/self-update");
			return r.ok ? await r.json() : null;
		}
	});
	if (server?.latest && !server.renew && me?.admin) return {
		kind: "server",
		version: server.latest,
		current: server.current,
		notes: server.notes,
		title: "New version for the server",
		text: "Everyone is disconnected for a minute or two while the server updates. Then update each computer's app."
	};
	if (app?.ready) return {
		kind: "app",
		version: app.ready.version,
		current: app.current,
		notes: app.ready.notes,
		title: app.officeComputer ? "New version available" : "Update this computer",
		text: app.officeComputer ? "Tallkeep closes for a moment and opens again." : "The server has this version. Update this computer so everything works right."
	};
	return null;
}
/** The small pill in the menu and the card in the corner. */
function UpdateNotice() {
	const offer = useOffer();
	const [skip, setSkip] = (0, import_react.useState)(() => read(SKIP));
	const [later, setLater] = (0, import_react.useState)(() => read(LATER));
	const [open, setOpen] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!offer) return;
		let l = {};
		try {
			l = JSON.parse(later ?? "{}");
		} catch {}
		const putOff = l.version === offer.version && (l.until ?? 0) > Date.now();
		setOpen(skip !== offer.version && !putOff);
	}, [
		offer?.version,
		skip,
		later
	]);
	if (!offer || skip === offer.version) return null;
	const remindLater = () => {
		const v = JSON.stringify({
			version: offer.version,
			until: Date.now() + 864e5
		});
		write(LATER, v);
		setLater(v);
		setOpen(false);
	};
	const skipIt = () => {
		write(SKIP, offer.version);
		setSkip(offer.version);
	};
	const update = async () => {
		setBusy(true);
		try {
			if (offer.kind === "server") {
				await post({});
				toast.success("Updating the server… This page reloads by itself in a minute or two.");
				waitAndReload();
			} else {
				await installUpdate();
				setBusy(false);
			}
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdatePill, {
		version: offer.version,
		onClick: () => setOpen(true)
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed bottom-4 right-4 z-50 w-[22rem] max-w-[calc(100vw-2rem)] rounded-2xl border bg-card p-4 shadow-xl print:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: offer.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Tallkeep ",
								offer.version,
								offer.current ? ` · you have ${offer.current}` : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Close",
						className: "rounded-md p-1 text-muted-foreground hover:bg-muted",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})
				]
			}),
			offer.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm",
				children: ["What's new: ", sentence(offer.notes)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted-foreground",
				children: offer.text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-3 w-full",
				disabled: busy,
				onClick: () => void update(),
				children: busy ? "Updating…" : offer.kind === "server" ? "Update the server now" : "Update now"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex items-center gap-1 hover:text-foreground",
					onClick: remindLater,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3.5 w-3.5" }), " Remind me tomorrow"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex items-center gap-1 hover:text-foreground",
					onClick: skipIt,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "h-3.5 w-3.5" }), " Skip this version"]
				})]
			})
		]
	})] });
}
function UpdatePill({ version, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		title: `Tallkeep ${version} is ready. Click to see what's new.`,
		className: "mx-3 mb-2 flex items-center justify-center gap-2 rounded-full border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-800 hover:bg-emerald-100 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-200 lg:justify-between",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5 shrink-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "hidden flex-1 text-left lg:inline",
				children: ["New version ", version]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleArrowUp, { className: "hidden h-4 w-4 shrink-0 lg:block" })
		]
	});
}
/**
* The name line, like a window title: the small Tallkeep mark, "Tallkeep" and the edition
* ("Tallkeep - Everything Edition"). In the Tallkeep window it goes in the window's title bar;
* in a browser (no title bar of ours) it's a slim line at the top of the menu.
*/
var bridge = () => typeof window !== "undefined" ? window.tallkeep : void 0;
function useEditionName() {
	const { data: lic } = useDesktopLicense();
	if (!lic) return null;
	if (lic.mode === "trial") return "Free Trial";
	if (lic.mode === "ended") return "Trial Ended";
	const ed = "edition" in lic ? lic.edition : null;
	const e = ed && EDITIONS[ed];
	return `${e ? e.label : "Full Business"} Edition`;
}
function AppTitle() {
	const edition = useEditionName();
	const b = bridge();
	const inWindow = !!b;
	(0, import_react.useEffect)(() => {
		if (b?.setTitle) b.setTitle(edition ? `Tallkeep - ${edition}` : "Tallkeep");
	}, [b, edition]);
	if (inWindow) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-9 items-center justify-center gap-2 border-b border-sidebar-border px-4 text-xs lg:justify-start",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/tallkeep-mark.svg",
				alt: "",
				className: "h-4 w-auto dark:hidden"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/tallkeep-mark-light.svg",
				alt: "",
				className: "hidden h-4 w-auto dark:block"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "hidden truncate lg:inline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "Tallkeep"
				}), edition ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sidebar-foreground/60",
					children: [" - ", edition]
				}) : null]
			})
		]
	});
}
function getTheme() {
	try {
		return localStorage.getItem("theme") === "dark" ? "dark" : "light";
	} catch {
		return "light";
	}
}
function applyTheme(t) {
	if (typeof document === "undefined") return;
	document.documentElement.classList.toggle("dark", t === "dark");
}
function setTheme(t) {
	try {
		localStorage.setItem("theme", t);
	} catch {}
	applyTheme(t);
}
var DEFAULTS = {
	products: [
		"/",
		"/new-quote",
		"/sales-list",
		"/products"
	],
	manufacturing: [
		"/",
		"/new-quote",
		"/sales-list",
		"/products"
	],
	services: [
		"/",
		"/tickets",
		"/new-invoice",
		"/customers"
	],
	real_estate: [
		"/",
		"/rent",
		"/leases",
		"/properties"
	],
	personal: [
		"/",
		"/budget",
		"/register",
		"/shoebox"
	],
	other: [
		"/",
		"/new-invoice",
		"/customers",
		"/receipts"
	]
};
/** Shorter names where the menu name doesn't fit under an icon. */
var SHORT = {
	"/leases": "Tenants",
	"/banking": "Bank Feeds"
};
function usePhoneBarChoice() {
	return useQuery({
		queryKey: ["phone-bar"],
		staleTime: Infinity,
		queryFn: async () => {
			const [{ data: u }, { data: s }] = await Promise.all([db.auth.getUser(), db.from("company_settings").select("business_type").maybeSingle()]);
			const mine = (u.user?.user_metadata)?.["phone_bar"];
			return {
				mine: Array.isArray(mine) ? mine : null,
				type: s?.business_type ?? "products"
			};
		}
	});
}
/** The four buttons: the person's pick, then the business's defaults, then the first pages they can open. */
function pickBar(items, choice) {
	const byUrl = new Map(items.map((i) => [i.url, i]));
	const want = [
		...choice?.mine ?? [],
		...DEFAULTS[choice?.type ?? "products"] ?? DEFAULTS["products"],
		...items.map((i) => i.url)
	];
	const out = [];
	for (const u of want) {
		const it = byUrl.get(u);
		if (it && !out.includes(it)) out.push(it);
		if (out.length === 4) break;
	}
	return out;
}
function useSavePhoneBar() {
	const qc = useQueryClient();
	return async (urls) => {
		const { error } = await db.auth.updateUser({ data: { phone_bar: urls } });
		if (error) throw error;
		await qc.invalidateQueries({ queryKey: ["phone-bar"] });
	};
}
/** Which company I'm working in; a menu to switch when I can open more than one. */
function CompanyPicker({ className }) {
	const { data } = useMyCompanies();
	if (!data?.length) return null;
	const active = data.find((c) => c.active) ?? data[0];
	if (data.length === 1) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("truncate text-xs font-medium text-sidebar-foreground/70", className),
		children: active.name
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		"aria-label": "Company you're working in",
		title: "Switch company",
		className: cn("w-full truncate rounded-md border border-sidebar-border bg-sidebar px-2 py-1.5 text-xs font-medium text-sidebar-foreground", className),
		value: active.id,
		onChange: (e) => void switchCompany(e.target.value).catch((err) => toast.error(err.message)),
		children: data.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: c.id,
			children: c.name
		}, c.id))
	});
}
function useSignOut() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	return async () => {
		await qc.cancelQueries();
		qc.clear();
		await supabase.auth.signOut();
		navigate({
			to: "/auth",
			replace: true
		});
	};
}
/** The office (desktop) version: the window's own icon is the logo, so the menu starts with the company. */
var DESKTOP = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1"
}["VITE_TALLKEEP_DESKTOP"];
function AppShell({ children, email, access }) {
	const path = useRouterState({ select: (s) => s.location.pathname.startsWith("/checks/") && s.location.search.card ? "/credit-cards" : s.location.pathname });
	const isActive = (url) => pathIn(path, url);
	const here = sectionForPath(path);
	const [openSec, setOpenSec] = (0, import_react.useState)(here);
	(0, import_react.useEffect)(() => setOpenSec(here), [here]);
	const [sound, setSound] = (0, import_react.useState)(true);
	const [theme, setThemeState] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const t = getTheme();
		setThemeState(t);
		applyTheme(t);
		wireSavedSound();
		wireReadOnly();
		setSound(soundOn());
	}, []);
	const toggle = (sec) => setOpenSec((o) => o === sec ? "" : sec);
	const signOut = useSignOut();
	const [moreOpen, setMoreOpen] = (0, import_react.useState)(false);
	const { data: addons } = useAddons();
	const personal = !!addons?.includes("personal");
	const items = navItems.filter((i) => canSeeGroup(access, i.group) && featureOn(addons, i)).map((i) => ({
		...i,
		title: itemTitle(i, personal)
	}));
	const { data: barChoice } = usePhoneBarChoice();
	const bottom = pickBar(items, barChoice);
	const more = items.filter((i) => !bottom.includes(i));
	const [picking, setPicking] = (0, import_react.useState)(false);
	const moreActive = more.some((i) => isActive(i.url));
	const section = colorForPath(path);
	const lookButtons = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => {
			setSoundOn(!sound);
			setSound(!sound);
		},
		title: sound ? "Turn off the sound when something is saved" : "Turn on the sound when something is saved",
		className: "flex w-full items-center justify-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground lg:ml-3 lg:justify-start",
		children: [sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden lg:inline",
			children: sound ? "Saved sound: on" : "Saved sound: off"
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => {
			const next = theme === "dark" ? "light" : "dark";
			setTheme(next);
			setThemeState(next);
		},
		title: theme === "dark" ? "Switch to the light look" : "Switch to the dark look",
		className: "flex w-full items-center justify-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground lg:ml-3 lg:justify-start",
		children: [theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden lg:inline",
			children: theme === "dark" ? "Light look" : "Dark look"
		})]
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen w-full bg-background",
		style: {
			"--section": section.main,
			"--section-soft": section.soft
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden print:!hidden h-screen shrink-0 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground md:flex md:w-20 lg:w-64",
				children: [
					DESKTOP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppTitle, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-16 items-center justify-center gap-2 px-4 lg:justify-between",
						children: [DESKTOP ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden min-w-0 flex-1 lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyPicker, {})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
							compactOnTablet: true,
							auto: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanButton, { compact: true })
						})]
					}),
					!DESKTOP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden px-4 pb-2 lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyPicker, {})
					}),
					DESKTOP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdateNotice, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearch, { className: "w-full justify-center lg:justify-start" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex-1 space-y-1 overflow-y-auto px-3 py-2",
						children: items.map((item, i) => {
							const c = colorOfItem(item);
							const active = isActive(item.url);
							const sec = sectionOf(item);
							const first = !!sec && sec !== (items[i - 1] ? sectionOf(items[i - 1]) : "");
							const shut = !!sec && sec !== openSec;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								first && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => toggle(sec),
									className: "mt-1 hidden w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-semibold text-sidebar-foreground hover:bg-sidebar-accent lg:flex",
									style: { backgroundColor: shut ? void 0 : `${c.main}1f` },
									"aria-expanded": !shut,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-3",
										children: [(() => {
											const Icon = SECTION_ICON[sec];
											return Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												className: "h-5 w-5",
												style: { color: c.main }
											}) : null;
										})(), sectionName(sec, !!addons?.includes("personal"))]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-3.5 w-3.5 transition-transform", shut && "-rotate-90") })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.url,
									title: item.title,
									className: cn("flex items-center justify-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors lg:justify-start", sec && "lg:ml-3", shut && "lg:hidden", active ? "text-white" : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground"),
									style: active ? { backgroundColor: c.main } : void 0,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
										className: "h-5 w-5 shrink-0",
										style: active ? void 0 : { color: c.main }
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden lg:inline",
										children: item.title
									})]
								}),
								item.url === "/settings" && !shut && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden lg:block",
									children: lookButtons
								})
							] }, item.url);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-sidebar-border p-3",
						children: [
							email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hidden truncate px-3 pb-2 text-xs text-sidebar-foreground/60 lg:block",
								children: email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "hidden px-3 pb-2 text-[11px] text-sidebar-foreground/45 lg:block",
								title: "Compare this with the preview in Lovable to see if the latest changes are published.",
								children: [
									siteKind(),
									" · ",
									versionLabel()
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden",
								children: lookButtons
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => openHelp(),
								title: "Help for this page (F1)",
								className: "flex w-full items-center justify-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground lg:justify-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "hidden lg:inline",
									children: ["Help ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-sidebar-foreground/50",
										children: "F1"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: signOut,
								title: "Sign out",
								className: "flex w-full items-center justify-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-foreground lg:justify-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden lg:inline",
									children: "Sign out"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex h-14 items-center justify-between border-b bg-sidebar px-4 md:hidden print:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { auto: true }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyPicker, { className: "mx-2 max-w-[9rem]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GlobalSearch, {
							compact: true,
							className: "mr-2 border-0 bg-transparent px-2"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => openHelp(),
							"aria-label": "Help",
							className: "mr-1 rounded-md p-1.5 text-sidebar-foreground/75",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleQuestionMark, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanButton, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex-1 bg-[var(--section-soft)]/60 pb-24 md:pb-0 dark:bg-background print:bg-white print:pb-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 w-full bg-[var(--section)] print:hidden" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageTabs, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrialBanner, {}),
						children
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 print:hidden border-t bg-card pb-[env(safe-area-inset-bottom)] md:hidden",
				children: [bottom.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.url,
					className: cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", isActive(item.url) ? "text-primary" : "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
						className: "h-5 w-5",
						style: { color: colorOfItem(item).main }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "line-clamp-1 px-0.5 text-center",
						children: SHORT[item.url] ?? item.title
					})]
				}, item.url)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setMoreOpen(true),
					className: cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", moreActive ? "text-primary" : "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" }), "More"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpCenter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoeboxDrop, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneBarPicker, {
				open: picking,
				onOpenChange: setPicking,
				items,
				current: bottom.map((i) => i.url),
				custom: !!barChoice?.mine
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: moreOpen,
				onOpenChange: setMoreOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					side: "bottom",
					className: "max-h-[85vh] overflow-y-auto rounded-t-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
						className: "flex-row items-center justify-between gap-2 space-y-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "More" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setMoreOpen(false);
								setPicking(true);
							},
							className: "rounded-lg border px-3 py-1.5 text-xs font-medium",
							children: "Change the bottom buttons"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 px-4 pb-6",
						children: [more.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.url,
							onClick: () => setMoreOpen(false),
							className: cn("flex flex-col items-center gap-2 rounded-xl border p-3 text-center text-xs font-medium", isActive(item.url) ? "border-primary bg-primary/10 text-primary" : "bg-card"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
								className: "h-5 w-5",
								style: { color: colorOfItem(item).main }
							}), item.title]
						}, item.url)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: signOut,
							className: "flex flex-col items-center gap-2 rounded-xl border bg-card p-3 text-xs font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-5 w-5" }), "Sign out"]
						})]
					})]
				})
			})
		]
	});
}
/** Free-trial reminder for customer accounts (never shown to our own group). */
function TrialBanner() {
	const { data: account } = useMyAccount();
	const writable = canWrite(account);
	(0, import_react.useEffect)(() => setReadOnly(!writable), [writable]);
	if (!account || account.is_platform && account.edition !== "desktop") return null;
	const desk = account.edition === "desktop";
	const days = trialDaysLeft(account);
	if (writable && days == null) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-center gap-x-2 bg-[#0F2A44] px-4 py-1.5 text-center text-xs text-white print:hidden",
		children: [writable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Free trial:",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
				days,
				" day",
				days === 1 ? "" : "s"
			] }),
			" ",
			"left."
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			account.status === "canceled" ? desk ? "Your license isn't valid." : "Your plan has ended." : "Your free trial has ended.",
			" ",
			"Your books are read-only: you can still open, print and download everything."
		] }), desk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/settings",
				hash: "plan",
				className: "font-semibold underline",
				children: "Enter your license key"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "or" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: PLANS_URL,
				target: "_blank",
				rel: "noreferrer",
				className: "font-semibold underline",
				children: "buy Tallkeep"
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/plan",
			className: "font-semibold underline",
			children: writable ? "See plans" : "Choose a plan"
		})]
	});
}
/** Pick the four buttons on the phone's bottom bar, in the order tapped. */
function PhoneBarPicker({ open, onOpenChange, items, current, custom }) {
	const save = useSavePhoneBar();
	const [picked, setPicked] = (0, import_react.useState)([]);
	const need = Math.min(4, items.length);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (open) setPicked([]);
	}, [open]);
	const tap = (url) => setPicked((p) => p.includes(url) ? p.filter((x) => x !== url) : p.length >= need ? p : [...p, url]);
	async function done(urls) {
		setBusy(true);
		try {
			await save(urls);
			toast.success(urls ? "Your buttons are saved." : "Back to the usual buttons.");
			onOpenChange(false);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "bottom",
			className: "max-h-[85vh] overflow-y-auto rounded-t-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Your bottom buttons" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Tap ",
						need,
						" pages in the order you want them (",
						picked.length,
						" of ",
						need,
						"). Tap again to take one off. More is always last. Now:",
						" ",
						current.map((u) => {
							const it = items.find((i) => i.url === u);
							return it ? SHORT[u] ?? it.title : "";
						}).filter(Boolean).join(", "),
						"."
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2 px-4 py-3",
					children: items.map((item) => {
						const n = picked.indexOf(item.url);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => tap(item.url),
							className: cn("relative flex flex-col items-center gap-2 rounded-xl border p-3 text-center text-xs font-medium", n >= 0 ? "border-primary bg-primary/10 text-primary" : "bg-card"),
							children: [
								n >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-1.5 top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground",
									children: n + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
									className: "h-5 w-5",
									style: { color: colorOfItem(item).main }
								}),
								item.title
							]
						}, item.url);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 px-4 pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy || picked.length !== need,
						onClick: () => void done(picked),
						className: "rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground disabled:opacity-50",
						children: picked.length === need ? "Save my buttons" : `Pick ${need - picked.length} more`
					}), custom && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						onClick: () => void done(null),
						className: "rounded-lg border px-4 py-2 text-sm font-medium",
						children: "Use the usual buttons"
					})]
				})
			]
		})
	});
}
function Layout() {
	const { user } = Route.useRouteContext();
	const { data: access } = useAccess(user.id);
	const path = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const { data: addons } = useAddons();
	const allowed = canSeePath(access, path) && !addonOffForPath(addons, path);
	(0, import_react.useEffect)(() => {
		if (access && access.member === false) return void navigate({
			to: "/welcome",
			replace: true
		});
		if (access && !allowed) navigate({
			to: firstAllowedUrl(access),
			replace: true
		});
	}, [
		access,
		allowed,
		navigate
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		email: user.email,
		access,
		children: access && access.member !== false && allowed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) : null
	});
}
//#endregion
export { Layout as component };
