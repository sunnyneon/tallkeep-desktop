import { J as redirect, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/plan-B06P5MSS.js
var $$splitComponentImporter = () => import("./plan-BXOBZ05N.mjs");
/** Online accounts: pick a plan, pay monthly or yearly, change it, or manage the card. */
var Route = createFileRoute("/_authenticated/plan")({
	validateSearch: (s) => typeof s["session"] === "string" ? { session: s["session"] } : {},
	beforeLoad: () => {
		if ({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
			"VITE_SUPABASE_URL": "http://localhost:4600",
			"VITE_TALLKEEP_DESKTOP": "1"
		}["VITE_TALLKEEP_DESKTOP"]) throw redirect({ to: "/settings" });
	},
	head: () => ({ meta: [{ title: "Plan & billing · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
