//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-juYhUxYU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-vB_V34b8.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-B1u4pBnC.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-Dx98tdfu.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-vB_V34b8.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DXEu4Ocd.js",
			"/assets/log-out-DEliOr8x.js",
			"/assets/testers.functions-Dg5kDar0.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DNnUaZQI.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CSUoqTkR.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-CBNN3yWm.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/dist-DcjvaPBj.js",
			"/assets/dialog-CWnZAXJ4.js",
			"/assets/queries-q3TQdUlm.js",
			"/assets/input-FtJO-33F.js",
			"/assets/label-DOWCcFUM.js",
			"/assets/textarea-BroPP6hF.js",
			"/assets/shoebox-CvLOGtOH.js",
			"/assets/company-ByzVovHQ.js",
			"/assets/reports-Da09LvOe.js",
			"/assets/access-RCW4YgHz.js",
			"/assets/theme-lXtOKhEl.js",
			"/assets/Logo-B4miZhof.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CjSacjQm.js",
			"/assets/log-out-DEliOr8x.js",
			"/assets/admin.functions-D1z1KhtF.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-B4miZhof.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-w5_8ALC1.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/label-DOWCcFUM.js",
			"/assets/Logo-B4miZhof.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Bze2eIzg.js",
			"/assets/testers.functions-Dg5kDar0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/coupons.functions-CmZlzYjK.js",
			"/assets/buy.functions-DNb4eTjd.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DMh6qr2f.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/downloads.functions-CFPzguWN.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-293bJVG1.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/label-DOWCcFUM.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-C38AXBpf.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/label-DOWCcFUM.js",
			"/assets/Logo-B4miZhof.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-DET62P3U.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/upgrade.functions-DD20OYwS.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-BKXEZwt3.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/label-DOWCcFUM.js",
			"/assets/Logo-B4miZhof.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BDJdSe9-.js",
			"/assets/select-C8BBooqf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-SNqgpbld.js", "/assets/StockDocList-BazPYJw3.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-Df-DGgIY.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/ai-7SYVYoZ2.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BMb-XAMy.js",
			"/assets/BankConnections-Bt47-OxD.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers--Fd6UUmq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BN4BCHET.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-Bt47-OxD.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/ai-7SYVYoZ2.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-D90sckve.js",
			"/assets/TxnEditor-DQmjNjMQ.js",
			"/assets/feedWaiting-cEyzcmQE.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-CGE-ePs0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-CiHbBtan.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DmuwSCuz.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/personal-DpfhyO80.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/WhoPicker-1TbT8WE0.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BXPWMxfu.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CVaQW8oZ.js", "/assets/AccountRegister-OEfL0nSU.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Ba8gOdX-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CeV9cVw-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/money-UWHMvVIF.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CScxvPo9.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-7SYVYoZ2.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales--NOonkue.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-q9Ahd-ls.js", "/assets/StockDocList-BazPYJw3.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DzPWrlFa.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-V8G--3LJ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DLCRZW1a.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CGmaFxkF.js", "/assets/PartyList-CkwEWi7G.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DZdrjt_l.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DE3UeyT-.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/storage.functions-Bbd-SBZa.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-TQg1A0pe.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-pOyarRgd.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-Bnt_v0Ra.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BcpQ1rQe.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DpYNdPEc.js", "/assets/ChangeHistory-TF2YsTv9.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-Bam1c3Ug.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/members-DmZW2kk1.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DkyjxoP5.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/personal-DpfhyO80.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/WhoPicker-1TbT8WE0.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CcSy1jdr.js", "/assets/SalesList-DQr_rBvu.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-Tx7EuDw8.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-pH4dN2GB.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-Cpd3N5g1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-meZLvCvB.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/loans-D90sckve.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-w91te9oM.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-CrPmcYus.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-C3NpzWPG.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/personal-DpfhyO80.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/WhoPicker-1TbT8WE0.js",
			"/assets/reminders-Cq0aKg2K.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-iC-MAE0p.js",
			"/assets/select-C8BBooqf.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DiT4tJeC.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/personal-DpfhyO80.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/WhoPicker-1TbT8WE0.js",
			"/assets/generateCategoricalChart-Cs2Im38S.js",
			"/assets/Area-Def8xvoi.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-luj5O65L.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/generateCategoricalChart-Cs2Im38S.js",
			"/assets/PlCharts-Bnt_v0Ra.js",
			"/assets/BarChart-CUUKXzHu.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DpCq4ixf.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/balances-CiHbBtan.js",
			"/assets/money-UWHMvVIF.js",
			"/assets/DecimalInput-olkLCTJK.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-B9KZ_Sfx.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-B2NKzGRz.js",
			"/assets/createServerFn-Nks6kjq1.js",
			"/assets/auth-middleware-D7d-fAt7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/storage.functions-Bbd-SBZa.js",
			"/assets/coupons.functions-CmZlzYjK.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-C2WhDF79.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Co6Uynt8.js",
			"/assets/select-C8BBooqf.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/DecimalInput-olkLCTJK.js",
			"/assets/StockDialogs-Div9YLnJ.js",
			"/assets/checkbox-DzWRAO6R.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CnyFiDv-.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders--5tKOJAP.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-C8BBooqf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales--NOonkue.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DJDGmXSB.js", "/assets/SalesList-DQr_rBvu.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CHN0qkIK.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/ai-7SYVYoZ2.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bbd-SBZa.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CkS5U9da.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/money-UWHMvVIF.js",
			"/assets/badge-Cw40FNMT.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BzBVVPLJ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BIvhK3Kj.js", "/assets/AccountRegister-OEfL0nSU.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-RmaRv_RE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/MoneyAccountPick-Bg8s4psb.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BOHRd9OC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BgUolF_G.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/RepeatInvoice-B_R07JCU.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DMMjhuYS.js",
			"/assets/select-C8BBooqf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/sales--NOonkue.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-Cs2Im38S.js",
			"/assets/BarChart-CUUKXzHu.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-C9s3hGv2.js", "/assets/SalesList-DQr_rBvu.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CIGzXTCu.js", "/assets/SalesList-DQr_rBvu.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BNjYGirV.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-crAiUhrh.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/serials-BYzRjvnC.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CGEEVtTh.js",
			"/assets/createServerFn-Nks6kjq1.js",
			"/assets/auth-middleware-D7d-fAt7.js",
			"/assets/AppsCatalog-Df_mVbw-.js",
			"/assets/select-C8BBooqf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-C1oVpO_7.js",
			"/assets/switch-CrPmcYus.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-DLCRZW1a.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-Dh1Yvdv7.js",
			"/assets/footers-oPOGT4eC.js",
			"/assets/PrintFrame-NwizC_jX.js",
			"/assets/checkbox-DzWRAO6R.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D8QtIrql.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-Czx2aoxR.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-Df_mVbw-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-Bt47-OxD.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-acqThNqh.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/StockDialogs-Div9YLnJ.js",
			"/assets/photos-Dh1Yvdv7.js",
			"/assets/stockmove-By5KPr4W.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CGJyboRc.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/loans-D90sckve.js",
			"/assets/feedWaiting-cEyzcmQE.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bbd-SBZa.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-D0qGZ-0h.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/PrintFrame-NwizC_jX.js",
			"/assets/DocPdf-D5jnonZK.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-CFHv_8KM.js",
			"/assets/createServerFn-Nks6kjq1.js",
			"/assets/auth-middleware-D7d-fAt7.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/MoneyAccountPick-Bg8s4psb.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D8QtIrql.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-NAUxH-Iq.js",
			"/assets/select-C8BBooqf.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/StockDialogs-Div9YLnJ.js",
			"/assets/stockmove-By5KPr4W.js",
			"/assets/checkbox-DzWRAO6R.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BacB-Vxp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/members-DmZW2kk1.js",
			"/assets/WhoPicker-1TbT8WE0.js",
			"/assets/reminders-Cq0aKg2K.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-l_JL5pli.js",
			"/assets/select-C8BBooqf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/tickets.functions-7klQsCuy.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CXe7aHRU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D8QtIrql.js",
			"/assets/support.functions-CF0hJf_S.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Bs05tiZQ.js", "/assets/StockDocList-BazPYJw3.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CwaRBmVM.js", "/assets/PartyList-CkwEWi7G.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BjlNvxkF.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/tickets.functions-7klQsCuy.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-Darnp9Vc.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/workorders-C6l4d8Fx.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BUpwB19s.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-C6Qi5yO6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/coupons.functions-CmZlzYjK.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-C5kzgDdx.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/AdminAccount-CYm_CbPK.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-B_cyjWt1.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/downloads.functions-CFPzguWN.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C5SXMFQm.js",
			"/assets/createServerFn-Nks6kjq1.js",
			"/assets/auth-middleware-D7d-fAt7.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CmVswJsH.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DQjIxGsT.js",
			"/assets/testers.functions-Dg5kDar0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-C52O816S.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-CrqT3AaP.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DNb4eTjd.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BTG-UNJz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/textarea-BroPP6hF.js",
			"/assets/support.functions-CF0hJf_S.js",
			"/assets/HelpParts-D-fzUirq.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CBR90qqb.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CnZK9BIn.js",
			"/assets/manual._slug-CNt3bH01.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-D2EV8LB0.js",
			"/assets/createServerFn-Nks6kjq1.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DWfIk_5p.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DD20OYwS.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CwqZn6S3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-7SYVYoZ2.js",
			"/assets/personal-DpfhyO80.js",
			"/assets/reminders-Cq0aKg2K.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BKFInOrl.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/AdminAccount-CYm_CbPK.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DHFIXouM.js", "/assets/ManualFrame-CnZK9BIn.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B4RazbQD.js", "/assets/AccountRegister-OEfL0nSU.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-zALhgGO7.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/OriginalLink-BL39Uc0W.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/realestate-B_LIRcQd.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-kZyDBpI6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/realestate-B_LIRcQd.js",
			"/assets/money-UWHMvVIF.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DqkS4l8L.js",
			"/assets/select-C8BBooqf.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-0CEOKnA1.js",
			"/assets/sales--NOonkue.js",
			"/assets/SideList-D5MUpJEo.js",
			"/assets/PartyHistory-DYBU6jHW.js",
			"/assets/tabs-RrUAWwsc.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-3Ljhs-1W.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C8BBooqf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/ChangeHistory-TF2YsTv9.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/sales--NOonkue.js",
			"/assets/SideList-D5MUpJEo.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-olkLCTJK.js",
			"/assets/StockDialogs-Div9YLnJ.js",
			"/assets/NewProductDialog-CQ-CEm-V.js",
			"/assets/MoneyAccountPick-Bg8s4psb.js",
			"/assets/footers-oPOGT4eC.js",
			"/assets/PrintFrame-NwizC_jX.js",
			"/assets/serials-BYzRjvnC.js",
			"/assets/SerialsBox-B_NBQIP7.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DvL53I8-.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-C8BBooqf.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-TF2YsTv9.js",
			"/assets/switch-CrPmcYus.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Cw40FNMT.js",
			"/assets/SideList-D5MUpJEo.js",
			"/assets/tabs-RrUAWwsc.js",
			"/assets/StockDialogs-Div9YLnJ.js",
			"/assets/photos-Dh1Yvdv7.js",
			"/assets/stockmove-By5KPr4W.js",
			"/assets/serials-BYzRjvnC.js",
			"/assets/SerialsBox-B_NBQIP7.js",
			"/assets/workorders-C6l4d8Fx.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-QvE9F1SA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C8BBooqf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/ChangeHistory-TF2YsTv9.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/booksStart-0CEOKnA1.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/sales--NOonkue.js",
			"/assets/SideList-D5MUpJEo.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-olkLCTJK.js",
			"/assets/NewProductDialog-CQ-CEm-V.js",
			"/assets/MoneyAccountPick-Bg8s4psb.js",
			"/assets/footers-oPOGT4eC.js",
			"/assets/PrintFrame-NwizC_jX.js",
			"/assets/cardpay-DWggewNA.js",
			"/assets/checkbox-DzWRAO6R.js",
			"/assets/serials-BYzRjvnC.js",
			"/assets/workorders-C6l4d8Fx.js",
			"/assets/RepeatInvoice-B_R07JCU.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-7klQsCuy.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-ZQ1PePNm.js",
			"/assets/select-C8BBooqf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales--NOonkue.js",
			"/assets/SideList-D5MUpJEo.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CqYWm0PY.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/quickadd--PFfy541.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-D8QtIrql.js",
			"/assets/support.functions-CF0hJf_S.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BGClHU0M.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-mXpM5gRa.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/SideList-D5MUpJEo.js",
			"/assets/PartyHistory-DYBU6jHW.js",
			"/assets/tabs-RrUAWwsc.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-Cuif1QP2.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/accounting-BT3YenHO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/sales--NOonkue.js",
			"/assets/footers-oPOGT4eC.js",
			"/assets/tickets.functions-7klQsCuy.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DDOfQoJL.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/input-FtJO-33F.js",
			"/assets/skeleton-BQjkFQyK.js",
			"/assets/AdminAccount-CYm_CbPK.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-D4-5oJdi.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-KeAmGcwV.js",
			"/assets/textarea-BroPP6hF.js",
			"/assets/support-D8QtIrql.js",
			"/assets/support.functions-CF0hJf_S.js",
			"/assets/HelpParts-D-fzUirq.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Doz4JKk9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BQjkFQyK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
