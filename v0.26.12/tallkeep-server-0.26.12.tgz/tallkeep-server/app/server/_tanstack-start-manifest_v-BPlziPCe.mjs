//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BPlziPCe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-B664Z9DJ.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DKxw4vyV.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-9aUzMrzS.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B664Z9DJ.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-Du-QmSS-.js",
			"/assets/log-out-C72nztwH.js",
			"/assets/testers.functions-BilNjMyM.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DL6K1eG6.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BGmscIj9.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CpCpPr4_.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/dist-D5Gc599Z.js",
			"/assets/dialog-DuLxwdfJ.js",
			"/assets/queries-DG4nZiLg.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/label-IFBvmewl.js",
			"/assets/textarea-BvcgYuEy.js",
			"/assets/shoebox-DL6wlZlh.js",
			"/assets/company-6ivUg5aZ.js",
			"/assets/reports-Dduyo0xv.js",
			"/assets/access-Cec2L_3B.js",
			"/assets/LicenseCard-DcHVJGd7.js",
			"/assets/Logo-gcnzKJSn.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-D9CWIT5S.js",
			"/assets/log-out-C72nztwH.js",
			"/assets/admin.functions-26vCGjJK.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-gcnzKJSn.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-GBeSEccD.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/label-IFBvmewl.js",
			"/assets/Logo-gcnzKJSn.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BVEY5Nmj.js",
			"/assets/testers.functions-BilNjMyM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/buy.functions-BOrUWa0F.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-Ba9Gor6s.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/downloads.functions-BW4yferj.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-DIeHRxn-.js",
			"/assets/testers.functions-BilNjMyM.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/textarea-BvcgYuEy.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CvbHcYal.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/label-IFBvmewl.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-B8KBsOrP.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/label-IFBvmewl.js",
			"/assets/Logo-gcnzKJSn.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-Dm987D5f.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/upgrade.functions-CL65N8UA.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CPgqy0LD.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/label-IFBvmewl.js",
			"/assets/Logo-gcnzKJSn.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-D9o6ktUh.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-4VBdeFBm.js", "/assets/StockDocList-Cmh_swBO.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BqKbm4IG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/ai-BGkI_g17.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-ByiwsNap.js",
			"/assets/BankConnections-CYSPtoe5.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers--GxaQ2dE.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-D_oWz946.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-CYSPtoe5.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/ai-BGkI_g17.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-2y4GtOfa.js",
			"/assets/TxnEditor-BidRUV_u.js",
			"/assets/feedWaiting-Bd54Jsom.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-C76t9CM5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-B77_JobR.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/personal-B2xda2OC.js",
			"/assets/members-BkcvNudb.js",
			"/assets/WhoPicker-h7_co7-h.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BWahm8Zg.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DTTOQKlF.js", "/assets/AccountRegister-BwlkZ_X6.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CUydN4nB.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-LH35GWZD.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/money-DPyAzpie.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-XjMt9C_W.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BGkI_g17.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-CMOQFokI.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-aGsTjAEz.js", "/assets/StockDocList-Cmh_swBO.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DLWwycfO.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CGDWmJhY.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BkcvNudb.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-fgCen24p.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D7Pa9uUZ.js", "/assets/PartyList-BdIdOteS.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-D2T2DxbR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CwYOOiaQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/storage.functions-DdWRSNBI.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CAY2QCKR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DYYUGCA6.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-oStdhwxL.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BF2Nq0EC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-v18exKjw.js", "/assets/ChangeHistory-BLx_7_gb.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-C-HUzYob.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/members-BkcvNudb.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-B2qIrb3N.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/personal-B2xda2OC.js",
			"/assets/members-BkcvNudb.js",
			"/assets/WhoPicker-h7_co7-h.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-XmiydVQa.js", "/assets/SalesList-BMEay2MK.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CwbBofjf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-C49e4ssf.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-9FWfLc2d.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-ecXXmLGs.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/loans-2y4GtOfa.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DV_QdRzD.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BCkszmCh.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Bq8zcLJ7.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/personal-B2xda2OC.js",
			"/assets/members-BkcvNudb.js",
			"/assets/WhoPicker-h7_co7-h.js",
			"/assets/reminders-CpPvb1al.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BmzE9QBU.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-B56tLvXm.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/personal-B2xda2OC.js",
			"/assets/members-BkcvNudb.js",
			"/assets/WhoPicker-h7_co7-h.js",
			"/assets/generateCategoricalChart-BZFo01yg.js",
			"/assets/Area-DI29YmRW.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DI3W1Wx_.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/generateCategoricalChart-BZFo01yg.js",
			"/assets/PlCharts-oStdhwxL.js",
			"/assets/BarChart-DkXpTb7K.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-n-5RboLs.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-ruCSEgqB.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CPYTrz-a.js",
			"/assets/createServerFn-D8x6JcRt.js",
			"/assets/auth-middleware-fVUiZVU3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/storage.functions-DdWRSNBI.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BDn4FmbQ.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CXDAX0b0.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/checkbox-DCgatmgv.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-C5r0yDcJ.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-C0crjCQI.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-yGpXzgB0.js", "/assets/SalesList-BMEay2MK.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CMxXvYYj.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/ai-BGkI_g17.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DdWRSNBI.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-yUm8hHpb.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/money-DPyAzpie.js",
			"/assets/badge-BcshkQTW.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-A2Jfg55r.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-D9qWnRSW.js", "/assets/AccountRegister-BwlkZ_X6.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Dah9Kpaq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/MoneyAccountPick-BGADWkFI.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-UaqwWL7P.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-Jw7SQQlC.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/RepeatInvoice-DXBXCKr4.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-6zkbJMXI.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BZFo01yg.js",
			"/assets/BarChart-DkXpTb7K.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-dIA_5oeH.js", "/assets/SalesList-BMEay2MK.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CYUXrJWm.js", "/assets/SalesList-BMEay2MK.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-DLkhY6mW.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DR2MQPbZ.js",
			"/assets/createServerFn-D8x6JcRt.js",
			"/assets/auth-middleware-fVUiZVU3.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-NXL1kz8L.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BBHHSa5O.js",
			"/assets/switch-BCkszmCh.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-fgCen24p.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DVw0pPZv.js",
			"/assets/footers-CkeeNl9x.js",
			"/assets/PrintFrame-fPAZ5S4f.js",
			"/assets/checkbox-DCgatmgv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-Dg7SvQS9.js",
			"/assets/FeaturePicker-DZmGxx1y.js",
			"/assets/support-CkXA9xWE.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DoaMrQsS.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/FeaturePicker-DZmGxx1y.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-B09II35R.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-C6cmK7xa.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/photos-DVw0pPZv.js",
			"/assets/stockmove-SVjM4G_G.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BS2Q3Cs7.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/loans-2y4GtOfa.js",
			"/assets/feedWaiting-Bd54Jsom.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DdWRSNBI.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-zRM47n2e.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/PrintFrame-fPAZ5S4f.js",
			"/assets/DocPdf-BcMFrJI-.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-CMhrXrqB.js",
			"/assets/createServerFn-D8x6JcRt.js",
			"/assets/auth-middleware-fVUiZVU3.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/MoneyAccountPick-BGADWkFI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CkXA9xWE.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DPz13CmH.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/StockDialogs-C6cmK7xa.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/stockmove-SVjM4G_G.js",
			"/assets/checkbox-DCgatmgv.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-D5_llKOW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/members-BkcvNudb.js",
			"/assets/WhoPicker-h7_co7-h.js",
			"/assets/reminders-CpPvb1al.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-D__Ppmj_.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/tickets.functions-D_EVxLv0.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Db9Og8V3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CkXA9xWE.js",
			"/assets/support.functions-CD_xHZCh.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-TEC6pQ7_.js", "/assets/StockDocList-Cmh_swBO.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DClITuUh.js", "/assets/PartyList-BdIdOteS.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-D2q9-21a.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/tickets.functions-D_EVxLv0.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-BN-eJIRO.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/workorders-CLHl5ske.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DRaubKba.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-C9HhJTf1.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/AdminAccount-nzO-0IAb.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-DlbARyWy.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/downloads.functions-BW4yferj.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C902Ygyr.js",
			"/assets/createServerFn-D8x6JcRt.js",
			"/assets/auth-middleware-fVUiZVU3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-qt7fRDIK.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CIDsNiVh.js",
			"/assets/testers.functions-BilNjMyM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CpqRy_ZJ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BE8PMv0C.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BOrUWa0F.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Cd2Exd3-.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/textarea-BvcgYuEy.js",
			"/assets/support.functions-CD_xHZCh.js",
			"/assets/HelpParts-DLLFK5pg.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BTFOEJ3R.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BkLMRTyQ.js",
			"/assets/manual._slug-Bd5LdJLH.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CthfOK7P.js",
			"/assets/createServerFn-D8x6JcRt.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CNMpMz0v.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-CL65N8UA.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Dgnnz5ok.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BGkI_g17.js",
			"/assets/personal-B2xda2OC.js",
			"/assets/reminders-CpPvb1al.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-PI0PDh0r.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/AdminAccount-nzO-0IAb.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-Du7pk7nG.js", "/assets/ManualFrame-BkLMRTyQ.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B1S-RwD5.js", "/assets/AccountRegister-BwlkZ_X6.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-M2JkjrOx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/OriginalLink-jBDmGf5x.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/realestate-CXaLJik8.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C9COI05F.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-DUHdM0dp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/realestate-CXaLJik8.js",
			"/assets/money-DPyAzpie.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-69QX84iv.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/SideList-D9xOmC8b.js",
			"/assets/PartyHistory-wcIcUd-t.js",
			"/assets/tabs-D67Aj6ut.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DmB1RIId.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-NXL1kz8L.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLx_7_gb.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/SideList-D9xOmC8b.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-D1s-H_Yq.js",
			"/assets/MoneyAccountPick-BGADWkFI.js",
			"/assets/footers-CkeeNl9x.js",
			"/assets/PrintFrame-fPAZ5S4f.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Dv9BVc7_.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-C6cmK7xa.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLx_7_gb.js",
			"/assets/switch-BCkszmCh.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/badge-BcshkQTW.js",
			"/assets/SideList-D9xOmC8b.js",
			"/assets/tabs-D67Aj6ut.js",
			"/assets/photos-DVw0pPZv.js",
			"/assets/stockmove-SVjM4G_G.js",
			"/assets/workorders-CLHl5ske.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-Db8b7A18.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-NXL1kz8L.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BLx_7_gb.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/SideList-D9xOmC8b.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-D1s-H_Yq.js",
			"/assets/MoneyAccountPick-BGADWkFI.js",
			"/assets/footers-CkeeNl9x.js",
			"/assets/PrintFrame-fPAZ5S4f.js",
			"/assets/checkbox-DCgatmgv.js",
			"/assets/workorders-CLHl5ske.js",
			"/assets/RepeatInvoice-DXBXCKr4.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-D_EVxLv0.js",
			"/assets/users.functions-Dg7SvQS9.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BjyfEY1x.js",
			"/assets/select-C-EF-lKj.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/SideList-D9xOmC8b.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-DMQzF2C7.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/quickadd-BlkyXILa.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CkXA9xWE.js",
			"/assets/support.functions-CD_xHZCh.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-Dt1GwAwF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNtX_95E.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/SideList-D9xOmC8b.js",
			"/assets/PartyHistory-wcIcUd-t.js",
			"/assets/tabs-D67Aj6ut.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CvOOerm1.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/sales-CMOQFokI.js",
			"/assets/footers-CkeeNl9x.js",
			"/assets/tickets.functions-D_EVxLv0.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B3swPzng.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/input-H0tLNNr5.js",
			"/assets/skeleton-DSuYRCTM.js",
			"/assets/AdminAccount-nzO-0IAb.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-C8vWQi8V.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DjBCvsPC.js",
			"/assets/textarea-BvcgYuEy.js",
			"/assets/support-CkXA9xWE.js",
			"/assets/support.functions-CD_xHZCh.js",
			"/assets/HelpParts-DLLFK5pg.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BuSxIN7E.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DSuYRCTM.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
