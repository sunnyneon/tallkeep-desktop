import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as getRequest } from "./request-response-C-WzAr0X.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/downloads.functions-DCx4OkUo.js
/**
* The download page: a short form (name, email), then the download starts and we email the
* link and setup steps. The owner panel lists downloads, and how many installs run Tallkeep.
*/
var LINKS = {
	windows: "https://app.tallkeep.com/api/public/download",
	linux: "https://app.tallkeep.com/api/public/download?for=server"
};
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
/** Downloads per internet address in the last hour (kept in this server's memory). */
var recent = /* @__PURE__ */ new Map();
function tooMany() {
	let ip = "";
	try {
		const h = getRequest()?.headers;
		ip = h?.get("cf-connecting-ip") || h?.get("x-real-ip") || (h?.get("x-forwarded-for") ?? "").split(",")[0].trim() || "";
	} catch {
		return false;
	}
	if (!ip) return false;
	const now = Date.now();
	const list = (recent.get(ip) ?? []).filter((t) => now - t < 36e5);
	if (list.length >= 10) return true;
	list.push(now);
	recent.set(ip, list);
	if (recent.size > 5e3) recent.clear();
	return false;
}
var clean = (v, n) => String(v ?? "").replace(/\s+/g, " ").trim().slice(0, n);
var STEPS = {
	windows: `Setting it up on Windows:
1. Open the file you downloaded (Tallkeep-Setup).
2. If Windows says "Windows protected your PC", press "More info", then "Run anyway".
3. Tallkeep opens in your browser. Make your company and start; it's free for 30 days.
Other computers and phones in the office open Tallkeep by the address it shows you.`,
	linux: `Setting it up on a Synology or a Linux server (needs Docker):
1. Unzip tallkeep-docker.zip into a folder on the server.
2. Synology: open Container Manager → Project → Create, and pick that folder.
   Linux: in that folder, run: docker compose up -d --build
3. Open http://your-server:4600 from any computer, make your company and start; it's free for 30 days.
The README file in the zip has the full steps.`,
	mac: ""
};
var recordDownload_createServerFn_handler = createServerRpc({
	id: "019a423964e1dad1bd104e3a9a51f9a9b938bc4dbfc1395567fb46023a4c414a",
	name: "recordDownload",
	filename: "src/lib/downloads.functions.ts"
}, (opts) => recordDownload.__executeServer(opts));
var recordDownload = createServerFn({ method: "POST" }).inputValidator((d) => {
	const name = clean(d.name, 120);
	const email = clean(d.email, 200).toLowerCase();
	if (!name) throw new Error("Type your name.");
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Type a valid email.");
	if (![
		"windows",
		"linux",
		"mac"
	].includes(d.platform)) throw new Error("Pick a version.");
	return {
		name,
		email,
		business: clean(d.business, 80) || null,
		platform: d.platform,
		source: clean(d.source, 200) || null
	};
}).handler(recordDownload_createServerFn_handler, async ({ data }) => {
	if (tooMany()) throw new Error("Lots of downloads from here just now. Try again in an hour.");
	await (await admin()).from("downloads").insert(data).then(() => null, () => null);
	const url = data.platform === "mac" ? null : LINKS[data.platform];
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const first = data.name.split(" ")[0];
	const text = data.platform === "mac" ? `Hi ${first},\n\nThanks for your interest in Tallkeep for Mac. It isn't ready yet; we'll email you as soon as it is.\n\nIn the meantime you can use Tallkeep online, in any browser on your Mac, free for 30 days:\nhttps://app.tallkeep.com/signup\n\nQuestions? Just reply to this email.\n\nTallkeep` : `Hi ${first},\n\nThanks for downloading Tallkeep! If the download didn't start, here is the link again:\n${url}\n\n${STEPS[data.platform]}\n\nYour books stay on your own computer. When you're ready, buy a license at https://app.tallkeep.com/buy\n\nQuestions? Just reply to this email.\n\nTallkeep`;
	await deliver({
		fromName: "Tallkeep",
		to: [data.email],
		replyTo: "hello@tallkeep.com",
		subject: data.platform === "mac" ? "Tallkeep for Mac: we'll let you know" : "Your Tallkeep download",
		text
	}).catch(() => null);
	return { url };
});
var listDownloads_createServerFn_handler = createServerRpc({
	id: "e48180cae480f45ad9db96730afc03d85cbfe3d41e37c5b8d5887cd9d838dd38",
	name: "listDownloads",
	filename: "src/lib/downloads.functions.ts"
}, (opts) => listDownloads.__executeServer(opts));
var listDownloads = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listDownloads_createServerFn_handler, async ({ context }) => {
	const { requireOwner } = await import("./admin.functions-DHkqk0kg.mjs");
	await requireOwner(context.userId);
	const db = await admin();
	const [d, lic, inst] = await Promise.all([
		db.from("downloads").select("*").order("created_at", { ascending: false }).limit(2e3),
		db.from("desktop_licenses").select("email").not("email", "is", null),
		db.from("installs").select("*")
	]);
	if (d.error) return {
		ready: false,
		rows: [],
		installs: null
	};
	const buyers = new Set((lic.data ?? []).map((l) => l.email.toLowerCase()));
	const rows = (d.data ?? []).map((r) => ({
		...r,
		bought: buyers.has(r.email.toLowerCase())
	}));
	const all = inst.data ?? [];
	const week = Date.now() - 6048e5;
	const active = all.filter((i) => Date.parse(i.last_seen) > week);
	return {
		ready: true,
		rows,
		installs: {
			total: all.length,
			activeWeek: active.length,
			trialActive: active.filter((i) => !i.licensed).length,
			licensedActive: active.filter((i) => i.licensed).length,
			windows: active.filter((i) => i.platform === "windows").length,
			linux: active.filter((i) => i.platform === "linux").length
		}
	};
});
//#endregion
export { listDownloads_createServerFn_handler, recordDownload_createServerFn_handler };
