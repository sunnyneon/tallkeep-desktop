import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ht as Download, at as Mail } from "../_libs/lucide-react.mjs";
import { r as useCategories } from "./queries-CUGyjerL.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as SearchSelect } from "./SearchSelect-KZGKVtkS.mjs";
import { i as SLOT, r as PLACEMENTS } from "./footers-BNGmbiMB.mjs";
import { n as makePdf, r as sendDocEmail, t as blobToBase64 } from "./DocPdf-DIf1ZSo_.mjs";
import { a as useCardPay, r as payLink } from "./cardpay-CotP51jv.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/NewProductDialog-BtKm5W69.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Pick the saved footers for this document; the text can still be changed here. */
function FooterPicker({ footers, doc, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Footers and attached pages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/settings",
					className: "text-xs text-primary underline",
					children: "Edit saved footers"
				})]
			}),
			PLACEMENTS.map((pl) => {
				const { id, text } = SLOT[pl.key];
				const choices = footers.filter((f) => f.placement === pl.key);
				const val = doc[id];
				const body = doc[text];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: pl.pick
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: val ?? "none",
							disabled: disabled ?? false,
							onValueChange: (v) => {
								const f = footers.find((x) => x.id === v);
								onChange({
									[id]: f?.id ?? null,
									[text]: f?.body ?? null
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "None" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "none",
								children: "None"
							}), choices.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: f.id,
								children: f.name
							}, f.id))] })]
						}),
						(val || body) && pl.key !== "attach" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							className: "text-xs",
							disabled: disabled ?? false,
							value: body ?? "",
							onChange: (e) => onChange({ [text]: e.target.value || null })
						})
					]
				}, pl.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Changes here are for this document only."
			})
		]
	});
}
var split = (v) => v.split(/[,;\s]+/).map((x) => x.trim()).filter(Boolean);
/** Send the document as a PDF (with any attached page) from the company email. */
function EmailDocDialog({ doc, filename, to, subject, message, myEmail, onClose, onSent, deposit, payNow }) {
	const { data: card } = useCardPay();
	const canPay = !!payNow && !!card?.connected;
	const [addPay, setAddPay] = (0, import_react.useState)(true);
	const [f, setF] = (0, import_react.useState)({
		to,
		cc: "",
		subject,
		message,
		copyMe: true
	});
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)("");
	const [askDep, setAskDep] = (0, import_react.useState)(false);
	const [pct, setPct] = (0, import_react.useState)(String(deposit?.percent ?? 50));
	const depAmount = deposit ? Math.round(deposit.of * (Number(pct) || 0)) / 100 : 0;
	const opts = () => askDep && depAmount > 0 ? { deposit: depAmount } : {};
	async function send() {
		setBusy("send");
		setFailed("");
		try {
			const blob = await makePdf(doc(opts()));
			const cc = [...split(f.cc), ...f.copyMe && myEmail ? [myEmail] : []];
			let message = f.message;
			if (canPay && addPay) {
				const { url } = await payLink(payNow.invoiceId, askDep && depAmount > 0 ? Math.round(depAmount * 100) : void 0);
				message = `${message.trimEnd()}\n\nPay online by card: ${url}`;
			}
			await sendDocEmail({ data: {
				to: split(f.to),
				cc,
				subject: f.subject,
				message,
				filename,
				pdfBase64: await blobToBase64(blob)
			} });
			toast.success(`Sent to ${f.to}.`);
			onSent?.();
			onClose();
		} catch (e) {
			setFailed(e.message);
		} finally {
			setBusy(null);
		}
	}
	async function download() {
		setBusy("pdf");
		try {
			const blob = await makePdf(doc(opts()));
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = filename;
			a.click();
			setTimeout(() => URL.revokeObjectURL(url), 5e3);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Email ", filename.replace(/\.pdf$/, "")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Sent from the company email with the PDF attached. Replies come back to you." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "To" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.to,
								onChange: (e) => setF({
									...f,
									to: e.target.value
								}),
								placeholder: "customer@example.com"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Copy to (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.cc,
								onChange: (e) => setF({
									...f,
									cc: e.target.value
								}),
								placeholder: "other emails, separated by commas"
							})]
						}),
						myEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: f.copyMe,
									onCheckedChange: (v) => setF({
										...f,
										copyMe: v === true
									})
								}),
								"Send me a copy (",
								myEmail,
								")"
							]
						}),
						canPay && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: addPay,
									onCheckedChange: (v) => setAddPay(v === true)
								}),
								"Add a \"Pay now by card\" link",
								askDep && depAmount > 0 ? " (for the deposit)" : ""
							]
						}),
						deposit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 rounded-xl border p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: askDep,
										onCheckedChange: (v) => setAskDep(v === true)
									}), "Ask for a deposit"]
								}),
								askDep && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "h-8 w-20 text-right",
											inputMode: "decimal",
											value: pct,
											onChange: (e) => setPct(e.target.value)
										}),
										"% of ",
										deposit.label,
										" =",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: depAmount.toLocaleString("en-US", {
											style: "currency",
											currency: "USD"
										}) })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: "Adds a \"Deposit due now\" line to the PDF. Record the money with Record payment when it arrives."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Subject" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.subject,
								onChange: (e) => setF({
									...f,
									subject: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Message" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 6,
								value: f.message,
								onChange: (e) => setF({
									...f,
									message: e.target.value
								})
							})]
						})
					]
				}),
				failed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-900 dark:border-red-900 dark:bg-red-950/40 dark:text-red-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Not sent." }),
						" ",
						failed
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void download(),
						disabled: !!busy,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }),
							" ",
							busy === "pdf" ? "Making PDF…" : "Download PDF"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void send(),
						disabled: !!busy || !f.to.trim(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
							" ",
							busy === "send" ? "Sending…" : "Send email"
						]
					})]
				})
			]
		})
	});
}
/** Add a product without leaving the quote / invoice / purchase order (like inFlow's "Add new"). */
function NewProductDialog({ name, onClose, onCreated }) {
	const qc = useQueryClient();
	const { data: cats } = useCategories();
	const [f, setF] = (0, import_react.useState)({
		name,
		description: "",
		item_type: "stocked",
		price: "",
		cost: "",
		category: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		if (!f.name.trim()) {
			toast.error("Type the product name.");
			return;
		}
		setBusy(true);
		const { data, error } = await db.from("products").insert({
			name: f.name.trim(),
			description: f.description.trim() || null,
			item_type: f.item_type,
			price: Number(f.price) || 0,
			cost: Number(f.cost) || 0,
			category_id: f.category || null
		}).select("id,name,description,price,cost,unit,item_type").single();
		setBusy(false);
		if (error) {
			toast.error(error.message.includes("duplicate") ? "A product with that name already exists." : error.message);
			return;
		}
		toast.success(`${f.name.trim()} added to the product list.`);
		qc.invalidateQueries({ queryKey: ["products"] });
		onCreated(data);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add a new product" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "It's added to your Product List and put on this line." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Item name / code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: f.name,
								onChange: (e) => setF({
									...f,
									name: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.description,
								onChange: (e) => setF({
									...f,
									description: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: f.item_type,
										onValueChange: (v) => setF({
											...f,
											item_type: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "stocked",
												children: "Stocked product"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "non_stocked",
												children: "Non-stocked product"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "service",
												children: "Service / labor"
											})
										] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
										value: f.category,
										onChange: (v) => setF({
											...f,
											category: v
										}),
										options: [...(cats ?? []).map((c) => ({
											value: c.id,
											label: c.name
										}))],
										placeholder: "Choose",
										searchText: "Type a category"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Selling price ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: f.price,
										onChange: (e) => setF({
											...f,
											price: e.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Cost ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: f.cost,
										onChange: (e) => setF({
											...f,
											cost: e.target.value
										})
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Adding…" : "Add product"
				})] })
			]
		})
	});
}
//#endregion
export { FooterPicker as n, NewProductDialog as r, EmailDocDialog as t };
