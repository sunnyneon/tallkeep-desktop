import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Mn as Apple, T as Server, in as Check, lt as LoaderCircle, tt as Monitor } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as BuyFrame } from "./buy-WPDOv50T.mjs";
import { t as Route } from "./download-ZhPNmJEt.mjs";
import { n as recordDownload } from "./downloads.functions-BISBe07G.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/download-DGPbfE5c.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Download Tallkeep: pick Windows, Synology/Linux (or Mac, coming soon), a short form, go. */
var KINDS = [
	{
		key: "windows",
		label: "Windows",
		text: "Windows 10 or 11 computer",
		icon: Monitor
	},
	{
		key: "linux",
		label: "Synology / Linux",
		text: "A Synology NAS or Linux server with Docker",
		icon: Server
	},
	{
		key: "mac",
		label: "Mac",
		text: "Coming soon",
		icon: Apple,
		soon: true
	}
];
var BUSINESS = [
	"Sells products",
	"Makes products",
	"Services",
	"Real estate",
	"Personal / family",
	"Other"
];
function DownloadPage() {
	const search = Route.useSearch();
	const start = search.for === "linux" || search.for === "server" || search.for === "synology" ? "linux" : search.for === "mac" ? "mac" : "windows";
	const [platform, setPlatform] = (0, import_react.useState)(start);
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [business, setBusiness] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(null);
	async function go(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const r = await recordDownload({ data: {
				name,
				email,
				business,
				platform,
				source: search.from ?? (document.referrer || "")
			} });
			setDone(r);
			if (r.url) window.location.href = r.url;
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-bold",
				children: done.url ? "Your download is starting" : "Thanks! We'll let you know"
			}),
			done.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"If it didn't start,",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: done.url,
						className: "font-medium text-primary underline",
						children: "press here"
					}),
					". We also emailed you the link and the setup steps."
				]
			}), platform === "windows" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"If Windows says \"Windows protected your PC\", press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "More info" }),
					", then",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Run anyway" }),
					"."
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Tallkeep for Mac isn't ready yet. We'll email you when it is. Meanwhile you can use Tallkeep online in any browser on your Mac."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "https://app.tallkeep.com/signup",
				className: "inline-block text-sm font-semibold text-primary underline",
				children: "Or use Tallkeep online instead"
			})
		]
	}) });
	const soon = platform === "mac";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: go,
		className: "space-y-5 rounded-2xl border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-bold",
				children: "Download Tallkeep"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Free for 30 days with everything. No card needed. Your books stay on your own computer."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: KINDS.map((k) => {
					const on = platform === k.key;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setPlatform(k.key),
						className: cn("rounded-xl border p-3 text-left text-sm transition-shadow hover:shadow-md", on && "border-primary ring-2 ring-primary"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(k.icon, { className: "h-5 w-5" }), on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-primary" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-2 block font-semibold",
								children: k.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: k.text
							})
						]
					}, k.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Your name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "What's it for? (optional)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: business,
					onChange: (e) => setBusiness(e.target.value),
					className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Choose one"
					}), BUSINESS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				className: "w-full",
				disabled: busy,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }), soon ? "Email me when it's ready" : `Download for ${platform === "windows" ? "Windows" : "Synology / Linux"}`]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"We'll email you the link and setup steps. No spam. Prefer no download?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://app.tallkeep.com/signup",
						className: "text-primary underline",
						children: "Use Tallkeep online"
					}),
					"."
				]
			})
		]
	}) });
}
//#endregion
export { DownloadPage as component };
