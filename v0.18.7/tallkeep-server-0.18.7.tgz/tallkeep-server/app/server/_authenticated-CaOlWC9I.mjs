import { _ as lazyRouteComponent, v as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/_authenticated-CaOlWC9I.js
var $$splitComponentImporter = () => import("./_authenticated-ClummH8l.mjs");
var Route = createFileRoute("/_authenticated/")({
	head: () => ({ meta: [{ title: "Home · Tallkeep" }, {
		name: "description",
		content: "Where to go for each job, in the order the work flows."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
