import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { D as Search, J as Package, R as Plus, jt as FolderTree, m as TriangleAlert, n as X } from "../_libs/lucide-react.mjs";
import { r as useCategories, t as byId } from "./queries-CUGyjerL.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-Biwt2AGn.mjs";
import { t as Route } from "./products-Ck1IUMdS.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/products-CNIYDZOb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useProductList() {
	return useQuery({
		queryKey: ["products"],
		queryFn: () => fetchAll("products", "id,name,description,barcode,item_type,category_id,price,reorder_point,is_active,unit,stock(qty)")
	});
}
function ProductsPage() {
	const navigate = useNavigate();
	const { data, isLoading, error } = useProductList();
	const { data: cats } = useCategories();
	const catName = byId(cats);
	const search = Route.useSearch();
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	const [show, setShow] = (0, import_react.useState)("active");
	const [cat, setCat] = (0, import_react.useState)("all");
	const [picked, setPicked] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [setting, setSetting] = (0, import_react.useState)(false);
	const pick = (id, on) => setPicked((p) => {
		const n = new Set(p);
		if (on) n.add(id);
		else n.delete(id);
		return n;
	});
	const rows = (0, import_react.useMemo)(() => {
		const list = (data ?? []).map((p) => ({
			...p,
			onHand: p.stock.reduce((s, r) => s + Number(r.qty), 0)
		})).filter((p) => show === "all" ? true : p.is_active).filter((p) => show === "negative" ? p.item_type === "stocked" && p.onHand < 0 : true).filter((p) => show === "low" ? p.item_type === "stocked" && Number(p.reorder_point) > 0 && p.onHand <= Number(p.reorder_point) : true).filter((p) => cat === "all" ? true : p.category_id === cat).sort((a, b) => a.name.localeCompare(b.name));
		return smartSearch(list, q, (p) => p.name, (p) => `${p.description ?? ""} ${p.barcode ?? ""}`);
	}, [
		data,
		q,
		show,
		cat
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Product List",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewProductButton, {}),
				text: data ? `${rows.length} of ${data.length} products` : "Your product list, prices and stock."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search name, description or barcode",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: show,
						onValueChange: (v) => setShow(v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "sm:w-44",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "active",
								children: "Active products"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "low",
								children: "Running low"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "negative",
								children: "Below zero (check count)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "All, incl. inactive"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: cat,
						onChange: setCat,
						options: [{
							value: "all",
							label: "All categories"
						}, ...(cats ?? []).map((c) => ({
							value: c.id,
							label: c.name
						}))],
						placeholder: "Category",
						searchText: "Type a category",
						className: "sm:w-52"
					})
				]
			}),
			picked.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-14 z-10 flex flex-wrap items-center gap-2 rounded-2xl border-2 border-[var(--section)] bg-card p-3 md:top-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-medium",
						children: [picked.size, " selected"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setSetting(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderTree, { className: "h-4 w-4" }), " Put in a category"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setPicked(/* @__PURE__ */ new Set()),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), " Clear selection"]
					})
				]
			}),
			setting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryDialog, {
				ids: [...picked],
				onClose: () => setSetting(false),
				onDone: () => {
					setSetting(false);
					setPicked(/* @__PURE__ */ new Set());
				}
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-destructive",
				children: ["Could not load products: ", error.message]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16" }, i))
			}),
			data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-2xl border border-dashed bg-card p-10 text-center text-muted-foreground",
				children: data.length === 0 ? "No products yet. Bring them over from inFlow in Settings." : "No products match your search."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card md:hidden",
				children: rows.slice(0, 300).map((p) => {
					const low = p.item_type === "stocked" && Number(p.reorder_point) > 0 && p.onHand <= Number(p.reorder_point);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 pl-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							"aria-label": "Select",
							className: "h-5 w-5",
							checked: picked.has(p.id),
							onCheckedChange: (v) => pick(p.id, v === true)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/products/$id",
							params: { id: p.id },
							className: "flex min-w-0 flex-1 items-center gap-3 px-3 py-3 transition-colors hover:bg-muted/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-muted text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, { className: "h-5 w-5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-medium",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [p.category_id ? catName.get(p.category_id) : null, p.barcode].filter(Boolean).join(" · ") || "\xA0"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [p.item_type === "stocked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: p.onHand < 0 ? "font-semibold text-destructive" : low ? "font-semibold text-primary" : "font-semibold",
										children: [
											low && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mr-1 inline h-3.5 w-3.5" }),
											fmtQty(p.onHand),
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-normal text-muted-foreground",
												children: p.unit ?? "in stock"
											})
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: p.item_type === "service" ? "Service" : "Not stocked"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: fmtMoney(p.price)
									})]
								}),
								!p.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: "Inactive"
								})
							]
						})]
					}, p.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-2xl border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "w-10 px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									"aria-label": "Select all shown",
									checked: rows.length > 0 && rows.slice(0, 600).every((p) => picked.has(p.id)),
									onCheckedChange: (v) => setPicked((p) => {
										const n = new Set(p);
										rows.slice(0, 600).forEach((r) => v === true ? n.add(r.id) : n.delete(r.id));
										return n;
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Description"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Category"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Normal price"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "In stock"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: rows.slice(0, 600).map((p) => {
							const low = p.item_type === "stocked" && Number(p.reorder_point) > 0 && p.onHand <= Number(p.reorder_point);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "cursor-pointer hover:bg-muted/50",
								onClick: () => navigate({
									to: "/products/$id",
									params: { id: p.id }
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										onClick: (e) => e.stopPropagation(),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											"aria-label": "Select",
											checked: picked.has(p.id),
											onCheckedChange: (v) => pick(p.id, v === true)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "max-w-[260px] truncate px-3 py-2 font-medium",
										style: { color: "var(--section)" },
										children: [p.name, !p.is_active && " (inactive)"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[420px] truncate px-3 py-2 text-muted-foreground",
										children: p.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: p.item_type === "stocked" ? "Stocked product" : p.item_type === "service" ? "Service" : "Non-stocked"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[180px] truncate px-3 py-2",
										children: p.category_id ? catName.get(p.category_id) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(p.price)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: `whitespace-nowrap px-3 py-2 text-right font-semibold ${p.onHand < 0 ? "text-destructive" : low ? "text-primary" : ""}`,
										children: p.item_type === "stocked" ? fmtQty(p.onHand) : ""
									})
								]
							}, p.id);
						})
					})]
				})
			}),
			rows.length > 600 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Showing the first 600. Search to narrow it down."
			})
		]
	});
}
function NewProductButton() {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("stocked");
	async function create(e) {
		e.preventDefault();
		if (!name.trim()) return;
		const { data, error } = await db.from("products").insert({
			name: name.trim(),
			item_type: type
		}).select("id").single();
		if (error) {
			toast.error(error.code === "23505" ? "That name is already used." : error.message);
			return;
		}
		qc.invalidateQueries({ queryKey: ["products"] });
		setOpen(false);
		navigate({
			to: "/products/$id",
			params: { id: data.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick: () => setOpen(true),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New product"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: create,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New product" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Item name / code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						autoFocus: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: type,
						onValueChange: (v) => setType(v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "stocked",
								children: "Stocked product (we keep count)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "non_stocked",
								children: "Non-stocked product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "service",
								children: "Service (labor, shipping…)"
							})
						] })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => setOpen(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: !name.trim(),
					children: "Create product"
				})] })
			]
		}) })
	})] });
}
function CategoryDialog({ ids, onClose, onDone }) {
	const qc = useQueryClient();
	const { data: cats } = useCategories();
	const [cat, setCat] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function go() {
		if (!cat) {
			toast.error("Choose a category.");
			return;
		}
		setBusy(true);
		for (let i = 0; i < ids.length; i += 200) {
			const { error } = await db.from("products").update({ category_id: cat === "none" ? null : cat }).in("id", ids.slice(i, i + 200));
			if (error) {
				toast.error(error.message);
				setBusy(false);
				return;
			}
		}
		setBusy(false);
		toast.success(`${ids.length} products updated.`);
		qc.invalidateQueries({ queryKey: ["products"] });
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
				"Put ",
				ids.length,
				" products in a category"
			] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: cat,
						onChange: setCat,
						options: [{
							value: "none",
							label: "No category"
						}, ...(cats ?? []).map((c) => ({
							value: c.id,
							label: c.name
						}))],
						placeholder: "Choose a category",
						searchText: "Type a category"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Need a new one? Add it in Product Categories first."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void go(),
				disabled: busy,
				children: busy ? "Saving…" : "Save category"
			})] })
		] })
	});
}
//#endregion
export { ProductsPage as component, useProductList };
