import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today } from "./accounting-QuDdqtoA.mjs";
import { i as fmtQty, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Dt as Hammer, R as Plus, f as Undo2, g as Trash2 } from "../_libs/lucide-react.mjs";
import { o as useLocations } from "./queries-CUGyjerL.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-wDrazOwE.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-Biwt2AGn.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { i as useRecipes, n as createWorkOrder, r as useLiteProducts, t as WO_STATUS } from "./workorders-BJqwVDtn.mjs";
import { t as Route } from "./work-orders-Dc67y-au.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/work-orders-CXmHBNdc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var num = (w) => ({
	...w,
	qty: Number(w.qty),
	extra_cost: Number(w.extra_cost),
	parts_cost: w.parts_cost == null ? null : Number(w.parts_cost)
});
function useWorkOrders() {
	return useQuery({
		queryKey: ["work-orders"],
		queryFn: async () => {
			return (await fetchAll("work_orders")).map(num).sort((a, b) => b.number.localeCompare(a.number));
		}
	});
}
function WorkOrders() {
	const search = Route.useSearch();
	const { data: list, isLoading } = useWorkOrders();
	const { data: products } = useLiteProducts();
	const [show, setShow] = (0, import_react.useState)("open");
	const [open, setOpen] = (0, import_react.useState)(search.wo ?? null);
	const [adding, setAdding] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (search.wo) setOpen(search.wo);
	}, [search.wo]);
	const pname = new Map((products ?? []).map((p) => [p.id, p.name]));
	const rows = (list ?? []).filter((w) => show === "all" || w.status === "planned" || w.status === "in_progress");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Work Orders",
			text: "Build products from their parts. Finishing a work order takes the parts out of stock and adds what you built.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setAdding(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New work order"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "inline-flex rounded-lg border p-0.5 text-sm",
			children: ["open", "all"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setShow(v),
				className: `rounded-md px-3 py-1 ${show === v ? "bg-[var(--section)] text-white" : ""}`,
				children: v === "open" ? "To build" : "All"
			}, v))
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [list && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "Nothing to build. Give a product its parts on the product page → \"Made from\", then press \"New work order\"."
			}), rows.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setOpen(w.id),
				className: "flex w-full flex-wrap items-center gap-3 px-4 py-3 text-left hover:bg-muted/50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							w.number,
							" · ",
							fmtQty(w.qty),
							" × ",
							pname.get(w.product_id)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [w.due_date ? `Due ${fmtDate(w.due_date)}` : "No due date", w.done_on ? ` · finished ${fmtDate(w.done_on)}` : ""]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: w.status === "done" ? "secondary" : "default",
					children: WO_STATUS[w.status]
				})]
			}, w.id))]
		}),
		adding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewWorkOrder, { onClose: (id) => {
			setAdding(false);
			if (id) setOpen(id);
		} }),
		open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkOrderDialog, {
			id: open,
			onClose: () => setOpen(null)
		})
	] });
}
function NewWorkOrder({ onClose }) {
	const qc = useQueryClient();
	const { data: products } = useLiteProducts();
	const { data: recipes } = useRecipes();
	const { data: locations } = useLocations();
	const [product, setProduct] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)("1");
	const [loc, setLoc] = (0, import_react.useState)("");
	const [due, setDue] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const options = (products ?? []).filter((p) => p.is_active && recipes?.has(p.id)).map((p) => ({
		value: p.id,
		label: p.name
	}));
	const places = (locations ?? []).filter((l) => l.is_active);
	const p = products?.find((x) => x.id === product);
	(0, import_react.useEffect)(() => {
		if (p && !loc) setLoc(p.default_location_id ?? places[0]?.id ?? "");
	}, [
		p,
		loc,
		places
	]);
	async function save() {
		if (!product) return void toast.error("Pick what to build.");
		if (!(Number(qty) > 0)) return void toast.error("How many?");
		if (!loc) return void toast.error("Pick where it's built.");
		setBusy(true);
		try {
			const w = await createWorkOrder({
				product_id: product,
				qty: Number(qty),
				location_id: loc,
				recipe: recipes?.get(product) ?? [],
				extra_per_unit: p?.build_extra_cost ?? 0,
				due_date: due || null,
				notes: notes.trim() || null
			});
			toast.success(`${w.number} made.`);
			qc.invalidateQueries({ queryKey: ["work-orders"] });
			onClose(w.id);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New work order" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Only products with parts (\"Made from\" on the product page) can be built." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What to build",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: product,
							onChange: setProduct,
							options,
							placeholder: "Pick a product"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How many",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "any",
							value: qty,
							onChange: (e) => setQty(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Due (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: due,
							onChange: (e) => setDue(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Where (parts come from and it goes to)",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: loc,
							onChange: (e) => setLoc(e.target.value),
							className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Pick a place"
							}), places.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: l.id,
								children: l.name
							}, l.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: () => onClose(),
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Making…" : "Make work order"
			})] })
		] })
	});
}
function WorkOrderDialog({ id, onClose }) {
	const qc = useQueryClient();
	const { data: products } = useLiteProducts();
	const { data: locations } = useLocations();
	const { data, isLoading } = useQuery({
		queryKey: ["work-orders", id],
		queryFn: async () => {
			const [w, l] = await Promise.all([db.from("work_orders").select("*").eq("id", id).single(), db.from("work_order_lines").select("*").eq("work_order_id", id)]);
			if (w.error) throw w.error;
			const wo = num(w.data);
			const lines = (l.data ?? []).map((x) => ({
				...x,
				qty: Number(x.qty),
				unit_cost: x.unit_cost == null ? null : Number(x.unit_cost)
			}));
			const ids = lines.map((x) => x.part_id);
			const st = ids.length ? await db.from("stock").select("product_id,qty").eq("location_id", wo.location_id).in("product_id", ids) : { data: [] };
			const have = /* @__PURE__ */ new Map();
			for (const s of st.data ?? []) have.set(s.product_id, (have.get(s.product_id) ?? 0) + Number(s.qty));
			let order = null;
			if (wo.sales_order_id) {
				const { data: so } = await db.from("sales_orders").select("id,number").eq("id", wo.sales_order_id).maybeSingle();
				order = so;
			}
			return {
				wo,
				lines,
				have,
				order
			};
		}
	});
	const [qtys, setQtys] = (0, import_react.useState)({});
	const [extra, setExtra] = (0, import_react.useState)(null);
	const [doneOn, setDoneOn] = (0, import_react.useState)(today());
	const [busy, setBusy] = (0, import_react.useState)(false);
	const pmap = (0, import_react.useMemo)(() => new Map((products ?? []).map((p) => [p.id, p])), [products]);
	if (isLoading || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) })
	});
	const { wo, lines, have, order } = data;
	const editable = wo.status === "planned" || wo.status === "in_progress";
	const short = lines.filter((l) => l.qty > (have.get(l.part_id) ?? 0) + 1e-5);
	const partsCost = wo.parts_cost ?? lines.reduce((s, l) => s + l.qty * (l.unit_cost ?? pmap.get(l.part_id)?.cost ?? 0), 0);
	const extraNow = Number(extra ?? wo.extra_cost) || 0;
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["work-orders"] });
		qc.invalidateQueries({ queryKey: ["products-lite"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	async function saveEdits() {
		const changed = lines.filter((l) => qtys[l.id] != null && Number(qtys[l.id]) !== l.qty);
		for (const l of changed) {
			const { error } = await db.from("work_order_lines").update({ qty: Math.max(0, Number(qtys[l.id]) || 0) }).eq("id", l.id);
			if (error) throw error;
		}
		if (extra != null) {
			const { error } = await db.from("work_orders").update({ extra_cost: extraNow }).eq("id", wo.id);
			if (error) throw error;
		}
	}
	async function run(what) {
		setBusy(true);
		try {
			if (what === "save") await saveEdits();
			if (what === "start") {
				await saveEdits();
				const { error } = await db.from("work_orders").update({ status: "in_progress" }).eq("id", wo.id);
				if (error) throw error;
			}
			if (what === "finish") {
				if (short.length && !window.confirm(`Not enough in stock for ${short.length} part${short.length > 1 ? "s" : ""}. Finish anyway? Stock will go below zero.`)) return;
				await saveEdits();
				const { error } = await db.rpc("finish_work_order", {
					_id: wo.id,
					_done_on: doneOn
				});
				if (error) throw error;
				toast.success(`Finished: ${fmtQty(wo.qty)} added to stock.`);
			}
			if (what === "undo") {
				if (!window.confirm("Undo this work order? The parts go back to stock and the built products come out.")) return;
				const { error } = await db.rpc("undo_work_order", { _id: wo.id });
				if (error) throw error;
				toast.success("Undone.");
			}
			if (what === "cancel") {
				const { error } = await db.from("work_orders").update({ status: "cancelled" }).eq("id", wo.id);
				if (error) throw error;
			}
			if (what === "delete") {
				if (!window.confirm(`Delete ${wo.number}?`)) return;
				const { error } = await db.from("work_orders").delete().eq("id", wo.id);
				if (error) throw error;
				refresh();
				onClose();
				return;
			}
			setQtys({});
			setExtra(null);
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
					wo.number,
					" · ",
					fmtQty(wo.qty),
					" × ",
					pmap.get(wo.product_id)?.name
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					WO_STATUS[wo.status],
					" · at",
					" ",
					(locations ?? []).find((l) => l.id === wo.location_id)?.name,
					wo.due_date ? ` · due ${fmtDate(wo.due_date)}` : "",
					order ? " · for invoice " : "",
					order && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sales/$id",
						params: { id: order.id },
						className: "underline",
						children: order.number
					})
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y rounded-xl border text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3 px-3 py-2 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1",
									children: "Part"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-24 text-right",
									children: "Needed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-20 text-right",
									children: "In stock"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-24 text-right",
									children: "Cost"
								})
							]
						}),
						lines.map((l) => {
							const p = pmap.get(l.part_id);
							const inStock = have.get(l.part_id) ?? 0;
							const low = editable && l.qty > inStock + 1e-5;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-3 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate",
										children: p?.name
									}),
									editable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										step: "any",
										className: "h-8 w-24 text-right",
										value: qtys[l.id] ?? String(l.qty),
										onChange: (e) => setQtys({
											...qtys,
											[l.id]: e.target.value
										})
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-24 text-right tabular-nums",
										children: fmtQty(l.qty)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `w-20 text-right tabular-nums ${low ? "font-semibold text-destructive" : ""}`,
										children: editable ? fmtQty(inStock) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-24 text-right tabular-nums text-muted-foreground",
										children: fmtMoney(l.qty * (l.unit_cost ?? p?.cost ?? 0))
									})
								]
							}, l.id);
						}),
						lines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "p-3 text-muted-foreground",
							children: "No parts on this work order."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Labor and other cost (all)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								className: "w-32",
								disabled: !editable,
								value: extra ?? String(wo.extra_cost),
								onChange: (e) => setExtra(e.target.value)
							})]
						}),
						editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Finished on"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: doneOn,
								onChange: (e) => setDoneOn(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "ml-auto text-right",
							children: [
								"Parts ",
								fmtMoney(partsCost),
								" + labor ",
								fmtMoney(extraNow),
								" =",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(partsCost + extraNow) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [fmtMoney((partsCost + extraNow) / wo.qty), " each"]
								})
							]
						})
					]
				}),
				editable && short.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-lg bg-amber-50 p-2 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
					children: [
						"Not enough in stock here for ",
						short.map((l) => pmap.get(l.part_id)?.name).join(", "),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "flex-wrap gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							wo.status === "planned" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								onClick: () => void run("delete"),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
							}),
							editable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => void run("cancel"),
								disabled: busy,
								children: "Cancel work order"
							}),
							wo.status === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => void run("undo"),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-4 w-4" }), " Undo finish"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							editable && (Object.keys(qtys).length > 0 || extra != null) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void run("save"),
								disabled: busy,
								children: "Save changes"
							}),
							wo.status === "planned" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void run("start"),
								disabled: busy,
								children: "Mark as being built"
							}),
							editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => void run("finish"),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { className: "h-4 w-4" }), " Finish and add to stock"]
							})
						]
					})]
				})
			]
		})
	});
}
//#endregion
export { WorkOrders as component };
