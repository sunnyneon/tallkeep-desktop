import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { g as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-wDrazOwE.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-Biwt2AGn.mjs";
import { i as payFromAccounts } from "./money-uSYuy5S6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/payroll-KaMXQ8WI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var REF = "PAYROLL";
var SAVED = "payroll-accounts";
var r2 = (n) => Math.round(n * 100) / 100;
var num = (s) => Number(s) || 0;
function guess(accts, type, re) {
	return accts.find((a) => a.is_active && a.type === type && re.test(a.name))?.id ?? "";
}
function PayrollPage() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const all = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active), [accounts]);
	const expenses = all.filter((a) => a.type === "expense");
	const liabilities = all.filter((a) => a.type === "liability" && a.kind !== "ap");
	const banks = payFromAccounts(accounts);
	const [picks, setPicks] = (0, import_react.useState)({
		wages: "",
		taxes: "",
		fees: "",
		bank: "",
		owed: ""
	});
	(0, import_react.useEffect)(() => {
		if (!all.length || picks.wages) return;
		let saved = {};
		try {
			saved = JSON.parse(localStorage.getItem(SAVED) ?? "{}");
		} catch {}
		const ok = (id) => id && all.some((a) => a.id === id) ? id : "";
		const wages = ok(saved.wages) || guess(all, "expense", /payroll|wage|salar/i);
		setPicks({
			wages,
			taxes: ok(saved.taxes) || guess(all, "expense", /payroll tax/i) || wages,
			fees: ok(saved.fees) || guess(all, "expense", /payroll (fee|service)|bank (fee|charge)|service charge/i) || wages,
			bank: ok(saved.bank) || (banks.find((a) => a.kind === "bank") ?? banks[0])?.id || "",
			owed: ok(saved.owed) || guess(all, "liability", /payroll/i)
		});
	}, [
		all,
		banks,
		picks.wages
	]);
	const [date, setDate] = (0, import_react.useState)(today());
	const [period, setPeriod] = (0, import_react.useState)("");
	const [gross, setGross] = (0, import_react.useState)("");
	const [empTax, setEmpTax] = (0, import_react.useState)("");
	const [deduct, setDeduct] = (0, import_react.useState)("");
	const [erTax, setErTax] = (0, import_react.useState)("");
	const [fee, setFee] = (0, import_react.useState)("");
	const [theyPayTaxes, setTheyPayTaxes] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const net = r2(num(gross) - num(empTax) - num(deduct));
	const taxes = r2(num(empTax) + num(erTax));
	const fromBank = r2(net + (theyPayTaxes ? taxes : 0) + num(fee));
	const stillOwed = r2(num(deduct) + (theyPayTaxes ? 0 : taxes));
	const runs = useQuery({
		queryKey: ["journal", "payroll"],
		queryFn: async () => {
			const { data, error } = await db.from("journal_entries").select("id,entry_date,memo,journal_lines(debit,account_id)").eq("ref", REF).order("entry_date", { ascending: false }).limit(200);
			if (error) throw error;
			return data ?? [];
		}
	});
	async function save() {
		if (!(num(gross) > 0)) return void toast.error("Type the gross wages.");
		if (net < 0) return void toast.error("Withholdings are more than gross wages.");
		if (!picks.wages || !picks.bank) return void toast.error("Choose the accounts below.");
		if (num(erTax) > 0 && !picks.taxes) return void toast.error("Choose the payroll tax account.");
		if (num(fee) > 0 && !picks.fees) return void toast.error("Choose the account for fees.");
		if (stillOwed > 0 && !picks.owed) return void toast.error("Choose the Payroll Liabilities account for amounts you still owe.");
		const lines = [
			{
				account_id: picks.wages,
				debit: r2(num(gross)),
				credit: 0,
				memo: "Gross wages"
			},
			{
				account_id: picks.taxes,
				debit: r2(num(erTax)),
				credit: 0,
				memo: "Employer payroll taxes"
			},
			{
				account_id: picks.fees,
				debit: r2(num(fee)),
				credit: 0,
				memo: "Payroll service fee"
			},
			{
				account_id: picks.bank,
				debit: 0,
				credit: fromBank,
				memo: "Paid from bank"
			},
			{
				account_id: picks.owed,
				debit: 0,
				credit: stillOwed,
				memo: "Withheld, still to pay"
			}
		].filter((l) => l.debit > 0 || l.credit > 0);
		setBusy(true);
		try {
			try {
				localStorage.setItem(SAVED, JSON.stringify(picks));
			} catch {}
			const { data: u } = await db.auth.getUser();
			const { data: e, error } = await db.from("journal_entries").insert({
				entry_date: date,
				ref: REF,
				memo: `Payroll${period.trim() ? ` · ${period.trim()}` : ""}`,
				source_type: "manual",
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("journal_lines").insert(lines.map((l) => ({
				...l,
				entry_id: e.id
			})));
			if (le) {
				await db.from("journal_entries").delete().eq("id", e.id);
				throw le;
			}
			toast.success(`Payroll of ${fmtMoney(num(gross))} saved.`);
			for (const f of [
				setGross,
				setEmpTax,
				setDeduct,
				setErTax,
				setFee,
				setPeriod
			]) f("");
			qc.invalidateQueries({ queryKey: ["journal"] });
			qc.invalidateQueries({ queryKey: ["account-totals"] });
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function remove(r) {
		if (!confirm(`Delete the payroll of ${fmtDate(r.entry_date)}?`)) return;
		const { error } = await db.from("journal_entries").delete().eq("id", r.id);
		if (error) return void toast.error(error.message);
		toast.success("Deleted.");
		qc.invalidateQueries({ queryKey: ["journal"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	}
	const pick = (k, list) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
		value: picks[k],
		options: list.map((a) => ({
			value: a.id,
			label: accountLabel(a)
		})),
		onChange: (v) => setPicks((p) => ({
			...p,
			[k]: v
		}))
	});
	const money = (v, set) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		type: "number",
		step: "0.01",
		min: "0",
		value: v,
		onChange: (e) => set(e.target.value),
		placeholder: "0.00"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Payroll",
			text: "Your payroll company (ADP, Gusto, Paychex…) does the paychecks. After each payroll, type the totals from their report here and the books are updated."
		}),
		!accounts ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-60" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Record a payroll"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Pay date",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: date,
									onChange: (e) => setDate(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Pay period (optional)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: period,
									onChange: (e) => setPeriod(e.target.value),
									placeholder: "Oct 1–15"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Gross wages (all employees)",
								children: money(gross, setGross)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Employee taxes withheld",
								children: money(empTax, setEmpTax)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Other deductions withheld (401k, insurance)",
								children: money(deduct, setDeduct)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Employer taxes (your share)",
								children: money(erTax, setErTax)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Payroll company fee",
								children: money(fee, setFee)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: theyPayTaxes,
							onChange: (e) => setTheyPayTaxes(e.target.checked)
						}), "The payroll company pays the taxes for us (takes them from the bank)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 rounded-lg bg-muted/50 p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Net pay to employees" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: fmtMoney(net)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex justify-between font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Taken from the bank" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: fmtMoney(fromBank)
								})]
							}),
							stillOwed > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Withheld, you still have to pay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: fmtMoney(stillOwed)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy,
						children: busy ? "Saving…" : "Save the payroll"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Accounts"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Set once; they are remembered."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Wages go to",
						children: pick("wages", expenses)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Employer taxes go to",
						children: pick("taxes", expenses)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fees go to",
						children: pick("fees", expenses)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Paid from",
						children: pick("bank", banks)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Amounts still owed go to (Payroll Liabilities)",
						children: pick("owed", liabilities)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "When you later pay what you still owe (for example the 401k), write a check to that Payroll Liabilities account."
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "pt-2 font-semibold",
			children: "Payrolls recorded"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [
				runs.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-20" }),
				runs.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-muted-foreground",
					children: "None yet."
				}),
				runs.data?.map((r) => {
					const gross = r.journal_lines.find((l) => l.account_id === picks.wages)?.debit;
					const total = r.journal_lines.reduce((s, l) => s + Number(l.debit), 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24 text-xs",
								children: fmtDate(r.entry_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [r.memo ?? "Payroll", gross != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: ["Gross ", fmtMoney(Number(gross))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: fmtMoney(total)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								onClick: () => void remove(r),
								"aria-label": "Delete",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, r.id);
				})
			]
		})
	] });
}
//#endregion
export { PayrollPage as component };
