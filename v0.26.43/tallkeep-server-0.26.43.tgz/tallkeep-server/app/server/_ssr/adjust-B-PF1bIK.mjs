import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as StockDocList } from "./StockDocList-D1WK1jwM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/adjust-B-PF1bIK.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockDocList, { kind: "adjust" });
//#endregion
export { SplitComponent as component };
