import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { listAccounts } from "./admin.functions-CNzN2J4P.mjs";
import { n as daysLeft, r as standing, t as ChangeDialog } from "./AdminAccount-D1k2d33g.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers-DeV63Ygs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLAN = {
	personal: "Personal",
	service: "Service Business",
	full: "Full Business"
};
function CustomersPage() {
	const accounts = useQuery({
		queryKey: ["admin-accounts"],
		queryFn: () => listAccounts()
	});
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [find, setFind] = (0, import_react.useState)("");
	if (accounts.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Customers",
		text: "Every Tallkeep customer."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6 text-muted-foreground",
		children: accounts.error.message
	})] });
	const all = accounts.data ?? [];
	const customers = all.filter((a) => !a.is_platform);
	const onTrial = customers.filter((a) => a.status === "trial" && (daysLeft(a) ?? 1) > 0);
	const endingSoon = onTrial.filter((a) => (daysLeft(a) ?? 99) <= 7);
	const paying = customers.filter((a) => a.status === "active" || a.status === "past_due");
	const readOnly = customers.filter((a) => a.status === "canceled" || a.status === "trial" && (daysLeft(a) ?? 1) <= 0);
	const aiCost = all.reduce((s, a) => s + a.ai_cost_month, 0);
	const q = find.trim().toLowerCase();
	const shown = q ? all.filter((a) => `${a.name} ${a.owner_email}`.toLowerCase().includes(q)) : all;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Customers",
			text: "Every Tallkeep customer: trials, plans and usage. Click a name to see its companies and people."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6",
			children: [
				["Customers", customers.length],
				["On free trial", onTrial.length],
				["Trial ends in 7 days", endingSoon.length],
				["Paying", paying.length],
				["Read-only", readOnly.length],
				["AI cost this month", fmtMoney(aiCost)]
			].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-2xl font-semibold",
					children: accounts.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-7 w-12" }) : value
				})]
			}, label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-lg font-semibold",
					children: "Accounts"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: find,
					onChange: (e) => setFind(e.target.value),
					placeholder: "Find a business or email",
					className: "w-64"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Business"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Standing"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Version"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Set up"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Companies"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "People"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Signed up"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Last sign-in"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-right",
									children: "AI this month"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "p-3" })
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
						accounts.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 10,
							className: "p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-full" })
						}) }),
						shown.map((a) => {
							const s = standing(a);
							const of = (n, max) => max == null ? `${n}` : `${n} of ${max}`;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/admin/customers/$id",
											params: { id: a.id },
											className: "font-medium text-primary hover:underline",
											children: a.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: a.owner_email
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-full px-2 py-0.5 text-xs ${s.tone}`,
											children: s.text
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3",
										children: [a.edition === "desktop" ? "Desktop" : "Cloud", a.plan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: [PLAN[a.plan] ?? a.plan, a.billing === "year" ? ", yearly" : a.billing === "month" ? ", monthly" : ""]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3",
										title: a.setup?.missing.length ? `Still to do: ${a.setup.missing.join(", ")}` : "",
										children: [a.setup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: `rounded-full px-2 py-0.5 text-xs ${a.setup.done === a.setup.total ? "bg-emerald-100 text-emerald-900" : a.setup.done === 0 ? "bg-red-100 text-red-900" : "bg-amber-100 text-amber-900"}`,
											children: [
												a.setup.done,
												" of ",
												a.setup.total
											]
										}) : "", a.setup && a.setup.missing.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: ["Next: ", a.setup.missing[0]]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: of(a.companies, a.companies_allowed)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: of(a.people, a.users_allowed)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: fmtDate(a.created_at)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3",
										children: a.last_sign_in ? fmtDate(a.last_sign_in) : "Never"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "p-3 text-right",
										children: [fmtMoney(a.ai_cost_month), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: [a.ai_pages_month, " pages"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "p-3 text-right",
										children: !a.is_platform && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setEditing(a),
											children: "Change plan"
										})
									})
								]
							}, a.id);
						}),
						!accounts.isLoading && shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 10,
							className: "p-6 text-center text-muted-foreground",
							children: "No accounts match."
						}) })
					] })]
				})
			})]
		}),
		editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangeDialog, {
			account: editing,
			onClose: () => setEditing(null)
		})
	] });
}
//#endregion
export { CustomersPage as component };
