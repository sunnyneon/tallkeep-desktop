import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { C as useRouter, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as kindLabel, f as useAccounts, i as accountLabel, o as balanceOf } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { D as Search, K as PanelLeftOpen, Nn as ArrowLeft, q as PanelLeftClose } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { n as TxnEditor, t as EDITABLE } from "./TxnEditor-2D2AvLDH.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/AccountRegister-BrrPMtGO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Register for one account, like QuickBooks' check register: every check, deposit, payment,
* transfer and card charge in date order, with the payee, the other account, cleared status and a
* running balance. A search column on the left (it can be hidden) finds checks, deposits,
* numbers, payees or amounts, in one account or in all bank and card accounts at once.
*/
var SOURCE = {
	invoice: "Invoice",
	invoice_cogs: "Cost of goods",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	stock: "Stock change",
	bill: "Bill",
	bill_payment: "Bill payment",
	manual: "Journal entry",
	opening: "Opening balance",
	adjust: "Accountant adjustment",
	history: "From QuickBooks",
	rent_charge: "Rent charge",
	rent_payment: "Rent received",
	work_order: "Work order",
	check: "Check / payment",
	deposit: "Deposit",
	transfer: "Transfer",
	bank: "Bank feed",
	stay: "Short-term stay"
};
/** The kinds of transaction people look for. */
var TYPES = [
	{
		key: "all",
		label: "Every type",
		match: () => true
	},
	{
		key: "check",
		label: "Checks & payments",
		match: (s) => s === "check"
	},
	{
		key: "deposit",
		label: "Deposits",
		match: (s) => s === "deposit"
	},
	{
		key: "received",
		label: "Payments received",
		match: (s) => s === "payment" || s === "rent_payment" || s === "stay"
	},
	{
		key: "bills",
		label: "Bill & PO payments",
		match: (s) => s === "bill_payment" || s === "po_payment"
	},
	{
		key: "transfer",
		label: "Transfers",
		match: (s) => s === "transfer"
	},
	{
		key: "bank",
		label: "From the bank feed",
		match: (s) => s === "bank"
	},
	{
		key: "journal",
		label: "Journal & opening entries",
		match: (s) => [
			"manual",
			"opening",
			"adjust",
			"history"
		].includes(s)
	}
];
var NO_FILTERS = {
	q: "",
	amount: "",
	type: "all",
	from: "",
	to: "",
	cleared: "all"
};
var OPEN_KEY = "register-search-open";
async function loadLines(ids) {
	const out = [];
	for (let from = 0;; from += 1e3) {
		const { data, error } = await db.from("journal_lines").select("id,account_id,debit,credit,memo,customers(name),vendors(name),journal_entries!inner(id,entry_date,ref,memo,source_type,journal_lines(account_id,debit,credit,customers(name),vendors(name)))").in("account_id", ids).order("id").range(from, from + 999);
		if (error) throw error;
		out.push(...data ?? []);
		if (!data || data.length < 1e3) break;
	}
	return out;
}
async function loadCleared(ids) {
	const m = /* @__PURE__ */ new Map();
	for (const id of ids) {
		const { data } = await db.rpc("account_lines", {
			_account: id,
			_to: null
		});
		for (const r of data ?? []) if (r.cleared) m.set(r.line_id, r.reconciliation_id ? "R" : "C");
	}
	return m;
}
var isRegister = (a) => a.kind === "bank" || a.kind === "credit_card";
function AccountRegister({ accountId, onAccount, kind, start }) {
	const router = useRouter();
	const { data: accounts } = useAccounts();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const registers = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && isRegister(a)), [accounts]);
	const all = accountId === "all";
	const account = all ? null : accounts?.find((a) => a.id === accountId);
	const [last, setLast] = useSticky("register-last", {});
	(0, import_react.useEffect)(() => {
		if (accountId || !registers.length) return;
		const want = kind === "any" ? "bank" : kind;
		const prev = last[want];
		onAccount(prev && (prev === "all" || registers.some((a) => a.id === prev)) && prev || registers.find((a) => a.kind === want)?.id || registers[0].id);
	}, [accountId, registers]);
	(0, import_react.useEffect)(() => {
		if (!accountId) return;
		const k = all ? kind === "credit_card" ? "credit_card" : "bank" : account?.kind;
		if (k === "bank" || k === "credit_card") setLast((x) => ({
			...x,
			[k]: accountId
		}));
	}, [accountId, account?.kind]);
	const [f, setF] = useSticky("register-filters", {
		...NO_FILTERS,
		...start
	});
	(0, import_react.useEffect)(() => {
		if (start?.from || start?.to) setF({
			...NO_FILTERS,
			...start
		});
	}, [start?.from, start?.to]);
	const [newestFirst, setNewestFirst] = useSticky("register-newest-first", true);
	const [open, setOpen] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem(OPEN_KEY) !== "0";
		} catch {
			return true;
		}
	});
	const toggle = () => setOpen((v) => {
		try {
			localStorage.setItem(OPEN_KEY, v ? "0" : "1");
		} catch {}
		return !v;
	});
	const ids = (0, import_react.useMemo)(() => all ? registers.map((a) => a.id) : accountId ? [accountId] : [], [
		all,
		registers,
		accountId
	]);
	const { data, isLoading, error } = useQuery({
		queryKey: ["register", ids.join(",")],
		enabled: ids.length > 0,
		queryFn: async () => {
			const [lines, cleared] = await Promise.all([loadLines(ids), loadCleared(ids)]);
			return {
				lines,
				cleared
			};
		}
	});
	const name = (0, import_react.useMemo)(() => {
		const m = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
		return (id) => m.get(id) ?? "";
	}, [accounts]);
	const typeOf = (0, import_react.useMemo)(() => {
		const m = new Map((accounts ?? []).map((a) => [a.id, a.type]));
		return (id) => m.get(id) ?? "asset";
	}, [accounts]);
	const allRows = (0, import_react.useMemo)(() => {
		if (!data) return [];
		const sorted = [...data.lines].sort((a, b) => a.journal_entries.entry_date.localeCompare(b.journal_entries.entry_date) || Number(b.debit) - Number(a.debit));
		let running = 0;
		return sorted.map((l) => {
			const e = l.journal_entries;
			const amount = balanceOf(typeOf(l.account_id), Number(l.debit), Number(l.credit));
			running += amount;
			const others = e.journal_lines.filter((o) => o.account_id !== l.account_id);
			const otherIds = [...new Set(others.map((o) => o.account_id))];
			const party = l.vendors?.name ?? l.customers?.name ?? e.journal_lines.find((o) => o.vendors || o.customers)?.vendors?.name ?? e.journal_lines.find((o) => o.customers)?.customers?.name ?? "";
			return {
				id: l.id,
				entryId: e.id,
				accountId: l.account_id,
				date: e.entry_date,
				number: e.ref ?? "",
				payee: party || (e.source_type === "check" ? e.memo ?? "" : ""),
				type: SOURCE[e.source_type] ?? e.source_type,
				source: e.source_type,
				other: otherIds.length === 0 ? "" : otherIds.length === 1 ? name(otherIds[0]) : `Split (${otherIds.length} accounts)`,
				otherAll: otherIds.map(name).join(", "),
				memo: (l.memo || e.memo) ?? "",
				amount,
				cleared: data.cleared.get(l.id) ?? "",
				running
			};
		});
	}, [
		data,
		name,
		typeOf
	]);
	const rows = (0, import_react.useMemo)(() => {
		const words = f.q.toLowerCase().split(/\s+/).filter(Boolean);
		const amt = f.amount.replace(/[$,\s]/g, "");
		const amtN = amt && !Number.isNaN(Number(amt)) ? Math.abs(Number(amt)) : null;
		const type = TYPES.find((t) => t.key === f.type) ?? TYPES[0];
		const list = allRows.filter((r) => {
			if (f.from && r.date < f.from) return false;
			if (f.to && r.date > f.to) return false;
			if (!type.match(r.source)) return false;
			if (f.cleared === "no" && r.cleared) return false;
			if (f.cleared === "yes" && !r.cleared) return false;
			if (amtN !== null && Math.abs(Math.abs(r.amount) - amtN) > .005) return false;
			const hay = `${r.number} ${r.payee} ${r.memo} ${r.otherAll} ${r.type} ${all ? name(r.accountId) : ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
		return newestFirst ? list.reverse() : list;
	}, [
		allRows,
		f,
		newestFirst,
		all,
		name
	]);
	const filtered = JSON.stringify({ ...f }) !== JSON.stringify(NO_FILTERS);
	const card = all ? kind === "credit_card" : account?.kind === "credit_card";
	const upWord = card ? "Charge" : account && account.kind !== "bank" && !all ? "Increase" : "Deposit";
	const downWord = card ? "Payment" : account && account.kind !== "bank" && !all ? "Decrease" : "Payment";
	const ups = rows.reduce((s, r) => s + Math.max(r.amount, 0), 0);
	const downs = rows.reduce((s, r) => s + Math.max(-r.amount, 0), 0);
	const balance = allRows.length ? allRows[allRows.length - 1].running : 0;
	const shown = rows.slice(0, 1e3);
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	const searchColumn = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggle,
					title: "Hide the search",
					"aria-label": "Hide the search",
					className: "rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Account"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: accountId ?? "",
					onChange: (e) => onAccount(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All bank and card accounts"
						}),
						registers.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.id,
							children: accountLabel(a)
						}, a.id)),
						account && !isRegister(account) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: account.id,
							children: accountLabel(account)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Number, payee or memo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "h-9 pl-8",
						placeholder: "e.g. 1042 or Home Depot",
						value: f.q,
						onChange: (e) => set({ q: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Amount"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-9",
					inputMode: "decimal",
					placeholder: "e.g. 250.00",
					value: f.amount,
					onChange: (e) => set({ amount: e.target.value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: f.type,
					onChange: (e) => set({ type: e.target.value }),
					children: TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: t.key,
						children: t.label
					}, t.key))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 px-2 text-xs",
						value: f.from,
						onChange: (e) => set({ from: e.target.value })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 px-2 text-xs",
						value: f.to,
						onChange: (e) => set({ to: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Cleared with the bank"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: f.cleared,
					onChange: (e) => set({ cleared: e.target.value }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Cleared or not"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "no",
							children: "Not cleared yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "yes",
							children: "Cleared"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data ? `${rows.length} found` : "" }), filtered && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "underline hover:text-foreground",
					onClick: () => setF(NO_FILTERS),
					children: "Clear search"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full",
		children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "sticky top-0 hidden h-screen w-72 shrink-0 overflow-y-auto border-r bg-card lg:block print:hidden",
			children: searchColumn
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: toggle,
			title: "Show the search",
			"aria-label": "Show the search",
			className: "sticky top-0 hidden h-screen w-8 shrink-0 items-start justify-center border-r bg-card pt-4 text-muted-foreground hover:text-foreground lg:flex print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftOpen, { className: "h-4 w-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				wide: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/accounts",
						className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Chart of Accounts"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
							children: all ? "All bank and card accounts" : account ? `${accountLabel(account)} register` : "Register"
						}), account && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: kindLabel(account.kind)
						})] }), !all && data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border bg-card px-4 py-2 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: card ? "Balance owed" : "Ending balance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold tabular-nums",
								children: fmtMoney(balance)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl border bg-card lg:hidden",
						children: searchColumn
					}),
					account && (account.kind === "bank" || account.kind === "credit_card") && allRows.length > 0 && !allRows.some((r) => r.source === "opening") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "No opening balance yet" }),
							", so this balance starts from $0. Add what the account",
							" ",
							account.kind === "credit_card" ? "owed" : "held",
							" the day before its first line: a journal entry with this account and 3000 · Opening Balance Equity, dated that day (the first statement shows it as its",
							" ",
							account.kind === "credit_card" ? "previous" : "beginning",
							" balance)."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							rows.length,
							" shown · ",
							upWord.toLowerCase(),
							"s ",
							fmtMoney(ups),
							" ·",
							" ",
							downWord.toLowerCase(),
							"s ",
							fmtMoney(downs)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: newestFirst,
								onChange: (e) => setNewestFirst(e.target.checked)
							}), "Newest first"]
						})]
					}),
					isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: error.message
					}),
					data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-2xl border bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b bg-muted/40 text-xs text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Number · type"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Payee · memo"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: all ? "Account" : "Account (other side)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: downWord
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 text-center font-semibold",
										title: "Cleared (C) or reconciled (R)",
										children: "✓"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: upWord
									}),
									!all && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: "Balance"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y",
								children: [shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "cursor-pointer hover:bg-muted",
									title: EDITABLE.has(r.source) ? "Change or delete" : "Open this transaction",
									onClick: () => EDITABLE.has(r.source) ? setEditing({
										entryId: r.entryId,
										accountId: r.accountId
									}) : router.history.push(`/go/entry/${r.entryId}`),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2",
											children: fmtDate(r.date)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "max-w-[160px] px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate font-medium",
												children: r.number
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted-foreground",
												children: r.type
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "max-w-[260px] px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate",
												children: r.payee || r.memo
											}), r.payee && r.memo && r.memo !== r.payee && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted-foreground",
												children: r.memo
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-[200px] truncate px-3 py-2",
											title: all ? name(r.accountId) : r.otherAll,
											children: all ? name(r.accountId) : r.other
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right tabular-nums",
											children: r.amount < 0 ? fmtMoney(-r.amount) : ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2 text-center text-xs font-semibold text-emerald-700",
											children: r.cleared
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right tabular-nums",
											children: r.amount > 0 ? fmtMoney(r.amount) : ""
										}),
										!all && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right font-medium tabular-nums",
											children: fmtMoney(r.running)
										})
									]
								}, r.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 8,
									className: "p-8 text-center text-muted-foreground",
									children: filtered ? "Nothing matches the search." : "No transactions yet."
								}) })]
							})]
						})
					}),
					rows.length > shown.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: [
							"Showing ",
							shown.length,
							" of ",
							rows.length,
							". Search or pick dates to narrow it down."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "✓: C = cleared with the bank, R = reconciled. Click a line to change, delete or open it."
					}),
					editing && accounts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxnEditor, {
						entryId: editing.entryId,
						accountId: editing.accountId,
						accounts,
						onClose: () => setEditing(null)
					})
				]
			})
		})]
	});
}
//#endregion
export { AccountRegister as t };
