import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Bt as EyeOff, d as Upload, f as Undo2, ft as Link2, g as Trash2, in as Check, x as Sparkles, xn as BookMarked } from "../_libs/lucide-react.mjs";
import { n as fileToPages } from "./ai-DFyYp0ty.mjs";
import { t as aiRead } from "./ai.functions-BcqQuYBo.mjs";
import { a as ruleFor, i as payeeKey, n as parseBankCsv, r as parseOfx } from "./bankfile-C7N990Vr.mjs";
import { a as recordLoanPayments } from "./loans-IovjuDQY.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as SearchSelect } from "./SearchSelect-KZGKVtkS.mjs";
import { t as Route } from "./banking-BM_9bWPa.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/banking-BMJfafag.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPE_NAME = {
	invoice: "Invoice",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	bill: "Bill",
	bill_payment: "Bill payment",
	manual: "Journal entry",
	opening: "Opening balance",
	bank: "Added from bank"
};
var daysApart = (a, b) => Math.abs(Date.parse(`${a}T12:00:00`) - Date.parse(`${b}T12:00:00`)) / 864e5;
/** For each new bank line, an uncleared book line with the same amount within 10 days. */
function suggest(txns, lines) {
	const used = new Set(txns.filter((t) => t.source_id).map((t) => t.source_id));
	const m = /* @__PURE__ */ new Map();
	for (const t of txns.filter((x) => x.status === "new")) {
		const hit = lines.filter((l) => !l.cleared && !used.has(l.item_key) && Math.abs(Number(l.amount) - Number(t.amount)) < .005 && daysApart(l.entry_date, t.txn_date) <= 10).sort((a, b) => daysApart(a.entry_date, t.txn_date) - daysApart(b.entry_date, t.txn_date))[0];
		if (hit) {
			m.set(t.id, hit);
			used.add(hit.item_key);
		}
	}
	return m;
}
var AUTO_KEY = "bank-auto-record";
function readAuto() {
	try {
		return localStorage.getItem(AUTO_KEY) !== "off";
	} catch {
		return true;
	}
}
function Banking() {
	const { data: accounts } = useAccounts();
	const banks = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	const search = Route.useSearch();
	const [accountId, setAccountId] = (0, import_react.useState)(search.account ?? null);
	(0, import_react.useEffect)(() => {
		if (search.account) setAccountId(search.account);
	}, [search.account]);
	(0, import_react.useEffect)(() => {
		if (!accountId && banks[0]) setAccountId(banks[0].id);
	}, [banks, accountId]);
	const account = banks.find((a) => a.id === accountId);
	const [tab, setTab] = (0, import_react.useState)(search.tab ?? "review");
	(0, import_react.useEffect)(() => {
		if (search.tab) setTab(search.tab);
	}, [search.tab]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Banking",
			text: "Bring in your bank or credit card statement, check each line against the books, then reconcile so the books match the bank to the penny."
		}),
		accounts && banks.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-sm text-muted-foreground",
			children: "No bank or credit card accounts yet. Add one in the Chart of Accounts."
		}),
		banks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-72",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
					value: accountId,
					options: banks.map((a) => ({
						value: a.id,
						label: accountLabel(a)
					})),
					onChange: setAccountId,
					placeholder: "Choose the account"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: [
					["review", "For review"],
					["done", "Done"],
					["reconcile", "Reconcile"]
				].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(k),
					className: `rounded-md px-3 py-1 ${tab === k ? "bg-[var(--section)] text-white" : ""}`,
					children: label
				}, k))
			})]
		}),
		account && tab !== "reconcile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feed, {
			account,
			accounts: accounts ?? [],
			done: tab === "done"
		}),
		account && tab === "reconcile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reconcile, { account })
	] });
}
function Feed({ account, accounts, done }) {
	const qc = useQueryClient();
	const [flip, setFlip] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const loadTxns = async () => {
		const { data, error } = await db.from("bank_transactions").select("id,txn_date,amount,description,ref,status,source_type,source_id").eq("account_id", account.id).order("txn_date", { ascending: false }).limit(5e3);
		if (error) throw error;
		return data ?? [];
	};
	const loadLines = async () => {
		const { data, error } = await db.rpc("account_lines", {
			_account: account.id,
			_to: null
		});
		if (error) throw error;
		return data ?? [];
	};
	const loadRules = () => fetchAll("bank_rules", "id,contains,account_id");
	const { data: txns, isLoading } = useQuery({
		queryKey: ["bank-txns", account.id],
		queryFn: loadTxns
	});
	const { data: lines } = useQuery({
		queryKey: ["account-lines", account.id],
		queryFn: loadLines
	});
	const { data: rules } = useQuery({
		queryKey: ["bank-rules"],
		queryFn: loadRules
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["bank-txns", account.id] });
		qc.invalidateQueries({ queryKey: ["account-lines", account.id] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	const suggestions = (0, import_react.useMemo)(() => suggest(txns ?? [], lines ?? []), [txns, lines]);
	const [auto, setAuto] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => setAuto(readAuto()), []);
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)("");
	const [rulesOpen, setRulesOpen] = (0, import_react.useState)(false);
	/** Record every line we're sure about: matches with the books, then remembered payees. */
	async function recordSure(quiet = false) {
		const loans = account.kind === "bank" ? await recordLoanPayments(account.id) : 0;
		const [t2, l2, r2] = await Promise.all([
			qc.fetchQuery({
				queryKey: ["bank-txns", account.id],
				queryFn: loadTxns,
				staleTime: 0
			}),
			qc.fetchQuery({
				queryKey: ["account-lines", account.id],
				queryFn: loadLines,
				staleTime: 0
			}),
			qc.fetchQuery({
				queryKey: ["bank-rules"],
				queryFn: loadRules,
				staleTime: 0
			})
		]);
		const sugg = suggest(t2, l2);
		let matched = 0;
		let added = loans;
		setBusy(true);
		for (const t of t2.filter((x) => x.status === "new")) {
			const l = sugg.get(t.id);
			if (l) {
				if (await match(t, l, false)) matched++;
				continue;
			}
			const r = ruleFor(r2, t.description);
			if (r && await add(t, r.account_id, null, false)) added++;
		}
		setBusy(false);
		refresh();
		if (matched + added > 0) toast.success(`Recorded ${matched + added} automatically (${matched} matched, ${added - loans} from remembered payees${loans ? `, ${loans} loan payment${loans === 1 ? "" : "s"} split` : ""}). Check them under Done.`);
		else if (!quiet) toast.message("Nothing sure to record. The rest needs you.");
	}
	/** A PDF statement: the AI reads the pages (6 at a time) and returns the lines. */
	async function readPdf(file) {
		try {
			setBusy(true);
			const pages = await fileToPages(file, 40);
			const lines = [];
			for (let i = 0; i < pages.length; i += 6) {
				setStep(`Reading pages ${i + 1}–${Math.min(i + 6, pages.length)} of ${pages.length}…`);
				const r = JSON.parse(await aiRead({ data: {
					feature: "statement",
					images: pages.slice(i, i + 6),
					hint: `This is a ${account.kind === "credit_card" ? "credit card" : "bank account"} statement${pages.length > 6 ? `, pages ${i + 1}-${Math.min(i + 6, pages.length)} of ${pages.length}` : ""}.`
				} }));
				lines.push(...r["lines"] ?? []);
			}
			const seen = /* @__PURE__ */ new Map();
			const out = [];
			for (const l of lines) {
				const date = String(l.date ?? "").slice(0, 10);
				const amount = Math.round(Number(l.amount) * 100) / 100;
				if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !amount) continue;
				const description = String(l.description ?? "").trim();
				const k = `${date}|${amount}|${description.toLowerCase()}`;
				const n = (seen.get(k) ?? 0) + 1;
				seen.set(k, n);
				out.push({
					txn_date: date,
					amount,
					description,
					ref: l.ref ? String(l.ref) : null,
					fit_id: `pdf:${k}:${n}`
				});
			}
			return out;
		} catch (e) {
			return e.message;
		} finally {
			setStep("");
			setBusy(false);
		}
	}
	async function importFile(file) {
		let parsed;
		if (/\.pdf$/i.test(file.name)) parsed = await readPdf(file);
		else {
			const text = await file.text();
			parsed = /<OFX>|<STMTTRN>/i.test(text) ? parseOfx(text) : parseBankCsv(text, flip);
		}
		if (typeof parsed === "string") return void toast.error(parsed);
		if (!parsed.length) return void toast.error("No lines found in this file.");
		setBusy(true);
		const before = txns?.length ?? 0;
		const { error } = await db.from("bank_transactions").upsert(parsed.map((p) => ({
			...p,
			account_id: account.id
		})), {
			onConflict: "account_id,fit_id",
			ignoreDuplicates: true
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		const { count } = await db.from("bank_transactions").select("id", {
			count: "exact",
			head: true
		}).eq("account_id", account.id);
		const added = (count ?? before) - before;
		toast.success(added > 0 ? `Brought in ${added} new lines${parsed.length > added ? ` (${parsed.length - added} were already here)` : ""}.` : "All these lines were already here.");
		refresh();
		if (auto && added > 0) await recordSure(true);
	}
	async function match(t, l, again = true) {
		const a = await db.from("bank_transactions").update({
			status: "matched",
			source_type: l.source_type,
			source_id: l.item_key
		}).eq("id", t.id);
		if (a.error) {
			toast.error(a.error.message);
			return false;
		}
		await db.from("cleared_items").upsert({
			account_id: account.id,
			item_key: l.item_key
		}, { onConflict: "account_id,item_key" });
		if (again) refresh();
		return true;
	}
	async function add(t, other, remember, again = true) {
		const { error } = await db.rpc("add_bank_transaction", {
			_txn: t.id,
			_other: other,
			_memo: t.description ?? ""
		});
		if (error) {
			toast.error(error.message);
			return false;
		}
		const key = remember?.trim();
		if (key) {
			const old = (rules ?? []).find((r) => r.contains.toLowerCase() === key.toLowerCase());
			if (old) await db.from("bank_rules").update({ account_id: other }).eq("id", old.id);
			else await db.from("bank_rules").insert({
				contains: key,
				account_id: other
			});
			qc.invalidateQueries({ queryKey: ["bank-rules"] });
		}
		if (again) {
			refresh();
			if (key && auto) await recordSure(true);
		}
		return true;
	}
	async function ignore(t) {
		await db.from("bank_transactions").update({ status: "ignored" }).eq("id", t.id);
		refresh();
	}
	async function undo(t) {
		const { error } = await db.rpc("undo_bank_transaction", { _txn: t.id });
		if (error) return void toast.error(error.message);
		refresh();
	}
	const list = (txns ?? []).filter((t) => done ? t.status !== "new" : t.status === "new");
	const guessFor = (desc) => ruleFor(rules ?? [], desc)?.account_id ?? null;
	const sure = list.filter((t) => suggestions.has(t.id) || guessFor(t.description)).length;
	const onFile = (f) => {
		if (!f) return;
		if (!/\.(csv|ofx|qfx|qbo|pdf)$/i.test(f.name)) return void toast.error("Use a PDF, CSV, QBO, QFX or OFX file from your bank's website.");
		importFile(f);
	};
	const options = accounts.filter((a) => a.is_active && a.id !== account.id && !["ar", "ap"].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		onDragOver: (e) => {
			if (done) return;
			e.preventDefault();
			setDrag(true);
		},
		onDragLeave: (e) => {
			if (!e.currentTarget.contains(e.relatedTarget)) setDrag(false);
		},
		onDrop: (e) => {
			if (done) return;
			e.preventDefault();
			setDrag(false);
			onFile(e.dataTransfer.files[0]);
		},
		children: [
			rulesOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RulesDialog, {
				rules: rules ?? [],
				options,
				onClose: () => setRulesOpen(false)
			}),
			!done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex flex-wrap items-center gap-3 rounded-2xl border-2 border-dashed bg-card p-4 text-sm ${drag ? "border-[var(--section)] bg-[var(--section-soft)]" : "border-border"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 font-medium hover:bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
							" ",
							busy ? step || "Working…" : "Bring in a statement file",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: ".pdf,.csv,.ofx,.qfx,.qbo",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									e.target.value = "";
									onFile(f);
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "or drop it here. A PDF statement works (AI reads it), or download CSV / QuickBooks / Quicken (QBO, QFX, OFX) from your bank's website."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: flip,
							onChange: (e) => setFlip(e.target.checked)
						}), "CSV shows charges as positive numbers (flip them)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full flex-wrap items-center gap-3 border-t pt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: auto,
									onChange: (e) => {
										setAuto(e.target.checked);
										try {
											localStorage.setItem(AUTO_KEY, e.target.checked ? "on" : "off");
										} catch {}
									}
								}), "Record sure lines automatically (matches and remembered payees)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								disabled: busy || sure === 0,
								onClick: () => void recordSure(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }),
									" Record the ",
									sure,
									" sure line",
									sure === 1 ? "" : "s"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setRulesOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "h-3.5 w-3.5" }),
									" Remembered payees (",
									rules?.length ?? 0,
									")"
								]
							})
						]
					})
				]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [list.map((t) => done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24",
							children: fmtDate(t.txn_date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate",
							children: t.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: t.status === "matched" ? `Matched · ${TYPE_NAME[t.source_type ?? ""] ?? ""}` : t.status === "added" ? "Added to the books" : "Ignored"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: t.amount }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void undo(t),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-3.5 w-3.5" }), " Undo"]
						})
					]
				}, t.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewRow, {
					t,
					suggestion: suggestions.get(t.id),
					guess: guessFor(t.description),
					options,
					onMatch: (l) => void match(t, l),
					onAdd: (acc, remember) => void add(t, acc, remember),
					onIgnore: () => void ignore(t)
				}, t.id)), txns && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-muted-foreground",
					children: done ? "Nothing handled yet." : "Nothing to review. Bring in a statement file to start."
				})]
			})
		]
	});
}
function Amount({ v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `w-28 text-right font-medium tabular-nums ${v < 0 ? "" : "text-emerald-700"}`,
		children: v < 0 ? `− ${fmtMoney(-v)}` : `+ ${fmtMoney(v)}`
	});
}
function ReviewRow({ t, suggestion, guess, options, onMatch, onAdd, onIgnore }) {
	const [acc, setAcc] = (0, import_react.useState)(guess);
	(0, import_react.useEffect)(() => {
		if (guess) setAcc(guess);
	}, [guess]);
	const [remember, setRemember] = (0, import_react.useState)(!guess);
	const [word, setWord] = (0, import_react.useState)(() => payeeKey(t.description));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-24",
					children: fmtDate(t.txn_date)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 flex-1 truncate font-medium",
					children: t.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: t.amount })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2 pl-0 sm:pl-[6.75rem]",
			children: [suggestion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-center gap-1.5 text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-3.5 w-3.5 text-[var(--section)]" }),
					"Matches ",
					TYPE_NAME[suggestion.source_type] ?? "entry",
					" ",
					suggestion.ref ?? "",
					" on",
					" ",
					fmtDate(suggestion.entry_date)
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => onMatch(suggestion),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }), " Match"]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: acc,
						options,
						onChange: setAcc,
						placeholder: t.amount < 0 ? "What was it for? (account)" : "Where did it come from? (account)"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: remember,
						onChange: (e) => setRemember(e.target.checked)
					}), "Always use it for"]
				}),
				remember && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: word,
					onChange: (e) => setWord(e.target.value),
					className: "h-8 w-44 text-xs",
					title: "Bank lines that contain this text get this account from now on"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					disabled: !acc,
					onClick: () => acc && onAdd(acc, remember && word.trim() ? word : null),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }), " Add to the books"]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: onIgnore,
				title: "Already in the books some other way, or not ours",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-3.5 w-3.5" }), " Ignore"]
			})]
		})]
	});
}
function RulesDialog({ rules, options, onClose }) {
	const qc = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const shown = [...rules].sort((a, b) => a.contains.localeCompare(b.contains)).filter((r) => r.contains.toLowerCase().includes(q.toLowerCase()));
	const save = async (id, patch) => {
		const { error } = await db.from("bank_rules").update(patch).eq("id", id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["bank-rules"] });
	};
	const remove = async (id) => {
		const { error } = await db.from("bank_rules").delete().eq("id", id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["bank-rules"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Remembered payees" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Bank lines that contain the text on the left get the account on the right, for every bank and card account. Fix or delete any of them here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Find…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[55vh] divide-y overflow-y-auto rounded-lg border",
					children: [shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "None yet. They are saved when you add a bank line with \"Always use it for\"."
					}), shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								defaultValue: r.contains,
								className: "h-8 w-48 text-sm",
								onBlur: (e) => {
									const v = e.target.value.trim();
									if (v && v !== r.contains) save(r.id, { contains: v });
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: r.account_id,
									options,
									onChange: (v) => v && void save(r.id, { account_id: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "Delete",
								onClick: () => void remove(r.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, r.id))]
				})
			]
		})
	});
}
function Reconcile({ account }) {
	const qc = useQueryClient();
	const sign = account.type === "liability" ? -1 : 1;
	const [date, setDate] = (0, import_react.useState)(today());
	const [ending, setEnding] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: lines, isLoading } = useQuery({
		queryKey: ["account-lines", account.id],
		queryFn: async () => {
			const { data, error } = await db.rpc("account_lines", {
				_account: account.id,
				_to: null
			});
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: history } = useQuery({
		queryKey: ["reconciliations", account.id],
		queryFn: async () => {
			const { data } = await db.from("reconciliations").select("id,statement_date,ending_balance,completed_at").eq("account_id", account.id).not("completed_at", "is", null).order("statement_date", { ascending: false });
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["account-lines", account.id] });
		qc.invalidateQueries({ queryKey: ["reconciliations", account.id] });
	};
	const items = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const l of lines ?? []) {
			const x = m.get(l.item_key);
			if (x) x.total += Number(l.amount);
			else m.set(l.item_key, {
				...l,
				total: Number(l.amount)
			});
		}
		return [...m.values()].sort((a, b) => a.entry_date.localeCompare(b.entry_date));
	}, [lines]);
	const beginning = items.filter((i) => i.reconciliation_id).reduce((s, i) => s + i.total, 0) * sign;
	const open = items.filter((i) => !i.reconciliation_id && i.entry_date <= date);
	const ticked = open.filter((i) => i.cleared);
	const clearedBal = beginning + ticked.reduce((s, i) => s + i.total, 0) * sign;
	const target = Number(ending);
	const diff = ending === "" ? null : Math.round((target - clearedBal) * 100) / 100;
	async function toggle(i, on) {
		const { error } = on ? await db.from("cleared_items").upsert({
			account_id: account.id,
			item_key: i.item_key
		}, { onConflict: "account_id,item_key" }) : await db.from("cleared_items").delete().eq("account_id", account.id).eq("item_key", i.item_key);
		if (error) toast.error(error.message);
		refresh();
	}
	async function finish() {
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const { data: r, error } = await db.from("reconciliations").insert({
				account_id: account.id,
				statement_date: date,
				ending_balance: target,
				completed_at: (/* @__PURE__ */ new Date()).toISOString(),
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const keys = ticked.map((i) => i.item_key);
			for (let k = 0; k < keys.length; k += 200) {
				const { error: e2 } = await db.from("cleared_items").update({ reconciliation_id: r.id }).eq("account_id", account.id).in("item_key", keys.slice(k, k + 200));
				if (e2) throw e2;
			}
			toast.success(`Reconciled through ${fmtDate(date)}.`);
			setEnding("");
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3 rounded-2xl border bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: "Statement end date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: account.type === "liability" ? "Statement balance owed" : "Statement ending balance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							className: "w-40",
							value: ending,
							onChange: (e) => setEnding(e.target.value),
							placeholder: "0.00"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto grid grid-cols-3 gap-4 text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Beginning",
								v: beginning
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Cleared balance",
								v: clearedBal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Difference",
								v: diff ?? 0,
								bad: diff !== null && diff !== 0,
								good: diff === 0
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Tick every line that shows on the statement. Lines matched from a bank file are already ticked. When the difference is $0.00, press Finish."
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [open.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 px-4 py-2 hover:bg-muted/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "h-4 w-4",
							checked: i.cleared,
							onChange: (e) => void toggle(i, e.target.checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24",
							children: fmtDate(i.entry_date)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-36 text-muted-foreground",
							children: TYPE_NAME[i.source_type] ?? i.source_type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24",
							children: i.ref
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate text-muted-foreground",
							children: i.memo
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: i.total })
					]
				}, i.item_key)), lines && open.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-muted-foreground",
					children: "Nothing left to reconcile up to this date."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void finish(),
					disabled: busy || diff !== 0 || ticked.length === 0,
					children: busy ? "Finishing…" : "Finish reconciling"
				})
			}),
			(history ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 font-semibold",
					children: "Reconciled before"
				}), (history ?? []).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Statement of ", fmtDate(h.statement_date)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: fmtMoney(h.ending_balance)
					})]
				}, h.id))]
			})
		]
	});
}
function Stat({ label, v, bad, good }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `font-semibold tabular-nums ${bad ? "text-destructive" : good ? "text-emerald-700" : ""}`,
		children: fmtMoney(v)
	})] });
}
//#endregion
export { Banking as component };
