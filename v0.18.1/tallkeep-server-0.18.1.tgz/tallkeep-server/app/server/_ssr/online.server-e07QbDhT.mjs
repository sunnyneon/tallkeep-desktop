import { c as licensedFeatures, i as EDITION_KEYS, l as onlineBundle, n as ADDON_KEYS, o as catalog } from "./editions-Fg8o4E4M.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/online.server-e07QbDhT.js
/**
* Online plans (app.tallkeep.com), on Tallkeep's server: Stripe subscriptions for accounts.
* The account's status, limits and features are only ever set from what Stripe itself says
* (syncOnline reads the subscription from Stripe; nothing is taken from a message's body).
*/
var PRODUCT = "tallkeep_online";
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
/** Prices with the owner panel's changes. */
async function onlineCatalog() {
	const { readPrices } = await import("./admin.functions-CHI4k2kU.mjs");
	const row = await readPrices().catch(() => null);
	return catalog(row?.prices ?? null);
}
function cleanPick(d) {
	if (!EDITION_KEYS.includes(d.plan)) throw new Error("Pick a plan.");
	const n = (v) => {
		const x = Number(v ?? 0);
		if (!Number.isInteger(x) || x < 0 || x > 100) throw new Error("Type a whole number from 0 to 100.");
		return x;
	};
	return {
		plan: d.plan,
		addons: [...new Set((d.addons ?? []).filter((a) => ADDON_KEYS.includes(a)))],
		extraUsers: n(d.extraUsers),
		extraCompanies: n(d.extraCompanies),
		yearly: !!d.yearly
	};
}
/** The signed-in person's account; only its admins may change the plan. */
async function myOrg(userId, mustBeAdmin) {
	const db = await admin();
	const { data: m } = await db.from("org_members").select("org_id").eq("user_id", userId).maybeSingle();
	if (!m?.org_id) throw new Error("Your account is not set up yet.");
	const { data: o } = await db.from("orgs").select("*").eq("id", m.org_id).maybeSingle();
	if (!o) throw new Error("Your account is not set up yet.");
	if (mustBeAdmin) {
		const { data: r } = await db.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
		if (!r) throw new Error("Only an admin of your account can change the plan.");
	}
	return o;
}
var LABEL = (cat) => ({
	...Object.fromEntries(EDITION_KEYS.map((k) => [k, `Tallkeep Online – ${cat.editions[k].label}`])),
	...Object.fromEntries(ADDON_KEYS.map((k) => [k, `Tallkeep Online – ${cat.addons[k].label} add-on`])),
	extra_user: "Tallkeep Online – extra person",
	extra_company: "Tallkeep Online – extra company"
});
/** Stripe products with our own ids (made the first time they're needed). */
async function product(id, name) {
	const { stripe } = await import("./pay.server-BF1ryl4S.mjs");
	const pid = `tk_online_${id}`;
	try {
		await stripe(`products/${pid}`);
	} catch {
		await stripe("products", {
			id: pid,
			name
		}).catch(async (e) => {
			if (!/already exists/i.test(e.message)) throw e;
		});
	}
	return pid;
}
/** The lines of a plan, as Stripe price_data (cents, per month or per year). */
async function planLines(pick) {
	const cat = await onlineCatalog();
	const names = LABEL(cat);
	const per = pick.yearly ? 10 : 1;
	const lines = [{
		key: pick.plan,
		cents: Math.round(cat.editions[pick.plan].month * per * 100),
		qty: 1
	}, ...pick.addons.map((a) => ({
		key: a,
		cents: Math.round(cat.addons[a].month * per * 100),
		qty: 1
	}))];
	if (pick.extraUsers) lines.push({
		key: "extra_user",
		cents: Math.round(cat.extra.user * per * 100),
		qty: pick.extraUsers
	});
	if (pick.extraCompanies) lines.push({
		key: "extra_company",
		cents: Math.round(cat.extra.company * per * 100),
		qty: pick.extraCompanies
	});
	const out = [];
	for (const l of lines) out.push({
		...l,
		product: await product(l.key, names[l.key] ?? l.key)
	});
	return out;
}
function pickMetadata(pick, org, prefix) {
	return {
		[`${prefix}[product]`]: PRODUCT,
		[`${prefix}[org]`]: org,
		[`${prefix}[plan]`]: pick.plan,
		[`${prefix}[addons]`]: pick.addons.join(","),
		[`${prefix}[extra_users]`]: String(pick.extraUsers),
		[`${prefix}[extra_companies]`]: String(pick.extraCompanies),
		[`${prefix}[billing]`]: pick.yearly ? "year" : "month"
	};
}
async function readSub(id) {
	const { stripe } = await import("./pay.server-BF1ryl4S.mjs");
	return await stripe(`subscriptions/${encodeURIComponent(id)}`);
}
/** Bring an account up to date from its Stripe subscription. */
async function syncOnline(subscriptionId) {
	const sub = await readSub(subscriptionId);
	const md = sub.metadata ?? {};
	const org = md["org"];
	if (md["product"] !== "tallkeep_online" || !org) return null;
	const db = await admin();
	const { data: o } = await db.from("orgs").select("*").eq("id", org).maybeSingle();
	if (!o || o.is_platform) return null;
	const cur = o.stripe_subscription;
	if (cur && cur !== sub.id && ["canceled", "incomplete_expired"].includes(sub.status)) return null;
	if (sub.status === "incomplete") return o;
	const pick = cleanPick({
		plan: md["plan"],
		addons: (md["addons"] ?? "").split(",").filter(Boolean),
		extraUsers: Number(md["extra_users"] ?? 0),
		extraCompanies: Number(md["extra_companies"] ?? 0),
		yearly: md["billing"] === "year"
	});
	const b = onlineBundle(await onlineCatalog(), pick.plan, pick.addons, pick.extraUsers, pick.extraCompanies, pick.yearly);
	const ended = sub.status === "canceled" || sub.status === "incomplete_expired" || sub.status === "unpaid";
	const status = ended ? "canceled" : sub.status === "past_due" ? "past_due" : "active";
	const end = sub.current_period_end ?? sub.items?.data?.[0]?.current_period_end ?? null;
	const iso = (t) => t ? (/* @__PURE__ */ new Date(t * 1e3)).toISOString() : null;
	const patch = {
		status,
		plan: pick.plan,
		plan_addons: pick.addons,
		billing: pick.yearly ? "year" : "month",
		stripe_customer: sub.customer,
		stripe_subscription: sub.id,
		paid_until: iso(end),
		ends_at: sub.cancel_at_period_end ? iso(end) : iso(sub.cancel_at),
		closed_at: ended ? o.closed_at ?? (/* @__PURE__ */ new Date()).toISOString() : null,
		companies_allowed: b.companies,
		users_allowed: b.users,
		ai_pages_month: b.aiPages,
		licensed_features: licensedFeatures(pick.plan, pick.addons)
	};
	const { data, error } = await db.from("orgs").update(patch).eq("id", org).select("*").single();
	if (error) throw new Error(error.message);
	return data;
}
//#endregion
export { admin, cleanPick, myOrg, onlineCatalog, pickMetadata, planLines, readSub, syncOnline };
