import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/download-3LkKiGo8.js
var $$splitComponentImporter = () => import("./download-C7YX1dGR.mjs");
/** Download Tallkeep: pick Windows, Synology/Linux (or Mac, coming soon), a short form, go. */
var Route = createFileRoute("/download")({
	ssr: false,
	validateSearch: (s) => ({
		...typeof s["for"] === "string" ? { for: s["for"] } : {},
		...typeof s["from"] === "string" ? { from: s["from"] } : {}
	}),
	head: () => ({ meta: [{ title: "Download Tallkeep" }, {
		name: "description",
		content: "Download Tallkeep for Windows, Synology or Linux. Free for 30 days."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
