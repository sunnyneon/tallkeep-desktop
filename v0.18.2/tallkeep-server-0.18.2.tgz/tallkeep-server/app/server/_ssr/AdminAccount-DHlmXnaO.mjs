import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { changeAccount } from "./admin.functions-DN1eN2lO.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/AdminAccount-DHlmXnaO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	trial: "Free trial",
	active: "Paying",
	past_due: "Payment late",
	canceled: "Canceled"
};
var daysLeft = (a) => a.trial_ends_at ? Math.ceil((Date.parse(a.trial_ends_at) - Date.now()) / 864e5) : null;
/** What the customer sees right now, in plain words. */
function standing(a) {
	if (a.is_platform) return {
		text: "Our own group",
		tone: "bg-muted"
	};
	if (a.status === "trial") {
		const d = daysLeft(a);
		if (d != null && d <= 0) return {
			text: "Trial ended (read-only)",
			tone: "bg-red-100 text-red-900"
		};
		return {
			text: `Free trial, ${d ?? "?"} day${d === 1 ? "" : "s"} left`,
			tone: d != null && d <= 7 ? "bg-amber-100 text-amber-900" : "bg-sky-100 text-sky-900"
		};
	}
	if (a.status === "canceled") {
		const left = a.closed_at ? 90 - Math.floor((Date.now() - Date.parse(a.closed_at)) / 864e5) : null;
		return {
			text: left == null ? "Canceled (read-only)" : left > 0 ? `Canceled, books kept ${left} more day${left === 1 ? "" : "s"}` : "Canceled over 90 days: books can be deleted",
			tone: "bg-red-100 text-red-900"
		};
	}
	if (a.status === "past_due") return {
		text: "Payment late",
		tone: "bg-amber-100 text-amber-900"
	};
	return {
		text: "Paying",
		tone: "bg-emerald-100 text-emerald-900"
	};
}
var selectClass = "h-9 w-full rounded-md border border-input bg-background px-3 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-ring";
function ChangeDialog({ account, onClose }) {
	const qc = useQueryClient();
	const [status, setStatus] = (0, import_react.useState)(account.status);
	const [edition, setEdition] = (0, import_react.useState)(account.edition);
	const [trialEnd, setTrialEnd] = (0, import_react.useState)(account.trial_ends_at?.slice(0, 10) ?? "");
	const [companies, setCompanies] = (0, import_react.useState)(account.companies_allowed?.toString() ?? "");
	const [people, setPeople] = (0, import_react.useState)(account.users_allowed?.toString() ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const addDays = (n) => {
		setTrialEnd(new Date(Math.max(Date.now(), trialEnd ? Date.parse(trialEnd) : 0) + n * 864e5).toISOString().slice(0, 10));
		setStatus("trial");
	};
	const num = (s) => s.trim() === "" ? null : Number(s);
	async function save() {
		setBusy(true);
		try {
			const change = {
				id: account.id,
				status,
				edition,
				trial_ends_at: trialEnd ? (/* @__PURE__ */ new Date(`${trialEnd}T23:59:00`)).toISOString() : null,
				companies_allowed: num(companies),
				users_allowed: num(people)
			};
			await changeAccount({ data: change });
			toast.success("Plan saved.");
			qc.invalidateQueries({ queryKey: ["admin-accounts"] });
			qc.invalidateQueries({ queryKey: ["admin-account"] });
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Change plan: ", account.name] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Standing"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: selectClass,
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: Object.entries(STATUS).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: v
							}, k))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Version"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: selectClass,
							value: edition,
							onChange: (e) => setEdition(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "cloud",
								children: "Cloud"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "desktop",
								children: "Desktop"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Companies allowed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "numeric",
							value: companies,
							onChange: (e) => setCompanies(e.target.value),
							placeholder: "No limit"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "People allowed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "numeric",
							value: people,
							onChange: (e) => setPeople(e.target.value),
							placeholder: "No limit"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Free trial ends"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: trialEnd,
								onChange: (e) => setTrialEnd(e.target.value),
								className: "w-44"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => addDays(30),
								children: "Add 30 days to the trial"
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Free trial: they can work until the end date, then the books turn read-only. Paying or Payment late: they can work. Canceled: read-only."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Close without saving"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				disabled: busy,
				children: busy ? "Saving…" : "Save plan"
			})] })
		] })
	});
}
//#endregion
export { daysLeft as n, standing as r, ChangeDialog as t };
