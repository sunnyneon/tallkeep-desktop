import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, t as axisMoney } from "./format-CgElbAz-.mjs";
import { n as db, r as fetchAll } from "./db-BTfVNKFN.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons--77O3UAF.mjs";
import { b as Link, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, h as yearStart, m as useTotals, p as useAccounts } from "./accounting-CNNI6VXG.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { C as ShoppingCart, Cn as Boxes, In as ArrowRight, It as FileText, Jt as CreditCard, L as Receipt, Y as Package, a as Wallet, en as ClipboardList, h as TrendingUp, m as TriangleAlert, p as Truck, pn as ChartColumn, s as Users, st as Mail, vn as CalendarDays, vt as Landmark, xn as Building2, yt as KeyRound } from "../_libs/lucide-react.mjs";
import { t as GROUP_COLOR } from "./nav-BIrQ7OjK.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as loadCharges, s as useRealEstate } from "./realestate-B6VY8e0h.mjs";
import { n as useProductList } from "./products-CDbHeGKR.mjs";
import { h as rentInAr } from "./reports-DtOLleQw.mjs";
import { a as YAxis, i as BarChart, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, u as Bar } from "../_libs/recharts+[...].mjs";
import { t as PlCharts } from "./PlCharts-Dao2JJKT.mjs";
import { n as ageDays, o as stageOf, t as DEFAULT_RULES } from "./followups-CAmQFMgv.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/overview-BYX9fGbo.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Personal books have their numbers on Home; this page is the business one. */
function OverviewPage() {
	const { data: features } = useFeatures();
	if (!features) return null;
	if (features.includes("personal")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/",
		replace: true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, { realEstate: features.includes("real_estate") });
}
var SOLD = [
	"invoiced",
	"paid",
	"completed"
];
/** "1 invoice", "2 invoices". */
var count = (n, one, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function Home$1({ realEstate }) {
	const qc = useQueryClient();
	const { data: products } = useProductList();
	const { data: accounts } = useAccounts();
	const { data: allTime } = useTotals(null, null);
	const { data: rentAr } = useQuery({
		queryKey: ["rent-in-ar"],
		enabled: realEstate,
		queryFn: rentInAr
	});
	const { data: thisYear } = useTotals(yearStart(), null);
	const { data: re } = useRealEstate(realEstate);
	const { data: openRent } = useQuery({
		queryKey: ["rent-open-overview"],
		enabled: realEstate,
		queryFn: () => loadCharges(true)
	});
	const { data: sos } = useQuery({
		queryKey: ["home", "sales"],
		queryFn: () => fetchAll("sales_orders", "*")
	});
	const { data: booksStart } = useQuery({
		queryKey: ["books-start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
	const monthStart = new Date((/* @__PURE__ */ new Date()).getFullYear(), (/* @__PURE__ */ new Date()).getMonth(), 1);
	const { data: paidThisMonth } = useQuery({
		queryKey: [
			"home",
			"payments",
			monthStart.toISOString()
		],
		queryFn: async () => {
			const { data } = await db.from("payments").select("amount, method").not("sales_order_id", "is", null).gte("paid_on", monthStart.toISOString()).limit(5e3);
			return (data ?? []).filter((p) => p.method !== "Paid before switch-over").reduce((s, p) => s + Number(p.amount), 0);
		}
	});
	const { data: stockValue } = useQuery({
		queryKey: ["home", "stock-value"],
		queryFn: async () => {
			return (await fetchAll("stock", "qty,products(cost)")).reduce((s, r) => s + Math.max(0, Number(r.qty)) * Number(r.products?.cost ?? 0), 0);
		}
	});
	const { data: rules } = useQuery({
		queryKey: ["followup-rules"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			const r = { ...DEFAULT_RULES };
			if (data) Object.keys(r).forEach((k) => {
				const v = data[k];
				if (v != null) r[k] = v;
			});
			return r;
		}
	});
	const now = /* @__PURE__ */ new Date();
	const y = now.getFullYear();
	const dayOfYear = (d) => Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 1).getTime()) / 864e5);
	const stats = (0, import_react.useMemo)(() => {
		const sold = (sos ?? []).filter((o) => SOLD.includes(o.status) && !o.number.startsWith("RMA-") && (!booksStart || (o.invoice_date ?? o.order_date).slice(0, 10) >= booksStart));
		const when = (o) => new Date(o.invoice_date ?? o.order_date);
		const ytd = sold.filter((o) => when(o).getFullYear() === y);
		const lastYtd = sold.filter((o) => when(o).getFullYear() === y - 1 && dayOfYear(when(o)) <= dayOfYear(now));
		const month = ytd.filter((o) => when(o).getMonth() === now.getMonth());
		const sum = (l) => l.reduce((s, o) => s + Number(o.total) - Number(o.tax ?? 0), 0);
		const byMonth = MONTHS.map((m, i) => ({
			month: m,
			[String(y)]: sum(ytd.filter((o) => when(o).getMonth() === i)),
			[String(y - 1)]: sum(sold.filter((o) => when(o).getFullYear() === y - 1 && when(o).getMonth() === i))
		}));
		const top = /* @__PURE__ */ new Map();
		ytd.forEach((o) => top.set(o.customer_name ?? "—", (top.get(o.customer_name ?? "—") ?? 0) + Number(o.total) - Number(o.tax ?? 0)));
		const quotes = (sos ?? []).filter((o) => o.status === "quote" && !o.number.startsWith("RMA-"));
		const toFollow = quotes.filter((o) => !o.accepted_at);
		const unpaid = (sos ?? []).filter((o) => [
			"open",
			"invoiced",
			"paid",
			"completed"
		].includes(o.status) && !o.number.startsWith("RMA-") && Number(o.balance) > .005);
		const inBooks = (o) => !!booksStart && (o.invoice_date ?? o.order_date).slice(0, 10) >= booksStart;
		const owed = unpaid.filter((o) => o.status !== "open" && inBooks(o));
		const notInvoiced = unpaid.filter((o) => o.status === "open");
		const beforeBooks = unpaid.filter((o) => o.status !== "open" && !inBooks(o));
		return {
			ytd: sum(ytd),
			lastYtd: sum(lastYtd),
			month: sum(month),
			count: ytd.length,
			avg: ytd.length ? sum(ytd) / ytd.length : 0,
			byMonth,
			top: [...top.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5),
			quotes: quotes.length,
			quotesValue: sum(quotes),
			owed: owed.reduce((s, o) => s + Number(o.balance), 0),
			owedCount: owed.length,
			notInvoiced: notInvoiced.reduce((s, o) => s + Number(o.balance), 0),
			notInvoicedCount: notInvoiced.length,
			beforeBooks: beforeBooks.reduce((s, o) => s + Number(o.balance), 0),
			beforeBooksCount: beforeBooks.length,
			quoteList: toFollow
		};
	}, [
		sos,
		y,
		booksStart
	]);
	const r = rules ?? DEFAULT_RULES;
	const due = stats.quoteList.map((q) => ({
		q,
		st: stageOf(q, r)
	})).filter((x) => x.st === "first" || x.st === "second").sort((a, b) => a.q.order_date.localeCompare(b.q.order_date));
	const stale = stats.quoteList.filter((q) => stageOf(q, r) === "close").length;
	const change = stats.lastYtd ? (stats.ytd - stats.lastYtd) / stats.lastYtd * 100 : null;
	async function closeQuote(id) {
		const { error } = await db.from("sales_orders").update({
			status: "cancelled",
			closed_reason: "Closed: customer didn't go ahead"
		}).eq("id", id);
		if (error) toast.error(error.message);
		else {
			toast.success("Quote closed. You can reopen it from the quote page.");
			qc.invalidateQueries({ queryKey: ["home"] });
		}
	}
	const active = (products ?? []).filter((p) => p.is_active);
	const low = active.filter((p) => {
		const on = p.stock.reduce((s, x) => s + Number(x.qty), 0);
		return p.item_type === "stocked" && Number(p.reorder_point) > 0 && on <= Number(p.reorder_point);
	});
	const negative = active.filter((p) => p.item_type === "stocked" && p.stock.reduce((s, x) => s + Number(x.qty), 0) < 0).length;
	const v = (x, f = fmtMoney) => x == null || !sos ? "…" : f(x);
	const money = (0, import_react.useMemo)(() => {
		if (!accounts || !allTime || !thisYear || realEstate && rentAr == null) return null;
		const all = balFrom(allTime);
		const yr = balFrom(thisYear);
		const sum = (f, b) => accounts.filter(f).reduce((t, a) => t + b(a), 0);
		const income = sum((a) => a.type === "income", yr);
		return {
			cash: sum((a) => a.kind === "bank", all),
			ar: sum((a) => a.kind === "ar", all) - (realEstate ? rentAr ?? 0 : 0),
			owed: sum((a) => ["credit_card", "long_term_liability"].includes(a.kind) || /loan|mortgage/i.test(a.name) && a.type === "liability", all),
			income,
			profit: income - sum((a) => a.type === "expense", yr),
			inventory: accounts.some((a) => a.kind === "inventory" && allTime.has(a.id)) ? sum((a) => a.kind === "inventory", all) : null
		};
	}, [
		accounts,
		allTime,
		thisYear,
		realEstate,
		rentAr
	]);
	const showSales = !sos || sos.length > 0 || (products ?? []).some((p) => p.is_active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Overview",
				text: "Your day at a glance: numbers, what needs attention, and recent work."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedsAttention, {
				cash: money?.cash ?? null,
				booksStart: booksStart ?? null
			}),
			money && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/banking",
						icon: Landmark,
						label: "Cash in the bank",
						value: fmtMoney(money.cash)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/accounts",
						icon: CreditCard,
						label: "Owed on cards and loans",
						value: fmtMoney(money.owed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/financials",
						icon: TrendingUp,
						label: `Income this year (${y})`,
						value: fmtMoney(money.income),
						hint: "Income in the books this year (Profit & Loss), before tax: sales plus other income, less refunds."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/financials",
						icon: ChartColumn,
						label: `Profit this year (${y})`,
						value: fmtMoney(money.profit),
						good: money.profit > 0,
						bad: money.profit < 0
					})
				]
			}),
			re && re.properties.some((p) => p.is_active) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: (() => {
					const props = re.properties.filter((p) => p.is_active);
					const land = props.filter((p) => p.kind === "land").length;
					const units = re.units.filter((u) => u.is_active && u.rental_type !== "short");
					const rented = units.filter((u) => re.current(u.id)).length;
					const soon = new Date(Date.now() + 5184e6).toISOString().slice(0, 10);
					const ending = re.leases.filter((l) => l.status === "active" && l.end_date && l.end_date <= soon).length;
					const owed = (openRent ?? []).reduce((t, c) => t + c.balance, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/properties",
							icon: Building2,
							label: "Properties",
							value: String(props.length),
							sub: land ? `${land} land` : void 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/properties",
							icon: KeyRound,
							label: "Units rented",
							value: units.length ? `${rented} of ${units.length}` : "—",
							sub: units.length > rented ? `${units.length - rented} empty` : void 0,
							bad: units.length > rented
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/rent",
							icon: Wallet,
							label: "Rent owed to you",
							value: openRent ? fmtMoney(owed) : "…",
							bad: owed > 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/leases",
							icon: CalendarDays,
							label: "Leases ending in 60 days",
							value: String(ending),
							bad: ending > 0
						})
					] });
				})()
			}),
			showSales && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: TrendingUp,
						label: `Sales this year (${y})`,
						value: v(stats.ytd),
						hint: "Invoices in the books dated this year, before tax. Income also counts other income and takes off refunds.",
						sub: change == null ? `${count(stats.count, "invoice")}, before tax` : `${change >= 0 ? "▲" : "▼"} ${Math.abs(change).toFixed(0)}% vs same time ${y - 1}`,
						good: change != null && change >= 0,
						bad: change != null && change < 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: CalendarDays,
						label: `Sales in ${MONTHS[now.getMonth()]}`,
						value: v(stats.month)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						icon: Wallet,
						label: `Payments received in ${MONTHS[now.getMonth()]}`,
						value: paidThisMonth == null ? "…" : fmtMoney(paidThisMonth)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						search: { pay: "owed" },
						icon: Receipt,
						label: "Customers owe",
						value: sos ? fmtMoney(stats.owed + stats.beforeBooks) : "…",
						hint: "What customers owe on unpaid invoices. Opens the unpaid invoices. In the books is the Balance Sheet's Accounts Receivable; invoices from before your books start aren't in it.",
						sub: sos ? [
							count(stats.owedCount + stats.beforeBooksCount, "unpaid invoice"),
							stats.beforeBooksCount ? `${fmtMoney(stats.beforeBooks)} of it from before your books start` : "",
							money ? `In the books: ${fmtMoney(money.ar)}` : "",
							stats.notInvoicedCount ? `+ ${fmtMoney(stats.notInvoiced)} on ${count(stats.notInvoicedCount, "order")} not invoiced yet` : ""
						].filter(Boolean).join(" · ") : void 0,
						bad: sos ? stats.owed + stats.beforeBooks > 0 : false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						icon: FileText,
						label: "Open quotes",
						value: sos ? String(stats.quotes) : "…",
						sub: sos ? `worth ${fmtMoney(stats.quotesValue)}` : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: ChartColumn,
						label: "Average invoice this year",
						value: v(stats.avg)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/stock",
						icon: Boxes,
						label: "Stock value (at cost)",
						value: money?.inventory != null ? fmtMoney(money.inventory) : stockValue == null ? "…" : fmtMoney(stockValue),
						hint: money?.inventory != null ? "Inventory in the books: the same as the Balance Sheet. It can differ from on-hand times today's cost when a cost changed after the stock came in, or stock was counted below zero." : "What's on hand times each product's cost.",
						sub: [products ? `${active.length.toLocaleString()} active products` : "", money?.inventory != null && stockValue != null && Math.abs(money.inventory - stockValue) > .005 ? `${fmtMoney(stockValue)} at today's product costs` : ""].filter(Boolean).join(" · ")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/products",
						icon: TriangleAlert,
						label: "Running low",
						value: products ? String(low.length) : "…",
						sub: products && negative > 0 ? `${negative} below zero — check the count` : void 0,
						bad: low.length > 0
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlCharts, {
				from: yearStart(),
				to: (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"),
				personal: false
			}),
			showSales && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-sm font-semibold text-muted-foreground",
						children: "How things flow"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-5 items-start gap-1 text-center text-xs sm:text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/vendors",
								icon: Truck,
								label: "Vendor",
								color: GROUP_COLOR.Purchasing.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/purchase-orders",
								icon: ClipboardList,
								label: "Purchase order",
								arrow: true,
								color: GROUP_COLOR.Purchasing.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/stock",
								icon: Boxes,
								label: "Inventory",
								arrow: true,
								strong: true,
								color: GROUP_COLOR.Inventory.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/sales-list",
								icon: Receipt,
								label: "Invoice",
								arrow: true,
								color: GROUP_COLOR.Sales.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/customers",
								icon: Users,
								label: "Customer",
								arrow: true,
								color: GROUP_COLOR.Sales.main
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border bg-card p-4 lg:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-2 text-sm font-semibold text-muted-foreground",
							children: [
								"Sales by month — ",
								y,
								" and ",
								y - 1
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-56",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: stats.byMonth,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											strokeDasharray: "3 3",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "month",
											tick: { fontSize: 11 }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: { fontSize: 11 },
											tickFormatter: axisMoney,
											width: 48
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (n) => fmtMoney(n) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: String(y - 1),
											fill: "#cbd5e1",
											radius: [
												3,
												3,
												0,
												0
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: String(y),
											fill: GROUP_COLOR.Sales.main,
											radius: [
												3,
												3,
												0,
												0
											]
										})
									]
								})
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-sm font-semibold text-muted-foreground",
								children: "Top customers this year"
							}),
							stats.top.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No sales yet this year."
							}),
							stats.top.map(([name, total], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 border-b py-2 text-sm last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0 truncate",
									title: name,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mr-2 text-muted-foreground",
										children: [i + 1, "."]
									}), name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-semibold",
									children: fmtMoney(total)
								})]
							}, name))
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold text-muted-foreground",
							children: [
								"Quotes to follow up (",
								due.length,
								")",
								stale > 0 && ` · ${stale} older than ${r.quote_close_days} days`
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "text-xs text-primary underline",
							children: r.followup_enabled ? "Follow-up rules" : "Turn on daily follow-ups"
						})]
					}), due.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Nothing to follow up today."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y",
						children: due.slice(0, 12).map(({ q, st }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/sales/$id",
									params: { id: q.id },
									className: "w-28 font-medium underline",
									children: q.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: q.customer_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [ageDays(q.order_date), " days"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-20 text-right font-semibold",
									children: fmtMoney(q.total)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-0.5 text-xs ${st === "second" ? "bg-orange-100 text-orange-800" : "bg-sky-100 text-sky-800"}`,
									children: st === "second" ? "2nd follow-up" : "1st follow-up"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/sales/$id",
										params: { id: q.id },
										search: { followup: "1" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email follow-up"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void closeQuote(q.id),
									children: "Close quote"
								})
							]
						}, q.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/sales/$id",
							icon: FileText,
							label: "New quote",
							search: { kind: "quote" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/sales/$id",
							icon: ShoppingCart,
							label: "New invoice",
							search: { kind: "order" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/products",
							icon: Package,
							label: "Find a product"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/stock",
							icon: Boxes,
							label: "Check stock"
						})
					]
				})
			] })
		]
	});
}
function Tile({ to, search, icon: Icon, label, value, sub, good, bad, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		...search ? { search } : {},
		title: hint,
		className: "min-w-0 rounded-2xl border bg-card p-4 transition-colors hover:bg-muted/50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: bad ? "h-5 w-5 text-primary" : "h-5 w-5 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground [overflow-wrap:anywhere]",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl font-bold [overflow-wrap:anywhere] sm:text-2xl",
				children: value
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-xs [overflow-wrap:anywhere] ${good ? "text-emerald-700" : bad ? "text-primary" : "text-muted-foreground"}`,
				children: sub
			})
		]
	});
}
function FlowStep({ to, icon: Icon, label, arrow, strong, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group relative flex flex-col items-center gap-2 rounded-xl p-2 hover:bg-muted/60",
		children: [
			arrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "absolute -left-2 top-5 h-4 w-4 text-muted-foreground/50 sm:top-6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `grid place-items-center rounded-2xl text-white shadow-sm ${strong ? "h-14 w-14 sm:h-16 sm:w-16" : "h-11 w-11 sm:h-14 sm:w-14"}`,
				style: { backgroundColor: color },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 sm:h-7 sm:w-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: strong ? "font-semibold uppercase" : "uppercase",
				children: label
			})
		]
	});
}
function Quick({ to, icon: Icon, label, search }) {
	const cls = "flex items-center gap-2 rounded-xl border bg-card px-3 py-3 text-sm font-medium hover:bg-muted/50";
	if (to === "/sales/$id") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/sales/$id",
		params: { id: "new" },
		search: search ?? {},
		className: cls,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-primary" }), label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cls,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-primary" }), label]
	});
}
/** What to deal with today (improvement 4): overdue invoices, bills due this week, bank lines to
*  review, and cash below zero. Shown only when there's something. */
function NeedsAttention({ cash, booksStart }) {
	const { data } = useQuery({
		queryKey: [
			"home",
			"attention",
			booksStart
		],
		queryFn: async () => {
			const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
			const week = new Date(Date.now() + 6048e5).toLocaleDateString("en-CA");
			const [inv, bills, bank] = await Promise.all([
				db.from("sales_orders").select("balance,due_date,invoice_date,order_date,number").in("status", ["invoiced", "paid"]).gt("balance", .005).lt("due_date", today).limit(2e3),
				db.from("bills").select("balance").eq("status", "open").gt("balance", .005).lte("due_date", week).limit(2e3),
				db.from("bank_transactions").select("id", {
					count: "exact",
					head: true
				}).eq("status", "new")
			]);
			const overdue = (inv.data ?? []).filter((o) => !o.number.startsWith("RMA-") && (!booksStart || (o.invoice_date ?? o.order_date).slice(0, 10) >= booksStart));
			const due = bills.data ?? [];
			return {
				overdue: overdue.length,
				overdueSum: overdue.reduce((t, o) => t + Number(o.balance), 0),
				bills: due.length,
				billsSum: due.reduce((t, b) => t + Number(b.balance), 0),
				bank: bank.count ?? 0
			};
		}
	});
	const items = [];
	if (cash != null && cash < -.005) items.push({
		text: `Cash in the bank is below zero (${fmtMoney(cash)}). Check for missing deposits or reconcile.`,
		to: "/banking"
	});
	if (data?.overdue) items.push({
		text: `${count(data.overdue, "invoice")} overdue · ${fmtMoney(data.overdueSum)}`,
		to: "/sales-list",
		search: { pay: "late" }
	});
	if (data?.bills) items.push({
		text: `${count(data.bills, "bill")} due this week · ${fmtMoney(data.billsSum)}`,
		to: "/pay-bills"
	});
	if (data?.bank) items.push({
		text: `${count(data.bank, "bank line")} to review`,
		to: "/banking"
	});
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": "Needs attention today",
		className: "rounded-2xl border border-amber-300 bg-amber-50 p-4 text-amber-950 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold",
			children: "Needs attention today"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-2 grid gap-1.5 text-sm lg:grid-cols-2",
			children: items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "min-w-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: i.to,
					search: i.search,
					className: "underline-offset-2 [overflow-wrap:anywhere] hover:underline",
					children: [i.text, " →"]
				})
			}, i.text))
		})]
	});
}
//#endregion
export { OverviewPage as component };
