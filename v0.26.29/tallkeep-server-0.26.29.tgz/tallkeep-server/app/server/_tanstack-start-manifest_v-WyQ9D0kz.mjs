//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-WyQ9D0kz.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BHB0f1TU.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DhZbxwLH.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-A7debo1z.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BHB0f1TU.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-knuTuUo9.js",
			"/assets/log-out-DbxiWl4F.js",
			"/assets/testers.functions-wzNYoG1r.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CAq42yAI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-iB2bvvXb.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CeUAmu_p.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-DI4YZLnk.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/dist-Cibc2cFa.js",
			"/assets/dialog-Cg9imrgk.js",
			"/assets/queries-C77QBGDs.js",
			"/assets/input-Crf8CMen.js",
			"/assets/label-DwmXkzIl.js",
			"/assets/textarea-COGPe4df.js",
			"/assets/shoebox-B4oiEyUM.js",
			"/assets/company-KNMAU5ix.js",
			"/assets/reports-B21tVhNv.js",
			"/assets/access-BrdbkE17.js",
			"/assets/theme-C3mT96xd.js",
			"/assets/Logo-YouvaS7T.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-XpnNrTcH.js",
			"/assets/log-out-DbxiWl4F.js",
			"/assets/admin.functions-DnRD53aV.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-YouvaS7T.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-SiplEwVx.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/label-DwmXkzIl.js",
			"/assets/Logo-YouvaS7T.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-CIXqxw2w.js",
			"/assets/testers.functions-wzNYoG1r.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/coupons.functions-C5oYtnVw.js",
			"/assets/buy.functions-Dca08cCB.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DOdgKydt.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/downloads.functions-DTpbEVp8.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CN6TnkUy.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/label-DwmXkzIl.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BslLjtRF.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/label-DwmXkzIl.js",
			"/assets/Logo-YouvaS7T.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BHjnbHkM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/upgrade.functions-C6RqKWaq.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CyNCqpeR.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/label-DwmXkzIl.js",
			"/assets/Logo-YouvaS7T.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CkUkQHfu.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-D_OynJEe.js", "/assets/StockDocList-B_8sOyg1.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CmRZPY-b.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/ai-CwVJRj0V.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BN08rBBA.js",
			"/assets/BankConnections-CffRMYoa.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-DnyNbCbQ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-s2Hj3-ry.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-CffRMYoa.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/ai-CwVJRj0V.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-fByvk9GW.js",
			"/assets/TxnEditor-C-4g7cg3.js",
			"/assets/feedWaiting-D2OGVIBi.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-C7eoGcyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-Bkk9zuVQ.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/personal-DwljOv8M.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/WhoPicker-Dhc9dgCo.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-gHD0sRcA.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-D0GHDCx-.js", "/assets/AccountRegister-DSnRRPsf.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Bop9eL6Q.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-uU9-D3dl.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/money-CIqc6QpQ.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-AMeZcwgo.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CwVJRj0V.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-S6WzrxZL.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-DQ21UW5X.js", "/assets/StockDocList-B_8sOyg1.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CC8__RhE.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-C_4-k-sT.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CuxOAL_Y.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BDKIVjJA.js", "/assets/PartyList-BqvVdClE.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BLyUvd4Z.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Cy_znPkx.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/storage.functions-BJCQ9MpD.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-v8cCNLxc.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-ZYMUxjVV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-EmdhD8UA.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CR2g6jQR.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DktQKjlk.js", "/assets/ChangeHistory-B_BduPuR.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BxoldhOb.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/members-DgZEsZkr.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-9fNCKMhR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/personal-DwljOv8M.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/WhoPicker-Dhc9dgCo.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CntDf28v.js", "/assets/SalesList-BNTx5ml2.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-SFTBZUg7.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Ck7RlrGJ.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BaFETgv9.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CX3WA1-Z.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/loans-fByvk9GW.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-qpyVTvcV.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BeIz944W.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-D8PdBIdi.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/personal-DwljOv8M.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/WhoPicker-Dhc9dgCo.js",
			"/assets/reminders-DKeFyvBT.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BCz5PPMC.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-Cq8lxipm.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/personal-DwljOv8M.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/WhoPicker-Dhc9dgCo.js",
			"/assets/generateCategoricalChart-2nC2hov3.js",
			"/assets/Area-DUUMVEzt.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CxM_raTp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/generateCategoricalChart-2nC2hov3.js",
			"/assets/PlCharts-EmdhD8UA.js",
			"/assets/BarChart-Bq8dofuP.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CCrzgpPW.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-VYWlAROa.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-Q37hVDAo.js",
			"/assets/createServerFn-CAH6fekQ.js",
			"/assets/auth-middleware-CjG9tDYK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/storage.functions-BJCQ9MpD.js",
			"/assets/coupons.functions-C5oYtnVw.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-bUIdshBK.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-G6QpI-4f.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/checkbox-CJWPzS3z.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-C2KaMgF0.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DU1PTYkm.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-du1LkA5W.js", "/assets/SalesList-BNTx5ml2.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-Di03XKF4.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/ai-CwVJRj0V.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BJCQ9MpD.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-b8cSjZqL.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/money-CIqc6QpQ.js",
			"/assets/badge-xCELSQZc.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-C33B0g55.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BMx-EXzY.js", "/assets/AccountRegister-DSnRRPsf.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-D4A7YCvS.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/MoneyAccountPick-DTKbCEyl.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BKnJmp_V.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-D0VP3b89.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/RepeatInvoice-BjQ-rCYi.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Jt1YFP21.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-2nC2hov3.js",
			"/assets/BarChart-Bq8dofuP.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-COlZ6Fb7.js", "/assets/SalesList-BNTx5ml2.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DtdzGU4o.js", "/assets/SalesList-BNTx5ml2.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-D5v9PE-e.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-C-3VPv5Z.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/serials-BBbpog0c.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Q1lVaCJv.js",
			"/assets/createServerFn-CAH6fekQ.js",
			"/assets/auth-middleware-CjG9tDYK.js",
			"/assets/AppsCatalog-CtCHDIbB.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-B7lm9W25.js",
			"/assets/switch-BeIz944W.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-CuxOAL_Y.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-Da01uoPP.js",
			"/assets/footers-s6bKD0P_.js",
			"/assets/PrintFrame-BHl4ka_l.js",
			"/assets/checkbox-CJWPzS3z.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-D-d7SN1T.js",
			"/assets/support-bV4lHU5M.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-MCt29CJu.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-CtCHDIbB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-CffRMYoa.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/users.functions-D-d7SN1T.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-lNcuXIpH.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-D7UJOTVv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/photos-Da01uoPP.js",
			"/assets/stockmove-DJ1g8fiK.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-C8zLCi-r.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/loans-fByvk9GW.js",
			"/assets/feedWaiting-D2OGVIBi.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BJCQ9MpD.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DVgMS5dp.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/PrintFrame-BHl4ka_l.js",
			"/assets/DocPdf-HQrhbW1C.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-CymdN8tr.js",
			"/assets/createServerFn-CAH6fekQ.js",
			"/assets/auth-middleware-CjG9tDYK.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/MoneyAccountPick-DTKbCEyl.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-bV4lHU5M.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C8wQlRjz.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/StockDialogs-D7UJOTVv.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/stockmove-DJ1g8fiK.js",
			"/assets/checkbox-CJWPzS3z.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DBma91CZ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/members-DgZEsZkr.js",
			"/assets/WhoPicker-Dhc9dgCo.js",
			"/assets/reminders-DKeFyvBT.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-D7dCIse5.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/tickets.functions-Bz9kwFmh.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-GARR8raV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-bV4lHU5M.js",
			"/assets/support.functions-BLjza2eN.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-C_7H4InH.js", "/assets/StockDocList-B_8sOyg1.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-BZGblJn9.js", "/assets/PartyList-BqvVdClE.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BI0ZH2YV.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/tickets.functions-Bz9kwFmh.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-Dvf30H0i.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/workorders-B_8dyPIO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-WuBr0JII.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-D4Bmqfmn.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/coupons.functions-C5oYtnVw.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BZALYJo7.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/AdminAccount-CuIkCV63.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BRNXToAP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/downloads.functions-DTpbEVp8.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BylU86jb.js",
			"/assets/createServerFn-CAH6fekQ.js",
			"/assets/auth-middleware-CjG9tDYK.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DbLhbEuh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CWS7BEMH.js",
			"/assets/testers.functions-wzNYoG1r.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CAAjdWMZ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-C-iBgiAb.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-Dca08cCB.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DgEzBZKs.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/textarea-COGPe4df.js",
			"/assets/support.functions-BLjza2eN.js",
			"/assets/HelpParts-D5P5Q1l6.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-DXcZpWjQ.js",
			"/assets/ManualFrame-D6NH28GV.js",
			"/assets/manual._slug-Dp3Gge4h.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BxT8ZNaS.js",
			"/assets/createServerFn-CAH6fekQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BwOQPlx2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-C6RqKWaq.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CUIJnYG8.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CwVJRj0V.js",
			"/assets/personal-DwljOv8M.js",
			"/assets/reminders-DKeFyvBT.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CkvdMSyA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/AdminAccount-CuIkCV63.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BJY0RqSp.js", "/assets/ManualFrame-D6NH28GV.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B1_j1lV8.js", "/assets/AccountRegister-DSnRRPsf.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CPQl8MbM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/OriginalLink-xmhfImy_.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/realestate-D51pGorG.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Brg7TYGA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BZ0zW7I-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/realestate-D51pGorG.js",
			"/assets/money-CIqc6QpQ.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B7K-jUxb.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/SideList-Cgnp2Omm.js",
			"/assets/PartyHistory-kFmhTsZu.js",
			"/assets/tabs-ClbYE5Sc.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CLPjRpyA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_BduPuR.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/SideList-Cgnp2Omm.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-Befmset2.js",
			"/assets/MoneyAccountPick-DTKbCEyl.js",
			"/assets/footers-s6bKD0P_.js",
			"/assets/PrintFrame-BHl4ka_l.js",
			"/assets/serials-BBbpog0c.js",
			"/assets/SerialsBox-CwxEd_yU.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Dx4oWbkG.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-D7UJOTVv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_BduPuR.js",
			"/assets/switch-BeIz944W.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-xCELSQZc.js",
			"/assets/SideList-Cgnp2Omm.js",
			"/assets/tabs-ClbYE5Sc.js",
			"/assets/photos-Da01uoPP.js",
			"/assets/stockmove-DJ1g8fiK.js",
			"/assets/serials-BBbpog0c.js",
			"/assets/SerialsBox-CwxEd_yU.js",
			"/assets/workorders-B_8dyPIO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DNLD3QuC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B_BduPuR.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/SideList-Cgnp2Omm.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-Befmset2.js",
			"/assets/MoneyAccountPick-DTKbCEyl.js",
			"/assets/footers-s6bKD0P_.js",
			"/assets/PrintFrame-BHl4ka_l.js",
			"/assets/cardpay-Drv7RmHT.js",
			"/assets/checkbox-CJWPzS3z.js",
			"/assets/serials-BBbpog0c.js",
			"/assets/workorders-B_8dyPIO.js",
			"/assets/RepeatInvoice-BjQ-rCYi.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-Bz9kwFmh.js",
			"/assets/users.functions-D-d7SN1T.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-9JeL7iep.js",
			"/assets/select-B4XA1aXI.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/SideList-Cgnp2Omm.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-B2wMmOH6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/quickadd-of8BeLkr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-bV4lHU5M.js",
			"/assets/support.functions-BLjza2eN.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DRdNDJLC.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BkPRp8N-.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/SideList-Cgnp2Omm.js",
			"/assets/PartyHistory-kFmhTsZu.js",
			"/assets/tabs-ClbYE5Sc.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CdXpHZmt.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/sales-S6WzrxZL.js",
			"/assets/footers-s6bKD0P_.js",
			"/assets/tickets.functions-Bz9kwFmh.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-PUFAWdWo.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/input-Crf8CMen.js",
			"/assets/skeleton-CdveGQVH.js",
			"/assets/AdminAccount-CuIkCV63.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-C6xuaETu.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-j-2lRKUr.js",
			"/assets/textarea-COGPe4df.js",
			"/assets/support-bV4lHU5M.js",
			"/assets/support.functions-BLjza2eN.js",
			"/assets/HelpParts-D5P5Q1l6.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-JTRUsczg.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CdveGQVH.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
