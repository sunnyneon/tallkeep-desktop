import { t as APP_VERSION } from "./version-B-cxbfgT.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/backup.server-BFJEcRny.js
var BUCKET = "office-backups";
var TABLES = [
	"companies",
	"company_members",
	"user_company",
	"company_settings",
	"doc_counters",
	"doc_footers",
	"user_roles",
	"categories",
	"locations",
	"shelves",
	"price_lists",
	"payment_terms",
	"tax_rates",
	"products",
	"product_prices",
	"serial_numbers",
	"stock",
	"stock_moves",
	"stock_docs",
	"stock_doc_lines",
	"customers",
	"vendors",
	"vendor_items",
	"sales_orders",
	"sales_order_lines",
	"purchase_orders",
	"purchase_order_lines",
	"payments",
	"accounts",
	"bills",
	"bill_lines",
	"bill_payments",
	"bank_rules",
	"reconciliations",
	"bank_transactions",
	"cleared_items",
	"journal_entries",
	"journal_lines",
	"properties",
	"units",
	"tenants",
	"leases",
	"rent_charges",
	"rent_payments",
	"product_parts",
	"work_orders",
	"work_order_lines",
	"checks",
	"check_lines",
	"deposits",
	"deposit_lines",
	"transfers",
	"recurring",
	"receipts",
	"budgets",
	"holdings",
	"household_members",
	"money_reminders",
	"tax_wallets",
	"tax_records",
	"tax_methods"
];
/** Hand-typed entries; the rest of the books are made again from the documents. */
var HAND_ENTRIES = [
	"manual",
	"opening",
	"bank",
	"adjust",
	"history"
];
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
async function allRows(db, table) {
	const out = [];
	let sortById = true;
	for (let from = 0;; from += 1e3) {
		let q = db.from(table).select("*");
		if (sortById) q = q.order("id");
		let { data, error } = await q.range(from, from + 999);
		if (error && sortById && /column .*id.* does not exist/i.test(error.message)) {
			sortById = false;
			({data, error} = await db.from(table).select("*").range(from, from + 999));
		}
		if (error && /does not exist|could not find the table/i.test(error.message) && from === 0) return out;
		if (error) throw new Error(`${table}: ${error.message}`);
		out.push(...data ?? []);
		if (!data || data.length < 1e3) break;
	}
	return out;
}
async function gzip(text) {
	const stream = new Blob([text]).stream().pipeThrough(new CompressionStream("gzip"));
	return new Uint8Array(await new Response(stream).arrayBuffer());
}
/** "2026-10-21" in Chicago time. */
function today() {
	return new Intl.DateTimeFormat("en-CA", { timeZone: "America/Chicago" }).format(/* @__PURE__ */ new Date());
}
async function listBackupFiles() {
	const { data, error } = await (await admin()).storage.from(BUCKET).list("", {
		limit: 500,
		sortBy: {
			column: "name",
			order: "desc"
		}
	});
	if (error) throw new Error(error.message);
	return (data ?? []).filter((f) => f.name.endsWith(".json.gz")).map((f) => ({
		name: f.name,
		size: Number(f.metadata?.size ?? 0),
		created_at: f.created_at ?? null
	}));
}
/** A backup we made (office-2026-10-21[-before-restore-1405].json.gz) or one you uploaded. */
var NAME = /^(office-\d{4}-\d{2}-\d{2}(-[a-z0-9-]+)?|uploads\/upload-\d+)\.json\.gz$/;
async function makeBackup(by = "nightly", suffix = "") {
	const db = await admin();
	const tables = {};
	const counts = {};
	for (const t of TABLES) {
		tables[t] = await allRows(db, t);
		counts[t] = tables[t].length;
	}
	const { data: u } = await db.auth.admin.listUsers({
		page: 1,
		perPage: 500
	});
	const users = (u?.users ?? []).map((x) => ({
		id: x.id,
		email: x.email,
		name: x.user_metadata?.["name"] ?? null,
		created_at: x.created_at
	}));
	const file = await gzip(JSON.stringify({
		app: "SunRise Office",
		version: APP_VERSION,
		made_at: (/* @__PURE__ */ new Date()).toISOString(),
		made_by: by,
		counts,
		users,
		tables
	}));
	const name = `office-${today()}${suffix}.json.gz`;
	const up = await db.storage.from(BUCKET).upload(name, file, {
		contentType: "application/gzip",
		upsert: true
	});
	if (up.error) throw new Error(up.error.message);
	const now = Date.now();
	const old = (await listBackupFiles()).map((f) => ({
		f,
		day: f.name.slice(7, 17)
	})).filter(({ day }) => /^\d{4}-\d{2}-\d{2}$/.test(day)).filter(({ day }) => {
		const age = (now - (/* @__PURE__ */ new Date(`${day}T12:00:00Z`)).getTime()) / 864e5;
		if (age <= 31) return false;
		if (day.endsWith("-01") && age <= 366) return false;
		return true;
	}).map(({ f }) => f.name);
	if (old.length) await db.storage.from(BUCKET).remove(old);
	return {
		name,
		size: file.length,
		counts,
		removed: old.length
	};
}
async function readBackup(name) {
	if (!NAME.test(name)) throw new Error("Unknown backup.");
	const { data, error } = await (await admin()).storage.from(BUCKET).download(name);
	if (error || !data) throw new Error(error?.message ?? "Backup not found.");
	return data;
}
async function signedLink(name) {
	if (!NAME.test(name)) throw new Error("Unknown backup.");
	const { data, error } = await (await admin()).storage.from(BUCKET).createSignedUrl(name, 600, { download: name });
	if (error) throw new Error(error.message);
	return data.signedUrl;
}
/** What can be restored, as the parts people think in. Tables are in the order they're filled. */
var RESTORE_PARTS = {
	settings: {
		label: "Settings, footers, terms and taxes",
		tables: [
			"companies",
			"company_members",
			"company_settings",
			"doc_counters",
			"doc_footers",
			"payment_terms",
			"tax_rates",
			"price_lists"
		]
	},
	inventory: {
		label: "Products, categories, places and stock",
		tables: [
			"categories",
			"locations",
			"shelves",
			"products",
			"product_prices",
			"serial_numbers",
			"stock",
			"stock_moves",
			"stock_docs",
			"stock_doc_lines"
		]
	},
	customers: {
		label: "Customers",
		tables: ["customers"]
	},
	vendors: {
		label: "Vendors and what they sell",
		tables: ["vendors", "vendor_items"]
	},
	orders: {
		label: "Quotes, invoices, purchase orders and payments",
		tables: [
			"sales_orders",
			"sales_order_lines",
			"purchase_orders",
			"purchase_order_lines",
			"payments"
		]
	},
	books: {
		label: "Books: accounts, bills, banking and typed-in journal entries",
		tables: [
			"accounts",
			"bills",
			"bill_lines",
			"bill_payments",
			"bank_rules",
			"reconciliations",
			"bank_transactions",
			"cleared_items",
			"checks",
			"check_lines",
			"deposits",
			"deposit_lines",
			"transfers",
			"recurring",
			"receipts",
			"journal_entries"
		]
	},
	realEstate: {
		label: "Real estate: properties, tenants, leases, rent",
		tables: [
			"properties",
			"units",
			"tenants",
			"leases",
			"rent_charges",
			"rent_payments"
		]
	},
	workOrders: {
		label: "Work orders and what products are made from",
		tables: [
			"product_parts",
			"work_orders",
			"work_order_lines"
		]
	},
	personal: {
		label: "Budgets, investments, bills, household and crypto tax",
		tables: [
			"budgets",
			"holdings",
			"household_members",
			"money_reminders",
			"tax_wallets",
			"tax_records",
			"tax_methods"
		]
	}
};
/** Fill order for a full restore: things others point to come first. */
var ORDER = [
	"companies",
	"company_members",
	"household_members",
	"accounts",
	"payment_terms",
	"tax_rates",
	"price_lists",
	"doc_footers",
	"company_settings",
	"doc_counters",
	"categories",
	"locations",
	"shelves",
	"products",
	"product_prices",
	"serial_numbers",
	"stock",
	"stock_moves",
	"stock_docs",
	"stock_doc_lines",
	"customers",
	"vendors",
	"vendor_items",
	"checks",
	"sales_orders",
	"sales_order_lines",
	"purchase_orders",
	"purchase_order_lines",
	"payments",
	"bills",
	"bill_lines",
	"bill_payments",
	"bank_rules",
	"reconciliations",
	"bank_transactions",
	"cleared_items",
	"properties",
	"units",
	"tenants",
	"leases",
	"rent_charges",
	"rent_payments",
	"product_parts",
	"work_orders",
	"work_order_lines",
	"check_lines",
	"deposits",
	"deposit_lines",
	"transfers",
	"recurring",
	"receipts",
	"budgets",
	"holdings",
	"money_reminders",
	"tax_wallets",
	"tax_records",
	"tax_methods"
];
var KEYS = {
	tax_methods: ["company_id", "year"],
	product_prices: ["product_id", "price_list_id"],
	doc_counters: ["company_id", "kind"],
	company_members: ["company_id", "user_id"],
	user_company: ["user_id"],
	cleared_items: ["account_id", "item_key"]
};
var keyOf = (t) => KEYS[t] ?? ["id"];
var rowKey = (t, r) => keyOf(t).map((k) => String(r[k])).join("|");
async function loadBackup(name) {
	const blob = await readBackup(name);
	const text = await new Response(blob.stream().pipeThrough(new DecompressionStream("gzip"))).text();
	const b = JSON.parse(text);
	if (b.app !== "SunRise Office" || !b.tables) throw new Error("This isn't a SunRise Office backup.");
	return b;
}
/** Save a backup file you picked from your computer/Synology, so it can be restored. */
async function saveUploadedBackup(base64) {
	const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
	const name = `uploads/upload-${Date.now()}.json.gz`;
	const up = await (await admin()).storage.from(BUCKET).upload(name, bytes, {
		contentType: "application/gzip",
		upsert: true
	});
	if (up.error) throw new Error(up.error.message);
	await loadBackup(name);
	return name;
}
async function currentCount(db, table) {
	const { count, error } = await db.from(table).select("*", {
		count: "exact",
		head: true
	});
	if (error) throw new Error(`${table}: ${error.message}`);
	return count ?? 0;
}
/** What's in the backup next to what's in the app now, per part. */
async function backupSummary(name) {
	const b = await loadBackup(name);
	const db = await admin();
	const parts = await Promise.all(Object.keys(RESTORE_PARTS).map(async (key) => {
		const p = RESTORE_PARTS[key];
		const rows = await Promise.all(p.tables.map(async (t) => ({
			table: t,
			backup: (b.tables[t] ?? []).length,
			now: await currentCount(db, t)
		})));
		return {
			key,
			label: p.label,
			tables: rows
		};
	}));
	return {
		made_at: b.made_at ?? null,
		version: b.version ?? null,
		parts
	};
}
async function allKeys(db, table) {
	const cols = keyOf(table).join(",");
	const out = [];
	for (let from = 0;; from += 1e3) {
		const { data, error } = await db.from(table).select(cols).range(from, from + 999);
		if (error) throw new Error(`${table}: ${error.message}`);
		out.push(...data ?? []);
		if (!data || data.length < 1e3) break;
	}
	return out;
}
/** Links that can't be empty: a record whose link is gone is skipped instead. */
var REQUIRED_LINKS = {
	shelves: ["location_id"],
	product_prices: ["product_id", "price_list_id"],
	serial_numbers: ["product_id"],
	stock: ["product_id", "location_id"],
	stock_moves: ["product_id", "location_id"],
	stock_doc_lines: ["doc_id"],
	vendor_items: ["vendor_id", "product_id"],
	sales_order_lines: ["sales_order_id"],
	purchase_order_lines: ["purchase_order_id"],
	bill_lines: ["bill_id"],
	bill_payments: ["bill_id"],
	bank_rules: ["account_id"],
	reconciliations: ["account_id"],
	bank_transactions: ["account_id"],
	cleared_items: ["account_id"],
	units: ["property_id"],
	leases: ["unit_id", "tenant_id"],
	rent_charges: ["lease_id"],
	rent_payments: ["charge_id"],
	product_parts: ["product_id", "part_id"],
	work_orders: ["product_id", "location_id"],
	work_order_lines: ["work_order_id", "part_id"],
	checks: ["account_id"],
	check_lines: ["check_id", "account_id"],
	deposits: ["account_id"],
	deposit_lines: ["deposit_id"],
	transfers: ["from_account_id", "to_account_id"]
};
/**
* Add/update rows. If a row points to something that no longer exists (possible when only
* some parts are restored), the link is cleared — or the row skipped if it can't be empty.
*/
async function upsertAll(db, table, input) {
	let skipped = 0;
	for (let i = 0; i < input.length; i += 500) {
		let rows = input.slice(i, i + 500);
		for (let tries = 0; tries < 50 && rows.length; tries++) {
			const { error } = await db.from(table).upsert(rows, { onConflict: keyOf(table).join(",") });
			if (!error) break;
			const m = /Key \((\w+)\)=\(([^)]+)\) is not present/.exec(error.details ?? error.message);
			if (error.code !== "23503" || !m) throw new Error(`${table}: ${error.message}`);
			const [, col, val] = m;
			if ((REQUIRED_LINKS[table] ?? []).includes(col)) {
				const before = rows.length;
				rows = rows.filter((r) => String(r[col]) !== val);
				skipped += before - rows.length;
			} else rows = rows.map((r) => String(r[col]) === val ? {
				...r,
				[col]: null
			} : r);
		}
	}
	return skipped;
}
/** Remove every journal entry (their lines go with them), 500 at a time. */
async function clearJournal(db) {
	for (;;) {
		const { data, error } = await db.from("journal_entries").select("id").limit(500);
		if (error) throw new Error(`journal_entries: ${error.message}`);
		const ids = (data ?? []).map((r) => r.id);
		if (!ids.length) return;
		const del = await db.from("journal_entries").delete().in("id", ids);
		if (del.error) throw new Error(`journal_entries: ${del.error.message}`);
	}
}
/**
* Put the chosen parts back the way they were in the backup:
* records added since are removed, changed ones are set back, deleted ones come back.
* A backup of the current data is saved first ("before restore"), so this can be undone.
*/
async function restoreBackup(name, partKeys) {
	if (!partKeys.length) throw new Error("Choose what to restore.");
	const b = await loadBackup(name);
	const chosen = new Set(partKeys.flatMap((k) => [...RESTORE_PARTS[k].tables]));
	const tables = ORDER.filter((t) => chosen.has(t));
	const { data: closed } = await (await admin()).from("company_settings").select("books_closed_through").not("books_closed_through", "is", null).limit(1);
	if ((closed ?? []).length) throw new Error("The books are closed for a year. Reopen them in Accounting → Year-End, restore, then close them again.");
	const safety = await makeBackup("Before restore", `-before-restore-${new Intl.DateTimeFormat("en-GB", {
		timeZone: "America/Chicago",
		hour: "2-digit",
		minute: "2-digit"
	}).format(/* @__PURE__ */ new Date()).replace(":", "")}`);
	const db = await admin();
	const removed = {};
	const restored = {};
	const books = chosen.has("journal_entries");
	if (books) await clearJournal(db);
	for (const t of [...tables].reverse()) {
		if ([
			"doc_counters",
			"company_settings",
			"companies",
			"company_members"
		].includes(t)) continue;
		const keep = new Set((b.tables[t] ?? []).map((r) => rowKey(t, r)));
		const extra = (await allKeys(db, t)).filter((r) => !keep.has(rowKey(t, r)));
		removed[t] = extra.length;
		if (!extra.length) continue;
		const keys = keyOf(t);
		if (keys.length === 1) {
			const k = keys[0];
			const ids = extra.map((r) => r[k]);
			for (let i = 0; i < ids.length; i += 200) {
				const { error } = await db.from(t).delete().in(k, ids.slice(i, i + 200));
				if (error) throw new Error(`${t}: ${error.message}`);
			}
		} else for (const r of extra) {
			let q = db.from(t).delete();
			for (const k of keys) q = q.eq(k, r[k]);
			const { error } = await q;
			if (error) throw new Error(`${t}: ${error.message}`);
		}
	}
	const { data: firstRow } = await db.from("companies").select("id").order("created_at").limit(1).maybeSingle();
	const firstCo = firstRow?.id;
	const { data: orgRows } = await db.from("orgs").select("id,is_platform").order("created_at");
	const orgs = orgRows ?? [];
	const orgIds = new Set(orgs.map((o) => o.id));
	const homeOrg = (orgs.find((o) => o.is_platform) ?? orgs[0])?.id;
	const userIds = /* @__PURE__ */ new Set();
	const idByEmail = /* @__PURE__ */ new Map();
	for (let page = 1;; page++) {
		const { data } = await db.auth.admin.listUsers({
			page,
			perPage: 1e3
		});
		const list = data?.users ?? [];
		list.forEach((u) => {
			userIds.add(u.id);
			if (u.email) idByEmail.set(u.email.toLowerCase(), u.id);
		});
		if (list.length < 1e3) break;
	}
	const userMap = /* @__PURE__ */ new Map();
	const newLogins = [];
	if (chosen.has("companies")) {
		for (const p of b.users ?? []) {
			if (userIds.has(p.id)) {
				userMap.set(p.id, p.id);
				continue;
			}
			const email = (p.email ?? "").toLowerCase();
			if (!email) continue;
			const mine = idByEmail.get(email);
			if (mine) {
				userMap.set(p.id, mine);
				continue;
			}
			const { data: made, error } = await db.auth.admin.createUser({
				id: p.id,
				email,
				password: crypto.randomUUID() + crypto.randomUUID(),
				email_confirm: true,
				user_metadata: p.name ? { name: p.name } : {}
			});
			if (error || !made.user) continue;
			userMap.set(p.id, made.user.id);
			userIds.add(made.user.id);
			newLogins.push(made.user.id);
		}
		if (homeOrg && newLogins.length) await db.from("org_members").upsert(newLogins.map((u) => ({
			org_id: homeOrg,
			user_id: u
		})), {
			onConflict: "user_id",
			ignoreDuplicates: true
		});
		const fresh = new Set(newLogins);
		const roles = (b.tables["user_roles"] ?? []).flatMap((r) => {
			const user_id = userMap.get(String(r["user_id"]));
			if (!user_id || !fresh.has(user_id)) return [];
			return [{
				user_id,
				role: r["role"],
				...r["zones"] ? { zones: r["zones"] } : {}
			}];
		});
		if (roles.length) await db.from("user_roles").insert(roles);
	}
	for (const t of tables) {
		let rows = b.tables[t] ?? [];
		if (t === "companies" && homeOrg) rows = rows.map((r) => r["org_id"] && orgIds.has(String(r["org_id"])) ? r : {
			...r,
			org_id: homeOrg
		});
		if ([
			"user_roles",
			"company_members",
			"user_company"
		].includes(t)) rows = rows.map((r) => ({
			...r,
			user_id: userMap.get(String(r["user_id"])) ?? r["user_id"]
		})).filter((r) => userIds.has(String(r["user_id"])));
		if (firstCo && ![
			"companies",
			"company_members",
			"user_company"
		].includes(t)) rows = rows.map((r) => "company_id" in r ? r : {
			...r,
			company_id: firstCo
		});
		if (t === "doc_counters") {
			const { data } = await db.from("doc_counters").select("company_id,kind,next_number");
			const now = new Map((data ?? []).map((r) => [`${r.company_id}|${r.kind}`, r.next_number]));
			rows = rows.map((r) => ({
				...r,
				next_number: Math.max(Number(r["next_number"]), now.get(`${String(r["company_id"])}|${String(r["kind"])}`) ?? 0)
			}));
		}
		const skipped = await upsertAll(db, t, rows);
		restored[t] = rows.length - skipped;
	}
	const backupCos = new Set((b.tables["companies"] ?? []).map((r) => String(r["id"])));
	const everything = Object.keys(RESTORE_PARTS).every((k) => partKeys.includes(k));
	const fromElsewhere = (b.tables["companies"] ?? []).some((r) => r["org_id"] && !orgIds.has(String(r["org_id"])));
	if (everything && fromElsewhere && backupCos.size) {
		const { data: here } = await db.from("companies").select("id");
		const gone = (here ?? []).map((c) => c.id).filter((id) => !backupCos.has(id));
		if (gone.length) {
			const del = await db.from("companies").delete().in("id", gone);
			if (del.error) throw new Error(`companies: ${del.error.message}`);
			removed["companies"] = gone.length;
		}
		const first = String((b.tables["companies"] ?? [])[0]?.["id"]);
		const { data: picks } = await db.from("user_company").select("user_id");
		const picked = new Set((picks ?? []).map((r) => r.user_id));
		const missing = [...userIds].filter((u) => !picked.has(u));
		if (missing.length) await db.from("user_company").upsert(missing.map((u) => ({
			user_id: u,
			company_id: first
		})));
	}
	if (chosen.has("payments")) {
		await upsertAll(db, "sales_orders", b.tables["sales_orders"] ?? []);
		await upsertAll(db, "purchase_orders", b.tables["purchase_orders"] ?? []);
	}
	if (books) {
		const entries = (b.tables["journal_entries"] ?? []).filter((e) => HAND_ENTRIES.includes(String(e["source_type"])));
		const ids = new Set(entries.map((e) => String(e["id"])));
		const lines = (b.tables["journal_lines"] ?? []).filter((l) => ids.has(String(l["entry_id"])));
		await upsertAll(db, "journal_entries", entries);
		await upsertAll(db, "journal_lines", lines);
		restored["journal_entries"] = entries.length;
		const { data: cos } = await db.from("companies").select("id");
		for (const c of cos ?? []) {
			const { error } = await db.rpc("rebuild_books_company", { _co: c.id });
			if (error) throw new Error(`Rebuilding the books: ${error.message}`);
		}
	}
	return {
		from: b.made_at ?? null,
		safety: safety.name,
		removed,
		restored,
		newLogins: newLogins.length
	};
}
//#endregion
export { RESTORE_PARTS, backupSummary, listBackupFiles, makeBackup, readBackup, restoreBackup, saveUploadedBackup, signedLink };
