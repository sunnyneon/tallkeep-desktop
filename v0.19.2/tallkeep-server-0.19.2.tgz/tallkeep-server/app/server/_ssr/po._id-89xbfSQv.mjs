import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/po._id-89xbfSQv.js
var $$splitComponentImporter = () => import("./po._id-Di35h6JV.mjs");
var Route = createFileRoute("/_authenticated/po/$id")({
	validateSearch: (s) => ({
		...typeof s["vendor"] === "string" ? { vendor: s["vendor"] } : {},
		...typeof s["product"] === "string" ? { product: s["product"] } : {}
	}),
	head: () => ({ meta: [{ title: "Purchase Order · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
