import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy_.done-Zs6tWS7D.js
var $$splitComponentImporter = () => import("./buy_.done-8LZNjIoR.mjs");
/** After paying: the license key, and how to start. */
var Route = createFileRoute("/buy_/done")({
	ssr: false,
	validateSearch: (s) => ({ session: String(s["session"] ?? "") }),
	head: () => ({ meta: [{ title: "Thank you · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
