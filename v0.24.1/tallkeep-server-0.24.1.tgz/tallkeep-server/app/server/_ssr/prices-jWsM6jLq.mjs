import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { getPrices, savePrices } from "./admin.functions-DRbjINB8.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/prices-jWsM6jLq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SECTIONS = [
	{
		title: "Desktop (pay once)",
		rows: [
			{
				label: "Base plan, one time",
				path: ["desktop", "base"],
				unit: "$"
			},
			{
				label: "Companies included",
				path: ["desktop", "base_companies"],
				unit: "#"
			},
			{
				label: "Users included",
				path: ["desktop", "base_users"],
				unit: "#"
			},
			{
				label: "Each extra company, one time",
				path: ["desktop", "extra_company"],
				unit: "$"
			},
			{
				label: "Each extra user, one time",
				path: ["desktop", "extra_user"],
				unit: "$"
			},
			{
				label: "Phone access (Connect), per month",
				path: ["desktop", "connect_monthly"],
				unit: "$"
			},
			{
				label: "Updates after year one, per year",
				path: ["desktop", "updates_yearly"],
				unit: "$"
			}
		]
	},
	{
		title: "Plans and add-ons (pay once; empty = the built-in price)",
		rows: [
			{
				label: "Personal: regular price",
				path: [
					"editions",
					"personal",
					"price"
				],
				unit: "$"
			},
			{
				label: "Personal: founders price",
				path: [
					"editions",
					"personal",
					"founders"
				],
				unit: "$"
			},
			{
				label: "Real Estate: regular price",
				path: [
					"editions",
					"real_estate",
					"price"
				],
				unit: "$"
			},
			{
				label: "Real Estate: founders price",
				path: [
					"editions",
					"real_estate",
					"founders"
				],
				unit: "$"
			},
			{
				label: "Service Business: regular price",
				path: [
					"editions",
					"service",
					"price"
				],
				unit: "$"
			},
			{
				label: "Service Business: founders price",
				path: [
					"editions",
					"service",
					"founders"
				],
				unit: "$"
			},
			{
				label: "Full Business: regular price",
				path: [
					"editions",
					"full",
					"price"
				],
				unit: "$"
			},
			{
				label: "Full Business: founders price",
				path: [
					"editions",
					"full",
					"founders"
				],
				unit: "$"
			},
			{
				label: "Crypto Tax add-on: regular",
				path: [
					"addons",
					"crypto_tax",
					"price"
				],
				unit: "$"
			},
			{
				label: "Crypto Tax add-on: founders",
				path: [
					"addons",
					"crypto_tax",
					"founders"
				],
				unit: "$"
			}
		]
	},
	{
		title: "Online plans, per month (app.tallkeep.com; empty = the built-in price)",
		rows: [
			{
				label: "Personal, per month",
				path: [
					"editions",
					"personal",
					"month"
				],
				unit: "$"
			},
			{
				label: "Real Estate, per month",
				path: [
					"editions",
					"real_estate",
					"month"
				],
				unit: "$"
			},
			{
				label: "Service Business, per month",
				path: [
					"editions",
					"service",
					"month"
				],
				unit: "$"
			},
			{
				label: "Full Business, per month",
				path: [
					"editions",
					"full",
					"month"
				],
				unit: "$"
			},
			{
				label: "Crypto Tax add-on, per month",
				path: [
					"addons",
					"crypto_tax",
					"month"
				],
				unit: "$"
			},
			{
				label: "Each extra person, per month",
				path: ["online_extra", "user"],
				unit: "$"
			},
			{
				label: "Each extra company, per month",
				path: ["online_extra", "company"],
				unit: "$"
			},
			{
				label: "Personal: AI pages a month",
				path: [
					"editions",
					"personal",
					"aiPages"
				],
				unit: "#"
			},
			{
				label: "Real Estate: AI pages a month",
				path: [
					"editions",
					"real_estate",
					"aiPages"
				],
				unit: "#"
			},
			{
				label: "Service Business: AI pages a month",
				path: [
					"editions",
					"service",
					"aiPages"
				],
				unit: "#"
			},
			{
				label: "Full Business: AI pages a month",
				path: [
					"editions",
					"full",
					"aiPages"
				],
				unit: "#"
			}
		]
	},
	{
		title: "Extras and offers",
		rows: [
			{
				label: "Free trial length (days)",
				path: ["trial_days"],
				unit: "#"
			},
			{
				label: "AI pack price",
				path: ["ai_pack", "price"],
				unit: "$"
			},
			{
				label: "AI pages in a pack",
				path: ["ai_pack", "pages"],
				unit: "#"
			},
			{
				label: "Founders: desktop price",
				path: ["founders", "desktop"],
				unit: "$"
			},
			{
				label: "Founders: cloud discount",
				path: ["founders", "cloud_discount_pct"],
				unit: "%"
			},
			{
				label: "Founders: first how many customers",
				path: ["founders", "limit"],
				unit: "#"
			},
			{
				label: "Pay now: Tallkeep's share of each card payment",
				path: ["payments", "app_fee_pct"],
				unit: "%"
			}
		]
	}
];
var get = (o, path) => path.reduce((v, k) => v?.[k], o);
function set(o, path, value) {
	const copy = structuredClone(o);
	let cur = copy;
	path.slice(0, -1).forEach((k) => {
		cur[k] = { ...cur[k] ?? {} };
		cur = cur[k];
	});
	cur[path.at(-1)] = value;
	return copy;
}
function PricesPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["admin-prices"],
		queryFn: () => getPrices()
	});
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (q.data?.prices) setDraft(q.data.prices);
	}, [q.data]);
	async function save() {
		if (!draft) return;
		setBusy(true);
		try {
			await savePrices({ data: draft });
			toast.success("Prices saved.");
			qc.invalidateQueries({ queryKey: ["admin-prices"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Prices",
			text: "One price list for everything. tallkeep.com/pricing shows these within a few minutes of saving, and new free trials use the trial length.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				disabled: !draft || busy,
				children: busy ? "Saving…" : "Save prices"
			})
		}),
		q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) : !draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-muted-foreground",
			children: "The price list isn't set up yet (database step 29)."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-6 lg:grid-cols-3",
			children: SECTIONS.map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 font-display text-lg font-semibold",
					children: sec.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: sec.rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1",
							children: [
								r.unit === "$" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "$"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "decimal",
									className: "w-24 text-right",
									value: String(get(draft, r.path) ?? ""),
									onChange: (e) => {
										const n = Number(e.target.value);
										if (e.target.value === "" || Number.isFinite(n)) setDraft(set(draft, r.path, e.target.value === "" ? 0 : n));
									}
								}),
								r.unit === "%" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "%"
								})
							]
						})]
					}, r.path.join(".")))
				})]
			}, sec.title))
		}),
		q.data?.updated_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Last saved ",
				fmtDateTime(q.data.updated_at),
				"."
			]
		})
	] });
}
//#endregion
export { PricesPage as component };
