-- 086: Fixes from the sixth test round (20 November 2026).
--
-- Deposits (R6-01): money taken on a quote or an order that isn't invoiced yet is a Customer
-- Deposit until it's invoiced (step 085). Companies made after step 085 (and the sample company
-- when it's rebuilt) got a "2300 Customer Deposits" account without the marker that says so, so
-- their deposits went to Accounts Receivable. Mark those accounts, and every new one from now on.
update public.accounts a set key = 'customer_deposits'
 where a.number = '2300' and lower(a.name) = 'customer deposits' and a.key is null
   and not exists (select 1 from public.accounts b where b.company_id = a.company_id and b.key = 'customer_deposits');

create or replace function public.mark_customer_deposits()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.key is null and new.number = '2300' and lower(new.name) = 'customer deposits'
     and not exists (select 1 from public.accounts b
                      where b.company_id = new.company_id and b.key = 'customer_deposits') then
    new.key := 'customer_deposits';
  end if;
  return new;
end $$;
drop trigger if exists accounts_mark_customer_deposits on public.accounts;
create trigger accounts_mark_customer_deposits before insert on public.accounts
  for each row execute function public.mark_customer_deposits();

-- Deposits already written to Accounts Receivable on documents that aren't invoiced are written
-- again now, on Customer Deposits.
do $$
declare r record;
begin
  for r in select p.id from public.payments p join public.sales_orders o on o.id = p.sales_order_id
            where o.status not in ('invoiced', 'paid', 'completed', 'cancelled')
              and o.number not like 'RMA-%' loop
    perform public.post_payment(r.id);
  end loop;
end $$;

-- Stock value (R6-03): part of an invoice fulfilled took the stock off the shelf, but the cost of
-- it stayed in Inventory in the books until everything went out. So the Balance Sheet showed more
-- inventory than is on hand. Now the cost of what has gone out is posted each time, and when part
-- is put back it comes off again. Press "Rebuild the books" once to correct earlier invoices.
create or replace function public.post_invoice(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare o record; cost numeric; d date; went date;
begin
  delete from public.journal_entries where source_type in ('invoice', 'invoice_cogs') and source_id = _id;
  select * into o from public.sales_orders where id = _id;
  if o.id is null then return; end if;
  if o.status not in ('invoiced','paid','completed') or o.number like 'RMA-%' then return; end if;
  d := coalesce(o.invoice_date, o.order_date)::date;
  if not public.books_open(o.company_id, d) then return; end if;
  perform public.write_entry(o.company_id, d, 'invoice', o.id, o.number, 'Invoice ' || o.number,
    jsonb_build_array(
      jsonb_build_object('account', public.acct(o.company_id, 'ar'), 'debit', o.total, 'customer', o.customer_id),
      jsonb_build_object('account', public.acct(o.company_id, 'sales'), 'credit', o.total - o.tax, 'customer', o.customer_id),
      jsonb_build_object('account', public.acct(o.company_id, 'sales_tax'), 'credit', o.tax)));
  if o.stock_taken_at is not null then
    -- Everything went out.
    select coalesce(sum(l.qty * p.cost), 0) into cost
      from public.sales_order_lines l join public.products p on p.id = l.product_id
     where l.sales_order_id = o.id and p.item_type = 'stocked';
    went := o.stock_taken_at::date;
  else
    -- Only part went out: the cost of what did.
    select coalesce(sum(least(l.qty_fulfilled, l.qty) * p.cost), 0) into cost
      from public.sales_order_lines l join public.products p on p.id = l.product_id
     where l.sales_order_id = o.id and p.item_type = 'stocked' and l.qty_fulfilled > 0;
    select max(b.created_at)::date into went from public.stock_batches b
     where b.doc_id = o.id and b.doc_type = 'sales_order' and b.undone_at is null;
  end if;
  if cost <> 0 then
    perform public.write_entry(o.company_id, greatest(d, coalesce(went, d)), 'invoice_cogs', o.id, o.number,
      'Cost of goods, invoice ' || o.number,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(o.company_id, 'cogs'), 'debit', cost),
        jsonb_build_object('account', public.acct(o.company_id, 'inventory'), 'credit', cost)));
  end if;
end $$;

-- Fulfilling or putting back part of an invoice writes its cost again.
create or replace function public.repost_after_fulfil()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.qty_fulfilled is distinct from old.qty_fulfilled then
    perform public.post_invoice(new.sales_order_id);
  end if;
  return null;
end $$;
drop trigger if exists sales_lines_repost_after_fulfil on public.sales_order_lines;
create trigger sales_lines_repost_after_fulfil after update of qty_fulfilled on public.sales_order_lines
  for each row execute function public.repost_after_fulfil();

-- Invoices partly fulfilled now are written again.
do $$
declare r record;
begin
  for r in select distinct o.id from public.sales_orders o join public.sales_order_lines l on l.sales_order_id = o.id
            where o.stock_taken_at is null and l.qty_fulfilled > 0
              and o.status in ('invoiced', 'paid', 'completed') loop
    perform public.post_invoice(r.id);
  end loop;
end $$;

notify pgrst, 'reload schema';
