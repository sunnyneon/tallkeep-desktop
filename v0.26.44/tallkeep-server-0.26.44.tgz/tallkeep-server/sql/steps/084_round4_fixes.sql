-- 084: Fixes from the fourth test round (19 November 2026).
--
-- 1) A sales tax rate is a percent between 0 and 50 (7.77 means 7.77%). Typing 7.77 once saved
--    777%; the page keeps the decimal now, and the database refuses a rate like that too.
create or replace function public.tax_rate_ok()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.tax_rate is not null and (new.tax_rate < 0 or new.tax_rate > 50)
     and (tg_op = 'INSERT' or new.tax_rate is distinct from old.tax_rate) then
    raise exception 'The sales tax should be a percent between 0 and 50, like 7.75. % %% looks wrong.',
      new.tax_rate using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists sales_tax_rate_ok on public.sales_orders;
create trigger sales_tax_rate_ok before insert or update of tax_rate on public.sales_orders
  for each row execute function public.tax_rate_ok();
drop trigger if exists po_tax_rate_ok on public.purchase_orders;
create trigger po_tax_rate_ok before insert or update of tax_rate on public.purchase_orders
  for each row execute function public.tax_rate_ok();

-- 2) A payment can't be more than what's still owed on the invoice (D15): the extra would leave
--    the invoice below zero and the Balance Sheet and Who owes us disagreeing. Payments brought in
--    from QuickBooks, and ones the website records for card payments, are left as they are.
create or replace function public.payment_not_over()
returns trigger language plpgsql set search_path = public as $$
declare o record; paid numeric;
begin
  if new.sales_order_id is null or new.amount <= 0 or auth.uid() is null
     or coalesce(new.method, '') = 'QuickBooks' or coalesce(new.remarks, '') ilike 'From QuickBooks%' then
    return new;
  end if;
  if tg_op = 'UPDATE' and new.amount <= old.amount and new.sales_order_id = old.sales_order_id then
    return new;
  end if;
  select id, number, total into o from public.sales_orders where id = new.sales_order_id;
  if o.id is null then return new; end if;
  select coalesce(sum(p.amount), 0) into paid from public.payments p
   where p.sales_order_id = o.id and p.id is distinct from new.id;
  if paid + new.amount > coalesce(o.total, 0) + 0.005 then
    raise exception 'That''s more than the % still owed on %. Record % or less.',
      to_char(greatest(coalesce(o.total, 0) - paid, 0), 'FM$999,999,990.00'), o.number,
      to_char(greatest(coalesce(o.total, 0) - paid, 0), 'FM$999,999,990.00')
      using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists payment_not_over on public.payments;
create trigger payment_not_over before insert or update of amount, sales_order_id on public.payments
  for each row execute function public.payment_not_over();

notify pgrst, 'reload schema';
