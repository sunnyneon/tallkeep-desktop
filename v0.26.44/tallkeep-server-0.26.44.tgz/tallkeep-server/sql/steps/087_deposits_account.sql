-- 087: Deposits always land in Customer Deposits (Round 6 retest, 20 November 2026).
--
-- Steps 085 and 086 found the Customer Deposits account only when it was "2300 Customer Deposits"
-- exactly. A company whose deposits account has another number or name (brought in from
-- QuickBooks, renamed, or added by hand) had no match, so a deposit on an order that wasn't
-- invoiced yet still went to Accounts Receivable. Now Tallkeep looks for it by name too, and
-- makes "2300 Customer Deposits" when a company has none.

-- Needs step 36's card-fee column and card accounts. A database that skipped step 36 gets them
-- here first (nothing changes where they already exist).
alter table public.payments add column if not exists fee numeric(14,2) not null default 0;
create or replace function public.seed_card_accounts(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, x.key
    from (values
      ('1060', 'Stripe', 'asset', 'bank', 'stripe'),
      ('6170', 'Card Processing Fees', 'expense', 'expense', 'card_fees')
    ) as x(number, name, type, kind, key)
   where not exists (select 1 from public.accounts a where a.company_id = _co
                      and ((x.key is not null and a.key = x.key) or a.number = x.number));
end $$;
revoke all on function public.seed_card_accounts(uuid) from public, anon;
grant execute on function public.seed_card_accounts(uuid) to authenticated, service_role;

-- The company's Customer Deposits account: marked, or found by name, or made now.
create or replace function public.deposits_account(_co uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare a uuid; num text;
begin
  select id into a from public.accounts where company_id = _co and key = 'customer_deposits';
  if a is not null then return a; end if;
  select id into a from public.accounts
   where company_id = _co and key is null and type = 'liability'
     and lower(name) ~ 'customer\s*deposit|deposits?\s*(from|received from)\s*customers?|unearned\s*revenue'
   order by (number = '2300') desc, (lower(name) ~ 'customer\s*deposit') desc, number nulls last
   limit 1;
  if a is null then
    num := case when exists (select 1 from public.accounts where company_id = _co and number = '2300')
                then null else '2300' end;
    insert into public.accounts (company_id, number, name, type, kind, key)
    values (_co, num, 'Customer Deposits', 'liability', 'other_liability', 'customer_deposits')
    returning id into a;
    return a;
  end if;
  update public.accounts set key = 'customer_deposits' where id = a;
  return a;
end $$;

create or replace function public.post_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; co uuid; bank uuid; who uuid; ref text; st text; credit_to uuid; is_deposit boolean;
begin
  delete from public.journal_entries where source_type in ('payment', 'po_payment') and source_id = _id;
  select * into p from public.payments where id = _id;
  if p.id is null or p.check_id is not null then return; end if;
  if p.sales_order_id is not null then
    select company_id, customer_id, number, status into co, who, ref, st
      from public.sales_orders where id = p.sales_order_id;
  else
    select company_id, vendor_id, number into co, who, ref from public.purchase_orders where id = p.purchase_order_id;
  end if;
  if co is null or not public.books_open(co, p.paid_on::date) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = co),
    public.acct(co, 'bank'));
  if p.sales_order_id is not null then
    -- Not invoiced yet (a quote or an open order): it's a deposit, owed back as goods or money.
    is_deposit := st not in ('invoiced', 'paid', 'completed') and ref not like 'RMA-%';
    credit_to := case when is_deposit then public.deposits_account(co) else public.acct(co, 'ar') end;
    if coalesce(p.fee, 0) <> 0 then perform public.seed_card_accounts(co); end if;
    perform public.write_entry(co, p.paid_on::date, 'payment', p.id, ref,
      case when is_deposit then 'Deposit on ' else 'Payment for ' end || ref,
      jsonb_build_array(
        jsonb_build_object('account', bank, 'debit', p.amount - coalesce(p.fee, 0), 'customer', who),
        jsonb_build_object('account', public.acct(co, 'card_fees'), 'debit', coalesce(p.fee, 0), 'customer', who,
                           'memo', 'Card fee'),
        jsonb_build_object('account', credit_to, 'credit', p.amount, 'customer', who)));
  else
    perform public.write_entry(co, p.paid_on::date, 'po_payment', p.id, ref, 'Paid ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'ap'), 'debit', p.amount, 'vendor', who),
        jsonb_build_object('account', bank, 'credit', p.amount, 'vendor', who)));
  end if;
end $$;

-- Mark every company's deposits account now (by name when it isn't 2300), then write again the
-- deposits on documents that aren't invoiced, so they move off Accounts Receivable.
do $$
declare r record;
begin
  for r in select distinct o.company_id from public.payments p join public.sales_orders o on o.id = p.sales_order_id
            where o.status not in ('invoiced', 'paid', 'completed') and o.number not like 'RMA-%' loop
    perform public.deposits_account(r.company_id);
  end loop;
  for r in select p.id from public.payments p join public.sales_orders o on o.id = p.sales_order_id
            where o.status not in ('invoiced', 'paid', 'completed') and o.number not like 'RMA-%' loop
    perform public.post_payment(r.id);
  end loop;
end $$;

-- Whose money is in Customer Deposits: deposits on quotes and orders not invoiced yet.
create or replace view public.deposits_held with (security_invoker = true) as
select o.company_id, o.id as sales_order_id, o.number, o.status, o.customer_id, o.customer_name,
       o.total, sum(p.amount) as held, max(p.paid_on) as last_paid_on
  from public.sales_orders o join public.payments p on p.sales_order_id = o.id
 where o.status not in ('invoiced', 'paid', 'completed') and o.number not like 'RMA-%'
 group by o.company_id, o.id, o.number, o.status, o.customer_id, o.customer_name, o.total
having sum(p.amount) <> 0;
grant select on public.deposits_held to authenticated;

notify pgrst, 'reload schema';
