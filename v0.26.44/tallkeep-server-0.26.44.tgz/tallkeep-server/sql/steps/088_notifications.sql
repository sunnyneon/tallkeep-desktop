-- 088: Notifications — what needs your attention, in the app and by email (23 November 2026).
--
-- * notices_for(company, day): the list for one company, worked out from the books each time:
--   invoices past due, bills due within a week, bills & subscriptions (personal) due within a
--   week, loan payments due within a week, bank or cash accounts below zero, bank lines waiting
--   to be recorded, products at or below their reorder point, rent that's late, and budgets
--   gone over this month.
-- * notice_hidden: items someone marked "Done" (gone; a payment due comes back on its next date)
--   or "Remind me in a week". Each person has their own.
-- * notices_all(): the list for every company I can use, without the ones I hid. The bell in the
--   app reads it.
-- * notice_settings: each person's email choice: a weekly list (on the days picked) and a monthly
--   summary on the 1st. Off until the person turns it on.
-- * month_summary(company, month): money in, money out, profit, the biggest costs, cash, and
--   what customers and vendors owe, for the monthly email.

create table if not exists public.notice_hidden (
  user_id uuid not null default auth.uid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  key text not null,
  until date,                       -- empty: hidden for good ("Done")
  created_at timestamptz not null default now(),
  primary key (user_id, company_id, key)
);
alter table public.notice_hidden enable row level security;
drop policy if exists notice_hidden_own on public.notice_hidden;
create policy notice_hidden_own on public.notice_hidden for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid() and public.can_use_company(auth.uid(), company_id));
grant select, insert, update, delete on public.notice_hidden to authenticated;

create table if not exists public.notice_settings (
  user_id uuid primary key default auth.uid(),
  email text,                                   -- empty: the address you sign in with
  weekly boolean not null default false,
  days text[] not null default '{mon}',         -- mon..sun
  monthly boolean not null default false,
  hour int not null default 8 check (hour between 0 and 23),
  skip_companies uuid[] not null default '{}',  -- companies left out of the emails
  app_url text,                                 -- for the "Open Tallkeep" button in the email
  last_weekly date,
  last_monthly text,                            -- YYYY-MM
  updated_at timestamptz not null default now()
);
alter table public.notice_settings enable row level security;
drop policy if exists notice_settings_own on public.notice_settings;
create policy notice_settings_own on public.notice_settings for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update, delete on public.notice_settings to authenticated;

-- One company's list. Called by the app (for companies you can use) and the daily email job.
create or replace function public.notices_for(_co uuid, _today date default current_date)
returns table (kind text, key text, title text, detail text, amount numeric, due date, urgent boolean, link text)
language plpgsql stable security definer set search_path = public as $$
declare has_rent boolean := to_regclass('public.rent_charges') is not null;
        has_rem boolean := to_regclass('public.money_reminders') is not null;
        has_loans boolean := to_regclass('public.loans') is not null;
        has_budgets boolean := to_regclass('public.budgets') is not null;
begin
  if auth.uid() is not null and not public.can_use_company(auth.uid(), _co) then return; end if;

  -- Invoices past due (all unpaid invoices, also ones from before the books start).
  return query
  select 'overdue_invoice'::text, 'inv:' || o.id::text,
         o.number || ' · ' || coalesce(o.customer_name, 'No customer'),
         (_today - o.due_date::date) || ' day' || case when _today - o.due_date::date = 1 then '' else 's' end || ' late',
         o.balance, o.due_date::date, (_today - o.due_date::date) >= 30, '/sales/' || o.id::text
    from public.sales_orders o
   where o.company_id = _co and o.status in ('invoiced', 'completed', 'paid') and o.balance > 0.005
     and o.due_date is not null and o.due_date::date < _today and o.number not like 'RMA-%';

  -- Bills to pay within a week (or late).
  return query
  select 'bill_due'::text, 'bill:' || b.id::text || ':' || b.due_date::text,
         coalesce(b.vendor_name, 'Bill') || coalesce(' · ' || nullif(b.ref, ''), ''),
         case when b.due_date < _today then (_today - b.due_date) || ' days late'
              when b.due_date = _today then 'Due today' else 'Due ' || to_char(b.due_date, 'Mon FMDD') end,
         b.balance, b.due_date, b.due_date <= _today + 2, '/bills/' || b.id::text
    from public.bills b
   where b.company_id = _co and coalesce(b.status, '') not in ('void', 'paid', 'draft') and b.balance > 0.005
     and b.due_date is not null and b.due_date <= _today + 7;

  -- Bills and subscriptions you track (personal books).
  if has_rem then
    return query execute $q$
      select 'reminder'::text, 'rem:' || r.id::text || ':' || r.next_date::text,
             r.name || case when r.kind = 'subscription' then ' (subscription)' else '' end,
             case when r.next_date < $2 then 'Was due ' || to_char(r.next_date, 'Mon FMDD')
                  when r.next_date = $2 then 'Due today' else 'Due ' || to_char(r.next_date, 'Mon FMDD') end
               || case when r.autopay then ' · autopay' else '' end,
             r.amount, r.next_date, r.next_date <= $2 + 2 and not r.autopay, '/subscriptions'
        from public.money_reminders r
       where r.company_id = $1 and r.status = 'active' and r.next_date <= $2 + 7 and r.next_date >= $2 - 30
    $q$ using _co, _today;
  end if;

  -- Loan payments due within a week.
  if has_loans then
    return query execute $q$
      select 'loan_due'::text, 'loan:' || l.id::text || ':' || l.due_date::text,
             coalesce(l.lender, 'Loan') || ' payment',
             case when l.due_date < $2 then 'Was due ' else 'Due ' end || to_char(l.due_date, 'Mon FMDD'),
             l.payment, l.due_date::date, l.due_date::date <= $2 + 2, '/loans'
        from public.loans l
       where l.company_id = $1 and l.due_date is not null and l.due_date::date <= $2 + 7
         and l.due_date::date >= $2 - 30 and coalesce(l.balance, 1) > 0
    $q$ using _co, _today;
  end if;

  -- Bank and cash accounts below zero in the books.
  return query
  select 'negative_cash'::text, 'cash:' || a.id::text || ':' || round(s.bal)::text,
         a.name || ' is below zero', 'In the books today', s.bal, null::date, true, '/banking'
    from public.accounts a
    join lateral (select coalesce(sum(l.debit - l.credit), 0) as bal from public.journal_lines l
                   join public.journal_entries e on e.id = l.entry_id
                  where l.account_id = a.id and e.entry_date <= _today) s on true
   where a.company_id = _co and a.kind = 'bank' and s.bal < -0.005;

  -- Bank lines waiting to be recorded.
  return query
  select 'bank_lines'::text, 'banklines:' || count(*)::text,
         count(*) || ' bank line' || case when count(*) = 1 then '' else 's' end || ' waiting to be recorded',
         'Since ' || to_char(min(t.txn_date), 'Mon FMDD'), null::numeric, min(t.txn_date)::date,
         min(t.txn_date)::date < _today - 30, '/banking'
    from public.bank_transactions t
   where t.company_id = _co and t.status = 'new'
  having count(*) > 0;

  -- Products at or below their reorder point.
  return query
  select 'low_stock'::text, 'stock:' || p.id::text || ':' || coalesce(q.qty, 0)::text,
         p.name || ' is running low',
         trim(trailing '.' from trim(trailing '0' from coalesce(q.qty, 0)::numeric(14,2)::text)) || ' on hand · reorder at '
           || trim(trailing '.' from trim(trailing '0' from p.reorder_point::numeric(14,2)::text)),
         null::numeric, null::date, coalesce(q.qty, 0) <= 0, '/products/' || p.id::text
    from public.products p
    left join lateral (select sum(s.qty) as qty from public.stock s where s.product_id = p.id) q on true
   where p.company_id = _co and coalesce(p.is_active, true) and p.item_type = 'stocked'
     and coalesce(p.reorder_point, 0) > 0 and coalesce(q.qty, 0) <= p.reorder_point;

  -- Rent that's late.
  if has_rent then
    return query execute $q$
      select 'rent_late'::text, 'rent:' || c.id::text,
             coalesce(nullif(c.description, ''), 'Rent') || coalesce(' · ' || t.name, ''),
             ($2 - c.due_date::date) || ' days late', c.balance, c.due_date::date,
             ($2 - c.due_date::date) >= 15, '/rent-roll'
        from public.rent_charges c
        left join public.leases ls on ls.id = c.lease_id
        left join public.tenants t on t.id = ls.tenant_id
       where c.company_id = $1 and c.balance > 0.005 and c.due_date::date < $2
         and coalesce(c.status, '') not in ('void', 'paid')
    $q$ using _co, _today;
  end if;

  -- Budgets gone over this month.
  if has_budgets then
    return query execute $q$
      select 'over_budget'::text, 'budget:' || b.account_id::text || ':' || to_char($2, 'YYYY-MM'),
             a.name || ' is over budget',
             'Spent ' || to_char(s.spent, 'FM$999,999,990.00') || ' of ' || to_char(b.amount, 'FM$999,999,990.00') || ' this month',
             s.spent - b.amount, null::date, s.spent > b.amount * 1.2, '/budget'
        from public.budgets b
        join public.accounts a on a.id = b.account_id
        join lateral (select coalesce(sum(l.debit - l.credit), 0) as spent from public.journal_lines l
                       join public.journal_entries e on e.id = l.entry_id
                      where l.account_id = b.account_id
                        and e.entry_date >= date_trunc('month', $2)::date and e.entry_date <= $2) s on true
       where b.company_id = $1 and b.amount > 0 and s.spent > b.amount
    $q$ using _co, _today;
  end if;
end $$;
revoke all on function public.notices_for(uuid, date) from public, anon;
grant execute on function public.notices_for(uuid, date) to authenticated, service_role;

-- Everything for one person: every company they can use, less what they hid.
drop function if exists public.notices_of(uuid, date);
create or replace function public.notices_of(_uid uuid, _today date default current_date, _sample uuid default null)
returns table (company_id uuid, company_name text, kind text, key text, title text, detail text,
               amount numeric, due date, urgent boolean, link text)
language sql stable security definer set search_path = public as $$
  select c.id, c.name, n.kind, n.key, n.title, n.detail, n.amount, n.due, n.urgent, n.link
    from public.companies c
    cross join lateral public.notices_for(c.id, _today) n
   -- The sample company only while you're working in it (never in the emails).
   where public.can_use_company(_uid, c.id) and (not coalesce(c.is_sample, false) or c.id = _sample)
     and not exists (select 1 from public.notice_hidden h
                      where h.user_id = _uid and h.company_id = c.id and h.key = n.key
                        and (h.until is null or h.until >= _today))
   order by c.created_at, c.name, n.urgent desc, n.due nulls last;
$$;
revoke all on function public.notices_of(uuid, date, uuid) from public, anon, authenticated;
grant execute on function public.notices_of(uuid, date, uuid) to service_role;

create or replace function public.notices_all(_today date default current_date)
returns table (company_id uuid, company_name text, kind text, key text, title text, detail text,
               amount numeric, due date, urgent boolean, link text)
language sql stable security definer set search_path = public as $$
  select * from public.notices_of(auth.uid(), _today, public.active_company()) where auth.uid() is not null;
$$;
revoke all on function public.notices_all(date) from public, anon;
grant execute on function public.notices_all(date) to authenticated;

-- The companies one person can use (for the monthly email; the sample company left out).
create or replace function public.companies_of(_uid uuid)
returns table (id uuid, name text)
language sql stable security definer set search_path = public as $$
  select c.id, c.name from public.companies c
   where public.can_use_company(_uid, c.id) and not coalesce(c.is_sample, false)
   order by c.created_at, c.name;
$$;
revoke all on function public.companies_of(uuid) from public, anon, authenticated;
grant execute on function public.companies_of(uuid) to service_role;

-- One month for one company: for the monthly email.
create or replace function public.month_summary(_co uuid, _month date)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare a date := date_trunc('month', _month)::date; b date := (date_trunc('month', _month) + interval '1 month')::date;
        r jsonb;
begin
  if auth.uid() is not null and not public.can_use_company(auth.uid(), _co) then return null; end if;
  with lines as (
    select ac.type, ac.kind, ac.name, l.debit, l.credit, e.entry_date
      from public.journal_lines l
      join public.journal_entries e on e.id = l.entry_id
      join public.accounts ac on ac.id = l.account_id
     where l.company_id = _co
  ), month as (select * from lines where entry_date >= a and entry_date < b)
  select jsonb_build_object(
    'income', coalesce((select sum(credit - debit) from month where type = 'income'), 0),
    'expenses', coalesce((select sum(debit - credit) from month where type = 'expense'), 0),
    'top', coalesce((select jsonb_agg(jsonb_build_object('name', name, 'amount', amt) order by amt desc)
                       from (select name, sum(debit - credit) as amt from month where type = 'expense'
                              group by name having sum(debit - credit) > 0 order by 2 desc limit 5) t), '[]'::jsonb),
    'cash', coalesce((select sum(debit - credit) from lines where kind = 'bank' and entry_date < b), 0),
    'owed_to_us', coalesce((select sum(debit - credit) from lines where kind = 'ar' and entry_date < b), 0),
    'we_owe', coalesce((select sum(credit - debit) from lines where kind = 'ap' and entry_date < b), 0)
  ) into r;
  return r;
end $$;
revoke all on function public.month_summary(uuid, date) from public, anon;
grant execute on function public.month_summary(uuid, date) to authenticated, service_role;

notify pgrst, 'reload schema';
