-- 082: Fixes from the 19 November 2026 test rounds.
--
-- 1) A new business company starts its books the day it's made (it used to have no start day, so
--    every report stayed at $0 while the Overview showed sales). Households already start in 2000.
--    Companies made before today keep what they have (Tallkeep shows a banner when there's none).
-- 2) Opening stock goes to Opening Balance Equity, not to Inventory Adjustments: a product's first
--    stock count (before anything was bought, sold or moved for it, on the day it first got stock)
--    is the stock you started with, not a gain. Later count changes still go to 5100 Inventory
--    Adjustments (under cost of goods): finding stock lowers cost, losing stock raises it.
--    Books already written keep their entries until "Rebuild the books" is pressed.

create or replace function public.default_books_start()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.books_start_date is null and coalesce(new.business_type, 'products') <> 'personal' then
    new.books_start_date := current_date;
  end if;
  return new;
end $$;
drop trigger if exists company_settings_books_start on public.company_settings;
create trigger company_settings_books_start before insert on public.company_settings
  for each row execute function public.default_books_start();

create or replace function public.post_stock_move(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m record; co uuid; value numeric; other uuid; first_day date; opening boolean;
begin
  delete from public.journal_entries where source_type = 'stock' and source_id = _id;
  select sm.*, p.cost, p.company_id as co, p.name as pname into m
    from public.stock_moves sm join public.products p on p.id = sm.product_id where sm.id = _id;
  if m.id is null or m.reason not in ('adjust', 'count', 'import') then return; end if;
  co := m.co;
  if not public.books_open(co, m.created_at::date) then return; end if;
  value := round(m.qty_change * m.cost, 2);
  -- Opening stock: marked so, brought in by an import, or the product's first stock (counted or
  -- set on its first day, with nothing bought, sold or moved before it).
  select min(x.created_at)::date into first_day from public.stock_moves x where x.product_id = m.product_id;
  opening := coalesce(m.note, '') ilike 'opening stock%' or m.reason = 'import'
    or (m.created_at::date = first_day
        and not exists (select 1 from public.stock_moves x
                         where x.product_id = m.product_id and x.created_at < m.created_at
                           and x.reason not in ('adjust', 'count', 'import')));
  other := case when opening then public.acct(co, 'opening') else public.acct(co, 'inv_adjust') end;
  perform public.write_entry(co, m.created_at::date, 'stock', m.id, null,
    case when opening then 'Opening stock: ' else 'Stock ' || m.reason || ': ' end || m.pname,
    case when value >= 0 then jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'inventory'), 'debit', value),
        jsonb_build_object('account', other, 'credit', value))
      else jsonb_build_array(
        jsonb_build_object('account', other, 'debit', -value),
        jsonb_build_object('account', public.acct(co, 'inventory'), 'credit', -value)) end);
end $$;

-- 3) Partly fulfilled / partly received: lists can ask for part_moved on an order. True when some
--    (not all) of its stock went out or came in.
create or replace function public.part_moved(public.sales_orders)
returns boolean language sql stable set search_path = public as $$
  select $1.stock_taken_at is null
     and exists (select 1 from public.sales_order_lines l where l.sales_order_id = $1.id and l.qty_fulfilled > 0)
$$;
create or replace function public.part_moved(public.purchase_orders)
returns boolean language sql stable set search_path = public as $$
  select $1.stock_received_at is null
     and exists (select 1 from public.purchase_order_lines l where l.purchase_order_id = $1.id and l.qty_received > 0)
$$;
grant execute on function public.part_moved(public.sales_orders) to authenticated;
grant execute on function public.part_moved(public.purchase_orders) to authenticated;

-- 4) A bill typed with a vendor name (not picked from Vendors) still shows that name in the ledger
--    and in Expenses by vendor. (New bills now make the vendor when it's typed.)
create or replace function public.general_ledger(_from date, _to date)
returns table (
  line_id uuid, account_id uuid, entry_id uuid, entry_date date, ref text, memo text,
  source_type text, name text, debit numeric, credit numeric
)
language sql stable set search_path = public as $$
  select l.id, l.account_id, e.id, e.entry_date, e.ref, coalesce(l.memo, e.memo), e.source_type,
         coalesce(c.name, v.name,
                  case when e.source_type = 'bill'
                       then (select nullif(btrim(b.vendor_name), '') from public.bills b where b.id = e.source_id) end),
         l.debit, l.credit
    from public.journal_lines l
    join public.journal_entries e on e.id = l.entry_id
    left join public.customers c on c.id = l.customer_id
    left join public.vendors v on v.id = l.vendor_id
   where (_from is null or e.entry_date >= _from) and (_to is null or e.entry_date <= _to)
   order by l.account_id, e.entry_date, e.created_at, l.id
$$;
grant execute on function public.general_ledger(date, date) to authenticated;

-- 5) An invoice remembers the quote number it was made from (it shows "Made from quote Q-…").
alter table public.sales_orders add column if not exists quote_number text;

notify pgrst, 'reload schema';
