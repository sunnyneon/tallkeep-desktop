-- 077: Serial numbers. A product can track one serial number per unit: typed or scanned when it
-- comes in (or made up by Tallkeep, like SN-000123), picked when it goes out, printed on the
-- invoice, and looked up later (who bought it, when) for warranty and returns.

alter table public.serial_numbers add column if not exists created_at timestamptz not null default now();
alter table public.serial_numbers add column if not exists received_at timestamptz default now();
alter table public.serial_numbers add column if not exists received_from text;       -- vendor
alter table public.serial_numbers add column if not exists received_doc text;        -- PO number
alter table public.serial_numbers add column if not exists purchase_order_id uuid
  references public.purchase_orders(id) on delete set null;
alter table public.serial_numbers add column if not exists sales_order_id uuid
  references public.sales_orders(id) on delete set null;
-- The line it went out on (no foreign key, so the sales order ↔ line link stays the only one).
alter table public.serial_numbers add column if not exists sales_order_line_id uuid;
alter table public.serial_numbers add column if not exists sold_at timestamptz;
alter table public.serial_numbers add column if not exists notes text;
create index if not exists serial_numbers_serial_idx on public.serial_numbers (lower(serial));
create index if not exists serial_numbers_order_idx on public.serial_numbers (sales_order_id);

-- Serials Tallkeep makes up: prefix + a running number for the company.
alter table public.company_settings add column if not exists serial_prefix text not null default 'SN-';
alter table public.company_settings add column if not exists serial_next bigint not null default 1;

create or replace function public.make_serials(_n int)
returns text[] language plpgsql security definer set search_path = public as $$
declare c uuid := public.active_company(); p text; s bigint;
begin
  if c is null or not public.can_write_company(c) then raise exception 'You can''t add to this company.'; end if;
  if _n is null or _n < 1 or _n > 1000 then raise exception 'Between 1 and 1000 at a time.'; end if;
  update public.company_settings set serial_next = serial_next + _n
   where company_id = c returning serial_prefix, serial_next - _n into p, s;
  if p is null then raise exception 'Company settings are missing.'; end if;
  return array(
    select p || lpad((s + g)::text, 6, '0') from generate_series(0, _n - 1) g);
end $$;
grant execute on function public.make_serials(int) to authenticated;

-- After an undo of a fulfilment: each line keeps as many sold serials as it still has out
-- (the earliest ones); the rest go back into stock. The line's printed list follows.
create or replace function public.fix_order_serials(_order uuid)
returns int language plpgsql security invoker set search_path = public as $$
declare l record; n int := 0;
begin
  for l in select id, qty_fulfilled from public.sales_order_lines where sales_order_id = _order loop
    with sold as (
      select id, row_number() over (order by sold_at, serial) as k
        from public.serial_numbers where sales_order_line_id = l.id and status = 'sold'),
    back as (
      update public.serial_numbers s
         set status = 'in_stock', sales_order_id = null, sales_order_line_id = null, sold_at = null
        from sold where s.id = sold.id and sold.k > floor(coalesce(l.qty_fulfilled, 0))
      returning 1)
    select n + count(*) into n from back;
    update public.sales_order_lines set serials = (
      select string_agg(serial, ', ' order by sold_at, serial) from public.serial_numbers
       where sales_order_line_id = l.id and status = 'sold')
     where id = l.id;
  end loop;
  return n;
end $$;
grant execute on function public.fix_order_serials(uuid) to authenticated;

-- Which receipt brought it in, and which fulfilment took it out (so undoing one is exact).
alter table public.serial_numbers add column if not exists batch_id uuid;
alter table public.serial_numbers add column if not exists sold_batch_id uuid;

-- Undo of one receipt or one fulfilment: serials that came in with it (and are still in stock)
-- are taken off; serials that went out with it come back into stock.
create or replace function public.undo_batch_serials(_batch uuid)
returns int language plpgsql security invoker set search_path = public as $$
declare n int; m int; o uuid;
begin
  delete from public.serial_numbers where batch_id = _batch and status = 'in_stock';
  get diagnostics n = row_count;
  select sales_order_id into o from public.serial_numbers where sold_batch_id = _batch limit 1;
  update public.serial_numbers
     set status = 'in_stock', sales_order_id = null, sales_order_line_id = null, sold_at = null,
         sold_batch_id = null
   where sold_batch_id = _batch and status = 'sold';
  get diagnostics m = row_count;
  if o is not null then perform public.fix_order_serials(o); end if;
  return n + m;
end $$;
grant execute on function public.undo_batch_serials(uuid) to authenticated;

notify pgrst, 'reload schema';
