-- 081: The Welcome steps on a new install, and starting accounts for each kind of business.
--
-- * company_settings.welcome_done_at: empty for a brand-new company until its Welcome steps are
--   finished or skipped; Tallkeep opens the Welcome steps first while it's empty. Every company
--   that exists today counts as done.
-- * Kinds of business: two new ones, Construction and Restaurant (business_type has no fixed list).
-- * seed_kind_accounts: when a company picks its kind of business, it gets a few accounts that
--   kind usually needs, on top of the standard chart. Kept general: people change them as they
--   go. In brand-new books (nothing posted yet), a few starter accounts get that kind's usual
--   name and the ones it rarely uses are hidden (never deleted; turn them back on in the Chart of
--   Accounts). Books with entries only get the new accounts.

alter table public.company_settings add column if not exists welcome_done_at timestamptz;
update public.company_settings set welcome_done_at = now() where welcome_done_at is null;

create or replace function public.seed_kind_accounts(_co uuid, _kind text)
returns void language plpgsql security definer set search_path = public as $$
declare fresh boolean;
begin
  perform public.seed_accounts(_co);
  fresh := not exists (select 1 from public.journal_lines where company_id = _co);

  -- New accounts for this kind (skipped when the number or key is already there).
  insert into public.accounts (company_id, number, name, type, kind, key)
  select _co, x.number, x.name, x.type, x.kind, null
    from (values
      ('products',      '4050', 'Shipping and Handling Income', 'income',    'income'),
      ('manufacturing', '4050', 'Shipping and Handling Income', 'income',    'income'),
      ('manufacturing', '5300', 'Production Supplies',          'expense',   'cogs'),
      ('manufacturing', '5310', 'Production Labor',             'expense',   'cogs'),
      ('construction',  '1150', 'Retainage Receivable',         'asset',     'other_asset'),
      ('construction',  '2150', 'Retainage Payable',            'liability', 'other_liability'),
      ('construction',  '5300', 'Job Materials',                'expense',   'cogs'),
      ('construction',  '5310', 'Job Labor',                    'expense',   'cogs'),
      ('construction',  '5320', 'Job Subcontractors',           'expense',   'cogs'),
      ('construction',  '5330', 'Equipment Rental',             'expense',   'cogs'),
      ('construction',  '5340', 'Permits and Inspections',      'expense',   'cogs'),
      ('construction',  '6350', 'Small Tools',                  'expense',   'expense'),
      ('restaurant',    '4010', 'Beverage Sales',               'income',    'income'),
      ('restaurant',    '4020', 'Catering and Events',          'income',    'income'),
      ('restaurant',    '4030', 'Delivery App Sales',           'income',    'income'),
      ('restaurant',    '2210', 'Tips Owed to Staff',           'liability', 'other_liability'),
      ('restaurant',    '5010', 'Beverage Cost',                'expense',   'cogs'),
      ('restaurant',    '5020', 'Paper and To-Go Supplies',     'expense',   'cogs'),
      ('restaurant',    '6960', 'Delivery App Fees',            'expense',   'expense'),
      ('restaurant',    '6970', 'Kitchen Supplies and Smallwares', 'expense', 'expense'),
      ('restaurant',    '6980', 'Cleaning and Linens',          'expense',   'expense')
    ) as x(k, number, name, type, kind)
   where x.k = _kind
     and not exists (select 1 from public.accounts a where a.company_id = _co and a.number = x.number);

  if _kind = 'real_estate' then perform public.seed_real_estate_accounts(_co); end if;

  if not fresh then return; end if;

  -- Brand-new books: the usual names for this kind.
  update public.accounts a set name = x.name
    from (values
      ('services',     '4000', 'Sales',                           'Service Income'),
      ('construction', '4000', 'Sales',                           'Contract Income'),
      ('construction', '4100', 'Installation and Service Income', 'Service and Repair Income'),
      ('restaurant',   '4000', 'Sales',                           'Food Sales'),
      ('restaurant',   '5000', 'Cost of Goods Sold',              'Food Cost')
    ) as x(k, number, old, name)
   where x.k = _kind and a.company_id = _co and a.number = x.number and a.name = x.old;

  -- Brand-new books: hide what this kind rarely uses.
  update public.accounts a set is_active = false
    from (values
      ('services',     '1200'), ('services',     '5100'), ('services',     '5200'),
      ('services',     '4100'),
      ('construction', '6700'),
      ('restaurant',   '4100'), ('restaurant',   '6700')
    ) as x(k, number)
   where x.k = _kind and a.company_id = _co and a.number = x.number and a.is_active;
end $$;
revoke all on function public.seed_kind_accounts(uuid, text) from public, anon, authenticated;
grant execute on function public.seed_kind_accounts(uuid, text) to service_role;

-- Picking (or changing) the kind of business adds its accounts.
create or replace function public.seed_kind_accounts_on_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.business_type is not null
     and (tg_op = 'INSERT' or new.business_type is distinct from old.business_type) then
    perform public.seed_kind_accounts(new.company_id, new.business_type);
  end if;
  return new;
end $$;
drop trigger if exists company_settings_kind_accounts on public.company_settings;
create trigger company_settings_kind_accounts after insert or update of business_type
  on public.company_settings for each row execute function public.seed_kind_accounts_on_change();

notify pgrst, 'reload schema';
