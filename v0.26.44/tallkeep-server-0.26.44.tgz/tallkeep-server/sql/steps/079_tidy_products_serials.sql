-- 079: Tidy up after moving from inFlow, and remove products you no longer need.
--
-- Serial numbers brought from inFlow all came in marked "in stock". Here:
--  * the ones written on a sales order line are marked sold on that order (with its date);
--  * the rest, for products with nothing in stock, are marked "Not in stock";
--  * their "came in" date is cleared (it was the day of the move, not when they came in).
-- A new status "out" (shown as "Not in stock") is for a unit that left without an invoice.
--
-- delete_products: deletes products that have nothing in stock and aren't used to build
-- something. Past invoices and orders keep their lines (the text stays); the product's own
-- stock history, prices and serial numbers go with it.

alter table public.serial_numbers drop constraint if exists serial_numbers_status_check;
alter table public.serial_numbers add constraint serial_numbers_status_check
  check (status in ('in_stock','sold','returned','scrapped','out'));

do $$
begin
  -- Imported serials: no real "came in" date.
  update public.serial_numbers set received_at = null
   where inflow_id is not null and received_from is null and received_doc is null;

  -- Written on a sales line: sold on that order.
  update public.serial_numbers s
     set status = 'sold', sales_order_id = x.order_id, sales_order_line_id = x.line_id,
         sold_at = x.at
    from (
      select l.id as line_id, l.sales_order_id as order_id, l.product_id,
             lower(btrim(v)) as serial,
             coalesce(o.invoice_date, o.order_date)::timestamptz as at
        from public.sales_order_lines l
        join public.sales_orders o on o.id = l.sales_order_id
        cross join lateral regexp_split_to_table(coalesce(l.serials, ''), '[,;\n\r]+') v
       where l.serials is not null and l.product_id is not null and btrim(v) <> ''
         and coalesce(o.status, '') not in ('quote', 'cancelled')
    ) x
   where s.product_id = x.product_id and lower(s.serial) = x.serial
     and s.inflow_id is not null and s.status = 'in_stock';

  -- Nothing on the shelf: the rest aren't in stock either.
  update public.serial_numbers s set status = 'out', notes = coalesce(s.notes, 'Not in stock when moved from inFlow')
   where s.inflow_id is not null and s.status = 'in_stock'
     and coalesce((select sum(qty) from public.stock k where k.product_id = s.product_id), 0) <= 0;
end $$;

create or replace function public.delete_products(_ids uuid[])
returns jsonb language plpgsql security invoker set search_path = public as $$
declare p record; q numeric; done int := 0; kept jsonb := '[]';
begin
  for p in select id, name from public.products where id = any(_ids) loop
    select coalesce(sum(qty), 0) into q from public.stock where product_id = p.id and qty <> 0;
    if q <> 0 then
      kept := kept || jsonb_build_object('name', p.name, 'why', 'still has stock (' || trim(to_char(q, 'FM999999990.##')) || ')');
      continue;
    end if;
    if exists (select 1 from public.product_parts where part_id = p.id)
       or exists (select 1 from public.work_orders where product_id = p.id)
       or exists (select 1 from public.work_order_lines where part_id = p.id) then
      kept := kept || jsonb_build_object('name', p.name, 'why', 'is used to build another product');
      continue;
    end if;
    delete from public.products where id = p.id;
    done := done + 1;
  end loop;
  return jsonb_build_object('deleted', done, 'kept', kept);
end $$;
grant execute on function public.delete_products(uuid[]) to authenticated;

notify pgrst, 'reload schema';
