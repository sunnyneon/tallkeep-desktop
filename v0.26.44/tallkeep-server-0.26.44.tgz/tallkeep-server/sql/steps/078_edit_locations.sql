-- 078: Change or remove places and shelves. Renaming a shelf moves everything on it (stock,
-- history, documents) to the new name; if that shelf already has some of the same item, the
-- counts are added together. A shelf or place can be removed only when nothing is on it; a
-- place with stock history can't be deleted (that history would go too): stop using it instead.

create or replace function public.rename_shelf(_location uuid, _old text, _new text)
returns void language plpgsql security invoker set search_path = public as $$
declare n text := btrim(coalesce(_new, '')); r record;
begin
  if n = '' then raise exception 'Type the new shelf name.'; end if;
  if n = _old then return; end if;
  if not exists (select 1 from public.shelves where location_id = _location and name = _old) then
    raise exception 'That shelf isn''t here any more.';
  end if;
  if exists (select 1 from public.shelves where location_id = _location and name = n) then
    raise exception 'There''s already a shelf named % here.', n;
  end if;
  update public.shelves set name = n where location_id = _location and name = _old;
  -- Stock on the old shelf moves to the new name (added to any already there).
  for r in select * from public.stock where location_id = _location and shelf = _old loop
    if exists (select 1 from public.stock where product_id = r.product_id and location_id = _location and shelf = n) then
      update public.stock set qty = qty + r.qty, updated_at = now()
       where product_id = r.product_id and location_id = _location and shelf = n;
      delete from public.stock where id = r.id;
    else
      update public.stock set shelf = n, updated_at = now() where id = r.id;
    end if;
  end loop;
  update public.stock_moves set shelf = n where location_id = _location and shelf = _old;
  update public.stock_doc_lines set shelf = n where location_id = _location and shelf = _old;
  update public.stock_doc_lines set to_shelf = n where to_location_id = _location and to_shelf = _old;
  update public.products set default_shelf = n where default_location_id = _location and default_shelf = _old;
  update public.work_orders set shelf = n where location_id = _location and shelf = _old;
end $$;
grant execute on function public.rename_shelf(uuid, text, text) to authenticated;

create or replace function public.delete_shelf(_location uuid, _name text)
returns void language plpgsql security invoker set search_path = public as $$
declare q numeric;
begin
  select coalesce(sum(qty), 0) into q from public.stock
   where location_id = _location and shelf = _name and qty <> 0;
  if q <> 0 then
    raise exception 'Shelf % still has % items. Move them to another shelf first (Move to Shelves or Transfer Stock).', _name, trim(to_char(q, 'FM999999990.##'));
  end if;
  delete from public.stock where location_id = _location and shelf = _name and qty = 0;
  delete from public.shelves where location_id = _location and name = _name;
  update public.products set default_shelf = null where default_location_id = _location and default_shelf = _name;
end $$;
grant execute on function public.delete_shelf(uuid, text) to authenticated;

create or replace function public.delete_location(_location uuid)
returns void language plpgsql security invoker set search_path = public as $$
declare q numeric;
begin
  select coalesce(sum(qty), 0) into q from public.stock where location_id = _location and qty <> 0;
  if q <> 0 then
    raise exception 'This place still has % items. Move them first (Transfer Stock), then delete it.', trim(to_char(q, 'FM999999990.##'));
  end if;
  if exists (select 1 from public.stock_moves where location_id = _location)
     or exists (select 1 from public.work_orders where location_id = _location) then
    raise exception 'This place has stock history, which would be lost. Press "Stop using this place" instead: it disappears from the lists and the history stays.';
  end if;
  delete from public.stock where location_id = _location;
  delete from public.locations where id = _location;
end $$;
grant execute on function public.delete_location(uuid) to authenticated;

notify pgrst, 'reload schema';
