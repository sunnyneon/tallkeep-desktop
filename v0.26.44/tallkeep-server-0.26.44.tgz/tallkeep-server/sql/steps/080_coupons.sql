-- 080: Discount codes (friends and family). The owner makes them in the admin panel; each one
-- is also a coupon in Stripe, which counts the uses and stops it at the limit or end date.
-- Customers type the code on the Buy page (desktop) or the Plan page (online).

create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code ~ '^[A-Z0-9-]{3,20}$'),
  note text,
  percent_off numeric check (percent_off > 0 and percent_off <= 100),
  amount_off numeric check (amount_off > 0),
  for_desktop boolean not null default true,
  for_online boolean not null default true,
  online_forever boolean not null default false,
  max_uses int check (max_uses > 0),
  ends_on date,
  stripe_coupon text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  check ((percent_off is null) <> (amount_off is null)),
  check (for_desktop or for_online)
);

-- Only the server reads and writes it (it checks who is asking first).
alter table public.coupons enable row level security;
revoke all on public.coupons from anon, authenticated;
grant all on public.coupons to service_role;

notify pgrst, 'reload schema';
