-- 083: Fixes from the third test round (19 November 2026).
--
-- 1) Journal lines never get a minus amount: a minus debit is written as a credit and the other
--    way round. (Before, a minus amount stopped the whole save with a database error.)
create or replace function public.write_entry(_co uuid, _date date, _type text, _src uuid, _ref text,
  _memo text, _lines jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare e uuid; x jsonb; dr numeric := 0; cr numeric := 0;
begin
  for x in select value from jsonb_array_elements(_lines) loop
    dr := dr + coalesce((x->>'debit')::numeric, 0);
    cr := cr + coalesce((x->>'credit')::numeric, 0);
  end loop;
  if round(dr, 2) = 0 and round(cr, 2) = 0 then return; end if;
  if round(dr, 2) <> round(cr, 2) then
    raise exception 'Entry for % % does not balance (% vs %)', _type, coalesce(_ref, ''), dr, cr;
  end if;
  insert into public.journal_entries (company_id, entry_date, memo, source_type, source_id, ref)
  values (_co, _date, _memo, _type, _src, _ref) returning id into e;
  insert into public.journal_lines (company_id, entry_id, account_id, debit, credit, memo, customer_id, vendor_id, property_id)
  select _co, e, (q.l->>'account')::uuid, greatest(q.net, 0), greatest(-q.net, 0), q.l->>'memo',
         nullif(q.l->>'customer', '')::uuid, nullif(q.l->>'vendor', '')::uuid, nullif(q.l->>'property', '')::uuid
    from (select l, round(coalesce((l->>'debit')::numeric, 0), 2) - round(coalesce((l->>'credit')::numeric, 0), 2) as net
            from jsonb_array_elements(_lines) l) q
   where q.net <> 0;
end $$;

-- 2) A sales line can't have a minus quantity (a refund or an RMA takes things back). Credit memos
--    brought over from QuickBooks (numbers starting QB-CM-) keep theirs.
create or replace function public.sales_line_qty_ok()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.qty < 0 and (tg_op = 'INSERT' or new.qty is distinct from old.qty)
     and not exists (select 1 from public.sales_orders o
                      where o.id = new.sales_order_id and o.number like 'QB-CM-%') then
    raise exception 'Quantity must be 0 or more. To take something back, use a refund or an RMA.'
      using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists sales_line_qty_ok on public.sales_order_lines;
create trigger sales_line_qty_ok before insert or update of qty on public.sales_order_lines
  for each row execute function public.sales_line_qty_ok();

-- 3) A paid invoice can't be lowered below what's already been paid (refund or remove a payment
--    first). Only checked when the total goes down.
create or replace function public.sales_total_not_below_paid()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.total < old.total and new.total < coalesce(new.amount_paid, 0) - 0.005
     and new.status not in ('cancelled', 'quote', 'rma') and new.number not like 'QB-CM-%' then
    raise exception 'The new total (%) is below the % already paid. Remove a payment or give a refund first.',
      to_char(new.total, 'FM$999,999,990.00'), to_char(new.amount_paid, 'FM$999,999,990.00')
      using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists sales_total_not_below_paid on public.sales_orders;
create trigger sales_total_not_below_paid before update of total on public.sales_orders
  for each row execute function public.sales_total_not_below_paid();

-- 4) A bill with payments (or a vendor credit already used) can't be voided: the money would stay
--    posted while the bill left the books. Remove the payments first.
create or replace function public.bill_void_ok()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.status = 'void' and old.status is distinct from 'void'
     and exists (select 1 from public.bill_payments p where p.bill_id = new.id) then
    raise exception 'This bill has payments. Remove them first, then void it.' using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists bill_void_ok on public.bills;
create trigger bill_void_ok before update of status on public.bills
  for each row execute function public.bill_void_ok();

-- 5) A document number taken for a save that failed goes back, so numbers don't skip. Only the
--    last number handed out can come back.
create or replace function public.release_doc_number(_kind text, _number text)
returns boolean language plpgsql security definer set search_path = public as $$
declare co uuid := public.active_company(); n int;
begin
  if not public.is_staff(auth.uid()) then return false; end if;
  update public.doc_counters set next_number = next_number - 1
   where company_id = co and kind = _kind and prefix || lpad((next_number - 1)::text, 6, '0') = _number
     and not exists (select 1 from public.sales_orders where company_id = co and number = _number)
     and not exists (select 1 from public.purchase_orders where company_id = co and number = _number);
  get diagnostics n = row_count;
  return n > 0;
end $$;
grant execute on function public.release_doc_number(text, text) to authenticated;

-- 6) Opening stock is only a product's very first stock (or one marked "Opening stock", or an
--    import). Every later count or change goes to 5100 Inventory Adjustments, even on the same
--    day (D10).
create or replace function public.post_stock_move(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m record; co uuid; value numeric; other uuid; opening boolean;
begin
  delete from public.journal_entries where source_type = 'stock' and source_id = _id;
  select sm.*, p.cost, p.company_id as co, p.name as pname into m
    from public.stock_moves sm join public.products p on p.id = sm.product_id where sm.id = _id;
  if m.id is null or m.reason not in ('adjust', 'count', 'import') then return; end if;
  co := m.co;
  if not public.books_open(co, m.created_at::date) then return; end if;
  value := round(m.qty_change * m.cost, 2);
  opening := coalesce(m.note, '') ilike 'opening stock%' or m.reason = 'import'
    or not exists (select 1 from public.stock_moves x
                    where x.product_id = m.product_id
                      and (x.created_at < m.created_at or (x.created_at = m.created_at and x.id < m.id)));
  other := case when opening then public.acct(co, 'opening') else public.acct(co, 'inv_adjust') end;
  perform public.write_entry(co, m.created_at::date, 'stock', m.id, null,
    case when opening then 'Opening stock: ' else 'Stock ' || m.reason || ': ' end || m.pname,
    case when value >= 0 then jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'inventory'), 'debit', value),
        jsonb_build_object('account', other, 'credit', value))
      else jsonb_build_array(
        jsonb_build_object('account', other, 'debit', -value),
        jsonb_build_object('account', public.acct(co, 'inventory'), 'credit', -value)) end);
end $$;

-- 7) What a purchase order owes right now, the same as the Balance Sheet: all that's left to pay
--    once it's fully received; for a part receipt, the value of what came in less what's paid.
--    Pay Bills, Bills, the vendor page and What we owe use it.
create or replace function public.owed_now(public.purchase_orders)
returns numeric language sql stable set search_path = public as $$
  select case
    when $1.status = 'cancelled' then 0
    when $1.stock_received_at is not null or $1.status in ('received', 'paid', 'completed') then $1.balance
    else round(coalesce((select sum(l.line_total * least(l.qty_received / nullif(l.qty, 0), 1))
                           from public.purchase_order_lines l
                          where l.purchase_order_id = $1.id and l.qty_received > 0), 0), 2)
         - coalesce($1.amount_paid, 0)
  end
$$;
grant execute on function public.owed_now(public.purchase_orders) to authenticated;

-- 8) A customer or vendor with documents can't be deleted (hide it instead): its invoices, orders
--    and bills keep pointing to it (D13).
create or replace function public.party_delete_ok()
returns trigger language plpgsql set search_path = public as $$
begin
  -- Removing the whole sample company (or a whole company) clears everything in it.
  if exists (select 1 from public.companies c where c.id = old.company_id and c.is_sample)
     or coalesce(current_setting('tallkeep.clearing_company', true), '') = 'on' then
    return old;
  end if;
  if tg_table_name = 'customers'
     and exists (select 1 from public.sales_orders where customer_id = old.id) then
    raise exception 'This customer has quotes, orders or invoices, so it can''t be deleted. Untick Active to hide it.'
      using errcode = 'P0001';
  end if;
  if tg_table_name = 'vendors'
     and (exists (select 1 from public.purchase_orders where vendor_id = old.id)
          or exists (select 1 from public.bills where vendor_id = old.id)) then
    raise exception 'This vendor has purchase orders or bills, so it can''t be deleted. Untick Active to hide it.'
      using errcode = 'P0001';
  end if;
  return old;
end $$;
drop trigger if exists customers_delete_ok on public.customers;
create trigger customers_delete_ok before delete on public.customers
  for each row execute function public.party_delete_ok();
drop trigger if exists vendors_delete_ok on public.vendors;
create trigger vendors_delete_ok before delete on public.vendors
  for each row execute function public.party_delete_ok();

-- 9) A bill's total, paid and balance are worked out even when it's in another company of yours
--    than the one open (the sample company's bills were left at $0 while the books had them).
--    Bills whose total doesn't match their lines are worked out again once.
create or replace function public.refresh_bill(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t numeric; paid numeric;
begin
  if auth.uid() is not null and not exists (
       select 1 from public.bills b where b.id = _id and public.can_use_company(auth.uid(), b.company_id)) then
    return;
  end if;
  select coalesce(sum(amount), 0) into t from public.bill_lines where bill_id = _id;
  select coalesce(sum(amount), 0) into paid from public.bill_payments where bill_id = _id;
  update public.bills set total = t, amount_paid = paid, balance = t - paid, updated_at = now(),
    status = case when status = 'void' then 'void'
                  when t <> 0 and abs(t - paid) <= 0.005 then 'paid'
                  when t > 0 and t - paid <= 0.005 then 'paid'
                  else 'open' end
   where id = _id;
end $$;
grant execute on function public.refresh_bill(uuid) to authenticated;

do $$
declare b record;
begin
  for b in select x.id from public.bills x
            where x.total is distinct from (select coalesce(sum(l.amount), 0) from public.bill_lines l where l.bill_id = x.id)
               or x.amount_paid is distinct from (select coalesce(sum(p.amount), 0) from public.bill_payments p where p.bill_id = x.id)
  loop
    perform public.refresh_bill(b.id);
  end loop;
end $$;

notify pgrst, 'reload schema';
