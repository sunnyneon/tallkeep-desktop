import { Bt as FileCheckCorner, Cn as Boxes, Dt as HardHat, En as BookOpenText, Et as History, Fn as BadgeDollarSign, H as Percent, I as ReceiptText, It as FileText, Jt as CreditCard, L as Receipt, Ln as ArrowRightLeft, Lt as FileSpreadsheet, M as Scale, Mn as Barcode, Mt as FolderTree, Nn as Banknote, Nt as FolderOpen, On as Bitcoin, Ot as HandCoins, P as Repeat, R as Printer, Rt as FilePlusCorner, T as Settings, Tn as BookOpen, Tt as HousePlus, V as PiggyBank, W as PenLine, Xt as Coins, Y as Package, Z as PackageOpen, _t as LayoutDashboard, a as Wallet, bn as CalendarCheck, c as UsersRound, en as ClipboardList, f as Undo2, fn as ChartLine, gt as LifeBuoy, h as TrendingUp, j as ScanBarcode, jn as BedDouble, k as ScrollText, kt as Hammer, mn as Camera, mt as Link2, ot as MapPin, p as Truck, pn as ChartColumn, pt as ListChecks, r as Wrench, s as Users, t as Zap, tn as ClipboardCheck, v as Target, vn as CalendarDays, vt as Landmark, w as ShoppingBag, wn as Bot, wt as House, xn as Building2, xt as Inbox, yn as CalendarClock, yt as KeyRound } from "../_libs/lucide-react.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/nav-BIrQ7OjK.js
/** The feature each menu group belongs to (General, Reports and Options are always there). */
var GROUP_FEATURE = {
	Sales: "sales",
	Purchasing: "purchasing",
	Inventory: "inventory",
	Accounting: "accounting",
	Properties: "real_estate"
};
var featureOf = (i) => i.addon ?? GROUP_FEATURE[i.group];
var navItems = [
	{
		title: "Home",
		url: "/",
		icon: House,
		group: "General"
	},
	{
		title: "Shoebox",
		url: "/shoebox",
		icon: Inbox,
		group: "Accounting",
		section: ""
	},
	{
		title: "Overview",
		url: "/overview",
		icon: LayoutDashboard,
		group: "General",
		hideWith: "personal"
	},
	{
		title: "Budget",
		url: "/budget",
		icon: Target,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Net Worth",
		url: "/net-worth",
		icon: TrendingUp,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Investments",
		url: "/investments",
		icon: ChartLine,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Bills, Rent & Subscriptions",
		url: "/subscriptions",
		icon: CalendarClock,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Mortgage & Loans",
		url: "/loans",
		icon: HousePlus,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Monthly Review",
		url: "/monthly-review",
		icon: ListChecks,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "Crypto Tax",
		url: "/crypto-tax",
		icon: Bitcoin,
		group: "Accounting",
		addon: "crypto_tax",
		section: "My Money"
	},
	{
		title: "Household",
		url: "/household",
		icon: UsersRound,
		group: "Accounting",
		addon: "personal",
		section: "My Money"
	},
	{
		title: "New Quote",
		url: "/new-quote",
		icon: FilePlusCorner,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "New Invoice",
		url: "/new-invoice",
		icon: Receipt,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "Sales List",
		url: "/sales-list",
		icon: FileText,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "Repeating Invoices",
		url: "/repeating",
		icon: Repeat,
		group: "Sales",
		section: "Sales",
		hideWith: "personal"
	},
	{
		title: "Tickets",
		url: "/tickets",
		icon: LifeBuoy,
		group: "Sales",
		addon: "support",
		section: "Sales"
	},
	{
		title: "Website Tickets",
		url: "/website-tickets",
		icon: LifeBuoy,
		group: "Sales",
		addon: "tickets",
		section: "Sales"
	},
	{
		title: "Sales Receipt",
		url: "/sales-receipt",
		icon: BadgeDollarSign,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "Customers",
		url: "/customers",
		icon: Users,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "Statements",
		url: "/statements",
		icon: FileSpreadsheet,
		group: "Sales",
		section: "Sales"
	},
	{
		title: "Refunds & Credits",
		url: "/refunds",
		icon: Undo2,
		group: "Accounting",
		section: "Sales",
		hideWith: "personal"
	},
	{
		title: "Purchase Orders",
		url: "/purchase-orders",
		icon: ClipboardList,
		group: "Purchasing",
		section: "Purchasing"
	},
	{
		title: "Bills & Expenses",
		url: "/bills",
		icon: ReceiptText,
		group: "Accounting",
		section: "Purchasing",
		hideWith: "personal"
	},
	{
		title: "Pay Bills",
		url: "/pay-bills",
		icon: Wallet,
		group: "Accounting",
		section: "Purchasing",
		hideWith: "personal"
	},
	{
		title: "Pay Sales Tax",
		url: "/sales-tax",
		icon: Percent,
		group: "Accounting",
		section: "Purchasing",
		hideWith: "personal"
	},
	{
		title: "1099 Forms",
		url: "/forms-1099",
		icon: FileCheckCorner,
		group: "Accounting",
		section: "Purchasing",
		hideWith: "personal"
	},
	{
		title: "Technician Pay",
		url: "/tech-pay",
		icon: HardHat,
		group: "Purchasing",
		addon: "tech_pay",
		section: "Purchasing"
	},
	{
		title: "Vendors",
		url: "/vendors",
		icon: Truck,
		group: "Purchasing",
		section: "Purchasing",
		hideWith: "personal"
	},
	{
		title: "Product List",
		url: "/products",
		icon: Package,
		group: "Inventory"
	},
	{
		title: "Barcode Labels",
		url: "/labels",
		icon: Barcode,
		group: "Inventory"
	},
	{
		title: "Product Categories",
		url: "/categories",
		icon: FolderTree,
		group: "Inventory"
	},
	{
		title: "Current Stock",
		url: "/stock",
		icon: Boxes,
		group: "Inventory"
	},
	{
		title: "Movement History",
		url: "/movements",
		icon: History,
		group: "Inventory"
	},
	{
		title: "Serial Numbers",
		url: "/serials",
		icon: ScanBarcode,
		group: "Inventory"
	},
	{
		title: "Adjust Stock",
		url: "/adjust",
		icon: Wrench,
		group: "Inventory"
	},
	{
		title: "Count Sheet",
		url: "/count",
		icon: ClipboardCheck,
		group: "Inventory"
	},
	{
		title: "Transfer Stock",
		url: "/transfer",
		icon: ArrowRightLeft,
		group: "Inventory"
	},
	{
		title: "Move to Shelves",
		url: "/shelve",
		icon: PackageOpen,
		group: "Inventory"
	},
	{
		title: "Locations",
		url: "/locations",
		icon: MapPin,
		group: "Inventory"
	},
	{
		title: "Work Orders",
		url: "/work-orders",
		icon: Hammer,
		group: "Inventory",
		addon: "work_orders"
	},
	{
		title: "Properties",
		url: "/properties",
		icon: Building2,
		group: "Properties"
	},
	{
		title: "Leases & Tenants",
		url: "/leases",
		icon: KeyRound,
		group: "Properties"
	},
	{
		title: "Rent",
		url: "/rent",
		icon: HandCoins,
		group: "Properties"
	},
	{
		title: "Short-Term Stays",
		url: "/stays",
		icon: BedDouble,
		group: "Properties"
	},
	{
		title: "Rent Roll",
		url: "/rent-roll",
		icon: ScrollText,
		group: "Properties"
	},
	{
		title: "Review & Reconcile",
		url: "/banking",
		icon: Banknote,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Bank Connections",
		url: "/bank-connections",
		icon: Link2,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Check Register",
		url: "/register",
		icon: BookOpenText,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Credit Card Register",
		url: "/card-register",
		icon: CreditCard,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Credit Cards",
		url: "/credit-cards",
		icon: CreditCard,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Receipts",
		url: "/receipts",
		icon: Camera,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Checks Received",
		url: "/checks-received",
		icon: Banknote,
		group: "Accounting",
		section: "Banking",
		hideWith: "personal"
	},
	{
		title: "Fast Entry",
		url: "/fast-entry",
		icon: Zap,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Write Checks",
		url: "/checks",
		icon: PenLine,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Print Checks",
		url: "/print-checks",
		icon: Printer,
		group: "Accounting",
		section: "Banking",
		hideWith: "personal"
	},
	{
		title: "Record Deposits",
		url: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		section: "Banking",
		hideWith: "personal"
	},
	{
		title: "Recurring",
		url: "/recurring",
		icon: CalendarClock,
		group: "Accounting",
		section: "Banking",
		hideWith: "personal"
	},
	{
		title: "Transfers",
		url: "/bank-transfers",
		icon: Repeat,
		group: "Accounting",
		section: "Banking"
	},
	{
		title: "Mortgage & Loans",
		url: "/loans",
		icon: HousePlus,
		group: "Accounting",
		section: "Banking",
		hideWith: "personal"
	},
	{
		title: "Chart of Accounts",
		url: "/accounts",
		icon: Landmark,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Journal Entries",
		url: "/journal",
		icon: BookOpen,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Change History",
		url: "/history",
		icon: History,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Calendar",
		url: "/calendar",
		icon: CalendarDays,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Documents",
		url: "/documents",
		icon: FolderOpen,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "AI & Usage",
		url: "/ai",
		icon: Bot,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Payroll",
		url: "/payroll",
		icon: Coins,
		group: "Accounting",
		section: "Company",
		hideWith: "personal"
	},
	{
		title: "Year-End & CPA",
		url: "/year-end",
		icon: CalendarCheck,
		group: "Accounting",
		section: "Company"
	},
	{
		title: "Reports",
		url: "/reports",
		icon: ChartColumn,
		group: "Reports",
		hideWith: "personal"
	},
	{
		title: "Financial Reports",
		url: "/financials",
		icon: Scale,
		group: "Accounting",
		section: "Reports",
		showWith: "personal"
	},
	{
		title: "Options",
		url: "/settings",
		icon: Settings,
		group: "Options",
		section: ""
	}
];
/** The heading a menu item sits under (its own section, or its group's name). */
var GROUP_SECTION = {
	General: "",
	Sales: "Sales",
	Purchasing: "Purchasing",
	Inventory: "Inventory",
	Properties: "Properties",
	Accounting: "Company",
	Reports: "Reports",
	Options: "Options"
};
var sectionOf = (i) => i.section ?? GROUP_SECTION[i.group];
/** The first page of a feature (Options → Apps opens it). */
var featureHome = (f) => navItems.find((i) => (i.addon ?? GROUP_FEATURE[i.group]) === f)?.url ?? null;
/** Words for personal books: menu headings and page names that say "business" otherwise. */
var PERSONAL_SECTION = {
	Company: "Taxes & Tools",
	Purchasing: "Bills"
};
var PERSONAL_TITLE = {
	"/accounts": "Categories & Accounts",
	"/year-end": "Taxes & CPA",
	"/financials": "Money Reports"
};
var sectionName = (sec, personal) => personal && PERSONAL_SECTION[sec] || sec;
var itemTitle = (i, personal) => personal && PERSONAL_TITLE[i.url] || i.title;
/** Is this page (or a page inside it, like /products/123) the menu item's page? */
var pathIn = (path, url) => url === "/" ? path === "/" : path === url || path.startsWith(`${url}/`);
/**
* Section colors, after inFlow's look the team is used to:
* orange General, green Sales, brown Purchasing, blue Inventory, purple Reports, grey Options.
*/
var GROUP_COLOR = {
	General: {
		main: "#E8A13A",
		soft: "#FBF1E3"
	},
	Sales: {
		main: "#6E9D8B",
		soft: "#E4EDE8"
	},
	Purchasing: {
		main: "#9C8877",
		soft: "#F1EAE3"
	},
	Inventory: {
		main: "#5B8BD0",
		soft: "#E6EDF8"
	},
	Properties: {
		main: "#B5764A",
		soft: "#F6EBE2"
	},
	Accounting: {
		main: "#2F8F83",
		soft: "#E1F1EE"
	},
	Reports: {
		main: "#8A6A93",
		soft: "#EEE8F0"
	},
	Options: {
		main: "#687282",
		soft: "#ECEEF1"
	}
};
/** Which section a page belongs to (detail pages follow their list). */
function groupForPath(path) {
	if (path.startsWith("/sales") || path.startsWith("/customers") || path.startsWith("/statements") || [
		"/quotes",
		"/invoices",
		"/rma",
		"/tickets",
		"/website-tickets",
		"/repeating"
	].some((x) => path.startsWith(x))) return "Sales";
	if (path.startsWith("/purchase") || path.startsWith("/po/") || path.startsWith("/vendors")) return "Purchasing";
	if ([
		"/products",
		"/stock",
		"/locations",
		"/work-orders"
	].some((x) => path.startsWith(x))) return "Inventory";
	if ([
		"/properties",
		"/leases",
		"/rent",
		"/rent-roll",
		"/stays"
	].some((x) => pathIn(path, x))) return "Properties";
	if ([
		"/accounts",
		"/banking",
		"/shoebox",
		"/register",
		"/card-register",
		"/bills",
		"/journal",
		"/history",
		"/financials",
		"/year-end",
		"/checks",
		"/print-checks",
		"/pay-bills",
		"/deposits",
		"/bank-transfers",
		"/recurring",
		"/refunds",
		"/sales-tax",
		"/calendar",
		"/payroll",
		"/forms-1099",
		"/receipts",
		"/checks-received",
		"/ai",
		"/fast-entry",
		"/budget",
		"/net-worth",
		"/investments",
		"/subscriptions",
		"/monthly-review",
		"/crypto-tax",
		"/household"
	].some((x) => pathIn(path, x))) return "Accounting";
	return navItems.filter((i) => pathIn(path, i.url)).sort((a, b) => b.url.length - a.url.length)[0]?.group ?? "General";
}
/**
* Each menu heading has its own color, so Sales, Banking and Company don't look alike.
* main = icons and the band at the top of the page; soft = the page background tint.
*/
var SECTION_COLOR = {
	"": {
		main: "#E8A13A",
		soft: "#FBF1E3"
	},
	Sales: {
		main: "#4E9A72",
		soft: "#E3F0E8"
	},
	Purchasing: {
		main: "#9C7E62",
		soft: "#F1EAE3"
	},
	Inventory: {
		main: "#4F82C9",
		soft: "#E6EDF8"
	},
	Properties: {
		main: "#B5764A",
		soft: "#F6EBE2"
	},
	Banking: {
		main: "#1F8FA6",
		soft: "#E0F1F5"
	},
	"My Money": {
		main: "#0E7C74",
		soft: "#E0F2F0"
	},
	Company: {
		main: "#6366B8",
		soft: "#ECECF8"
	},
	Reports: {
		main: "#8A6A93",
		soft: "#EEE8F0"
	},
	Options: {
		main: "#687282",
		soft: "#ECEEF1"
	}
};
var colorOfItem = (i) => SECTION_COLOR[sectionOf(i)] ?? GROUP_COLOR[i.group];
/** The color of the page you're on: its menu item's heading (detail pages follow their list). */
function colorForPath(path) {
	const hit = navItems.filter((i) => pathIn(path, i.url)).sort((a, b) => b.url.length - a.url.length)[0];
	return hit ? colorOfItem(hit) : GROUP_COLOR[groupForPath(path)];
}
/** The menu heading of the page you're on ("" for Home and Overview). */
function sectionForPath(path) {
	const hit = navItems.filter((i) => pathIn(path, i.url)).sort((a, b) => b.url.length - a.url.length)[0];
	return hit ? sectionOf(hit) : "";
}
/** The icon next to each menu heading (the heading's words stay plain; the icon carries the color). */
var SECTION_ICON = {
	Sales: ShoppingBag,
	Purchasing: Truck,
	Inventory: Boxes,
	Properties: Building2,
	Banking: Landmark,
	"My Money": Wallet,
	Company: BookOpen,
	Reports: ChartColumn,
	Options: Settings
};
//#endregion
export { featureHome as a, itemTitle as c, sectionForPath as d, sectionName as f, colorOfItem as i, navItems as l, SECTION_ICON as n, featureOf as o, sectionOf as p, colorForPath as r, groupForPath as s, GROUP_COLOR as t, pathIn as u };
