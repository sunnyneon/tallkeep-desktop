//#region ../../node_modules/.nitro/vite/services/ssr/assets/purchasing-C4qcHG46.js
function poPayStatus(o) {
	if (o.status === "cancelled") return "Cancelled";
	const total = Number(o.total), paid = Number(o.amount_paid), bal = Number(o.balance);
	if (total > 0 && bal <= .005) return "Paid";
	if (total === 0 && (o.status === "paid" || o.status === "completed")) return "Paid";
	if (paid > 0) return "Partial";
	return "Unpaid";
}
/** Received all, some (part_moved, database step 82) or none. */
function poInvStatus(o) {
	if (o.stock_received_at || o.status === "received" || o.status === "completed") return "Fulfilled";
	return o.part_moved ? "Partial" : "Unfulfilled";
}
var PO_INV_LABEL = {
	Unfulfilled: "Not received",
	Partial: "Partly received",
	Fulfilled: "Received"
};
var r2 = (n) => Math.round(n * 100) / 100;
function poLineTotal(l) {
	const gross = Number(l.qty || 0) * Number(l.unit_cost || 0);
	const d = Number(l.discount || 0);
	return r2(l.discount_is_percent ? gross * (1 - d / 100) : gross - d);
}
function poTotals(lines, taxRate, freight) {
	const subtotal = r2(lines.reduce((s, l) => s + poLineTotal(l), 0));
	const tax = r2(subtotal * Number(taxRate || 0) / 100);
	return {
		subtotal,
		tax,
		total: r2(subtotal + tax + Number(freight || 0))
	};
}
//#endregion
export { poTotals as a, poPayStatus as i, poInvStatus as n, poLineTotal as r, PO_INV_LABEL as t };
