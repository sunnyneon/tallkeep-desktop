import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as db } from "./db-D7wKurqQ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-DLxCOMwe.js
var sales_DLxCOMwe_exports = /* @__PURE__ */ __exportAll({
	_: () => sales_exports,
	a: () => docName,
	c: () => isQuoteLike,
	d: () => nextNumber,
	f: () => noPartCol,
	g: () => releaseNumber,
	h: () => plainError,
	i: () => docBadge,
	l: () => isRmaDoc,
	m: () => payStatus,
	n: () => INV_STYLE,
	o: () => invMatches,
	p: () => partCol,
	r: () => PAY_STYLE,
	s: () => invStatus,
	t: () => INV_LABEL,
	u: () => lineTotal,
	v: () => totals
});
var sales_exports = /* @__PURE__ */ __exportAll$1({
	INV_LABEL: () => INV_LABEL,
	INV_STYLE: () => INV_STYLE,
	PAY_STYLE: () => PAY_STYLE,
	STATUS_LABEL: () => STATUS_LABEL,
	STATUS_STYLE: () => STATUS_STYLE,
	docBadge: () => docBadge,
	docName: () => docName,
	invMatches: () => invMatches,
	invStatus: () => invStatus,
	isQuoteLike: () => isQuoteLike,
	isRmaDoc: () => isRmaDoc,
	lineTotal: () => lineTotal,
	nextNumber: () => nextNumber,
	noPartCol: () => noPartCol,
	partCol: () => partCol,
	payStatus: () => payStatus,
	plainError: () => plainError,
	releaseNumber: () => releaseNumber,
	totals: () => totals
});
var STATUS_LABEL = {
	quote: "Quote",
	rma: "RMA",
	open: "Not invoiced yet",
	invoiced: "Invoice – unpaid",
	paid: "Invoice – paid",
	completed: "Completed",
	cancelled: "Cancelled"
};
/** What to call the document on screen and on paper. */
function docName(status) {
	if (status === "quote") return "Quote";
	if (status === "rma") return "RMA";
	if (status === "open") return "Invoice";
	if (status === "cancelled") return "Cancelled";
	return "Invoice";
}
var STATUS_STYLE = {
	quote: "bg-sky-100 text-sky-800",
	rma: "bg-violet-100 text-violet-800",
	open: "bg-amber-100 text-amber-800",
	invoiced: "bg-red-100 text-red-800",
	paid: "bg-emerald-100 text-emerald-800",
	completed: "bg-emerald-100 text-emerald-800",
	cancelled: "bg-muted text-muted-foreground"
};
/** Quotes and RMAs: paperwork only, no money owed and no stock moved. */
var isQuoteLike = (s) => s === "quote" || s === "rma";
/** A cancelled RMA still has its RMA- number. */
var isRmaDoc = (o) => o.status === "rma" || (o.number ?? "").startsWith("RMA-");
var r2 = (n) => Math.round(n * 100) / 100;
function lineTotal(l) {
	const gross = Number(l.qty || 0) * Number(l.unit_price || 0);
	const d = Number(l.discount || 0);
	return r2(l.discount_is_percent ? gross * (1 - d / 100) : gross - d);
}
function totals(lines, taxRate, shipping) {
	const subtotal = r2(lines.reduce((s, l) => s + lineTotal(l), 0));
	const tax = r2(lines.filter((l) => l.taxable).reduce((s, l) => s + lineTotal(l), 0) * Number(taxRate || 0) / 100);
	return {
		subtotal,
		tax,
		total: r2(subtotal + tax + Number(shipping || 0))
	};
}
async function nextNumber(kind) {
	const { data, error } = await db.rpc("next_doc_number", { _kind: kind });
	if (error) throw error;
	return data;
}
/** Gives a number back when the document it was taken for wasn't saved, so numbers don't skip.
*  Only the last number handed out can come back (step 083); older ones stay used. */
async function releaseNumber(kind, number) {
	await db.rpc("release_doc_number", {
		_kind: kind,
		_number: number
	}).catch(() => void 0);
}
/** A database error in plain words: never a raw constraint name (NEW-03). */
function plainError(e) {
	const m = e?.message ?? String(e);
	if (/violates check constraint|violates (not-null|foreign key|unique) constraint|journal_lines/i.test(m)) return "That couldn't be saved: a number on it doesn't add up. Nothing was changed.";
	return m;
}
function payStatus(o) {
	if (o.status === "quote") return "Quote";
	if (o.status === "rma") return "RMA";
	if (o.status === "cancelled") return "Cancelled";
	const paid = Number(o.amount_paid), bal = Number(o.balance);
	if (o.status === "open") return "Uninvoiced";
	if (bal <= .005) return "Paid";
	if (paid > 0) return "Partial";
	return "Unpaid";
}
function invStatus(o) {
	if (o.status === "quote") return "Quote";
	if (o.status === "rma") return "RMA";
	if (o.stock_taken_at) return "Fulfilled";
	return o.part_moved ? "Partial" : "Unfulfilled";
}
var INV_LABEL = {
	Quote: "Quote",
	RMA: "RMA",
	Fulfilled: "Fulfilled",
	Partial: "Partly fulfilled",
	Unfulfilled: "Unfulfilled"
};
/** "Unfulfilled" in a filter means "still has something to send": none or only some sent. */
var invMatches = (s, want) => want === "Unfulfilled" ? s === "Unfulfilled" || s === "Partial" : s === want;
var partOk = true;
var partCol = () => partOk ? ",part_moved" : "";
/** The database doesn't have part_moved yet: stop asking (the caller tries again). */
function noPartCol(e) {
	if (partOk && e && /part_moved/.test(e.message ?? "")) {
		partOk = false;
		return true;
	}
	return false;
}
/** The badge at the top of a quote or invoice: paid, partly paid or unpaid, from the numbers. */
function docBadge(o) {
	const s = o.status;
	if (s === "invoiced" || s === "paid") {
		const p = payStatus(o);
		if (p === "Paid") return {
			label: "Invoice – paid",
			style: STATUS_STYLE.paid
		};
		if (p === "Partial") return {
			label: "Invoice – partly paid",
			style: PAY_STYLE.Partial
		};
		return {
			label: "Invoice – unpaid",
			style: STATUS_STYLE.invoiced
		};
	}
	if (s === "open" && Number(o.amount_paid) > .005) return {
		label: "Not invoiced yet – deposit received",
		style: STATUS_STYLE.open
	};
	return {
		label: STATUS_LABEL[s],
		style: STATUS_STYLE[s]
	};
}
var PAY_STYLE = {
	Quote: "bg-sky-100 text-sky-800",
	RMA: "bg-violet-100 text-violet-800",
	Cancelled: "bg-muted text-muted-foreground line-through",
	Uninvoiced: "bg-amber-100 text-amber-800",
	Unpaid: "bg-red-100 text-red-800",
	Partial: "bg-orange-100 text-orange-800",
	Paid: "bg-emerald-100 text-emerald-800"
};
var INV_STYLE = {
	Quote: "bg-sky-100 text-sky-800",
	RMA: "bg-violet-100 text-violet-800",
	Fulfilled: "bg-emerald-100 text-emerald-800",
	Partial: "bg-orange-100 text-orange-800",
	Unfulfilled: "bg-muted text-foreground"
};
//#endregion
export { sales_DLxCOMwe_exports as _, docName as a, isQuoteLike as c, nextNumber as d, noPartCol as f, releaseNumber as g, plainError as h, docBadge as i, isRmaDoc as l, payStatus as m, INV_STYLE as n, invMatches as o, partCol as p, PAY_STYLE as r, invStatus as s, INV_LABEL as t, lineTotal as u, totals as v };
