import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets.functions-DdSsWpqD.js
/** A support ticket from sunriseled.com (Admin → Tickets). */
var NO_WEBSITE_KEY = "Link the office computer to your website: paste the website key below.";
async function site(path, userId, init) {
	const viaOffice = process.env["TALLKEEP_DESKTOP"] ? process.env["TALLKEEP_WEBSITE_URL"] : "";
	const key = process.env["OFFICE_SYNC_KEY"];
	if (!key && !viaOffice) throw new Error(process.env["TALLKEEP_DESKTOP"] ? "Tickets come from your website. Update Tallkeep on this computer to link it." : "The website link isn't set up yet: add the OFFICE_SYNC_KEY secret.");
	const { requireZone, requirePlatform } = await import("./zone.server-JWxH1ixr.mjs");
	await requirePlatform(userId);
	await requireZone(userId, ["Sales", "Purchasing"], "tickets");
	const base = process.env["WEBSITE_URL"] || "https://sunriseled.com";
	const res = viaOffice ? await fetch(`${viaOffice}${path}`, {
		...init,
		headers: {
			"x-tallkeep-mail": process.env["TALLKEEP_MAIL_TOKEN"] ?? "",
			"Content-Type": "application/json",
			...init?.headers ?? {}
		}
	}) : await fetch(`${base}/api/public/office/tickets${path}`, {
		...init,
		headers: {
			"x-office-key": key,
			"Content-Type": "application/json",
			...init?.headers ?? {}
		}
	});
	if (!res.ok) {
		if (res.status === 409) throw new Error(NO_WEBSITE_KEY);
		if (res.status === 404) throw new Error("The website doesn't have the office link yet. Publish sunriseled.com in Lovable, then try again.");
		if (res.status === 401) throw new Error(viaOffice ? "The website didn't accept the key saved on this computer. Paste it again below." : "The website didn't accept the key. OFFICE_SYNC_KEY must be the same in both apps.");
		const text = (await res.text().catch(() => "")).slice(0, 200);
		throw new Error(`The website said: ${res.status} ${text.startsWith("<") ? "" : text}`.trim());
	}
	return res.json();
}
var listTickets_createServerFn_handler = createServerRpc({
	id: "9d0066a13f2c073e0ecdd9f1dd3f644b1b5340b2bbe255f787f7eaf97c1d5ddd",
	name: "listTickets",
	filename: "src/lib/tickets.functions.ts"
}, (opts) => listTickets.__executeServer(opts));
var listTickets = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listTickets_createServerFn_handler, async ({ context }) => await site("?limit=500", context.userId));
var getTicket_createServerFn_handler = createServerRpc({
	id: "8e3e903a2c7b9dc8b4ebb470802f7497971688c5226db897ef3dcc22517c0996",
	name: "getTicket",
	filename: "src/lib/tickets.functions.ts"
}, (opts) => getTicket.__executeServer(opts));
var getTicket = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).inputValidator((d) => ({ id: Number(d.id) })).handler(getTicket_createServerFn_handler, async ({ data, context }) => await site(`?id=${data.id}`, context.userId));
var markTicket_createServerFn_handler = createServerRpc({
	id: "63062885b1d5ebe758cd8e6e4fcc209bf4492aacb2eaf6de2d83d140038ea485",
	name: "markTicket",
	filename: "src/lib/tickets.functions.ts"
}, (opts) => markTicket.__executeServer(opts));
var markTicket = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(markTicket_createServerFn_handler, async ({ data, context }) => {
	await site("", context.userId, {
		method: "POST",
		body: JSON.stringify(data)
	});
	return { ok: true };
});
var listTechFees_createServerFn_handler = createServerRpc({
	id: "7eaf5dbf89412f42ebd190a5a5b2b70b9bb5443150881549323022ab87ce003c",
	name: "listTechFees",
	filename: "src/lib/tickets.functions.ts"
}, (opts) => listTechFees.__executeServer(opts));
var listTechFees = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listTechFees_createServerFn_handler, async ({ context }) => await site("?view=tech-fees", context.userId));
//#endregion
export { getTicket_createServerFn_handler, listTechFees_createServerFn_handler, listTickets_createServerFn_handler, markTicket_createServerFn_handler };
