import { t as supabase } from "./client-OyQk2IBe.mjs";
import { J as redirect, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/route-DCg28UJM.js
var $$splitComponentImporter = () => import("./route-DeIeWhdr.mjs");
var Route = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data } = await supabase.auth.getSession();
		const user = data.session?.user;
		if (!user) throw redirect({ to: "/auth" });
		if (typeof window !== "undefined" && window.location.hostname.startsWith("admin.")) throw redirect({ to: "/admin" });
		return { user };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
