import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/notices.functions-iNOpiZ5a.js
/** "Send it to me now": the weekly list (or the monthly summary) for me, right away. */
var sendMyNotices_createServerFn_handler = createServerRpc({
	id: "82a7d5fbbaedbceed511171497d488fe7532fe56b56ed96abc3a745c5a1532c8",
	name: "sendMyNotices",
	filename: "src/lib/notices.functions.ts"
}, (opts) => sendMyNotices.__executeServer(opts));
var sendMyNotices = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => ({
	kind: d.kind === "monthly" ? "monthly" : "weekly",
	appUrl: /^https?:\/\/[^\s<>"']+$/.test(d.appUrl ?? "") ? d.appUrl : null
})).handler(sendMyNotices_createServerFn_handler, async ({ context, data }) => {
	const { runNoticeMail } = await import("./noticeMail.server-BW-zCSRR.mjs");
	return await runNoticeMail({
		user: context.userId,
		kind: data.kind,
		appUrl: data.appUrl
	});
});
//#endregion
export { sendMyNotices_createServerFn_handler };
