import { i as fmtMoney } from "./format-CgElbAz-.mjs";
import { supabaseAdmin } from "./client.server-KzwUIAkW.mjs";
import { deliver } from "./mailer.server-DR8PG4aY.mjs";
import { t as KIND_TITLES } from "./noticeKinds-TI0vp8qB.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/noticeMail.server-BW-zCSRR.js
/** The notification emails' wording and layout (no database code here, so it can be checked). */
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
function frame(label, body, appUrl) {
	const open = appUrl ? `<a href="${esc(appUrl)}/" style="display:inline-block;margin-top:18px;background:#0f766e;color:#fff;text-decoration:none;padding:10px 16px;border-radius:8px;font-size:14px;font-weight:600">Open Tallkeep</a>` : "";
	return `<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f5f3ee">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f3ee"><tr><td align="center" style="padding:24px 12px">
<table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fff;border-radius:12px;overflow:hidden;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
<tr><td style="background:#0f766e;padding:16px 24px;color:#fff;font-size:18px;font-weight:700">Tallkeep <span style="font-weight:400;font-size:13px;opacity:.85;float:right">${esc(label)}</span></td></tr>
<tr><td style="padding:18px 24px;color:#1f2937;font-size:14px">${body}${open}</td></tr>
<tr><td style="padding:12px 24px;background:#faf9f6;border-top:1px solid #eee;font-size:12px;color:#6b7280">
Mark an item Done (or Remind me in a week) under the bell in Tallkeep and it won't be emailed again. Change or stop these emails there too, under "Email me this list".
</td></tr></table></td></tr></table></body></html>`;
}
var table = (rows) => `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:14px">${rows.join("")}</table>`;
var tr = (cells, red = false) => `<tr>${cells.map((c, i) => `<td style="padding:6px 8px;border-bottom:1px solid #eee;${i === cells.length - 1 ? "text-align:right;white-space:nowrap;" : ""}${red ? "color:#b91c1c;" : ""}">${c}</td>`).join("")}</tr>`;
/** The weekly list: what needs attention, by company. */
function weeklyEmail(notices, appUrl, today) {
	const byCo = /* @__PURE__ */ new Map();
	for (const n of notices) byCo.set(n.company_name, [...byCo.get(n.company_name) ?? [], n]);
	const text = [`${notices.length} thing(s) need your attention`, ""];
	let html = `<p style="margin:0 0 6px;font-size:16px;font-weight:600">${notices.length} thing${notices.length === 1 ? "" : "s"} need${notices.length === 1 ? "s" : ""} your attention</p>`;
	for (const [co, items] of byCo) {
		html += `<h2 style="margin:20px 0 4px;font-size:15px;color:#0f766e">${esc(co)}</h2>`;
		text.push(`== ${co} ==`);
		for (const [kind, title] of KIND_TITLES) {
			const list = items.filter((n) => n.kind === kind);
			if (!list.length) continue;
			html += `<h3 style="margin:12px 0 2px;font-size:13px;color:#6b7280;text-transform:uppercase;letter-spacing:.03em">${esc(title)}</h3>`;
			const shown = list.slice(0, 15);
			html += table(shown.map((n) => tr([`<b>${esc(n.title)}</b>${n.detail ? `<br><span style="color:#6b7280;font-size:12px">${esc(n.detail)}</span>` : ""}`, n.amount != null && Math.abs(n.amount) > .005 ? esc(fmtMoney(n.amount)) : ""], n.urgent)));
			if (list.length > shown.length) html += `<p style="margin:4px 0 0;font-size:12px;color:#6b7280">and ${list.length - shown.length} more in the app</p>`;
			text.push(`${title}:`);
			for (const n of list) text.push(`  • ${n.title}${n.amount != null && Math.abs(n.amount) > .005 ? ` — ${fmtMoney(n.amount)}` : ""}${n.detail ? ` (${n.detail})` : ""}`);
		}
		text.push("");
	}
	if (appUrl) text.push(`Open Tallkeep: ${appUrl}/`);
	const stamp = today.toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	});
	return {
		subject: `Tallkeep — ${notices.length} thing${notices.length === 1 ? "" : "s"} need${notices.length === 1 ? "s" : ""} your attention (${stamp})`,
		text: text.join("\n"),
		html: frame(stamp, html, appUrl)
	};
}
/** The monthly summary: last month for each company. */
function monthlyEmail(rows, monthLabel, appUrl) {
	const text = [`Your ${monthLabel} summary`, ""];
	let html = `<p style="margin:0 0 6px;font-size:16px;font-weight:600">${esc(monthLabel)}: how each company did</p>`;
	const change = (a, b) => b == null || Math.abs(b) < .5 ? "" : `${a >= b ? "up" : "down"} ${fmtMoney(Math.abs(a - b))}`;
	for (const r of rows) {
		const m = r.month;
		const profit = Number(m.income) - Number(m.expenses);
		html += `<h2 style="margin:20px 0 6px;font-size:15px;color:#0f766e">${esc(r.name)}</h2>`;
		html += table([
			tr(["Money in", `${esc(fmtMoney(m.income))}${r.prev ? ` <span style="color:#6b7280;font-size:12px">${esc(change(m.income, r.prev.income))}</span>` : ""}`]),
			tr(["Money out", `${esc(fmtMoney(m.expenses))}${r.prev ? ` <span style="color:#6b7280;font-size:12px">${esc(change(m.expenses, r.prev.expenses))}</span>` : ""}`]),
			tr([`<b>${profit >= 0 ? "Profit" : "Loss"}</b>`, `<b>${esc(fmtMoney(profit))}</b>`], profit < 0),
			tr(["Cash at month end", esc(fmtMoney(m.cash))], m.cash < 0),
			...Math.abs(m.owed_to_us) > .005 ? [tr(["Customers owe you", esc(fmtMoney(m.owed_to_us))])] : [],
			...Math.abs(m.we_owe) > .005 ? [tr(["You owe vendors", esc(fmtMoney(m.we_owe))])] : []
		]);
		if (m.top?.length) html += `<p style="margin:8px 0 2px;font-size:12px;color:#6b7280">Biggest costs: ` + m.top.map((t) => `${esc(t.name)} ${esc(fmtMoney(t.amount))}`).join(" · ") + `</p>`;
		if (r.open) html += `<p style="margin:6px 0 0;font-size:12px;color:#b45309">${r.open} thing${r.open === 1 ? "" : "s"} need${r.open === 1 ? "s" : ""} your attention in the app.</p>`;
		text.push(`== ${r.name} ==`, `Money in: ${fmtMoney(m.income)}  Money out: ${fmtMoney(m.expenses)}  ${profit >= 0 ? "Profit" : "Loss"}: ${fmtMoney(profit)}`, `Cash at month end: ${fmtMoney(m.cash)}`, ...m.top?.length ? [`Biggest costs: ${m.top.map((t) => `${t.name} ${fmtMoney(t.amount)}`).join(", ")}`] : [], ...r.open ? [`${r.open} thing(s) need your attention in the app.`] : [], "");
	}
	if (appUrl) text.push(`Open Tallkeep: ${appUrl}/`);
	return {
		subject: `Tallkeep — your ${monthLabel} summary`,
		text: text.join("\n"),
		html: frame(monthLabel, html, appUrl)
	};
}
var db = supabaseAdmin;
var WEEKDAYS = [
	"sun",
	"mon",
	"tue",
	"wed",
	"thu",
	"fri",
	"sat"
];
function now() {
	if (process.env["TALLKEEP_DESKTOP"] === "1") return /* @__PURE__ */ new Date();
	return new Date((/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "America/Chicago" }));
}
var dayOf = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
async function addressOf(r) {
	if (r.email?.trim()) return r.email.trim();
	const { data } = await db.auth.admin.getUserById(r.user_id);
	return data.user?.email ?? null;
}
/** Daily job (hourly): send the weekly lists and monthly summaries that are due. */
async function runNoticeMail(force) {
	const run = {
		weekly: 0,
		monthly: 0,
		failed: 0,
		skipped: false
	};
	const q = db.from("notice_settings").select("*");
	const { data: found, error } = force?.user ? await q.eq("user_id", force.user) : await q.or("weekly.eq.true,monthly.eq.true");
	if (error) {
		if (/notice_settings|does not exist|schema cache/i.test(error.message)) return {
			...run,
			skipped: true
		};
		throw error;
	}
	const data = (found ?? []).length ? found : force?.user ? [{
		user_id: force.user,
		email: null,
		weekly: false,
		days: ["mon"],
		monthly: false,
		hour: 8,
		skip_companies: [],
		app_url: null,
		last_weekly: null,
		last_monthly: null
	}] : [];
	const t = now();
	const today = dayOf(t);
	const wd = WEEKDAYS[t.getDay()];
	const thisMonth = today.slice(0, 7);
	for (const r0 of data) {
		if (force?.user && r0.user_id !== force.user) continue;
		const r = force?.appUrl ? {
			...r0,
			app_url: force.appUrl
		} : r0;
		const late = t.getHours() >= (r.hour ?? 8);
		const skip = new Set(r.skip_companies ?? []);
		const to = await addressOf(r);
		if (!to) continue;
		if (force?.kind === "weekly" || !force && r.weekly && (r.days ?? ["mon"]).includes(wd) && late && r.last_weekly !== today) {
			const { data: ns, error: e } = await db.rpc("notices_of", {
				_uid: r.user_id,
				_today: today
			});
			if (e) throw e;
			const list = (ns ?? []).filter((n) => !skip.has(n.company_id)).map((n) => ({
				...n,
				amount: n.amount == null ? null : Number(n.amount)
			}));
			let ok = true;
			if (list.length) {
				const m = weeklyEmail(list, r.app_url, t);
				const res = await deliver({
					to: [to],
					fromName: "Tallkeep",
					...m
				});
				ok = res.ok;
				if (ok) run.weekly++;
				else {
					run.failed++;
					console.error("[notice-emails] weekly:", res.why);
				}
			}
			if (ok && !force) await db.from("notice_settings").update({ last_weekly: today }).eq("user_id", r.user_id);
		}
		if (force?.kind === "monthly" || !force && r.monthly && t.getDate() <= 7 && late && r.last_monthly !== thisMonth) {
			const first = new Date(t.getFullYear(), t.getMonth() - 1, 1);
			const before = new Date(t.getFullYear(), t.getMonth() - 2, 1);
			const { data: cos, error: e } = await db.rpc("companies_of", { _uid: r.user_id });
			if (e) throw e;
			const { data: ns } = await db.rpc("notices_of", {
				_uid: r.user_id,
				_today: today
			});
			const open = /* @__PURE__ */ new Map();
			for (const n of ns ?? []) open.set(n.company_id, (open.get(n.company_id) ?? 0) + 1);
			const rows = [];
			for (const c of cos ?? []) {
				if (skip.has(c.id)) continue;
				const [{ data: cur }, { data: prev }] = await Promise.all([db.rpc("month_summary", {
					_co: c.id,
					_month: dayOf(first)
				}), db.rpc("month_summary", {
					_co: c.id,
					_month: dayOf(before)
				})]);
				const m = cur;
				if (!m) continue;
				if (!Number(m.income) && !Number(m.expenses) && !open.get(c.id) && !Number(m.cash)) continue;
				rows.push({
					name: c.name,
					month: m,
					prev,
					open: open.get(c.id) ?? 0
				});
			}
			let ok = true;
			if (rows.length) {
				const m = monthlyEmail(rows, first.toLocaleDateString("en-US", {
					month: "long",
					year: "numeric"
				}), r.app_url);
				const res = await deliver({
					to: [to],
					fromName: "Tallkeep",
					...m
				});
				ok = res.ok;
				if (ok) run.monthly++;
				else {
					run.failed++;
					console.error("[notice-emails] monthly:", res.why);
				}
			}
			if (ok && !force) await db.from("notice_settings").update({ last_monthly: thisMonth }).eq("user_id", r.user_id);
		}
	}
	return run;
}
//#endregion
export { runNoticeMail };
