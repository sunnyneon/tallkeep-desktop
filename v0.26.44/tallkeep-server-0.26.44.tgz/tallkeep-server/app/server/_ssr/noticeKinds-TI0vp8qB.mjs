//#region ../../node_modules/.nitro/vite/services/ssr/assets/noticeKinds-TI0vp8qB.js
/** Section headings, in the order they're shown. */
var KIND_TITLES = [
	["overdue_invoice", "Invoices past due"],
	["rent_late", "Rent that's late"],
	["bill_due", "Bills to pay this week"],
	["reminder", "Bills & subscriptions due"],
	["loan_due", "Loan payments due"],
	["negative_cash", "Accounts below zero"],
	["bank_lines", "Bank lines to record"],
	["over_budget", "Over budget this month"],
	["low_stock", "Running low"]
];
//#endregion
export { KIND_TITLES as t };
