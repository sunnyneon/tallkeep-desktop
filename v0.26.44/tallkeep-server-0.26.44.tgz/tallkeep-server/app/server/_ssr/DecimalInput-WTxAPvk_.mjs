import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/DecimalInput-WTxAPvk_.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* A number box that keeps what's typed while you type ("7." stays "7." so 7.5 doesn't turn into
* 75), and passes the number up. With `money`, it shows two decimals when you leave it (5 → 5.00).
*/
function DecimalInput({ value, onValue, money, onBlur, onFocus, ...rest }) {
	const show = (v) => {
		if (v === null || v === void 0 || v === "") return "";
		const n = Number(v);
		if (!Number.isFinite(n)) return String(v);
		return money ? n.toFixed(2) : String(n);
	};
	const [s, setS] = (0, import_react.useState)(show(value));
	const [editing, setEditing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!editing && Number(s || 0) !== Number(value || 0)) setS(show(value));
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		inputMode: "decimal",
		...rest,
		value: s,
		onFocus: (e) => {
			setEditing(true);
			onFocus?.(e);
		},
		onChange: (e) => {
			const raw = e.target.value.replace(/[$,\s]/g, "");
			setS(e.target.value);
			if (raw === "" || raw === "-" || raw === ".") return onValue(0);
			const n = Number(raw);
			if (Number.isFinite(n)) onValue(n);
		},
		onBlur: (e) => {
			setEditing(false);
			setS(s === "" && !Number(value) ? "" : show(value ?? 0));
			onBlur?.(e);
		}
	});
}
//#endregion
export { DecimalInput as t };
