//#region ../../node_modules/.nitro/vite/services/ssr/assets/categories-DKQX6-jm.js
/** "Parent › Child" for a category (guards against loops in the data). */
function catPath(cats, id) {
	if (!id || !cats) return "";
	const by = new Map(cats.map((c) => [c.id, c]));
	const names = [];
	const seen = /* @__PURE__ */ new Set();
	let c = by.get(id);
	while (c && !seen.has(c.id)) {
		seen.add(c.id);
		names.unshift(c.name);
		c = c.parent_id ? by.get(c.parent_id) : void 0;
	}
	return names.join(" › ");
}
/** The category and every category under it (any depth). */
function withChildren(cats, id) {
	const out = /* @__PURE__ */ new Set([id]);
	let grew = true;
	while (grew) {
		grew = false;
		for (const c of cats ?? []) if (c.parent_id && out.has(c.parent_id) && !out.has(c.id)) {
			out.add(c.id);
			grew = true;
		}
	}
	return out;
}
/** Every category with its full name, in tree order (parents first, A–Z). */
function catOptions(cats) {
	return (cats ?? []).map((c) => ({
		value: c.id,
		label: catPath(cats, c.id)
	})).sort((a, b) => a.label.localeCompare(b.label, void 0, { numeric: true }));
}
/** The categories directly under a parent (null: the top level), A–Z. */
function childrenOf(cats, parent) {
	return (cats ?? []).filter((c) => (c.parent_id ?? null) === parent).sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true }));
}
//#endregion
export { withChildren as i, catPath as n, childrenOf as r, catOptions as t };
