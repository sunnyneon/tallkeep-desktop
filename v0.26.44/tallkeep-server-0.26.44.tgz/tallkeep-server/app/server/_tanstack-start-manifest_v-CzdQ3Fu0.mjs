//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CzdQ3Fu0.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/notice-emails",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BkPMISnu.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DnqKoVlX.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CBvTCxtR.js",
			"/assets/company-DjnW8du3.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BkPMISnu.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CSJpuCbL.js",
			"/assets/createServerFn-xYO9ZMwU.js",
			"/assets/log-out-CJYTMKH_.js",
			"/assets/auth-middleware-rxA0_8RK.js",
			"/assets/testers.functions-DKt094fG.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Bh9Hm9XJ.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-D9UlJ_sx.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/accounting-CyFcXaaV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-C356Qi6L.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/dist-DnAviZK6.js",
			"/assets/dialog-Dfdh7Ddp.js",
			"/assets/queries-Dby7digk.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/label-Ck5lwAQw.js",
			"/assets/textarea-GblDytQh.js",
			"/assets/shoebox-B2BWatqs.js",
			"/assets/reports-_dSsKIFr.js",
			"/assets/access-Cf1RbvXL.js",
			"/assets/theme-C3Gs-9WD.js",
			"/assets/Logo-DN8wa24x.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-DtILJps7.js",
			"/assets/log-out-CJYTMKH_.js",
			"/assets/admin.functions-DT7Ul1hW.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DN8wa24x.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BdCxMCCM.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/label-Ck5lwAQw.js",
			"/assets/Logo-DN8wa24x.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BqfLKQQg.js",
			"/assets/testers.functions-DKt094fG.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/coupons.functions-B0ca3GSj.js",
			"/assets/buy.functions-BlZX8-rd.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-BAgAic6q.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/downloads.functions-DxEPfHKO.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CNLZfTJU.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/label-Ck5lwAQw.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BmC1Q8Ay.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/label-Ck5lwAQw.js",
			"/assets/Logo-DN8wa24x.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-VV2AudM0.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/upgrade.functions-CbvTMG7y.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-DOUvLbW2.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/label-Ck5lwAQw.js",
			"/assets/Logo-DN8wa24x.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-Bd0VdsOV.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-D5qzwEaJ.js", "/assets/StockDocList--9LjSJPB.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-B7cimFlJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/ai-BqZoxzUA.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-ciiLkuPU.js",
			"/assets/BankConnections-DY9Nnofk.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BJwaECx_.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-C1SqVYyD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DY9Nnofk.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/ai-BqZoxzUA.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-CfmyTm_B.js",
			"/assets/TxnEditor-NNp5XdPR.js",
			"/assets/feedWaiting-DPUapZXr.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-LDYZf9eS.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-9eySTdtC.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DFffFUhH.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/personal-IbP4xpCI.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/WhoPicker-Baadj1UD.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-QnJhj6AG.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CR_pc-bP.js", "/assets/AccountRegister-DJiUsXXy.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-J5xOrXPS.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DeNmGCqW.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/money-BGX_Z9KL.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-D10qpW_a.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BqZoxzUA.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-6EX_V2cn.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-_rKwBu6C.js", "/assets/StockDocList--9LjSJPB.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DeBvu_j1.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BH-kPBvo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DpTxYDGC.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BIOW0qwf.js", "/assets/PartyList-CyrPEqSi.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-D7ey2sRn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Of2jnmaL.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/storage.functions-DyMiXu4z.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Ce02ZGJr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-HTRqaQ8J.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/booksStart-B45127Ry.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-B6_BZSdy.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CQmB2trV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-kEypzgKn.js", "/assets/ChangeHistory-CvLmDkcS.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-o5lGYrQv.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/members-DD3wvc2H.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DJvZ-ykc.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/personal-IbP4xpCI.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/WhoPicker-Baadj1UD.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-cVPWontS.js", "/assets/SalesList-BoOYQ4CQ.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BcMtjN6V.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BQrNBLPs.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CLecm6GJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CMem7qXr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/loans-CfmyTm_B.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-BiCzFU3v.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-DiJQ4ia_.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-aXuFl6iK.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/personal-IbP4xpCI.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/WhoPicker-Baadj1UD.js",
			"/assets/reminders-Btb3Fz7G.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-p-x9oTaf.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CySYIWlD.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/personal-IbP4xpCI.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/WhoPicker-Baadj1UD.js",
			"/assets/generateCategoricalChart-BEN6ZTNE.js",
			"/assets/Area-BtUVhmWu.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DOSEvkhZ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/generateCategoricalChart-BEN6ZTNE.js",
			"/assets/PlCharts-B6_BZSdy.js",
			"/assets/BarChart-D953v-cS.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-Qy7j8nmm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/balances-9eySTdtC.js",
			"/assets/money-BGX_Z9KL.js",
			"/assets/DecimalInput-DdVVzRUY.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CgmoVxII.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-D2ir7uRF.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/storage.functions-DyMiXu4z.js",
			"/assets/coupons.functions-B0ca3GSj.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-S29cDSG5.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Da8xrIgN.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/DecimalInput-DdVVzRUY.js",
			"/assets/StockDialogs-jaxO4Tlg.js",
			"/assets/checkbox-DInqmvXh.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DIadLnLV.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-msE37c5n.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BTs32Iet.js", "/assets/SalesList-BoOYQ4CQ.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DblOQLEP.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/ai-BqZoxzUA.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DyMiXu4z.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BA2rQWHa.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/money-BGX_Z9KL.js",
			"/assets/badge-D5cNFrMP.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-P3M3rV7m.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-tL2Nt46t.js", "/assets/AccountRegister-DJiUsXXy.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-eIem-I0Q.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/MoneyAccountPick-BX8QzfFv.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-x6HPHfkH.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BRnwzpAb.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/RepeatInvoice-CL6hSxOG.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BgLkMx1u.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-BEN6ZTNE.js",
			"/assets/BarChart-D953v-cS.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CgDIDMRL.js", "/assets/SalesList-BoOYQ4CQ.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-hE6ZIklt.js", "/assets/SalesList-BoOYQ4CQ.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CdgTmYT0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-Sn5l6ucG.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/serials-Blf8gLLO.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CduXlEHI.js",
			"/assets/AppsCatalog-Dk40KpuM.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-B468djHo.js",
			"/assets/switch-DiJQ4ia_.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-DpTxYDGC.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BdoiSzGc.js",
			"/assets/footers-BCvljdqa.js",
			"/assets/PrintFrame-YHFEVg_g.js",
			"/assets/checkbox-DInqmvXh.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DydvMwg0.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DKEjVC6T.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-Dk40KpuM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-DY9Nnofk.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DYjMu8wq.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/StockDialogs-jaxO4Tlg.js",
			"/assets/photos-BdoiSzGc.js",
			"/assets/stockmove-DmaLA91I.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BlFGAGWs.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/loans-CfmyTm_B.js",
			"/assets/feedWaiting-DPUapZXr.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DyMiXu4z.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Zv4wS8Zw.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/PrintFrame-YHFEVg_g.js",
			"/assets/DocPdf-CzCfq1GC.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-C9Jq8d51.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/MoneyAccountPick-BX8QzfFv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DydvMwg0.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C6HxWipH.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/StockDialogs-jaxO4Tlg.js",
			"/assets/stockmove-DmaLA91I.js",
			"/assets/checkbox-DInqmvXh.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-iYrQ4gQA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/members-DD3wvc2H.js",
			"/assets/WhoPicker-Baadj1UD.js",
			"/assets/reminders-Btb3Fz7G.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DCTh1yZR.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/tickets.functions-BD5vUJfq.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-OgrGFcgX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DydvMwg0.js",
			"/assets/support.functions-CEhAhDAv.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Daqri3y6.js", "/assets/StockDocList--9LjSJPB.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CPiHqA4j.js", "/assets/PartyList-CyrPEqSi.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-CmI2iCqE.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/tickets.functions-BD5vUJfq.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CzOjBoKh.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/workorders-DG5Q95UT.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BjhcVA8U.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-DnRWo4GY.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/coupons.functions-B0ca3GSj.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-a4-vrIV-.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/AdminAccount-KgiT_-cC.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-DCOkWYNO.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/downloads.functions-DxEPfHKO.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-pbyS8aRh.js",
			"/assets/createServerFn-xYO9ZMwU.js",
			"/assets/auth-middleware-rxA0_8RK.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CIPaltTg.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BzVHZLWO.js",
			"/assets/testers.functions-DKt094fG.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-nuYSs68w.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-qUGkIFNS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BlZX8-rd.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Cl4C5ASD.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/textarea-GblDytQh.js",
			"/assets/support.functions-CEhAhDAv.js",
			"/assets/HelpParts-CqKQ74XA.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-B9c46Uzu.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CfTtXvO1.js",
			"/assets/manual._slug-CrwgiB58.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-PYwINU5B.js",
			"/assets/createServerFn-xYO9ZMwU.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CvrDrden.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-CbvTMG7y.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-ClF_PyGz.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BqZoxzUA.js",
			"/assets/personal-IbP4xpCI.js",
			"/assets/reminders-Btb3Fz7G.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-7sw1Fk8x.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/AdminAccount-KgiT_-cC.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-B1bCLHHw.js", "/assets/ManualFrame-CfTtXvO1.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DtgQ20o9.js", "/assets/AccountRegister-DJiUsXXy.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BXucj6cJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/OriginalLink-BpLEHuAw.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/realestate-ClL5uKkZ.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C587ySgF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/realestate-ClL5uKkZ.js",
			"/assets/money-BGX_Z9KL.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BhWDHfXs.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-B45127Ry.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/SideList-7D0asKHr.js",
			"/assets/PartyHistory-LrmISFxC.js",
			"/assets/tabs-B8J5fSLz.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BNyt25dO.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/ChangeHistory-CvLmDkcS.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/SideList-7D0asKHr.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-DdVVzRUY.js",
			"/assets/StockDialogs-jaxO4Tlg.js",
			"/assets/NewProductDialog-CMg7bfIh.js",
			"/assets/MoneyAccountPick-BX8QzfFv.js",
			"/assets/footers-BCvljdqa.js",
			"/assets/PrintFrame-YHFEVg_g.js",
			"/assets/serials-Blf8gLLO.js",
			"/assets/SerialsBox-CKnq93JG.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BQ1CL5bs.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CvLmDkcS.js",
			"/assets/switch-DiJQ4ia_.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-D5cNFrMP.js",
			"/assets/SideList-7D0asKHr.js",
			"/assets/tabs-B8J5fSLz.js",
			"/assets/StockDialogs-jaxO4Tlg.js",
			"/assets/photos-BdoiSzGc.js",
			"/assets/stockmove-DmaLA91I.js",
			"/assets/serials-Blf8gLLO.js",
			"/assets/SerialsBox-CKnq93JG.js",
			"/assets/workorders-DG5Q95UT.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-iMLFV3aG.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/ChangeHistory-CvLmDkcS.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/booksStart-B45127Ry.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/SideList-7D0asKHr.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-DdVVzRUY.js",
			"/assets/NewProductDialog-CMg7bfIh.js",
			"/assets/MoneyAccountPick-BX8QzfFv.js",
			"/assets/footers-BCvljdqa.js",
			"/assets/PrintFrame-YHFEVg_g.js",
			"/assets/cardpay-xKNLLyVG.js",
			"/assets/checkbox-DInqmvXh.js",
			"/assets/serials-Blf8gLLO.js",
			"/assets/workorders-DG5Q95UT.js",
			"/assets/RepeatInvoice-CL6hSxOG.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BD5vUJfq.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DqI_rbqz.js",
			"/assets/select-AiG0w0PS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/SideList-7D0asKHr.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-DHCteIRX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/quickadd-DKrsVkGF.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DydvMwg0.js",
			"/assets/support.functions-CEhAhDAv.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DWR3jCyh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CEPaRSZ7.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/SideList-7D0asKHr.js",
			"/assets/PartyHistory-LrmISFxC.js",
			"/assets/tabs-B8J5fSLz.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BeFReLJg.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/sales-6EX_V2cn.js",
			"/assets/footers-BCvljdqa.js",
			"/assets/tickets.functions-BD5vUJfq.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BiuCRXvR.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/input-ELSWVf5M.js",
			"/assets/skeleton-3-z60wyj.js",
			"/assets/AdminAccount-KgiT_-cC.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-DzoyTULb.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-DjXXlHgv.js",
			"/assets/textarea-GblDytQh.js",
			"/assets/support-DydvMwg0.js",
			"/assets/support.functions-CEhAhDAv.js",
			"/assets/HelpParts-CqKQ74XA.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-B97O8pkf.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-3-z60wyj.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
