import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as payeeKey } from "./bankfile-DkbAjhEw.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/reminders-Dlub3iPA.js
/**
* Bills and subscriptions to remember (step 44). Tracking only: paying still happens in the
* registers, Write Checks or Recurring (for automatic entries). Bank and card lines show what was
* paid, and repeating charges in them are suggested as subscriptions.
*/
var tbl = (t) => db.from(t);
var EVERY_LABEL = {
	week: "Every week",
	month: "Every month",
	quarter: "Every 3 months",
	year: "Every year"
};
var PER_MONTH = {
	week: 52 / 12,
	month: 1,
	quarter: 1 / 3,
	year: 1 / 12
};
var perMonth = (r) => Math.round((r.amount ?? 0) * PER_MONTH[r.every] * 100) / 100;
var iso = (d) => d.toLocaleDateString("en-CA");
var day = (s) => /* @__PURE__ */ new Date(`${s}T12:00:00`);
var daysBetween = (a, b) => Math.round((day(b).getTime() - day(a).getTime()) / 864e5);
/** The date after this one, keeping the day of the month (Jan 31 → Feb 28 → Mar 31). */
function nextDate(from, every, anchorDay) {
	const d = day(from);
	if (every === "week") {
		d.setDate(d.getDate() + 7);
		return iso(d);
	}
	const months = every === "month" ? 1 : every === "quarter" ? 3 : 12;
	const want = anchorDay ?? d.getDate();
	const t = new Date(d.getFullYear(), d.getMonth() + months, 1, 12);
	const last = new Date(t.getFullYear(), t.getMonth() + 1, 0).getDate();
	t.setDate(Math.min(want, last));
	return iso(t);
}
function useReminders() {
	return useQuery({
		queryKey: ["money-reminders"],
		queryFn: async () => (await fetchAll("money_reminders", "id,kind,name,amount,every,next_date,account_id,category_id,autopay,status,match_text,last_paid,member_id,notes")).map((r) => ({
			...r,
			amount: r.amount == null ? null : Number(r.amount)
		}))
	});
}
/** Bank and card lines from the last 13 months (money out only). */
function useMoneyOut() {
	return useQuery({
		queryKey: ["bank-lines-out"],
		queryFn: async () => {
			const since = /* @__PURE__ */ new Date();
			since.setMonth(since.getMonth() - 13);
			const from = iso(since);
			const out = [];
			for (let i = 0;; i += 1e3) {
				const { data, error } = await db.from("bank_transactions").select("account_id,amount,description,txn_date").lt("amount", 0).gte("txn_date", from).order("txn_date").range(i, i + 999);
				if (error) throw error;
				out.push(...(data ?? []).map((l) => ({
					...l,
					amount: -Number(l.amount)
				})));
				if (!data || data.length < 1e3) break;
			}
			return out;
		}
	});
}
var norm = (s) => (s ?? "").toLowerCase().replace(/\s+/g, " ").trim();
/** A bank or card line near the due date that looks like this bill being paid. */
function findPayment(r, lines) {
	const words = norm(r.match_text) || norm(payeeKey(r.name));
	if (!words) return null;
	return lines.find((l) => {
		const gap = daysBetween(r.next_date, l.txn_date);
		if (gap < -10 || gap > 10) return false;
		if (r.account_id && l.account_id !== r.account_id) return false;
		if (r.amount && Math.abs(l.amount - r.amount) > Math.max(1, r.amount * .15)) return false;
		return norm(l.description).includes(words) || norm(payeeKey(l.description)) === words;
	}) ?? null;
}
/**
* Charges that repeat: the same payee, same account and same amount at least 3 times about a
* month apart (or 4 times a week apart, or twice a year apart).
*/
function findRepeats(lines, known) {
	const groups = /* @__PURE__ */ new Map();
	for (const l of lines) {
		const p = payeeKey(l.description);
		if (!p) continue;
		const k = `${l.account_id}|${p}|${l.amount.toFixed(2)}`;
		groups.set(k, [...groups.get(k) ?? [], l]);
	}
	const taken = known.map((r) => norm(r.match_text) || norm(payeeKey(r.name))).filter(Boolean);
	const out = [];
	for (const [k, g] of groups) {
		if (g.length < 2) continue;
		const dates = [...new Set(g.map((l) => l.txn_date))].sort();
		const gaps = dates.slice(1).map((d, i) => daysBetween(dates[i], d));
		const all = (lo, hi) => gaps.length > 0 && gaps.every((x) => x >= lo && x <= hi);
		const every = dates.length >= 3 && all(25, 35) ? "month" : dates.length >= 4 && all(6, 8) ? "week" : dates.length >= 2 && all(355, 375) ? "year" : dates.length >= 2 && all(85, 98) ? "quarter" : null;
		if (!every) continue;
		const period = {
			week: 7,
			month: 31,
			quarter: 92,
			year: 366
		}[every];
		if (daysBetween(dates.at(-1), iso(/* @__PURE__ */ new Date())) > period * 1.6) continue;
		const [account_id, payee] = k.split("|");
		if (taken.some((t) => norm(payee).includes(t) || t.includes(norm(payee)))) continue;
		const last = dates.at(-1);
		out.push({
			key: k,
			name: payee.replace(/\.(COM|NET|ORG|IO|CO)\b/g, "").replace(/\s+[A-Z]{2}$/, "").replace(/\b\w+/g, (w) => w[0] + w.slice(1).toLowerCase()).trim() || payee,
			match: payee,
			account_id,
			amount: g[0].amount,
			every,
			count: dates.length,
			last,
			next: nextDate(last, every)
		});
	}
	return out.sort((a, b) => b.amount * PER_MONTH[b.every] - a.amount * PER_MONTH[a.every]);
}
//#endregion
export { nextDate as a, useMoneyOut as c, findRepeats as i, useReminders as l, daysBetween as n, perMonth as o, findPayment as r, tbl as s, EVERY_LABEL as t };
