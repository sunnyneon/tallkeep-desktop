import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { l as require_react_dom, u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, at as Mail } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { n as makePdf, r as sendDocEmail, t as blobToBase64 } from "./DocPdf-DZcpJXYJ.mjs";
import { n as useCompanyLogo } from "./PrintFrame-PJ2rEoZR.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/statements-Br31JYKP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
var AGE = [
	"Current",
	"1–30 days late",
	"31–60",
	"61–90",
	"Over 90"
];
var ageOf = (due, asOf) => {
	const d = (Date.parse(`${asOf}T12:00:00`) - Date.parse(`${due}T12:00:00`)) / 864e5;
	return d <= 0 ? 0 : d <= 30 ? 1 : d <= 60 ? 2 : d <= 90 ? 3 : 4;
};
function Statements() {
	const [asOf, setAsOf] = (0, import_react.useState)(today());
	const [q, setQ] = (0, import_react.useState)("");
	const [pick, setPick] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("Thank you for your business! Please send payment for anything past due.");
	const { data, isLoading } = useQuery({
		queryKey: ["statements"],
		queryFn: async () => {
			const [inv, cust, co, pays] = await Promise.all([
				db.from("sales_orders").select("id,customer_id,customer_name,number,invoice_date,order_date,due_date,total,amount_paid,balance,status").in("status", [
					"invoiced",
					"paid",
					"completed"
				]).gt("balance", 0).limit(2e4),
				fetchAll("customers", "id,name,billing_address,address,email"),
				db.from("company_settings").select("name,address,mailing_address,phone,email,website").maybeSingle(),
				db.from("payments").select("amount,paid_on,method,sales_orders!inner(customer_id,number)").not("sales_order_id", "is", null).gte("paid_on", (/* @__PURE__ */ new Date(Date.now() - 3888e6)).toISOString()).limit(5e3)
			]);
			if (inv.error) throw inv.error;
			return {
				invoices: (inv.data ?? []).filter((o) => !o.number.startsWith("RMA-") && o.customer_id).map((o) => ({
					...o,
					total: Number(o.total),
					amount_paid: Number(o.amount_paid),
					balance: Number(o.balance)
				})),
				customers: new Map(cust.map((c) => [c.id, c])),
				co: co.data ?? {},
				payments: pays.data ?? []
			};
		}
	});
	const groups = (0, import_react.useMemo)(() => {
		const by = /* @__PURE__ */ new Map();
		for (const o of data?.invoices ?? []) {
			if ((o.invoice_date ?? o.order_date).slice(0, 10) > asOf) continue;
			by.set(o.customer_id, [...by.get(o.customer_id) ?? [], o]);
		}
		const list = [...by.entries()].map(([id, inv]) => ({
			id,
			name: data?.customers.get(id)?.name ?? inv[0].customer_name ?? "",
			inv: inv.sort((a, b) => (a.invoice_date ?? a.order_date).localeCompare(b.invoice_date ?? b.order_date)),
			owed: inv.reduce((s, o) => s + o.balance, 0)
		}));
		return smartSearch(list.sort((a, b) => a.name.localeCompare(b.name)), q, (g) => g.name);
	}, [
		data,
		asOf,
		q
	]);
	const [lateOnly, setLateOnly] = (0, import_react.useState)(false);
	const [mailing, setMailing] = (0, import_react.useState)(false);
	const isLate = (g) => g.inv.some((o) => (o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10) < asOf);
	const shown = lateOnly ? groups.filter(isLate) : groups;
	const chosen = shown.filter((g) => pick ? pick.has(g.id) : true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
					title: "Statements",
					text: "A statement for each customer: every invoice they still owe, how late it is, and the total. Print them, or email each customer their own statement or a payment reminder."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Statement date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: asOf,
								onChange: (e) => setAsOf(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "max-w-xs",
							placeholder: "Search customers",
							value: q,
							onChange: (e) => setQ(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setPick(null),
							children: "Tick all"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setPick(/* @__PURE__ */ new Set()),
							children: "Clear"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: lateOnly,
								onChange: (e) => setLateOnly(e.target.checked)
							}), "Only customers with past-due invoices"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setMailing(true),
							disabled: !chosen.length,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email…"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => window.print(),
							disabled: !chosen.length,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }),
								" Print ",
								chosen.length,
								" statement",
								chosen.length === 1 ? "" : "s"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "Note at the bottom"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						onChange: (e) => setNote(e.target.value)
					})]
				}),
				isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
					children: [data && shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-8 text-center text-muted-foreground",
						children: q.trim() ? `No customer matching "${q.trim()}" has an unpaid invoice on this date.` : lateOnly && groups.length ? "Nobody is past due on this date." : "Nobody owes anything on this date. Statements list only customers with unpaid invoices."
					}), shown.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer items-center gap-3 px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: pick ? pick.has(g.id) : true,
								onChange: (e) => {
									const n = new Set(pick ?? shown.map((x) => x.id));
									if (e.target.checked) n.add(g.id);
									else n.delete(g.id);
									setPick(n);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [g.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [
										g.inv.length,
										" open invoice",
										g.inv.length === 1 ? "" : "s",
										isLate(g) ? " · past due" : "",
										data?.customers.get(g.id)?.email ? "" : " · no email"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: fmtMoney(g.owed)
							})
						]
					}, g.id))]
				})
			]
		}),
		mailing && data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailStatements, {
			groups: chosen,
			customers: data.customers,
			co: data.co,
			asOf,
			note,
			onClose: () => setMailing(false)
		}),
		typeof document !== "undefined" && data && (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "statement-print hidden bg-white text-black print:block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: "@page { size: letter; margin: 0.5in } @media print { body > *:not(.statement-print) { display: none !important } }" }), chosen.map((g) => {
				const c = data.customers.get(g.id);
				const ages = [
					0,
					0,
					0,
					0,
					0
				];
				for (const o of g.inv) ages[ageOf((o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10), asOf)] += o.balance;
				const paid = data.payments.filter((p) => p.sales_orders.customer_id === g.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10pt]",
					style: { pageBreakAfter: "always" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[14pt] font-bold",
									children: data.co.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "whitespace-pre-line",
									children: data.co.mailing_address || data.co.address
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: [
									data.co.phone,
									data.co.email,
									data.co.website
								].filter(Boolean).join(" · ") })
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[18pt] font-bold",
										children: "Statement"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Date: ", fmtDate(asOf)] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-2 text-[12pt] font-bold",
										children: ["Amount due: ", fmtMoney(g.owed)]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[8pt] uppercase text-gray-500",
									children: "To"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: g.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "whitespace-pre-line",
									children: c?.billing_address || c?.address
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "mt-6 w-full border-collapse",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b-2 border-black text-left",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Invoice"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1",
										children: "Due"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right",
										children: "Amount"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right",
										children: "Paid"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-1 text-right",
										children: "Still owed"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: g.inv.map((o) => {
								const due = (o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-gray-300",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1",
											children: fmtDate((o.invoice_date ?? o.order_date).slice(0, 10))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1",
											children: o.number
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `py-1 ${due < asOf ? "font-semibold" : ""}`,
											children: fmtDate(due)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1 text-right",
											children: fmtMoney(o.total)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1 text-right",
											children: o.amount_paid ? fmtMoney(o.amount_paid) : ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1 text-right",
											children: fmtMoney(o.balance)
										})
									]
								}, o.id);
							}) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "mt-4 w-full border-collapse text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-black",
								children: [AGE.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 font-medium",
									children: a
								}, a)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 font-bold",
									children: "Total due"
								})]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [ages.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1",
								children: fmtMoney(x)
							}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 font-bold",
								children: fmtMoney(g.owed)
							})] }) })]
						}),
						paid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Payments received lately — thank you"
							}), paid.slice(0, 8).map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								fmtDate(p.paid_on.slice(0, 10)),
								" · ",
								p.sales_orders.number,
								p.method ? ` · ${p.method}` : "",
								" · ",
								fmtMoney(Number(p.amount))
							] }, i))]
						}),
						note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6",
							children: note
						})
					]
				}, g.id);
			})]
		}), document.body)
	] });
}
/** The statement as a PDF (same layout as invoices). */
function statementPdf(g, c, co, asOf, note, logo) {
	const ages = [
		0,
		0,
		0,
		0,
		0
	];
	for (const o of g.inv) ages[ageOf((o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10), asOf)] += o.balance;
	return {
		title: "STATEMENT",
		logo,
		company: {
			name: co.name ?? "",
			address: co.mailing_address || co.address || null,
			phone: co.phone,
			email: co.email,
			website: co.website
		},
		facts: [["Date", fmtDate(asOf)], ["Amount due", fmtMoney(g.owed)]],
		leftTitle: "TO",
		left: [g.name, c?.billing_address || c?.address].filter(Boolean).join("\n"),
		rightTitle: "",
		right: "",
		columns: [
			"Invoice",
			"Due",
			"Amount",
			"Paid",
			"Still owed"
		],
		lines: g.inv.map((o) => ({
			desc: `${o.number} · ${fmtDate((o.invoice_date ?? o.order_date).slice(0, 10))}`,
			qty: fmtDate((o.due_date ?? o.invoice_date ?? o.order_date).slice(0, 10)),
			price: fmtMoney(o.total),
			disc: o.amount_paid ? fmtMoney(o.amount_paid) : "",
			total: fmtMoney(o.balance)
		})),
		remarks: note || null,
		totals: [...AGE.map((a, i) => ({
			label: a,
			value: fmtMoney(ages[i])
		})).filter((x, i) => ages[i] > 0 || i === 0), {
			label: "Total due",
			value: fmtMoney(g.owed),
			big: true
		}]
	};
}
function EmailStatements({ groups, customers, co, asOf, note, onClose }) {
	const logoPath = useCompanyLogo();
	const [kind, setKind] = (0, import_react.useState)("statement");
	const coName = co.name ?? "us";
	const subjects = {
		statement: `Your statement from ${coName}`,
		reminder: `Friendly reminder: invoices past due — ${coName}`
	};
	const messages = {
		statement: `Hello {name},\n\nAttached is your statement as of ${fmtDate(asOf)}. The total due is {total}.\n\nThank you for your business!\n${coName}`,
		reminder: `Hello {name},\n\nThis is a friendly reminder that some invoices are past due. The total due is {total}; the attached statement lists each invoice.\n\nIf you've already sent payment, thank you — please ignore this note.\n${coName}`
	};
	const [subject, setSubject] = (0, import_react.useState)(subjects.statement);
	const [message, setMessage] = (0, import_react.useState)(messages.statement);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(0);
	const withEmail = groups.filter((g) => customers.get(g.id)?.email);
	const skipped = groups.length - withEmail.length;
	async function send() {
		setBusy(true);
		let ok = 0;
		const failed = [];
		const logo = logoPath ? new URL(logoPath, window.location.href).href : "";
		for (const g of withEmail) {
			const c = customers.get(g.id);
			try {
				const blob = await makePdf(statementPdf(g, c, co, asOf, note, logo));
				const fill = (t) => t.replaceAll("{name}", g.name).replaceAll("{total}", fmtMoney(g.owed));
				await sendDocEmail({ data: {
					to: c.email.split(/[,;\s]+/).filter(Boolean),
					cc: [],
					subject: fill(subject),
					message: fill(message),
					filename: `Statement ${asOf} - ${g.name.replace(/[^\w\- ]+/g, "")}.pdf`,
					pdfBase64: await blobToBase64(blob)
				} });
				ok++;
				setDone(ok);
			} catch (e) {
				failed.push(`${g.name}: ${e.message}`);
			}
		}
		setBusy(false);
		if (ok) toast.success(`Sent ${ok} email${ok === 1 ? "" : "s"}.`);
		if (failed.length) toast.error(`Not sent: ${failed.slice(0, 3).join("; ")}${failed.length > 3 ? "…" : ""}`);
		if (!failed.length) onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && !busy && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Email statements" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"Each customer gets their own statement as a PDF, from your company email. Write",
					" ",
					"{name}",
					" and ",
					"{total}",
					" to fill in their name and amount."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "inline-flex rounded-lg border p-0.5",
							children: [["statement", "Statement"], ["reminder", "Payment reminder"]].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setKind(k);
									setSubject(subjects[k]);
									setMessage(messages[k]);
								},
								className: `rounded-md px-3 py-1 ${kind === k ? "bg-[var(--section)] text-white" : ""}`,
								children: l
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Subject"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: subject,
								onChange: (e) => setSubject(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Message"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 8,
								value: message,
								onChange: (e) => setMessage(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Goes to ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: withEmail.length }),
							" customer",
							withEmail.length === 1 ? "" : "s",
							skipped ? ` (${skipped} without an email address are left out — add it on their customer page)` : "",
							"."
						] }),
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"Sending… ",
								done,
								" of ",
								withEmail.length
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					disabled: busy,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void send(),
					disabled: busy || !withEmail.length,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
						" ",
						busy ? "Sending…" : `Send ${withEmail.length} email${withEmail.length === 1 ? "" : "s"}`
					]
				})] })
			]
		})
	});
}
//#endregion
export { Statements as component };
