import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/website-tickets-CSGjDi8O.js
var $$splitComponentImporter = () => import("./website-tickets-RfbDU9tK.mjs");
var Route = createFileRoute("/_authenticated/website-tickets")({
	head: () => ({ meta: [{ title: "Tickets · Tallkeep" }, {
		name: "description",
		content: "Service tickets from sunriseled.com."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var BILLING_LABEL = {
	free: "No charge",
	pending_quote: "Needs quote",
	quoted: "Quote sent",
	po_quoted: "PO quote sent",
	po_received: "PO received",
	po_invoiced: "Invoiced",
	paid: "Paid",
	cancelled: "Cancelled"
};
var BILLING_STYLE = {
	paid: "bg-emerald-100 text-emerald-800",
	po_invoiced: "bg-red-100 text-red-800",
	quoted: "bg-amber-100 text-amber-800",
	po_quoted: "bg-amber-100 text-amber-800",
	po_received: "bg-orange-100 text-orange-800",
	pending_quote: "bg-sky-100 text-sky-800",
	free: "bg-muted text-muted-foreground",
	cancelled: "bg-muted text-muted-foreground line-through"
};
//#endregion
export { BILLING_STYLE as n, Route as r, BILLING_LABEL as t };
