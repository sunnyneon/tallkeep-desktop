//#region ../../node_modules/.nitro/vite/services/ssr/assets/version-2nRy_v31.js
/**
* App version. Bump APP_VERSION with each set of changes (major.minor.patch).
* BUILD_TIME is stamped when Lovable builds the app, so the preview and the
* published site (office.sunriseled.com) can be compared at a glance.
*/
var APP_VERSION = "1.65.0-test";
var BUILD_TIME = "2026-11-07T15:16:42.849Z";
/** "Desktop" in the office version, "Live" on the published addresses, "Preview" elsewhere (Lovable). */
function siteKind() {
	if ({
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
		"VITE_SUPABASE_URL": "http://localhost:4600",
		"VITE_TALLKEEP_DESKTOP": "1"
	}["VITE_TALLKEEP_DESKTOP"]) return "Desktop";
	if (typeof window === "undefined") return "Live";
	return [
		"office.sunriseled.com",
		"app.tallkeep.com",
		"admin.tallkeep.com"
	].includes(window.location.hostname) ? "Live" : "Preview";
}
function versionLabel() {
	const built = (/* @__PURE__ */ new Date(BUILD_TIME)).toLocaleString("en-US", {
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
	return `v${APP_VERSION}${built ? ` · built ${built}` : ""}`;
}
//#endregion
export { siteKind as n, versionLabel as r, APP_VERSION as t };
