import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { lt as LoaderCircle, st as Lock } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as BuyFrame } from "./buy-BkQzxVla.mjs";
import { t as Route } from "./upgrade-8s1LH8zV.mjs";
import { getUpgradeInfo, renewedUntil, startUpgrade } from "./upgrade.functions-BeuaNEp5.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade-BLS0dSF6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Renew updates or add companies/people to a Tallkeep Desktop license. No sign-in. */
var usd = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
});
var date = (d) => (/* @__PURE__ */ new Date(`${d}T12:00:00`)).toLocaleDateString(void 0, {
	month: "short",
	day: "numeric",
	year: "numeric"
});
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: label
		}), children]
	});
}
function UpgradePage() {
	const search = Route.useSearch();
	const [who, setWho] = (0, import_react.useState)({
		license: search.license ?? "",
		email: search.email ?? ""
	});
	const [info, setInfo] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [renew, setRenew] = (0, import_react.useState)(true);
	const [addC, setAddC] = (0, import_react.useState)("");
	const [addU, setAddU] = (0, import_react.useState)("");
	async function look(e) {
		e?.preventDefault();
		setBusy(true);
		try {
			const i = await getUpgradeInfo({ data: who });
			setInfo(i);
			const left = i.updatesUntil ? Date.parse(i.updatesUntil) - Date.now() : 0;
			setRenew(left < 5184e6);
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	const c = Math.max(0, Math.floor(Number(addC) || 0));
	const u = Math.max(0, Math.floor(Number(addU) || 0));
	const total = info ? (renew ? info.renewPrice : 0) + (info.companies == null ? 0 : c * info.extraCompany) + (info.users == null ? 0 : u * info.extraUser) : 0;
	async function pay() {
		setBusy(true);
		try {
			const r = await startUpgrade({ data: {
				...who,
				renew,
				addCompanies: c,
				addUsers: u,
				origin: window.location.origin
			} });
			window.location.href = r.url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-semibold",
			children: "Renew or upgrade Tallkeep"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Get another year of updates, or add companies or people to your license. Your office computer picks up the new key by itself."
		})] }), !info ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: look,
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "License number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: who.license,
							onChange: (e) => setWho({
								...who,
								license: e.target.value
							}),
							placeholder: "ABCD-1234",
							required: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your email or business name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: who.email,
							onChange: (e) => setWho({
								...who,
								email: e.target.value
							}),
							placeholder: "you@business.com or Business Name",
							required: true
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-muted/40 p-3 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-foreground",
						children: "Where do I find the license number?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-1 list-disc space-y-0.5 pl-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"In Tallkeep, open ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Settings → Plan & computer" }),
							". It's under",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Your license" }),
							" (like ABCD-1234). The ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Renew updates" }),
							" button there fills this page in for you."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Or in the email with your license key, after \"License number\"." })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					disabled: busy,
					children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Find my license"]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-muted/40 p-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							info.to,
							" · license ",
							info.id
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"Now: ",
							info.companies == null ? "any number of" : info.companies,
							" ",
							info.companies === 1 ? "company" : "companies",
							",",
							" ",
							info.users == null ? "any number of" : info.users,
							" ",
							info.users === 1 ? "person" : "people",
							info.updatesUntil ? `, updates ${info.updatesUntil < (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) ? "ended" : "until"} ${date(info.updatesUntil)}` : "",
							"."
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-3 rounded-xl border p-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-1",
							checked: renew,
							onChange: (e) => setRenew(e.target.checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: "Renew updates for 1 more year"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-muted-foreground",
								children: [
									"New versions until ",
									date(renewedUntil(info.updatesUntil)),
									"."
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: usd(info.renewPrice)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [info.companies != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Add companies (${usd(info.extraCompany)} each)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							value: addC,
							onChange: (e) => setAddC(e.target.value),
							placeholder: "0"
						})
					}), info.users != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Add people (${usd(info.extraUser)} each)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							value: addU,
							onChange: (e) => setAddU(e.target.value),
							placeholder: "0"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between rounded-xl bg-muted/40 p-4 text-base font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total, one time" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(total) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "w-full",
					onClick: () => void pay(),
					disabled: busy || total <= 0 || !info.ready,
					children: [
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
						"Pay ",
						usd(total),
						" with card"
					]
				}),
				!info.ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm",
					children: "Paying online opens soon. Email hello@tallkeep.com."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-xs text-muted-foreground",
					children: "Secure payment by Stripe. Questions? hello@tallkeep.com"
				})
			]
		})]
	}) });
}
//#endregion
export { UpgradePage as component };
