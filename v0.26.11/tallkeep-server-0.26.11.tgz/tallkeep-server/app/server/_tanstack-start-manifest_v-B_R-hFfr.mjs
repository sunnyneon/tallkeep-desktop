//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_R-hFfr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-Bh5Jsbie.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-CZ7cgvU6.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BuMrNymb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bh5Jsbie.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-B1nciLKC.js",
			"/assets/log-out-BuSUHDWn.js",
			"/assets/testers.functions-BjsfccOl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DL6K1eG6.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DuI0o9sI.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-D4DSero1.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/dist-B828JMJH.js",
			"/assets/dialog-njaeWpmv.js",
			"/assets/queries-CoSPxC26.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/label-bEysvWnD.js",
			"/assets/textarea-bTi-Y1T2.js",
			"/assets/shoebox-B7AtI-1-.js",
			"/assets/company-DL1mZoBc.js",
			"/assets/reports-DNETJ9zq.js",
			"/assets/access-BhvexVPy.js",
			"/assets/LicenseCard-Ch7Db7zG.js",
			"/assets/Logo-CBXMW_qX.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Csub1KWy.js",
			"/assets/log-out-BuSUHDWn.js",
			"/assets/admin.functions-EjcVlH_i.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CBXMW_qX.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CgJ0pmuI.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/label-bEysvWnD.js",
			"/assets/Logo-CBXMW_qX.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-B6K6i88B.js",
			"/assets/testers.functions-BjsfccOl.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/buy.functions-BrnyZh4z.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-B_TN883H.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/downloads.functions-Dylvurgb.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-BH4zdanO.js",
			"/assets/testers.functions-BjsfccOl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/textarea-bTi-Y1T2.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BMUujcFv.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/label-bEysvWnD.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-ByB922nE.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/label-bEysvWnD.js",
			"/assets/Logo-CBXMW_qX.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CjECv_AM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/upgrade.functions-BlmCVmb2.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-Bg0ccIPS.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/label-bEysvWnD.js",
			"/assets/Logo-CBXMW_qX.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DM-SkryE.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DmtdSjKF.js", "/assets/StockDocList-D6tMw8cf.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DAy8iZ8I.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/ai-BG3w1I0S.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-gQS81s0r.js",
			"/assets/BankConnections-QWqr9qy0.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BVQtRe8e.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-ez5gXGMi.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-QWqr9qy0.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/ai-BG3w1I0S.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BBaGv_wI.js",
			"/assets/TxnEditor-BtRREQAC.js",
			"/assets/feedWaiting-beJHzfz4.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-D2kpQRoJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-Czf-IfuW.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/personal-atQWu0tR.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/WhoPicker-ChvoiHmy.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-TebpqTCg.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BUzXn3am.js", "/assets/AccountRegister-DP9RvSU-.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BZP9E77l.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CIkcL73o.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/money-CT9DIoWU.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-q1VShOIh.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BG3w1I0S.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-jzJU-NBa.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BfAcNevc.js", "/assets/StockDocList-D6tMw8cf.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CziuTrAF.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-SdeD56Dq.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BVFWgLn3.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D6GS3M6O.js", "/assets/PartyList-DZAZ0w8o.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BRb771-W.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-By1Vjb9E.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/storage.functions-CeytChlb.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-DcQ2IgiG.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-5gHbypYV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-OtI_3WhA.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-yO3GegsC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-JiAi42wM.js", "/assets/ChangeHistory-W-kbxeT8.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CZJGeHSt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/members-o2KdwWGG.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-B4iolp92.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/personal-atQWu0tR.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/WhoPicker-ChvoiHmy.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-Brahh_Pt.js", "/assets/SalesList-CCNvR4En.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CPT2uanh.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-C1bVw7jD.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-OBVetzY0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CGPU-xLc.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/loans-BBaGv_wI.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-BCd_ones.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Cw5Q_ipN.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-K9eP8lqN.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/personal-atQWu0tR.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/WhoPicker-ChvoiHmy.js",
			"/assets/reminders-bO9HSeQc.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DkgVXAJ3.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CmEawCyw.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/personal-atQWu0tR.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/WhoPicker-ChvoiHmy.js",
			"/assets/generateCategoricalChart-fyYw3Qr1.js",
			"/assets/Area-B8M3qeBb.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-BL1JOoxB.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/generateCategoricalChart-fyYw3Qr1.js",
			"/assets/PlCharts-OtI_3WhA.js",
			"/assets/BarChart-DgNhRSxR.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CSKnhUn5.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BMki9nbS.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan--0DeDom1.js",
			"/assets/createServerFn-u_1Vpj7L.js",
			"/assets/auth-middleware-BlWjcMH0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/storage.functions-CeytChlb.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BSb7XAIi.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Dasc9KSE.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/checkbox-C8UXocwL.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DMe4t5om.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CUUe2Ls-.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BiheD-xs.js", "/assets/SalesList-CCNvR4En.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BzDfStsw.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/ai-BG3w1I0S.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CeytChlb.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CCX9_uMi.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/money-CT9DIoWU.js",
			"/assets/badge-DnXnwM7H.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-D2l13pAr.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DPu2Zm0m.js", "/assets/AccountRegister-DP9RvSU-.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-bHiSavW3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/MoneyAccountPick-DiBLTw-v.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-9gMWEJ4_.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-S7dNK7u0.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/RepeatInvoice-FbzJ_c7Y.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BjoCR7e0.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-fyYw3Qr1.js",
			"/assets/BarChart-DgNhRSxR.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-C0mFSJex.js", "/assets/SalesList-CCNvR4En.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-BEgAP8g8.js", "/assets/SalesList-CCNvR4En.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Cy9BXHwK.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DbMWW0Oe.js",
			"/assets/createServerFn-u_1Vpj7L.js",
			"/assets/auth-middleware-BlWjcMH0.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-DMeN-6V2.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DTPtCqrH.js",
			"/assets/switch-Cw5Q_ipN.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-BVFWgLn3.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BDnjG4uW.js",
			"/assets/footers-CS6Qi0jH.js",
			"/assets/PrintFrame-RFs2Y67W.js",
			"/assets/checkbox-C8UXocwL.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-CxKTLIwg.js",
			"/assets/FeaturePicker-BPa2K4tw.js",
			"/assets/support-CyHjo7cR.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CUaVQeQM.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/FeaturePicker-BPa2K4tw.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-Bu-mbpb5.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Dt_d0XpU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/photos-BDnjG4uW.js",
			"/assets/stockmove-C0a7Zve0.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BVRGAxUh.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/loans-BBaGv_wI.js",
			"/assets/feedWaiting-beJHzfz4.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CeytChlb.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CCi3kWd5.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/PrintFrame-RFs2Y67W.js",
			"/assets/DocPdf-H_GhDLlg.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-Cr9nWpzc.js",
			"/assets/createServerFn-u_1Vpj7L.js",
			"/assets/auth-middleware-BlWjcMH0.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/MoneyAccountPick-DiBLTw-v.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CyHjo7cR.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C8lXloC-.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/StockDialogs-Dt_d0XpU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/stockmove-C0a7Zve0.js",
			"/assets/checkbox-C8UXocwL.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DFO11_ge.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/members-o2KdwWGG.js",
			"/assets/WhoPicker-ChvoiHmy.js",
			"/assets/reminders-bO9HSeQc.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BPT7z0O4.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/tickets.functions-C7S-9DxU.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Ce-aOHrS.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CyHjo7cR.js",
			"/assets/support.functions-CHyjRLpM.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BJxoleGX.js", "/assets/StockDocList-D6tMw8cf.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-Byl70czy.js", "/assets/PartyList-DZAZ0w8o.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B7ihglAK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/tickets.functions-C7S-9DxU.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-So7L3iU9.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/workorders-BJUdYWM9.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DhFLe7hy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DyBtbyfr.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/AdminAccount-NZfXlXp7.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CQj46gKv.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/downloads.functions-Dylvurgb.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BBS2XFfv.js",
			"/assets/createServerFn-u_1Vpj7L.js",
			"/assets/auth-middleware-BlWjcMH0.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-RUZfCVlO.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BCxkTfMm.js",
			"/assets/testers.functions-BjsfccOl.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-DJRjwG8k.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-DzhG6928.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BrnyZh4z.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Dkjcmwog.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/textarea-bTi-Y1T2.js",
			"/assets/support.functions-CHyjRLpM.js",
			"/assets/HelpParts-C1zwNQKg.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-Cv6VUe2v.js",
			"/assets/ManualFrame-dzs7pIWJ.js",
			"/assets/manual._slug-DFVuIZSW.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-eSusbIYD.js",
			"/assets/createServerFn-u_1Vpj7L.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BDos8lXH.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-BlmCVmb2.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CLGiQR8v.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BG3w1I0S.js",
			"/assets/personal-atQWu0tR.js",
			"/assets/reminders-bO9HSeQc.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B842ks3N.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/AdminAccount-NZfXlXp7.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DNuLShsM.js", "/assets/ManualFrame-dzs7pIWJ.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CaHLFtmg.js", "/assets/AccountRegister-DP9RvSU-.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-97jJQVDl.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/OriginalLink-_zo0CmD5.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/realestate-BNDNrHHH.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-BJYqHSuE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-ii6lp5Bw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/realestate-BNDNrHHH.js",
			"/assets/money-CT9DIoWU.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BoTAa2bC.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/SideList-NbsXhntE.js",
			"/assets/PartyHistory-DoUhqUxQ.js",
			"/assets/tabs-CySB53SQ.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DjqGwzaD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-DMeN-6V2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-W-kbxeT8.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/SideList-NbsXhntE.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-Dc8XegyD.js",
			"/assets/MoneyAccountPick-DiBLTw-v.js",
			"/assets/footers-CS6Qi0jH.js",
			"/assets/PrintFrame-RFs2Y67W.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-UeMcAH8e.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Dt_d0XpU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-W-kbxeT8.js",
			"/assets/switch-Cw5Q_ipN.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/badge-DnXnwM7H.js",
			"/assets/SideList-NbsXhntE.js",
			"/assets/tabs-CySB53SQ.js",
			"/assets/photos-BDnjG4uW.js",
			"/assets/stockmove-C0a7Zve0.js",
			"/assets/workorders-BJUdYWM9.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-D4rfIXX5.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-DMeN-6V2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-W-kbxeT8.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/SideList-NbsXhntE.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-Dc8XegyD.js",
			"/assets/MoneyAccountPick-DiBLTw-v.js",
			"/assets/footers-CS6Qi0jH.js",
			"/assets/PrintFrame-RFs2Y67W.js",
			"/assets/checkbox-C8UXocwL.js",
			"/assets/workorders-BJUdYWM9.js",
			"/assets/RepeatInvoice-FbzJ_c7Y.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-C7S-9DxU.js",
			"/assets/users.functions-CxKTLIwg.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CJ6DF70i.js",
			"/assets/select-CLBuqfa2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/SideList-NbsXhntE.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BAbHZnBr.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/quickadd-DEDzsJZR.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CyHjo7cR.js",
			"/assets/support.functions-CHyjRLpM.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CvzVnkeM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-9QMPKtJZ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/SideList-NbsXhntE.js",
			"/assets/PartyHistory-DoUhqUxQ.js",
			"/assets/tabs-CySB53SQ.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C7R2OBL9.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/sales-jzJU-NBa.js",
			"/assets/footers-CS6Qi0jH.js",
			"/assets/tickets.functions-C7S-9DxU.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-D9vMLEke.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/input-Ct2K7Ns2.js",
			"/assets/skeleton-oYM6y4z9.js",
			"/assets/AdminAccount-NZfXlXp7.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-D2mZx7qg.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CEfPF7dW.js",
			"/assets/textarea-bTi-Y1T2.js",
			"/assets/support-CyHjo7cR.js",
			"/assets/support.functions-CHyjRLpM.js",
			"/assets/HelpParts-C1zwNQKg.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CRbIyRuT.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-oYM6y4z9.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
