import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/recurring-BGD2iHQ6.js
var $$splitComponentImporter = () => import("./recurring-A5ujZX1c.mjs");
var Route = createFileRoute("/_authenticated/recurring")({
	validateSearch: (s) => typeof s["from"] === "string" ? { from: s["from"] } : {},
	head: () => ({ meta: [{ title: "Recurring · Tallkeep" }, {
		name: "description",
		content: "Payments and bills that repeat, like autopay."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
