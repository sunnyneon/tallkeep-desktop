import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ht as ExternalLink, Ut as Download } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as listTechFees } from "./tickets.functions-BJ7tqlCB.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tech-pay-CBl57SkG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUS = {
	requested: {
		label: "Asked to be paid",
		style: "bg-red-100 text-red-800"
	},
	paid: {
		label: "Paid",
		style: "bg-emerald-100 text-emerald-800"
	},
	none: {
		label: "Not asked yet",
		style: "bg-muted text-muted-foreground"
	}
};
function TechPayPage() {
	const { data, isLoading, error } = useQuery({
		queryKey: ["tech-fees"],
		queryFn: () => listTechFees()
	});
	const thisYear = (/* @__PURE__ */ new Date()).getFullYear();
	const [year, setYear] = (0, import_react.useState)(String(thisYear));
	const [show, setShow] = (0, import_react.useState)("requested");
	const years = (0, import_react.useMemo)(() => {
		const y = /* @__PURE__ */ new Set([thisYear]);
		(data ?? []).forEach((f) => f.fee_paid_at && y.add(new Date(f.fee_paid_at).getFullYear()));
		return [...y].sort((a, b) => b - a);
	}, [data, thisYear]);
	const money = (c) => Number(c || 0) / 100;
	const waiting = (data ?? []).filter((f) => f.fee_status === "requested");
	const paidInYear = (data ?? []).filter((f) => f.fee_status === "paid" && f.fee_paid_at && String(new Date(f.fee_paid_at).getFullYear()) === year);
	const perTech = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		paidInYear.forEach((f) => {
			const k = f.technician_email || f.technician;
			const x = m.get(k) ?? {
				name: f.technician,
				email: f.technician_email,
				jobs: 0,
				total: 0
			};
			x.jobs += 1;
			x.total += money(f.technician_fee_cents);
			m.set(k, x);
		});
		return [...m.values()].sort((a, b) => b.total - a.total);
	}, [paidInYear]);
	const rows = (data ?? []).filter((f) => show === "all" ? true : show === "paid" ? f.fee_status === "paid" : f.fee_status === "requested");
	function downloadYear() {
		const head = [
			"Technician",
			"Email",
			"Jobs paid",
			`Total paid ${year}`
		];
		const body = perTech.map((t) => [
			t.name,
			t.email,
			String(t.jobs),
			t.total.toFixed(2)
		]);
		const detail = paidInYear.map((f) => [
			f.technician,
			f.number,
			f.fee_paid_at ? new Date(f.fee_paid_at).toLocaleDateString("en-US") : "",
			money(f.technician_fee_cents).toFixed(2)
		]);
		const csv = [
			head,
			...body,
			[],
			[
				"Technician",
				"Ticket",
				"Paid on",
				"Amount"
			],
			...detail
		].map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, "\"\"")}"`).join(",")).join("\n");
		const a = document.createElement("a");
		a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
		a.download = `Technician pay ${year}.csv`;
		a.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Technician Pay",
				text: "Fees technicians asked for on their job reports, what's been paid, and yearly totals for taxes.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: "https://sunriseled.com/admin/tickets",
						target: "_blank",
						rel: "noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" }), " Pay a technician on the website"]
					})
				})
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/40 p-4 text-sm text-destructive",
				children: error.message
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "Waiting to be paid"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl font-bold text-red-700",
									children: fmtMoney(waiting.reduce((s, f) => s + money(f.technician_fee_cents), 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [waiting.length, " requests"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border bg-card p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted-foreground",
										children: "Paid in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: year,
										onValueChange: setYear,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-7 w-24",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: years.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: String(y),
											children: y
										}, y)) })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl font-bold",
									children: fmtMoney(paidInYear.reduce((s, f) => s + money(f.technician_fee_cents), 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [paidInYear.length, " payments"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center rounded-2xl border bg-card p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "w-full",
								onClick: downloadYear,
								disabled: !perTech.length,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }),
									" Download ",
									year,
									" totals for taxes"
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-2xl border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "border-b px-4 py-2 text-sm font-semibold",
						children: ["Paid per technician in ", year]
					}), perTech.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "px-4 py-3 text-sm text-muted-foreground",
						children: [
							"Nothing paid in ",
							year,
							" yet."
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
						className: "w-full text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y",
							children: perTech.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 font-medium",
									children: t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 text-muted-foreground",
									children: t.email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2 text-right",
									children: [t.jobs, " jobs"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 text-right font-semibold",
									children: fmtMoney(t.total)
								})
							] }, t.email || t.name))
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						["requested", "Asked to be paid"],
						["paid", "Paid"],
						["all", "All"]
					].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShow(k),
						className: `rounded-full border px-3 py-1.5 text-sm font-medium ${show === k ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
						children: label
					}, k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-x-auto rounded-2xl border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Ticket"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Technician"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Asked on"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Paid on"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Notes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 text-right",
									children: "Amount"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y",
							children: rows.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/website-tickets/$id",
										params: { id: String(f.ticket_id) },
										className: "font-medium underline",
										children: f.number
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: f.technician
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-medium ${STATUS[f.fee_status]?.style ?? "bg-muted"}`,
										children: STATUS[f.fee_status]?.label ?? f.fee_status
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: f.fee_requested_at ? fmtDate(f.fee_requested_at) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: f.fee_paid_at ? fmtDate(f.fee_paid_at) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[260px] truncate px-3 py-2 text-muted-foreground",
									children: f.fee_notes
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right font-semibold",
									children: fmtMoney(money(f.technician_fee_cents))
								})
							] }, f.id))
						})]
					}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "Nothing here."
					})]
				})
			] })
		]
	});
}
//#endregion
export { TechPayPage as component };
