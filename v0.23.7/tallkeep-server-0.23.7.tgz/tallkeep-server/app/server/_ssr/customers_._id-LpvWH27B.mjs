import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers_._id-LpvWH27B.js
var $$splitComponentImporter = () => import("./customers_._id-BiY3HCVp.mjs");
var Route = createFileRoute("/_authenticated/customers_/$id")({
	head: () => ({ meta: [{ title: "Customer · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
