import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DeI1XABe.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/testers.functions-DhWH6lBH.js
/**
* Testers before launch, and "Report a problem".
*
* People ask to test on /testers. Tallkeep (Admin → Testers) checks the business and approves or
* declines. Approving makes a free license key that works until TESTER_UNTIL, plus a code for
* 50% off when they buy, and emails both. Problems reported from inside Tallkeep (Help → Report a
* problem) are kept here and emailed to hello@tallkeep.com.
*/
var testers_functions_exports = /* @__PURE__ */ __exportAll({
	TESTER_DISCOUNT_PCT: () => 50,
	TESTER_UNTIL: () => TESTER_UNTIL,
	askToTest: () => askToTest,
	checkTesterCode: () => checkTesterCode,
	holdTesterCode: () => holdTesterCode,
	listProblems: () => listProblems,
	listTesters: () => listTesters,
	markTesterCodeUsed: () => markTesterCodeUsed,
	reportProblem: () => reportProblem,
	reviewTester: () => reviewTester,
	saveProblem: () => saveProblem,
	setProblem: () => setProblem,
	testerCode: () => testerCode
});
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var clean = (v, max) => String(v ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, max);
/** Requests per internet address in the last hour (kept in this server's memory). */
var askToTest = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(createSsrRpc("00611f6528b281a5c3872f2e4bc5790e9e151ff9e66a0d314caa44bf6b1514d9"));
var listTesters = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("e494d86b25d6cb1e5b47bb29942a09b5106938cc3713eabb435e0244de7fe085"));
var reviewTester = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("b8ba26946ba21d048bed7a9b47519e0bd6e1457294f097774b028d2543b4a032"));
/** An approved tester's unused code (for the Buy page). */
async function testerCode(code) {
	const c = String(code ?? "").trim().toUpperCase();
	if (!/^TEST-[A-Z0-9]{6}$/.test(c)) return null;
	const { data } = await (await admin()).from("tester_requests").select("id,code,status,code_used_at,company,code_session").eq("code", c).maybeSingle();
	const r = data;
	if (!r || r.status !== "approved" || r.code_used_at) return null;
	return r;
}
/** The checkout this code is in (one at a time). */
async function holdTesterCode(code, session) {
	await (await admin()).from("tester_requests").update({ code_session: session }).eq("code", code).is("code_used_at", null);
}
async function markTesterCodeUsed(code, session) {
	await (await admin()).from("tester_requests").update({
		code_used_at: (/* @__PURE__ */ new Date()).toISOString(),
		code_session: session
	}).eq("code", code).is("code_used_at", null);
}
var checkTesterCode = createServerFn({ method: "GET" }).inputValidator((d) => ({ code: String(d.code ?? "") })).handler(createSsrRpc("12384f99b5b064dc9d8791957ad225d3e81cc320063f1a7f3a36680e2d998e01"));
/** Keep a report and email it to Tallkeep (used online, and by the desktop through the API). */
async function saveProblem(d) {
	const message = clean(d.message, 8e3);
	if (!message) throw new Error("Tell us what went wrong.");
	const pic = d.picture && /^image\/(png|jpe?g|webp|gif)$/.test(d.picture.type) && d.picture.base64.length < 7e6 ? d.picture : null;
	let licenseId = null;
	if (d.licenseKey) {
		const { keyId } = await import("./license.server-Bu3IQdFy.mjs");
		licenseId = await keyId(String(d.licenseKey)).catch(() => null);
	}
	const row = {
		email: clean(d.email, 200) || null,
		name: clean(d.name, 120) || null,
		company: clean(d.company, 160) || null,
		license_id: licenseId,
		edition: clean(d.edition, 20) || null,
		version: clean(d.version, 40) || null,
		page: clean(d.page, 300) || null,
		message,
		has_picture: !!pic
	};
	const db = await admin();
	const { count } = await db.from("problem_reports").select("id", {
		count: "exact",
		head: true
	}).gte("created_at", (/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString());
	if ((count ?? 0) > 200) throw new Error("Too many reports right now. Try again in an hour.");
	const { error } = await db.from("problem_reports").insert(row);
	if (error) throw new Error(error.message);
	const { sendTallkeepMail } = await import("./license.server-Bu3IQdFy.mjs");
	await sendTallkeepMail({
		to: process.env["LICENSE_COPY_TO"] || "hello@tallkeep.com",
		...row.email ? { replyTo: row.email } : {},
		subject: `Problem report: ${row.company ?? row.email ?? "someone"} · ${row.page ?? ""}`.slice(0, 180),
		text: [
			message,
			"",
			`From: ${row.name ?? "-"} <${row.email ?? "-"}> · ${row.company ?? "-"}`,
			`Page: ${row.page ?? "-"}`,
			`Tallkeep: ${row.edition ?? "-"} ${row.version ?? ""}${licenseId ? ` · license ${licenseId}` : ""}`,
			"",
			"All reports: https://app.tallkeep.com/admin/testers"
		].join("\n"),
		...pic ? { attachments: [{
			filename: pic.name || "picture.png",
			content: pic.base64
		}] } : {}
	}).catch(() => null);
	return { ok: true };
}
var listProblems = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("a0fe38d0ee0bb219de28cfe57f964c6a21fe31a49f0ec1912afe2e12dbe0c9df"));
var setProblem = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("889f4f23e0f328174ed54f2f0fbd7ecb2330a920d633a86ed599a3a931c44695"));
/** "Report a problem" from Tallkeep online (signed in). */
var reportProblem = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("2b55125109e43275df9d428a1a815dc1fc4a26ae3c1c4a252977a8c23afab6c6"));
//#endregion
export { reportProblem as a, testers_functions_exports as c, listTesters as i, checkTesterCode as n, reviewTester as o, listProblems as r, setProblem as s, askToTest as t };
