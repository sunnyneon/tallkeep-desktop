import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/help._slug-mOabi7qk.js
var $$splitComponentImporter = () => import("./help._slug-D0vV-n_2.mjs");
/** A business's support page: customers open a ticket here, no sign-in. */
var Route = createFileRoute("/help/$slug")({
	ssr: false,
	head: () => ({ meta: [{ title: "Support" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
