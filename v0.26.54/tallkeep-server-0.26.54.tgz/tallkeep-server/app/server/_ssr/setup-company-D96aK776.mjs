import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/setup-company-D96aK776.js
var $$splitComponentImporter = () => import("./setup-company-CYTBlpqu.mjs");
var Route = createFileRoute("/_authenticated/setup-company")({
	head: () => ({ meta: [{ title: "Set up a company · Tallkeep" }, {
		name: "description",
		content: "Step-by-step setup of a company."
	}] }),
	validateSearch: (s) => s["welcome"] === true || s["welcome"] === "1" || s["welcome"] === 1 ? { welcome: true } : {},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
