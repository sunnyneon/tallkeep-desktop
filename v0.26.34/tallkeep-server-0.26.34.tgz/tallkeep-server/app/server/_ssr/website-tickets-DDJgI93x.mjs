import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, n as fmtDate } from "./format-BVuRObRk.mjs";
import { t as supabase } from "./client-2oAEFzYT.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { O as Search, dt as LoaderCircle, mt as Link2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as BILLING_STYLE, t as BILLING_LABEL } from "./website-tickets-u0pympZk.mjs";
import { r as listTickets } from "./tickets.functions-BGAadU8H.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/website-tickets-DDJgI93x.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
async function call(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/website${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
/**
* Website Tickets on the office computer: link it to the website with the website key (the same
* OFFICE_SYNC_KEY the website uses). The key stays on this computer; the browser never gets it back.
*/
function WebsiteLinkCard({ onLinked }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [url, setUrl] = (0, import_react.useState)("sunriseled.com");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		try {
			const r = await call("PUT", "", {
				key,
				url
			});
			setKey("");
			if (r.ok) {
				toast.success("Linked. Tickets from the website show here now.");
				onLinked();
			} else toast.error(r.why || "The website didn't answer.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {
					className: "mt-0.5 h-5 w-5 shrink-0",
					style: { color: "var(--section)" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: "Link this computer to your website"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								"Paste the website key: the value of the ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "OFFICE_SYNC_KEY" }),
								" secret, the same one the website and Tallkeep online use. It stays on this computer. Only the account's Owner can save it."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: "Can't see the value? Make a new long key (at least 24 letters and numbers), set it as OFFICE_SYNC_KEY in both Lovable projects (the website and Tallkeep online), publish both, and paste it here."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-[1fr_14rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Website key"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "password",
						autoComplete: "off",
						value: key,
						onChange: (e) => setKey(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Website"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: url,
						onChange: (e) => setUrl(e.target.value)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void save(),
				disabled: busy || key.trim().length < 24,
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Save and link"]
			})
		]
	});
}
var SHOW = [
	{
		key: "done",
		label: "Job done, not paid"
	},
	{
		key: "open",
		label: "Open"
	},
	{
		key: "all",
		label: "All (not archived)"
	},
	{
		key: "archived",
		label: "Archived"
	}
];
function TicketsPage() {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["tickets"],
		queryFn: () => listTickets(),
		retry: false
	});
	const msg = error?.message ?? "";
	const needsKey = msg === "Link the office computer to your website: paste the website key below." || /saved on this computer/.test(msg);
	const [q, setQ] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)("done");
	const fits = (t, k) => {
		if (k === "archived") return !!t.archived_at;
		if (t.archived_at) return false;
		if (k === "done") return !!t.completed_at && t.billing_status !== "paid" && t.billing_status !== "free";
		if (k === "open") return !t.completed_at;
		return true;
	};
	const counts = (0, import_react.useMemo)(() => Object.fromEntries(SHOW.map((x) => [x.key, (data ?? []).filter((t) => fits(t, x.key)).length])), [data]);
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		return (data ?? []).filter((t) => fits(t, show)).filter((t) => {
			const hay = `${t.number} ${t.name ?? ""} ${t.company ?? ""} ${t.email ?? ""} ${t.subject ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
	}, [
		data,
		q,
		show
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Tickets",
				text: "Service tickets from sunriseled.com. Open one to make the final invoice."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: SHOW.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShow(x.key),
					className: `rounded-full border px-3 py-1.5 text-sm font-medium ${show === x.key ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
					children: [x.label, data ? ` (${counts[x.key] ?? 0})` : ""]
				}, x.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-9",
					placeholder: "Search ticket #, customer or subject",
					value: q,
					onChange: (e) => setQ(e.target.value)
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			error && !needsKey && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/40 p-4 text-sm text-destructive",
				children: msg
			}),
			needsKey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [msg !== "Link the office computer to your website: paste the website key below." && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: msg
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteLinkCard, { onLinked: () => void qc.invalidateQueries({ queryKey: ["tickets"] }) })] }),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Ticket"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Customer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Subject"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Billing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Quoted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Job done"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Opened"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: rows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "cursor-pointer hover:bg-muted/50",
							onClick: () => navigate({
								to: "/website-tickets/$id",
								params: { id: String(t.id) }
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-medium",
									style: { color: "var(--section)" },
									children: t.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[220px] truncate px-3 py-2",
									children: t.company || t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[320px] truncate px-3 py-2 text-muted-foreground",
									children: t.subject
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-medium ${BILLING_STYLE[t.billing_status ?? ""] ?? "bg-muted"}`,
										children: BILLING_LABEL[t.billing_status ?? ""] ?? t.billing_status
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: t.quoted_amount_cents ? fmtMoney(t.quoted_amount_cents / 100) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: t.completed_at ? fmtDate(t.completed_at) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-muted-foreground",
									children: fmtDate(t.created_at)
								})
							]
						}, t.id))
					})]
				}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted-foreground",
					children: "No tickets here."
				})]
			})
		]
	});
}
//#endregion
export { TicketsPage as component };
