//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CH5a7M2y.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-9OlqojlJ.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Cirk09bh.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CJ3PfM65.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-9OlqojlJ.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DSdC1MBO.js",
			"/assets/log-out-BpRCtg8h.js",
			"/assets/testers.functions-D9VxlYNK.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CoL71AK9.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DrvRfsYi.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DZcoPT3t.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/dist-DiWBpTD7.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/dist-DpHB_ne6.js",
			"/assets/dialog-CUF3hiOc.js",
			"/assets/queries-BQ1lIPMD.js",
			"/assets/input-D8rZALXG.js",
			"/assets/label-BOcD1ZvQ.js",
			"/assets/textarea-DtB_puzl.js",
			"/assets/shoebox-Bk98kc6F.js",
			"/assets/company-C9uhGDc8.js",
			"/assets/reports-CUX2lGSg.js",
			"/assets/access-6LuF576Z.js",
			"/assets/theme-Dw5DjmHq.js",
			"/assets/Logo-DHJAbuUw.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-BfKfTy75.js",
			"/assets/log-out-BpRCtg8h.js",
			"/assets/admin.functions-DO5WMjLz.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DHJAbuUw.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DcisCJxq.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/label-BOcD1ZvQ.js",
			"/assets/Logo-DHJAbuUw.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Q2gqSJ5h.js",
			"/assets/testers.functions-D9VxlYNK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/coupons.functions-RS1S0Z0w.js",
			"/assets/buy.functions-C4CUVXaG.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-C6khev63.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/downloads.functions-_OGfS0Hr.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-bVDFX8gB.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/label-BOcD1ZvQ.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CcRZ1QMN.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/label-BOcD1ZvQ.js",
			"/assets/Logo-DHJAbuUw.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CWTEG_JM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/upgrade.functions-DB8vA-Is.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-UFHUyj6D.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/label-BOcD1ZvQ.js",
			"/assets/Logo-DHJAbuUw.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-YXXlC3ow.js",
			"/assets/select-BpiBjw88.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BdGMoLlT.js", "/assets/StockDocList-Baew2jDi.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-kfOg18eR.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/ai-B4igPhfg.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Qyr26rCb.js",
			"/assets/BankConnections-fIn-v-SE.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BNHZp9zz.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CkSQSSPP.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-fIn-v-SE.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/ai-B4igPhfg.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-60AVU19A.js",
			"/assets/TxnEditor-BM9N_oSO.js",
			"/assets/feedWaiting-Btzjb5K8.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Cw0azsj8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-C58QMdJw.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CP2h4YcM.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/personal-D__f0mYe.js",
			"/assets/members-1q9qSevk.js",
			"/assets/WhoPicker-3N6fP-iT.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-C4F2O2F9.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BpvwC0lj.js", "/assets/AccountRegister-D3AfgwSZ.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DBhILt0I.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-8VKnd-_A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/money-Bd2DB5tv.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-LQFYQvHx.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B4igPhfg.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-7A72IlSj.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CXPOp52g.js", "/assets/StockDocList-Baew2jDi.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-NumReGng.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CBRU-dwd.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-1q9qSevk.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-ZuFkEwiu.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D1zEPPHZ.js", "/assets/PartyList-B96f3gh_.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Jtkd4bPL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Btfv7fVW.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/storage.functions-CpzyGHhH.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-D72XaKtg.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CRn7WM3A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-qEOtkBkG.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-D-Vzivw8.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-HORbJHB_.js", "/assets/ChangeHistory-BevV2HGx.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BO1F1k7B.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/members-1q9qSevk.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-CkOYbuVl.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/personal-D__f0mYe.js",
			"/assets/members-1q9qSevk.js",
			"/assets/WhoPicker-3N6fP-iT.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DSmSA7hJ.js", "/assets/SalesList-CNb0SEWc.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BHIVNejP.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CRL5Bsll.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DZw-llku.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-DjawQgIO.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/loans-60AVU19A.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CpU6LedV.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-DPTWPI1W.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-KIqqvTE2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/personal-D__f0mYe.js",
			"/assets/members-1q9qSevk.js",
			"/assets/WhoPicker-3N6fP-iT.js",
			"/assets/reminders-g1kV5q-T.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DuSaFe2U.js",
			"/assets/select-BpiBjw88.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-q0PEmsdF.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/personal-D__f0mYe.js",
			"/assets/members-1q9qSevk.js",
			"/assets/WhoPicker-3N6fP-iT.js",
			"/assets/generateCategoricalChart-i6PEH0R9.js",
			"/assets/Area--n1_ZTJR.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-XWzMzmF4.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/generateCategoricalChart-i6PEH0R9.js",
			"/assets/PlCharts-qEOtkBkG.js",
			"/assets/BarChart-D2scxLpd.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-C769mp67.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/balances-C58QMdJw.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CkB_dY3t.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BtHm9Slb.js",
			"/assets/createServerFn-Bo-KX54X.js",
			"/assets/auth-middleware-DfugY9rY.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/storage.functions-CpzyGHhH.js",
			"/assets/coupons.functions-RS1S0Z0w.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CthpcTVz.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BZN8ke6Q.js",
			"/assets/select-BpiBjw88.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/checkbox-C53oSzYR.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-z3ax8rRx.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-B-ogVWeN.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BpiBjw88.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CIFayQi-.js", "/assets/SalesList-CNb0SEWc.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CBJIwGEC.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/ai-B4igPhfg.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CpzyGHhH.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DUx7qhpG.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/money-Bd2DB5tv.js",
			"/assets/badge-cIXTS4UJ.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BRQxSBMe.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BbGcujUI.js", "/assets/AccountRegister-D3AfgwSZ.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BoXyfQSK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/MoneyAccountPick-B0LIGwAN.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-eIlDH9fu.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-B-50vVRs.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/RepeatInvoice-DPX26T-l.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CYM4DC98.js",
			"/assets/select-BpiBjw88.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-i6PEH0R9.js",
			"/assets/BarChart-D2scxLpd.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-Cyhvm82V.js", "/assets/SalesList-CNb0SEWc.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DEhwP3OV.js", "/assets/SalesList-CNb0SEWc.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Bi6oJJxx.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-DuYDLVcD.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/serials-Bg9_Bzp_.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DrafDhRg.js",
			"/assets/createServerFn-Bo-KX54X.js",
			"/assets/auth-middleware-DfugY9rY.js",
			"/assets/AppsCatalog-BqKyIrIp.js",
			"/assets/select-BpiBjw88.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-Cj706yR4.js",
			"/assets/switch-DPTWPI1W.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-ZuFkEwiu.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-D2nW5Sqt.js",
			"/assets/footers-DrKR4mpU.js",
			"/assets/PrintFrame-KGeM-I2x.js",
			"/assets/checkbox-C53oSzYR.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CGfGFEQU.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CtKx4bY4.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-BqKyIrIp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-fIn-v-SE.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BC4R1I-G.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DtoXr0fv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/photos-D2nW5Sqt.js",
			"/assets/stockmove-DB4K9c3x.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-Yti5JKHA.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/loans-60AVU19A.js",
			"/assets/feedWaiting-Btzjb5K8.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CpzyGHhH.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-D_NCOht6.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/PrintFrame-KGeM-I2x.js",
			"/assets/DocPdf-EebXRgKc.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-D9chV343.js",
			"/assets/createServerFn-Bo-KX54X.js",
			"/assets/auth-middleware-DfugY9rY.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/MoneyAccountPick-B0LIGwAN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CGfGFEQU.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DMhEwuzA.js",
			"/assets/select-BpiBjw88.js",
			"/assets/StockDialogs-DtoXr0fv.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/stockmove-DB4K9c3x.js",
			"/assets/checkbox-C53oSzYR.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Dyb-hMtP.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/members-1q9qSevk.js",
			"/assets/WhoPicker-3N6fP-iT.js",
			"/assets/reminders-g1kV5q-T.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BXR3TCeQ.js",
			"/assets/select-BpiBjw88.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/tickets.functions-x5AwXrGk.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Ct1n4xPN.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CGfGFEQU.js",
			"/assets/support.functions-UAwXqRuO.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DB9N0QXI.js", "/assets/StockDocList-Baew2jDi.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-C1tKXDWI.js", "/assets/PartyList-B96f3gh_.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-76GbmVeW.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/tickets.functions-x5AwXrGk.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-C0uWtih_.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/workorders-lllrVtDN.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-B2k5pEhM.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-BSQ3cKkq.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/coupons.functions-RS1S0Z0w.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-C1nVui9I.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/AdminAccount-CGbqTDxl.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CujfT5vx.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/downloads.functions-_OGfS0Hr.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-5M9dMjHp.js",
			"/assets/createServerFn-Bo-KX54X.js",
			"/assets/auth-middleware-DfugY9rY.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DaaNBhOM.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CpE7PARZ.js",
			"/assets/testers.functions-D9VxlYNK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-DR0tx01P.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-CvBf7cxQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-C4CUVXaG.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-0HrhAPjv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/textarea-DtB_puzl.js",
			"/assets/support.functions-UAwXqRuO.js",
			"/assets/HelpParts-D7VSvoFz.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-Da7_gR8p.js",
			"/assets/ManualFrame-D4QT5Ont.js",
			"/assets/manual._slug-DfVMUazd.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-B0G2TIXs.js",
			"/assets/createServerFn-Bo-KX54X.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-FMKT5Ty9.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DB8vA-Is.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DyqwFyTS.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-B4igPhfg.js",
			"/assets/personal-D__f0mYe.js",
			"/assets/reminders-g1kV5q-T.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CkMybBN0.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/AdminAccount-CGbqTDxl.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DSIt_VFJ.js", "/assets/ManualFrame-D4QT5Ont.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D1ZB7VJl.js", "/assets/AccountRegister-D3AfgwSZ.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BxTkMpVP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/OriginalLink-C2NzKl5v.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/realestate-CeuVpMZM.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-D45XdwR0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BQzUnDQK.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/realestate-CeuVpMZM.js",
			"/assets/money-Bd2DB5tv.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Dnp9ZClz.js",
			"/assets/select-BpiBjw88.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/SideList-DOOtAwws.js",
			"/assets/PartyHistory-C1ik8prE.js",
			"/assets/tabs-DjF0FS63.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-Bc9gsBzq.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BpiBjw88.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/ChangeHistory-BevV2HGx.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/SideList-DOOtAwws.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/NewProductDialog-C-vn5xm-.js",
			"/assets/MoneyAccountPick-B0LIGwAN.js",
			"/assets/footers-DrKR4mpU.js",
			"/assets/PrintFrame-KGeM-I2x.js",
			"/assets/serials-Bg9_Bzp_.js",
			"/assets/SerialsBox-DDnFMW7a.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-gOGQ5iHS.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BpiBjw88.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-DtoXr0fv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BevV2HGx.js",
			"/assets/switch-DPTWPI1W.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-cIXTS4UJ.js",
			"/assets/SideList-DOOtAwws.js",
			"/assets/tabs-DjF0FS63.js",
			"/assets/photos-D2nW5Sqt.js",
			"/assets/stockmove-DB4K9c3x.js",
			"/assets/serials-Bg9_Bzp_.js",
			"/assets/SerialsBox-DDnFMW7a.js",
			"/assets/workorders-lllrVtDN.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-D0ZH8jaj.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BpiBjw88.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/ChangeHistory-BevV2HGx.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/SideList-DOOtAwws.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-C-vn5xm-.js",
			"/assets/MoneyAccountPick-B0LIGwAN.js",
			"/assets/footers-DrKR4mpU.js",
			"/assets/PrintFrame-KGeM-I2x.js",
			"/assets/cardpay-DRVB2s0-.js",
			"/assets/checkbox-C53oSzYR.js",
			"/assets/serials-Bg9_Bzp_.js",
			"/assets/workorders-lllrVtDN.js",
			"/assets/RepeatInvoice-DPX26T-l.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-x5AwXrGk.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CG7la2Q1.js",
			"/assets/select-BpiBjw88.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/SideList-DOOtAwws.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-S9uGbF0R.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/quickadd-_FWKQEJm.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CGfGFEQU.js",
			"/assets/support.functions-UAwXqRuO.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BGNXGAmo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-D7feNQNR.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/SideList-DOOtAwws.js",
			"/assets/PartyHistory-C1ik8prE.js",
			"/assets/tabs-DjF0FS63.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DU1GQ-es.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/sales-7A72IlSj.js",
			"/assets/footers-DrKR4mpU.js",
			"/assets/tickets.functions-x5AwXrGk.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DOarIUoI.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/input-D8rZALXG.js",
			"/assets/skeleton-DLRYndpE.js",
			"/assets/AdminAccount-CGbqTDxl.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-WKcUdITd.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/button-BDoynZ2H.js",
			"/assets/textarea-DtB_puzl.js",
			"/assets/support-CGfGFEQU.js",
			"/assets/support.functions-UAwXqRuO.js",
			"/assets/HelpParts-D7VSvoFz.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CDGrEu_d.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DLRYndpE.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
