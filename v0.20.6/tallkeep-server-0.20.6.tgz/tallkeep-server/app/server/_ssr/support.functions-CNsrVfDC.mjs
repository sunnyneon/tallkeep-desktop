import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-gU6PXqhF.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/support.functions-CNsrVfDC.js
/**
* Support Desk server calls.
*
* The support page (/help/<address>) has no sign-in: a customer opens a ticket, then follows it
* with the secret link /help/t/<key>. Staff work tickets in the app; replies are emailed.
*/
var getSupportPage = createServerFn({ method: "GET" }).inputValidator((d) => ({ slug: String(d?.slug ?? "") })).handler(createSsrRpc("f8465b5a6844a72aa64a56949439349602aaa2860cac1d67442dfe948e025036"));
var openTicket = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(createSsrRpc("40f995acabc3d24a380ab7d182bbf46b853bb07eb89be8ccb844a7b7012a806d"));
var getTicketByKey = createServerFn({ method: "GET" }).inputValidator((d) => ({ key: String(d?.key ?? "") })).handler(createSsrRpc("edd227bdb9a1f3153ddfc027e2f64c788faedc6d7a2198167ff802f227dbcb5f"));
var replyByKey = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(createSsrRpc("f4a3843ba5b275a7d0f9497fd6e3748d8da5db0d4783dfa53e26efdbece5ca69"));
/** Reply to the customer (emailed) or add an internal note. Files are already uploaded. */
var staffReply = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("3337e16a1ca5d14776fbffb6ab88d8c08897b5c663e19c0a5445cc769c12e08f"));
/** Is email set up here (so replies reach the customer)? */
var supportEmailReady = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("f3dd04a2849ca3168bd7a7a323490b6df9b1b99564396df67070a7832cdacde3"));
/** Everyone in this account who can work tickets: for "Assigned to". */
var listSupportStaff = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("c0a9351fdf5fec73b82f254d09bc44ec7e4d5613560f4b5995f36d4118bc6a9c"));
//#endregion
export { replyByKey as a, openTicket as i, getTicketByKey as n, staffReply as o, listSupportStaff as r, supportEmailReady as s, getSupportPage as t };
