import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade.functions-FfY1LwDs.js
/**
* Renew or upgrade a Tallkeep Desktop license (no sign-in): renew updates for another year, add
* companies, add people. The customer finds their license by its number and email, pays with
* Stripe, and the license gets a new key (same number), emailed and picked up by the office
* computer at its next check.
*/
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
/** The new "updates until" after renewing: a year past today or the current date, whichever is later. */
function renewedUntil(current, years = 1) {
	const base = current && current > today() ? current : today();
	const d = /* @__PURE__ */ new Date(`${base}T12:00:00Z`);
	d.setUTCFullYear(d.getUTCFullYear() + years);
	return d.toISOString().slice(0, 10);
}
var plain = (v) => v.toLowerCase().replace(/\b(inc|llc|ltd|corp|co|company)\b\.?/g, "").replace(/[^a-z0-9]+/g, "");
/** Find a license by its number plus the email it was sent to, or the business name on it. */
async function find(license, who) {
	const id = String(license ?? "").trim().toUpperCase();
	const w = String(who ?? "").trim();
	if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(id)) throw new Error("Type the license number, like NAP8-6LNX (Settings → Plan & computer in Tallkeep).");
	const { data } = await (await admin()).from("desktop_licenses").select("*").eq("id", id).maybeSingle();
	const lic = data;
	const byEmail = !!lic?.email && w.includes("@") && lic.email.trim().toLowerCase() === w.toLowerCase();
	const byName = !!lic && !byEmail && plain(w).length >= 3 && plain(lic.to_name) === plain(w);
	if (!lic || !byEmail && !byName) throw new Error("We couldn't find that license. Check the license number, and use the email the key was sent to or the business name on the license. Or email hello@tallkeep.com.");
	if (lic.revoked) throw new Error("This license is switched off. Email hello@tallkeep.com.");
	if (lic.expires) throw new Error("This is an early access license. To keep Tallkeep, buy it on the Buy page with your early access code for 50% off.");
	return {
		...lic,
		byName
	};
}
async function prices() {
	const { readPrices } = await import("./admin.functions-BQJEYbr6.mjs");
	const p = (await readPrices())?.prices ?? null;
	return {
		renewPrice: p?.desktop.updates_yearly ?? 0,
		extraCompany: p?.desktop.extra_company ?? 0,
		extraUser: p?.desktop.extra_user ?? 0
	};
}
var getUpgradeInfo_createServerFn_handler = createServerRpc({
	id: "b3d9b550fd57f1619d6614223abb41699073a11378cef344750801aba49c44e7",
	name: "getUpgradeInfo",
	filename: "src/lib/upgrade.functions.ts"
}, (opts) => getUpgradeInfo.__executeServer(opts));
var getUpgradeInfo = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(getUpgradeInfo_createServerFn_handler, async ({ data }) => {
	const lic = await find(data.license, data.email);
	const p = await prices();
	return {
		id: lic.id,
		to: lic.to_name,
		companies: lic.companies,
		users: lic.users,
		updatesUntil: lic.updates_until,
		...p,
		ready: !!process.env["STRIPE_SECRET_KEY"]
	};
});
var startUpgrade_createServerFn_handler = createServerRpc({
	id: "724d38f1c752f08b3df6330bde3f49cb5f5e4cc51e2a7909d81ced3a8bd86e60",
	name: "startUpgrade",
	filename: "src/lib/upgrade.functions.ts"
}, (opts) => startUpgrade.__executeServer(opts));
var startUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => {
	const n = (v) => Math.max(0, Math.min(100, Math.floor(Number(v) || 0)));
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	return {
		...d,
		renew: !!d.renew,
		addCompanies: n(d.addCompanies),
		addUsers: n(d.addUsers)
	};
}).handler(startUpgrade_createServerFn_handler, async ({ data }) => {
	const lic = await find(data.license, data.email);
	const p = await prices();
	const addC = lic.companies == null ? 0 : data.addCompanies;
	const addU = lic.users == null ? 0 : data.addUsers;
	if (!data.renew && !addC && !addU) throw new Error("Pick what to add or renew.");
	const { stripe } = await import("./pay.server-B-Rkh4Z-.mjs");
	const f = {
		mode: "payment",
		billing_address_collection: "required",
		customer_email: lic.email,
		allow_promotion_codes: "true",
		success_url: `${data.origin}/upgrade/done?session={CHECKOUT_SESSION_ID}`,
		cancel_url: `${data.origin}/upgrade?license=${lic.id}`,
		"metadata[product]": "tallkeep_upgrade",
		"metadata[license]": lic.id,
		"metadata[renew]": data.renew ? 1 : 0,
		"metadata[add_companies]": addC,
		"metadata[add_users]": addU,
		"metadata[by_name]": lic.byName ? 1 : 0
	};
	let i = 0;
	const line = (name, dollars, qty) => {
		if (qty <= 0 || dollars <= 0) return;
		f[`line_items[${i}][price_data][currency]`] = "usd";
		f[`line_items[${i}][price_data][product_data][name]`] = name;
		f[`line_items[${i}][price_data][unit_amount]`] = Math.round(dollars * 100);
		f[`line_items[${i}][quantity]`] = qty;
		i++;
	};
	if (data.renew) line(`Tallkeep updates for 1 more year (until ${renewedUntil(lic.updates_until)}), license ${lic.id}`, p.renewPrice, 1);
	line(`Extra company, license ${lic.id}`, p.extraCompany, addC);
	line(`Extra person, license ${lic.id}`, p.extraUser, addU);
	if (!i) throw new Error("Prices aren't set yet. Email hello@tallkeep.com.");
	return { url: (await stripe("checkout/sessions", f)).url };
});
async function fulfillUpgrade(session) {
	if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return { status: "unpaid" };
	const db = await admin();
	const done = async () => {
		const { data: u } = await db.from("license_upgrades").select("license_id").eq("stripe_session", session).maybeSingle();
		if (!u) return null;
		const { data: l } = await db.from("desktop_licenses").select("*").eq("id", u.license_id).maybeSingle();
		const lic = l;
		return {
			status: "paid",
			id: lic.id,
			key: showKey ? lic.license_key : "",
			email: lic.email,
			companies: lic.companies,
			users: lic.users,
			updatesUntil: lic.updates_until,
			mailed: /key emailed/.test(lic.notes ?? ""),
			showKey
		};
	};
	const { stripe } = await import("./pay.server-B-Rkh4Z-.mjs");
	const s = await stripe(`checkout/sessions/${session}`);
	const m = s.metadata ?? {};
	const showKey = m["by_name"] !== "1";
	const had = await done();
	if (had) return had;
	if (s.payment_status !== "paid" || m["product"] !== "tallkeep_upgrade") return { status: "unpaid" };
	const renew = m["renew"] === "1" ? 1 : 0;
	const addC = Number(m["add_companies"]) || 0;
	const addU = Number(m["add_users"]) || 0;
	const ins = await db.from("license_upgrades").insert({
		license_id: m["license"],
		stripe_session: session,
		renew_years: renew,
		add_companies: addC,
		add_users: addU,
		paid_cents: s.amount_total ?? null
	});
	if (ins.error) {
		const again = await done();
		if (again) return again;
		throw new Error(ins.error.message);
	}
	const { data: l } = await db.from("desktop_licenses").select("*").eq("id", m["license"]).maybeSingle();
	const lic = l;
	const next = {
		companies: lic.companies == null ? null : lic.companies + addC,
		users: lic.users == null ? null : lic.users + addU,
		updatesUntil: renew ? renewedUntil(lic.updates_until) : lic.updates_until
	};
	const { signLicenseKey, mailLicense, mailNote } = await import("./license.server-Bu3IQdFy.mjs");
	const key = await signLicenseKey({
		id: lic.id,
		to: lic.to_name,
		email: lic.email,
		...next,
		expires: lic.expires ?? null,
		edition: lic.edition ?? null,
		addons: lic.addons ?? null
	});
	const what = [
		renew ? `renewed to ${next.updatesUntil}` : "",
		addC ? `+${addC} compan${addC === 1 ? "y" : "ies"}` : "",
		addU ? `+${addU} ${addU === 1 ? "person" : "people"}` : ""
	].filter(Boolean).join(", ");
	const sent = lic.email ? await mailLicense({
		to: lic.email,
		name: lic.to_name,
		id: lic.id,
		key,
		companies: next.companies,
		users: next.users,
		updatesUntil: next.updatesUntil,
		origin: "https://app.tallkeep.com",
		updated: true
	}) : {
		ok: false,
		why: "no email address"
	};
	const notes = String(lic.notes ?? "").replace(/ ?·? ?key email(ed [0-9-]+| didn't go \([^)]*\))/g, "").trim();
	await db.from("desktop_licenses").update({
		license_key: key,
		companies: next.companies,
		users: next.users,
		updates_until: next.updatesUntil,
		notes: [
			notes,
			`${today()} paid online $${((s.amount_total ?? 0) / 100).toFixed(2)}: ${what}`,
			mailNote(sent)
		].filter(Boolean).join(" · ")
	}).eq("id", lic.id);
	return {
		status: "paid",
		id: lic.id,
		key: showKey ? key : "",
		email: lic.email,
		...next,
		mailed: sent.ok,
		showKey
	};
}
var getUpgradeOrder_createServerFn_handler = createServerRpc({
	id: "059a3c99824bb5684bd30d408e4be244c5916b85e8f697267342e19e20e6a210",
	name: "getUpgradeOrder",
	filename: "src/lib/upgrade.functions.ts"
}, (opts) => getUpgradeOrder.__executeServer(opts));
var getUpgradeOrder = createServerFn({ method: "GET" }).inputValidator((d) => ({ session: String(d.session ?? "") })).handler(getUpgradeOrder_createServerFn_handler, async ({ data }) => fulfillUpgrade(data.session));
//#endregion
export { getUpgradeInfo_createServerFn_handler, getUpgradeOrder_createServerFn_handler, startUpgrade_createServerFn_handler };
