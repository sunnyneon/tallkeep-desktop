import { t as supabase } from "./client-C9I0PyVu.mjs";
import { J as redirect, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/route-B6rFs8B3.js
var $$splitComponentImporter = () => import("./route--dXcVoFG.mjs");
var Route = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data } = await supabase.auth.getUser();
		if (!data.user) throw redirect({ to: "/auth" });
		if (typeof window !== "undefined" && window.location.hostname.startsWith("admin.")) throw redirect({ to: "/admin" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
