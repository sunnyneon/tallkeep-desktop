import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Qt as CircleCheck, kt as Gift } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { t as askToTest } from "./testers.functions-Df8dxMCt.mjs";
import { t as BuyFrame } from "./buy-D9XTGIZG.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/early-access-DHeSFp_v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Ask to test Tallkeep before launch (no sign-in). Tallkeep checks each request. */
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: label
		}), children]
	});
}
var USES = [
	{
		key: "inventory",
		label: "Inventory"
	},
	{
		key: "sales",
		label: "Quotes & invoices"
	},
	{
		key: "purchasing",
		label: "Purchase orders"
	},
	{
		key: "accounting",
		label: "Banking & accounting"
	},
	{
		key: "properties",
		label: "Rentals / properties"
	},
	{
		key: "personal",
		label: "Personal money"
	}
];
function EarlyAccessPage() {
	const [f, setF] = (0, import_react.useState)({
		name: "",
		email: "",
		company: "",
		website: "",
		phone: "",
		location: "",
		business: "",
		people: "",
		nowUsing: "",
		setup: "windows",
		notes: "",
		fax: ""
	});
	const [uses, setUses] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(null);
	const set = (k) => (e) => setF({
		...f,
		[k]: e.target.value
	});
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setFailed("");
		try {
			const r = await askToTest({ data: {
				...f,
				uses
			} });
			setDone({ again: !!r.again });
		} catch (err) {
			setFailed(err.message);
		} finally {
			setBusy(false);
		}
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-6 text-center shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-10 w-10 text-emerald-600" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Thank you!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground",
				children: done.again ? "We already have your request. We'll email you soon." : "We got your request. We look at each business and email you within 2 business days, with your free license and the download link."
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: "Tallkeep Early Access"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Use Tallkeep for your real business before it opens to everyone, free until January 31, 2027. Tell us what doesn't work right and we'll fix it before launch."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "mt-0.5 h-5 w-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Early access members get 50% off" }), " when they decide to buy. Your books stay yours: keep everything you entered."] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Your name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.name,
									onChange: set("name"),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Your email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: f.email,
									onChange: set("email"),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Business name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.company,
									onChange: set("company"),
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Business website",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.website,
									onChange: set("website"),
									placeholder: "yourbusiness.com"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "tel",
									value: f.phone,
									onChange: set("phone")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "City and state",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.location,
									onChange: set("location")
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What does your business do?",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.business,
							onChange: set("business"),
							placeholder: "For example: we sell and install LED signs"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "What would you use Tallkeep for?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: USES.map((u) => {
								const on = uses.includes(u.key);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setUses((x) => on ? x.filter((y) => y !== u.key) : [...x, u.key]),
									className: `rounded-full border px-3 py-1.5 ${on ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-muted"}`,
									children: u.label
								}, u.key);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "How many people would use it?",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								value: f.people,
								onChange: set("people")
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What do you use now?",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.nowUsing,
								onChange: set("nowUsing"),
								placeholder: "QuickBooks, inFlow, Excel…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Where would Tallkeep run?",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-10 w-full rounded-md border bg-background px-3 text-sm",
							value: f.setup,
							onChange: set("setup"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "windows",
									children: "A Windows computer in the office"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "synology",
									children: "A Synology or a Linux server"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "online",
									children: "Online (no install)"
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Anything else? (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							value: f.notes,
							onChange: set("notes")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						tabIndex: -1,
						autoComplete: "off",
						className: "hidden",
						value: f.fax,
						onChange: set("fax"),
						"aria-hidden": true
					}),
					failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-900",
						children: failed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: busy,
						children: busy ? "Sending…" : "Ask for early access"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-xs text-muted-foreground",
						children: "We check each business before we send a license. No payment card needed."
					})
				]
			})
		]
	}) });
}
//#endregion
export { EarlyAccessPage as component };
