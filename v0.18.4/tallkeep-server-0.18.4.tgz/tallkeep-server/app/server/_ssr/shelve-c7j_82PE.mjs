import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { $ as MoveRight, D as Search, R as Plus, bt as ImagePlus, cn as Camera, f as Undo2, in as Check, ln as CameraOff, n as X, xt as ImageOff } from "../_libs/lucide-react.mjs";
import { o as useLocations, r as useCategories, t as byId } from "./queries-CUGyjerL.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as SearchSelect } from "./SearchSelect-KZGKVtkS.mjs";
import { i as usePhotoUrl, n as shrinkImage, r as uploadExtraPhoto } from "./photos-PwQoyCNs.mjs";
import { a as undoMoves, i as moveSpots, r as ensureShelf, t as PlacePicker } from "./stockmove-ChAUDHR5.mjs";
import { n as startScan } from "./BarcodeScanner-DRDUmXbX.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/shelve-c7j_82PE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Small photo with a camera button: tap to take one (or more) photos; they save straight away. */
function QuickPhoto({ productId, path }) {
	const qc = useQueryClient();
	const { data: url } = usePhotoUrl(path);
	const input = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function upload(files) {
		const list = Array.from(files ?? []);
		if (!list.length) return;
		setBusy(true);
		let main = path;
		try {
			for (const f of list) {
				const p = await uploadExtraPhoto(productId, await shrinkImage(f));
				if (!main) {
					await db.from("products").update({ picture_path: p }).eq("id", productId);
					main = p;
				}
			}
			toast.success(list.length === 1 ? "Photo saved." : `${list.length} photos saved.`);
			qc.invalidateQueries({ queryKey: ["shelve-products"] });
			qc.invalidateQueries({ queryKey: ["photos", productId] });
			qc.invalidateQueries({ queryKey: ["product", productId] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		title: "Take a photo of this product",
		"aria-label": "Take a photo of this product",
		onClick: () => input.current?.click(),
		className: "relative grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-lg border bg-muted text-muted-foreground",
		children: [
			url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: url,
				alt: "",
				className: "h-full w-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "h-5 w-5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute bottom-0.5 right-0.5 grid h-5 w-5 place-items-center rounded-full bg-[var(--section)] text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-3 w-3" })
			}),
			busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute inset-0 grid place-items-center bg-white/70 text-[10px]",
				children: "Saving…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: input,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => {
					upload(e.target.files);
					e.target.value = "";
				},
				onClick: (e) => e.stopPropagation()
			})
		]
	});
}
var DEST_KEY = "shelve-dest";
function ShelvePage() {
	const qc = useQueryClient();
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const { data: products } = useQuery({
		queryKey: ["shelve-products"],
		queryFn: () => fetchAll("products", "id,name,description,barcode,item_type,picture_path,stock(location_id,shelf,qty)")
	});
	const [dest, setDest] = (0, import_react.useState)(() => {
		try {
			return JSON.parse(localStorage.getItem(DEST_KEY) ?? "");
		} catch {
			return {
				loc: "",
				shelf: ""
			};
		}
	});
	(0, import_react.useEffect)(() => {
		try {
			localStorage.setItem(DEST_KEY, JSON.stringify(dest));
		} catch {}
	}, [dest]);
	const [q, setQ] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [log, setLog] = (0, import_react.useState)([]);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const input = (0, import_react.useRef)(null);
	const results = (0, import_react.useMemo)(() => {
		if (!q.toLowerCase().split(/\s+/).filter(Boolean).length || !products) return [];
		const exact = products.filter((p) => p.barcode && p.barcode.toLowerCase() === q.trim().toLowerCase());
		if (exact.length) return exact;
		const az = [...products].sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true }));
		return smartSearch(az, q, (p) => p.name, (p) => `${p.description ?? ""} ${p.barcode ?? ""}`).slice(0, 30);
	}, [q, products]);
	const onShelfNow = (0, import_react.useMemo)(() => (products ?? []).flatMap((p) => p.stock.filter((s) => s.location_id === dest.loc && s.shelf === dest.shelf.trim() && Number(s.qty) !== 0).map((s) => ({
		p,
		qty: Number(s.qty)
	}))).sort((a, b) => a.p.name.localeCompare(b.p.name)), [products, dest]);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["shelve-products"] });
		qc.invalidateQueries({ queryKey: ["stock"] });
		qc.invalidateQueries({ queryKey: ["products"] });
	};
	async function moveHere(p) {
		if (!dest.loc) {
			toast.error("First choose where the items go.");
			return;
		}
		const spots = p.stock.map((s) => ({
			...s,
			product_id: p.id
		}));
		setBusy(p.id);
		try {
			const moves = await moveSpots(spots, dest.loc, dest.shelf);
			if (!moves.length) toast("Nothing to move — it's already there or none in stock.");
			else {
				const n = moves.reduce((s, m) => s + m.qty, 0);
				toast.success(`${p.name}: ${fmtQty(n)} moved to ${where()}.`);
				setLog((l) => [{
					product: p,
					moves
				}, ...l]);
				setQ("");
				input.current?.focus();
			}
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(null);
		}
	}
	async function undo(i) {
		const d = log[i];
		if (!d || d.undone) return;
		try {
			await undoMoves(d.moves);
			setLog((l) => l.map((x, j) => j === i ? {
				...x,
				undone: true
			} : x));
			toast.success(`${d.product.name} put back.`);
			refresh();
		} catch (e) {
			toast.error(e.message);
		}
	}
	const where = () => `${locName.get(dest.loc) ?? ""}${dest.shelf.trim() ? ` · ${dest.shelf.trim()}` : ""}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Move to Shelves",
			text: "Choose the shelf, then scan or search each item and press Move here. Everything of that item moves in one tap."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky top-14 z-10 space-y-3 rounded-2xl border-2 border-[var(--section)] bg-card p-4 md:top-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlacePicker, {
				label: "Put items on",
				locationId: dest.loc,
				shelf: dest.shelf,
				onLocation: (v) => setDest((d) => ({
					...d,
					loc: v
				})),
				onShelf: (v) => setDest((d) => ({
					...d,
					shelf: v
				}))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: dest.loc ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Moving to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-foreground",
						children: where()
					}),
					" · ",
					onShelfNow.length,
					" items there now"
				] }) : "Choose a place. Type a new shelf name to make a new shelf."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3 rounded-2xl border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							ref: input,
							className: "pl-9",
							placeholder: "Scan a barcode or type a name",
							value: q,
							onChange: (e) => setQ(e.target.value),
							onKeyDown: (e) => {
								const only = results[0];
								if (e.key === "Enter" && results.length === 1 && only) moveHere(only);
							}
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraButton, { onCode: (c) => {
						setQ(c);
						const hit = products?.filter((p) => p.barcode && p.barcode.toLowerCase() === c.toLowerCase());
						if (hit && hit.length === 1 && hit[0]) moveHere(hit[0]);
					} })]
				}),
				q && results.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border border-dashed p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							"No product matches “",
							q,
							"”."
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setAdding(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add it as a new product"]
					})]
				}),
				!q && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setAdding(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a new product to this shelf"]
				}),
				adding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewHereDialog, {
					text: q,
					dest,
					where: where(),
					onClose: () => setAdding(false),
					onDone: () => {
						setAdding(false);
						setQ("");
						refresh();
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y",
					children: results.map((p) => {
						const spots = p.stock.filter((s) => Number(s.qty) !== 0);
						const total = spots.reduce((s, x) => s + Math.max(0, Number(x.qty)), 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickPhoto, {
									productId: p.id,
									path: p.picture_path
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/products/$id",
											params: { id: p.id },
											className: "font-medium hover:underline",
											children: p.name
										}),
										p.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: p.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-1 flex flex-wrap gap-1",
											children: [spots.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted-foreground",
												children: "None in stock"
											}), spots.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "rounded-full bg-muted px-2 py-0.5 text-xs",
												children: [
													locName.get(s.location_id),
													s.shelf ? ` · ${s.shelf}` : " · no shelf",
													": ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtQty(s.qty) })
												]
											}, `${s.location_id}|${s.shelf}`))]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => void moveHere(p),
									disabled: !!busy || total <= 0 || !dest.loc,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveRight, { className: "h-4 w-4" }), busy === p.id ? "Moving…" : `Move here (${fmtQty(total)})`]
								})
							]
						}, p.id);
					})
				})
			]
		}),
		log.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-b px-4 py-2 text-sm font-semibold",
				children: "Moved just now"
			}), log.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 px-4 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-emerald-600" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `min-w-0 flex-1 truncate ${d.undone ? "line-through text-muted-foreground" : ""}`,
						children: [
							d.product.name,
							" — ",
							fmtQty(d.moves.reduce((s, m) => s + m.qty, 0)),
							" to",
							" ",
							locName.get(d.moves[0]?.to_location ?? ""),
							d.moves[0]?.to_shelf ? ` · ${d.moves[0].to_shelf}` : ""
						]
					}),
					!d.undone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => void undo(i),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-4 w-4" }), " Put back"]
					})
				]
			}, i))]
		}),
		dest.loc && onShelfNow.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-hidden rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-b px-4 py-2 text-sm font-semibold",
				children: [
					"On ",
					where(),
					" now"
				]
			}), onShelfNow.map(({ p, qty }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between gap-3 px-4 py-1.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: p.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: fmtQty(qty)
				})]
			}, p.id))]
		})
	] });
}
/** Keeps the camera on so you can scan item after item. */
function CameraButton({ onCode }) {
	const [on, setOn] = (0, import_react.useState)(false);
	const video = (0, import_react.useRef)(null);
	const last = (0, import_react.useRef)({
		code: "",
		at: 0
	});
	const cb = (0, import_react.useRef)(onCode);
	cb.current = onCode;
	(0, import_react.useEffect)(() => {
		if (!on || !video.current) return;
		let stop;
		startScan(video.current, (c) => {
			const now = Date.now();
			if (c === last.current.code && now - last.current.at < 3e3) return;
			last.current = {
				code: c,
				at: now
			};
			if (navigator.vibrate) navigator.vibrate(60);
			cb.current(c);
		}).then((s) => stop = s).catch(() => {
			toast.error("Can't open the camera. Allow camera access, or type the code.");
			setOn(false);
		});
		return () => stop?.();
	}, [on]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: on ? "default" : "outline",
		onClick: () => setOn((v) => !v),
		children: [on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden sm:inline",
			children: on ? "Stop camera" : "Scan"
		})]
	}), on && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-x-4 bottom-24 z-30 overflow-hidden rounded-2xl border-2 border-[var(--section)] bg-black shadow-xl sm:inset-x-auto sm:right-6 sm:w-80 md:bottom-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			ref: video,
			className: "aspect-[4/3] w-full object-cover",
			muted: true,
			playsInline: true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-6 top-1/2 h-0.5 bg-red-500/80" })]
	})] });
}
/** Add a product that isn't in the list yet, put it on this shelf and take its photos — one step. */
function NewHereDialog({ text, dest, where, onClose, onDone }) {
	const { data: cats } = useCategories();
	const looksLikeCode = /^[A-Za-z0-9-]{6,}$/.test(text.trim()) && /\d{4,}/.test(text);
	const [f, setF] = (0, import_react.useState)({
		name: looksLikeCode ? "" : text.trim(),
		barcode: looksLikeCode ? text.trim() : "",
		description: "",
		category: "",
		qty: "1"
	});
	const [photos, setPhotos] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const camera = (0, import_react.useRef)(null);
	const gallery = (0, import_react.useRef)(null);
	async function save() {
		if (!f.name.trim()) {
			toast.error("Type the product name.");
			return;
		}
		setBusy(true);
		try {
			const { data, error } = await db.from("products").insert({
				name: f.name.trim(),
				description: f.description.trim() || null,
				barcode: f.barcode.trim() || null,
				category_id: f.category || null,
				item_type: "stocked",
				default_location_id: dest.loc || null,
				default_shelf: dest.shelf.trim() || null
			}).select("id").single();
			if (error) throw new Error(error.message);
			const id = data.id;
			let main = null;
			for (const ph of photos) {
				const path = await uploadExtraPhoto(id, await shrinkImage(ph));
				if (!main) {
					main = path;
					await db.from("products").update({ picture_path: path }).eq("id", id);
				}
			}
			const qty = Number(f.qty) || 0;
			if (dest.loc && qty > 0) {
				await ensureShelf(dest.loc, dest.shelf);
				const { error: e2 } = await db.rpc("change_stock", {
					_product_id: id,
					_location_id: dest.loc,
					_shelf: dest.shelf.trim(),
					_qty_change: qty,
					_reason: "adjust",
					_note: "New product put on shelf"
				});
				if (e2) throw new Error(e2.message);
			}
			toast.success(`${f.name.trim()} added${dest.loc && qty > 0 ? ` — ${qty} on ${where}` : ""}.`);
			onDone();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add a new product" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: dest.loc ? `It goes on ${where}.` : "Choose a place above first if you want to put stock on a shelf." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: f.name,
								onChange: (e) => setF({
									...f,
									name: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.description,
								onChange: (e) => setF({
									...f,
									description: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Barcode (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.barcode,
									onChange: (e) => setF({
										...f,
										barcode: e.target.value
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How many here" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "decimal",
									value: f.qty,
									onChange: (e) => setF({
										...f,
										qty: e.target.value
									})
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: f.category,
								onChange: (v) => setF({
									...f,
									category: v
								}),
								options: [...(cats ?? []).map((c) => ({
									value: c.id,
									label: c.name
								}))],
								placeholder: "Choose a category",
								searchText: "Type a category"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Photos (front, back, side…)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap gap-2",
									children: [
										photos.map((ph, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "relative h-14 w-14 overflow-hidden rounded-lg border",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: URL.createObjectURL(ph),
												alt: "",
												className: "h-full w-full object-cover"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Remove this photo",
												className: "absolute right-0 top-0 rounded-bl bg-black/60 p-0.5 text-white",
												onClick: () => setPhotos((x) => x.filter((_, j) => j !== i)),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" })
											})]
										}, i)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => camera.current?.click(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }), " Take photo"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => gallery.current?.click(),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" }), " Choose photos"]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: camera,
									type: "file",
									accept: "image/*",
									capture: "environment",
									className: "hidden",
									onChange: (e) => {
										const l = Array.from(e.target.files ?? []);
										setPhotos((x) => [...x, ...l]);
										e.target.value = "";
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: gallery,
									type: "file",
									accept: "image/*",
									multiple: true,
									className: "hidden",
									onChange: (e) => {
										const l = Array.from(e.target.files ?? []);
										setPhotos((x) => [...x, ...l]);
										e.target.value = "";
									}
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Saving…" : "Add product"
				})] })
			]
		})
	});
}
//#endregion
export { ShelvePage as component };
