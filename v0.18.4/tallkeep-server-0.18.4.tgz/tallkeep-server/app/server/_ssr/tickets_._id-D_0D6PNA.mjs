import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets_._id-D_0D6PNA.js
var $$splitComponentImporter = () => import("./tickets_._id-7kFD4W6f.mjs");
var Route = createFileRoute("/_authenticated/tickets_/$id")({
	head: () => ({ meta: [{ title: "Ticket · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
