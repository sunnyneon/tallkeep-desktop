//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B8ClVs6e.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BIEYv4N5.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-CbrrUKrD.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-Bc9aTRcY.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIEYv4N5.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BcNWNAaq.js",
			"/assets/log-out-U_0CtZQN.js",
			"/assets/testers.functions-BDx2eW0-.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CoL71AK9.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CpqrRCFH.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-C6zAwWu-.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/dist-DfkWj3aj.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/dist-Bdpsfauv.js",
			"/assets/dialog-rRJKSmjw.js",
			"/assets/queries-CBQKc3F8.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/label-DeQBGLgy.js",
			"/assets/textarea-BdZJF7L0.js",
			"/assets/shoebox-DjM5fomn.js",
			"/assets/company-rc5BHdMS.js",
			"/assets/reports-DTGYngM_.js",
			"/assets/access-BDQnEkpn.js",
			"/assets/theme-1Otek0IT.js",
			"/assets/Logo-C7RZwtrp.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CLwEOBQ8.js",
			"/assets/log-out-U_0CtZQN.js",
			"/assets/admin.functions-BU8Lbu29.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-C7RZwtrp.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CnnL_taA.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/label-DeQBGLgy.js",
			"/assets/Logo-C7RZwtrp.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DJBtGQx5.js",
			"/assets/testers.functions-BDx2eW0-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/coupons.functions-BE14SgAg.js",
			"/assets/buy.functions-BBR0sOsX.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-BHOZQ21e.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/downloads.functions-A9jQEWUu.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Cu4yXtyP.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/label-DeQBGLgy.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-hWB2bL6J.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/label-DeQBGLgy.js",
			"/assets/Logo-C7RZwtrp.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BhkIHnku.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/upgrade.functions-B2pOCUst.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-BTPJhveQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/label-DeQBGLgy.js",
			"/assets/Logo-C7RZwtrp.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DOqoFIy5.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-WbrgW_1i.js", "/assets/StockDocList-CyScho2n.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BalmcTZR.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/ai-6SlqzA2j.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-CI3Te_TK.js",
			"/assets/BankConnections-vvXBCqpl.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-KxhC_WQd.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CIKCwid9.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-vvXBCqpl.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/ai-6SlqzA2j.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-Olx8WH3T.js",
			"/assets/TxnEditor-DwcYpzOa.js",
			"/assets/feedWaiting-Bu5fotBG.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Jsavk8Qy.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/bills-CguplMIv.js",
			"/assets/balances-DsSviMet.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-btAI3zrm.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/personal-yY8k4kSo.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/WhoPicker-CE-PDr9s.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BDq57PRR.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DkrV-WKs.js", "/assets/AccountRegister-DNwLUnHy.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Bmc6D_Hm.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DmDrPF43.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/money-_H9f0Dm-.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BftufnfH.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-6SlqzA2j.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-8nwFoO_Q.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-DKYHu67C.js", "/assets/StockDocList-CyScho2n.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-C_SIgBsU.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-DYWZQwrB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-Dbi9zWWr.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DB2qqRCq.js", "/assets/PartyList-BCxICmWk.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CavV07ck.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DMsdjp4p.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/storage.functions-Tgca_YM2.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Ct_9mVEM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CFkmycSE.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BbhcuHf5.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DfYb9gpQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-C5fXM_IF.js", "/assets/ChangeHistory-CujgqIsP.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-U-cGNijw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/members-DyfwPAKn.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DR3ofz51.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/personal-yY8k4kSo.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/WhoPicker-CE-PDr9s.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-LU79_yII.js", "/assets/SalesList-C0uI5Ld0.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-6Ljg191i.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CA2oAdVv.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-HAzCDVhm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-D-KEXJ9t.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/loans-Olx8WH3T.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-BdUjPR7O.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-DZNEVNWJ.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CZIAjPXL.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/personal-yY8k4kSo.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/WhoPicker-CE-PDr9s.js",
			"/assets/reminders-CG7yBpBn.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Cn_ODA1u.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-rkhlZRlZ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/personal-yY8k4kSo.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/WhoPicker-CE-PDr9s.js",
			"/assets/generateCategoricalChart-BczppTgR.js",
			"/assets/Area-eeqpEHON.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-C9xoB3zI.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/generateCategoricalChart-BczppTgR.js",
			"/assets/PlCharts-BbhcuHf5.js",
			"/assets/BarChart-DbNr-WC-.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-zYjpFJ0V.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CvkZSG5i.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-Chuo4hv-.js",
			"/assets/createServerFn-MGXzTmYt.js",
			"/assets/auth-middleware-BoII4eGm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/storage.functions-Tgca_YM2.js",
			"/assets/coupons.functions-BE14SgAg.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-6sJBcp05.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-D-pQfPHw.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BijYC96J.js",
			"/assets/checkbox-DHcguj6d.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-R84uqmxV.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DXtcsgSV.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CHF3RF7M.js", "/assets/SalesList-C0uI5Ld0.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-D27sL1Bv.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/ai-6SlqzA2j.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Tgca_YM2.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CM5otGSQ.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/money-_H9f0Dm-.js",
			"/assets/badge-BijYC96J.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Ds-KIdkU.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-ajbl_Btj.js", "/assets/AccountRegister-DNwLUnHy.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Bwgh_VqA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/badge-BijYC96J.js",
			"/assets/MoneyAccountPick-KVb_qgXB.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BraP-Ldi.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-ClXB4HQH.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/badge-BijYC96J.js",
			"/assets/RepeatInvoice-ChbRmK1c.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CWHtlAjl.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-BczppTgR.js",
			"/assets/BarChart-DbNr-WC-.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-Oaby9oF7.js", "/assets/SalesList-C0uI5Ld0.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-URXuzDmH.js", "/assets/SalesList-C0uI5Ld0.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Bpl2S1Mj.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-B2KwFj6R.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BijYC96J.js",
			"/assets/serials-DObcxQpW.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-D0XKeJRe.js",
			"/assets/createServerFn-MGXzTmYt.js",
			"/assets/auth-middleware-BoII4eGm.js",
			"/assets/AppsCatalog-1p57lK7m.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BoLluTgG.js",
			"/assets/switch-DZNEVNWJ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-Dbi9zWWr.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-Cq-pRFOJ.js",
			"/assets/footers-CqugR64A.js",
			"/assets/PrintFrame-FW9MsARo.js",
			"/assets/checkbox-DHcguj6d.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BTeYlIuU.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-XjjtR35o.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-1p57lK7m.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-vvXBCqpl.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-B7gwFkTa.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BJUp4vLI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/photos-Cq-pRFOJ.js",
			"/assets/stockmove-Djp53R3c.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CNVmgxWN.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/loans-Olx8WH3T.js",
			"/assets/feedWaiting-Bu5fotBG.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Tgca_YM2.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CE1DLbo4.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/PrintFrame-FW9MsARo.js",
			"/assets/DocPdf-DNOyLaL5.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DTDusLFx.js",
			"/assets/createServerFn-MGXzTmYt.js",
			"/assets/auth-middleware-BoII4eGm.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/badge-BijYC96J.js",
			"/assets/MoneyAccountPick-KVb_qgXB.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BTeYlIuU.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CTTdeiGh.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/StockDialogs-BJUp4vLI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/stockmove-Djp53R3c.js",
			"/assets/checkbox-DHcguj6d.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-A267_RP4.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/members-DyfwPAKn.js",
			"/assets/WhoPicker-CE-PDr9s.js",
			"/assets/reminders-CG7yBpBn.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BUq5KSyX.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/tickets.functions-CrdTqdnB.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-kFdz7ttn.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BTeYlIuU.js",
			"/assets/support.functions-Q2ebTNpG.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-69bnVMjf.js", "/assets/StockDocList-CyScho2n.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-ts9WcabF.js", "/assets/PartyList-BCxICmWk.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B23hClfu.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/tickets.functions-CrdTqdnB.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-BpXM1ob3.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/badge-BijYC96J.js",
			"/assets/workorders-DUziHglU.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-yXH21ALz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-CTT12RRD.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/badge-BijYC96J.js",
			"/assets/coupons.functions-BE14SgAg.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BVnXHTDk.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/AdminAccount-I790PynG.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CdDT8l3s.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/downloads.functions-A9jQEWUu.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C1sBHYL_.js",
			"/assets/createServerFn-MGXzTmYt.js",
			"/assets/auth-middleware-BoII4eGm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-jM4LAvBE.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-B9G8n-C9.js",
			"/assets/testers.functions-BDx2eW0-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CsOqn_eC.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-D4Fmvm6r.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BBR0sOsX.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-o6-Hmi4Q.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/textarea-BdZJF7L0.js",
			"/assets/support.functions-Q2ebTNpG.js",
			"/assets/HelpParts-BlpSfjsW.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-5_4FI9Rf.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CO9kvgaW.js",
			"/assets/manual._slug-m35FKNrE.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-D-2OJVuR.js",
			"/assets/createServerFn-MGXzTmYt.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Db1gaGtq.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-B2pOCUst.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DoZmWCeT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-6SlqzA2j.js",
			"/assets/personal-yY8k4kSo.js",
			"/assets/reminders-CG7yBpBn.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-C3K7-HuN.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/AdminAccount-I790PynG.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CFG2Y_Qe.js", "/assets/ManualFrame-CO9kvgaW.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CajKypco.js", "/assets/AccountRegister-DNwLUnHy.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DCV7le45.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/OriginalLink-DdkhfqZa.js",
			"/assets/bills-CguplMIv.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/realestate-CiNHE-5L.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-DBM4SQL1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-863kHxKw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/realestate-CiNHE-5L.js",
			"/assets/money-_H9f0Dm-.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-zYnFzGzy.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/SideList-CgLybUPA.js",
			"/assets/PartyHistory-CFq7g7_n.js",
			"/assets/tabs-B-mA5Ffd.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-QHNBrFGf.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/ChangeHistory-CujgqIsP.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/SideList-CgLybUPA.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/NewProductDialog-DFBW5sIq.js",
			"/assets/MoneyAccountPick-KVb_qgXB.js",
			"/assets/footers-CqugR64A.js",
			"/assets/PrintFrame-FW9MsARo.js",
			"/assets/serials-DObcxQpW.js",
			"/assets/SerialsBox-D-pN1bvK.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-C9ZL8zaH.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BJUp4vLI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CujgqIsP.js",
			"/assets/switch-DZNEVNWJ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BijYC96J.js",
			"/assets/SideList-CgLybUPA.js",
			"/assets/tabs-B-mA5Ffd.js",
			"/assets/photos-Cq-pRFOJ.js",
			"/assets/stockmove-Djp53R3c.js",
			"/assets/serials-DObcxQpW.js",
			"/assets/SerialsBox-D-pN1bvK.js",
			"/assets/workorders-DUziHglU.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-ckTmkwWp.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/ChangeHistory-CujgqIsP.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/SideList-CgLybUPA.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-DFBW5sIq.js",
			"/assets/MoneyAccountPick-KVb_qgXB.js",
			"/assets/footers-CqugR64A.js",
			"/assets/PrintFrame-FW9MsARo.js",
			"/assets/cardpay-BKzxHmIA.js",
			"/assets/checkbox-DHcguj6d.js",
			"/assets/serials-DObcxQpW.js",
			"/assets/workorders-DUziHglU.js",
			"/assets/RepeatInvoice-ChbRmK1c.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-CrdTqdnB.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DKXR9cOg.js",
			"/assets/select-Cc02dwZB.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/SideList-CgLybUPA.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CtHGYAQq.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/quickadd-D1pn4mB0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BTeYlIuU.js",
			"/assets/support.functions-Q2ebTNpG.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-0LYHmGqg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BG8RDxGd.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/SideList-CgLybUPA.js",
			"/assets/PartyHistory-CFq7g7_n.js",
			"/assets/tabs-B-mA5Ffd.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-wCVhHJHW.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/sales-8nwFoO_Q.js",
			"/assets/footers-CqugR64A.js",
			"/assets/tickets.functions-CrdTqdnB.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-By96_b1Z.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/input-yRDsz2ip.js",
			"/assets/skeleton-BPMEOdl8.js",
			"/assets/AdminAccount-I790PynG.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-bBOsoQBL.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-D8qXbr8J.js",
			"/assets/button-DleQeCoZ.js",
			"/assets/textarea-BdZJF7L0.js",
			"/assets/support-BTeYlIuU.js",
			"/assets/support.functions-Q2ebTNpG.js",
			"/assets/HelpParts-BlpSfjsW.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-DYIHR9NI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BPMEOdl8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
