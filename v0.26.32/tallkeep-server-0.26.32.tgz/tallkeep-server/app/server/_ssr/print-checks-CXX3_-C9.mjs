import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/print-checks-CXX3_-C9.js
var $$splitComponentImporter = () => import("./print-checks-CVp68iB-.mjs");
var Route = createFileRoute("/_authenticated/print-checks")({
	validateSearch: (s) => typeof s["only"] === "string" ? { only: s["only"] } : {},
	head: () => ({ meta: [{ title: "Print Checks · Tallkeep" }, {
		name: "description",
		content: "Print checks on voucher check paper."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
