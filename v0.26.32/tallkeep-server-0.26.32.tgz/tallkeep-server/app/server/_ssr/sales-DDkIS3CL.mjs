import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as db } from "./db-Coc48DC_.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-DDkIS3CL.js
var sales_DDkIS3CL_exports = /* @__PURE__ */ __exportAll({
	a: () => docName,
	c: () => isQuoteLike,
	d: () => nextNumber,
	f: () => noPartCol,
	g: () => totals,
	h: () => sales_exports,
	i: () => docBadge,
	l: () => isRmaDoc,
	m: () => payStatus,
	n: () => INV_STYLE,
	o: () => invMatches,
	p: () => partCol,
	r: () => PAY_STYLE,
	s: () => invStatus,
	t: () => INV_LABEL,
	u: () => lineTotal
});
var sales_exports = /* @__PURE__ */ __exportAll$1({
	INV_LABEL: () => INV_LABEL,
	INV_STYLE: () => INV_STYLE,
	PAY_STYLE: () => PAY_STYLE,
	STATUS_LABEL: () => STATUS_LABEL,
	STATUS_STYLE: () => STATUS_STYLE,
	docBadge: () => docBadge,
	docName: () => docName,
	invMatches: () => invMatches,
	invStatus: () => invStatus,
	isQuoteLike: () => isQuoteLike,
	isRmaDoc: () => isRmaDoc,
	lineTotal: () => lineTotal,
	nextNumber: () => nextNumber,
	noPartCol: () => noPartCol,
	partCol: () => partCol,
	payStatus: () => payStatus,
	totals: () => totals
});
var STATUS_LABEL = {
	quote: "Quote",
	rma: "RMA",
	open: "Not invoiced yet",
	invoiced: "Invoice – unpaid",
	paid: "Invoice – paid",
	completed: "Completed",
	cancelled: "Cancelled"
};
/** What to call the document on screen and on paper. */
function docName(status) {
	if (status === "quote") return "Quote";
	if (status === "rma") return "RMA";
	if (status === "open") return "Invoice";
	if (status === "cancelled") return "Cancelled";
	return "Invoice";
}
var STATUS_STYLE = {
	quote: "bg-sky-100 text-sky-800",
	rma: "bg-violet-100 text-violet-800",
	open: "bg-amber-100 text-amber-800",
	invoiced: "bg-red-100 text-red-800",
	paid: "bg-emerald-100 text-emerald-800",
	completed: "bg-emerald-100 text-emerald-800",
	cancelled: "bg-muted text-muted-foreground"
};
/** Quotes and RMAs: paperwork only, no money owed and no stock moved. */
var isQuoteLike = (s) => s === "quote" || s === "rma";
/** A cancelled RMA still has its RMA- number. */
var isRmaDoc = (o) => o.status === "rma" || (o.number ?? "").startsWith("RMA-");
var r2 = (n) => Math.round(n * 100) / 100;
function lineTotal(l) {
	const gross = Number(l.qty || 0) * Number(l.unit_price || 0);
	const d = Number(l.discount || 0);
	return r2(l.discount_is_percent ? gross * (1 - d / 100) : gross - d);
}
function totals(lines, taxRate, shipping) {
	const subtotal = r2(lines.reduce((s, l) => s + lineTotal(l), 0));
	const tax = r2(lines.filter((l) => l.taxable).reduce((s, l) => s + lineTotal(l), 0) * Number(taxRate || 0) / 100);
	return {
		subtotal,
		tax,
		total: r2(subtotal + tax + Number(shipping || 0))
	};
}
async function nextNumber(kind) {
	const { data, error } = await db.rpc("next_doc_number", { _kind: kind });
	if (error) throw error;
	return data;
}
function payStatus(o) {
	if (o.status === "quote") return "Quote";
	if (o.status === "rma") return "RMA";
	if (o.status === "cancelled") return "Cancelled";
	const total = Number(o.total), paid = Number(o.amount_paid), bal = Number(o.balance);
	if (bal <= .005 && o.status !== "open") return "Paid";
	if (total > 0 && bal <= .005) return "Paid";
	if (paid > 0) return "Partial";
	if (o.status === "open") return "Uninvoiced";
	return "Unpaid";
}
function invStatus(o) {
	if (o.status === "quote") return "Quote";
	if (o.status === "rma") return "RMA";
	if (o.stock_taken_at) return "Fulfilled";
	return o.part_moved ? "Partial" : "Unfulfilled";
}
var INV_LABEL = {
	Quote: "Quote",
	RMA: "RMA",
	Fulfilled: "Fulfilled",
	Partial: "Partly fulfilled",
	Unfulfilled: "Unfulfilled"
};
/** "Unfulfilled" in a filter means "still has something to send": none or only some sent. */
var invMatches = (s, want) => want === "Unfulfilled" ? s === "Unfulfilled" || s === "Partial" : s === want;
var partOk = true;
var partCol = () => partOk ? ",part_moved" : "";
/** The database doesn't have part_moved yet: stop asking (the caller tries again). */
function noPartCol(e) {
	if (partOk && e && /part_moved/.test(e.message ?? "")) {
		partOk = false;
		return true;
	}
	return false;
}
/** The badge at the top of a quote or invoice: paid, partly paid or unpaid, from the numbers. */
function docBadge(o) {
	const s = o.status;
	if (s === "invoiced" || s === "paid") {
		const p = payStatus(o);
		if (p === "Paid") return {
			label: "Invoice – paid",
			style: STATUS_STYLE.paid
		};
		if (p === "Partial") return {
			label: "Invoice – partly paid",
			style: PAY_STYLE.Partial
		};
		return {
			label: "Invoice – unpaid",
			style: STATUS_STYLE.invoiced
		};
	}
	if (s === "open" && Number(o.amount_paid) > .005) return {
		label: Number(o.balance) <= .005 ? "Not invoiced yet – paid" : "Not invoiced yet – partly paid",
		style: STATUS_STYLE.open
	};
	return {
		label: STATUS_LABEL[s],
		style: STATUS_STYLE[s]
	};
}
var PAY_STYLE = {
	Quote: "bg-sky-100 text-sky-800",
	RMA: "bg-violet-100 text-violet-800",
	Cancelled: "bg-muted text-muted-foreground line-through",
	Uninvoiced: "bg-amber-100 text-amber-800",
	Unpaid: "bg-red-100 text-red-800",
	Partial: "bg-orange-100 text-orange-800",
	Paid: "bg-emerald-100 text-emerald-800"
};
var INV_STYLE = {
	Quote: "bg-sky-100 text-sky-800",
	RMA: "bg-violet-100 text-violet-800",
	Fulfilled: "bg-emerald-100 text-emerald-800",
	Partial: "bg-orange-100 text-orange-800",
	Unfulfilled: "bg-muted text-foreground"
};
//#endregion
export { docName as a, isQuoteLike as c, nextNumber as d, noPartCol as f, totals as g, sales_DDkIS3CL_exports as h, docBadge as i, isRmaDoc as l, payStatus as m, INV_STYLE as n, invMatches as o, partCol as p, PAY_STYLE as r, invStatus as s, INV_LABEL as t, lineTotal as u };
