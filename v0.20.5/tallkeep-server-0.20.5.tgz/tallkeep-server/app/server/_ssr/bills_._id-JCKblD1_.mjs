import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-8tQCpcOj.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Nn as ArrowLeft, R as Plus, g as Trash2 } from "../_libs/lucide-react.mjs";
import { i as useIsAdmin } from "./queries-Chjya1cy.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-C_XVL5mk.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as OriginalLink } from "./OriginalLink-BOys2tL8.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { t as Route } from "./bills_._id-2fp2ja1I.mjs";
import { s as useAddVendor } from "./quickadd-Xo4-V0Jo.mjs";
import { s as useRealEstate } from "./realestate-DQ-XkZ06.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bills_._id-JCKblD1_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var newLine = () => ({
	id: crypto.randomUUID(),
	account_id: null,
	description: "",
	amount: 0
});
function BillPage() {
	const addVendorNow = useAddVendor();
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const isNew = id === "new";
	const paidNow = isNew && !!search.paid;
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { data: isAdmin } = useIsAdmin();
	const { data: accounts } = useAccounts();
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "names"],
		queryFn: () => fetchAll("vendors", "id,name,is_active")
	});
	const { data: loaded, isLoading } = useQuery({
		queryKey: ["bill", id],
		enabled: !isNew,
		queryFn: async () => {
			const [b, l, p] = await Promise.all([
				db.from("bills").select("*").eq("id", id).single(),
				db.from("bill_lines").select("*").eq("bill_id", id).order("line_no"),
				db.from("bill_payments").select("id,paid_on,amount,account_id,method,reference").eq("bill_id", id).order("paid_on")
			]);
			if (b.error) throw b.error;
			return {
				bill: b.data,
				lines: l.data ?? [],
				payments: p.data ?? []
			};
		}
	});
	const [bill, setBill] = (0, import_react.useState)({
		vendor_id: null,
		vendor_name: null,
		ref: null,
		bill_date: today(),
		due_date: null,
		memo: null,
		status: "open",
		total: 0,
		amount_paid: 0,
		balance: 0
	});
	const [lines, setLines] = (0, import_react.useState)([newLine()]);
	const [removed, setRemoved] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [payFrom, setPayFrom] = (0, import_react.useState)(null);
	const [method, setMethod] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (loaded) {
			setBill(loaded.bill);
			setLines(loaded.lines.length ? loaded.lines : [newLine()]);
			setRemoved([]);
		}
	}, [loaded]);
	const { data: features } = useFeatures();
	const realEstate = !!features?.includes("real_estate");
	const { data: re } = useRealEstate(realEstate);
	const propertyOptions = (re?.properties ?? []).filter((p) => p.is_active).map((p) => ({
		value: p.id,
		label: p.name
	}));
	const lineAccounts = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && ![
		"ar",
		"ap",
		"bank"
	].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	})), [accounts]);
	const payAccounts = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card")).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	})), [accounts]);
	(0, import_react.useEffect)(() => {
		if (!payFrom && payAccounts[0]) setPayFrom(payAccounts[0].value);
	}, [payAccounts, payFrom]);
	const total = lines.reduce((s, l) => s + (Number(l.amount) || 0), 0);
	const locked = bill.status === "void";
	const patchLine = (i, p) => setLines((ls) => ls.map((l, j) => j === i ? {
		...l,
		...p
	} : l));
	async function save() {
		const used = lines.filter((l) => Number(l.amount) || l.description.trim());
		if (!bill.vendor_name?.trim()) return void toast.error("Choose or type who the bill is from.");
		if (!used.length) return void toast.error("Add at least one line with an amount.");
		if (used.some((l) => !l.account_id)) return void toast.error("Choose an account for every line (what it was for).");
		if (paidNow && !payFrom) return void toast.error("Choose which account it was paid from.");
		setBusy(true);
		try {
			const head = {
				vendor_id: bill.vendor_id,
				vendor_name: bill.vendor_name?.trim() || null,
				ref: bill.ref?.trim() || null,
				bill_date: bill.bill_date,
				due_date: bill.due_date || null,
				memo: bill.memo?.trim() || null
			};
			let bid = bill.id;
			if (!bid) {
				const { data: u } = await db.auth.getUser();
				const { data, error } = await db.from("bills").insert({
					...head,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				bid = data.id;
			} else {
				const { error } = await db.from("bills").update(head).eq("id", bid);
				if (error) throw error;
			}
			if (removed.length) {
				const { error } = await db.from("bill_lines").delete().in("id", removed);
				if (error) throw error;
			}
			const { error: le } = await db.from("bill_lines").upsert(used.map((l, i) => ({
				id: l.id,
				bill_id: bid,
				line_no: i + 1,
				account_id: l.account_id,
				description: l.description.trim() || null,
				amount: Math.round((Number(l.amount) || 0) * 100) / 100,
				...realEstate ? { property_id: l.property_id || null } : {}
			})), { onConflict: "id" });
			if (le) throw le;
			if (paidNow) {
				const { error } = await db.from("bill_payments").insert({
					bill_id: bid,
					paid_on: bill.bill_date,
					amount: Math.round(total * 100) / 100,
					account_id: payFrom,
					method: method.trim() || null
				});
				if (error) throw error;
			}
			toast.success(paidNow ? "Expense saved." : "Bill saved.");
			qc.invalidateQueries({ queryKey: ["bills"] });
			qc.invalidateQueries({ queryKey: ["bill", bid] });
			qc.invalidateQueries({ queryKey: ["account-totals"] });
			if (isNew) navigate({
				to: "/bills/$id",
				params: { id: bid },
				search: {},
				replace: true
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function setVoid(v) {
		if (!bill.id) return;
		const { error } = await db.from("bills").update({ status: v ? "void" : "open" }).eq("id", bill.id);
		if (error) return void toast.error(error.message);
		if (!v) await db.rpc("refresh_bill", { _id: bill.id });
		toast.success(v ? "Bill voided: it no longer counts in the books." : "Bill is active again.");
		qc.invalidateQueries({ queryKey: ["bill", id] });
		qc.invalidateQueries({ queryKey: ["bills"] });
	}
	async function remove() {
		if (!bill.id || !window.confirm("Delete this bill and its payments for good?")) return;
		const { error } = await db.from("bills").delete().eq("id", bill.id);
		if (error) return void toast.error(error.message);
		toast.success("Bill deleted.");
		qc.invalidateQueries({ queryKey: ["bills"] });
		navigate({ to: "/bills" });
	}
	if (!isNew && (isLoading || !loaded)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" })] });
	const vendorOptions = (vendors ?? []).filter((v) => v.is_active || v.id === bill.vendor_id).sort((a, b) => a.name.localeCompare(b.name)).map((v) => ({
		value: v.id,
		label: v.name
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/bills",
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Bills & Expenses"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
				children: isNew ? paidNow ? "New expense" : "New bill" : `Bill from ${bill.vendor_name ?? ""}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalLink, {
						type: "bill",
						id: bill.id
					}),
					!isNew && bill.status !== "void" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void setVoid(true),
						children: "Void this bill"
					}),
					!isNew && bill.status === "void" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void setVoid(false),
						children: "Undo void"
					}),
					!isNew && isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => void remove(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy || locked,
						children: busy ? "Saving…" : isNew ? paidNow ? "Save expense" : "Save bill" : "Save"
					})
				]
			})]
		}),
		bill.status === "void" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl bg-muted p-3 text-sm",
			children: "This bill is void and not in the books."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2 sm:p-6 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "From (vendor)",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: bill.vendor_id,
						options: vendorOptions,
						placeholder: bill.vendor_name || "Choose a vendor",
						onAdd: addVendorNow,
						addLabel: "Add new vendor",
						searchText: "Type a vendor name",
						onChange: (v) => setBill({
							...bill,
							vendor_id: v,
							vendor_name: vendorOptions.find((o) => o.value === v)?.label ?? null
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						placeholder: "…or type a name (e.g. landlord)",
						value: bill.vendor_id ? "" : bill.vendor_name ?? "",
						onChange: (e) => setBill({
							...bill,
							vendor_id: null,
							vendor_name: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: paidNow ? "Receipt # (optional)" : "Bill # (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: bill.ref ?? "",
						onChange: (e) => setBill({
							...bill,
							ref: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: paidNow ? "Date paid" : "Bill date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: bill.bill_date,
						onChange: (e) => setBill({
							...bill,
							bill_date: e.target.value
						})
					})
				}),
				paidNow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Paid from",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: payFrom,
						options: payAccounts,
						placeholder: "Bank or credit card",
						onChange: setPayFrom
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Due date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: bill.due_date ?? "",
						onChange: (e) => setBill({
							...bill,
							due_date: e.target.value || null
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Memo",
					wide: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 2,
						value: bill.memo ?? "",
						onChange: (e) => setBill({
							...bill,
							memo: e.target.value
						})
					})
				}),
				paidNow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "How paid (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Check #, card, ACH…",
						value: method,
						onChange: (e) => setMethod(e.target.value)
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-2xl border bg-card p-4 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "What it was for"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-xl border",
					children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 p-2 sm:grid-cols-[minmax(0,2fr)_minmax(0,3fr)_8rem_2rem]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: l.account_id,
								options: lineAccounts,
								placeholder: "Account (e.g. Rent)",
								searchText: "Type an account",
								onChange: (v) => patchLine(i, { account_id: v }),
								disabled: locked
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Description",
								value: l.description,
								onChange: (e) => patchLine(i, { description: e.target.value }),
								disabled: locked
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								className: "text-right",
								value: l.amount || "",
								placeholder: "0.00",
								onChange: (e) => patchLine(i, { amount: Number(e.target.value) }),
								disabled: locked
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Remove line",
								disabled: locked,
								onClick: () => {
									setRemoved((r) => [...r, l.id]);
									setLines((ls) => ls.length > 1 ? ls.filter((_, j) => j !== i) : [newLine()]);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							}),
							realEstate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: l.property_id ?? "",
									options: propertyOptions,
									placeholder: "For which property? (optional)",
									onChange: (v) => patchLine(i, { property_id: v }),
									disabled: locked
								})
							})
						]
					}, l.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setLines((ls) => [...ls, newLine()]),
						disabled: locked,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-lg font-semibold",
						children: ["Total ", fmtMoney(total)]
					})]
				})
			]
		}),
		!isNew && loaded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Payments, {
			billId: bill.id,
			balance: Number(bill.balance),
			payments: loaded.payments,
			payAccounts,
			locked
		})
	] });
}
function Payments({ billId, balance, payments, payAccounts, locked }) {
	const qc = useQueryClient();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [p, setP] = (0, import_react.useState)({
		amount: balance,
		paid_on: today(),
		account_id: "",
		method: "",
		reference: ""
	});
	(0, import_react.useEffect)(() => setP((x) => ({
		...x,
		amount: balance,
		account_id: x.account_id || payAccounts[0]?.value || ""
	})), [balance, payAccounts]);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["bill", billId] });
		qc.invalidateQueries({ queryKey: ["bills"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	async function add() {
		if (!(p.amount > 0)) return void toast.error("Type the amount paid.");
		if (!p.account_id) return void toast.error("Choose which account it was paid from.");
		const { error } = await db.from("bill_payments").insert({
			bill_id: billId,
			amount: Math.round(p.amount * 100) / 100,
			paid_on: p.paid_on,
			account_id: p.account_id,
			method: p.method.trim() || null,
			reference: p.reference.trim() || null
		});
		if (error) return void toast.error(error.message);
		toast.success("Payment recorded.");
		setOpen(false);
		refresh();
	}
	async function del(pid) {
		if (!window.confirm("Remove this payment?")) return;
		const { error } = await db.from("bill_payments").delete().eq("id", pid);
		if (error) return void toast.error(error.message);
		refresh();
	}
	const name = (id) => payAccounts.find((a) => a.value === id)?.label ?? "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-semibold",
					children: ["Payments ", balance > .005 ? `· still owed ${fmtMoney(balance)}` : "· paid in full"]
				}), !locked && balance > .005 && !open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => setOpen(true),
					children: "Record a payment"
				})]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 rounded-xl border p-3 sm:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						step: "0.01",
						value: p.amount,
						onChange: (e) => setP({
							...p,
							amount: Number(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: p.paid_on,
						onChange: (e) => setP({
							...p,
							paid_on: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: p.account_id,
						options: payAccounts,
						placeholder: "Paid from",
						onChange: (v) => setP({
							...p,
							account_id: v
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Check #, card, ACH…",
						value: p.method,
						onChange: (e) => setP({
							...p,
							method: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void add(),
							children: "Save payment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setOpen(false),
							children: "Cancel"
						})]
					})
				]
			}),
			payments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No payments yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border text-sm",
				children: payments.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-28",
							children: fmtDate(x.paid_on)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1 text-muted-foreground",
							children: [name(x.account_id), x.method ? ` · ${x.method}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium tabular-nums",
							children: fmtMoney(x.amount)
						}),
						!locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							className: "h-7 w-7",
							"aria-label": "Remove payment",
							onClick: () => void del(x.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3.5 w-3.5" })
						})
					]
				}, x.id))
			})
		]
	});
}
//#endregion
export { BillPage as component };
