import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { D as Search, Ht as ExternalLink, R as Plus, qt as Copy } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { r as listSupportStaff } from "./support.functions-DkVO1o41.mjs";
import { c as publicOrigin, i as ago, n as TICKET_STATUS, s as ourTurn, t as PRIORITY } from "./support-Bri7jlNl.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets-d5f8Xed0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	["open", "Open"],
	["waiting", "Waiting on customer"],
	["done", "Done"],
	["all", "All"]
];
function Tickets() {
	const [filter, setFilter] = (0, import_react.useState)("open");
	const [mine, setMine] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const { data: tickets, isLoading } = useQuery({
		queryKey: ["tickets"],
		queryFn: () => fetchAll("tickets"),
		refetchInterval: 6e4
	});
	const { data: staff } = useQuery({
		queryKey: ["support-staff"],
		queryFn: () => listSupportStaff(),
		staleTime: 6e5
	});
	const { data: me } = useQuery({
		queryKey: ["me-id"],
		queryFn: async () => (await db.auth.getUser()).data.user?.id ?? null
	});
	const { data: slug } = useQuery({
		queryKey: ["support-slug"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("support_slug").maybeSingle();
			return data?.support_slug ?? null;
		}
	});
	const { data: origin } = useQuery({
		queryKey: ["public-origin"],
		queryFn: publicOrigin
	});
	const pageUrl = slug && origin ? `${origin}/help/${slug}` : null;
	const name = new Map((staff ?? []).map((s) => [s.id, s.name]));
	const rows = (0, import_react.useMemo)(() => {
		const list = (tickets ?? []).filter((t) => filter === "all" ? true : filter === "open" ? t.status === "new" || t.status === "open" : filter === "waiting" ? t.status === "waiting" : t.status === "done" || t.status === "closed").filter((t) => !mine || t.assigned_to === me).sort((a, b) => {
			return Number(ourTurn(b)) - Number(ourTurn(a)) || b.updated_at.localeCompare(a.updated_at);
		});
		return smartSearch(list, q, (t) => `${t.number} ${t.subject}`, (t) => `${t.name ?? ""} ${t.company_name ?? ""} ${t.email ?? ""}`);
	}, [
		tickets,
		filter,
		mine,
		me,
		q
	]);
	const count = (f) => (tickets ?? []).filter((t) => f === "open" ? t.status === "new" || t.status === "open" : f === "waiting" ? t.status === "waiting" : false).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Tickets",
			text: "Requests from your customers. Newest replies from customers come first.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tickets/$id",
					params: { id: "new" },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New ticket"]
				})
			})
		}),
		pageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2 rounded-xl border bg-card px-4 py-2 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Your support page:"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: pageUrl,
					target: "_blank",
					rel: "noreferrer",
					className: "font-medium underline",
					children: pageUrl
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => {
						copyText(pageUrl);
						toast.success("Link copied. Put it on your website or in your email signature.");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy link"]
				})
			]
		}) : slug === null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "rounded-xl border bg-card px-4 py-2 text-sm text-muted-foreground",
			children: [
				"Give your support page an address in",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/settings",
					hash: "features",
					className: "underline",
					children: "Settings → Features"
				}),
				" ",
				"so customers can open tickets themselves."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [FILTERS.map(([k, label]) => {
				const n = count(k);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setFilter(k),
					className: cn("rounded-full border px-3 py-1 text-sm", filter === k ? "border-transparent bg-[var(--section)] text-white" : "bg-card"),
					children: [label, n > 0 && ` (${n})`]
				}, k);
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "ml-1 flex items-center gap-1.5 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: mine,
					onChange: (e) => setMine(e.target.checked)
				}), "Only mine"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "pl-9",
				placeholder: "Search ticket #, customer or subject",
				value: q,
				onChange: (e) => setQ(e.target.value)
			})]
		}),
		isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: tickets?.length ? "No tickets here." : "No tickets yet."
			}), rows.map((t) => {
				const st = TICKET_STATUS[t.status] ?? TICKET_STATUS.open;
				const turn = ourTurn(t);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/tickets/$id",
					params: { id: t.id },
					className: "flex flex-wrap items-center gap-3 px-4 py-3 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-16 text-xs text-muted-foreground",
							children: t.number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: cn("truncate", turn ? "font-semibold" : "font-medium"),
								children: [turn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mr-1.5 inline-block h-2 w-2 rounded-full bg-[var(--section)]" }), t.subject]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: [[t.company_name, t.name].filter(Boolean).join(" · ") || t.email, t.topic ? ` · ${t.topic}` : ""]
							})]
						}),
						(t.priority === "high" || t.priority === "urgent") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2 py-0.5 text-xs font-medium", t.priority === "urgent" ? "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-200" : "bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-200"),
							children: PRIORITY[t.priority]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2 py-0.5 text-xs font-medium", st.tone),
							children: st.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-28 truncate text-right text-xs text-muted-foreground",
							children: t.assigned_to ? name.get(t.assigned_to) ?? "" : "Not assigned"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-right text-xs text-muted-foreground",
							children: ago(t.updated_at)
						})
					]
				}, t.id);
			})]
		}),
		pageUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "mr-1 inline h-3 w-3" }), "Customers can also follow their ticket with the link we email them."]
		})
	] });
}
//#endregion
export { Tickets as component };
