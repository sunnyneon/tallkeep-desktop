-- 074: Saved email wording. Each company can change the subject and message Tallkeep starts
-- with for its emails: quotes, invoices, quote follow-ups, payment reminders and purchase orders.
-- Empty means Tallkeep's own wording. Set in Settings → Features → Email wording.
alter table public.company_settings add column if not exists email_wording jsonb not null default '{}'::jsonb;

notify pgrst, 'reload schema';
