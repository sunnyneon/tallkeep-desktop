-- 073: Customers accept quotes online, and pay by bank account or Apple Pay as well as card.
-- 1) "Pay now" links (step 37) can also be for a quote: the customer sees the quote, types their
--    name to accept it, and pays the deposit if one was asked. The office computer picks up the
--    acceptance and marks the quote "Accepted online".
-- 2) How each online payment was made (card, bank account, Apple Pay…) is kept, so the books say
--    so. A bank payment takes a few days: the link shows it's on its way meanwhile.

-- ===== The payment links (Tallkeep's server) =====
alter table public.pay_requests add column if not exists kind text not null default 'invoice';
alter table public.pay_requests drop constraint if exists pay_requests_kind_check;
alter table public.pay_requests add constraint pay_requests_kind_check check (kind in ('invoice', 'quote'));
alter table public.pay_requests add column if not exists doc jsonb;            -- the quote as the customer sees it
alter table public.pay_requests add column if not exists accepted_at timestamptz;
alter table public.pay_requests add column if not exists accepted_name text;
alter table public.pay_requests add column if not exists accept_picked_up_at timestamptz;
alter table public.pay_requests add column if not exists method text;          -- card, us_bank_account, apple_pay…
alter table public.pay_requests add column if not exists pending_at timestamptz; -- a bank payment on its way

-- A quote with no deposit asks for no money; once accepted it is 'accepted'.
alter table public.pay_requests drop constraint if exists pay_requests_amount_cents_check;
alter table public.pay_requests add constraint pay_requests_amount_cents_check check (amount_cents >= 0);
alter table public.pay_requests drop constraint if exists pay_requests_status_check;
alter table public.pay_requests add constraint pay_requests_status_check
  check (status in ('open', 'paid', 'canceled', 'accepted'));

create index if not exists pay_requests_accept_pickup_idx on public.pay_requests (merchant_id)
  where accepted_at is not null and accept_picked_up_at is null;

-- ===== The business's books =====
alter table public.sales_orders add column if not exists accepted_at timestamptz;
alter table public.sales_orders add column if not exists accepted_name text;

notify pgrst, 'reload schema';
