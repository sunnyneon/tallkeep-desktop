-- 072: Invoice emails that go by themselves.
-- 1) A repeating invoice can be emailed to the customer (with its PDF) on the day it's made.
-- 2) Overdue reminders: a friendly email when an invoice is past due (say 3, 10 and 30 days),
--    stopping as soon as it's paid. Off until turned on in Settings → Features.
-- Every email sent or failed is written down (Invoice emails), so nothing is sent twice.

-- Backups put invoices back before repeating schedules, so an invoice's link to the schedule
-- that made it can't be a strict database link (step 71). It stays as a plain reference.
alter table public.sales_orders drop constraint if exists sales_orders_recurring_id_fkey;

alter table public.recurring add column if not exists email_customer boolean not null default false;

alter table public.company_settings add column if not exists reminders_on boolean not null default false;
alter table public.company_settings add column if not exists reminder_days int[] not null default '{3,10,30}';
-- Only invoices due on or after this date get reminders (so turning it on doesn't email old debts).
alter table public.company_settings add column if not exists reminders_from date;
alter table public.company_settings add column if not exists reminder_note text;

-- A customer who shouldn't get reminders (you call them instead).
alter table public.customers add column if not exists no_reminders boolean not null default false;

create table if not exists public.invoice_emails (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  sales_order_id uuid not null references public.sales_orders(id) on delete cascade,
  kind text not null check (kind in ('new','reminder')),
  step int not null default 0,          -- which reminder (1st, 2nd…); 0 for a new invoice
  to_email text,
  ok boolean not null,
  why text,                              -- why it didn't go
  at timestamptz not null default now()
);
create index if not exists invoice_emails_order_idx on public.invoice_emails (sales_order_id, at desc);
create index if not exists invoice_emails_company_idx on public.invoice_emails (company_id, at desc);
-- Never the same email twice.
create unique index if not exists invoice_emails_once
  on public.invoice_emails (sales_order_id, kind, step) where ok;

alter table public.invoice_emails enable row level security;
revoke all on public.invoice_emails from anon, authenticated;
grant select on public.invoice_emails to authenticated;
grant all on public.invoice_emails to service_role;
drop policy if exists "Staff can read" on public.invoice_emails;
create policy "Staff can read" on public.invoice_emails for select to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Sales')
         and company_id = (select public.active_company()));
-- Only the daily job (as the server) writes here.

-- Keep the look-only guard (step 70) on the new table too.
do $$ begin
  if to_regproc('public.trg_look_only') is not null then
    execute 'drop trigger if exists invoice_emails_look_only on public.invoice_emails';
    execute 'create trigger invoice_emails_look_only before insert or update or delete on public.invoice_emails
             for each row execute function public.trg_look_only()';
  end if;
end $$;

-- Fix for step 069: saving Company settings failed ("invalid input syntax for type uuid"),
-- because that table's id is a number. Ids that aren't uuids are now left out of the history line.
create or replace function public.as_uuid(_v text)
returns uuid language sql immutable as $$
  select case when _v ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then _v::uuid end
$$;

create or replace function public.trg_change_log()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  o jsonb := case when tg_op <> 'INSERT' then to_jsonb(old) end;
  n jsonb := case when tg_op <> 'DELETE' then to_jsonb(new) end;
  r jsonb := coalesce(n, o);
  b jsonb; a jsonb; k text;
  skip text[] := array['updated_at','created_at','imported_at','balance','amount_paid','subtotal','tax','total',
                       'last_followup_at','followup_count','pay_url'];
  dt text; di uuid; lbl text; src text;
begin
  -- Hand-typed journal entries only (the automatic books follow their documents).
  if tg_table_name = 'journal_entries' then
    src := r->>'source_type';
    if src not in ('manual','adjust','opening') then return null; end if;
  elsif tg_table_name = 'journal_lines' then
    select e.source_type into src from public.journal_entries e where e.id = (r->>'entry_id')::uuid;
    -- (an entry already gone: its own delete was logged, or it was an automatic one)
    if src is null or src not in ('manual','adjust','opening') then return null; end if;
  end if;

  if tg_op = 'UPDATE' then
    b := '{}'; a := '{}';
    for k in select jsonb_object_keys(n) loop
      continue when k = any(skip);
      if (o->k) is distinct from (n->k) then
        b := b || jsonb_build_object(k, o->k);
        a := a || jsonb_build_object(k, n->k);
      end if;
    end loop;
    if a = '{}'::jsonb then return null; end if;   -- nothing that matters changed
  elsif tg_op = 'INSERT' then
    a := n;
  else
    b := o;
  end if;

  dt := case tg_table_name
          when 'sales_order_lines' then 'sales_orders'
          when 'purchase_order_lines' then 'purchase_orders'
          when 'bill_lines' then 'bills'
          when 'bill_payments' then 'bills'
          when 'journal_lines' then 'journal_entries'
          when 'payments' then case when r ? 'sales_order_id' and r->>'sales_order_id' is not null
                                    then 'sales_orders' else 'purchase_orders' end
          else tg_table_name end;
  di := case tg_table_name
          when 'sales_order_lines' then (r->>'sales_order_id')::uuid
          when 'purchase_order_lines' then (r->>'purchase_order_id')::uuid
          when 'bill_lines' then (r->>'bill_id')::uuid
          when 'bill_payments' then (r->>'bill_id')::uuid
          when 'journal_lines' then (r->>'entry_id')::uuid
          when 'payments' then coalesce((r->>'sales_order_id')::uuid, (r->>'purchase_order_id')::uuid)
          else public.as_uuid(r->>'id') end;
  lbl := coalesce(r->>'number', r->>'name', r->>'ref', r->>'description', r->>'memo');

  insert into public.change_log (company_id, table_name, row_id, action, doc_table, doc_id, label,
                                 before, after, user_id, user_email)
  values ((r->>'company_id')::uuid, tg_table_name, public.as_uuid(r->>'id'), lower(tg_op), dt, di, left(lbl, 200),
          b, a, auth.uid(), (select email from auth.users where id = auth.uid()));
  return null;
end $$;


notify pgrst, 'reload schema';
