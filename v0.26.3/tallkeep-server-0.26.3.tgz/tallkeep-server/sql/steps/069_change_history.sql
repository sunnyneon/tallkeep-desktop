-- 069: Change history. Every save to the money and record tables is written down: who, when,
-- and what it was before and after (only the parts that changed). Nobody can edit or delete it,
-- not even an admin: the app may only read it, and only staff with the Accounting section.
-- Entries Tallkeep writes by itself from documents (the automatic books) aren't logged, since the
-- documents themselves are; hand-typed journal entries are.

create table if not exists public.change_log (
  id bigserial primary key,
  company_id uuid references public.companies(id) on delete cascade,
  table_name text not null,
  row_id uuid,
  action text not null check (action in ('insert','update','delete')),
  doc_table text,          -- the document it belongs to (a line's invoice, a payment's invoice…)
  doc_id uuid,
  label text,              -- what it was, in words (number, name…)
  before jsonb,
  after jsonb,
  user_id uuid,
  user_email text,
  at timestamptz not null default now()
);
create index if not exists change_log_company_at_idx on public.change_log (company_id, at desc);
create index if not exists change_log_doc_idx on public.change_log (doc_id, at desc);
create index if not exists change_log_row_idx on public.change_log (row_id, at desc);

alter table public.change_log enable row level security;
revoke all on public.change_log from anon, authenticated;
grant select on public.change_log to authenticated;
grant select on public.change_log to service_role;
drop policy if exists "Staff can read" on public.change_log;
create policy "Staff can read" on public.change_log for select to authenticated
  using (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')
         and company_id = (select public.active_company()));
-- No insert/update/delete rules: only the trigger below (as the database owner) writes here.

create or replace function public.trg_change_log()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  o jsonb := case when tg_op <> 'INSERT' then to_jsonb(old) end;
  n jsonb := case when tg_op <> 'DELETE' then to_jsonb(new) end;
  r jsonb := coalesce(n, o);
  b jsonb; a jsonb; k text;
  skip text[] := array['updated_at','created_at','imported_at','balance','amount_paid','subtotal','tax','total',
                       'last_followup_at','followup_count','pay_url'];
  dt text; di uuid; lbl text; src text;
begin
  -- Hand-typed journal entries only (the automatic books follow their documents).
  if tg_table_name = 'journal_entries' then
    src := r->>'source_type';
    if src not in ('manual','adjust','opening') then return null; end if;
  elsif tg_table_name = 'journal_lines' then
    select e.source_type into src from public.journal_entries e where e.id = (r->>'entry_id')::uuid;
    -- (an entry already gone: its own delete was logged, or it was an automatic one)
    if src is null or src not in ('manual','adjust','opening') then return null; end if;
  end if;

  if tg_op = 'UPDATE' then
    b := '{}'; a := '{}';
    for k in select jsonb_object_keys(n) loop
      continue when k = any(skip);
      if (o->k) is distinct from (n->k) then
        b := b || jsonb_build_object(k, o->k);
        a := a || jsonb_build_object(k, n->k);
      end if;
    end loop;
    if a = '{}'::jsonb then return null; end if;   -- nothing that matters changed
  elsif tg_op = 'INSERT' then
    a := n;
  else
    b := o;
  end if;

  dt := case tg_table_name
          when 'sales_order_lines' then 'sales_orders'
          when 'purchase_order_lines' then 'purchase_orders'
          when 'bill_lines' then 'bills'
          when 'bill_payments' then 'bills'
          when 'journal_lines' then 'journal_entries'
          when 'payments' then case when r ? 'sales_order_id' and r->>'sales_order_id' is not null
                                    then 'sales_orders' else 'purchase_orders' end
          else tg_table_name end;
  di := case tg_table_name
          when 'sales_order_lines' then (r->>'sales_order_id')::uuid
          when 'purchase_order_lines' then (r->>'purchase_order_id')::uuid
          when 'bill_lines' then (r->>'bill_id')::uuid
          when 'bill_payments' then (r->>'bill_id')::uuid
          when 'journal_lines' then (r->>'entry_id')::uuid
          when 'payments' then coalesce((r->>'sales_order_id')::uuid, (r->>'purchase_order_id')::uuid)
          else (r->>'id')::uuid end;
  lbl := coalesce(r->>'number', r->>'name', r->>'ref', r->>'description', r->>'memo');

  insert into public.change_log (company_id, table_name, row_id, action, doc_table, doc_id, label,
                                 before, after, user_id, user_email)
  values ((r->>'company_id')::uuid, tg_table_name, (r->>'id')::uuid, lower(tg_op), dt, di, left(lbl, 200),
          b, a, auth.uid(), (select email from auth.users where id = auth.uid()));
  return null;
end $$;

do $$
declare t text;
begin
  foreach t in array array['sales_orders','sales_order_lines','payments','purchase_orders','purchase_order_lines',
    'bills','bill_lines','bill_payments','journal_entries','journal_lines','accounts','customers','vendors',
    'products','stock_docs','tax_rates','company_settings'] loop
    if to_regclass('public.' || t) is not null then
      execute format('drop trigger if exists %I on public.%I', t || '_change_log', t);
      execute format('create trigger %I after insert or update or delete on public.%I
                      for each row execute function public.trg_change_log()', t || '_change_log', t);
    end if;
  end loop;
  -- Bank lines: what was done with them (not every line brought in).
  execute 'drop trigger if exists bank_transactions_change_log on public.bank_transactions';
  execute 'create trigger bank_transactions_change_log after update or delete on public.bank_transactions
           for each row execute function public.trg_change_log()';
end $$;

notify pgrst, 'reload schema';
