-- 071: Repeating invoices (monthly billing). "Repeat this invoice" saves a schedule: every week,
-- month, 3 months or year, from a first date, with an optional last date. On each date Tallkeep
-- makes a copy of that invoice (same customer, items, prices, terms, notes), as a ready invoice
-- or as an uninvoiced draft to check first. It never makes the same date twice.
-- Uses the same Recurring table and daily job as repeating payments and bills (step 22).

-- ===== Table changes =====
alter table public.recurring drop constraint if exists recurring_kind_check;
alter table public.recurring add constraint recurring_kind_check check (kind in ('check','bill','invoice'));
alter table public.recurring add column if not exists sales_order_id uuid references public.sales_orders(id) on delete set null;
alter table public.recurring add column if not exists as_draft boolean not null default false;
-- Dates count from the first one (so the 31st stays the 31st, or the month's last day).
alter table public.recurring add column if not exists start_date date;
alter table public.recurring add column if not exists steps int not null default 0;
alter table public.recurring add column if not exists last_error text;
create index if not exists recurring_order_idx on public.recurring (sales_order_id);

alter table public.sales_orders add column if not exists recurring_id uuid references public.recurring(id) on delete set null;
alter table public.sales_orders add column if not exists recurring_date date;
-- The guard against doubles: one invoice per schedule per date.
create unique index if not exists sales_orders_recurring_once
  on public.sales_orders (recurring_id, recurring_date) where recurring_id is not null;

-- People with the Sales section may set up repeating invoices (payments and bills stay Accounting).
drop policy if exists "Sales can repeat invoices" on public.recurring;
create policy "Sales can repeat invoices" on public.recurring for all to authenticated
  using (kind = 'invoice' and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Sales')
         and company_id = (select public.active_company()))
  with check (kind = 'invoice' and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Sales')
              and company_id = (select public.active_company()));

-- ===== Dates =====
-- The n-th date after a first date.
create or replace function public.recurring_after(_start date, _every text, _n int)
returns date language sql immutable as $$
  select (case _every
    when 'week' then _start + make_interval(days => 7 * _n)
    when 'quarter' then _start + make_interval(months => 3 * _n)
    when 'year' then _start + make_interval(years => _n)
    else _start + make_interval(months => _n) end)::date
$$;

-- Move a schedule on to its next date (and stop it after its last date).
create or replace function public.recurring_advance(_id uuid)
returns date language plpgsql security definer set search_path = public as $$
declare r record; d date;
begin
  select * into r from public.recurring where id = _id for update;
  d := case when r.start_date is null then public.recurring_next(r.next_date, r.every)
            else public.recurring_after(r.start_date, r.every, r.steps + 1) end;
  update public.recurring
     set next_date = d, steps = r.steps + 1, last_error = null,
         active = case when r.end_date is not null and d > r.end_date then false else r.active end
   where id = _id;
  return d;
end $$;
revoke all on function public.recurring_advance(uuid) from public, anon, authenticated;

-- ===== Make one invoice =====
create or replace function public.make_recurring_invoice(_id uuid, _date date)
returns uuid language plpgsql security definer set search_path = public as $$
declare r record; s public.sales_orders; n uuid := gen_random_uuid(); num text; p text; k int;
        days int; at timestamptz := (_date + time '12:00')::timestamptz;
begin
  select * into r from public.recurring where id = _id;
  if r.id is null then raise exception 'Not found'; end if;
  -- Already made for this date: hand back that one.
  select id into n from public.sales_orders where recurring_id = _id and recurring_date = _date;
  if n is not null then return n; end if;
  n := gen_random_uuid();
  select * into s from public.sales_orders where id = r.sales_order_id;
  if s.id is null then raise exception 'The invoice it copies was deleted. Pick another one to repeat.'; end if;

  -- The next invoice number in that company.
  insert into public.doc_counters (company_id, kind, prefix, next_number)
  values (r.company_id, 'sales_order', 'INV-', 1001) on conflict (company_id, kind) do nothing;
  update public.doc_counters set next_number = next_number + 1
   where company_id = r.company_id and kind = 'sales_order'
   returning prefix, next_number - 1 into p, k;
  num := p || lpad(k::text, 6, '0');

  select days_due into days from public.payment_terms where id = s.payment_terms_id;

  insert into public.sales_orders
  select (jsonb_populate_record(null::public.sales_orders,
    to_jsonb(s) || jsonb_build_object(
      'id', n, 'number', num, 'inflow_id', null,
      'status', case when r.as_draft then 'open' else 'invoiced' end,
      'order_date', at,
      'invoice_date', case when r.as_draft then null else at end,
      'due_date', case when r.as_draft then null else at + make_interval(days => coalesce(days, 0)) end,
      'ship_by', null, 'amount_paid', 0, 'balance', s.total, 'stock_taken_at', null,
      'followup_count', 0, 'last_followup_at', null, 'pay_url', null, 'closed_reason', null,
      'ticket_id', null, 'custom', '{}'::jsonb, 'created_by', r.created_by,
      'created_at', now(), 'updated_at', now(),
      'recurring_id', r.id, 'recurring_date', _date))).*;

  insert into public.sales_order_lines
  select (jsonb_populate_record(null::public.sales_order_lines,
    to_jsonb(l) || jsonb_build_object('id', gen_random_uuid(), 'sales_order_id', n,
      'inflow_id', null, 'qty_fulfilled', 0, 'serials', null))).*
    from public.sales_order_lines l where l.sales_order_id = s.id order by l.line_no;

  update public.recurring set last_made = _date where id = _id;
  return n;
end $$;
revoke all on function public.make_recurring_invoice(uuid, date) from public, anon, authenticated;

-- Payments and bills as before; invoices by the function above.
create or replace function public.make_recurring(_id uuid, _date date)
returns uuid language plpgsql security definer set search_path = public as $$
declare r record; n uuid; x jsonb; i int := 0; vname text;
begin
  select * into r from public.recurring where id = _id;
  if r.id is null then raise exception 'Not found'; end if;
  if r.kind = 'invoice' then return public.make_recurring_invoice(_id, _date); end if;
  vname := coalesce(r.payee, (select name from public.vendors where id = r.vendor_id), r.name);
  if r.kind = 'check' then
    insert into public.checks (company_id, account_id, method, number, check_date, vendor_id, payee, memo, to_print)
    values (r.company_id, r.account_id, r.method, null, _date, r.vendor_id, vname,
            coalesce(r.memo, r.name), r.method = 'check')
    returning id into n;
    for x in select value from jsonb_array_elements(r.lines) loop
      i := i + 1;
      insert into public.check_lines (company_id, check_id, line_no, account_id, description, amount, property_id)
      values (r.company_id, n, i, (x->>'account_id')::uuid, nullif(x->>'description', ''),
              coalesce((x->>'amount')::numeric, 0), nullif(x->>'property_id', '')::uuid);
    end loop;
  else
    insert into public.bills (company_id, vendor_id, vendor_name, bill_date, due_date, memo)
    values (r.company_id, r.vendor_id, vname, _date, _date, coalesce(r.memo, r.name))
    returning id into n;
    for x in select value from jsonb_array_elements(r.lines) loop
      i := i + 1;
      insert into public.bill_lines (company_id, bill_id, line_no, account_id, description, amount, property_id)
      values (r.company_id, n, i, (x->>'account_id')::uuid, nullif(x->>'description', ''),
              coalesce((x->>'amount')::numeric, 0), nullif(x->>'property_id', '')::uuid);
    end loop;
  end if;
  update public.recurring set last_made = _date where id = _id;
  return n;
end $$;
revoke all on function public.make_recurring(uuid, date) from public, anon, authenticated;
grant execute on function public.make_recurring(uuid, date) to service_role;

-- "Make the next one now": invoices need the Sales section, payments and bills Accounting.
create or replace function public.make_recurring_now(_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare r record; n uuid;
begin
  select * into r from public.recurring where id = _id and company_id = public.active_company();
  if r.id is null then raise exception 'Not found'; end if;
  if not (public.is_staff(auth.uid())
          and public.has_zone(auth.uid(), case when r.kind = 'invoice' then 'Sales' else 'Accounting' end))
  then raise exception 'Not allowed'; end if;
  if public.is_look_only(r.company_id) then
    raise exception 'You can look in this company but not change anything. Ask an admin if you need to.';
  end if;
  n := public.make_recurring(_id, r.next_date);
  perform public.recurring_advance(_id);
  return n;
end $$;
grant execute on function public.make_recurring_now(uuid) to authenticated;

-- The daily job: everything due, one date at a time. One schedule failing (say, its invoice was
-- deleted) is paused with the reason and doesn't stop the others.
create or replace function public.run_recurring_company(_co uuid, _today date)
returns integer language plpgsql security definer set search_path = public as $$
declare r record; k int := 0; guard int; d date;
begin
  for r in select id from public.recurring
            where company_id = _co and active and auto and next_date <= _today loop
    guard := 0;
    loop
      select next_date into d from public.recurring where id = r.id;
      exit when d > _today or guard >= 60;
      begin
        if (select end_date from public.recurring where id = r.id) is not null
           and d > (select end_date from public.recurring where id = r.id) then
          update public.recurring set active = false where id = r.id;
          exit;
        end if;
        perform public.make_recurring(r.id, d);
        perform public.recurring_advance(r.id);
        k := k + 1;
      exception when others then
        update public.recurring set active = false, last_error = sqlerrm where id = r.id;
        exit;
      end;
      guard := guard + 1;
      exit when not (select active from public.recurring where id = r.id);
    end loop;
  end loop;
  return k;
end $$;
revoke all on function public.run_recurring_company(uuid, date) from public, anon, authenticated;
grant execute on function public.run_recurring_company(uuid, date) to service_role;

-- What a repeating schedule will make next (for the preview): its next few dates.
create or replace function public.recurring_preview(_start date, _every text, _end date, _count int default 4)
returns setof date language sql immutable as $$
  select public.recurring_after(_start, _every, g)
    from generate_series(0, greatest(_count, 1) - 1) g
   where _end is null or public.recurring_after(_start, _every, g) <= _end
$$;
grant execute on function public.recurring_preview(date, text, date, int) to authenticated;

notify pgrst, 'reload schema';
