-- 070: "Can look, can't change" — a person (an accountant, a bookkeeper checking the books) who
-- opens a company to read, print and download, but can't add, change or delete anything in it.
-- Set per company in Settings → Users. Account admins and company admins are never look-only.
-- The database enforces it on every business table, including the changes made through
-- Tallkeep's own functions (stock, fulfilment, receiving, books…), not just in the app.

alter table public.company_members add column if not exists read_only boolean not null default false;

-- Is the signed-in person only allowed to look in this company?
create or replace function public.is_look_only(_c uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and _c is not null
     and not public.has_role(auth.uid(), 'admin')
     and exists (select 1 from public.company_members m
                  where m.user_id = auth.uid() and m.company_id = _c
                    and m.read_only and not m.is_admin)
$$;
grant execute on function public.is_look_only(uuid) to authenticated;

-- The same answer for the company this window is working in (for the app).
create or replace function public.look_only()
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_look_only(public.active_company())
$$;
grant execute on function public.look_only() to authenticated;

-- Writing is refused while the plan has ended (step 28) and now also for look-only people.
create or replace function public.can_write_company(_c uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select _c is null
      or (public.org_can_write((select org_id from public.companies where id = _c))
          and not public.is_look_only(_c))
$$;
grant execute on function public.can_write_company(uuid) to authenticated;

-- A guard on every business table, so Tallkeep's own functions (which skip the table rules)
-- refuse too. Background jobs and backups have no signed-in person and aren't affected.
create or replace function public.trg_look_only()
returns trigger language plpgsql security definer set search_path = public as $$
declare c uuid;
begin
  if auth.uid() is null then return coalesce(new, old); end if;
  c := case when tg_op = 'DELETE' then old.company_id else new.company_id end;
  if public.is_look_only(c) then
    raise exception 'You can look in this company but not change anything. Ask an admin if you need to.'
      using errcode = '42501';
  end if;
  return coalesce(new, old);
end $$;

do $$
declare t text;
begin
  for t in
    select c.table_name from information_schema.columns c
      join information_schema.tables x on x.table_schema = c.table_schema and x.table_name = c.table_name
     where c.table_schema = 'public' and c.column_name = 'company_id' and x.table_type = 'BASE TABLE'
       -- picking a company, who opens what, the change history (written by its own trigger),
       -- and the AI's usage count stay open
       and c.table_name not in ('user_company', 'company_members', 'change_log', 'ai_usage')
  loop
    execute format('drop trigger if exists %I on public.%I', t || '_look_only', t);
    execute format('create trigger %I before insert or update or delete on public.%I
                    for each row execute function public.trg_look_only()', t || '_look_only', t);
  end loop;
end $$;

notify pgrst, 'reload schema';
