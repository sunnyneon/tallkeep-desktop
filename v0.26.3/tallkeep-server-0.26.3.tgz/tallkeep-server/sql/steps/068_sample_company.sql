-- 068: A sample company to try things in, record tutorials with, and see how records connect.
-- "Bright Signs Co. (Sample)": a small sign shop with customers, products in two places, quotes,
-- invoices (paid, part paid, partly fulfilled), purchase orders (one part received), bills, a
-- bank account with lines to review, and a few months of books. Its dates follow today.
-- Settings → Company: switch it on (made fresh) or off (removed). Off then on starts it over.
-- It doesn't count toward the plan's companies and never mixes with real books.

alter table public.companies add column if not exists is_sample boolean not null default false;

-- The plan's company count leaves the sample out.
create or replace function public.create_company(_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare n uuid; o uuid := public.my_org(); lim int;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can add a company.'; end if;
  if o is null then raise exception 'Your account is not set up yet.'; end if;
  if not public.org_can_write(o) then
    raise exception 'Your account is read-only. Choose a plan to keep working.';
  end if;
  select companies_allowed into lim from public.orgs where id = o;
  if lim is not null and (select count(*) from public.companies where org_id = o and not is_sample) >= lim then
    raise exception 'Your plan includes % compan%. Add another company to your plan first.',
      lim, case when lim = 1 then 'y' else 'ies' end;
  end if;
  if coalesce(trim(_name), '') = '' then raise exception 'Type the company name.'; end if;
  n := public.make_company(o, trim(_name), null, null, auth.uid(), public.active_company());
  insert into public.tax_rates (company_id, name, rate, is_active)
    select n, name, rate, is_active from public.tax_rates where company_id = public.active_company();
  return n;
end $$;
grant execute on function public.create_company(text) to authenticated;

-- Remove a sample company and everything in it (only ever a sample).
create or replace function public.drop_sample_company(_co uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t record; pass int; left_over int;
begin
  if not exists (select 1 from public.companies where id = _co and is_sample) then
    raise exception 'Only the sample company can be removed this way';
  end if;
  -- Everything with this company's id, in passes (children before parents).
  for pass in 1..8 loop
    left_over := 0;
    for t in
      select c.table_name from information_schema.columns c
        join information_schema.tables tb on tb.table_schema = c.table_schema and tb.table_name = c.table_name
       where c.table_schema = 'public' and c.column_name = 'company_id' and tb.table_type = 'BASE TABLE'
         and c.table_name not in ('companies')
    loop
      begin
        execute format('delete from public.%I where company_id = $1', t.table_name) using _co;
      exception when foreign_key_violation then
        left_over := left_over + 1;
      end;
    end loop;
    exit when left_over = 0;
  end loop;
  delete from public.companies where id = _co;
end $$;
revoke execute on function public.drop_sample_company(uuid) from public, anon, authenticated;

-- Stock in or out for the sample (no signed-in company needed).
create or replace function public.sample_move(_co uuid, _p uuid, _loc uuid, _shelf text, _qty numeric,
  _reason text, _ref_type text, _ref_id uuid, _at timestamptz, _note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.stock (company_id, product_id, location_id, shelf, qty)
  values (_co, _p, _loc, coalesce(_shelf, ''), _qty)
  on conflict (product_id, location_id, shelf) do update set qty = public.stock.qty + excluded.qty, updated_at = now();
  insert into public.stock_moves (company_id, product_id, location_id, shelf, qty_change, reason, note, ref_type, ref_id, created_at)
  values (_co, _p, _loc, coalesce(_shelf, ''), _qty, _reason, _note, _ref_type, _ref_id, _at);
end $$;
revoke execute on function public.sample_move(uuid, uuid, uuid, text, numeric, text, text, uuid, timestamptz, text) from public, anon, authenticated;

-- Totals of a sample sales order or purchase order from its lines.
create or replace function public.sample_totals(_so uuid, _po uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if _so is not null then
    update public.sales_orders o set
      subtotal = x.sub, tax = round(x.taxable * coalesce(o.tax_rate, 0) / 100, 2),
      total = x.sub + round(x.taxable * coalesce(o.tax_rate, 0) / 100, 2) + coalesce(o.shipping, 0),
      balance = x.sub + round(x.taxable * coalesce(o.tax_rate, 0) / 100, 2) + coalesce(o.shipping, 0) - coalesce(o.amount_paid, 0)
      from (select coalesce(sum(line_total), 0) sub, coalesce(sum(line_total) filter (where taxable), 0) taxable
              from public.sales_order_lines where sales_order_id = _so) x
     where o.id = _so;
  end if;
  if _po is not null then
    update public.purchase_orders o set
      subtotal = x.sub, tax = 0, total = x.sub + coalesce(o.freight, 0),
      balance = x.sub + coalesce(o.freight, 0) - coalesce(o.amount_paid, 0)
      from (select coalesce(sum(line_total), 0) sub from public.purchase_order_lines where purchase_order_id = _po) x
     where o.id = _po;
  end if;
end $$;
revoke execute on function public.sample_totals(uuid, uuid) from public, anon, authenticated;

-- Build the sample company. Returns its id.
create or replace function public.build_sample_company(_org uuid, _uid uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  co uuid; d0 date := (date_trunc('month', current_date) - interval '3 months')::date;
  shop uuid; van uuid; bank uuid; tax numeric := 8.25;
  c1 uuid; c2 uuid; c3 uuid; c4 uuid; c5 uuid; c6 uuid; v1 uuid; v2 uuid; v3 uuid;
  p1 uuid; p2 uuid; p3 uuid; p4 uuid; p5 uuid; p6 uuid; p7 uuid; p8 uuid; s1 uuid; s2 uuid;
  o uuid; po uuid; b uuid; l1 uuid; l2 uuid; e uuid;
begin
  co := public.make_company(_org, 'Bright Signs Co. (Sample)', 'products',
                            array['sales','purchasing','inventory','accounting'], _uid, null);
  update public.companies set is_sample = true where id = co;
  update public.company_settings set
    name = 'Bright Signs Co.', books_start_date = d0,
    address = E'1200 Main Street\nSpringfield, TX 75000',
    phone = '(555) 010-2030', email = 'hello@brightsigns.example', website = 'brightsigns.example'
   where company_id = co;
  insert into public.tax_rates (company_id, name, rate, is_active) values (co, 'Springfield Sales Tax', tax, true);
  bank := public.acct(co, 'bank');
  update public.accounts set name = 'Checking (Sample Bank 4321)' where id = bank;

  -- Places
  insert into public.locations (company_id, name) values (co, 'Shop') returning id into shop;
  insert into public.locations (company_id, name) values (co, 'Service Van') returning id into van;

  -- Customers
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'Maple Street Cafe', 'Dana Lee', '(555) 201-1001', 'dana@maplecafe.example', E'45 Maple St\nSpringfield, TX 75001') returning id into c1;
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'Springfield Dental', 'Dr. Ruiz', '(555) 201-1002', 'office@sfdental.example', E'300 Oak Ave\nSpringfield, TX 75002') returning id into c2;
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'Riverside Church', 'Pastor Tom', '(555) 201-1003', 'tom@riverside.example', E'9 River Rd\nSpringfield, TX 75003') returning id into c3;
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'Lone Oak Auto', 'Sam Patel', '(555) 201-1004', 'sam@loneoak.example', E'770 Hwy 5\nSpringfield, TX 75004') returning id into c4;
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'City of Springfield', 'Parks Dept.', '(555) 201-1005', 'parks@springfield.example', E'1 City Hall Plaza\nSpringfield, TX 75000') returning id into c5;
  insert into public.customers (company_id, name, contact_name, phone, email, billing_address) values
    (co, 'Green Leaf Market', 'Ana Gomez', '(555) 201-1006', 'ana@greenleaf.example', E'88 Market St\nSpringfield, TX 75005') returning id into c6;

  -- Vendors
  insert into public.vendors (company_id, name, contact_name, phone, email) values
    (co, 'Bright LED Supply', 'Kevin Wu', '(555) 301-2001', 'orders@brightled.example') returning id into v1;
  insert into public.vendors (company_id, name, contact_name, phone, email) values
    (co, 'Metro Sign Parts', 'Lisa Brown', '(555) 301-2002', 'sales@metroparts.example') returning id into v2;
  insert into public.vendors (company_id, name, contact_name, phone, email) values
    (co, 'Springfield Properties', 'Office', '(555) 301-2003', 'rent@sfprop.example') returning id into v3;

  -- Products (stocked) and services
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'LED Open Sign 24in', 'Bright LED "OPEN" sign, 24 x 12 in, with remote', 'stocked', 45, 129, 5, shop, 'A1') returning id into p1;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Channel Letter Kit', 'Lit channel letter set, up to 8 letters', 'stocked', 380, 950, 2, shop, 'B2') returning id into p2;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'LED Module 3-pack', 'White LED modules for sign boxes, 3 per string', 'stocked', 2.4, 6.5, 200, shop, 'C1') returning id into p3;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Power Supply 12V 100W', 'Weatherproof 12V LED power supply', 'stocked', 18, 49, 10, shop, 'C2') returning id into p4;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Aluminum Sign Panel 4x8', 'Blank aluminum composite panel, 4 x 8 ft', 'stocked', 62, 145, 4, shop, 'D1') returning id into p5;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Vinyl Roll 24in x 50yd', 'Outdoor cast vinyl, 24 in x 50 yd', 'stocked', 140, 260, 2, shop, 'D2') returning id into p6;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Digital Display 55in', 'Outdoor digital sign display, 55 in', 'stocked', 1450, 3200, 1, shop, 'E1') returning id into p7;
  insert into public.products (company_id, name, description, item_type, cost, price, reorder_point, default_location_id, default_shelf) values
    (co, 'Photocell Timer', 'Dusk-to-dawn sign timer', 'stocked', 9, 29, 6, van, '') returning id into p8;
  insert into public.products (company_id, name, description, item_type, cost, price) values
    (co, 'Installation Labor', 'Installation per hour, two-person crew', 'service', 0, 125) returning id into s1;
  insert into public.products (company_id, name, description, item_type, cost, price) values
    (co, 'Design Fee', 'Sign design and proof', 'service', 0, 250) returning id into s2;

  -- Opening money and stock on the first day
  insert into public.journal_entries (company_id, entry_date, memo, source_type)
  values (co, d0 - 1, 'Opening balance of the checking account', 'opening') returning id into e;
  insert into public.journal_lines (company_id, entry_id, account_id, debit, credit) values
    (co, e, bank, 18500, 0), (co, e, public.acct(co, 'opening'), 0, 18500);
  perform public.sample_move(co, p1, shop, 'A1', 14, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p2, shop, 'B2', 4, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p3, shop, 'C1', 600, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p4, shop, 'C2', 25, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p5, shop, 'D1', 10, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p6, shop, 'D2', 3, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p7, shop, 'E1', 2, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p8, van, '', 12, 'import', null, null, d0::timestamptz, 'Opening stock');
  perform public.sample_move(co, p4, van, '', 6, 'import', null, null, d0::timestamptz, 'Opening stock');

  -- Invoice 1: paid in full, fulfilled
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, shipping_address, order_date, invoice_date, due_date, tax_name, tax_rate, project_name, sales_rep, location_id)
  values (co, 'INV-001001', 'invoiced', c1, 'Maple Street Cafe', 'Dana Lee', '(555) 201-1001', 'dana@maplecafe.example',
      E'45 Maple St\nSpringfield, TX 75001', E'45 Maple St\nSpringfield, TX 75001',
      d0 + 9, d0 + 9, d0 + 9, 'Springfield Sales Tax', tax, 'Storefront open sign', 'Sample Rep', shop)
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable, qty_fulfilled) values
    (co, o, 1, p1, 'LED Open Sign 24in — Bright LED "OPEN" sign, 24 x 12 in, with remote', 2, 129, 258, true, 2),
    (co, o, 2, p8, 'Photocell Timer — Dusk-to-dawn sign timer', 2, 29, 58, true, 2),
    (co, o, 3, s1, 'Installation Labor — mount and wire both signs', 2, 125, 250, false, 0);
  perform public.sample_totals(o, null);
  perform public.sample_move(co, p1, shop, 'A1', -2, 'sold', 'sales_order', o, (d0 + 10)::timestamptz);
  perform public.sample_move(co, p8, van, '', -2, 'sold', 'sales_order', o, (d0 + 10)::timestamptz);
  update public.sales_orders set stock_taken_at = (d0 + 10)::timestamptz where id = o;
  insert into public.payments (company_id, sales_order_id, paid_on, amount, method, reference, account_id)
    select co, o, d0 + 20, total, 'check', '1047', bank from public.sales_orders where id = o;

  -- Invoice 2: channel letters, half paid (deposit), fulfilled
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, shipping_address, order_date, invoice_date, due_date, tax_name, tax_rate, project_name, sales_rep, location_id)
  values (co, 'INV-001002', 'invoiced', c2, 'Springfield Dental', 'Dr. Ruiz', '(555) 201-1002', 'office@sfdental.example',
      E'300 Oak Ave\nSpringfield, TX 75002', E'300 Oak Ave\nSpringfield, TX 75002',
      d0 + 25, d0 + 25, d0 + 55, 'Springfield Sales Tax', tax, 'Building channel letters', 'Sample Rep', shop)
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable, qty_fulfilled) values
    (co, o, 1, s2, 'Design Fee — logo letters, two proofs', 1, 250, 250, false, 0),
    (co, o, 2, p2, 'Channel Letter Kit — "DENTAL" lit letters', 1, 950, 950, true, 1),
    (co, o, 3, p4, 'Power Supply 12V 100W', 2, 49, 98, true, 2),
    (co, o, 4, s1, 'Installation Labor — 6 hours', 6, 125, 750, false, 0);
  perform public.sample_totals(o, null);
  perform public.sample_move(co, p2, shop, 'B2', -1, 'sold', 'sales_order', o, (d0 + 30)::timestamptz);
  perform public.sample_move(co, p4, shop, 'C2', -2, 'sold', 'sales_order', o, (d0 + 30)::timestamptz);
  update public.sales_orders set stock_taken_at = (d0 + 30)::timestamptz where id = o;
  insert into public.payments (company_id, sales_order_id, paid_on, amount, method, reference, account_id)
    select co, o, d0 + 26, round(total / 2, 2), 'card', 'Deposit', bank from public.sales_orders where id = o;

  -- Invoice 3: digital display, partly fulfilled (screen out, power supplies still to go), unpaid
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, shipping_address, order_date, invoice_date, due_date, tax_name, tax_rate, project_name, sales_rep, location_id, po_number)
  values (co, 'INV-001003', 'invoiced', c3, 'Riverside Church', 'Pastor Tom', '(555) 201-1003', 'tom@riverside.example',
      E'9 River Rd\nSpringfield, TX 75003', E'9 River Rd\nSpringfield, TX 75003',
      current_date - 12, current_date - 12, current_date + 18, 'Springfield Sales Tax', tax, 'Message board', 'Sample Rep', shop, 'RC-2214')
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable, qty_fulfilled) values
    (co, o, 1, p7, 'Digital Display 55in — outdoor message board', 1, 3200, 3200, true, 1),
    (co, o, 2, p4, 'Power Supply 12V 100W — spare', 2, 49, 98, true, 0),
    (co, o, 3, s1, 'Installation Labor — 8 hours', 8, 125, 1000, false, 0);
  perform public.sample_totals(o, null);
  perform public.sample_move(co, p7, shop, 'E1', -1, 'sold', 'sales_order', o, (current_date - 10)::timestamptz);
  insert into public.stock_batches (company_id, doc_type, doc_id, location_id, lines, created_at)
    select co, 'sales_order', o, shop, jsonb_build_array(jsonb_build_object('line', id, 'qty', 1)), (current_date - 10)::timestamptz
      from public.sales_order_lines where sales_order_id = o and line_no = 1;

  -- Invoice 4: not invoiced yet (an order), signs for the market
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, shipping_address, order_date, tax_name, tax_rate, project_name, sales_rep, location_id)
  values (co, 'INV-001004', 'open', c6, 'Green Leaf Market', 'Ana Gomez', '(555) 201-1006', 'ana@greenleaf.example',
      E'88 Market St\nSpringfield, TX 75005', E'88 Market St\nSpringfield, TX 75005',
      current_date - 3, 'Springfield Sales Tax', tax, 'Window and aisle signs', 'Sample Rep', shop)
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable) values
    (co, o, 1, p5, 'Aluminum Sign Panel 4x8 — printed aisle signs', 3, 145, 435, true),
    (co, o, 2, p1, 'LED Open Sign 24in', 1, 129, 129, true);
  perform public.sample_totals(o, null);

  -- Quotes
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, order_date, tax_name, tax_rate, project_name, sales_rep, followup_count, last_followup_at)
  values (co, 'SQ-001001', 'quote', c4, 'Lone Oak Auto', 'Sam Patel', '(555) 201-1004', 'sam@loneoak.example',
      E'770 Hwy 5\nSpringfield, TX 75004', current_date - 20, 'Springfield Sales Tax', tax, 'Pylon sign refresh', 'Sample Rep',
      1, current_date - 6)
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable) values
    (co, o, 1, p5, 'Aluminum Sign Panel 4x8 — printed both sides', 2, 145, 290, true),
    (co, o, 2, p3, 'LED Module 3-pack — relight the pylon', 120, 6.5, 780, true),
    (co, o, 3, p4, 'Power Supply 12V 100W', 3, 49, 147, true),
    (co, o, 4, s1, 'Installation Labor — 5 hours with lift', 5, 125, 625, false);
  perform public.sample_totals(o, null);
  insert into public.sales_orders (company_id, number, status, customer_id, customer_name, contact_name, phone, email,
      billing_address, order_date, tax_name, tax_rate, project_name, sales_rep)
  values (co, 'SQ-001002', 'quote', c5, 'City of Springfield', 'Parks Dept.', '(555) 201-1005', 'parks@springfield.example',
      E'1 City Hall Plaza\nSpringfield, TX 75000', current_date - 2, 'Springfield Sales Tax', 0, 'Park entrance sign', 'Sample Rep')
  returning id into o;
  insert into public.sales_order_lines (company_id, sales_order_id, line_no, product_id, description, qty, unit_price, line_total, taxable) values
    (co, o, 1, s2, 'Design Fee — park entrance sign', 1, 250, 250, false),
    (co, o, 2, p2, 'Channel Letter Kit — "RIVER PARK"', 1, 950, 950, false),
    (co, o, 3, s1, 'Installation Labor — 6 hours', 6, 125, 750, false);
  perform public.sample_totals(o, null);

  -- Purchase order 1: received and paid
  insert into public.purchase_orders (company_id, number, status, vendor_id, vendor_name, contact_name, location_id, order_date, due_date)
  values (co, 'PO-001001', 'paid', v1, 'Bright LED Supply', 'Kevin Wu', shop, d0 + 15, d0 + 45) returning id into po;
  insert into public.purchase_order_lines (company_id, purchase_order_id, line_no, product_id, description, qty, unit_cost, line_total, qty_received) values
    (co, po, 1, p3, 'LED Module 3-pack', 300, 2.4, 720, 300),
    (co, po, 2, p4, 'Power Supply 12V 100W', 10, 18, 180, 10);
  perform public.sample_totals(null, po);
  perform public.sample_move(co, p3, shop, 'C1', 300, 'received', 'purchase_order', po, (d0 + 22)::timestamptz);
  perform public.sample_move(co, p4, shop, 'C2', 10, 'received', 'purchase_order', po, (d0 + 22)::timestamptz);
  update public.purchase_orders set stock_received_at = (d0 + 22)::timestamptz where id = po;
  insert into public.payments (company_id, purchase_order_id, paid_on, amount, method, reference, account_id)
    select co, po, d0 + 40, total, 'transfer', 'ACH', bank from public.purchase_orders where id = po;

  -- Purchase order 2: part received (4 of 10 open signs came in)
  insert into public.purchase_orders (company_id, number, status, vendor_id, vendor_name, contact_name, location_id, order_date, due_date)
  values (co, 'PO-001002', 'open', v1, 'Bright LED Supply', 'Kevin Wu', shop, current_date - 9, current_date + 21) returning id into po;
  insert into public.purchase_order_lines (company_id, purchase_order_id, line_no, product_id, description, qty, unit_cost, line_total, qty_received) values
    (co, po, 1, p1, 'LED Open Sign 24in', 10, 45, 450, 4),
    (co, po, 2, p6, 'Vinyl Roll 24in x 50yd', 2, 140, 280, 0);
  perform public.sample_totals(null, po);
  perform public.sample_move(co, p1, shop, 'A1', 4, 'received', 'purchase_order', po, (current_date - 4)::timestamptz);
  insert into public.stock_batches (company_id, doc_type, doc_id, location_id, lines, created_at)
    select co, 'purchase_order', po, shop, jsonb_build_array(jsonb_build_object('line', id, 'qty', 4)), (current_date - 4)::timestamptz
      from public.purchase_order_lines where purchase_order_id = po and line_no = 1;
  perform public.post_po(po);

  -- Bills: rent (paid each month), parts (open)
  for i in 0..2 loop
    insert into public.bills (company_id, vendor_id, vendor_name, ref, bill_date, due_date, memo)
    values (co, v3, 'Springfield Properties', 'Rent ' || to_char(d0 + (i || ' months')::interval, 'Mon YYYY'),
            (d0 + (i || ' months')::interval)::date, (d0 + (i || ' months')::interval)::date + 5, 'Shop rent')
    returning id into b;
    insert into public.bill_lines (company_id, bill_id, line_no, account_id, description, amount)
      select co, b, 1, id, 'Shop rent', 2400 from public.accounts where company_id = co and number = '6400';
    insert into public.bill_payments (company_id, bill_id, paid_on, amount, account_id, method, reference)
      values (co, b, (d0 + (i || ' months')::interval)::date + 3, 2400, bank, 'check', (2001 + i)::text);
  end loop;
  insert into public.bills (company_id, vendor_id, vendor_name, ref, bill_date, due_date, memo)
  values (co, v2, 'Metro Sign Parts', 'MSP-88412', current_date - 8, current_date + 22, 'Brackets and hardware')
  returning id into b;
  insert into public.bill_lines (company_id, bill_id, line_no, account_id, description, amount)
    select co, b, 1, id, 'Mounting brackets and hardware', 186.40 from public.accounts where company_id = co and number = '7200';

  -- Bank lines waiting in Bank Feeds
  insert into public.bank_transactions (company_id, account_id, txn_date, amount, description, fit_id, status) values
    (co, bank, current_date - 6, -84.12, 'HOME DEPOT #6572 SPRINGFIELD TX', 'sample:1', 'new'),
    (co, bank, current_date - 5, -62.40, 'SHELL OIL 57442 SPRINGFIELD TX', 'sample:2', 'new'),
    (co, bank, current_date - 4, -129.99, 'AT&T PAYMENT ONLINE', 'sample:3', 'new'),
    (co, bank, current_date - 3, -210.55, 'CITY OF SPRINGFIELD UTILITIES', 'sample:4', 'new'),
    (co, bank, current_date - 2, -35.00, 'MONTHLY SERVICE FEE', 'sample:5', 'new'),
    (co, bank, current_date - 1, 1200.00, 'MOBILE DEPOSIT', 'sample:6', 'new');

  -- Numbers carry on from the sample's own
  update public.doc_counters set next_number = 1005 where company_id = co and kind = 'sales_order';
  update public.doc_counters set next_number = 1003 where company_id = co and kind = 'quote';
  update public.doc_counters set next_number = 1003 where company_id = co and kind = 'purchase_order';
  return co;
end $$;
revoke execute on function public.build_sample_company(uuid, uuid) from public, anon, authenticated;

-- The switch in Settings: on (made fresh, or kept if it's there) / off (removed). Admins only.
create or replace function public.sample_company(_on boolean, _fresh boolean default false)
returns uuid language plpgsql security definer set search_path = public as $$
declare o uuid := public.my_org(); co uuid;
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can change the sample company.'; end if;
  if o is null then raise exception 'Your account is not set up yet.'; end if;
  select id into co from public.companies where org_id = o and is_sample limit 1;
  if co is not null and (not _on or _fresh) then
    delete from public.user_company where company_id = co;
    perform public.drop_sample_company(co);
    co := null;
  end if;
  if _on and co is null then
    co := public.build_sample_company(o, auth.uid());
  end if;
  return co;
end $$;
grant execute on function public.sample_company(boolean, boolean) to authenticated;

notify pgrst, 'reload schema';
