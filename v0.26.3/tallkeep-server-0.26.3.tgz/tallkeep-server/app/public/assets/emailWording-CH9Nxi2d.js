import{t as e}from"./client-Bw20J02D.js";import{t}from"./useQuery-8nhBZsKX.js";import{t as n}from"./createLucideIcon-CLdWFMku.js";var r=n(`rotate-ccw`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}]]),i=()=>!!{BASE_URL:`/`,DEV:!1,MODE:`production`,PROD:!0,SSR:!1,TSS_DEV_SERVER:`false`,TSS_DEV_SSR_STYLES_BASEPATH:`/`,TSS_DEV_SSR_STYLES_ENABLED:`true`,TSS_DISABLE_CSRF_MIDDLEWARE_WARNING:`false`,TSS_INLINE_CSS_ENABLED:`false`,TSS_ROUTER_BASEPATH:``,TSS_SERVER_FN_BASE:`/_serverFn/`,VITE_SUPABASE_PROJECT_ID:`rmxenvanqycmhesadcen`,VITE_SUPABASE_PUBLISHABLE_KEY:`sb_publishable_tallkeep_desktop`,VITE_SUPABASE_URL:`http://localhost:4600`,VITE_TALLKEEP_DESKTOP:`1`}.VITE_TALLKEEP_DESKTOP;async function a(t,n,r){let{data:i}=await e.auth.getSession(),a=await fetch(`/tallkeep/pay${n}`,{method:t,headers:{authorization:`Bearer ${i.session?.access_token??``}`,"content-type":`application/json`},body:r===void 0?null:JSON.stringify(r)}),o=await a.json().catch(()=>({}));if(!a.ok)throw Error(o.message??`That didn't work.`);return o}async function o(){let{data:t}=await e.rpc(`active_company`);return String(t??``)}var s=()=>`${window.location.origin}/settings?card=back`;function c(){return t({queryKey:[`card-pay`],enabled:i(),staleTime:3e5,queryFn:async()=>{let e=await o();return{company:e,...await a(`GET`,`?${new URLSearchParams({company:e,returnUrl:s()})}`)}}})}var l=(e,t=!1)=>a(`POST`,`/connect`,{company:e,returnUrl:s(),existing:t}),u=(e,t)=>a(`POST`,`/link`,{invoice:e,cents:t}),d=(e,t)=>a(`POST`,`/quote`,{quote:e,cents:t}),f=e=>a(`POST`,`/disconnect`,{company:e}),p=()=>a(`POST`,`/sync`,{}),m=[{kind:`quote`,label:`Quote`,when:`When you email a quote.`,fields:[`name`,`customer`,`number`,`total`,`company`,`terms_line`]},{kind:`invoice`,label:`Invoice`,when:`When you email an invoice, and when a repeating invoice is emailed by itself.`,fields:[`name`,`customer`,`number`,`total`,`balance`,`due_date`,`company`,`terms_line`,`payment_note`]},{kind:`quote_followup`,label:`Quote follow-up`,when:`Following up on a quote, by hand or by itself.`,fields:[`name`,`customer`,`number`,`total`,`company`]},{kind:`payment_reminder`,label:`Payment reminder`,when:`Asking about a late invoice, by hand or the automatic overdue reminders.`,fields:[`name`,`customer`,`number`,`balance`,`due_date`,`days_late`,`company`]},{kind:`po`,label:`Purchase order`,when:`When you email a purchase order to a vendor.`,fields:[`name`,`vendor`,`number`,`total`,`company`]}],h={name:`the contact's name (or the customer's)`,customer:`the customer's name`,vendor:`the vendor's name`,number:`the document number`,total:`the total`,balance:`what's still owed`,due_date:`the due date`,days_late:`how many days late`,company:`your company name`,terms_line:`"Our Terms & Conditions are on the last page." when attached`,payment_note:`"Your prompt payment is appreciated." when money is owed`},g={quote:{subject:`Quote {number} from {company}`,body:`Hello {name},

Please find attached our quote {number} for {total}.{terms_line}

Thank you,
{company}`},invoice:{subject:`Invoice {number} from {company}`,body:`Hello {name},

Please find attached our invoice {number} for {total}.{terms_line}{payment_note}

Thank you,
{company}`},quote_followup:{subject:`Following up: quote {number} from {company}`,body:`Hello {name},

I'm following up on our quote {number}.

If you'd like a new quote with different specs, are looking for a lower price, or have any questions, just reply to this email and we'll be happy to help.

Thank you,
{company}`},payment_reminder:{subject:`Payment reminder: invoice {number} from {company}`,body:`Hello {name},

A friendly reminder about invoice {number}: {balance} was due on {due_date}. The invoice is attached.

Please send us the status of this payment. If you've already sent it, thank you, and please let us know the date and how it was paid.

Thank you,
{company}`},po:{subject:`Purchase Order {number} from {company}`,body:`Hello {name},

Please find attached our purchase order {number}. Please confirm the order and the ship date.

Thank you,
{company}`}};function _(e,t){let n=e?.[t];return!n||!n.subject?.trim()&&!n.body?.trim()?null:{subject:n.subject?.trim()||g[t].subject,body:n.body?.trim()?n.body:g[t].body}}function v(e,t){return e.replace(/\{([a-z_]+)\}/g,(e,n)=>n in t?String(t[n]??``):e).replace(/\n{3,}/g,`

`).trim()}function y(e,t,n){let r=_(e,t);return r?{subject:v(r.subject,n),body:v(r.body,n)}:null}var b={name:`Sam Patel`,customer:`Lone Oak Auto`,vendor:`Acme Supply`,number:`INV-001042`,total:`$1,942.40`,balance:`$971.20`,due_date:`Nov 30, 2026`,days_late:`12`,company:`Your Company`,terms_line:`
Our Terms & Conditions are on the last page.`,payment_note:`

Your prompt payment is appreciated.`};export{v as a,f as c,p as d,c as f,m as i,u as l,h as n,y as o,r as p,b as r,l as s,g as t,d as u};