import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as AI_PROVIDERS } from "./ai-DoFpV1D-.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai.functions-C9EqiA1Q.js
async function companyOf(context) {
	const { data } = await context.supabase.rpc("active_company");
	if (!data) throw new Error("No company chosen.");
	return data;
}
/**
* Whose AI settings a company uses: its own, or, when it has none, the AI set up in another
* company on the same account (one key serves all your companies; any company can still pick
* its own).
*/
async function aiOwner(co) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	if ((await db.from("ai_keys").select("company_id").eq("company_id", co).maybeSingle()).data) return {
		co,
		shared: null
	};
	const me = await db.from("companies").select("org_id").eq("id", co).maybeSingle();
	if (!me.data?.org_id) return {
		co,
		shared: null
	};
	const ids = ((await db.from("companies").select("id,name").eq("org_id", me.data.org_id)).data ?? []).filter((c) => c.id !== co);
	if (!ids.length) return {
		co,
		shared: null
	};
	const k = ((await db.from("ai_keys").select("company_id,updated_at").in("company_id", ids.map((c) => c.id)).order("updated_at", { ascending: false }).limit(1)).data ?? [])[0];
	if (!k) return {
		co,
		shared: null
	};
	return {
		co: k.company_id,
		shared: ids.find((c) => c.id === k.company_id)?.name ?? null
	};
}
var monthStart = () => {
	const d = /* @__PURE__ */ new Date();
	return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString();
};
/** What this company's AI looks like right now (never the key itself). */
var aiStatus_createServerFn_handler = createServerRpc({
	id: "eb2ee64070a95f5ca231302b02ebc4033bc4338affec0d905e7b745c92a76c32",
	name: "aiStatus",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiStatus.__executeServer(opts));
var aiStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(aiStatus_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const co = await companyOf(context);
	const src = await aiOwner(co);
	const admin = supabaseAdmin;
	const [s, k, u] = await Promise.all([
		admin.from("ai_settings").select("provider,model,monthly_cap_usd").eq("company_id", src.co).maybeSingle(),
		admin.from("ai_keys").select("company_id").eq("company_id", src.co).maybeSingle(),
		admin.from("ai_usage").select("cost_usd,pages,own_key").eq("company_id", co).gte("created_at", monthStart())
	]);
	const provider = s.data?.["provider"] || "vooska";
	const rows = u.data ?? [];
	const b = await readBackup(src.co);
	return {
		sharedFrom: src.shared,
		provider,
		model: s.data?.["model"] || AI_PROVIDERS[provider].model,
		cap: s.data?.["monthly_cap_usd"] == null ? null : Number(s.data["monthly_cap_usd"]),
		hasKey: !!k.data,
		backupProvider: b.provider,
		hasBackupKey: !!b.key,
		builtInReady: !!process.env["LOVABLE_API_KEY"],
		monthCost: rows.filter((r) => !r["own_key"]).reduce((t, r) => t + Number(r["cost_usd"]), 0),
		monthPages: rows.reduce((t, r) => t + Number(r["pages"]), 0),
		monthUses: rows.length
	};
});
/** The backup AI and its key (none before database step 52). */
async function readBackup(co) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const [s, k] = await Promise.all([db.from("ai_settings").select("backup_provider").eq("company_id", co).maybeSingle(), db.from("ai_backup_keys").select("api_key").eq("company_id", co).maybeSingle()]);
	const p = s.error ? null : s.data?.backup_provider;
	return {
		provider: p && p in AI_PROVIDERS ? p : null,
		key: k.error ? null : k.data?.api_key ?? null
	};
}
/** Choose the AI for this company. Admins or staff with the Accounting section. */
var aiSave_createServerFn_handler = createServerRpc({
	id: "cf6f48d63d7d776519762389066263927129c6ba829b48eeab381d2ca77616fa",
	name: "aiSave",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiSave.__executeServer(opts));
var aiSave = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!(d.provider in AI_PROVIDERS)) throw new Error("Unknown AI.");
	if (d.cap != null && !(d.cap >= 0)) throw new Error("The monthly limit must be 0 or more.");
	if (d.key && d.key.length > 400) throw new Error("That key is too long.");
	if (d.backupKey && d.backupKey.length > 400) throw new Error("That key is too long.");
	if (d.backupProvider && (!(d.backupProvider in AI_PROVIDERS) || d.backupProvider === "vooska")) throw new Error("Pick your own AI account as the backup.");
	return d;
}).handler(aiSave_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone } = await import("./zone.server-JWxH1ixr.mjs");
	await requireZone(context.userId, ["Accounting"], "AI settings", context.supabase);
	const co = await companyOf(context);
	const admin = supabaseAdmin;
	const s = await admin.from("ai_settings").upsert({
		company_id: co,
		provider: data.provider,
		model: data.model.trim() || null,
		monthly_cap_usd: data.cap,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	});
	if (s.error) throw new Error(s.error.message);
	if (data.key === "") await admin.from("ai_keys").delete().eq("company_id", co);
	else if (data.key) {
		const k = await admin.from("ai_keys").upsert({
			company_id: co,
			api_key: data.key.trim(),
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		});
		if (k.error) throw new Error(k.error.message);
	}
	if (data.backupProvider !== void 0) {
		const db = supabaseAdmin;
		if ((await db.from("ai_settings").update({ backup_provider: data.backupProvider }).eq("company_id", co)).error) throw new Error("Run database step 52 first to add a backup AI.");
		if (data.backupKey === "" || !data.backupProvider) await db.from("ai_backup_keys").delete().eq("company_id", co);
		else if (data.backupKey) {
			const k = await db.from("ai_backup_keys").upsert({
				company_id: co,
				api_key: data.backupKey.trim(),
				updated_at: (/* @__PURE__ */ new Date()).toISOString()
			});
			if (k.error) throw new Error(k.error.message);
		}
	}
	return { ok: true };
});
var PROMPTS = {
	categorize: `You are a careful bookkeeper. For each bank or credit card line, pick the best account
from the chart of accounts given (use the exact account name from the list). Return JSON only:
{"picks":[{"id":"the line id","account":"exact account name"|null,"why":"a few plain words"}]}
Rules: money out for a business cost goes to an expense or cost account that fits; money in from
customers goes to an income account. Personal spending (groceries, pharmacy, restaurants for
the family, clothing, personal subscriptions) in a business's books goes to the owner's draws or
withdrawals account when there is one. Paying a credit card from the bank goes to that credit
card account; moving money between the company's own accounts goes to the other account. If a
note says what someone uses the card for, follow it. When unsure, use null rather than guess.`,
	sort: `You sort business and household paperwork. Look at the first page(s) and say what it is,
and read the key facts. Return JSON only:
{"kind":"bank_statement"|"card_statement"|"loan_statement"|"investment_statement"|"receipt"|"bill"|"check"|"other",
 "issuer":"bank, card company, store or vendor name"|null,
 "account_last4":"last 4 digits of the bank or card account on a statement"|null,
 "period_end":"YYYY-MM-DD"|null,
 "vendor":"…"|null,"date":"YYYY-MM-DD"|null,"due_date":"YYYY-MM-DD"|null,"total":number|null,
 "tax":number|null,"bill_number":"…"|null,"category":"short guess like Supplies, Utilities, Rent"|null,
 "payer":"…"|null,"amount":number|null,"check_number":"…"|null,"memo":"…"|null,
 "loan_kind":"mortgage"|"car"|"student"|"personal"|"heloc"|"other"|null,
 "payment":number|null,"principal":number|null,"interest":number|null,"escrow":number|null,
 "fees":number|null,"balance":number|null,"rate":number|null,
 "invest_kind":"retirement"|"brokerage"|"other"|null,"account_type":"Roth IRA, 401k, Brokerage…"|null,
 "ending_value":number|null,"total_invested":number|null,
 "holdings":[{"name":"fund or stock name","symbol":"ticker"|null,"shares":number|null,"price":number|null,"value":number|null}],
 "description":"one short line saying what it is"}
kind: bank_statement = a bank account statement with many transactions; card_statement = a credit
card statement; receipt = proof of something already paid (store or online receipt, paid
invoice); bill = an invoice or bill that still has to be paid (shows an amount due or a due date);
check = a paper check someone wrote to this business; loan_statement = a monthly mortgage, car
loan, student loan, personal loan or home equity statement from a lender; other = anything else.
For a loan_statement: issuer = the lender (servicer) name as printed; account_last4 = last 4 of
the loan number; period_end = the statement date; due_date = when the payment is due;
payment = the regular monthly payment (not past-due amounts); principal, interest, escrow (taxes
and insurance) and fees = how this payment splits; balance = the unpaid principal balance;
rate = the interest rate in percent (4.625 for 4.625%).
investment_statement = a brokerage, mutual fund, IRA, Roth IRA, 401k or other investment or
retirement account statement. For it: issuer = the company (Primerica, Fidelity…);
account_last4 = last 4 of the account number; period_end = the statement's end date;
ending_value = the account's total value on that date; holdings = each fund or stock with its
shares, price and value on that date (an empty list when the pages shown don't list them).
total_invested = the money put in since the account opened (purchases or contributions, plus
rollovers and transfers in) minus withdrawals, when the statement shows it; otherwise null.
total = the amount paid (receipt) or the amount due (bill). Never return full account, card or
routing numbers: only the last 4 digits.`,
	product: `You look at a photo of a product or part (often a box, label or the item itself) for a
business's inventory. Return JSON only:
{"name":"a short, clear inventory name, like a store would use (brand, what it is, size or
 model), e.g. 'Mean Well LRS-150-12 12V 150W power supply'","brand":"…"|null,"model":"…"|null,
 "description":"one short line"|null,"barcode":"the UPC/EAN digits printed under a barcode"|null}
Use only what you can read or clearly see. Never invent a model number.`,
	investment: `You read investment and retirement account statements (Fidelity, Schwab, Vanguard,
Primerica, 401k, IRA, Roth IRA, brokerage). Return JSON only:
{"kind":"investment_statement","issuer":"the company (Fidelity…)","account_last4":"1234"|null,
 "invest_kind":"retirement"|"brokerage"|"other","account_type":"Roth IRA, 401k, Brokerage…"|null,
 "period_start":"YYYY-MM-DD"|null,"period_end":"YYYY-MM-DD","beginning_value":number|null,
 "ending_value":number|null,"total_invested":number|null,
 "period":{"deposits":n,"withdrawals":n,"fees":n,"dividends":n,"interest":n,
   "realized_short":n,"realized_long":n,"change_in_value":n},
 "ytd":{ the same names, for the year to date },
 "holdings":[{"name":"…","symbol":"ticker"|null,"shares":number|null,"price":number|null,
   "value":number|null,"cost":number|null}]}
(n = a number, or null when the statement doesn't show it)
Rules: ending_value = the account's total value at the end of the period. Holdings come from the
detailed Holdings section (the table with Quantity, Price Per Unit, Ending Market Value and Total
Cost Basis), one entry per position, including the core / cash / money market position. Never use
a "Top Holdings" or summary list, and never add subtotals or totals ("Total Common Stock…").
shares = Quantity, price = Price Per Unit, value = Ending Market Value, cost = Total Cost Basis
(for cash and money market funds, cost = value; null when the statement says unavailable or not
applicable for anything else). symbol = the ticker in parentheses, like (MRVL). Use the
statement's numbers exactly; don't round. total_invested = money put in since the account opened
(contributions, purchases, deposits, rollovers in, minus withdrawals) only when the statement shows
it since the account opened; a year-to-date figure is not it (then null). account_last4 = the last
4 digits or characters of the account number.
period and ytd come from the summary pages ("This Period" and "Year-to-Date" columns):
deposits = Additions / Deposits / Contributions; withdrawals = money taken out (not fees), as a
positive number; fees = Transaction Costs, Fees & Charges, as a positive number; dividends and
interest = from the Income Summary; realized_short and realized_long = Net Short-term and Net
Long-term Gain/Loss from the Realized Gains and Losses section (a loss is negative);
change_in_value = Change in Investment Value (or Investment gain/decline).`,
	statement: `You read bank and credit card statements. Return JSON only:
{"account_kind":"bank"|"credit_card","period_end":"YYYY-MM-DD"|null,
 "beginning_balance":number|null,"ending_balance":number|null,
 "lines":[{"date":"YYYY-MM-DD","description":"…","amount":number,"ref":"check number or null"}]}
beginning_balance and ending_balance are the statement's opening and closing balances as printed
(for a credit card: Previous Balance and New Balance owed, as positive numbers); null when these
pages don't show them.
Rules: one entry per transaction line, in statement order. Money INTO the account is positive,
money OUT is negative (for a credit card: purchases and fees negative, payments and refunds
positive). Skip balances, subtotals, headers and summaries. Use the statement's year for dates.
Copy descriptions as printed (no card numbers).`,
	receipt: `You read store receipts and vendor invoices. Return JSON only:
{"vendor":"…"|null,"date":"YYYY-MM-DD"|null,"total":number|null,"tax":number|null,
 "payment":"card"|"cash"|"check"|"other"|null,"card_last4":"1234"|null,
 "category":"short guess like Supplies, Fuel, Meals, Repairs"|null,"items":"one short line"|null}
total = the amount actually paid, including tax and tip.`,
	check: `You read a paper check that a business RECEIVED from its customer. Return JSON only:
{"payer":"…"|null,"amount":number|null,"date":"YYYY-MM-DD"|null,"check_number":"…"|null,
 "memo":"…"|null,"bank":"…"|null}
payer = the person or company that wrote the check (printed top left), not the bank and not who it
is paid to. amount = the number in the amount box. check_number = the number at the top right.
memo = the memo line, often an invoice number. Never return account or routing numbers.`
};
/** Pages the built-in AI may read in a month during the free trial (online). */
var TRIAL_AI_PAGES = 50;
/** Stop when the account's built-in AI pages for this month are used up. */
async function checkAiPages(userId, pages) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { data: m } = await db.from("org_members").select("org_id").eq("user_id", userId).maybeSingle();
	if (!m?.org_id) return;
	const { data: o } = await db.from("orgs").select("*").eq("id", m.org_id).maybeSingle();
	if (!o || o.is_platform || o.edition === "desktop") return;
	const trialOver = o.status === "trial" && o.trial_ends_at && Date.parse(o.trial_ends_at) < Date.now();
	if (o.status === "canceled" || trialOver) throw new Error("Your books are read-only. Pick a plan in Plan & billing to use the AI.");
	const limit = o.ai_pages_month ?? (o.status === "trial" ? TRIAL_AI_PAGES : null);
	if (limit == null) return;
	const { data: cos } = await db.from("companies").select("id").eq("org_id", o.id);
	const ids = (cos ?? []).map((c) => c.id);
	if (!ids.length) return;
	const { data: used } = await db.from("ai_usage").select("pages").in("company_id", ids).eq("own_key", false).gte("created_at", monthStart());
	const n = (used ?? []).reduce((t, r) => t + (r.pages ?? 0), 0);
	if (n + pages > limit) throw new Error(`This month's ${limit} AI pages are used up (${n} read). Add your own AI key in Settings → AI, or move up a plan in Plan & billing.`);
}
/** Read statement pages or a receipt with AI. Logs the use; stops at the monthly limit. */
var aiRead_createServerFn_handler = createServerRpc({
	id: "add849362d949ebbc4eb83205c60058bb0fff83a0b7d10809a072293a387221a",
	name: "aiRead",
	filename: "src/lib/ai.functions.ts"
}, (opts) => aiRead.__executeServer(opts));
var aiRead = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!PROMPTS[d.feature]) throw new Error("Unknown job.");
	if (d.feature === "categorize") {
		if (d.images.length || !d.hint || d.hint.length > 6e4) throw new Error("Nothing to sort.");
		return d;
	}
	if (!d.images.length) throw new Error("Nothing to read.");
	if (d.images.length > 12) throw new Error("Too many pages at once (12 at most).");
	if (d.hint && d.hint.length > 2e3) throw new Error("The note for the AI is too long.");
	if (d.images.reduce((t, i) => t + i.length, 0) > 18e6) throw new Error("These pages are too big. Try fewer pages at a time.");
	if (!d.images.every((i) => /^data:image\/(jpeg|png|webp);base64,/.test(i))) throw new Error("Pages must be images.");
	return d;
}).handler(aiRead_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone } = await import("./zone.server-JWxH1ixr.mjs");
	await requireZone(context.userId, ["Accounting"], "reading statements and receipts", context.supabase);
	const co = await companyOf(context);
	const admin = supabaseAdmin;
	const aiCo = (await aiOwner(co)).co;
	const [s, k] = await Promise.all([admin.from("ai_settings").select("provider,model,monthly_cap_usd").eq("company_id", aiCo).maybeSingle(), admin.from("ai_keys").select("api_key").eq("company_id", aiCo).maybeSingle()]);
	const provider = s.data?.["provider"] || "vooska";
	const p = AI_PROVIDERS[provider];
	const own = provider !== "vooska";
	const key = own ? k.data?.["api_key"] : process.env["LOVABLE_API_KEY"];
	if (!key) throw new Error(own ? "Add your AI key in Settings → AI first." : "The AI isn't set up on this computer yet. Open AI & Usage (in the menu), pick your own AI account, paste its key and save.");
	const model = own ? s.data?.["model"] || p.model : process.env["AI_MODEL"] || p.model;
	if (!own) await checkAiPages(context.userId, data.images.length);
	const cap = s.data?.["monthly_cap_usd"];
	if (!own && cap != null) {
		const { data: used } = await admin.from("ai_usage").select("cost_usd").eq("company_id", co).eq("own_key", false).gte("created_at", monthStart());
		if ((used ?? []).reduce((t, r) => t + Number(r["cost_usd"]), 0) >= Number(cap)) throw new Error("This month's AI limit is used up. Raise it in Settings → AI.");
	}
	const usage = supabaseAdmin.from.bind(supabaseAdmin);
	const { data: held } = await usage("ai_usage").insert({
		company_id: co,
		user_id: context.userId,
		feature: data.feature,
		provider,
		model,
		pages: data.images.length,
		input_tokens: 0,
		output_tokens: 0,
		cost_usd: 0,
		own_key: own
	}).select("id").single();
	const heldId = held?.id;
	if (!own) try {
		await checkAiPages(context.userId, 0);
	} catch (e) {
		if (heldId) await usage("ai_usage").delete().eq("id", heldId);
		throw e;
	}
	const backup = await readBackup(aiCo);
	const hasBackup = !!backup.provider && !!backup.key && backup.provider !== provider;
	const busy = (st) => st === 429 || st === 500 || st === 502 || st === 503 || st === 529;
	async function tryAi(prov, k, first, tries) {
		const P = AI_PROVIDERS[prov];
		const models = [first, ...P.backup].filter((m, i, l) => l.indexOf(m) === i);
		const ask = (m) => fetch(P.url, {
			method: "POST",
			headers: {
				Authorization: `Bearer ${k}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				model: m,
				messages: [{
					role: "system",
					content: PROMPTS[data.feature]
				}, {
					role: "user",
					content: [{
						type: "text",
						text: data.feature === "categorize" ? data.hint : data.hint || "Read this."
					}, ...data.images.map((url) => ({
						type: "image_url",
						image_url: { url }
					}))]
				}],
				...prov === "anthropic" ? { max_tokens: 16e3 } : { response_format: { type: "json_object" } }
			})
		}).catch((e) => new Response(JSON.stringify({ error: { message: e.message } }), { status: 502 }));
		let r = await ask(models[0]);
		for (let next = 1; r.status === 404 && next < models.length; next++) r = await ask(models[next]);
		for (let i = 1; busy(r.status) && i < tries; i++) {
			await new Promise((ok) => setTimeout(ok, 1500 * i));
			r = await ask(models[Math.min(i, models.length - 1)]);
			for (let next = i + 1; r.status === 404 && next < models.length; next++) r = await ask(models[next]);
		}
		return r;
	}
	let res = await tryAi(provider, key, model, hasBackup ? 2 : 4);
	let used = provider;
	if (!res.ok && res.status !== 400 && hasBackup) {
		const r2 = await tryAi(backup.provider, backup.key, AI_PROVIDERS[backup.provider].model, 3);
		if (r2.ok) {
			res = r2;
			used = backup.provider;
			if (heldId) await usage("ai_usage").update({
				provider: used,
				model: AI_PROVIDERS[used].model,
				own_key: true
			}).eq("id", heldId);
		}
	}
	const raw = await res.json().catch(() => ({}));
	const body = Array.isArray(raw) ? raw[0] ?? {} : raw;
	if (!res.ok) {
		if (heldId) await usage("ai_usage").delete().eq("id", heldId);
		const msg = typeof body.error === "string" ? body.error : body.error?.message;
		if (res.status === 503 || res.status === 500) throw new Error(`${own ? AI_PROVIDERS[used].label.replace(/^My own /, "") : "The AI"} is overloaded right now.${hasBackup ? " The backup AI didn't answer either." : " Add a backup AI in AI & Usage, or try again in a few minutes."}`);
		if (res.status === 429) throw new Error(own ? "Your AI account's limit is reached for now (free accounts allow a few pages a minute). Try again in a minute." : "The AI is busy. Try again in a minute.");
		if (res.status === 401 || res.status === 403) throw new Error("The AI key wasn't accepted. Paste the key again in AI & Usage and save.");
		if (res.status === 402) throw new Error(own ? "Your AI account is out of credit." : "AI credits are used up. Add credits in Lovable.");
		throw new Error(`The AI couldn't read it (${res.status}${msg ? `: ${msg}` : ""}).`);
	}
	const inTok = body.usage?.prompt_tokens ?? 0;
	const outTok = body.usage?.completion_tokens ?? 0;
	const rateIn = Number(process.env["AI_COST_IN_PER_M"] ?? .3);
	const rateOut = Number(process.env["AI_COST_OUT_PER_M"] ?? 2.5);
	const cost = {
		input_tokens: inTok,
		output_tokens: outTok,
		cost_usd: (inTok * rateIn + outTok * rateOut) / 1e6
	};
	if (heldId) await usage("ai_usage").update(cost).eq("id", heldId);
	const said = String(body.choices?.[0]?.message?.content ?? "");
	const text = (said.includes("{") ? said.slice(said.indexOf("{"), said.lastIndexOf("}") + 1) : said).trim();
	try {
		JSON.parse(text);
	} catch {
		throw new Error("The AI's answer wasn't readable. Try again.");
	}
	return text;
});
//#endregion
export { aiRead_createServerFn_handler, aiSave_createServerFn_handler, aiStatus_createServerFn_handler };
