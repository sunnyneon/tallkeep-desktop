import { t as supabase } from "./client-sss9hg5u.mjs";
import { n as BUSINESS_TYPES } from "./addons-tdRottJR.mjs";
import { J as redirect, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/signup-Dig6FLvR.js
var $$splitComponentImporter = () => import("./signup-BXKoVldt.mjs");
var Route = createFileRoute("/signup")({
	ssr: false,
	beforeLoad: () => {
		if ({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/",
			"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
			"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
			"VITE_SUPABASE_URL": "http://localhost:4600",
			"VITE_TALLKEEP_DESKTOP": "1"
		}["VITE_TALLKEEP_DESKTOP"]) throw redirect({ to: "/auth" });
	},
	head: () => ({ meta: [{ title: "Start your free trial · Tallkeep" }, {
		name: "description",
		content: "Try Tallkeep free for 30 days: inventory, sales and books for every company you run."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
/** Make the account and first company for someone who is signed in. */
async function startTrial(company, type) {
	const { error } = await supabase.rpc("start_trial", {
		_company: company,
		_business_type: type,
		_addons: [...BUSINESS_TYPES[type].features]
	});
	if (error) throw new Error(error.message);
}
//#endregion
export { startTrial as n, Route as t };
