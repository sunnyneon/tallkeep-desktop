import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/work-orders-Crgqw1XU.js
var $$splitComponentImporter = () => import("./work-orders-CuZsMztK.mjs");
var Route = createFileRoute("/_authenticated/work-orders")({
	validateSearch: (s) => typeof s["wo"] === "string" ? { wo: s["wo"] } : {},
	head: () => ({ meta: [{ title: "Work Orders · Tallkeep" }, {
		name: "description",
		content: "Build products from parts."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
