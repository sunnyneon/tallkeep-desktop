import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as Search, K as PanelLeftOpen, q as PanelLeftClose } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { c as isRmaDoc, d as payStatus, o as invStatus } from "./sales-DLuHnKkT.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/SideList-CDc-cOPj.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var SHOW_MAX = 300;
var OPEN_KEY = "side-list-open";
/** Which tab a sales document belongs to. */
function salesGroup(o) {
	if (isRmaDoc(o)) return "rma";
	if (o.status === "quote") return "quote";
	if (o.status === "cancelled") return "all";
	return "invoice";
}
var SALES_TABS = [
	{
		key: "quote",
		label: "Quotes"
	},
	{
		key: "invoice",
		label: "Invoices"
	},
	{
		key: "rma",
		label: "RMAs"
	},
	{
		key: "all",
		label: "All"
	}
];
async function load(kind) {
	switch (kind.type) {
		case "sales": return (await fetchAll("sales_orders", "id,number,status,customer_name,order_date,total,amount_paid,balance,stock_taken_at,po_number")).sort((a, b) => b.order_date.localeCompare(a.order_date)).map((r) => ({
			id: r.id,
			title: r.number,
			sub: `${fmtDate(r.order_date)} · ${r.customer_name ?? ""}${r.status === "cancelled" ? " · cancelled" : ""}`,
			right: fmtMoney(r.total),
			hay: `${r.number} ${r.customer_name ?? ""} ${r.po_number ?? ""}`.toLowerCase(),
			group: salesGroup(r),
			party: (r.customer_name ?? "").toLowerCase(),
			partyName: r.customer_name ?? "",
			pay: payStatus(r),
			inv: invStatus(r)
		}));
		case "po": return (await fetchAll("purchase_orders", "id,number,vendor_name,order_date,total,status")).sort((a, b) => b.order_date.localeCompare(a.order_date)).map((r) => ({
			id: r.id,
			title: r.number,
			sub: `${fmtDate(r.order_date)} · ${r.vendor_name ?? ""}`,
			right: fmtMoney(r.total),
			hay: `${r.number} ${r.vendor_name ?? ""}`.toLowerCase(),
			party: (r.vendor_name ?? "").toLowerCase(),
			partyName: r.vendor_name ?? ""
		}));
		case "product": return (await fetchAll("products", "id,name,description,barcode,is_active,categories(name)")).filter((r) => r.is_active !== false).sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true })).map((r) => ({
			id: r.id,
			title: r.name,
			sub: [r.categories?.name, r.description].filter(Boolean).join(" · "),
			hay: `${r.name} ${r.description ?? ""} ${r.barcode ?? ""} ${r.categories?.name ?? ""}`.toLowerCase()
		}));
		case "customer":
		case "vendor": return (await fetchAll(kind.type === "customer" ? "customers" : "vendors", "id,name,contact_name,phone,is_active")).filter((r) => r.is_active !== false).sort((a, b) => a.name.localeCompare(b.name)).map((r) => ({
			id: r.id,
			title: r.name,
			sub: [r.contact_name, r.phone].filter(Boolean).join(" · "),
			hay: `${r.name} ${r.contact_name ?? ""} ${r.phone ?? ""}`.toLowerCase()
		}));
		case "stockdoc": return (await fetchAll("stock_docs", "id,number,kind,doc_date,status,remarks")).filter((r) => r.kind === kind.kind).sort((a, b) => b.doc_date.localeCompare(a.doc_date)).map((r) => ({
			id: r.id,
			title: r.number,
			sub: `${fmtDate(r.doc_date)} · ${r.status}`,
			hay: `${r.number} ${r.remarks ?? ""}`.toLowerCase()
		}));
	}
}
function linkFor(kind, id) {
	switch (kind.type) {
		case "sales": return {
			to: "/sales/$id",
			params: { id }
		};
		case "po": return {
			to: "/po/$id",
			params: { id }
		};
		case "product": return {
			to: "/products/$id",
			params: { id }
		};
		case "customer": return {
			to: "/customers/$id",
			params: { id }
		};
		case "vendor": return {
			to: "/vendors/$id",
			params: { id }
		};
		case "stockdoc": return {
			to: "/stock-doc/$id",
			params: { id }
		};
	}
}
/** inFlow-style searchable list on the left of a detail page (wide screens only). */
function SideLayout({ kind, currentId, children }) {
	const [open, setOpen] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem(OPEN_KEY) !== "0";
		} catch {
			return true;
		}
	});
	const toggle = () => {
		setOpen((v) => {
			try {
				localStorage.setItem(OPEN_KEY, v ? "0" : "1");
			} catch {}
			return !v;
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full",
		children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "sticky top-0 hidden h-screen w-72 shrink-0 flex-col border-r bg-card lg:flex print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideList, {
				kind,
				currentId,
				onHide: toggle
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: toggle,
			title: "Show the list",
			"aria-label": "Show the list",
			className: "sticky top-0 hidden h-screen w-8 shrink-0 items-start justify-center border-r bg-card pt-4 text-muted-foreground hover:text-foreground lg:flex print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftOpen, { className: "h-4 w-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1",
			children
		})]
	});
}
function SideList({ kind, currentId, onHide }) {
	const key = kind.type === "stockdoc" ? `stockdoc-${kind.kind}` : kind.type;
	const { data, isLoading } = useQuery({
		queryKey: ["side-list", key],
		queryFn: () => load(kind),
		staleTime: 6e4
	});
	const searchKey = kind.type === "sales" ? "sales-search" : kind.type === "po" ? "po-search" : `side-search:${key}`;
	const [search, setSearch] = useSticky(searchKey, {
		q: "",
		customer: "",
		vendor: ""
	});
	const q = search.q;
	const party = (kind.type === "po" ? search.vendor : search.customer) ?? "";
	const setQ = (v) => setSearch((x) => ({
		...x,
		q: v
	}));
	const setParty = (v) => setSearch((x) => kind.type === "po" ? {
		...x,
		vendor: v
	} : {
		...x,
		customer: v
	});
	const [more, setMore] = useSticky("side-sales-filters", {
		pay: "all",
		inv: "all"
	});
	const [tab, setTab] = useSticky("side-sales-tab", kind.type === "sales" ? kind.group : "all");
	const groupNow = kind.type === "sales" ? kind.group : "all";
	(0, import_react.useEffect)(() => {
		if (kind.type === "sales" && groupNow !== "all" && tab !== "all" && !party) setTab(groupNow);
	}, [groupNow]);
	const parties = (0, import_react.useMemo)(() => {
		if (kind.type !== "sales" && kind.type !== "po") return [];
		const names = /* @__PURE__ */ new Map();
		for (const r of data ?? []) if (r.party && r.partyName) names.set(r.party, r.partyName);
		return [...names.values()].sort((a, b) => a.localeCompare(b));
	}, [data, kind.type]);
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		const p = party.trim().toLowerCase();
		return (data ?? []).filter((r) => (kind.type !== "sales" || tab === "all" || r.group === tab) && (!p || (r.party ?? "").includes(p)) && (kind.type !== "sales" || more.pay === "all" || (more.pay === "owed" ? r.pay === "Unpaid" || r.pay === "Partial" : r.pay === more.pay)) && (kind.type !== "sales" || more.inv === "all" || r.inv === more.inv) && words.every((w) => r.hay.includes(w)));
	}, [
		data,
		q,
		party,
		tab,
		more,
		kind.type
	]);
	const filtered = !!q || !!party || kind.type === "sales" && (more.pay !== "all" || more.inv !== "all");
	const clear = () => {
		setSearch({
			q: "",
			customer: "",
			vendor: ""
		});
		setMore({
			pay: "all",
			inv: "all"
		});
	};
	const shown = (0, import_react.useMemo)(() => {
		const top = rows.slice(0, SHOW_MAX);
		const cur = rows.find((r) => r.id === currentId);
		return cur && !top.includes(cur) ? [cur, ...top] : top;
	}, [rows, currentId]);
	const current = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		current.current?.scrollIntoView({ block: "nearest" });
	}, [currentId, data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 border-b p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "h-9 pl-8",
						placeholder: "Search",
						value: q,
						onChange: (e) => setQ(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onHide,
					title: "Hide the list",
					"aria-label": "Hide the list",
					className: "rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "h-4 w-4" })
				})]
			}),
			(kind.type === "sales" || kind.type === "po") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground",
					children: kind.type === "po" ? "Vendor:" : "Customer:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: `h-8 text-sm ${kind.type === "po" ? "pl-14" : "pl-[4.5rem]"}`,
					"aria-label": kind.type === "po" ? "Vendor" : "Customer",
					placeholder: "all",
					list: `side-parties-${kind.type}`,
					value: party,
					onChange: (e) => setParty(e.target.value)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
				id: `side-parties-${kind.type}`,
				children: parties.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: n }, n))
			})] }),
			kind.type === "sales" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Inventory",
					className: "h-8 rounded-md border bg-background px-1.5 text-xs",
					value: more.inv,
					onChange: (e) => setMore((x) => ({
						...x,
						inv: e.target.value
					})),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Inventory: all"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Unfulfilled",
							children: "Unfulfilled"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Fulfilled",
							children: "Fulfilled"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Payment",
					className: "h-8 rounded-md border bg-background px-1.5 text-xs",
					value: more.pay,
					onChange: (e) => setMore((x) => ({
						...x,
						pay: e.target.value
					})),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Payment: all"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "owed",
							children: "Unpaid or partial"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Unpaid",
							children: "Unpaid"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Partial",
							children: "Partial"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Paid",
							children: "Paid"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "Uninvoiced",
							children: "Uninvoiced"
						})
					]
				})]
			}),
			kind.type === "sales" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1",
				children: SALES_TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(t.key),
					className: `rounded-full px-2.5 py-0.5 text-xs font-medium ${tab === t.key ? "bg-[var(--section)] text-white" : "bg-muted hover:bg-muted/70"}`,
					children: t.label
				}, t.key))
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [rows.length, " found"] }), filtered && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "underline hover:text-foreground",
					onClick: clear,
					children: "Clear search"
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex-1 overflow-y-auto",
		children: [
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-3 text-sm text-muted-foreground",
				children: "Loading…"
			}),
			shown.map((r) => {
				const on = r.id === currentId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					ref: on ? current : void 0,
					...linkFor(kind, r.id),
					className: `block border-b px-3 py-2 text-sm ${on ? "bg-[var(--section)] text-white" : "hover:bg-[var(--section-soft)]"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium",
							children: r.title
						}), r.right && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `shrink-0 text-xs ${on ? "text-white/80" : "text-muted-foreground"}`,
							children: r.right
						})]
					}), r.sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `truncate text-xs ${on ? "text-white/80" : "text-muted-foreground"}`,
						children: r.sub
					})]
				}, r.id);
			}),
			rows.length > SHOW_MAX && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "p-3 text-xs text-muted-foreground",
				children: [
					"Showing ",
					SHOW_MAX,
					" of ",
					rows.length,
					". Type to narrow it down."
				]
			}),
			data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-3 text-sm text-muted-foreground",
				children: "Nothing matches."
			})
		]
	})] });
}
//#endregion
export { salesGroup as n, SideLayout as t };
