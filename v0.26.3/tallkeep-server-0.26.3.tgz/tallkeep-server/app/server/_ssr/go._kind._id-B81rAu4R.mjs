import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/go._kind._id-B81rAu4R.js
var $$splitComponentImporter = () => import("./go._kind._id-BUJFAI8C.mjs");
/** Opens whatever made a line in the books: /go/entry/<journal entry id> or /go/<type>/<id>. */
var Route = createFileRoute("/_authenticated/go/$kind/$id")({
	head: () => ({ meta: [{ title: "Opening… · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
