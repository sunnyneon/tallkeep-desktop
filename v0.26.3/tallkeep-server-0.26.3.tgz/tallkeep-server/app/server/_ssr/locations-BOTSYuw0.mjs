import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtQty } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { R as Plus, it as MapPin } from "../_libs/lucide-react.mjs";
import { o as useLocations, u as useShelves } from "./queries-DKvOnwaZ.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Switch } from "./switch-Dkd0-FGF.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/locations-BOTSYuw0.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function LocationsPage() {
	const qc = useQueryClient();
	const { data: locations } = useLocations();
	const { data: shelves } = useShelves();
	const { data: stock } = useQuery({
		queryKey: ["stock", "by-location"],
		queryFn: () => fetchAll("stock", "location_id,shelf,qty")
	});
	const [name, setName] = (0, import_react.useState)("");
	const [showInactive, setShowInactive] = (0, import_react.useState)(false);
	const totals = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(stock ?? []).forEach((s) => {
			if (Number(s.qty) > 0) m.set(s.location_id, (m.get(s.location_id) ?? 0) + Number(s.qty));
		});
		return m;
	}, [stock]);
	async function addLocation(e) {
		e.preventDefault();
		if (!name.trim()) return;
		const { error } = await db.from("locations").insert({ name: name.trim() });
		if (error) {
			toast.error(error.message);
			return;
		}
		setName("");
		toast.success("Place added.");
		qc.invalidateQueries({ queryKey: ["locations"] });
	}
	const list = (locations ?? []).filter((l) => showInactive || l.is_active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Locations",
			text: "Rooms, shelves and every place you keep things. Add as many as you need."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: addLocation,
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "New place, e.g. Warehouse 2, Van, Room B",
				value: name,
				onChange: (e) => setName(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add place"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-2 text-sm text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				checked: showInactive,
				onCheckedChange: setShowInactive
			}), " Show places we stopped using"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: list.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationCard, {
				id: l.id,
				name: l.name,
				active: l.is_active,
				units: totals.get(l.id) ?? 0,
				shelves: (shelves ?? []).filter((s) => s.location_id === l.id).map((s) => s.name).sort((a, b) => a.localeCompare(b, void 0, { numeric: true }))
			}, l.id))
		})
	] });
}
function LocationCard({ id, name, active, units, shelves }) {
	const qc = useQueryClient();
	const [shelf, setShelf] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)(name);
	async function addShelf(e) {
		e.preventDefault();
		if (!shelf.trim()) return;
		const { error } = await db.from("shelves").insert({
			location_id: id,
			name: shelf.trim()
		});
		if (error) {
			toast.error(error.code === "23505" ? "That shelf already exists here." : error.message);
			return;
		}
		setShelf("");
		qc.invalidateQueries({ queryKey: ["shelves"] });
	}
	async function save(patch) {
		const { error } = await db.from("locations").update(patch).eq("id", id);
		if (error) {
			toast.error(error.message);
			return;
		}
		qc.invalidateQueries({ queryKey: ["locations"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-5 w-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							save({ name: newName.trim() });
							setEditing(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: newName,
							onChange: (e) => setNewName(e.target.value),
							autoFocus: true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							type: "submit",
							children: "Save name"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-lg font-semibold",
						children: [
							name,
							" ",
							!active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: "Not used"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							fmtQty(units),
							" items · ",
							shelves.length,
							" shelves"
						]
					})]
				})]
			}),
			shelves.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: shelves.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: s
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: addShelf,
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "New shelf or spot",
					value: shelf,
					onChange: (e) => setShelf(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					type: "submit",
					children: "Add shelf"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [!editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => setEditing(true),
					children: "Rename place"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => save({ is_active: !active }),
					children: active ? "Stop using this place" : "Use this place again"
				})]
			})
		]
	});
}
//#endregion
export { LocationsPage as component };
