import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as supabase } from "./client-sss9hg5u.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as BUSINESS_TYPES, r as BUSINESS_TYPE_KEYS } from "./addons-tdRottJR.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/signup-BXKoVldt.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Make the account and first company for someone who is signed in. */
async function startTrial(company, type) {
	const { error } = await supabase.rpc("start_trial", {
		_company: company,
		_business_type: type,
		_addons: [...BUSINESS_TYPES[type].features]
	});
	if (error) throw new Error(error.message);
}
function SignupPage() {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [company, setCompany] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("products");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [sent, setSent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		supabase.auth.getUser().then(({ data }) => {
			if (data.user) navigate({
				to: "/",
				replace: true
			});
		});
	}, [navigate]);
	async function onSubmit(e) {
		e.preventDefault();
		if (password.length < 8) return void toast.error("The password needs at least 8 characters.");
		if (!company.trim()) return void toast.error("Type your company name.");
		setBusy(true);
		try {
			const { data, error } = await supabase.auth.signUp({
				email: email.trim().toLowerCase(),
				password,
				options: {
					emailRedirectTo: `${window.location.origin}/welcome`,
					data: {
						name: name.trim(),
						company: company.trim(),
						business_type: type
					}
				}
			});
			if (error) throw error;
			if (data.session) {
				await startTrial(company.trim(), type);
				await qc.invalidateQueries();
				toast.success("Welcome to Tallkeep! Your 30 days start today.");
				navigate({
					to: "/",
					replace: true
				});
			} else setSent(true);
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-6 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { light: true }), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border bg-card p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-bold",
					children: "Check your email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted-foreground",
					children: [
						"We sent a link to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: email }),
						". Open it to confirm your email; your company is set up right after."
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-5 rounded-2xl border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl font-bold",
							children: "Start your free trial online"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "30 days free. No card needed. Use it in your browser, from any computer or phone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [
								"Rather keep your books on your own computer?",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/download?for=windows",
									className: "font-medium text-primary underline",
									children: "Download Tallkeep for Windows"
								}),
								" ",
								"or",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/download?for=linux",
									className: "font-medium text-primary underline",
									children: "for Synology / Linux"
								}),
								"."
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "name",
							children: "Your name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "name",
							autoComplete: "name",
							required: true,
							value: name,
							onChange: (e) => setName(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "email",
							children: "Work email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "email",
							type: "email",
							autoComplete: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "company",
							children: "Company name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "company",
							autoComplete: "organization",
							required: true,
							value: company,
							onChange: (e) => setCompany(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium",
							children: "What does it do?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2",
							children: BUSINESS_TYPE_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex cursor-pointer items-start gap-3 rounded-lg border p-3 text-sm ${type === k ? "border-primary bg-accent" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "type",
									checked: type === k,
									onChange: () => setType(k),
									className: "mt-1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: BUSINESS_TYPES[k].label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-muted-foreground",
									children: BUSINESS_TYPES[k].text
								})] })]
							}, k))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "password",
							children: "Choose a password (8 or more characters)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "password",
							type: "password",
							autoComplete: "new-password",
							required: true,
							value: password,
							onChange: (e) => setPassword(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-start gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							required: true,
							className: "mt-1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"I agree to the",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://tallkeep.com/terms",
								target: "_blank",
								rel: "noreferrer",
								className: "text-primary underline",
								children: "terms"
							}),
							" ",
							"and",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "https://tallkeep.com/privacy",
								target: "_blank",
								rel: "noreferrer",
								className: "text-primary underline",
								children: "privacy policy"
							}),
							"."
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "h-11 w-full text-base",
						children: busy ? "Setting up…" : "Start my 30 days free"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: [
							"Already have an account?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/auth",
								className: "font-medium text-primary hover:underline",
								children: "Sign in"
							})
						]
					})
				]
			})]
		})
	});
}
//#endregion
export { SignupPage as component, startTrial };
