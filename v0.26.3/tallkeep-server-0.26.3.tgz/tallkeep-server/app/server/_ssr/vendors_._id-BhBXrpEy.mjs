import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/vendors_._id-BhBXrpEy.js
var $$splitComponentImporter = () => import("./vendors_._id-BPXStBPH.mjs");
var Route = createFileRoute("/_authenticated/vendors_/$id")({
	head: () => ({ meta: [{ title: "Vendor · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
