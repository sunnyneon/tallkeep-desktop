import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { R as Plus, a as Wallet } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bills-BRCUV60-.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var STATUS_STYLE = {
	open: "bg-amber-100 text-amber-800",
	paid: "bg-emerald-100 text-emerald-800",
	void: "bg-muted text-muted-foreground"
};
var STATUS_LABEL = {
	open: "To pay",
	paid: "Paid",
	void: "Void"
};
function Bills() {
	const navigate = useNavigate();
	const [show, setShow] = (0, import_react.useState)("open");
	const [q, setQ] = (0, import_react.useState)("");
	const { data, isLoading } = useQuery({
		queryKey: ["bills"],
		queryFn: async () => {
			const { data, error } = await db.from("bills").select("id,vendor_name,ref,bill_date,due_date,memo,status,total,balance").order("bill_date", { ascending: false }).limit(5e3);
			if (error) throw error;
			return data ?? [];
		}
	});
	const rows = (0, import_react.useMemo)(() => smartSearch((data ?? []).filter((r) => show === "all" || r.status === "open"), q, (r) => r.vendor_name ?? "", (r) => `${r.ref ?? ""} ${r.memo ?? ""}`), [
		data,
		show,
		q
	]);
	const owed = (data ?? []).filter((r) => r.status === "open").reduce((s, r) => s + Number(r.balance), 0);
	const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Bills & Expenses",
			text: "Bills you owe (rent, utilities, subcontractors…) and expenses you already paid. Purchase orders are paid from their own page.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/bills/$id",
						params: { id: "new" },
						search: { paid: 1 },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-4 w-4" }), " New expense (already paid)"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/bills/$id",
						params: { id: "new" },
						search: {},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New bill"]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex rounded-lg border p-0.5 text-sm",
					children: ["open", "all"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setShow(v),
						className: `rounded-md px-3 py-1 ${show === v ? "bg-[var(--section)] text-white" : ""}`,
						children: v === "open" ? "To pay" : "All"
					}, v))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-xs",
					placeholder: "Search vendor, number or memo",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: owed > 0 ? `We owe ${fmtMoney(owed)} on bills` : "No unpaid bills"
				})
			]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-2xl border bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b bg-muted/40 text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Date"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Vendor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Bill #"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Memo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Due"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-semibold",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-right font-semibold",
							children: "Total"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-right font-semibold",
							children: "Still owed"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y",
					children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "cursor-pointer hover:bg-muted/50",
						onClick: () => navigate({
							to: "/bills/$id",
							params: { id: r.id },
							search: {}
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap px-3 py-2",
								children: fmtDate(r.bill_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 font-medium",
								children: r.vendor_name || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: r.ref
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-xs truncate px-3 py-2 text-muted-foreground",
								children: r.memo
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `whitespace-nowrap px-3 py-2 ${r.status === "open" && r.due_date && r.due_date < today ? "font-medium text-destructive" : ""}`,
								children: r.due_date ? fmtDate(r.due_date) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded px-1.5 py-0.5 text-xs ${STATUS_STYLE[r.status]}`,
									children: STATUS_LABEL[r.status]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-right tabular-nums",
								children: fmtMoney(r.total)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-right tabular-nums",
								children: r.status === "open" ? fmtMoney(r.balance) : ""
							})
						]
					}, r.id)), data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 8,
						className: "p-8 text-center text-muted-foreground",
						children: show === "open" ? "No bills to pay." : "No bills or expenses yet."
					}) })]
				})]
			})
		})
	] });
}
//#endregion
export { Bills as component };
