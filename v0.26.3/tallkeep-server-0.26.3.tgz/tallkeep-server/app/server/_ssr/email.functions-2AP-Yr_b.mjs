import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/email.functions-2AP-Yr_b.js
/** Emails a day for one company: free trial, and paid plans. Tallkeep's own account: no limit. */
var PER_DAY = {
	trial: 30,
	paid: 300
};
/** Stop when the company has sent its emails for today; else count this one. */
async function emailLimit(companyId, recipients = 1) {
	if (process.env["TALLKEEP_DESKTOP"]) return;
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const db = supabaseAdmin;
	const { data: c } = await db.from("companies").select("org_id").eq("id", companyId).maybeSingle();
	const { data: o } = c ? await db.from("orgs").select("status,is_platform").eq("id", c.org_id).maybeSingle() : { data: null };
	if (o?.is_platform) return;
	const max = o?.status === "trial" ? PER_DAY.trial : PER_DAY.paid;
	const since = (/* @__PURE__ */ new Date(Date.now() - 864e5)).toISOString();
	const { data: rows, error } = await db.from("email_sends").select("recipients").eq("company_id", companyId).gte("created_at", since);
	if (error) return;
	if ((rows ?? []).reduce((t, r) => t + r.recipients, 0) + recipients > max) throw new Error(`This company has sent its ${max} emails for today. Try again tomorrow, or write to hello@tallkeep.com.`);
	await db.from("email_sends").insert({
		company_id: companyId,
		recipients
	});
}
/** Send a quote / invoice / PO as a PDF from the company (see mailer.server.ts). */
var sendDocEmail_createServerFn_handler = createServerRpc({
	id: "a7f32f276406e2d7206bbca2e8c5fc871d65fb4425fcac828b84b5aae9eb123f",
	name: "sendDocEmail",
	filename: "src/lib/email.functions.ts"
}, (opts) => sendDocEmail.__executeServer(opts));
var sendDocEmail = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const ok = (e) => /^\S+@\S+\.\S+$/.test(e);
	if (!d.to.length || !d.to.every(ok)) throw new Error("Type a valid email for the customer.");
	if (!d.cc.every(ok)) throw new Error("One of the copy addresses isn't a valid email.");
	if (d.to.length + d.cc.length > 10) throw new Error("Send to 10 addresses at most.");
	if (!d.pdfBase64) throw new Error("The PDF is missing.");
	if (d.pdfBase64.length > 14e6) throw new Error("The PDF is too big to email.");
	return d;
}).handler(sendDocEmail_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { requireZone, activeCompany } = await import("./zone.server-JWxH1ixr.mjs");
	await requireZone(context.userId, ["Sales", "Purchasing"], "emailing documents", context.supabase);
	const companyId = await activeCompany(context.supabase, true);
	await emailLimit(companyId, data.to.length + data.cc.length);
	const { data: me } = await supabaseAdmin.auth.admin.getUserById(context.userId);
	const { data: coRows } = await supabaseAdmin.from("company_settings").select("*").eq("company_id", companyId).limit(1);
	const co = (coRows ?? [])[0] ?? {};
	const fromName = (co.email_from_name || co.name || "").trim();
	const replyTo = co.email_reply_to || me.user?.email || co.email || null;
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const r = await deliver({
		fromName,
		to: data.to,
		cc: data.cc,
		replyTo,
		subject: data.subject,
		text: data.message,
		attachments: [{
			filename: data.filename,
			content: data.pdfBase64
		}]
	});
	if (!r.ok) throw new Error(process.env["TALLKEEP_DESKTOP"] === "1" && /isn't set up/.test(r.why) ? "Email isn't set up yet: an admin can set it up in Settings → Company → Email." : `The email didn't go: ${r.why}.`);
	return { id: r.id ?? "" };
});
//#endregion
export { sendDocEmail_createServerFn_handler };
