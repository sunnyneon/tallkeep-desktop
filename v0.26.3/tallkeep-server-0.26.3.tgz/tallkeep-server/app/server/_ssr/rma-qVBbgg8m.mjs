import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as SalesList } from "./SalesList-C5x82AV8.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/rma-qVBbgg8m.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesList, {
	title: "RMAs",
	text: "Return Merchandise Authorizations — they look like a quote and don't change money or stock.",
	newKind: "rma",
	newLabel: "New RMA",
	initial: {
		show: "rma",
		inv: "all",
		pay: "all",
		cancelled: false
	}
});
//#endregion
export { SplitComponent as component };
