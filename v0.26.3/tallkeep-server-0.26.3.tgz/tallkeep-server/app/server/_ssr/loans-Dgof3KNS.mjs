import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/loans-Dgof3KNS.js
/**
* Loan and mortgage statements from the Shoebox.
*
* The statement tells Tallkeep who the lender is, the monthly payment and how it splits
* (principal, interest, escrow), what's still owed and the interest rate. Tallkeep then:
*   1. finds the loan's account (by the last 4 digits, or the Mortgage / Car Loan / Student Loans
*      account), or adds one;
*   2. remembers the loan (the `loans` table), with an interest account (Mortgage Interest or Loan
*      Interest) and, when there's escrow, an escrow account (Home Taxes and Insurance);
*   3. sets the loan's balance in the books to the statement's (only while Tallkeep made all of
*      that account's entries itself);
*   4. splits the payments to this lender waiting in Bank Feeds, and every new one after that.
*/
var T = (t) => db.from(t);
var rpc = (f, a) => db.rpc(f, a);
var KIND_NAME = {
	mortgage: "Mortgage",
	car: "Car Loan",
	student: "Student Loans",
	personal: "Personal Loan",
	heloc: "Home Equity Line",
	other: "Loan"
};
/** The starter accounts personal books come with. */
var STARTER = {
	mortgage: "2510",
	car: "2520",
	student: "2530"
};
var isDay = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? ""));
var num = (v) => {
	if (v == null || v === "") return null;
	const n = Number(String(v).replace(/[$,%\s]/g, ""));
	return Number.isFinite(n) ? Math.abs(Math.round(n * 1e3) / 1e3) : null;
};
var money = (v) => v == null ? null : Math.round(v * 100) / 100;
/** Words that don't tell one lender from another on a bank line. */
var COMMON = new Set("the of and bank home homes loan loans mortgage mortgages financial finance servicing services service lending lender credit union national n.a na inc llc co corp company group trust fsb federal savings auto car student payment".split(" "));
/** A word from the lender's name that shows on their bank lines ("Lakeview Loan Servicing" → "lakeview"). */
function matchWord(lender) {
	return (lender ?? "").toLowerCase().replace(/[^a-z0-9 ]+/g, " ").split(" ").filter((w) => w.length >= 3 && !COMMON.has(w))[0] ?? null;
}
function loanKind(v) {
	const k = String(v ?? "").toLowerCase();
	return Object.keys(KIND_NAME).includes(k) ? k : "other";
}
var loanAccounts = (accounts) => accounts.filter((a) => a.is_active && (a.kind === "long_term_liability" || a.kind === "other_liability"));
/** A free account number near the others of its kind. */
function freeNumber(accounts, from) {
	const used = new Set(accounts.map((a) => a.number));
	let n = from;
	while (used.has(String(n))) n++;
	return String(n);
}
async function addAccount(accounts, a) {
	const { data, error } = await T("accounts").insert({
		number: freeNumber(accounts, a.from),
		name: a.name,
		type: a.type,
		kind: a.kind,
		description: a.description ?? null
	}).select("id,number,name,type,kind,key,description,is_active").single();
	if (error) throw new Error(error.message);
	accounts.push(data);
	return data;
}
/** An expense account by one of its names, or a new one. */
async function expenseAccount(accounts, names, from) {
	const low = names.map((n) => n.toLowerCase());
	const hit = accounts.find((a) => a.type === "expense" && low.includes(a.name.toLowerCase()));
	if (hit) return hit;
	return addAccount(accounts, {
		name: names[0],
		type: "expense",
		kind: "expense",
		from
	});
}
/** The loan's account: the one with these last 4 digits, the starter account, or a new one. */
async function findLoanAccount(accounts, loans, kind, lender, last4) {
	const pool = loanAccounts(accounts);
	if (last4) {
		const byLoan = loans.find((l) => l.last4 === last4);
		const a1 = byLoan && pool.find((a) => a.id === byLoan.account_id);
		if (a1) return {
			acct: a1,
			added: false
		};
		const hits = pool.filter((a) => `${a.number ?? ""} ${a.name} ${a.description ?? ""}`.includes(last4));
		if (hits.length === 1) return {
			acct: hits[0],
			added: false
		};
	}
	const m = matchWord(lender);
	if (m && !last4) {
		const byLender = loans.find((l) => matchWord(l.lender) === m);
		const a2 = byLender && pool.find((a) => a.id === byLender.account_id);
		if (a2) return {
			acct: a2,
			added: false
		};
	}
	const starter = STARTER[kind];
	const s = starter ? pool.find((a) => a.number === starter && !loans.some((l) => l.account_id === a.id)) : void 0;
	const label = [lender, last4 ? `ending ${last4}` : null].filter(Boolean).join(", ");
	if (s) {
		if (label && !s.description) await T("accounts").update({ description: label }).eq("id", s.id);
		return {
			acct: {
				...s,
				description: s.description || label
			},
			added: false
		};
	}
	return {
		acct: await addAccount(accounts, {
			name: `${KIND_NAME[kind]}${lender ? ` (${lender})` : ""}`.slice(0, 80),
			type: "liability",
			kind: "long_term_liability",
			from: 2540,
			description: label
		}),
		added: true
	};
}
/** What the AI read off a loan statement, cleaned up. */
function readLoan(r) {
	const payment = num(r["payment"] ?? r["amount_due"] ?? r["total"]);
	const principal = num(r["principal"]);
	const interest = num(r["interest"]);
	const escrow = num(r["escrow"]);
	const fees = num(r["fees"]);
	const rate = num(r["rate"]);
	return {
		kind: loanKind(r["loan_kind"]),
		lender: r["issuer"] ? String(r["issuer"]).trim() : r["vendor"] ? String(r["vendor"]) : null,
		last4: /^\d{4}$/.test(String(r["account_last4"] ?? "")) ? String(r["account_last4"]) : null,
		statementDate: isDay(r["period_end"]) ? String(r["period_end"]) : isDay(r["date"]) ? String(r["date"]) : null,
		dueDate: isDay(r["due_date"]) ? String(r["due_date"]) : null,
		payment: money(payment),
		principal: money(principal),
		interest: money(interest),
		escrow: money(escrow),
		fees: money(fees),
		balance: money(num(r["balance"])),
		rate: rate == null ? null : rate < 1 ? rate * 100 : rate > 30 ? null : rate
	};
}
/**
* Save a loan (from a statement, or typed in on Mortgage & Loans): its account, the interest and
* escrow accounts, the `loans` row, the balance, and the payments waiting in Bank Feeds.
*/
async function saveLoan(L, ctx, opts = {}) {
	const accounts = [...ctx.accounts];
	const { data: had } = await T("loans").select("id,account_id,last4,lender,match");
	const loans = had ?? [];
	let found;
	const picked = opts.accountId && accounts.find((a) => a.id === opts.accountId);
	if (picked) found = {
		acct: picked,
		added: false
	};
	else if (opts.name) found = {
		acct: await addAccount(accounts, {
			name: opts.name.slice(0, 80),
			type: "liability",
			kind: "long_term_liability",
			from: 2540,
			description: [L.lender, L.last4 ? `ending ${L.last4}` : null].filter(Boolean).join(", ")
		}),
		added: true
	};
	else found = await findLoanAccount(accounts, loans, L.kind, L.lender, L.last4);
	const { acct, added } = found;
	const old = loans.find((l) => l.account_id === acct.id);
	const interestAcct = L.interest || L.rate ? await expenseAccount(accounts, L.kind === "mortgage" || L.kind === "heloc" ? ["Mortgage Interest"] : ["Loan Interest", "Interest Expense"], L.kind === "mortgage" || L.kind === "heloc" ? 8125 : 8120) : null;
	const escrowAcct = L.escrow ? await expenseAccount(accounts, ["Home Taxes and Insurance (escrow)", "Escrow (taxes and insurance)"], 8140) : null;
	const row = {
		account_id: acct.id,
		lender: L.lender,
		match: opts.match !== void 0 ? opts.match?.trim().toLowerCase() || null : old?.match ?? matchWord(L.lender),
		loan_kind: L.kind,
		last4: L.last4,
		rate: L.rate,
		interest_account_id: interestAcct?.id ?? null,
		escrow_account_id: escrowAcct?.id ?? null,
		payment: L.payment,
		principal: L.principal,
		interest: L.interest,
		escrow: L.escrow,
		fees: L.fees,
		balance: L.balance,
		statement_date: L.statementDate,
		due_date: L.dueDate,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	};
	const saved = old ? await T("loans").update(row).eq("id", old.id).select("id").single() : await T("loans").insert(row).select("id").single();
	if (saved.error) throw new Error(saved.error.message);
	const loanId = saved.data.id;
	ctx.step("Splitting the payments in Bank Feeds…");
	let state = String((await rpc("set_loan_balance", { _loan: loanId })).data ?? "");
	let split = 0;
	for (const b of accounts.filter((a) => a.is_active && a.kind === "bank")) {
		const { data } = await rpc("record_loan_payments", { _bank: b.id });
		split += Number(data ?? 0);
	}
	if (split) state = String((await rpc("set_loan_balance", { _loan: loanId })).data ?? state);
	return {
		loanId,
		acct,
		added,
		state,
		split,
		match: row.match
	};
}
/** File a loan statement: the loan, its balance, and its payments in Bank Feeds. */
async function fileLoan(id, r, ctx, fileName) {
	const L = readLoan(r);
	ctx.step(`${fileName}: saving the loan…`);
	const { loanId, acct, added, state, split, match } = await saveLoan(L, ctx);
	const row = { match };
	const parts = [
		L.principal != null ? `${fmtMoney(L.principal)} pays down the loan` : null,
		L.interest != null ? `${fmtMoney(L.interest)} interest` : null,
		L.escrow ? `${fmtMoney(L.escrow)} escrow (taxes and insurance)` : null,
		L.fees ? `${fmtMoney(L.fees)} fees` : null
	].filter(Boolean);
	const what = `${KIND_NAME[L.kind] === "Loan" ? "A loan" : `A ${KIND_NAME[L.kind].toLowerCase()}`} statement${L.lender ? ` from ${L.lender}` : ""}${L.last4 ? ` (ending ${L.last4})` : ""}.`;
	const pay = L.payment ? ` Payment ${fmtMoney(L.payment)}${parts.length ? `: ${parts.join(", ")}` : ""}.` : "";
	const owed = L.balance != null ? ` Still owed ${fmtMoney(L.balance)}${L.rate ? ` at ${L.rate}%` : ""}.` : "";
	const books = state.startsWith("differs:") ? ` The books show ${fmtMoney(Math.abs(Number(state.slice(8))))} ${Number(state.slice(8)) > 0 ? "less" : "more"} owed on the statement date than the statement does.` : state === "set" ? ` ${acct.name} now shows what's owed.` : "";
	const next = row.match ? ` ${split ? `${split} payment${split === 1 ? "" : "s"} in Bank Feeds split automatically; ` : ""}each payment to ${L.lender ?? "this lender"} in Bank Feeds will be split by itself.` : " Payments to this lender wait in Bank Feeds for you.";
	const summary = `${what}${pay}${owed}${added ? ` Added the account ${acct.name}.` : ""}${books}${next}`;
	const { data: it } = await T("shoebox_items").select("ai").eq("id", id).maybeSingle();
	await T("shoebox_items").update({
		ai: {
			...it?.ai ?? r,
			loan_differs: state.startsWith("differs:") ? Number(state.slice(8)) : null
		},
		status: "done",
		kind: "loan",
		account_id: acct.id,
		target_type: "loan",
		target_id: loanId,
		summary
	}).eq("id", id);
}
/** Split loan payments waiting in Bank Feeds for one bank account (0 before step 51). */
async function recordLoanPayments(bankId) {
	const { data, error } = await rpc("record_loan_payments", { _bank: bankId });
	return error ? 0 : Number(data ?? 0);
}
/** "Match the statement": one adjusting entry so the books show what the statement says. */
async function matchLoanStatement(itemId, loanId) {
	const { data, error } = await rpc("set_loan_balance", {
		_loan: loanId,
		_force: true
	});
	if (error) throw new Error(error.message);
	const { data: it } = await T("shoebox_items").select("ai,summary").eq("id", itemId).maybeSingle();
	await T("shoebox_items").update({
		ai: {
			...it?.ai ?? {},
			loan_differs: null
		},
		summary: String(it?.summary ?? "").replace(/ The books show \S+ (less|more) owed on the statement date than the statement does\./, " The books now match the statement.")
	}).eq("id", itemId);
	return String(data ?? "");
}
//#endregion
export { recordLoanPayments as a, matchWord as i, loanKind as n, saveLoan as o, matchLoanStatement as r, fileLoan as t };
