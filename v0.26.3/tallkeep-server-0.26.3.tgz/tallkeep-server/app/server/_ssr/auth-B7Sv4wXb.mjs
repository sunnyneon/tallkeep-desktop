import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as supabase } from "./client-sss9hg5u.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/auth-B7Sv4wXb.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** The office (desktop) version: no email and no free trials; the office admin adds people. */
var DESKTOP = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1"
}["VITE_TALLKEEP_DESKTOP"];
function AuthPage() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		supabase.auth.getUser().then(({ data }) => {
			if (data.user) navigate({
				to: "/",
				replace: true
			});
		});
	}, [navigate]);
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		const { error } = await supabase.auth.signInWithPassword({
			email,
			password
		});
		setBusy(false);
		if (error) {
			toast.error("Wrong email or password. Please try again.");
			return;
		}
		navigate({
			to: "/",
			replace: true
		});
	}
	async function onForgot() {
		if (!email) {
			toast("Type your email first, then tap “Forgot password?”");
			return;
		}
		const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
		if (error) toast.error("Could not send the email. Please try again.");
		else toast.success("Check your email for a link to set a new password.");
	}
	const [brand, setBrand] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!DESKTOP) return;
		fetch("/tallkeep/brand").then((r) => r.ok ? r.json() : null).then((b) => setBrand(b)).catch(() => {});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-screen lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden flex-col justify-between bg-[#0F2A44] p-12 lg:flex",
			children: [
				brand?.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-fit rounded-2xl bg-white p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: brand.logo,
						alt: brand.name ?? "",
						className: "max-h-20 max-w-64"
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mb-6 h-1.5 w-16 rounded-full bg-[#F07A1A]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl font-bold leading-tight text-white",
					children: brand?.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						brand.name,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#2CC0C2]",
							children: "Stock, sales and books."
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Stock, sales and books.",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[#2CC0C2]",
							children: "All in one place."
						})
					] })
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tracking-[0.2em] text-white/60",
					children: brand?.logo ? "TALLKEEP · OWN YOUR BOOKS" : "OWN YOUR BOOKS"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-center px-6 py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "w-full max-w-sm space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden",
						children: brand?.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: brand.logo,
							alt: brand.name ?? "",
							className: "max-h-14 max-w-48"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { light: true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-bold",
						children: "Sign in"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted-foreground",
						children: "Use your work email and password."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "email",
							children: "Email"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "email",
							type: "email",
							autoComplete: "email",
							required: true,
							value: email,
							onChange: (e) => setEmail(e.target.value),
							className: "h-11"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "password",
								children: "Password"
							}), !DESKTOP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onForgot,
								className: "text-sm font-medium text-primary hover:underline",
								children: "Forgot password?"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "password",
							type: "password",
							autoComplete: "current-password",
							required: true,
							value: password,
							onChange: (e) => setPassword(e.target.value),
							className: "h-11"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "h-11 w-full text-base",
						children: busy ? "Signing in…" : "Sign in"
					}),
					DESKTOP ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: "No login yet, or forgot your password? Ask your office admin: they add people and set new passwords in Settings → Users."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: [
							"New to Tallkeep?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/signup",
								className: "font-medium text-primary hover:underline",
								children: "Start your 30-day free trial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block pt-1",
								children: "Joining a team? Ask your manager to add you."
							})
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { AuthPage as component };
