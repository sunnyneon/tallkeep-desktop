import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { Nn as ArrowLeft, R as Plus, Wt as DollarSign } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as PartyForm } from "./PartyForm-CojDUW5Y.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { d as payStatus } from "./sales-DLuHnKkT.mjs";
import { t as Route } from "./customers_._id-BKH2zgUB.mjs";
import { t as SideLayout } from "./SideList-CDc-cOPj.mjs";
import { r as nameMatch, t as CustomerHistory } from "./PartyHistory-Do-Bvbp7.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-C7HocT_U.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers_._id-__MsDXT2.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function CustomerPage() {
	const { id } = Route.useParams();
	const [collect, setCollect] = (0, import_react.useState)(false);
	const [tab, setTab] = useSticky("customer-tab", "orders");
	const { data: c, isLoading } = useQuery({
		queryKey: ["customer", id],
		queryFn: async () => {
			const { data, error } = await db.from("customers").select("*").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: docs } = useQuery({
		queryKey: [
			"customer",
			id,
			"docs",
			c?.name
		],
		enabled: !!c,
		queryFn: async () => {
			const { data, error } = await db.from("sales_orders").select("id,number,status,order_date,total,amount_paid,balance,stock_taken_at,due_date,po_number").or(`customer_id.eq.${id},and(customer_id.is.null,${nameMatch("customer_name", c.name)})`).order("order_date", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: pays } = useQuery({
		queryKey: [
			"customer",
			id,
			"payments"
		],
		queryFn: async () => {
			const { data, error } = await db.from("payments").select("id,paid_on,amount,method,reference,sales_orders!inner(id,number,customer_id)").eq("sales_orders.customer_id", id).order("paid_on", { ascending: false });
			if (error) throw error;
			return data ?? [];
		}
	});
	if (isLoading || !c) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
			kind: { type: "customer" },
			currentId: id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })] })
		})
	});
	const open = (docs ?? []).filter((d) => ["Unpaid", "Partial"].includes(payStatus(d)) || payStatus(d) === "Uninvoiced" && Number(d.amount_paid) > 0);
	const owed = (docs ?? []).filter((d) => ["Unpaid", "Partial"].includes(payStatus(d))).reduce((s, d) => s + Number(d.balance), 0);
	const credit = (docs ?? []).filter((d) => d.status !== "quote" && d.status !== "rma" && d.status !== "cancelled" && Number(d.balance) < 0).reduce((s, d) => s - Number(d.balance), 0);
	const sold = (docs ?? []).filter((d) => d.status !== "quote" && d.status !== "rma" && d.status !== "cancelled").reduce((s, d) => s + Number(d.total), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
		kind: { type: "customer" },
		currentId: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/customers",
				className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Customer list"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-bold sm:text-3xl",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: [
						c.contact_name,
						c.phone,
						c.email
					].filter(Boolean).join(" · ")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Balance",
							value: fmtMoney(owed),
							warn: owed > 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Credit",
							value: fmtMoney(credit)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Sold all time",
							value: fmtMoney(sold)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sales/$id",
							params: { id: "new" },
							search: {
								kind: "quote",
								customer: c.id
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New quote"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sales/$id",
							params: { id: "new" },
							search: {
								kind: "order",
								customer: c.id
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New invoice"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setCollect(true),
						disabled: !open.length,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-4 w-4" }), " Collect payment"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: tab,
				onValueChange: setTab,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "orders",
							children: [
								"Quotes, invoices & RMAs (",
								docs?.length ?? 0,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "info",
							children: "Customer info"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
							value: "payments",
							children: [
								"Payment history (",
								pays?.length ?? 0,
								")"
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "info",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyForm, {
							kind: "customers",
							record: c
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomerHistory, {
							docs: docs ?? [],
							customerId: id
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "payments",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "divide-y overflow-hidden rounded-2xl border bg-card",
							children: [(pays ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "p-6 text-center text-muted-foreground",
								children: "No payments yet."
							}), (pays ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 px-4 py-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-28",
										children: fmtDate(p.paid_on)
									}),
									p.sales_orders && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/sales/$id",
										params: { id: p.sales_orders.id },
										search: {},
										className: "w-28 text-primary",
										children: p.sales_orders.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 truncate text-muted-foreground",
										children: [p.method, p.reference].filter(Boolean).join(" · ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: fmtMoney(p.amount)
									})
								]
							}, p.id))]
						})
					})
				]
			}),
			collect && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectPayment, {
				customerId: c.id,
				open,
				onClose: () => setCollect(false)
			})
		] })
	});
}
function Stat({ label, value, warn }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border bg-card px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `font-display text-lg font-bold ${warn ? "text-primary" : ""}`,
			children: value
		})]
	});
}
function CollectPayment({ customerId, open, onClose }) {
	const qc = useQueryClient();
	const [orderId, setOrderId] = (0, import_react.useState)(open[0]?.id ?? "");
	const pick = open.find((d) => d.id === orderId);
	const [amount, setAmount] = (0, import_react.useState)(pick ? Number(pick.balance).toFixed(2) : "");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const [method, setMethod] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		const n = Number(amount);
		if (!orderId || !n) {
			toast.error("Pick an invoice and type the amount.");
			return;
		}
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const { error } = await db.from("payments").insert({
			sales_order_id: orderId,
			amount: n,
			paid_on: (/* @__PURE__ */ new Date(date + "T12:00:00")).toISOString(),
			method: method || null,
			reference: ref || null,
			created_by: u.user?.id
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Payment recorded.");
		qc.invalidateQueries({ queryKey: ["customer", customerId] });
		qc.invalidateQueries({ queryKey: ["sales"] });
		qc.invalidateQueries({ queryKey: ["sale", orderId] });
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Collect payment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Choose which invoice this payment is for." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Invoice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: orderId,
							onValueChange: (v) => {
								setOrderId(v);
								const d = open.find((x) => x.id === v);
								if (d) setAmount(Number(d.balance).toFixed(2));
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: open.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: d.id,
								children: [
									d.number,
									" · owes ",
									fmtMoney(d.balance)
								]
							}, d.id)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How they paid" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								list: "pay-methods-c",
								value: method,
								onChange: (e) => setMethod(e.target.value),
								placeholder: "Check, card, wire…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "pay-methods-c",
								children: [
									"Check",
									"Credit card",
									"Wire transfer",
									"ACH",
									"Cash",
									"Zelle"
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: m }, m))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check # or reference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				disabled: busy,
				children: busy ? "Saving…" : "Save payment"
			})] })
		] })
	});
}
//#endregion
export { CustomerPage as component };
