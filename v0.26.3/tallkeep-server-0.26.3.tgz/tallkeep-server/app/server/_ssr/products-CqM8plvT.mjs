import { r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/products-CqM8plvT.js
var $$splitComponentImporter = () => import("./products-DfeG_pEQ.mjs");
var Route = createFileRoute("/_authenticated/products")({
	validateSearch: (s) => typeof s["q"] === "string" ? { q: s["q"] } : {},
	head: () => ({ meta: [{ title: "Products · Tallkeep" }, {
		name: "description",
		content: "Your product list, prices and stock."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function useProductList() {
	return useQuery({
		queryKey: ["products"],
		queryFn: () => fetchAll("products", "id,name,description,barcode,item_type,category_id,price,reorder_point,is_active,unit,stock(qty)")
	});
}
//#endregion
export { useProductList as n, Route as t };
