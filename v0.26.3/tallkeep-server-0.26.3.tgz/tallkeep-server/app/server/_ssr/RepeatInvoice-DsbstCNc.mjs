import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { N as Repeat, W as Pause, at as Mail, g as Trash2, z as Play } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/RepeatInvoice-DsbstCNc.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var EVERY_LABEL = {
	week: "Every week",
	month: "Every month",
	quarter: "Every 3 months",
	year: "Every year"
};
var EVERY_SHORT = {
	week: "weekly",
	month: "monthly",
	quarter: "every 3 months",
	year: "yearly"
};
/** The n-th date after a first one, like the database: the 31st becomes the month's last day. */
function dateAfter(start, every, n) {
	const [y, m, d] = start.split("-").map(Number);
	if (every === "week") return new Date(Date.UTC(y, m - 1, d + 7 * n)).toISOString().slice(0, 10);
	const months = every === "year" ? 12 * n : every === "quarter" ? 3 * n : n;
	const total = m - 1 + months;
	const ty = y + Math.floor(total / 12);
	const tm = (total % 12 + 12) % 12;
	const last = new Date(Date.UTC(ty, tm + 1, 0)).getUTCDate();
	return new Date(Date.UTC(ty, tm, Math.min(d, last))).toISOString().slice(0, 10);
}
var localToday = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
/** The schedule repeating this invoice, if there is one. */
function useRepeatOf(orderId) {
	return useQuery({
		queryKey: ["repeat-of", orderId],
		enabled: !!orderId,
		queryFn: async () => {
			const { data, error } = await db.from("recurring").select("*").eq("kind", "invoice").eq("sales_order_id", orderId).order("created_at", { ascending: false }).limit(1);
			if (error) return null;
			return (data ?? [])[0] ?? null;
		}
	});
}
/** "Repeat this invoice" on an invoice, or how it repeats when it already does. */
function RepeatButton({ orderId, number, customer, invoiceDate }) {
	const { data: rep } = useRepeatOf(orderId);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		onClick: () => setOpen(true),
		title: "Make a copy of this invoice every month (or week, 3 months, year), by itself",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-4 w-4" }), rep ? rep.active ? `Repeats ${EVERY_SHORT[rep.every]} · next ${fmtDate(rep.next_date)}` : "Repeating is paused" : "Repeat this invoice"]
	}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RepeatDialog, {
		orderId,
		number,
		customer,
		invoiceDate,
		rep: rep ?? null,
		onClose: () => setOpen(false)
	})] });
}
/** Set up, change, pause or stop a repeating invoice. */
function RepeatDialog({ orderId, number, customer, invoiceDate, rep, onClose }) {
	const qc = useQueryClient();
	const firstGuess = () => {
		const base = (invoiceDate ?? localToday()).slice(0, 10);
		let d = dateAfter(base, "month", 1);
		for (let i = 2; d < localToday() && i < 400; i++) d = dateAfter(base, "month", i);
		return d;
	};
	const [every, setEvery] = (0, import_react.useState)(rep?.every ?? "month");
	const [first, setFirst] = (0, import_react.useState)(rep?.next_date ?? firstGuess());
	const [end, setEnd] = (0, import_react.useState)(rep?.end_date ?? "");
	const [draft, setDraft] = (0, import_react.useState)(rep?.as_draft ?? false);
	const [mail, setMail] = (0, import_react.useState)(rep?.email_customer ?? false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (rep) {
			setEvery(rep.every);
			setFirst(rep.next_date);
			setEnd(rep.end_date ?? "");
			setDraft(rep.as_draft);
			setMail(!!rep.email_customer);
		}
	}, [rep]);
	const coming = first ? [
		0,
		1,
		2,
		3
	].map((n) => dateAfter(first, every, n)).filter((d) => !end || d <= end) : [];
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["repeat-of"] });
		qc.invalidateQueries({ queryKey: ["repeating"] });
		qc.invalidateQueries({ queryKey: ["sales"] });
	};
	async function save() {
		if (!first) return void toast.error("Pick the date of the first new invoice.");
		if (end && end < first) return void toast.error("The last date is before the first one.");
		if (first < localToday() && !rep) {
			if (!window.confirm(`${fmtDate(first)} has passed. Tallkeep will make the invoices for the dates already passed right away. Go ahead?`)) return;
		}
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const row = {
			kind: "invoice",
			name: `${customer || "Customer"} · ${number}`,
			sales_order_id: orderId,
			every,
			next_date: first,
			start_date: first,
			steps: 0,
			end_date: end || null,
			as_draft: draft,
			...mail && !draft ? { email_customer: true } : rep?.email_customer ? { email_customer: false } : {},
			auto: true,
			active: true,
			last_error: null
		};
		const { error } = rep ? await db.from("recurring").update(row).eq("id", rep.id) : await db.from("recurring").insert({
			...row,
			created_by: u.user?.id
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(rep ? "Saved." : `${number} will repeat ${EVERY_SHORT[every]}, starting ${fmtDate(first)}. Each one is made on its day.`);
		refresh();
		onClose();
	}
	async function setActive(active) {
		if (!rep) return;
		setBusy(true);
		const { error } = await db.from("recurring").update({
			active,
			last_error: null
		}).eq("id", rep.id);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(active ? "Repeating again." : "Paused. Nothing more is made until you resume.");
		refresh();
		onClose();
	}
	async function stop() {
		if (!rep) return;
		if (!window.confirm("Stop repeating this invoice? The invoices already made stay as they are; no new ones are made.")) return;
		setBusy(true);
		const { error } = await db.from("recurring").delete().eq("id", rep.id);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Stopped.");
		refresh();
		onClose();
	}
	async function makeNow() {
		if (!rep) return;
		if (!window.confirm(`Make the invoice for ${fmtDate(rep.next_date)} now?`)) return;
		setBusy(true);
		const { error } = await db.rpc("make_recurring_now", { _id: rep.id });
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Invoice made.");
		refresh();
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: rep ? "Repeating invoice" : "Repeat this invoice" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"On each date Tallkeep makes a copy of ",
					number,
					": same customer, items, prices, terms and notes. To change what the next ones say, change ",
					number,
					"."
				] })] }),
				rep?.last_error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-md bg-amber-100 px-3 py-2 text-sm text-amber-900 dark:bg-amber-900/40 dark:text-amber-100",
					children: ["Paused: ", rep.last_error]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "How often"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-9 rounded-md border bg-background px-2",
								value: every,
								onChange: (e) => setEvery(e.target.value),
								children: Object.keys(EVERY_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: EVERY_LABEL[k]
								}, k))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: rep ? "Next one on" : "First new one on"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: first,
									onChange: (e) => setFirst(e.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Last one on (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: end,
									onChange: (e) => setEnd(e.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "grid gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Make them as"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										checked: !draft,
										onChange: () => setDraft(false)
									}), "Ready invoices (in the books, due by the terms)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "radio",
										checked: draft,
										onChange: () => setDraft(true)
									}), "Drafts to check first (Uninvoiced: press Make invoice when right)"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: `flex items-start gap-2 ${draft ? "opacity-50" : ""}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-0.5",
								checked: mail && !draft,
								disabled: draft,
								onChange: (e) => setMail(e.target.checked)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Email each new invoice to the customer, with its PDF", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: draft ? "Drafts aren't emailed: send them yourself once they're right." : "Sent from 8 in the morning on its day, to the invoice's email (or the customer's). You get a short note of what went."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border bg-muted/40 px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Coming: "
								}),
								coming.length ? coming.map((d) => fmtDate(d)).join(", ") : "nothing",
								coming.length === 4 && (!end || dateAfter(first, every, 4) <= end) ? ", …" : ""
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "flex-wrap gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: rep && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => void stop(),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Stop repeating"]
							}),
							rep.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => void setActive(false),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" }), " Pause"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => void setActive(true),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" }), " Resume"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => void makeNow(),
								disabled: busy,
								children: "Make the next one now"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy,
						children: rep ? "Save" : "Start repeating"
					})]
				})
			]
		})
	});
}
/** On an invoice a schedule made: where it came from. */
function MadeByRepeat({ recurringId }) {
	const { data } = useQuery({
		queryKey: ["repeat-source", recurringId],
		queryFn: async () => {
			const { data } = await db.from("recurring").select("sales_order_id, every").eq("id", recurringId).maybeSingle();
			const r = data;
			if (!r?.sales_order_id) return null;
			const { data: o } = await db.from("sales_orders").select("id, number").eq("id", r.sales_order_id).maybeSingle();
			return o ? {
				...o,
				every: r.every
			} : null;
		}
	});
	if (!data) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1 text-xs text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-3.5 w-3.5" }),
			" Made ",
			EVERY_SHORT[data.every],
			" from",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/sales/$id",
				params: { id: data.id },
				search: {},
				className: "underline",
				children: data.number
			})
		]
	});
}
/** On an invoice: the emails Tallkeep sent by itself (new invoice, reminders). */
function InvoiceEmailsNote({ orderId }) {
	const { data } = useQuery({
		queryKey: ["invoice-emails", orderId],
		queryFn: async () => {
			const { data, error } = await db.from("invoice_emails").select("kind,step,ok,why,at,to_email").eq("sales_order_id", orderId).order("at");
			if (error) return [];
			return data ?? [];
		}
	});
	if (!data?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex flex-wrap items-center gap-x-2 text-xs text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5" }), data.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: r.ok ? "" : "text-red-700",
			title: r.ok ? `To ${r.to_email ?? ""}` : r.why ?? "",
			children: [
				r.kind === "new" ? "Emailed" : `Reminder ${r.step}`,
				" ",
				fmtDate(r.at),
				r.ok ? "" : " (didn't go)",
				i < data.length - 1 ? " ·" : ""
			]
		}, i))]
	});
}
//#endregion
export { RepeatDialog as a, RepeatButton as i, InvoiceEmailsNote as n, MadeByRepeat as r, EVERY_LABEL as t };
