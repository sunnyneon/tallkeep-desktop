import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/print-checks-DK-H1smb.js
var $$splitComponentImporter = () => import("./print-checks-CFNWK55x.mjs");
var Route = createFileRoute("/_authenticated/print-checks")({
	validateSearch: (s) => typeof s["only"] === "string" ? { only: s["only"] } : {},
	head: () => ({ meta: [{ title: "Print Checks · Tallkeep" }, {
		name: "description",
		content: "Print checks on voucher check paper."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
