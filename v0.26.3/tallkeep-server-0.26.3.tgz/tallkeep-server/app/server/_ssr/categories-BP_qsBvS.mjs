import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { At as Folder, Mt as FolderOpen, R as Plus, g as Trash2, in as ChevronRight, on as ChevronDown } from "../_libs/lucide-react.mjs";
import { i as useIsAdmin, r as useCategories } from "./queries-DKvOnwaZ.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useProductList } from "./products-CqM8plvT.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/categories-BP_qsBvS.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function Categories() {
	const qc = useQueryClient();
	const { data: cats } = useCategories();
	const { data: products } = useProductList();
	const { data: isAdmin } = useIsAdmin();
	const [sel, setSel] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [name, setName] = (0, import_react.useState)("");
	const kids = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(cats ?? []).forEach((c) => {
			const k = c.parent_id ?? null;
			m.set(k, [...m.get(k) ?? [], c]);
		});
		m.forEach((v) => v.sort((a, b) => a.name.localeCompare(b.name)));
		return m;
	}, [cats]);
	const count = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(products ?? []).forEach((p) => p.category_id && m.set(p.category_id, (m.get(p.category_id) ?? 0) + 1));
		return m;
	}, [products]);
	const list = (products ?? []).filter((p) => p.category_id === sel).sort((a, b) => a.name.localeCompare(b.name));
	const selCat = cats?.find((c) => c.id === sel);
	async function add(e) {
		e.preventDefault();
		if (!name.trim()) return;
		const { error } = await db.from("categories").insert({
			name: name.trim(),
			parent_id: sel
		});
		if (error) {
			toast.error(error.message);
			return;
		}
		setName("");
		if (sel) setOpen((o) => new Set(o).add(sel));
		toast.success(sel ? `Added under ${selCat?.name}.` : "Category added.");
		qc.invalidateQueries({ queryKey: ["categories"] });
	}
	async function remove() {
		if (!sel) return;
		if ((kids.get(sel) ?? []).length || (count.get(sel) ?? 0)) {
			toast.error("Move its products and sub-categories first.");
			return;
		}
		const { error } = await db.from("categories").delete().eq("id", sel);
		if (error) {
			toast.error(error.message);
			return;
		}
		setSel(null);
		toast.success("Category removed.");
		qc.invalidateQueries({ queryKey: ["categories"] });
	}
	function Node({ c, depth }) {
		const children = kids.get(c.id) ?? [];
		const isOpen = open.has(c.id);
		const n = count.get(c.id) ?? 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `flex items-center gap-1 rounded-md py-1 pr-2 text-sm ${sel === c.id ? "bg-[var(--section)] text-white" : "hover:bg-muted"}`,
			style: { paddingLeft: depth * 16 + 4 },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "grid h-5 w-5 place-items-center",
				onClick: () => setOpen((o) => {
					const s = new Set(o);
					if (s.has(c.id)) s.delete(c.id);
					else s.add(c.id);
					return s;
				}),
				children: children.length ? isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-3.5 w-3.5" }) : null
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "flex flex-1 items-center gap-1.5 text-left",
				onClick: () => setSel(c.id),
				children: [
					isOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-4 w-4 text-amber-500" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folder, { className: "h-4 w-4 text-amber-500" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: c.name
					}),
					n > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "opacity-70",
						children: [
							"(",
							n,
							")"
						]
					})
				]
			})]
		}), isOpen && children.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
			c: k,
			depth: depth + 1
		}, k.id))] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Product Categories",
			text: "Group products. Click a category to see its products, or add one under it."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-[320px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border bg-card p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-h-[60vh] overflow-y-auto",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `mb-1 w-full rounded-md px-2 py-1 text-left text-sm ${sel === null ? "bg-[var(--section)] text-white" : "hover:bg-muted"}`,
							onClick: () => setSel(null),
							children: "All categories (top level)"
						}), (kids.get(null) ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
							c,
							depth: 0
						}, c.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: add,
						className: "flex gap-2 border-t pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: sel ? `New under ${selCat?.name}` : "New category",
							value: name,
							onChange: (e) => setName(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							size: "sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
						})]
					}),
					isAdmin && sel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: remove,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }),
							" Remove ",
							selCat?.name
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Description"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Normal price"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [
							!sel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 3,
								className: "p-8 text-center text-muted-foreground",
								children: "Choose a category on the left."
							}) }),
							sel && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 3,
								className: "p-8 text-center text-muted-foreground",
								children: "No products in this category."
							}) }),
							list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-muted/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/products/$id",
											params: { id: p.id },
											className: "font-medium hover:underline",
											children: p.name
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[480px] truncate px-3 py-2 text-muted-foreground",
										children: p.description
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 text-right",
										children: fmtMoney(p.price)
									})
								]
							}, p.id))
						]
					})]
				})
			})]
		})]
	});
}
//#endregion
export { Categories as component };
