import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-tVjV6EnW.mjs";
import { Yt as Clock, en as CircleCheck, lt as LoaderCircle, st as Lock, zt as FileCheckCorner } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Route } from "./pay._token-C-raFH4y.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay._token-CAHTVsGq.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** The customer's "Pay now" page (no sign-in). See pay.server.ts. */
var tokenOk = (t) => typeof t === "string" && /^[A-Za-z0-9_-]{10,40}$/.test(t);
var getPayPage = createServerFn({ method: "GET" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	return {
		token: d.token,
		session: /^cs_[A-Za-z0-9_]+$/.test(d.session ?? "") ? d.session : void 0
	};
}).handler(createSsrRpc("65167bf74740ab17c0fbab7a39a651e64108b27c734b7bc92f51ab7af27647c0"));
var startPayCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	if (!/^https?:\/\/[^/\s]+$/.test(d.origin)) throw new Error("Bad address.");
	return d;
}).handler(createSsrRpc("1451e52a03e1d052f3d1a13763407804acbc263dab8122da9b78e14acc3f6c68"));
/** The customer accepts a quote on its link (typing their name). */
var acceptQuote = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This link isn't right.");
	const name = String(d.name ?? "").trim().slice(0, 120);
	if (name.length < 2) throw new Error("Type your name to accept.");
	return {
		token: d.token,
		name
	};
}).handler(createSsrRpc("5dc7d881149d1054bafa0caa5fa9c389eb01afc534cc586a6ed5aef7f445bd6d"));
/**
* The customer's page for an invoice or a quote: no sign-in. An invoice is paid through Stripe's
* secure checkout (card, Apple Pay, Google Pay or bank account). A quote is read, accepted by
* typing a name, and its deposit paid the same way.
*/
var money = (cents, cur) => (cents / 100).toLocaleString("en-US", {
	style: "currency",
	currency: cur.toUpperCase()
});
var dollars = (n, cur) => money(Math.round(n * 100), cur);
var day = (iso) => iso ? new Date(iso).toLocaleDateString("en-US", {
	month: "short",
	day: "numeric",
	year: "numeric"
}) : "";
function PayPageView() {
	const { token } = Route.useParams();
	const { session } = Route.useSearch();
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [agree, setAgree] = (0, import_react.useState)(false);
	const key = [
		"pay",
		token,
		session
	];
	const { data, isLoading, error } = useQuery({
		queryKey: key,
		queryFn: () => getPayPage({ data: {
			token,
			session
		} }),
		refetchInterval: (q) => session && q.state.data?.status === "open" && !q.state.data?.pending ? 3e3 : false
	});
	async function pay() {
		setBusy(true);
		try {
			const r = await startPayCheckout({ data: {
				token,
				origin: window.location.origin
			} });
			window.location.href = r.url;
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	async function accept() {
		setBusy(true);
		try {
			const r = await acceptQuote({ data: {
				token,
				name
			} });
			qc.setQueryData(key, r);
			if (r.status === "open" && r.amountCents > 0) return void await pay();
			toast.success("Accepted. Thank you!");
		} catch (e) {
			toast.error(e.message);
		}
		setBusy(false);
	}
	const quote = data?.kind === "quote";
	const title = quote ? `Quote ${data?.number ?? ""}` : `Invoice ${data?.number ?? ""}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `mx-auto space-y-4 ${quote ? "max-w-2xl" : "max-w-md"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) : error || !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "This link isn't right or has ended. Please contact the business that sent it."
				}) : data.status === "canceled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"This ",
						quote ? "quote" : "invoice",
						" can't be ",
						quote ? "accepted" : "paid",
						" here anymore. Please contact ",
						data.business,
						"."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: data.business
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl font-semibold",
							children: title
						}),
						data.customer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: ["For ", data.customer]
						}),
						quote && data.doc?.project && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: ["Project: ", data.doc.project]
						})
					] }),
					quote && data.doc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteBody, { d: data }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
						d: data,
						session,
						busy,
						onPay: () => void pay(),
						accept: quote && !data.acceptedAt && data.status === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 rounded-xl border p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: "Accept this quote"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Your full name",
									value: name,
									onChange: (e) => setName(e.target.value),
									autoComplete: "name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-start gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "mt-1",
										checked: agree,
										onChange: (e) => setAgree(e.target.checked)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"I accept this quote from ",
										data.business.replace(/\.$/, ""),
										data.doc?.terms ? " and its terms" : "",
										"."
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "lg",
									className: "w-full",
									onClick: () => void accept(),
									disabled: busy || !agree || name.trim().length < 2,
									children: [
										busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "h-4 w-4" }),
										"Accept quote",
										data.amountCents > 0 ? ` and pay the ${money(data.amountCents, data.currency)} deposit` : ""
									]
								})
							]
						}) : null
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: "Secure payment by Stripe: card, Apple Pay, Google Pay or bank account. Your details go to Stripe, never to the business or Tallkeep."
			})]
		})
	});
}
/** The quote's lines and totals. */
function QuoteBody({ d }) {
	const q = d.doc;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Qty"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Price"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Total"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: q.lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-pre-line px-3 py-2",
								children: l.d
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-right",
								children: l.q
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-right",
								children: dollars(l.p, d.currency)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-right",
								children: dollars(l.t, d.currency)
							})
						] }, i))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto w-full max-w-xs space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Subtotal",
						v: dollars(q.subtotal, d.currency)
					}),
					q.tax ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Tax",
						v: dollars(q.tax, d.currency)
					}) : null,
					q.shipping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Shipping",
						v: dollars(q.shipping, d.currency)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t pt-1 text-base font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: dollars(q.total, d.currency) })]
					})
				]
			}),
			q.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-line text-sm",
				children: q.notes
			}),
			q.terms && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-lg border px-3 py-2 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm text-foreground",
					children: "Terms"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 whitespace-pre-line",
					children: q.terms
				})]
			})
		]
	});
}
var Row = ({ label, v }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "flex justify-between",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: v })]
});
/** What's done and what's next: accept, pay, on its way, paid. */
function Status({ d, session, busy, onPay, accept }) {
	const quote = d.kind === "quote";
	const accepted = quote && d.acceptedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-100",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0" }),
			" Accepted by ",
			d.acceptedName,
			" on",
			" ",
			day(d.acceptedAt),
			"."
		]
	}) : null;
	if (d.status === "paid") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 text-center",
		children: [
			accepted,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-12 w-12 text-emerald-600" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Paid. Thank you!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					d.business,
					" received ",
					money(d.paidCents ?? d.amountCents, d.currency),
					quote ? " as the deposit" : d.number ? ` for invoice ${d.number}` : "",
					". You can keep this page as your receipt."
				]
			})
		]
	});
	if (d.status === "accepted") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-12 w-12 text-emerald-600" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Accepted. Thank you!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [d.business, " has your OK and will be in touch about next steps."]
			}),
			accepted
		]
	});
	if (d.pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [accepted, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-start gap-2 rounded-lg bg-sky-50 px-3 py-2 text-sm text-sky-900 dark:bg-sky-900/30 dark:text-sky-100",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-0.5 h-4 w-4 shrink-0" }),
				"Your bank payment of ",
				money(d.amountCents, d.currency),
				" is on its way. Bank payments take a few business days; this page shows Paid once it arrives."
			]
		})]
	});
	if (accept) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: accept });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			accepted,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-muted/40 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: quote ? "Deposit due now" : "Amount due"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-semibold",
					children: money(d.amountCents, d.currency)
				})]
			}),
			session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Confirming your payment…"]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				className: "w-full",
				onClick: onPay,
				disabled: busy,
				children: [
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
					"Pay ",
					money(d.amountCents, d.currency)
				]
			})
		]
	});
}
//#endregion
export { PayPageView as component };
