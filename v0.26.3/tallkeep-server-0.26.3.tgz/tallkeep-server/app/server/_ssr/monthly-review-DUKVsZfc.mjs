import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, p as useTotals, u as loadTotals } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { c as monthName, f as thisMonth, i as amountIn, l as monthRange, r as addMonths } from "./personal-C-Op5nYv.mjs";
import { N as Repeat, an as ChevronLeft, in as ChevronRight, jn as ArrowRight, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { l as useReminders, n as daysBetween, r as findPayment } from "./reminders-Tzw68Ce0.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as useWho, r as useAccountOwners } from "./members-BvdxHr68.mjs";
import { t as WhoPicker } from "./WhoPicker-DLJRzcvg.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/monthly-review-DUKVsZfc.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function MonthlyReview() {
	const qc = useQueryClient();
	const [ym, setYm] = (0, import_react.useState)(addMonths(thisMonth(), -1));
	const { from, to } = monthRange(ym);
	const prev3 = {
		from: monthRange(addMonths(ym, -3)).from,
		to: monthRange(addMonths(ym, -1)).to
	};
	const { data: accounts } = useAccounts();
	const { data: totals } = useTotals(from, to);
	const before = useQuery({
		queryKey: [
			"account-totals",
			prev3.from,
			prev3.to
		],
		queryFn: () => loadTotals(prev3.from, prev3.to)
	});
	const { data: reminders } = useReminders();
	const [who] = useWho();
	const { data: owners } = useAccountOwners();
	const [busy, setBusy] = (0, import_react.useState)("");
	const lines = useQuery({
		queryKey: [
			"review-lines",
			from,
			to
		],
		queryFn: async () => {
			const out = [];
			for (let i = 0;; i += 1e3) {
				const { data, error } = await db.from("bank_transactions").select("id,account_id,txn_date,amount,description,status").gte("txn_date", addDays(from, -4)).lte("txn_date", addDays(to, 4)).range(i, i + 999);
				if (error) throw error;
				out.push(...(data ?? []).map((l) => ({
					...l,
					amount: Number(l.amount)
				})));
				if (!data || data.length < 1e3) break;
			}
			return out;
		}
	});
	const recs = useQuery({
		queryKey: ["reconciliations-list"],
		queryFn: () => fetchAll("reconciliations", "account_id,statement_date,completed_at")
	});
	const money = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card") && (!who || owners?.get(a.id) === who));
	const inMonth = (l) => l.txn_date >= from && l.txn_date <= to;
	const all = lines.data ?? [];
	const pairs = (0, import_react.useMemo)(() => {
		const mine = new Set(money.map((a) => a.id));
		const waiting = all.filter((l) => l.status === "new" && mine.has(l.account_id));
		const used = /* @__PURE__ */ new Set();
		const out = [];
		for (const o of waiting.filter((l) => l.amount < 0 && inMonth(l))) {
			const i = waiting.find((l) => !used.has(l.id) && l.account_id !== o.account_id && l.amount > 0 && Math.abs(l.amount + o.amount) < .005 && Math.abs(daysBetween(o.txn_date, l.txn_date)) <= 4);
			if (i) {
				used.add(i.id);
				out.push({
					out: o,
					in: i
				});
			}
		}
		return out;
	}, [
		all,
		money.length,
		from,
		to
	]);
	const name = (id) => accounts?.find((a) => a.id === id)?.name ?? "";
	async function pair(p) {
		setBusy(p.out.id);
		try {
			const a = await db.rpc("add_bank_transaction", {
				_txn: p.out.id,
				_other: p.in.account_id,
				_memo: p.out.description ?? ""
			});
			if (a.error) throw new Error(a.error.message);
			const { data, error } = await db.rpc("account_lines", {
				_account: p.in.account_id,
				_to: null
			});
			if (error) throw new Error(error.message);
			const hit = (data ?? []).find((l) => !l.cleared && Math.abs(Math.abs(Number(l.amount)) - p.in.amount) < .005 && l.entry_date === p.out.txn_date);
			if (hit) {
				await db.from("bank_transactions").update({
					status: "matched",
					source_type: hit.source_type,
					source_id: hit.item_key
				}).eq("id", p.in.id);
				await db.from("cleared_items").upsert({
					account_id: p.in.account_id,
					item_key: hit.item_key
				}, { onConflict: "account_id,item_key" });
			}
			toast.success(`Recorded ${fmtMoney(p.in.amount)} from ${name(p.out.account_id)} to ${name(p.in.account_id)}.`);
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	if (!accounts || lines.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	const cats = accounts.filter((a) => a.type === "expense");
	const spendRows = cats.map((a) => ({
		a,
		now: amountIn(a, totals),
		avg: amountIn(a, before.data) / 3
	})).filter((x) => x.now > .004 || x.avg > .004).sort((x, y) => y.now - x.now).slice(0, 10);
	const cameIn = accounts.filter((a) => a.type === "income").reduce((s, a) => s + amountIn(a, totals), 0);
	const wentOut = cats.reduce((s, a) => s + amountIn(a, totals), 0);
	const waiting = all.filter((l) => inMonth(l) && l.status === "new" && money.some((a) => a.id === l.account_id)).length;
	const due = (reminders ?? []).filter((r) => r.status === "active" && (!who || r.member_id === who) && (r.last_paid && r.last_paid >= from && r.last_paid <= to || r.next_date >= from && r.next_date <= to));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Monthly Review",
			text: "Go through a month once it's over: is every account in, is anything waiting, are transfers paired, were the bills paid?",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": "Month before",
						onClick: () => setYm(addMonths(ym, -1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-36 text-center font-medium",
						children: monthName(ym)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": "Month after",
						onClick: () => setYm(addMonths(ym, 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoPicker, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Came in",
					value: fmtMoney(cameIn)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Went out",
					value: fmtMoney(wentOut)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Left over",
					value: fmtMoney(cameIn - wentOut),
					bad: cameIn - wentOut < 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Waiting in Bank Feeds",
					value: String(waiting),
					bad: waiting > 0
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Box, {
			title: "1. Each account",
			children: [money.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No bank or card accounts yet." }), money.map((a) => {
				const mine = all.filter((l) => l.account_id === a.id && inMonth(l));
				const wait = mine.filter((l) => l.status === "new").length;
				const last = mine.map((l) => l.txn_date).sort().at(-1);
				const rec = (recs.data ?? []).filter((r) => r.account_id === a.id && r.completed_at).map((r) => r.statement_date).sort().at(-1);
				const ok = mine.length > 0 && wait === 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2.5 w-2.5 rounded-full", ok ? "bg-emerald-500" : mine.length ? "bg-amber-500" : "bg-muted-foreground/40") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted-foreground",
							children: [
								mine.length ? `${mine.length} lines, last ${fmtDate(last)}` : "Nothing brought in for this month yet",
								wait > 0 && ` · ${wait} waiting`,
								rec ? ` · reconciled through ${fmtDate(rec)}` : " · not reconciled yet"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/banking",
							search: { account: a.id },
							children: [
								mine.length ? wait ? "Record them" : "Bank Feeds" : "Bring in a statement",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
							]
						})
					})
				] }, a.id);
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
			title: `2. Transfers and card payments to pair (${pairs.length})`,
			children: pairs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nothing to pair." }) : pairs.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-4 w-4 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-medium",
						children: [
							fmtMoney(p.in.amount),
							": ",
							name(p.out.account_id),
							" → ",
							name(p.in.account_id)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block truncate text-xs text-muted-foreground",
						children: [
							fmtDate(p.out.txn_date),
							" “",
							p.out.description,
							"” and ",
							fmtDate(p.in.txn_date),
							" “",
							p.in.description,
							"”"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => void pair(p),
					disabled: !!busy,
					children: [busy === p.out.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), "Record as one transfer"]
				})
			] }, p.out.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
			title: "3. Bills and subscriptions",
			children: due.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, { children: [
				"No bills for this month. Add them on",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/subscriptions",
					className: "underline",
					children: "Bills & Subscriptions"
				}),
				"."
			] }) : due.map((r) => {
				const paid = r.last_paid && r.last_paid >= from && r.last_paid <= to;
				const hit = !paid ? findPayment(r, (lines.data ?? []).filter((l) => l.amount < 0).map((l) => ({
					...l,
					amount: -l.amount
				}))) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-2.5 w-2.5 rounded-full", paid || hit ? "bg-emerald-500" : "bg-amber-500") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: r.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: paid ? `Paid ${fmtDate(r.last_paid)}` : hit ? `Found in the bank ${fmtDate(hit.txn_date)}` : `Due ${fmtDate(r.next_date)}, not seen paid`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: r.amount == null ? "—" : fmtMoney(r.amount)
					})
				] }, r.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Box, {
			title: "4. Where the money went",
			children: [spendRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No spending recorded for this month." }) : spendRows.map(({ a, now, avg }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendRow, {
				a,
				now,
				avg
			}, a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-2 text-xs text-muted-foreground",
				children: "Compared with the average of the 3 months before."
			})]
		})
	] });
}
function addDays(d, n) {
	const x = /* @__PURE__ */ new Date(`${d}T12:00:00`);
	x.setDate(x.getDate() + n);
	return x.toLocaleDateString("en-CA");
}
function SpendRow({ a, now, avg }) {
	const diff = avg > 0 ? Math.round((now - avg) / avg * 100) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/accounts/$id",
			params: { id: a.id },
			className: "min-w-0 flex-1 truncate font-medium hover:underline",
			children: a.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: fmtMoney(now)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("w-28 text-right text-xs", diff != null && diff > 20 ? "text-destructive" : "text-muted-foreground"),
			children: diff == null ? "new" : diff === 0 ? "same as usual" : `${diff > 0 ? "+" : ""}${diff}% vs usual`
		})
	] });
}
function Tile({ label, value, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-2xl font-semibold tabular-nums", bad && "text-amber-600"),
			children: value
		})]
	});
}
function Box({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "border-b bg-muted/40 px-4 py-2 font-semibold",
			children: title
		}), children]
	});
}
var Row = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "flex flex-wrap items-center gap-3 border-t px-4 py-2 text-sm first:border-t-0",
	children
});
var Empty = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	className: "px-4 py-6 text-center text-sm text-muted-foreground",
	children
});
//#endregion
export { MonthlyReview as component };
