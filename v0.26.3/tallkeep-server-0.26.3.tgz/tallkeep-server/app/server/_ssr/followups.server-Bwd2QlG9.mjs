import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { supabaseAdmin as supabaseAdmin$1 } from "./client.server-KzwUIAkW.mjs";
import { o as savedEmail } from "./emailWording-D3tWNGRw.mjs";
import { n as ageDays, o as stageOf, r as followupMessage, t as DEFAULT_RULES } from "./followups-CAmQFMgv.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/followups.server-Bwd2QlG9.js
var supabaseAdmin = supabaseAdmin$1;
var APP = "https://app.tallkeep.com";
async function sendEmail(to, subject, text, replyTo) {
	const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
	const r = await deliver({
		to,
		subject,
		text,
		replyTo: replyTo ?? null
	});
	if (!r.ok) throw new Error(`Email failed: ${r.why}`);
}
/**
* The daily quote job: close quotes past the close day, and either email the customer
* (if automatic emails are on) or send the office a list of who to follow up with.
*/
async function runQuoteFollowups(opts = {}) {
	let q = supabaseAdmin.from("company_settings").select("*");
	if (opts.companyId) q = q.eq("company_id", opts.companyId);
	const { data: rows } = await q;
	const out = {
		skipped: true,
		closed: 0,
		due: 0,
		emailed: 0
	};
	for (const c of rows ?? []) {
		const r = await runForCompany(c, opts);
		out.skipped = out.skipped && r.skipped;
		out.closed += r.closed;
		out.due += r.due;
		out.emailed += r.emailed;
	}
	return out;
}
async function runForCompany(co, opts) {
	const rules = {
		...DEFAULT_RULES,
		...Object.fromEntries(Object.entries(co).filter(([k]) => k in DEFAULT_RULES))
	};
	if (!rules.followup_enabled && !opts.force) return {
		skipped: true,
		closed: 0,
		due: 0,
		emailed: 0
	};
	const { data } = await supabaseAdmin.from("sales_orders").select("id, number, status, order_date, followup_count, customer_name, contact_name, email, total").eq("status", "quote").eq("company_id", co.company_id ?? "").limit(5e3);
	const { data: acc } = await supabaseAdmin.from("sales_orders").select("id").eq("status", "quote").eq("company_id", co.company_id ?? "").not("accepted_at", "is", null).limit(5e3);
	const done = new Set((acc ?? []).map((r) => r.id));
	const quotes = (data ?? []).filter((q) => !done.has(q.id));
	const now = Date.now();
	const company = co.name || "";
	const officeEmail = co.email || "info@sunriseled.com";
	const toClose = quotes.filter((q) => stageOf(q, rules, now) === "close");
	const due = quotes.filter((q) => {
		const st = stageOf(q, rules, now);
		return st === "first" || st === "second";
	});
	if (toClose.length) {
		const reason = `Closed automatically: no answer after ${rules.quote_close_days} days`;
		for (let i = 0; i < toClose.length; i += 200) await supabaseAdmin.from("sales_orders").update({
			status: "cancelled",
			closed_reason: reason
		}).in("id", toClose.slice(i, i + 200).map((q) => q.id));
	}
	let emailed = 0;
	const manual = [];
	for (const q of due) {
		const second = stageOf(q, rules, now) === "second";
		if (rules.followup_auto_email && q.email) try {
			const own = savedEmail(co.email_wording, "quote_followup", {
				name: q.contact_name || q.customer_name || "",
				customer: q.customer_name ?? "",
				number: q.number,
				total: fmtMoney(Number(q.total ?? 0)),
				company
			});
			await sendEmail([q.email], own?.subject ?? `Following up: quote ${q.number} from ${company}`, own?.body ?? followupMessage(q, company, second), officeEmail);
			await supabaseAdmin.from("sales_orders").update({
				followup_count: Number(q.followup_count ?? 0) + 1,
				last_followup_at: (/* @__PURE__ */ new Date()).toISOString()
			}).eq("id", q.id);
			emailed++;
		} catch {
			manual.push(q);
		}
		else manual.push(q);
	}
	if (manual.length || toClose.length || emailed) {
		const lines = [];
		if (manual.length) {
			lines.push(`Quotes to follow up today (${manual.length}):`);
			manual.forEach((q) => lines.push(`- ${q.number} · ${q.customer_name ?? ""} · ${ageDays(q.order_date, now)} days old · ${APP}/sales/${q.id}?followup=1`));
			lines.push("");
		}
		if (emailed) lines.push(`${emailed} customers were emailed a follow-up automatically.`, "");
		if (toClose.length) {
			lines.push(`Closed ${toClose.length} quotes older than ${rules.quote_close_days} days:`);
			toClose.slice(0, 50).forEach((q) => lines.push(`- ${q.number} · ${q.customer_name ?? ""}`));
			if (toClose.length > 50) lines.push(`…and ${toClose.length - 50} more.`);
			lines.push("You can reopen any of them from the quote page.");
		}
		try {
			await sendEmail([officeEmail], `Quote follow-ups for today (${manual.length})`, lines.join("\n"));
		} catch {}
	}
	return {
		skipped: false,
		closed: toClose.length,
		due: manual.length,
		emailed
	};
}
//#endregion
export { runQuoteFollowups };
