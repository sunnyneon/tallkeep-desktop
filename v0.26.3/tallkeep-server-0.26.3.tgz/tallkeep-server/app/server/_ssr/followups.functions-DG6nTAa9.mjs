import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/followups.functions-DG6nTAa9.js
/** Admin: run today's quote follow-ups now (same as the daily job). */
var runFollowupsNow_createServerFn_handler = createServerRpc({
	id: "1c07c766055e3d99b4ce098f5bad7d8d0756bbe632b9e9d2384ee4f72ef8ecfc",
	name: "runFollowupsNow",
	filename: "src/lib/followups.functions.ts"
}, (opts) => runFollowupsNow.__executeServer(opts));
var runFollowupsNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(runFollowupsNow_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", context.userId).eq("role", "admin").maybeSingle();
	if (!data) throw new Error("Only an admin can do this.");
	const { runQuoteFollowups } = await import("./followups.server-Bwd2QlG9.mjs");
	const { activeCompany } = await import("./zone.server-JWxH1ixr.mjs");
	return runQuoteFollowups({
		force: true,
		companyId: await activeCompany(context.supabase, true)
	});
});
//#endregion
export { runFollowupsNow_createServerFn_handler };
