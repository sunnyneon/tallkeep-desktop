//#region ../../node_modules/.nitro/vite/services/ssr/assets/emailWording-D3tWNGRw.js
var WORDING_KINDS = [
	{
		kind: "quote",
		label: "Quote",
		when: "When you email a quote.",
		fields: [
			"name",
			"customer",
			"number",
			"total",
			"company",
			"terms_line"
		]
	},
	{
		kind: "invoice",
		label: "Invoice",
		when: "When you email an invoice, and when a repeating invoice is emailed by itself.",
		fields: [
			"name",
			"customer",
			"number",
			"total",
			"balance",
			"due_date",
			"company",
			"terms_line",
			"payment_note"
		]
	},
	{
		kind: "quote_followup",
		label: "Quote follow-up",
		when: "Following up on a quote, by hand or by itself.",
		fields: [
			"name",
			"customer",
			"number",
			"total",
			"company"
		]
	},
	{
		kind: "payment_reminder",
		label: "Payment reminder",
		when: "Asking about a late invoice, by hand or the automatic overdue reminders.",
		fields: [
			"name",
			"customer",
			"number",
			"balance",
			"due_date",
			"days_late",
			"company"
		]
	},
	{
		kind: "po",
		label: "Purchase order",
		when: "When you email a purchase order to a vendor.",
		fields: [
			"name",
			"vendor",
			"number",
			"total",
			"company"
		]
	}
];
/** What each fill-in word becomes, in plain words for the Settings screen. */
var FIELD_HELP = {
	name: "the contact's name (or the customer's)",
	customer: "the customer's name",
	vendor: "the vendor's name",
	number: "the document number",
	total: "the total",
	balance: "what's still owed",
	due_date: "the due date",
	days_late: "how many days late",
	company: "your company name",
	terms_line: "\"Our Terms & Conditions are on the last page.\" when attached",
	payment_note: "\"Your prompt payment is appreciated.\" when money is owed"
};
var DEFAULT_WORDING = {
	quote: {
		subject: "Quote {number} from {company}",
		body: "Hello {name},\n\nPlease find attached our quote {number} for {total}.{terms_line}\n\nThank you,\n{company}"
	},
	invoice: {
		subject: "Invoice {number} from {company}",
		body: "Hello {name},\n\nPlease find attached our invoice {number} for {total}.{terms_line}{payment_note}\n\nThank you,\n{company}"
	},
	quote_followup: {
		subject: "Following up: quote {number} from {company}",
		body: "Hello {name},\n\nI'm following up on our quote {number}.\n\nIf you'd like a new quote with different specs, are looking for a lower price, or have any questions, just reply to this email and we'll be happy to help.\n\nThank you,\n{company}"
	},
	payment_reminder: {
		subject: "Payment reminder: invoice {number} from {company}",
		body: "Hello {name},\n\nA friendly reminder about invoice {number}: {balance} was due on {due_date}. The invoice is attached.\n\nPlease send us the status of this payment. If you've already sent it, thank you, and please let us know the date and how it was paid.\n\nThank you,\n{company}"
	},
	po: {
		subject: "Purchase Order {number} from {company}",
		body: "Hello {name},\n\nPlease find attached our purchase order {number}. Please confirm the order and the ship date.\n\nThank you,\n{company}"
	}
};
/** The company's own wording for this email, or null (use the built-in one). */
function savedWording(saved, kind) {
	const w = saved?.[kind];
	if (!w || !w.subject?.trim() && !w.body?.trim()) return null;
	return {
		subject: w.subject?.trim() || DEFAULT_WORDING[kind].subject,
		body: w.body?.trim() ? w.body : DEFAULT_WORDING[kind].body
	};
}
/** Put the values in: {number} → INV-001001. Unknown words stay as typed. */
function fillWording(text, values) {
	return text.replace(/\{([a-z_]+)\}/g, (all, key) => key in values ? String(values[key] ?? "") : all).replace(/\n{3,}/g, "\n\n").trim();
}
/** Subject and message for an email: the company's wording filled in, or null. */
function savedEmail(saved, kind, values) {
	const w = savedWording(saved, kind);
	return w ? {
		subject: fillWording(w.subject, values),
		body: fillWording(w.body, values)
	} : null;
}
/** Example values for the preview in Settings. */
var SAMPLE_VALUES = {
	name: "Sam Patel",
	customer: "Lone Oak Auto",
	vendor: "Acme Supply",
	number: "INV-001042",
	total: "$1,942.40",
	balance: "$971.20",
	due_date: "Nov 30, 2026",
	days_late: "12",
	company: "Your Company",
	terms_line: "\nOur Terms & Conditions are on the last page.",
	payment_note: "\n\nYour prompt payment is appreciated."
};
//#endregion
export { fillWording as a, WORDING_KINDS as i, FIELD_HELP as n, savedEmail as o, SAMPLE_VALUES as r, DEFAULT_WORDING as t };
