//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ds1cQQNP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BdabJupl.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bw20J02D.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuWl1-_-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BdabJupl.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DL_oQueO.js",
			"/assets/log-out-BfH83uO9.js",
			"/assets/testers.functions-CYPR22Q_.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-BOCHCs9D.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BeAuadBR.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-BOo1RQAQ.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/dist-Ci6cizzQ.js",
			"/assets/dialog-koK57bmx.js",
			"/assets/queries-CoTwIZGh.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/label-qCuUMrQ4.js",
			"/assets/textarea-Du9k3xa4.js",
			"/assets/shoebox-CSaEOPVd.js",
			"/assets/company-BpxJ-8Zv.js",
			"/assets/reports-DU1m_pTa.js",
			"/assets/access-n-RMpd0n.js",
			"/assets/LicenseCard-fyms0mhK.js",
			"/assets/Logo-Dx7OXdmj.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-D0GuYfK-.js",
			"/assets/log-out-BfH83uO9.js",
			"/assets/admin.functions-C8V2Wt7F.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-Dx7OXdmj.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DKaFzR1O.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/label-qCuUMrQ4.js",
			"/assets/Logo-Dx7OXdmj.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-CJFOOHpM.js",
			"/assets/testers.functions-CYPR22Q_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/buy.functions-BcAtAING.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-B3unt6mv.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/downloads.functions-BeU2dXul.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-DWP4Wb_z.js",
			"/assets/testers.functions-CYPR22Q_.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/textarea-Du9k3xa4.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Bp_8QR4J.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/label-qCuUMrQ4.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-D1LE3HMz.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/label-qCuUMrQ4.js",
			"/assets/Logo-Dx7OXdmj.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CDyXAozk.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/upgrade.functions-Czz8JD5V.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-Cu1nQzLe.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/label-qCuUMrQ4.js",
			"/assets/Logo-Dx7OXdmj.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DLBZgGhg.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-CfQ1_5R0.js", "/assets/StockDocList-Bb_EvXhO.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BQiOpaxF.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/ai-BPVwo3Yz.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-DFpVocdF.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CKXpFaM2.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/ai-BPVwo3Yz.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/TxnEditor-B6GBUhQ0.js",
			"/assets/feedWaiting-DLL1S0nn.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Cs66xYf-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DQncecnP.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CklBifJh.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CFCB1mPW.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-B_TeuNLe.js", "/assets/AccountRegister-CN6Um6DH.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Bny-EQEc.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BSyWVR4b.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BSGKtKia.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BPVwo3Yz.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-D0gD1-Vz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Bb09SOlz.js", "/assets/StockDocList-Bb_EvXhO.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-BbgJkke_.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CTCQp9qR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DhU0_Q3M.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CX0Xj1uf.js", "/assets/PartyList-bBaPmV2Z.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-D8dSNQwU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DMhiyopR.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/storage.functions-P74nnP6o.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-T8xm07iB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CGlO36q6.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CZ9qdA0R.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CsMIJGmI.js", "/assets/ChangeHistory-Bc4gxPjI.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CEElUSYi.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/members-B1ktLCoR.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-s12au56s.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CklBifJh.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-B8FYYMeJ.js", "/assets/SalesList-Cyo59mDx.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CyltpptV.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BA0VzMGh.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DnyNgi2K.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-jDHKNAH_.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/loans-DlX_C_YK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Bjb6YW6g.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-DhOH641s.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-DMyxThm6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CklBifJh.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Y1Elq0pn.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-B1xA1oMD.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CklBifJh.js",
			"/assets/generateCategoricalChart-Sox6D0zr.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DZMOE9Yl.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-Sox6D0zr.js",
			"/assets/BarChart-BHMM2JhM.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-R5hYSS7-.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CeLvf4mx.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DkVtA_pU.js",
			"/assets/createServerFn-DQkAhuwQ.js",
			"/assets/auth-middleware-DhKuGcqk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/storage.functions-P74nnP6o.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BYHFaGtJ.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-F1VIcKt6.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/checkbox-lBy1ajyZ.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CQ-gV2SW.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-C97_cI-v.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-B0Hm99qu.js", "/assets/SalesList-Cyo59mDx.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DoJKV16H.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/ai-BPVwo3Yz.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-P74nnP6o.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CXh_2Qav.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-jQOpeHXa.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-0IEt_UCj.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-6CxmTiD-.js", "/assets/AccountRegister-CN6Um6DH.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DI218CCs.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/MoneyAccountPick-CI61x9cn.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DN2kiRYL.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BYHUk58Z.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/RepeatInvoice-DKSK5nFW.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-D3Fr4dlM.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-Sox6D0zr.js",
			"/assets/BarChart-BHMM2JhM.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BWhlQbCp.js", "/assets/SalesList-Cyo59mDx.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-BJS9QVXx.js", "/assets/SalesList-Cyo59mDx.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BoKMSiPB.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-f8sFK9qo.js",
			"/assets/createServerFn-DQkAhuwQ.js",
			"/assets/auth-middleware-DhKuGcqk.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-U61IRKEk.js",
			"/assets/switch-DhOH641s.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/QuickBooksImport-DhU0_Q3M.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-lBy1ajyZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-CGdy_Dlz.js",
			"/assets/FeaturePicker-C8Ij2F-n.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-B_wGy_u3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/FeaturePicker-C8Ij2F-n.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DWxmE9-2.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BXMGl-74.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-IojccGRD.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/feedWaiting-DLL1S0nn.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-P74nnP6o.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-3IlXp9wV.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/DocPdf-ByKqpJ8n.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-EkRYGQ32.js",
			"/assets/createServerFn-DQkAhuwQ.js",
			"/assets/auth-middleware-DhKuGcqk.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/MoneyAccountPick-CI61x9cn.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CRHdpFsK.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/StockDialogs-BXMGl-74.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/checkbox-lBy1ajyZ.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BH20AG1L.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-CklBifJh.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-B4yeeP82.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/tickets.functions-DnvbBfU7.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Dlsp44TX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DEkX6NOU.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-bpCHx27d.js", "/assets/StockDocList-Bb_EvXhO.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-yKJAFYeu.js", "/assets/PartyList-bBaPmV2Z.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-DZ5d0rrw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/tickets.functions-DnvbBfU7.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CYNj-_in.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DHzVGsAZ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-xGJpvG5m.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/AdminAccount-BFT-PlnI.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-D4QXnUns.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/downloads.functions-BeU2dXul.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-CNrjFxaa.js",
			"/assets/createServerFn-DQkAhuwQ.js",
			"/assets/auth-middleware-DhKuGcqk.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-B60f8F_5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-xaFV7DZE.js",
			"/assets/testers.functions-CYPR22Q_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-8EknaRyb.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-duXuFYfh.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BcAtAING.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BWa1r0RV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/textarea-Du9k3xa4.js",
			"/assets/support.functions-DEkX6NOU.js",
			"/assets/HelpParts-r_ROw00Y.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BDQ9nPSm.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DLvQdNU6.js",
			"/assets/manual._slug-CmkX1bvS.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Cm8kLCxe.js",
			"/assets/createServerFn-DQkAhuwQ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Cj9FIYDS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-Czz8JD5V.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DoIdojNT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BPVwo3Yz.js",
			"/assets/personal-DMq024VV.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DdJ5VIUJ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/AdminAccount-BFT-PlnI.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BnlfSlQV.js", "/assets/ManualFrame-DLvQdNU6.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DscX7suD.js", "/assets/AccountRegister-CN6Um6DH.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DbJ2h3U7.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/OriginalLink-BKHZYC3V.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CcDelgg3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Baowe-sC.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CTiDWoNw.js",
			"/assets/PartyHistory-C-_NClOv.js",
			"/assets/tabs-lsxjq0ER.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-UkDYPImr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bc4gxPjI.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CTiDWoNw.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BABj23FJ.js",
			"/assets/MoneyAccountPick-CI61x9cn.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Bb7MGpyI.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BXMGl-74.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bc4gxPjI.js",
			"/assets/switch-DhOH641s.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/badge-jQOpeHXa.js",
			"/assets/SideList-CTiDWoNw.js",
			"/assets/tabs-lsxjq0ER.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-B2Jj3cUl.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CH9Nxi2d.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Bc4gxPjI.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CTiDWoNw.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BABj23FJ.js",
			"/assets/MoneyAccountPick-CI61x9cn.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-lBy1ajyZ.js",
			"/assets/workorders-CiTNPjMt.js",
			"/assets/RepeatInvoice-DKSK5nFW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DnvbBfU7.js",
			"/assets/users.functions-CGdy_Dlz.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BqtvBLlg.js",
			"/assets/select-BWLDQrQk.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-CTiDWoNw.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-7P1zaVNy.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DEkX6NOU.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-Db2nU6xF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-_FtwBsDg.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/SideList-CTiDWoNw.js",
			"/assets/PartyHistory-C-_NClOv.js",
			"/assets/tabs-lsxjq0ER.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-fHt8b3H1.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/footers-C066M_rV.js",
			"/assets/tickets.functions-DnvbBfU7.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Cmujnxjt.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/input-BkbD7iS5.js",
			"/assets/skeleton-Cmcj3KCu.js",
			"/assets/AdminAccount-BFT-PlnI.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BPlBIlPP.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DYn4zo6H.js",
			"/assets/textarea-Du9k3xa4.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DEkX6NOU.js",
			"/assets/HelpParts-r_ROw00Y.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BQ1ERwTc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Cmcj3KCu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
