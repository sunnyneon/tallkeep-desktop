import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { getStripeMode, listAccounts, listWaitlist } from "./admin.functions-CIJmXF4V.mjs";
import { n as daysLeft, r as standing } from "./AdminAccount-B51SeuvB.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/admin-gKM3aZh5.js
var import_jsx_runtime = require_jsx_runtime();
function Overview() {
	const accounts = useQuery({
		queryKey: ["admin-accounts"],
		queryFn: () => listAccounts()
	});
	const waitlist = useQuery({
		queryKey: ["admin-waitlist"],
		queryFn: () => listWaitlist()
	});
	const stripe = useQuery({
		queryKey: ["admin-stripe-mode"],
		queryFn: () => getStripeMode()
	});
	const customers = (accounts.data ?? []).filter((a) => !a.is_platform);
	const trialing = customers.filter((a) => a.status === "trial" && (daysLeft(a) ?? 1) > 0);
	const ending = trialing.filter((a) => (daysLeft(a) ?? 99) <= 7).sort((a, b) => (daysLeft(a) ?? 0) - (daysLeft(b) ?? 0));
	const paying = customers.filter((a) => a.status === "active" || a.status === "past_due");
	const newest = [...customers].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 8);
	const joined = (waitlist.data?.entries ?? []).filter((e) => e.kind === "waitlist").length;
	const aiCost = (accounts.data ?? []).reduce((s, a) => s + a.ai_cost_month, 0);
	const tiles = [
		[
			"Customers",
			customers.length,
			"/admin/customers"
		],
		[
			"On free trial",
			trialing.length,
			"/admin/customers"
		],
		[
			"Paying",
			paying.length,
			"/admin/customers"
		],
		[
			"On the waitlist",
			waitlist.data?.ready ? joined : "Not linked",
			"/admin/waitlist"
		],
		[
			"AI cost this month",
			fmtMoney(aiCost),
			"/admin/customers"
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Overview",
			text: "How Tallkeep is doing today."
		}),
		stripe.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: `rounded-xl border px-4 py-2 text-sm ${stripe.data.mode === "live" ? "border-emerald-300 bg-emerald-50 text-emerald-900" : "border-amber-300 bg-amber-50 text-amber-900"}`,
			children: [stripe.data.mode === "live" ? "Payments: LIVE. The Buy page takes real cards." : stripe.data.mode === "test" ? "Payments: TEST mode. The Buy page only takes Stripe test cards; nobody can really pay yet." : stripe.data.mode === "missing" ? "Payments: not set up (no Stripe key)." : "Payments: the Stripe key isn't a normal secret key. Check it.", !stripe.data.connect && " · Customers' \"Pay now\" card payments: not set up."]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
			children: tiles.map(([label, value, url]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: url,
				className: "rounded-2xl border bg-card p-4 hover:bg-muted/50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-2xl font-semibold",
					children: accounts.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-7 w-12" }) : value
				})]
			}, label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
				title: "Trials ending in the next 7 days",
				empty: "No trials end this week.",
				rows: ending.map((a) => ({
					id: a.id,
					name: a.name,
					sub: a.owner_email,
					right: standing(a).text
				}))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
				title: "Newest sign-ups",
				empty: "No customers yet.",
				rows: newest.map((a) => ({
					id: a.id,
					name: a.name,
					sub: a.owner_email,
					right: fmtDate(a.created_at)
				}))
			})]
		})
	] });
}
function List({ title, empty, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "border-b p-4 font-display text-lg font-semibold",
			children: title
		}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-4 text-sm text-muted-foreground",
			children: empty
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center justify-between gap-3 border-b p-4 last:border-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/admin/customers/$id",
					params: { id: r.id },
					className: "font-medium text-primary hover:underline",
					children: r.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "truncate text-xs text-muted-foreground",
					children: r.sub
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 text-sm",
				children: r.right
			})]
		}, r.id)) })]
	});
}
//#endregion
export { Overview as component };
