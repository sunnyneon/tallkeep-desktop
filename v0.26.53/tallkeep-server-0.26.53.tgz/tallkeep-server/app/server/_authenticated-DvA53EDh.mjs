import { i as __toESM } from "./_runtime.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "./_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney } from "./_ssr/format-CgElbAz-.mjs";
import { n as db, r as fetchAll } from "./_ssr/db-zN6XRCX9.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { t as useQuery } from "./_libs/tanstack__react-query.mjs";
import { t as activeCompanyId } from "./_ssr/company-8PUivc6B.mjs";
import { s as useFeatures } from "./_ssr/addons-B1ybLHtC.mjs";
import { S as useNavigate, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./_authenticated-o2x__8Qn.mjs";
import { f as today, m as useTotals, p as useAccounts } from "./_ssr/accounting-C0Wyxijv.mjs";
import { n as PageHeader, t as Page } from "./_ssr/PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./_ssr/button-BRN_qfHO.mjs";
import { r as aiStatus } from "./_ssr/ai.functions-DMTP2vs_.mjs";
import { p as queueShoebox } from "./_ssr/shoebox-BQiOR5i1.mjs";
import { f as thisMonth, h as worth, i as amountIn, l as monthRange, m as useHoldings, p as useBudgets } from "./_ssr/personal-DEJt584t.mjs";
import { $ as PackageCheck, Bt as FileCheckCorner, Cn as Boxes, Dt as HardHat, Fn as BadgeDollarSign, H as Percent, I as ReceiptText, In as ArrowRight, It as FileText, Jt as CreditCard, L as Receipt, Lt as FileSpreadsheet, M as Scale, Nn as Banknote, On as Bitcoin, Ot as HandCoins, P as Repeat, R as Printer, Rt as FilePlusCorner, S as Smartphone, T as Settings, Tn as BookOpen, Tt as HousePlus, V as PiggyBank, W as PenLine, Xt as Coins, Y as Package, _t as LayoutDashboard, a as Wallet, bn as CalendarCheck, en as ClipboardList, f as Undo2, fn as ChartLine, gt as LifeBuoy, h as TrendingUp, k as ScrollText, kt as Hammer, mn as Camera, n as X, p as Truck, pn as ChartColumn, pt as ListChecks, r as Wrench, s as Users, t as Zap, tn as ClipboardCheck, u as Upload, un as Check, v as Target, vn as CalendarDays, vt as Landmark, xn as Building2, xt as Inbox, yn as CalendarClock, yt as KeyRound, zn as ArrowDown } from "./_libs/lucide-react.mjs";
import { t as GROUP_COLOR } from "./_ssr/nav-BIrQ7OjK.mjs";
import { r as canSeeGroup, s as useAccess } from "./_ssr/access-O0XT9AMT.mjs";
import { l as useReminders, n as daysBetween } from "./_ssr/reminders-D84HQn0G.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/_authenticated-DvA53EDh.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* The Shoebox on Home: drop papers (or choose them, or take a photo) and they go to the Shoebox,
* which reads and files them. Shows how many are waiting for you.
*/
function HomeShoebox() {
	const navigate = useNavigate();
	const pick = (0, import_react.useRef)(null);
	const photo = (0, import_react.useRef)(null);
	const [over, setOver] = (0, import_react.useState)(false);
	const waiting = useQuery({
		queryKey: ["shoebox-waiting"],
		queryFn: async () => {
			const { count } = await db.from("shoebox_items").select("id", {
				count: "exact",
				head: true
			}).eq("status", "needs_you");
			return count ?? 0;
		}
	});
	const send = (files) => {
		if (!files.length) return;
		queueShoebox(files);
		navigate({ to: "/shoebox" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		onDragOver: (e) => {
			if ([...e.dataTransfer.types].includes("Files")) {
				e.preventDefault();
				setOver(true);
			}
		},
		onDragLeave: () => setOver(false),
		onDrop: (e) => {
			e.preventDefault();
			setOver(false);
			send([...e.dataTransfer.files]);
		},
		className: cn("flex flex-col items-center gap-4 rounded-2xl border-2 border-dashed bg-card p-4 transition-colors sm:flex-row", over ? "border-[#F28C38] bg-[#F28C38]/10" : "border-[#F28C38]/40"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/shoebox.png",
				alt: "",
				className: "h-28 w-28 shrink-0 object-contain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 text-center sm:text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-semibold",
						children: "Shoebox"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Drop bank and card statements, receipts, bills, checks and loan statements here. Tallkeep reads them and puts each one where it belongs."
					}),
					!!waiting.data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/shoebox",
						className: "mt-1 inline-block text-sm font-medium text-[#C2410C] underline",
						children: waiting.data === 1 ? "1 paper needs you" : `${waiting.data} papers need you`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 flex-wrap justify-center gap-2 sm:flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => pick.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }), " Choose files"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => photo.current?.click(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }), " Take a photo"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: pick,
				type: "file",
				multiple: true,
				accept: ".pdf,.csv,.ofx,.qfx,.qbo,image/*",
				className: "hidden",
				onChange: (e) => send([...e.target.files ?? []])
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: photo,
				type: "file",
				accept: "image/*",
				capture: "environment",
				className: "hidden",
				onChange: (e) => send([...e.target.files ?? []])
			})
		]
	});
}
/**
* "Get started" on Home: a few first steps for a new company (or personal books), ticked off by
* themselves as the work gets done. Hidden when all are done, or when someone closes it.
*/
var tbl = (t) => db.from(t);
/** Is an AI ready to read statements (the Shoebox needs one)? */
async function aiReady() {
	try {
		const a = await aiStatus();
		return a.hasKey || !!a.sharedFrom || a.provider === "vooska" && a.builtInReady;
	} catch {
		return true;
	}
}
var AI_STEP = (done) => ({
	key: "ai",
	label: "Turn on the AI that reads your statements",
	text: "The Shoebox needs it. Free to start: get a Google Gemini key, paste it in AI & Usage, Save.",
	to: "/ai",
	done
});
/** How many rows a table has for the company being worked in (0 when it can't be read). */
async function count(table, where) {
	let q = tbl(table).select("*", {
		count: "exact",
		head: true
	});
	if (where) q = where(q);
	const { count: n, error } = await q;
	return error ? 0 : n ?? 0;
}
function SetupChecklist() {
	const { data: features } = useFeatures();
	const [company, setCompany] = (0, import_react.useState)(null);
	const [hidden, setHidden] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		activeCompanyId().then((c) => {
			setCompany(c);
			try {
				setHidden(localStorage.getItem(`setup-hidden:${c}`) === "1");
			} catch {
				setHidden(false);
			}
		});
	}, []);
	const personal = !!features?.includes("personal");
	const has = (f) => !!features?.includes(f);
	const q = useQuery({
		queryKey: [
			"setup-steps",
			company,
			personal,
			features?.join(",")
		],
		enabled: !!company && !!features && !hidden,
		staleTime: 6e4,
		queryFn: async () => {
			if (personal) {
				const [lines, budgets, bills, people, ai] = await Promise.all([
					count("bank_transactions"),
					count("budgets"),
					count("money_reminders"),
					count("household_members"),
					aiReady()
				]);
				return [
					AI_STEP(ai),
					{
						key: "lines",
						label: "Bring in your bank and card lines",
						text: "Drop a statement in the Shoebox, or upload it in Review & Reconcile.",
						to: "/banking",
						done: lines > 0
					},
					{
						key: "bills",
						label: "Add your bills and subscriptions",
						text: "Rent, phone, streaming… Tallkeep reminds you before they're due.",
						to: "/subscriptions",
						done: bills > 0
					},
					{
						key: "budget",
						label: "Set a monthly budget",
						text: "How much for food, home, car and the rest.",
						to: "/budget",
						done: budgets > 0
					},
					{
						key: "people",
						label: "Add who's in your household",
						text: "So each account shows whose it is.",
						to: "/household",
						done: people > 0
					}
				];
			}
			const [settings, products, customers, sales, lines, properties, ai] = await Promise.all([
				tbl("company_settings").select("address,phone,email").maybeSingle(),
				has("inventory") || has("sales") ? count("products") : Promise.resolve(-1),
				has("sales") ? count("customers") : Promise.resolve(-1),
				has("sales") ? count("sales_orders") : Promise.resolve(-1),
				has("accounting") ? count("bank_transactions") : Promise.resolve(-1),
				has("real_estate") ? count("properties") : Promise.resolve(-1),
				aiReady()
			]);
			const s = settings?.data ?? {};
			const steps = [{
				key: "company",
				label: "Add your company's address and phone",
				text: "They print on your quotes and invoices.",
				to: "/settings",
				hash: "company",
				done: !!(s.address || s.phone)
			}];
			if (products >= 0) steps.push({
				key: "products",
				label: "Add your products and services",
				text: "Type them in, or import from QuickBooks or inFlow (Options → Import).",
				to: "/products",
				done: products > 0
			});
			if (customers >= 0) steps.push({
				key: "customers",
				label: "Add your customers",
				text: "Or bring them over with the import.",
				to: "/customers",
				done: customers > 0
			});
			if (sales >= 0) steps.push({
				key: "sales",
				label: "Make your first quote or invoice",
				text: "Email it as a PDF straight from Tallkeep.",
				to: "/new-invoice",
				done: sales > 0
			});
			if (properties >= 0) steps.push({
				key: "properties",
				label: "Add your properties",
				text: "Then the leases and tenants; rent is charged by itself.",
				to: "/properties",
				done: properties > 0
			});
			if (lines >= 0) steps.push(AI_STEP(ai));
			if (lines >= 0) steps.push({
				key: "bank",
				label: "Bring in your bank lines",
				text: "Upload a statement in Review & Reconcile, or drop it in the Shoebox.",
				to: "/banking",
				done: lines > 0
			});
			return steps;
		}
	});
	if (hidden || !q.data) return null;
	const steps = q.data;
	const done = steps.filter((s) => s.done).length;
	if (done === steps.length) return null;
	const close = () => {
		try {
			localStorage.setItem(`setup-hidden:${company}`, "1");
		} catch {}
		setHidden(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Get started"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						done,
						" of ",
						steps.length,
						" done. Each step ticks itself off when you do it."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: close,
					className: "rounded-md p-1 text-muted-foreground hover:bg-muted",
					"aria-label": "Hide these steps",
					title: "Hide these steps",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-1.5 overflow-hidden rounded-full bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full rounded-full bg-[#0E7C74] transition-all",
					style: { width: `${done / steps.length * 100}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: s.to,
					...s.hash ? { hash: s.hash } : {},
					className: cn("flex gap-3 rounded-xl border p-3 text-sm transition-shadow hover:shadow-md", s.done && "bg-muted/40"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs font-semibold", s.done ? "border-transparent bg-[#0E7C74] text-white" : "text-muted-foreground"),
						children: s.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : i + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("block font-medium", s.done && "text-muted-foreground line-through"),
						children: s.label
					}), !s.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-muted-foreground",
						children: s.text
					})] })]
				}) }, s.key))
			})
		]
	});
}
/**
* Personal books, at the top of Home: net worth, this month's spending against the budget, bills
* due this week, and lines waiting in Review & Reconcile. Each one opens its page.
*/
function PersonalSummary() {
	const { data: accounts } = useAccounts();
	const { data: all } = useTotals(null, today());
	const m = monthRange(thisMonth());
	const { data: month } = useTotals(m.from, m.to);
	const { data: holdings } = useHoldings();
	const { data: budgets } = useBudgets();
	const { data: reminders } = useReminders();
	const waiting = useQuery({
		queryKey: ["bank-waiting-count"],
		queryFn: async () => {
			const { count } = await db.from("bank_transactions").select("id", {
				count: "exact",
				head: true
			}).eq("status", "new");
			return count ?? 0;
		}
	});
	if (!accounts) return null;
	const net = all ? worth(accounts, all, holdings ?? []).net : null;
	const spendCats = accounts.filter((a) => a.type === "expense");
	const spent = spendCats.reduce((s, a) => s + amountIn(a, month), 0);
	const planned = spendCats.reduce((s, a) => s + ((budgets ?? []).find((b) => b.account_id === a.id)?.amount ?? 0), 0);
	const now = today();
	const due = (reminders ?? []).filter((r) => r.status === "active" && daysBetween(now, r.next_date) <= 7);
	const late = due.filter((r) => r.next_date < now).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/net-worth",
				label: "Net worth",
				value: net == null ? "…" : fmtMoney(net),
				main: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/budget",
				label: "Spent this month",
				value: fmtMoney(spent),
				note: planned ? `${planned - spent >= 0 ? `${fmtMoney(planned - spent)} left` : `${fmtMoney(spent - planned)} over`} of ${fmtMoney(planned)}` : "No budget yet",
				bad: planned > 0 && spent > planned
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/subscriptions",
				label: "Bills this week",
				value: String(due.length),
				note: late ? `${late} late` : due.length ? fmtMoney(due.reduce((s, r) => s + (r.amount ?? 0), 0)) : "Nothing due",
				bad: late > 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				to: "/banking",
				label: "Waiting in Review & Reconcile",
				value: String(waiting.data ?? 0),
				note: waiting.data ? "Lines to record" : "All recorded",
				bad: !!waiting.data
			})
		]
	});
}
function Tile({ to, label, value, note, bad, main }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("rounded-2xl border p-4 transition-shadow hover:shadow-md", main ? "border-transparent bg-[#0E7C74] text-white" : "bg-card"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs", main ? "text-white/80" : "text-muted-foreground"),
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-2xl font-semibold tabular-nums", bad && "text-amber-600"),
				children: value
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs", main ? "text-white/80" : bad ? "text-amber-700" : "text-muted-foreground"),
				children: note
			})
		]
	});
}
/** The jobs people do from a phone, biggest first. */
var JOBS = [
	{
		label: "New quote",
		to: "/new-quote",
		icon: FilePlusCorner,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "New invoice",
		to: "/new-invoice",
		icon: Receipt,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Snap a receipt",
		to: "/shoebox",
		icon: Camera,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Find a product",
		to: "/products",
		icon: Package,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Check stock",
		to: "/stock",
		icon: Boxes,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Customers",
		to: "/customers",
		icon: Users,
		group: "Sales",
		feature: "sales"
	}
];
/**
* Home on a phone: the quick jobs as big buttons, what customers owe, and the latest sales.
* Shown only on small screens; the full Home follows underneath.
*/
function PhoneToday({ userId }) {
	const { data: access } = useAccess(userId);
	const { data: features } = useFeatures();
	const jobs = JOBS.filter((j) => canSeeGroup(access, j.group) && (!j.feature || !features || features.includes(j.feature)));
	const sells = !!features?.includes("sales") && canSeeGroup(access, "Sales");
	const { data: sos } = useQuery({
		queryKey: ["home", "phone-sales"],
		enabled: sells,
		queryFn: () => fetchAll("sales_orders", "id,number,status,total,balance,customer_name,order_date,invoice_date")
	});
	const glance = (0, import_react.useMemo)(() => {
		const list = (sos ?? []).filter((o) => !o.number.startsWith("RMA-"));
		const owed = list.filter((o) => [
			"open",
			"invoiced",
			"paid",
			"completed"
		].includes(o.status) && Number(o.balance) > .005);
		const quotes = list.filter((o) => o.status === "quote");
		const latest = [...list].sort((a, b) => (b.invoice_date ?? b.order_date).localeCompare(a.invoice_date ?? a.order_date)).slice(0, 5);
		return {
			owed: owed.reduce((s, o) => s + Number(o.balance), 0),
			owedCount: owed.length,
			quotes: quotes.length,
			quotesValue: quotes.reduce((s, o) => s + Number(o.total), 0),
			latest
		};
	}, [sos]);
	if (!features) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 md:hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddToPhone, {}),
			jobs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 px-1 text-sm font-semibold",
					children: "Quick jobs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: jobs.map((j) => {
						const color = GROUP_COLOR[j.group].main;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: j.to,
							search: j.search,
							className: "flex min-h-16 items-center gap-3 rounded-xl border bg-background px-3 py-3 text-sm font-semibold active:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl",
								style: {
									backgroundColor: `${color}1f`,
									color
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(j.icon, { className: "h-5 w-5" })
							}), j.label]
						}, j.label);
					})
				})]
			}),
			sells && sos && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/sales-list",
					className: "rounded-2xl border bg-card p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-1.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "h-3.5 w-3.5" }), " Customers owe"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-xl font-bold tabular-nums ${glance.owed > 0 ? "text-amber-700 dark:text-amber-400" : ""}`,
							children: fmtMoney(glance.owed)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								glance.owedCount,
								" unpaid ",
								glance.owedCount === 1 ? "invoice" : "invoices"
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/sales-list",
					className: "rounded-2xl border bg-card p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-1.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilePlusCorner, { className: "h-3.5 w-3.5" }), " Open quotes"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xl font-bold tabular-nums",
							children: glance.quotes
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: ["worth ", fmtMoney(glance.quotesValue)]
						})
					]
				})]
			}), glance.latest.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-4 pt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Latest sales"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sales-list",
						className: "text-xs font-medium text-primary",
						children: "See all"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y",
					children: glance.latest.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sales/$id",
						params: { id: o.id },
						className: "flex items-center gap-3 px-4 py-3 active:bg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm font-medium",
								children: o.customer_name ?? "No customer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									o.number,
									" · ",
									statusWord(o)
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tabular-nums",
							children: fmtMoney(Number(o.total))
						})]
					}) }, o.id))
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 pt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground",
				children: "Everything else"
			})
		]
	});
}
function statusWord(o) {
	if (o.status === "quote") return "Quote";
	if (o.status === "cancelled") return "Cancelled";
	if (Number(o.balance) > .005 && [
		"invoiced",
		"completed",
		"paid"
	].includes(o.status)) return "Not paid yet";
	if (o.status === "open") return "Order";
	return "Paid";
}
var HIDE_KEY = "tk-hide-add-to-phone";
/** "Put Tallkeep on your home screen", until it's there or they close the card. */
function AddToPhone() {
	const [hidden, setHidden] = (0, import_react.useState)(true);
	const [install, setInstall] = (0, import_react.useState)(null);
	const [ios, setIos] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const standalone = window.matchMedia?.("(display-mode: standalone)").matches || navigator.standalone === true;
		let closed = false;
		try {
			closed = localStorage.getItem(HIDE_KEY) === "1";
		} catch {}
		setIos(/iphone|ipad|ipod/i.test(navigator.userAgent));
		setHidden(standalone || closed);
		const grab = (e) => {
			e.preventDefault();
			setInstall(e);
		};
		window.addEventListener("beforeinstallprompt", grab);
		return () => window.removeEventListener("beforeinstallprompt", grab);
	}, []);
	if (hidden) return null;
	const close = () => {
		setHidden(true);
		try {
			localStorage.setItem(HIDE_KEY, "1");
		} catch {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative rounded-2xl border border-primary/30 bg-primary/5 p-4 pr-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: close,
				"aria-label": "Close this tip",
				className: "absolute right-2 top-2 rounded-md p-1.5 text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "h-4 w-4 text-primary" }), " Put Tallkeep on your home screen"]
			}),
			install ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "It opens like an app, full screen, with one tap."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => {
					install.prompt();
					setInstall(null);
				},
				className: "mt-3 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
				children: "Add Tallkeep to my home screen"
			})] }) : ios ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-2 list-decimal space-y-1 pl-5 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In Safari, tap the Share button (the square with an arrow)." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Tap ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Add to Home Screen" }),
					", then ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Add" }),
					"."
				] })]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-2 list-decimal space-y-1 pl-5 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In Chrome, tap the ⋮ menu at the top right." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					"Tap ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Add to Home screen" }),
					" (or ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Install app" }),
					")."
				] })]
			})
		]
	});
}
var MY_MONEY = [
	{
		label: "Budget",
		to: "/budget",
		icon: Target,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Net Worth",
		to: "/net-worth",
		icon: TrendingUp,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Investments",
		to: "/investments",
		icon: ChartLine,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Bills, Rent & Subscriptions",
		to: "/subscriptions",
		icon: CalendarClock,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Mortgage & Loans",
		to: "/loans",
		icon: HousePlus,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Monthly Review",
		to: "/monthly-review",
		icon: ListChecks,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Crypto Tax",
		to: "/crypto-tax",
		icon: Bitcoin,
		group: "Accounting",
		feature: "crypto_tax"
	},
	{
		label: "Shoebox",
		to: "/shoebox",
		icon: Inbox,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Check Register",
		to: "/register",
		icon: BookOpen,
		group: "Accounting",
		feature: "personal"
	},
	{
		label: "Credit Card Register",
		to: "/card-register",
		icon: CreditCard,
		group: "Accounting",
		feature: "personal"
	}
];
var VENDORS = [
	{
		label: "Purchase Orders",
		to: "/purchase-orders",
		icon: ClipboardList,
		group: "Purchasing",
		feature: "purchasing"
	},
	{
		label: "Receive Stock",
		to: "/purchase-orders",
		icon: PackageCheck,
		group: "Purchasing",
		feature: "purchasing"
	},
	{
		label: "Enter Bills",
		to: "/bills/$id",
		params: { id: "new" },
		search: {},
		icon: ReceiptText,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Pay Bills",
		to: "/pay-bills",
		icon: Wallet,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	}
];
var VENDORS_MORE = [
	{
		label: "Vendors",
		to: "/vendors",
		icon: Truck,
		group: "Purchasing",
		feature: "purchasing",
		hideWith: "personal"
	},
	{
		label: "Expense Paid Now",
		to: "/bills/$id",
		params: { id: "new" },
		search: { paid: 1 },
		icon: Receipt,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Technician Pay",
		to: "/tech-pay",
		icon: HardHat,
		group: "Purchasing",
		feature: "tech_pay"
	},
	{
		label: "Pay Sales Tax",
		to: "/sales-tax",
		icon: Percent,
		group: "Accounting",
		feature: "sales"
	},
	{
		label: "Vendor Credits",
		to: "/refunds",
		icon: Undo2,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	}
];
var CUSTOMERS = [
	{
		label: "Quotes",
		to: "/new-quote",
		icon: FilePlusCorner,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Invoices",
		to: "/new-invoice",
		icon: Receipt,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Receive Payments",
		to: "/sales-list",
		icon: HandCoins,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	}
];
var CUSTOMERS_MORE = [
	{
		label: "Customers",
		to: "/customers",
		icon: Users,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Sales List",
		to: "/sales-list",
		icon: FileText,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Sales Receipt",
		to: "/sales-receipt",
		icon: BadgeDollarSign,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Statements",
		to: "/statements",
		icon: FileSpreadsheet,
		group: "Sales",
		feature: "sales"
	},
	{
		label: "Refunds & Credits",
		to: "/refunds",
		icon: Undo2,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Tickets",
		to: "/tickets",
		icon: LifeBuoy,
		group: "Sales",
		feature: "support"
	},
	{
		label: "Website Tickets",
		to: "/website-tickets",
		icon: LifeBuoy,
		group: "Sales",
		feature: "tickets"
	}
];
var INVENTORY = [
	{
		label: "Products",
		to: "/products",
		icon: Package,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Current Stock",
		to: "/stock",
		icon: Boxes,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Count Sheet",
		to: "/count",
		icon: ClipboardCheck,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Adjust Stock",
		to: "/adjust",
		icon: Wrench,
		group: "Inventory",
		feature: "inventory"
	},
	{
		label: "Work Orders",
		to: "/work-orders",
		search: {},
		icon: Hammer,
		group: "Inventory",
		feature: "work_orders"
	}
];
var PROPERTIES = [
	{
		label: "Properties",
		to: "/properties",
		icon: Building2,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Leases & Tenants",
		to: "/leases",
		search: {},
		icon: KeyRound,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Charge & Collect Rent",
		to: "/rent",
		icon: HandCoins,
		group: "Properties",
		feature: "real_estate"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	}
];
var PROPERTIES_MORE = [{
	label: "Rent Roll",
	to: "/rent-roll",
	icon: ScrollText,
	group: "Properties",
	feature: "real_estate"
}];
var BANKING = [
	{
		label: "Fast Entry",
		to: "/fast-entry",
		icon: Zap,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Receipts",
		to: "/receipts",
		icon: Camera,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Write Checks",
		to: "/checks/$id",
		params: { id: "new" },
		search: {},
		icon: PenLine,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Credit Cards",
		to: "/credit-cards",
		search: {},
		icon: CreditCard,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Print Checks",
		to: "/print-checks",
		search: {},
		icon: Printer,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Record Deposits",
		to: "/deposits",
		icon: PiggyBank,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Transfers",
		to: "/bank-transfers",
		icon: Repeat,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Recurring",
		to: "/recurring",
		search: {},
		icon: CalendarClock,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Review & Reconcile",
		to: "/banking",
		icon: Banknote,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Checks & Payments",
		to: "/checks",
		icon: BookOpen,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	}
];
var COMPANY = [
	{
		label: "Calendar",
		to: "/calendar",
		icon: CalendarDays,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Chart of Accounts",
		to: "/accounts",
		icon: Landmark,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Journal Entries",
		to: "/journal",
		search: {},
		icon: BookOpen,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Financial Reports",
		to: "/financials",
		search: {},
		icon: Scale,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Payroll",
		to: "/payroll",
		icon: Coins,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "1099 Forms",
		to: "/forms-1099",
		icon: FileCheckCorner,
		group: "Accounting",
		feature: "accounting",
		hideWith: "personal"
	},
	{
		label: "Year-End & CPA",
		to: "/year-end",
		icon: CalendarCheck,
		group: "Accounting",
		feature: "accounting"
	},
	{
		label: "Reports",
		to: "/reports",
		icon: ChartColumn,
		group: "Reports",
		hideWith: "personal"
	},
	{
		label: "Overview",
		to: "/overview",
		icon: LayoutDashboard,
		group: "General",
		hideWith: "personal"
	},
	{
		label: "Settings",
		to: "/settings",
		icon: Settings,
		group: "Options"
	}
];
function Home() {
	const { user } = Route.useRouteContext();
	const { data: access } = useAccess(user.id);
	const { data: features } = useFeatures();
	const show = (t) => canSeeGroup(access, t.group) && (!t.feature || !features || features.includes(t.feature)) && !(t.hideWith && features?.includes(t.hideWith));
	const pick = (l) => l.filter(show);
	const sections = [
		{
			title: "Purchasing",
			color: GROUP_COLOR.Purchasing.main,
			flow: pick(VENDORS),
			more: pick(VENDORS_MORE)
		},
		{
			title: "Sales",
			color: GROUP_COLOR.Sales.main,
			flow: pick(CUSTOMERS),
			more: pick(CUSTOMERS_MORE)
		},
		{
			title: "Properties",
			color: GROUP_COLOR.Properties.main,
			flow: pick(PROPERTIES),
			more: pick(PROPERTIES_MORE)
		},
		{
			title: "Inventory",
			color: GROUP_COLOR.Inventory.main,
			flow: [],
			more: pick(INVENTORY)
		}
	].filter((s) => s.title === "Properties" || s.title === "Sales" ? [...s.flow, ...s.more].some((t) => t.group === s.title) : s.flow.length + s.more.length > 0).map((s) => s.title === "Purchasing" && features?.includes("personal") ? {
		...s,
		title: "Bills"
	} : s);
	const personal = !!features?.includes("personal");
	const myMoney = pick(MY_MONEY).filter((t) => t.to !== "/shoebox");
	const banking = pick(BANKING);
	const company = pick(COMPANY);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Home",
			text: personal ? "Your money at a glance. Drop papers in the Shoebox; open anything below." : "Where to go for each job, in the order the work flows. Numbers and to-dos are on Overview."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneToday, { userId: user.id }),
		personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonalSummary, {}),
		access?.isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetupChecklist, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					features?.includes("accounting") && canSeeGroup(access, "Accounting") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeShoebox, {}),
					myMoney.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "My Money",
						color: "#0E7C74",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2 sm:grid-cols-6",
							children: myMoney.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
								t,
								color: "#0E7C74"
							}, t.label))
						})
					}),
					sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						title: s.title,
						color: s.color,
						children: [s.flow.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flow, {
							tiles: s.flow,
							color: s.color
						}), s.more.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid grid-cols-3 gap-2 sm:grid-cols-5 ${s.flow.length ? "mt-3 border-t pt-3" : ""}`,
							children: s.more.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
								t,
								color: s.color
							}, t.label))
						})]
					}, s.title))
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [banking.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Banking",
					color: GROUP_COLOR.Accounting.main,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3",
						children: banking.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
							t,
							color: GROUP_COLOR.Accounting.main
						}, t.label))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					title: "Company",
					color: GROUP_COLOR.Options.main,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-3",
						children: company.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
							t,
							color: GROUP_COLOR[t.group].main
						}, t.label))
					})
				})]
			})]
		})
	] });
}
function Panel({ title, color, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 inline-block rounded-full px-3 py-0.5 text-xs font-bold uppercase tracking-wider text-white",
			style: { backgroundColor: color },
			children: title
		}), children]
	});
}
/** Steps in order, with arrows between them (down the page on phones). */
function Flow({ tiles, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col items-stretch gap-1 sm:flex-row sm:items-center",
		children: tiles.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "sm:flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TileLink, {
				t,
				color
			})
		}), i < tiles.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "hidden h-5 w-5 shrink-0 text-muted-foreground/60 sm:block" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "mx-auto h-4 w-4 text-muted-foreground/60 sm:hidden" })] })] }, t.label))
	});
}
function TileLink({ t, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: t.to,
		params: t.params,
		search: t.search,
		className: "flex flex-col items-center gap-1.5 rounded-xl p-2 text-center text-xs font-medium transition-colors hover:bg-muted/60 sm:text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-11 w-11 place-items-center rounded-xl",
			style: {
				backgroundColor: `${color}1f`,
				color
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(t.icon, { className: "h-6 w-6" })
		}), t.label]
	});
}
//#endregion
export { Home as component };
