import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AccountRegister } from "./AccountRegister-DD66k7Xx.mjs";
import { t as Route } from "./card-register-plV1r_1C.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/card-register-C_rBv5xz.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { account } = Route.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRegister, {
		accountId: account ?? null,
		kind: "credit_card",
		onAccount: (id) => void navigate({
			to: "/card-register",
			search: { account: id },
			replace: !account
		})
	});
}
//#endregion
export { Page as component };
