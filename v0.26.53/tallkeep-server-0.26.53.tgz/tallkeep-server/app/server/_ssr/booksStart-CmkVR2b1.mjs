import { n as db } from "./db-zN6XRCX9.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/booksStart-CmkVR2b1.js
/**
* The day the books start, and whether a sales document is in the books. One rule for the books,
* Who owes us, customer balances and the lists (D16): an invoice dated before the books start
* isn't posted, so it isn't counted as owed either. Money still owed from before then goes in as
* opening balances. With no start day set, everything counts (the banner asks for the day).
*/
async function fetchBooksStart() {
	const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
	const d = data?.books_start_date ?? null;
	return d ? d.slice(0, 10) : null;
}
function useBooksStart() {
	return useQuery({
		queryKey: ["books-start"],
		queryFn: fetchBooksStart,
		staleTime: 6e4
	});
}
/** The date a sales document counts on: its invoice date, else its order date. */
var docDay = (o) => (o.invoice_date ?? o.order_date ?? "").slice(0, 10);
function inBooks(o, start) {
	return !start || docDay(o) >= start;
}
//#endregion
export { inBooks as n, useBooksStart as r, fetchBooksStart as t };
