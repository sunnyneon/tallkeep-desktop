import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-CQ9Lt_6Z.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bankfeed.functions-DOJlOLu5.js
var listBankLinks = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("52743db9114c316defd0de80423075d8f3ce16d64637a0cab7bda678b037e7ee"));
var connectBank = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const code = String(d?.code ?? "").trim();
	if (!code) throw new Error("Paste the setup code from SimpleFIN.");
	if (code.length > 2e3) throw new Error("That code is too long. Copy just the setup code.");
	return { code };
}).handler(createSsrRpc("d4666967c9fdc9d7c8c16b3f6ce6b24652dd0a13c9bb7f80369329f45e85ac53"));
var setBankLinkAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which account?");
	if (d.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.startDate)) throw new Error("Pick a start date.");
	return {
		id: d.id,
		accountId: d.accountId || null,
		startDate: d.startDate || null
	};
}).handler(createSsrRpc("d45861089fecb1b6200c8e8e07147efcd9537a6f08a01f71fd821a171136d514"));
var pullBankNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("1ddc9bf46ce82113f0b8564806dc316e90df9282ae9ed81c6724e024d1d0757a"));
var removeBankLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which connection?");
	return { id: d.id };
}).handler(createSsrRpc("d9c39b8ea424292e98f3177e30e500e9266a64f5d23e5d8ca85b07aafc9b746d"));
//#endregion
export { setBankLinkAccount as a, removeBankLink as i, listBankLinks as n, pullBankNow as r, connectBank as t };
