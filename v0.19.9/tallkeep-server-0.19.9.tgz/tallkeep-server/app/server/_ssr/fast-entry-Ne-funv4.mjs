import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { a as ruleFor, i as payeeKey, t as anyDate } from "./bankfile-C7N990Vr.mjs";
import { R as Plus, g as Trash2, sn as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as payFromAccounts } from "./money-uSYuy5S6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/fast-entry-Ne-funv4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COLS = {
	out: [
		{
			k: "date",
			label: "Date",
			w: "8.5rem"
		},
		{
			k: "no",
			label: "Check #",
			w: "5.5rem"
		},
		{
			k: "name",
			label: "Paid to",
			w: "minmax(9rem,1.2fr)",
			list: "fe-vendors"
		},
		{
			k: "account",
			label: "Account (what for)",
			w: "minmax(10rem,1.4fr)",
			list: "fe-accounts"
		},
		{
			k: "memo",
			label: "Memo",
			w: "minmax(7rem,1fr)"
		},
		{
			k: "amount",
			label: "Amount",
			w: "7rem"
		}
	],
	bill: [
		{
			k: "date",
			label: "Bill date",
			w: "8.5rem"
		},
		{
			k: "name",
			label: "Vendor",
			w: "minmax(9rem,1.2fr)",
			list: "fe-vendors"
		},
		{
			k: "no",
			label: "Bill #",
			w: "6rem"
		},
		{
			k: "due",
			label: "Due",
			w: "8.5rem"
		},
		{
			k: "account",
			label: "Account (what for)",
			w: "minmax(10rem,1.4fr)",
			list: "fe-accounts"
		},
		{
			k: "memo",
			label: "Memo",
			w: "minmax(7rem,1fr)"
		},
		{
			k: "amount",
			label: "Amount",
			w: "7rem"
		}
	],
	in: [
		{
			k: "date",
			label: "Date",
			w: "8.5rem"
		},
		{
			k: "name",
			label: "Received from",
			w: "minmax(9rem,1.2fr)",
			list: "fe-customers"
		},
		{
			k: "account",
			label: "Account (what for)",
			w: "minmax(10rem,1.4fr)",
			list: "fe-accounts"
		},
		{
			k: "memo",
			label: "Memo",
			w: "minmax(7rem,1fr)"
		},
		{
			k: "amount",
			label: "Amount",
			w: "7rem"
		}
	]
};
var TITLE = {
	out: "Payments & checks",
	bill: "Bills",
	in: "Money in (deposits)"
};
var nextKey = 1;
var blank = (date = today()) => ({
	key: nextKey++,
	date,
	no: "",
	name: "",
	account: "",
	memo: "",
	amount: "",
	due: ""
});
var money = (s) => Math.round(Number(String(s).replace(/[$,\s]/g, "")) * 100) / 100;
var fixDate = (s) => anyDate(s.trim()) ?? (s.trim() ? "" : today());
function FastEntry() {
	const qc = useQueryClient();
	const [kind, setKind] = (0, import_react.useState)("out");
	const [rows, setRows] = (0, import_react.useState)(() => [
		blank(),
		blank(),
		blank()
	]);
	const [from, setFrom] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: accounts } = useAccounts();
	const { data: lists } = useQuery({
		queryKey: ["fast-entry-lists"],
		queryFn: async () => {
			const [v, c, r] = await Promise.all([
				fetchAll("vendors", "id,name"),
				fetchAll("customers", "id,name"),
				fetchAll("bank_rules", "id,contains,account_id")
			]);
			return {
				vendors: v,
				customers: c,
				rules: r
			};
		}
	});
	const all = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active), [accounts]);
	const accountOpts = all.filter((a) => ![
		"ar",
		"ap",
		"bank"
	].includes(a.kind));
	const label = (a) => accountLabel(a);
	const byLabel = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const a of all) {
			m.set(label(a).toLowerCase(), a.id);
			if (a.number) m.set(a.number.toLowerCase(), a.id);
			m.set(a.name.toLowerCase(), a.id);
		}
		return m;
	}, [all]);
	const accountId = (s) => byLabel.get(s.trim().toLowerCase()) ?? null;
	const pay = payFromAccounts(accounts);
	const deposits = all.filter((a) => a.kind === "bank");
	const fromList = kind === "in" ? deposits : pay;
	(0, import_react.useEffect)(() => {
		if (kind === "bill") return;
		if (!from || !fromList.some((a) => a.id === from)) setFrom((fromList.find((a) => a.kind === "bank") ?? fromList[0])?.id ?? null);
	}, [
		kind,
		fromList,
		from
	]);
	const cols = COLS[kind];
	const patch = (i, p) => setRows((rs) => rs.map((r, j) => j === i ? {
		...r,
		...p,
		error: void 0
	} : r));
	/** Fill the account from what we learned about this payee. */
	function guessAccount(i) {
		const r = rows[i];
		if (!r || r.account || !r.name.trim()) return;
		const rule = ruleFor(lists?.rules ?? [], r.name);
		const a = rule && all.find((x) => x.id === rule.account_id);
		if (a) patch(i, { account: label(a) });
	}
	function focus(r, c) {
		setTimeout(() => {
			const el = document.querySelector(`[data-fe="${r}-${c}"]`);
			el?.focus();
			el?.select();
		}, 0);
	}
	function onKey(e, r, c) {
		if (e.key === "Enter") {
			e.preventDefault();
			if (r === rows.length - 1) setRows((rs) => [...rs, blank(rs[r]?.date)]);
			focus(r + 1, e.shiftKey ? c : 0);
		} else if (e.key === "ArrowDown" && r < rows.length - 1) {
			e.preventDefault();
			focus(r + 1, c);
		} else if (e.key === "ArrowUp" && r > 0) {
			e.preventDefault();
			focus(r - 1, c);
		}
	}
	/** Paste rows straight from Excel or Google Sheets, starting at the cell pasted into. */
	function onPaste(e, r, c) {
		const text = e.clipboardData.getData("text");
		if (!/[\t\n]/.test(text.trim())) return;
		e.preventDefault();
		const grid = text.replace(/\r/g, "").split("\n").filter((l) => l.trim()).map((l) => l.split("	"));
		setRows((rs) => {
			const out = [...rs];
			grid.forEach((cells, dr) => {
				const at = r + dr;
				while (out.length <= at) out.push(blank(out.at(-1)?.date));
				const row = {
					...out[at],
					error: void 0
				};
				cells.forEach((v, dc) => {
					const col = cols[c + dc];
					if (!col) return;
					let val = v.trim();
					if (col.k === "date" || col.k === "due") val = anyDate(val) ?? val;
					if (col.k === "amount") val = val.replace(/[$,\s]/g, "").replace(/^\((.*)\)$/, "$1");
					row[col.k] = val;
				});
				out[at] = row;
			});
			return [...out, blank(out.at(-1)?.date)];
		});
		toast.message(`Pasted ${grid.length} row${grid.length === 1 ? "" : "s"}. Check them, then save.`);
	}
	const filled = rows.filter((r) => !r.saved && (r.name.trim() || r.amount.trim()));
	const total = filled.reduce((s, r) => s + (money(r.amount) || 0), 0);
	async function learn(name, acc) {
		const key = payeeKey(name);
		if (!key || ruleFor(lists?.rules ?? [], name)) return;
		await db.from("bank_rules").insert({
			contains: key,
			account_id: acc
		});
	}
	async function saveRow(r, userId) {
		const date = fixDate(r.date);
		const amt = money(r.amount);
		const acc = accountId(r.account);
		if (!date) return {
			...r,
			error: "Date?"
		};
		if (!(amt > 0)) return {
			...r,
			error: "Amount?"
		};
		if (!acc) return {
			...r,
			error: "Pick an account from the list"
		};
		if (kind !== "in" && !r.name.trim()) return {
			...r,
			error: kind === "bill" ? "Vendor?" : "Paid to?"
		};
		if (kind !== "bill" && !from) return {
			...r,
			error: "Choose the bank account above"
		};
		const vendor = (lists?.vendors ?? []).find((v) => v.name.toLowerCase() === r.name.trim().toLowerCase());
		try {
			if (kind === "out") {
				const fromAcc = all.find((a) => a.id === from);
				const method = r.no.trim() ? "check" : fromAcc?.kind === "credit_card" ? "card" : "ach";
				const { data: c, error } = await db.from("checks").insert({
					account_id: from,
					method,
					number: r.no.trim() || null,
					check_date: date,
					payee: r.name.trim(),
					vendor_id: vendor?.id ?? null,
					memo: r.memo.trim() || null,
					created_by: userId
				}).select("id").single();
				if (error) throw error;
				const { error: le } = await db.from("check_lines").insert({
					check_id: c.id,
					line_no: 1,
					account_id: acc,
					description: r.memo.trim() || null,
					amount: amt
				});
				if (le) {
					await db.from("checks").delete().eq("id", c.id);
					throw le;
				}
				await learn(r.name, acc);
				return {
					...r,
					saved: {
						id: c.id,
						label: "Payment"
					}
				};
			}
			if (kind === "bill") {
				const { data: b, error } = await db.from("bills").insert({
					vendor_id: vendor?.id ?? null,
					vendor_name: r.name.trim(),
					ref: r.no.trim() || null,
					bill_date: date,
					due_date: anyDate(r.due.trim()) ?? null,
					memo: r.memo.trim() || null,
					created_by: userId
				}).select("id").single();
				if (error) throw error;
				const { error: le } = await db.from("bill_lines").insert({
					bill_id: b.id,
					line_no: 1,
					account_id: acc,
					description: r.memo.trim() || null,
					amount: amt
				});
				if (le) {
					await db.from("bills").delete().eq("id", b.id);
					throw le;
				}
				await learn(r.name, acc);
				return {
					...r,
					saved: {
						id: b.id,
						label: "Bill"
					}
				};
			}
			const { data: d, error } = await db.from("deposits").insert({
				account_id: from,
				deposit_date: date,
				memo: r.memo.trim() || r.name.trim() || null,
				created_by: userId
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("deposit_lines").insert({
				deposit_id: d.id,
				account_id: acc,
				name: r.name.trim() || null,
				description: r.memo.trim() || null,
				amount: amt
			});
			if (le) {
				await db.from("deposits").delete().eq("id", d.id);
				throw le;
			}
			return {
				...r,
				saved: {
					id: d.id,
					label: "Deposit"
				}
			};
		} catch (e) {
			return {
				...r,
				error: e.message
			};
		}
	}
	async function saveAll() {
		if (!filled.length) return void toast.error("Type at least one line.");
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const out = [];
		let ok = 0;
		let bad = 0;
		for (const r of rows) {
			if (r.saved || !(r.name.trim() || r.amount.trim())) {
				out.push(r);
				continue;
			}
			const res = await saveRow(r, u.user?.id);
			if (res.saved) ok++;
			else bad++;
			out.push(res);
		}
		setRows(out);
		setBusy(false);
		qc.invalidateQueries();
		if (ok) toast.success(kind === "in" ? `Deposit${ok === 1 ? "" : "s"} saved: ${ok}.` : kind === "bill" ? `${ok} bill${ok === 1 ? "" : "s"} saved.` : `Payment made: ${ok} line${ok === 1 ? "" : "s"} saved.`);
		if (bad) toast.error(`${bad} line${bad === 1 ? "" : "s"} need a fix (shown in red).`);
	}
	function switchKind(k) {
		if (filled.length && !confirm("Lines you haven't saved will be cleared. Switch anyway?")) return;
		setKind(k);
		setRows([
			blank(),
			blank(),
			blank()
		]);
	}
	const grid = `2rem ${cols.map((c) => c.w).join(" ")} 2.5rem`;
	const savedCount = rows.filter((r) => r.saved).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Fast Entry",
			text: "Type many lines in a row like a spreadsheet: Tab moves to the next box, Enter starts a new line, arrows move up and down. You can also paste rows copied from Excel. Press Save all when done."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: Object.keys(TITLE).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => switchKind(k),
					className: `rounded-md px-3 py-1 ${kind === k ? "bg-[var(--section)] text-white" : ""}`,
					children: TITLE[k]
				}, k))
			}), kind !== "bill" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: kind === "in" ? "Deposit to" : "Paid from"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: from,
						options: fromList.map((a) => ({
							value: a.id,
							label: accountLabel(a)
						})),
						onChange: setFrom
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
			id: "fe-accounts",
			children: accountOpts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: label(a) }, a.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
			id: "fe-vendors",
			children: (lists?.vendors ?? []).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: v.name }, v.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
			id: "fe-customers",
			children: (lists?.customers ?? []).map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: v.name }, v.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-2xl border bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-[860px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid border-b bg-muted/40 text-xs font-semibold text-muted-foreground",
					style: { gridTemplateColumns: grid },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2 py-2",
							children: "#"
						}),
						cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `px-2 py-2 ${c.k === "amount" ? "text-right" : ""}`,
							children: c.label
						}, c.k)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
					]
				}), rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `grid items-center border-b last:border-b-0 ${r.saved ? "bg-emerald-50 dark:bg-emerald-950/30" : r.error ? "bg-red-50 dark:bg-red-950/30" : ""}`,
					style: { gridTemplateColumns: grid },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-2 text-xs text-muted-foreground",
							children: r.saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-emerald-600" }) : i + 1
						}),
						cols.map((c, ci) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"data-fe": `${i}-${ci}`,
							"aria-label": `${c.label}, line ${i + 1}`,
							value: String(r[c.k] ?? ""),
							disabled: !!r.saved,
							list: c.list,
							inputMode: c.k === "amount" ? "decimal" : void 0,
							placeholder: c.k === "date" ? "mm/dd/yyyy" : c.k === "due" ? "optional" : "",
							onChange: (e) => patch(i, { [c.k]: e.target.value }),
							onBlur: () => {
								if (c.k === "name") guessAccount(i);
								if ((c.k === "date" || c.k === "due") && r[c.k]) {
									const d = anyDate(String(r[c.k]).trim());
									if (d) patch(i, { [c.k]: d });
								}
							},
							onKeyDown: (e) => onKey(e, i, ci),
							onPaste: (e) => onPaste(e, i, ci),
							className: `h-9 w-full min-w-0 border-0 border-l bg-transparent px-2 outline-none focus:bg-accent focus:ring-2 focus:ring-inset focus:ring-[var(--section)] disabled:opacity-80 ${c.k === "amount" ? "text-right tabular-nums" : ""} ${c.k === "account" && r.account && !accountId(r.account) ? "text-destructive" : ""}`
						}, c.k)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex justify-center",
							children: r.saved ? r.saved.label === "Deposit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/deposits",
								className: "text-xs underline",
								children: "Open"
							}) : r.saved.label === "Bill" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bills/$id",
								params: { id: r.saved.id },
								className: "text-xs underline",
								children: "Open"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/checks/$id",
								params: { id: r.saved.id },
								className: "text-xs underline",
								children: "Open"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Remove this line",
								onClick: () => setRows((rs) => rs.length > 1 ? rs.filter((_, j) => j !== i) : [blank()]),
								className: "text-muted-foreground hover:text-destructive",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						}),
						r.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "col-span-full px-10 pb-1 text-xs text-destructive",
							children: r.error
						})
					]
				}, r.key))]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setRows((rs) => [...rs, blank(rs.at(-1)?.date)]),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a line"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-muted-foreground",
					children: [
						filled.length,
						" line",
						filled.length === 1 ? "" : "s",
						" to save · ",
						fmtMoney(total)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "ml-auto",
					onClick: () => void saveAll(),
					disabled: busy || !filled.length,
					children: busy ? "Saving…" : `Save all (${filled.length})`
				}),
				savedCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: () => setRows([
						blank(),
						blank(),
						blank()
					]),
					children: "Start a new batch"
				})
			]
		})
	] });
}
//#endregion
export { FastEntry as component };
