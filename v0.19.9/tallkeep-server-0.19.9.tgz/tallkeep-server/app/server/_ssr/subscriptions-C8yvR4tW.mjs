import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { H as Pencil, N as Repeat, R as Plus, n as X, sn as Check, x as Sparkles } from "../_libs/lucide-react.mjs";
import { a as nextDate, c as useMoneyOut, i as findRepeats, l as useReminders, n as daysBetween, o as perMonth, r as findPayment, s as tbl, t as EVERY_LABEL } from "./reminders-vPYfNAHe.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { a as useWho, i as useMembers } from "./members-CRgkIqM9.mjs";
import { t as WhoPicker } from "./WhoPicker-DJy3fIi-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/subscriptions-C8yvR4tW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HIDDEN_KEY = "tk-repeat-hidden";
var readHidden = () => {
	try {
		return JSON.parse(localStorage.getItem(HIDDEN_KEY) ?? "[]");
	} catch {
		return [];
	}
};
function Subscriptions() {
	const qc = useQueryClient();
	const { data: everyOne, isLoading } = useReminders();
	const [who] = useWho();
	const list = everyOne?.filter((r) => !who || r.member_id === who);
	const { data: lines } = useMoneyOut();
	const { data: accounts } = useAccounts();
	const { data: members } = useMembers();
	const autopays = useQuery({
		queryKey: ["recurring-list"],
		queryFn: () => fetchAll("recurring", "id,name,next_date,every,active,lines")
	});
	const [edit, setEdit] = (0, import_react.useState)(null);
	const [hidden, setHidden] = (0, import_react.useState)(readHidden);
	const now = today();
	const name = (id) => accounts?.find((a) => a.id === id)?.name ?? "";
	const refresh = () => void qc.invalidateQueries({ queryKey: ["money-reminders"] });
	const active = (list ?? []).filter((r) => r.status === "active");
	const soon = (0, import_react.useMemo)(() => {
		return [...active.map((r) => ({
			type: "r",
			r,
			date: r.next_date
		})), ...(autopays.data ?? []).filter((a) => a.active && !who).map((a) => ({
			type: "a",
			a,
			date: a.next_date
		}))].filter((x) => daysBetween(now, x.date) <= 31).sort((a, b) => a.date.localeCompare(b.date));
	}, [
		active,
		autopays.data,
		now,
		who
	]);
	const subs = (list ?? []).filter((r) => r.kind === "subscription");
	const bills = (list ?? []).filter((r) => r.kind === "bill");
	const monthly = subs.filter((r) => r.status === "active").reduce((s, r) => s + perMonth(r), 0);
	const due30 = soon.reduce((s, x) => s + (x.type === "r" ? x.r.amount ?? 0 : (x.a.lines ?? []).reduce((t, l) => t + Number(l.amount ?? 0), 0)), 0);
	const late = active.filter((r) => r.next_date < now).length;
	const repeats = (0, import_react.useMemo)(() => findRepeats(lines ?? [], list ?? []).filter((s) => !hidden.includes(s.key)), [
		lines,
		list,
		hidden
	]);
	async function paid(r, on) {
		const { error } = await tbl("money_reminders").update({
			last_paid: on,
			next_date: nextDate(r.next_date, r.every),
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", r.id);
		if (error) return void toast.error(error.message);
		toast.success(`${r.name}: marked paid. Next one ${fmtDate(nextDate(r.next_date, r.every))}.`);
		refresh();
	}
	function hide(s) {
		const next = [...hidden, s.key];
		setHidden(next);
		try {
			localStorage.setItem(HIDDEN_KEY, JSON.stringify(next));
		} catch {}
	}
	if (isLoading || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Bills, Rent & Subscriptions",
			text: "What's coming up, what your subscriptions cost, and repeating charges Tallkeep found in your bank and card lines.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setEdit({ kind: "bill" }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a bill"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setEdit({ kind: "subscription" }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a subscription"]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoPicker, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Due in the next 30 days",
					value: fmtMoney(due30)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Subscriptions each month",
					value: fmtMoney(monthly),
					note: `${fmtMoney(monthly * 12)} a year`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Past due",
					value: String(late),
					bad: late > 0
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Box, {
			title: "Coming up",
			children: [soon.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "Nothing due in the next 30 days." }), soon.map((x) => {
				if (x.type === "a") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateCell, {
						date: x.date,
						now
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: x.a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: "Automatic entry" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: fmtMoney((x.a.lines ?? []).reduce((t, l) => t + Number(l.amount ?? 0), 0))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/recurring",
							search: {},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-4 w-4" }), " Recurring"]
						})
					})
				] }, `a${x.a.id}`);
				const r = x.r;
				const hit = findPayment(r, lines ?? []);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateCell, {
						date: r.next_date,
						now
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: r.kind === "bill" ? "Bill" : "Subscription" }),
							r.autopay && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: "Autopay" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: [name(r.account_id) && `from ${name(r.account_id)}`, hit && `found in your bank: ${fmtDate(hit.txn_date)} ${fmtMoney(hit.amount)}`].filter(Boolean).join(" · ")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: r.amount == null ? "—" : fmtMoney(r.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: hit ? "default" : "outline",
							onClick: () => void paid(r, hit?.txn_date ?? now),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), " Paid"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							"aria-label": `Change ${r.name}`,
							onClick: () => setEdit(r),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
						})]
					})
				] }, r.id);
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBox, {
			title: "Subscriptions",
			rows: subs,
			name,
			onEdit: setEdit,
			perMonthCol: true
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBox, {
			title: "Bills",
			rows: bills,
			name,
			onEdit: setEdit
		}),
		repeats.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Box, {
			title: "Repeating charges we found",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pt-2 text-xs text-muted-foreground",
				children: "The same charge, same amount, on a regular schedule in your bank and card lines. Add the ones you want to keep an eye on."
			}), repeats.slice(0, 12).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: s.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-xs text-muted-foreground",
						children: [
							EVERY_LABEL[s.every],
							" · ",
							s.count,
							" times, last ",
							fmtDate(s.last),
							" ·",
							" ",
							name(s.account_id)
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: fmtMoney(s.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setEdit({
							kind: s.amount >= 250 ? "bill" : "subscription",
							name: s.name,
							amount: s.amount,
							every: s.every,
							next_date: s.next,
							account_id: s.account_id,
							match_text: s.match,
							autopay: true
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": `Not a repeat: ${s.name}`,
						onClick: () => hide(s),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
					})]
				})
			] }, s.key))]
		}),
		edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditDialog, {
			draft: edit,
			accounts,
			members: members ?? [],
			onClose: () => setEdit(null),
			onSaved: refresh
		})
	] });
}
function Tile({ label, value, note, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-2xl font-semibold tabular-nums", bad && "text-destructive"),
				children: value
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: note
			})
		]
	});
}
function Box({ title, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 border-b bg-muted/40 px-4 py-2 font-semibold",
			children: [icon, title]
		}), children]
	});
}
var Row = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "flex flex-wrap items-center gap-3 border-t px-4 py-2 text-sm first:border-t-0",
	children
});
var Empty = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	className: "px-4 py-6 text-center text-sm text-muted-foreground",
	children
});
var Pill = ({ children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
	className: "ml-2 rounded-full bg-muted px-2 py-0.5 text-[11px] text-muted-foreground",
	children
});
function DateCell({ date, now }) {
	const d = daysBetween(now, date);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("w-24 text-sm", d < 0 && "font-semibold text-destructive"),
		children: [fmtDate(date), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-muted-foreground",
			children: d < 0 ? `${-d} days late` : d === 0 ? "today" : `in ${d} days`
		})]
	});
}
function ListBox({ title, rows, name, onEdit, perMonthCol }) {
	if (!rows.length) return null;
	const order = {
		active: 0,
		paused: 1,
		cancelled: 2
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {
		title,
		children: [...rows].sort((a, b) => order[a.status] - order[b.status] || a.name.localeCompare(b.name)).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("min-w-0 flex-1", r.status !== "active" && "opacity-60"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: r.name
					}),
					r.status !== "active" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: r.status === "paused" ? "Paused" : "Cancelled" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-xs text-muted-foreground",
						children: [
							EVERY_LABEL[r.every],
							r.status === "active" && ` · next ${fmtDate(r.next_date)}`,
							name(r.account_id) && ` · ${name(r.account_id)}`,
							r.last_paid && ` · last paid ${fmtDate(r.last_paid)}`
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-right tabular-nums",
				children: [r.amount == null ? "—" : fmtMoney(r.amount), perMonthCol && r.every !== "month" && r.amount != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-xs text-muted-foreground",
					children: [fmtMoney(perMonth(r)), "/mo"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "ghost",
				"aria-label": `Change ${r.name}`,
				onClick: () => onEdit(r),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" })
			})
		] }, r.id))
	});
}
function EditDialog({ draft, accounts, members, onClose, onSaved }) {
	const [d, setD] = (0, import_react.useState)({
		every: "month",
		next_date: today(),
		autopay: false,
		status: "active",
		...draft
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	const payFrom = accounts.filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	const cats = accounts.filter((a) => a.is_active && a.type === "expense");
	async function save() {
		if (!d.name?.trim()) return void toast.error("Type a name, like Netflix or Electric bill.");
		if (!d.next_date) return void toast.error("Pick the next date.");
		setBusy(true);
		const row = {
			kind: d.kind,
			name: d.name.trim(),
			amount: d.amount ?? null,
			every: d.every,
			next_date: d.next_date,
			account_id: d.account_id || null,
			category_id: d.category_id || null,
			autopay: !!d.autopay,
			status: d.status,
			match_text: d.match_text?.trim() || null,
			member_id: d.member_id || null,
			notes: d.notes?.trim() || null,
			updated_at: (/* @__PURE__ */ new Date()).toISOString()
		};
		const { error } = d.id ? await tbl("money_reminders").update(row).eq("id", d.id) : await tbl("money_reminders").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		onSaved();
		onClose();
	}
	async function remove() {
		if (!d.id) return;
		const { error } = await tbl("money_reminders").delete().eq("id", d.id);
		if (error) return void toast.error(error.message);
		onSaved();
		onClose();
	}
	const sel = "h-9 w-full rounded-md border bg-background px-2 text-sm";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: d.id ? `Change ${d.name}` : d.kind === "bill" ? "Add a bill" : "Add a subscription" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Kind",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: sel,
								value: d.kind,
								onChange: (e) => set({ kind: e.target.value }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bill",
									children: "Bill (rent, mortgage, power, insurance…)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "subscription",
									children: "Subscription (streaming, apps, memberships…)"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.name ?? "",
								onChange: (e) => set({ name: e.target.value }),
								placeholder: d.kind === "bill" ? "Electric bill" : "Netflix"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Amount (empty if it changes)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: d.amount ?? "",
								onChange: (e) => {
									const v = e.target.value.replace(/[$,\s]/g, "");
									set({ amount: v === "" ? null : Number(v) });
								}
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "How often",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: sel,
								value: d.every,
								onChange: (e) => set({ every: e.target.value }),
								children: Object.keys(EVERY_LABEL).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: EVERY_LABEL[k]
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Next one is due",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.next_date ?? "",
								onChange: (e) => set({ next_date: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Paid from",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: sel,
								value: d.account_id ?? "",
								onChange: (e) => set({ account_id: e.target.value || null }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "—"
								}), payFrom.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: a.id,
									children: a.name
								}, a.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Category",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: sel,
								value: d.category_id ?? "",
								onChange: (e) => set({ category_id: e.target.value || null }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "—"
								}), cats.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: a.id,
									children: a.name
								}, a.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Words on the bank line (to spot it's paid)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.match_text ?? "",
								onChange: (e) => set({ match_text: e.target.value }),
								placeholder: "NETFLIX"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Status",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: sel,
								value: d.status,
								onChange: (e) => set({ status: e.target.value }),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "active",
										children: "Active"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "paused",
										children: "Paused"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "cancelled",
										children: "Cancelled"
									})
								]
							})
						}),
						members.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Whose is it",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: sel,
								value: d.member_id ?? "",
								onChange: (e) => set({ member_id: e.target.value || null }),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Everyone (joint)"
								}), members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: m.id,
									children: m.name
								}, m.id))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: !!d.autopay,
								onChange: (e) => set({ autopay: e.target.checked })
							}), "It's paid automatically (autopay)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Notes",
							wide: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.notes ?? "",
								onChange: (e) => set({ notes: e.target.value })
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [d.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-destructive",
						onClick: () => void remove(),
						children: "Remove"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: onClose,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void save(),
							disabled: busy,
							children: "Save"
						})]
					})]
				})
			]
		})
	});
}
function F({ label, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-1", wide && "sm:col-span-2"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
//#endregion
export { Subscriptions as component };
