import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as AccountRegister } from "./AccountRegister-wL3sXwrI.mjs";
import { t as Route } from "./register-B9K8u6a6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/register-BNB6cZMA.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { account } = Route.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRegister, {
		accountId: account ?? null,
		kind: "bank",
		onAccount: (id) => void navigate({
			to: "/register",
			search: { account: id },
			replace: !account
		})
	});
}
//#endregion
export { Page as component };
