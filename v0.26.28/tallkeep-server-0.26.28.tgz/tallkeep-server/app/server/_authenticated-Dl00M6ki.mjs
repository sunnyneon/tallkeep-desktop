import { _ as lazyRouteComponent, v as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/_authenticated-Dl00M6ki.js
var $$splitComponentImporter = () => import("./_authenticated-Dion3Gth.mjs");
var Route = createFileRoute("/_authenticated/")({
	head: () => ({ meta: [{ title: "Home · Tallkeep" }, {
		name: "description",
		content: "Where to go for each job, in the order the work flows."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
