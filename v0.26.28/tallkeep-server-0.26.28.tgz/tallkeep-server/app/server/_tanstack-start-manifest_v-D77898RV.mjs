//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D77898RV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-DMgacz0_.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-tYgmLpxx.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuNLEoiB.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DMgacz0_.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-Cn_7kQSS.js",
			"/assets/log-out-7ZMzqi8Q.js",
			"/assets/testers.functions-Ct87nCBw.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CAq42yAI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-9QTRRyLF.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd--Yl59aMG.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-vQ3gy2gg.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/dist-BuPAnufl.js",
			"/assets/dialog-DbD9x7R4.js",
			"/assets/queries-Bcbl0GZm.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/label-CF6navWt.js",
			"/assets/textarea-DkffQarw.js",
			"/assets/shoebox-BqDKC0S5.js",
			"/assets/company-DkfXZmiE.js",
			"/assets/reports-MARFES23.js",
			"/assets/access-BgcwZPOL.js",
			"/assets/theme-L2-SQdT3.js",
			"/assets/Logo-DOapM8D6.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CiNLGvl-.js",
			"/assets/log-out-7ZMzqi8Q.js",
			"/assets/admin.functions-C81Qxr-c.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DOapM8D6.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-C5jZvYYP.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/label-CF6navWt.js",
			"/assets/Logo-DOapM8D6.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DPFZGy2N.js",
			"/assets/testers.functions-Ct87nCBw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/coupons.functions-D07rPMsz.js",
			"/assets/buy.functions-Bw0NxQl6.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-C3ye4gE6.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/downloads.functions-CKA1kQgA.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CZu0lHXM.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/label-CF6navWt.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-Bx82NW1c.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/label-CF6navWt.js",
			"/assets/Logo-DOapM8D6.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-C0b3k3Sa.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/upgrade.functions-D5ZCjS5q.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CRYu8wub.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/label-CF6navWt.js",
			"/assets/Logo-DOapM8D6.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DxRrtH8U.js",
			"/assets/select-CvG62n4U.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DS4dtjYT.js", "/assets/StockDocList-Zj2kzXHT.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-Cps8U_NV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/ai-rtYfcvRy.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-Cv725DoM.js",
			"/assets/BankConnections-BxuheWUq.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BmAXPD0U.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-QNzyoitX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-BxuheWUq.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/ai-rtYfcvRy.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BJ1STlR2.js",
			"/assets/TxnEditor-0CRuSNqs.js",
			"/assets/feedWaiting-DGMHrFfw.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-lbVYQxk6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-C8PRnUtB.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/personal-DN54OzRh.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/WhoPicker-D6zDu--i.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-vgc9QiVE.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DmZOjiCI.js", "/assets/AccountRegister-B7AQGf1h.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DefpI-cP.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-Cu7k_uCw.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/money-CYkfiwgi.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DVgd-9aO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-rtYfcvRy.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-JL81v3N9.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BBln3YlH.js", "/assets/StockDocList-Zj2kzXHT.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D3tBOI7c.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-DARjGp6S.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-eQ8eUxS3.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BH9YU6Nm.js", "/assets/PartyList-D1GNIaNw.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Ck9HL-Eu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-BcKHaBkd.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/storage.functions-jEh_tPeS.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-D8mL9lVJ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DhLZqnW2.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-4WrovBN9.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DVbXtg7G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BYoWYuq1.js", "/assets/ChangeHistory-CRvYCkQd.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BH4dMvcV.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/members-DjTPXlTu.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-CBrnf3e-.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/personal-DN54OzRh.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/WhoPicker-D6zDu--i.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DNKzgq0l.js", "/assets/SalesList-BwRx_doU.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-eyoqCW4W.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-jB72uZ9K.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DcaV-Z9i.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-DgVSJHTH.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/loans-BJ1STlR2.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DKlZI4sK.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BIRIijFE.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-D5UZxmU7.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/personal-DN54OzRh.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/WhoPicker-D6zDu--i.js",
			"/assets/reminders-CXpCDbdy.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-1M7qfeq0.js",
			"/assets/select-CvG62n4U.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DNuyyPti.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/personal-DN54OzRh.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/WhoPicker-D6zDu--i.js",
			"/assets/generateCategoricalChart-Bd62AYf4.js",
			"/assets/Area-B2iphtKI.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-am6yqd3t.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/generateCategoricalChart-Bd62AYf4.js",
			"/assets/PlCharts-4WrovBN9.js",
			"/assets/BarChart-BTPgK8GZ.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DQTZZSTY.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-Dgh9uAV9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-Cse_wJSP.js",
			"/assets/createServerFn-YLwUPe6C.js",
			"/assets/auth-middleware-GDJ8zp6m.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/storage.functions-jEh_tPeS.js",
			"/assets/coupons.functions-D07rPMsz.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-D0wY3SGS.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DW39VBG2.js",
			"/assets/select-CvG62n4U.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/checkbox-C_XNvz_q.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-BVYQoV2f.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-Dn1yh5RU.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CvG62n4U.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-Bj0PE8tj.js", "/assets/SalesList-BwRx_doU.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-Ds9fsJYY.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/ai-rtYfcvRy.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-jEh_tPeS.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BM4ncdUa.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/money-CYkfiwgi.js",
			"/assets/badge-Bb4dAwNU.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-NcShT3IX.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-Bg7XNSxv.js", "/assets/AccountRegister-B7AQGf1h.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-jXlmpxuZ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/MoneyAccountPick-zA73SyOc.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-yzaJfASs.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DUV1GAtH.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/RepeatInvoice-D30fDk1h.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BWSlnzoO.js",
			"/assets/select-CvG62n4U.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-Bd62AYf4.js",
			"/assets/BarChart-BTPgK8GZ.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-44byBv0W.js", "/assets/SalesList-BwRx_doU.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DMfz03fm.js", "/assets/SalesList-BwRx_doU.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CMfevyG2.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-C9EwexOP.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/serials-BD1x8D0g.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-C0q1ovsi.js",
			"/assets/createServerFn-YLwUPe6C.js",
			"/assets/auth-middleware-GDJ8zp6m.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/select-CvG62n4U.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/emailWording-DOd9tXQS.js",
			"/assets/scan-barcode-i-o7I6qZ.js",
			"/assets/send-BwSadvej.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CndOCDp2.js",
			"/assets/switch-BIRIijFE.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/bankfeed.functions-DtDkvA3X.js",
			"/assets/QuickBooksImport-eQ8eUxS3.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DqGWM8A7.js",
			"/assets/footers-DcaLZtys.js",
			"/assets/PrintFrame-CCWXf9DA.js",
			"/assets/checkbox-C_XNvz_q.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-Dcgdl6h9.js",
			"/assets/FeaturePicker-BA062GI7.js",
			"/assets/support-B3C_Bd4G.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-Bb9ReIVW.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/FeaturePicker-BA062GI7.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-WKaAzyQg.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BtDN0-kh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/photos-DqGWM8A7.js",
			"/assets/stockmove-BVewpkps.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BIB5zvfg.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/loans-BJ1STlR2.js",
			"/assets/feedWaiting-DGMHrFfw.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-jEh_tPeS.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CWuq6Rwx.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/PrintFrame-CCWXf9DA.js",
			"/assets/DocPdf-DYDFMWro.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DE7ujNVk.js",
			"/assets/createServerFn-YLwUPe6C.js",
			"/assets/auth-middleware-GDJ8zp6m.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/MoneyAccountPick-zA73SyOc.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B3C_Bd4G.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-D2fVJsWY.js",
			"/assets/select-CvG62n4U.js",
			"/assets/StockDialogs-BtDN0-kh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/stockmove-BVewpkps.js",
			"/assets/checkbox-C_XNvz_q.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BfnCB6NF.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/members-DjTPXlTu.js",
			"/assets/WhoPicker-D6zDu--i.js",
			"/assets/reminders-CXpCDbdy.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BBObMs2W.js",
			"/assets/select-CvG62n4U.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/tickets.functions-BmCVYcxF.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DOeP6UHN.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B3C_Bd4G.js",
			"/assets/support.functions-Dn4wkl-3.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CLArQS-V.js", "/assets/StockDocList-Zj2kzXHT.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-B9fQZ4Rn.js", "/assets/PartyList-D1GNIaNw.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-D_Lq2vp_.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/tickets.functions-BmCVYcxF.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CJeKy37Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/workorders-C4m34IW4.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DvbFdSnT.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-BooHwsig.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/coupons.functions-D07rPMsz.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DuigV2Z2.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/AdminAccount-lzu2pIcc.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-D3W_viAb.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/downloads.functions-CKA1kQgA.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-D5Ux6TA0.js",
			"/assets/createServerFn-YLwUPe6C.js",
			"/assets/auth-middleware-GDJ8zp6m.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CMIK3KiH.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BPfdS0Vh.js",
			"/assets/testers.functions-Ct87nCBw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CUln6atJ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BPHCjGPS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-Bw0NxQl6.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DsiAgUut.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/textarea-DkffQarw.js",
			"/assets/support.functions-Dn4wkl-3.js",
			"/assets/HelpParts-D8iv9coI.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-EsAXQYg8.js",
			"/assets/ManualFrame-BS9G1NAr.js",
			"/assets/manual._slug-MJo_gw5i.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Bsy02yU_.js",
			"/assets/createServerFn-YLwUPe6C.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Cink1oiG.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-D5ZCjS5q.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Doyx-P7P.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-rtYfcvRy.js",
			"/assets/personal-DN54OzRh.js",
			"/assets/reminders-CXpCDbdy.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CHs7rNDO.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/AdminAccount-lzu2pIcc.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CS33cO2Y.js", "/assets/ManualFrame-BS9G1NAr.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DIiw6P44.js", "/assets/AccountRegister-B7AQGf1h.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DDe5i6Hn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/OriginalLink-DamSQNJ_.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/realestate-Dfg6g4Ai.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-_9OJdbnB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BLINOcc0.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/realestate-Dfg6g4Ai.js",
			"/assets/money-CYkfiwgi.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-C2BfLuxk.js",
			"/assets/select-CvG62n4U.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/SideList-CWD6UbgU.js",
			"/assets/PartyHistory-BDAeNYhV.js",
			"/assets/tabs-BQOjmnIQ.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-bOZDt1u3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CvG62n4U.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-DOd9tXQS.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CRvYCkQd.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/SideList-CWD6UbgU.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-DOvOolNM.js",
			"/assets/MoneyAccountPick-zA73SyOc.js",
			"/assets/footers-DcaLZtys.js",
			"/assets/PrintFrame-CCWXf9DA.js",
			"/assets/serials-BD1x8D0g.js",
			"/assets/SerialsBox-BPJHz9ey.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-KxI0MRu9.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CvG62n4U.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BtDN0-kh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CRvYCkQd.js",
			"/assets/switch-BIRIijFE.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Bb4dAwNU.js",
			"/assets/SideList-CWD6UbgU.js",
			"/assets/tabs-BQOjmnIQ.js",
			"/assets/photos-DqGWM8A7.js",
			"/assets/stockmove-BVewpkps.js",
			"/assets/serials-BD1x8D0g.js",
			"/assets/SerialsBox-BPJHz9ey.js",
			"/assets/workorders-C4m34IW4.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-Bfk9QCtH.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CvG62n4U.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-DOd9tXQS.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CRvYCkQd.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/SideList-CWD6UbgU.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-DOvOolNM.js",
			"/assets/MoneyAccountPick-zA73SyOc.js",
			"/assets/footers-DcaLZtys.js",
			"/assets/PrintFrame-CCWXf9DA.js",
			"/assets/checkbox-C_XNvz_q.js",
			"/assets/serials-BD1x8D0g.js",
			"/assets/workorders-C4m34IW4.js",
			"/assets/RepeatInvoice-D30fDk1h.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BmCVYcxF.js",
			"/assets/users.functions-Dcgdl6h9.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-MEEcFujd.js",
			"/assets/select-CvG62n4U.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/SideList-CWD6UbgU.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CfRqqyZb.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/quickadd-BPmSbxPF.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B3C_Bd4G.js",
			"/assets/support.functions-Dn4wkl-3.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CYkDPo2k.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-weI3eVWr.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/SideList-CWD6UbgU.js",
			"/assets/PartyHistory-BDAeNYhV.js",
			"/assets/tabs-BQOjmnIQ.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DrhmA92M.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/sales-JL81v3N9.js",
			"/assets/footers-DcaLZtys.js",
			"/assets/tickets.functions-BmCVYcxF.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CFoZRoaj.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/input-BzvSI4cw.js",
			"/assets/skeleton-pVjtcAzv.js",
			"/assets/AdminAccount-lzu2pIcc.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-G_3nRxke.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-D2gc33Pe.js",
			"/assets/textarea-DkffQarw.js",
			"/assets/support-B3C_Bd4G.js",
			"/assets/support.functions-Dn4wkl-3.js",
			"/assets/HelpParts-D8iv9coI.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-IJs21qYs.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-pVjtcAzv.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
