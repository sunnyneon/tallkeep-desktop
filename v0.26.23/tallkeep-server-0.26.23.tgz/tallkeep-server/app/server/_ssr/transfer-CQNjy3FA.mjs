import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as StockDocList } from "./StockDocList-tJu5C0AM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/transfer-CQNjy3FA.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockDocList, { kind: "transfer" });
//#endregion
export { SplitComponent as component };
