//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BHGRFxX_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-COUNC9m-.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-CWw3kZ3V.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-C1--b0WQ.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-COUNC9m-.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BYGf_T3C.js",
			"/assets/log-out-BHxRaYgH.js",
			"/assets/testers.functions-CwoTCMKB.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-HocwxORn.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CWSjX-hB.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-DPKELlvr.js",
			"/assets/button-D91Y_inu.js",
			"/assets/dist-Dd8C0xXz.js",
			"/assets/dialog-DWA90raK.js",
			"/assets/queries-DKH63sKu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/label-BE1le-Do.js",
			"/assets/textarea-Dn5clish.js",
			"/assets/shoebox-NiTBx1lv.js",
			"/assets/company-r_eGAUft.js",
			"/assets/reports-C_36oJT2.js",
			"/assets/access-B-i9l2sm.js",
			"/assets/LicenseCard-W0tzibGw.js",
			"/assets/Logo-DLcewiUc.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-ByJVfyf2.js",
			"/assets/log-out-BHxRaYgH.js",
			"/assets/admin.functions-ianiGRmS.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DLcewiUc.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Bvdkh4mY.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/label-BE1le-Do.js",
			"/assets/Logo-DLcewiUc.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-9VeiBZUH.js",
			"/assets/testers.functions-CwoTCMKB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/coupons.functions-BNKEZ31n.js",
			"/assets/buy.functions-DgrT1xLH.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-Cv_H9FUV.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/downloads.functions-DG_qvoMl.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CcL02j4W.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/label-BE1le-Do.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BY-GN7q0.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/label-BE1le-Do.js",
			"/assets/Logo-DLcewiUc.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-DtcP6K_B.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/upgrade.functions-zX2Q2uUS.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-BthjxOpd.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/label-BE1le-Do.js",
			"/assets/Logo-DLcewiUc.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-Doid1a_u.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-2EaOYGat.js", "/assets/StockDocList-R8wcB3Zl.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DwaX-U3i.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/ai-DknTF3hc.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-DQrZrhho.js",
			"/assets/BankConnections-DKZIuC4N.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-fI8kLYeq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DDttcwO-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DKZIuC4N.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/ai-DknTF3hc.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BCAAX9pQ.js",
			"/assets/TxnEditor-BdcsYX9b.js",
			"/assets/feedWaiting-KFEQmci5.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BtiuvkHV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-CFzhxp4w.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/personal-Cy0rDCDJ.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/WhoPicker-CYsmZeFS.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DDvOqvcL.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CQ2hrIAO.js", "/assets/AccountRegister-DtFfvXeg.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-YhKyOLSJ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-Rb8p6wqb.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/money-zFEe6xhF.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-B6TyNMRs.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DknTF3hc.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-atYNchBh.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Dc9YPyxS.js", "/assets/StockDocList-R8wcB3Zl.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Bhv0iiGd.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CLlmmEcY.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CoPQhioI.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BHSqxCZC.js", "/assets/PartyList-BjdCoibb.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CvOR6rRg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DuVqxmbf.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/storage.functions-Bk8GoT1Y.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Bf4KWZr_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-TP3xi7NB.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BR7eidPn.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DEKRilDb.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DNYQ7KFt.js", "/assets/ChangeHistory-aQsPUPhu.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-bY60MVLz.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/members-rfDyjQKm.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-f4p6Lv8L.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/personal-Cy0rDCDJ.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/WhoPicker-CYsmZeFS.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BAwej-3m.js", "/assets/SalesList-BnVxHiBX.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-SHwO1ouZ.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Cd4v6gtz.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BghSprkP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BBBuElHR.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/loans-BCAAX9pQ.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CE6RSjxu.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Dj94SRvB.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-DWCBoh8I.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/personal-Cy0rDCDJ.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/WhoPicker-CYsmZeFS.js",
			"/assets/reminders-C3Lk4MGc.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-_Fzut8Vy.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BFLLqpqH.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/personal-Cy0rDCDJ.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/WhoPicker-CYsmZeFS.js",
			"/assets/generateCategoricalChart-BubVEE5A.js",
			"/assets/Area-Cy7aDkxz.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CnpwBYrH.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/generateCategoricalChart-BubVEE5A.js",
			"/assets/PlCharts-BR7eidPn.js",
			"/assets/BarChart-HW1Rul8q.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DqacVHNs.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-h-nOR9zF.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CSGrg61G.js",
			"/assets/createServerFn-Cc52XvTh.js",
			"/assets/auth-middleware-9r7doeCw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/storage.functions-Bk8GoT1Y.js",
			"/assets/coupons.functions-BNKEZ31n.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CY4FwVx1.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-C_RQYfhX.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/checkbox-C-xIOZq6.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-C_fT9KcH.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BNHVREy4.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-atYNchBh.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DIlYPT6Q.js", "/assets/SalesList-BnVxHiBX.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CFvtPoIL.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/ai-DknTF3hc.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bk8GoT1Y.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-DEhElKVo.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/money-zFEe6xhF.js",
			"/assets/badge-DM2LZc-p.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-CHEvN0F0.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-C1E5teDH.js", "/assets/AccountRegister-DtFfvXeg.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Dvb560jb.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/MoneyAccountPick-DbwdeQMe.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BoeJHynX.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-Dw88ymjI.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/RepeatInvoice-BsHjb4QB.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BFm7Nnqk.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/sales-atYNchBh.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BubVEE5A.js",
			"/assets/BarChart-HW1Rul8q.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CLRzogFr.js", "/assets/SalesList-BnVxHiBX.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DgxXaDrZ.js", "/assets/SalesList-BnVxHiBX.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-qakfSvup.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-b0hDkBqC.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/serials-DxOdlT30.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DZkkX7Nf.js",
			"/assets/createServerFn-Cc52XvTh.js",
			"/assets/auth-middleware-9r7doeCw.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-DPxhVOnl.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DDRLTBF6.js",
			"/assets/switch-Dj94SRvB.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-CoPQhioI.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BSJtDXn1.js",
			"/assets/footers-ChS67sXo.js",
			"/assets/PrintFrame-C33Pay25.js",
			"/assets/checkbox-C-xIOZq6.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-Jm4oAD7W.js",
			"/assets/FeaturePicker-BROlVoe-.js",
			"/assets/support-CR_4siER.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-Cbr7aN1p.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/FeaturePicker-BROlVoe-.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BrmCqjOM.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Ca8uFKaO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/photos-BSJtDXn1.js",
			"/assets/stockmove-fbAnQIQL.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DhiPi2Od.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/loans-BCAAX9pQ.js",
			"/assets/feedWaiting-KFEQmci5.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bk8GoT1Y.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-BSnRzzVV.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/PrintFrame-C33Pay25.js",
			"/assets/DocPdf-CnwepIK8.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-D3RACHwc.js",
			"/assets/createServerFn-Cc52XvTh.js",
			"/assets/auth-middleware-9r7doeCw.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/MoneyAccountPick-DbwdeQMe.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CR_4siER.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-Bh2sVFGu.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/StockDialogs-Ca8uFKaO.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/stockmove-fbAnQIQL.js",
			"/assets/checkbox-C-xIOZq6.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-FRlj4w8Y.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/members-rfDyjQKm.js",
			"/assets/WhoPicker-CYsmZeFS.js",
			"/assets/reminders-C3Lk4MGc.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-C9e1p6yg.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/tickets.functions-BwHZhDfE.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Cc8AfJ2a.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CR_4siER.js",
			"/assets/support.functions-DTcF0LOY.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CnEZepWG.js", "/assets/StockDocList-R8wcB3Zl.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-BFvcEgns.js", "/assets/PartyList-BjdCoibb.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-CYvAxbDq.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/tickets.functions-BwHZhDfE.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-kVCTewPe.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/workorders-Bp4reDfl.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-B3onfeZP.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-jY4zee7u.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/coupons.functions-BNKEZ31n.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BbJNehCO.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/AdminAccount-Bju46CYH.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BlJRDWSi.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/downloads.functions-DG_qvoMl.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-CqgUmrFX.js",
			"/assets/createServerFn-Cc52XvTh.js",
			"/assets/auth-middleware-9r7doeCw.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BWcM4GWo.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-4sXq1uyF.js",
			"/assets/testers.functions-CwoTCMKB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CAxvgauZ.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-De_-KTCS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D91Y_inu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DgrT1xLH.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BCy73lgl.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/textarea-Dn5clish.js",
			"/assets/support.functions-DTcF0LOY.js",
			"/assets/HelpParts-BtJY65OH.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-2LA2798a.js",
			"/assets/ManualFrame-CDWY2CLH.js",
			"/assets/manual._slug-3PDwjj9z.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CVmSxEEI.js",
			"/assets/createServerFn-Cc52XvTh.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-MntCsYH8.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D91Y_inu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-zX2Q2uUS.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-tmIkj8Wc.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DknTF3hc.js",
			"/assets/personal-Cy0rDCDJ.js",
			"/assets/reminders-C3Lk4MGc.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Cwum9JRe.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/AdminAccount-Bju46CYH.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-Bob6kxdm.js", "/assets/ManualFrame-CDWY2CLH.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-DYHG-H7p.js", "/assets/AccountRegister-DtFfvXeg.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CGkWEeut.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/OriginalLink-DoTXxr_v.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/realestate-_oiLgHK6.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CrMTYrY4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-_THtmjm_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/realestate-_oiLgHK6.js",
			"/assets/money-zFEe6xhF.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B5k8gvNb.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-atYNchBh.js",
			"/assets/SideList-CjbHVv3w.js",
			"/assets/PartyHistory-Cyn1skdP.js",
			"/assets/tabs-ohG7m3uG.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-EzLF0sE5.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-DPxhVOnl.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-aQsPUPhu.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/sales-atYNchBh.js",
			"/assets/SideList-CjbHVv3w.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-BYHupkxf.js",
			"/assets/MoneyAccountPick-DbwdeQMe.js",
			"/assets/footers-ChS67sXo.js",
			"/assets/PrintFrame-C33Pay25.js",
			"/assets/serials-DxOdlT30.js",
			"/assets/SerialsBox-C0Smk1LP.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-a57o3O9u.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-Ca8uFKaO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-aQsPUPhu.js",
			"/assets/switch-Dj94SRvB.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-DM2LZc-p.js",
			"/assets/SideList-CjbHVv3w.js",
			"/assets/tabs-ohG7m3uG.js",
			"/assets/photos-BSJtDXn1.js",
			"/assets/stockmove-fbAnQIQL.js",
			"/assets/serials-DxOdlT30.js",
			"/assets/SerialsBox-C0Smk1LP.js",
			"/assets/workorders-Bp4reDfl.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-djW3X3ri.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-DPxhVOnl.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-aQsPUPhu.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/sales-atYNchBh.js",
			"/assets/SideList-CjbHVv3w.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-BYHupkxf.js",
			"/assets/MoneyAccountPick-DbwdeQMe.js",
			"/assets/footers-ChS67sXo.js",
			"/assets/PrintFrame-C33Pay25.js",
			"/assets/checkbox-C-xIOZq6.js",
			"/assets/serials-DxOdlT30.js",
			"/assets/workorders-Bp4reDfl.js",
			"/assets/RepeatInvoice-BsHjb4QB.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BwHZhDfE.js",
			"/assets/users.functions-Jm4oAD7W.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CLgG69-G.js",
			"/assets/select-CEAoR6zz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-atYNchBh.js",
			"/assets/SideList-CjbHVv3w.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-DMhfScKX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/quickadd-dARWm-jP.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CR_4siER.js",
			"/assets/support.functions-DTcF0LOY.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-nHGmYmT-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-tvWJzfvs.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/SideList-CjbHVv3w.js",
			"/assets/PartyHistory-Cyn1skdP.js",
			"/assets/tabs-ohG7m3uG.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CN6tHL6H.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/sales-atYNchBh.js",
			"/assets/footers-ChS67sXo.js",
			"/assets/tickets.functions-BwHZhDfE.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BScFdL8U.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D91Y_inu.js",
			"/assets/input-BHg6ubsP.js",
			"/assets/skeleton-BDThmExJ.js",
			"/assets/AdminAccount-Bju46CYH.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CCl7iW26.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-D91Y_inu.js",
			"/assets/textarea-Dn5clish.js",
			"/assets/support-CR_4siER.js",
			"/assets/support.functions-DTcF0LOY.js",
			"/assets/HelpParts-BtJY65OH.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CcdSvxIm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BDThmExJ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
