import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stock-doc._id-B7j6VY2E.js
var $$splitComponentImporter = () => import("./stock-doc._id-BB870Mrt.mjs");
var Route = createFileRoute("/_authenticated/stock-doc/$id")({
	validateSearch: (s) => s["kind"] === "adjust" || s["kind"] === "transfer" || s["kind"] === "count" ? { kind: s["kind"] } : {},
	head: () => ({ meta: [{ title: "Stock document · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
