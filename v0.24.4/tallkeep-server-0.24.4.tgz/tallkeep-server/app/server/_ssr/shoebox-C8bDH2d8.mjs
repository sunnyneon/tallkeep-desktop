import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as fileToPages, r as shrinkForStorage } from "./ai-DoFpV1D-.mjs";
import { t as aiRead } from "./ai.functions-RoQbEJEa.mjs";
import { a as ruleFor, n as parseBankCsv, r as parseOfx } from "./bankfile-DZuZ5KwQ.mjs";
import { a as recordLoanPayments, t as fileLoan } from "./loans-C8Jc4W1z.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/shoebox-C8bDH2d8.js
/**
* Statement dates that cross New Year. A January statement often lists December lines, and the
* AI gives them the statement's year (Dec 17, 2026 on a statement that ends Jan 17, 2026). A line
* can't be after the statement ends, so those go back a year.
*/
var DAY = 864e5;
var t = (d) => Date.parse(`${d}T12:00:00Z`);
/** The statement's end date: what the AI read, else the newest line not in the future. */
function statementEnd(periodEnds, dates) {
	const ok = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v.slice(0, 10));
	const pe = periodEnds.filter(ok).map((v) => String(v).slice(0, 10));
	if (pe.length) return pe.sort().at(-1);
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	return dates.filter((d) => d <= today).sort().at(-1) ?? today;
}
/** The line's date, moved back a year (or more) while it's after the statement's end. */
function fixLineYear(date, end) {
	let d = date;
	for (let i = 0; i < 3 && t(d) > t(end) + 5 * DAY; i++) d = `${Number(d.slice(0, 4)) - 1}${d.slice(4)}`;
	return d;
}
/**
* Read a PDF bank or card statement with the AI, then check it: the lines must add up to the
* difference between the statement's opening and closing balances. When they don't, read it once
* more, telling the AI what was off; keep whichever reading fits. What's still off is returned so
* the person can be told before reconciling (a line read the wrong way round, doubled or missed).
*/
var num$1 = (v) => typeof v === "number" && Number.isFinite(v) ? v : typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v.replace(/[$,]/g, ""))) ? Number(v.replace(/[$,]/g, "")) : null;
var r2 = (n) => Math.round(n * 100) / 100;
async function readOnce(pages, card, step, note) {
	const raw = [];
	const ends = [];
	let begin = null;
	let end = null;
	for (let i = 0; i < pages.length; i += 6) {
		step(`reading pages ${i + 1}–${Math.min(i + 6, pages.length)} of ${pages.length}…`);
		const r = JSON.parse(await aiRead({ data: {
			feature: "statement",
			images: pages.slice(i, i + 6),
			hint: `This is a ${card ? "credit card" : "bank account"} statement${pages.length > 6 ? `, pages ${i + 1}-${Math.min(i + 6, pages.length)} of ${pages.length}` : ""}.${note}`
		} }));
		raw.push(...r["lines"] ?? []);
		ends.push(r["period_end"]);
		begin ??= num$1(r["beginning_balance"]);
		end = num$1(r["ending_balance"]) ?? end;
	}
	const last = statementEnd(ends, raw.map((l) => String(l.date ?? "").slice(0, 10)));
	const seen = /* @__PURE__ */ new Map();
	const lines = [];
	for (const l of raw) {
		const date = fixLineYear(String(l.date ?? "").slice(0, 10), last);
		const amount = r2(Number(l.amount));
		if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !amount) continue;
		const description = String(l.description ?? "").trim();
		const k = `${date}|${amount}|${description.toLowerCase()}`;
		const n = (seen.get(k) ?? 0) + 1;
		seen.set(k, n);
		lines.push({
			txn_date: date,
			amount,
			description,
			ref: l.ref ? String(l.ref) : null,
			fit_id: `pdf:${k}:${n}`
		});
	}
	const total = r2(lines.reduce((t, l) => t + l.amount, 0));
	const want = begin != null && end != null ? r2(card ? begin - end : end - begin) : null;
	return {
		lines,
		begin,
		end,
		off: want == null ? null : r2(total - want)
	};
}
async function readStatement(file, card, step) {
	const pages = await fileToPages(file, 40);
	const first = await readOnce(pages, card, step, "");
	if (!first.off) return first;
	step("the lines don't add up to the statement's balances: reading it again…");
	const total = r2(first.lines.reduce((t, l) => t + l.amount, 0));
	const second = await readOnce(pages, card, step, ` Careful: a first reading's lines added up to ${total.toFixed(2)}, but the statement's balances say ${(total - first.off).toFixed(2)}. Check every line's sign (${card ? "purchases, interest and fees negative; payments and credits positive" : "deposits positive, withdrawals negative"}), and that no line is missed or listed twice.`);
	if (second.off != null && Math.abs(second.off) < Math.abs(first.off)) return second;
	return first;
}
/** Plain words for a statement that doesn't add up (null when it does, or can't be told). */
function offWarning(r) {
	if (!r.off) return null;
	return `Check this statement: its lines add up to ${fmtMoney(Math.abs(r.off))} ${r.off > 0 ? "more" : "less"} than its opening and closing balances say. A line may be read the wrong way round (a charge as a payment), listed twice or missed. Fix it in Bank Feeds or the register before reconciling.`;
}
/**
* Investment and retirement statements from the Shoebox (brokerage, IRA, Roth IRA, 401k…).
*
* The statement tells Tallkeep whose account it is (company and last 4 digits), the value on the
* statement date and, when it lists them, the funds and stocks in it. Tallkeep then:
*   1. finds the account in Investments by the last 4 digits, or adds one ("Primerica Roth IRA");
*   2. updates what it holds: each fund's shares and price on the statement date (what each cost
*      is kept); anything the statement doesn't list goes in "Other (not listed)", so the total
*      is the statement's value. Net Worth shows it.
*/
var T$1 = (t) => db.from(t);
var isDay$1 = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? ""));
var num = (v) => {
	if (v == null || v === "") return null;
	const n = Number(String(v).replace(/[$,\s]/g, "").replace(/^\((.*)\)$/, "-$1"));
	return Number.isFinite(n) ? n : null;
};
var OTHER = "Other (not listed)";
/** Cash and money market funds: what they cost is what they're worth. */
var isCash = (name, symbol) => /money market|cash|core account|sweep/i.test(name) || /^(SPAXX|FDRXX|FZFXX|SPRXX|SWVXX|VMFXX)$/.test(symbol ?? "");
/** The statement's summary numbers (only the ones it shows). */
var SUMMARY_KEYS = [
	"deposits",
	"withdrawals",
	"fees",
	"dividends",
	"interest",
	"realized_short",
	"realized_long",
	"change_in_value"
];
function summary(v) {
	const o = v && typeof v === "object" ? v : {};
	const out = {};
	for (const k of SUMMARY_KEYS) {
		const n = num(o[k]);
		if (n != null) out[k] = Math.round(n * 100) / 100;
	}
	return out;
}
/** Keep what the statement says for its period (every statement, older ones too). */
async function keepStatement(accountId, itemId, S) {
	if (!S.date) return;
	const row = {
		account_id: accountId,
		period_start: S.start,
		period_end: S.date,
		beginning_value: S.beginning,
		ending_value: S.value,
		period: S.period,
		ytd: S.ytd,
		shoebox_item_id: itemId
	};
	const { data: had } = await T$1("investment_statements").select("id").eq("account_id", accountId).eq("period_end", S.date).maybeSingle();
	if (had) await T$1("investment_statements").update(row).eq("id", had.id);
	else await T$1("investment_statements").insert(row);
}
function readInvestment(r) {
	const raw = Array.isArray(r["holdings"]) ? r["holdings"] : [];
	const lines = [];
	for (const h of raw) {
		const name = String(h["name"] ?? "").trim();
		const value = num(h["value"]);
		let shares = num(h["shares"]);
		let price = num(h["price"]);
		if (!name || value == null && (shares == null || price == null)) continue;
		if (shares == null || price == null || shares === 0) {
			shares = 1;
			price = value ?? 0;
		}
		if (/^total\b/i.test(name)) continue;
		const symbol = h["symbol"] ? String(h["symbol"]).replace(/[()]/g, "").trim().toUpperCase().slice(0, 12) : null;
		const cost = num(h["cost"]);
		lines.push({
			name: name.slice(0, 120),
			symbol,
			shares: Math.abs(shares),
			price: Math.abs(price),
			cost: cost != null ? Math.abs(cost) : isCash(name, symbol) ? Math.round(Math.abs(shares * price) * 100) / 100 : null
		});
	}
	const kind = String(r["invest_kind"] ?? "").toLowerCase();
	return {
		issuer: r["issuer"] ? String(r["issuer"]).trim() : null,
		last4: /^\d{4}$/.test(String(r["account_last4"] ?? "")) ? String(r["account_last4"]) : null,
		accountType: r["account_type"] ? String(r["account_type"]).trim() : null,
		retirement: kind === "retirement" || /ira|401|403|457|retire|pension|tsp/i.test(String(r["account_type"] ?? "")),
		date: isDay$1(r["period_end"]) ? String(r["period_end"]) : isDay$1(r["date"]) ? String(r["date"]) : null,
		value: num(r["ending_value"]) ?? num(r["total"]),
		/** Money put in since the account opened, less what was taken out (null when not shown). */
		invested: num(r["total_invested"]),
		start: isDay$1(r["period_start"]) ? String(r["period_start"]) : null,
		beginning: num(r["beginning_value"]),
		period: summary(r["period"]),
		ytd: summary(r["ytd"]),
		lines
	};
}
/** File an investment statement: the account and what it holds. */
async function fileInvestment(id, r, ctx, fileName) {
	const S = readInvestment(r);
	if (S.value == null && !S.lines.length) throw new Error("Couldn't find the account's value on this statement.");
	ctx.step(`${fileName}: updating Investments…`);
	const { data: fresh } = await T$1("accounts").select("id,number,name,type,kind,key,description,is_active");
	const all = fresh ?? ctx.accounts;
	const pool = all.filter((a) => a.is_active && a.kind === "other_asset");
	let acct = S.last4 && pool.find((a) => `${a.number ?? ""} ${a.name} ${a.description ?? ""}`.includes(S.last4)) || null;
	if (!acct && S.issuer) {
		const word = S.issuer.toLowerCase().split(/\s+/)[0] ?? "";
		const same = pool.filter((a) => word.length > 2 && a.name.toLowerCase().includes(word) && (!S.last4 || !/ending \d{4}/.test(a.description ?? "")));
		if (same.length === 1) {
			acct = same[0];
			if (S.last4 && !acct.description) await T$1("accounts").update({ description: `ending ${S.last4}` }).eq("id", acct.id);
		}
	}
	let added = false;
	if (!acct) {
		const used = new Set(all.map((a) => a.number));
		let n = S.retirement ? 1320 : 1301;
		while (used.has(String(n))) n++;
		const name = [S.issuer, S.accountType ?? (S.retirement ? "Retirement" : "Investments")].filter(Boolean).join(" ").slice(0, 80) || "Investment account";
		const { data, error } = await T$1("accounts").insert({
			number: String(n),
			name,
			type: "asset",
			kind: "other_asset",
			description: S.last4 ? `ending ${S.last4}` : null
		}).select("id,number,name,type,kind,key,description,is_active").single();
		if (error) throw new Error(error.message);
		acct = data;
		added = true;
	}
	const { data: had } = await T$1("holdings").select("id,symbol,name,shares,price,cost,price_date").eq("account_id", acct.id);
	const old = had ?? [];
	await keepStatement(acct.id, id, S);
	const newest = old.map((h) => h.price_date ?? "").sort().pop() ?? "";
	if (S.date && newest && S.date < newest && !added) {
		await T$1("shoebox_items").update({
			status: "done",
			kind: "investment",
			account_id: acct.id,
			target_type: "investment",
			target_id: acct.id,
			error: null,
			summary: `An older statement${S.issuer ? ` from ${S.issuer}` : ""} (${fmtDate(S.date)}). ${acct.name} already has the ${fmtDate(newest)} numbers, so what it holds didn't change. Its numbers for the month are kept.`
		}).eq("id", id);
		return;
	}
	const placeholder = (n) => n === OTHER || n === "Account value";
	const funds = old.filter((h) => !placeholder(h.name));
	if (!S.lines.length && funds.length) for (const h of funds) S.lines.push({
		name: h.name,
		symbol: h.symbol,
		shares: Number(h.shares),
		price: Number(h.price)
	});
	const date = S.date ?? (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
	const listed = S.lines.reduce((t, l) => t + l.shares * l.price, 0);
	const lines = [...S.lines];
	if (S.value != null) {
		const rest = Math.round((S.value - listed) * 100) / 100;
		if (rest > .5 || !lines.length) lines.push({
			name: lines.length ? OTHER : "Account value",
			symbol: null,
			shares: 1,
			price: rest > 0 ? rest : S.value
		});
	}
	const worth = lines.reduce((t, l) => t + l.shares * l.price, 0);
	const perFund = lines.some((l) => l.cost != null && !isCash(l.name, l.symbol));
	const costOf = (l) => l.cost != null ? l.cost : !perFund && S.invested != null && S.invested > 0 && worth > 0 ? Math.round(S.invested * l.shares * l.price / worth * 100) / 100 : null;
	const keep = /* @__PURE__ */ new Set();
	for (const l of lines) {
		const match = old.find((h) => l.symbol && h.symbol === l.symbol || h.name.toLowerCase() === l.name.toLowerCase());
		const row = {
			account_id: acct.id,
			symbol: l.symbol,
			name: l.name,
			shares: l.shares,
			price: l.price,
			price_date: date,
			updated_at: (/* @__PURE__ */ new Date()).toISOString(),
			...costOf(l) != null ? { cost: costOf(l) } : {}
		};
		if (match) {
			keep.add(match.id);
			const u = await T$1("holdings").update(row).eq("id", match.id);
			if (u.error) throw new Error(u.error.message);
		} else {
			const i = await T$1("holdings").insert({
				...row,
				notes: "From a statement in the Shoebox"
			});
			if (i.error) throw new Error(i.error.message);
		}
	}
	const gone = old.filter((h) => !keep.has(h.id)).map((h) => h.id);
	if (gone.length) await T$1("holdings").delete().in("id", gone);
	const total = lines.reduce((t, l) => t + l.shares * l.price, 0);
	const fundCount = S.lines.length;
	const summary = `${S.accountType ? `A ${S.accountType}` : S.retirement ? "A retirement" : "An investment"} statement${S.issuer ? ` from ${S.issuer}` : ""}${S.last4 ? ` (ending ${S.last4})` : ""}: ${fmtMoney(total)}${S.date ? ` on ${fmtDate(S.date)}` : ""}.${added ? ` Added ${acct.name} to Investments.` : ` Updated ${acct.name} in Investments.`}${fundCount ? ` ${fundCount} fund${fundCount === 1 ? "" : "s"} and their prices.` : ""}${S.invested != null && S.invested > 0 ? ` Put in so far: ${fmtMoney(S.invested)}.` : ""} Net Worth shows it.`;
	await T$1("shoebox_items").update({
		status: "done",
		kind: "investment",
		account_id: acct.id,
		target_type: "investment",
		target_id: acct.id,
		summary,
		error: null
	}).eq("id", id);
}
/**
* SHA-256 of some bytes, as hex. Uses the browser's own when it has it; pages opened over plain
* http (the office server at http://192.168.x.x) don't get it, so this does the same in plain
* JavaScript. Same result either way.
*/
var K = new Uint32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
function sha256Js(data) {
	const len = data.length;
	const total = Math.ceil((len + 9) / 64) * 64;
	const m = new Uint8Array(total);
	m.set(data);
	m[len] = 128;
	const dv = new DataView(m.buffer);
	dv.setUint32(total - 8, Math.floor(len / 536870912));
	dv.setUint32(total - 4, len << 3 >>> 0);
	const h = new Uint32Array([
		1779033703,
		3144134277,
		1013904242,
		2773480762,
		1359893119,
		2600822924,
		528734635,
		1541459225
	]);
	const w = /* @__PURE__ */ new Uint32Array(64);
	const rot = (x, n) => x >>> n | x << 32 - n;
	for (let o = 0; o < total; o += 64) {
		for (let i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
		for (let i = 16; i < 64; i++) {
			const a = w[i - 15], b = w[i - 2];
			const s0 = rot(a, 7) ^ rot(a, 18) ^ a >>> 3;
			const s1 = rot(b, 17) ^ rot(b, 19) ^ b >>> 10;
			w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
		}
		let [a, b, c, d, e, f, g, hh] = h;
		for (let i = 0; i < 64; i++) {
			const t1 = hh + (rot(e, 6) ^ rot(e, 11) ^ rot(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
			const t2 = (rot(a, 2) ^ rot(a, 13) ^ rot(a, 22)) + (a & b ^ a & c ^ b & c) >>> 0;
			hh = g;
			g = f;
			f = e;
			e = d + t1 >>> 0;
			d = c;
			c = b;
			b = a;
			a = t1 + t2 >>> 0;
		}
		h[0] = h[0] + a >>> 0;
		h[1] = h[1] + b >>> 0;
		h[2] = h[2] + c >>> 0;
		h[3] = h[3] + d >>> 0;
		h[4] = h[4] + e >>> 0;
		h[5] = h[5] + f >>> 0;
		h[6] = h[6] + g >>> 0;
		h[7] = h[7] + hh >>> 0;
	}
	const out = /* @__PURE__ */ new Uint8Array(32);
	const ov = new DataView(out.buffer);
	for (let i = 0; i < 8; i++) ov.setUint32(i * 4, h[i]);
	return out;
}
async function sha256Hex(buf) {
	return [...globalThis.crypto?.subtle ? new Uint8Array(await globalThis.crypto.subtle.digest("SHA-256", buf)) : sha256Js(new Uint8Array(buf))].map((b) => b.toString(16).padStart(2, "0")).join("");
}
/**
* The Shoebox: drop bank and card statements, receipts, bills and checks in one place.
*
* For each file: is it the same file as before (fingerprint)? What is it (statements by file type;
* PDFs and photos by AI)? Then it goes where it belongs:
*   - statement → its bank or card account is found by the last 4 digits; the lines go into Bank
*     Feeds, and every line Tallkeep is sure of (a match in the books, or a remembered payee) is
*     recorded right away. The rest wait in Bank Feeds.
*   - receipt → Receipts, already read, ready to record with one click.
*   - bill → a bill to pay, when the vendor is known and the expense account can be guessed;
*     otherwise it waits here with the details filled in.
*   - check → waits here; one click opens it in Checks Received.
*   - loan or mortgage statement → the loan, its balance, and its payments split by themselves
*     (see loans.ts).
* Anything Tallkeep isn't sure of waits here ("needs you").
*/
var BUCKET = "receipts";
var T = (t) => db.from(t);
var waiting = [];
/** Files dropped on another page, for the Shoebox page to take in. */
function queueShoebox(files) {
	waiting = [...waiting, ...files];
}
function takeShoebox() {
	const f = waiting;
	waiting = [];
	return f;
}
var isTextBank = (f) => /\.(csv|ofx|qfx|qbo)$/i.test(f.name);
var canTake = (f) => isTextBank(f) || /^image\//.test(f.type) || /\.pdf$/i.test(f.name);
async function fingerprint(f) {
	return sha256Hex(await f.arrayBuffer());
}
var isDay = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? ""));
var money = (v) => v == null || v === "" || Number.isNaN(Number(v)) ? null : Math.abs(Number(v));
/** Take one file in. Returns the Shoebox item's id (or null when it was the same file again). */
async function takeIn(file, ctx) {
	const hash = await fingerprint(file);
	const { data: had } = await T("shoebox_items").select("id,archived_at").eq("hash", hash).maybeSingle();
	if (had) {
		if (had.archived_at) await setRemoved(had.id, false);
		return null;
	}
	const { data: co } = await db.rpc("active_company");
	const { data: u } = await db.auth.getUser();
	const text = isTextBank(file);
	const pdf = /\.pdf$/i.test(file.name);
	ctx.step(`${file.name}: saving…`);
	const ext = text ? (file.name.split(".").pop() ?? "txt").toLowerCase() : pdf ? "pdf" : "jpg";
	const path = `${String(co)}/shoebox/${crypto.randomUUID()}.${ext}`;
	const blob = text ? file : await shrinkForStorage(file);
	const mime = text ? "text/plain" : pdf ? "application/pdf" : "image/jpeg";
	const up = await db.storage.from(BUCKET).upload(path, blob, { contentType: mime });
	const { data: row, error } = await T("shoebox_items").insert({
		file_name: file.name,
		file_path: up.error ? null : path,
		mime,
		size: file.size,
		hash,
		created_by: u.user?.id,
		kind: text ? "statement" : "unknown"
	}).select("id").single();
	if (error) throw new Error(error.message);
	const id = row.id;
	try {
		await sortAndFile(id, file, ctx);
	} catch (e) {
		await T("shoebox_items").update({
			status: "failed",
			error: e.message
		}).eq("id", id);
	}
	return id;
}
/**
* A statement brought in from Bank Feeds: keep the file and list it in the Shoebox as done, so
* every statement is in one place. (Bank Feeds already brought the lines in.)
*/
async function keepInShoebox(file, accountId, summary) {
	try {
		const hash = await fingerprint(file);
		const { data: had } = await T("shoebox_items").select("id").eq("hash", hash).maybeSingle();
		if (had) return;
		const { data: co } = await db.rpc("active_company");
		const { data: u } = await db.auth.getUser();
		const text = isTextBank(file);
		const ext = text ? (file.name.split(".").pop() ?? "txt").toLowerCase() : "pdf";
		const path = `${String(co)}/shoebox/${crypto.randomUUID()}.${ext}`;
		const mime = text ? "text/plain" : "application/pdf";
		const up = await db.storage.from(BUCKET).upload(path, file, { contentType: mime });
		await T("shoebox_items").insert({
			file_name: file.name,
			file_path: up.error ? null : path,
			mime,
			size: file.size,
			hash,
			created_by: u.user?.id,
			kind: "statement",
			status: "done",
			account_id: accountId,
			target_type: "bank_import",
			summary: `${summary} (brought in from Bank Feeds)`
		});
	} catch {}
}
/** Work out what the file is, then put it where it belongs. */
async function sortAndFile(id, file, ctx) {
	if (isTextBank(file)) {
		const text = await file.text();
		const last4 = /<OFX>|<STMTTRN>/i.test(text) ? /<ACCTID>\s*[^<\s]*?(\d{4})\s*</i.exec(text)?.[1] ?? null : null;
		const acct = findAccount(ctx.accounts, last4, null);
		await T("shoebox_items").update({
			kind: "statement",
			ai: last4 ? { account_last4: last4 } : null
		}).eq("id", id);
		if (!acct) return void await needsYou(id, "statement", "A bank or card file. Which account is it for?");
		await fileStatement(id, file, acct, ctx);
		return;
	}
	ctx.step(`${file.name}: AI is looking at it…`);
	const pages = await fileToPages(file, 2, true);
	const r = JSON.parse(await aiRead({ data: {
		feature: "sort",
		images: pages
	} }));
	const kind = String(r["kind"] ?? "other");
	await T("shoebox_items").update({ ai: r }).eq("id", id);
	if (kind === "bank_statement" || kind === "card_statement") {
		await T("shoebox_items").update({ kind: "statement" }).eq("id", id);
		const acct = findAccount(ctx.accounts, r["account_last4"] ? String(r["account_last4"]) : null, kind === "card_statement" ? "credit_card" : "bank");
		if (!acct) return void await needsYou(id, "statement", `${kind === "card_statement" ? "A credit card" : "A bank"} statement${r["issuer"] ? ` from ${String(r["issuer"])}` : ""}${r["account_last4"] ? ` (ending ${String(r["account_last4"])})` : ""}. Which account is it for?`);
		await fileStatement(id, file, acct, ctx);
		return;
	}
	if (kind === "loan_statement") return void await fileLoan(id, r, ctx, file.name);
	if (kind === "investment_statement") {
		ctx.step(`${file.name}: reading the funds…`);
		const rr = JSON.parse(await aiRead({ data: {
			feature: "investment",
			images: await fileToPages(file, 8, true)
		} }));
		await T("shoebox_items").update({ ai: rr }).eq("id", id);
		await fileInvestment(id, rr, ctx, file.name);
		return;
	}
	if (kind === "receipt") return void await fileReceipt(id, r, ctx);
	if (kind === "bill") return void await fileBill(id, r, ctx, false);
	if (kind === "check") return void await needsYou(id, "check", `A check${r["payer"] ? ` from ${String(r["payer"])}` : ""}${money(r["amount"]) ? ` for $${money(r["amount"]).toFixed(2)}` : ""}. Open it in Checks Received to put it on their invoices.`);
	await needsYou(id, "unknown", `Not sure what this is${r["description"] ? ` (${String(r["description"])})` : ""}. Tell Tallkeep what it is.`);
}
async function needsYou(id, kind, summary) {
	await T("shoebox_items").update({
		status: "needs_you",
		kind,
		summary
	}).eq("id", id);
}
/** A bank or card account by the last 4 digits on the statement (only when exactly one fits). */
function findAccount(accounts, last4, kind) {
	const regs = accounts.filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	const pool = kind ? regs.filter((a) => a.kind === kind) : regs;
	if (last4) {
		const hits = regs.filter((a) => `${a.number ?? ""} ${a.name} ${a.description ?? ""}`.includes(last4));
		if (hits.length === 1) return hits[0];
	}
	return pool.length === 1 && kind ? pool[0] : null;
}
/** Bring a statement's lines into Bank Feeds, then record the sure ones. */
async function fileStatement(id, file, acct, ctx) {
	let lines;
	let warn = null;
	let begin = null;
	let end = null;
	if (isTextBank(file)) {
		const text = await file.text();
		lines = /<OFX>|<STMTTRN>/i.test(text) ? parseOfx(text) : parseBankCsv(text, false);
	} else {
		const r = await readStatement(file, acct.kind === "credit_card", (t) => ctx.step(`${file.name}: ${t}`));
		lines = r.lines;
		warn = offWarning(r);
		begin = r.begin;
		end = r.end;
	}
	if (typeof lines === "string") throw new Error(lines);
	if (!lines.length) {
		if (end != null && (begin == null || Math.abs(begin - end) < .005)) {
			await T("shoebox_items").update({
				status: "done",
				kind: "statement",
				account_id: acct.id,
				target_type: "bank_import",
				summary: `No activity in ${acct.name} on this statement; the balance stayed ${fmtMoney(end)}.`,
				error: null
			}).eq("id", id);
			return;
		}
		throw new Error("No lines found in this statement.");
	}
	ctx.step(`${file.name}: putting the lines in Bank Feeds…`);
	const soon = new Date(Date.now() + 432e6).toISOString().slice(0, 10);
	await db.from("bank_transactions").delete().eq("account_id", acct.id).eq("status", "new").gt("txn_date", soon).like("fit_id", "pdf:%");
	const count = async () => (await db.from("bank_transactions").select("id", {
		count: "exact",
		head: true
	}).eq("account_id", acct.id)).count ?? 0;
	const { data: have } = await db.from("bank_transactions").select("txn_date,amount,description,fit_id").eq("account_id", acct.id).gte("txn_date", lines.map((l) => l.txn_date).sort()[0]).lte("txn_date", lines.map((l) => l.txn_date).sort().at(-1));
	const head = (d) => (d ?? "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 14);
	const pool = /* @__PURE__ */ new Map();
	const ids = /* @__PURE__ */ new Set();
	for (const h of have ?? []) {
		if (h.fit_id) ids.add(h.fit_id);
		const k = `${h.txn_date}|${Number(h.amount).toFixed(2)}|${head(h.description)}`;
		pool.set(k, (pool.get(k) ?? 0) + 1);
	}
	lines = lines.filter((l) => {
		if (ids.has(l.fit_id)) return true;
		const k = `${l.txn_date}|${Number(l.amount).toFixed(2)}|${head(l.description)}`;
		const n = pool.get(k) ?? 0;
		if (n > 0) {
			pool.set(k, n - 1);
			return false;
		}
		return true;
	});
	const before = await count();
	const opened = begin != null && lines.length ? await openFromStatement(acct, begin, lines.map((l) => l.txn_date).sort()[0]) : null;
	const { error } = await db.from("bank_transactions").upsert(lines.map((p) => ({
		...p,
		account_id: acct.id
	})), {
		onConflict: "account_id,fit_id",
		ignoreDuplicates: true
	});
	if (error) throw new Error(error.message);
	const added = await count() - before;
	const sure = added > 0 ? await recordSure(acct.id, new Set(lines.map((l) => l.fit_id))) : {
		matched: 0,
		added: 0
	};
	const done = sure.matched + sure.added;
	const left = Math.max(0, added - done);
	await T("shoebox_items").update({
		status: "done",
		kind: "statement",
		account_id: acct.id,
		target_type: "bank_import",
		summary: added === 0 ? `All ${lines.length} lines were already in ${acct.name}.` : `${added} new lines in ${acct.name}${lines.length > added ? ` (${lines.length - added} were already there)` : ""}. ${done} recorded automatically${left ? `, ${left} wait for you in Bank Feeds` : ""}.${opened ? ` ${opened}` : ""}`,
		error: warn
	}).eq("id", id);
}
/**
* Opening balance from a new account's first statement: what it held (a card or loan: what was
* owed) the day before its first line, against Opening Balance Equity. Only when nothing at all
* was recorded in the account yet. Returns a sentence for the summary, or null.
*/
async function openFromStatement(acct, begin, firstDate) {
	const d = /* @__PURE__ */ new Date(`${firstDate}T12:00:00Z`);
	d.setUTCDate(d.getUTCDate() - 1);
	const day = d.toISOString().slice(0, 10);
	const memo = `Opening balance of ${acct.name}, from its first statement`;
	const { data: had } = await db.from("journal_lines").select("entry_id, journal_entries!inner(id, entry_date, source_type, memo)").eq("account_id", acct.id).eq("journal_entries.source_type", "opening").like("journal_entries.memo", "Opening balance of %, from its first statement");
	const auto = (had ?? []).map((r) => r.journal_entries).filter(Boolean);
	let moved = false;
	if (auto.length) {
		if (auto.some((e) => e.entry_date <= day)) return null;
		await db.from("journal_entries").delete().in("id", auto.map((e) => e.id));
		moved = true;
	} else {
		const used = await db.from("journal_lines").select("id", {
			count: "exact",
			head: true
		}).eq("account_id", acct.id);
		if (used.error || (used.count ?? 0) > 0) return null;
	}
	if (!begin) return moved ? `Opening balance moved back to this older statement ($0 on ${day}).` : null;
	const { data: eq } = await db.from("accounts").select("id").eq("key", "opening").maybeSingle();
	const equity = eq?.id;
	if (!equity) return null;
	const amt = Math.round(Math.abs(begin) * 100) / 100;
	const owed = acct.type === "liability";
	const debitAcct = begin > 0 !== owed;
	const { data: u } = await db.auth.getUser();
	const { data: e, error } = await db.from("journal_entries").insert({
		entry_date: day,
		memo,
		source_type: "opening",
		created_by: u.user?.id
	}).select("id").single();
	if (error || !e) return null;
	const { error: le } = await db.from("journal_lines").insert([{
		entry_id: e.id,
		account_id: acct.id,
		debit: debitAcct ? amt : 0,
		credit: debitAcct ? 0 : amt,
		memo: null
	}, {
		entry_id: e.id,
		account_id: equity,
		debit: debitAcct ? 0 : amt,
		credit: debitAcct ? amt : 0,
		memo: null
	}]);
	if (le) {
		await db.from("journal_entries").delete().eq("id", e.id);
		return null;
	}
	return `Opening balance ${fmtMoney(begin)} on ${day} set from this statement.`;
}
var daysApart = (a, b) => Math.abs(Date.parse(`${a}T12:00:00`) - Date.parse(`${b}T12:00:00`)) / 864e5;
/** Record every new line Tallkeep is sure of: a match in the books, or a remembered payee. */
async function recordSure(accountId, only) {
	const loans = await recordLoanPayments(accountId);
	const [{ data: t }, { data: l }, rules] = await Promise.all([
		db.from("bank_transactions").select("id,txn_date,amount,description,status,source_id,fit_id").eq("account_id", accountId).limit(5e3),
		db.rpc("account_lines", {
			_account: accountId,
			_to: null
		}),
		fetchAll("bank_rules", "id,contains,account_id")
	]);
	const txns = t ?? [];
	const lines = l ?? [];
	const used = new Set(txns.filter((x) => x.source_id).map((x) => x.source_id));
	let matched = 0;
	let added = 0;
	for (const x of txns.filter((y) => y.status === "new" && (!only || only.has(y.fit_id ?? "")))) {
		const hit = lines.filter((b) => !b.cleared && !used.has(b.item_key) && Math.abs(Number(b.amount) - Number(x.amount)) < .005 && daysApart(b.entry_date, x.txn_date) <= 10).sort((a, b) => daysApart(a.entry_date, x.txn_date) - daysApart(b.entry_date, x.txn_date))[0];
		if (hit) {
			used.add(hit.item_key);
			if (!(await db.from("bank_transactions").update({
				status: "matched",
				source_type: hit.source_type,
				source_id: hit.item_key
			}).eq("id", x.id)).error) {
				await db.from("cleared_items").upsert({
					account_id: accountId,
					item_key: hit.item_key
				}, { onConflict: "account_id,item_key" });
				matched++;
			}
			continue;
		}
		const r = ruleFor(rules, x.description);
		if (r) {
			const { error } = await db.rpc("add_bank_transaction", {
				_txn: x.id,
				_other: r.account_id,
				_memo: x.description ?? ""
			});
			if (!error) added++;
			else console.warn("[shoebox] couldn't record a line", error.message);
		}
	}
	return {
		matched,
		added: added + loans
	};
}
var vendorFor = (vendors, name) => name ? vendors.find((x) => x.name.toLowerCase().includes(name.toLowerCase()) || name.toLowerCase().includes(x.name.toLowerCase())) : void 0;
async function fileReceipt(id, r, ctx) {
	const { data: item } = await T("shoebox_items").select("file_path,file_name,mime").eq("id", id).single();
	const it = item;
	if (!it.file_path) throw new Error("The file couldn't be saved. Try again.");
	const vendor = r["vendor"] ? String(r["vendor"]) : r["issuer"] ? String(r["issuer"]) : null;
	const v = vendorFor(ctx.vendors, vendor);
	const rule = vendor ? ruleFor(ctx.rules, vendor) : null;
	const { data: u } = await db.auth.getUser();
	const { data: rec, error } = await T("receipts").insert({
		file_path: it.file_path,
		file_name: it.file_name,
		mime: it.mime,
		created_by: u.user?.id,
		status: "read",
		vendor_name: v?.name ?? vendor,
		vendor_id: v?.id ?? null,
		receipt_date: isDay(r["date"]) ? String(r["date"]) : null,
		total: money(r["total"]),
		tax: r["tax"] == null ? null : Number(r["tax"]),
		account_id: rule?.account_id ?? null,
		ai: r
	}).select("id").single();
	if (error) throw new Error(error.message);
	await T("shoebox_items").update({
		status: "done",
		kind: "receipt",
		target_type: "receipt",
		target_id: rec.id,
		summary: `Receipt${v?.name || vendor ? ` from ${v?.name ?? vendor}` : ""}${money(r["total"]) ? ` for $${money(r["total"]).toFixed(2)}` : ""}. Ready in Receipts: one click to record it.`
	}).eq("id", id);
}
/** The expense account to guess for a vendor: a remembered payee, or their last bill's account. */
async function guessAccount(ctx, vendorId, name) {
	const rule = name ? ruleFor(ctx.rules, name) : null;
	if (rule) return rule.account_id;
	if (!vendorId) return null;
	const { data } = await T("bills").select("id,bill_lines(account_id)").eq("vendor_id", vendorId).order("bill_date", { ascending: false }).limit(1);
	return (data ?? [])[0]?.bill_lines?.find((x) => x.account_id)?.account_id ?? null;
}
/** A bill: entered right away when the vendor is known and the account can be guessed. */
async function fileBill(id, r, ctx, force) {
	const name = r["vendor"] ? String(r["vendor"]) : r["issuer"] ? String(r["issuer"]) : null;
	const v = vendorFor(ctx.vendors, name);
	const draft = {
		vendor: v?.name ?? name ?? "",
		total: money(r["total"]),
		billDate: isDay(r["date"]) ? String(r["date"]) : null,
		dueDate: isDay(r["due_date"]) ? String(r["due_date"]) : null,
		ref: r["bill_number"] ? String(r["bill_number"]) : null,
		accountId: await guessAccount(ctx, v?.id ?? null, name)
	};
	await T("shoebox_items").update({
		kind: "bill",
		ai: {
			...r,
			draft
		}
	}).eq("id", id);
	if ((v || force) && draft.total && draft.accountId) return addBill(id, draft, ctx);
	await needsYou(id, "bill", `A bill${draft.vendor ? ` from ${draft.vendor}` : ""}${draft.total ? ` for $${draft.total.toFixed(2)}` : ""}${draft.dueDate ? `, due ${draft.dueDate}` : ""}. Check the details and add it.`);
}
/** Enter the bill (to pay later in Pay Bills). */
async function addBill(id, d, ctx) {
	if (!d.vendor.trim()) throw new Error("Type who the bill is from.");
	if (!d.total || d.total <= 0) throw new Error("Type the amount due.");
	if (!d.accountId) throw new Error("Choose what the bill is for (the expense account).");
	const v = vendorFor(ctx.vendors, d.vendor.trim());
	const { data: u } = await db.auth.getUser();
	const { data: bill, error } = await T("bills").insert({
		vendor_id: v?.id ?? null,
		vendor_name: v?.name ?? d.vendor.trim(),
		ref: d.ref,
		bill_date: d.billDate ?? (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"),
		due_date: d.dueDate,
		memo: "From the Shoebox",
		created_by: u.user?.id
	}).select("id").single();
	if (error) throw new Error(error.message);
	const billId = bill.id;
	const ln = await T("bill_lines").insert({
		bill_id: billId,
		line_no: 1,
		account_id: d.accountId,
		description: d.ref ? `Bill ${d.ref}` : "Bill",
		amount: d.total
	});
	if (ln.error) throw new Error(ln.error.message);
	await T("shoebox_items").update({
		status: "done",
		kind: "bill",
		target_type: "bill",
		target_id: billId,
		summary: `Bill from ${v?.name ?? d.vendor} for $${d.total.toFixed(2)}${d.dueDate ? `, due ${d.dueDate}` : ""}. Entered in Bills; pay it in Pay Bills.`
	}).eq("id", id);
}
/** The file back from storage (to read it again as something else). */
async function fileOf(item) {
	if (!item.file_path) throw new Error("The file wasn't saved. Drop it in again.");
	const { data, error } = await db.storage.from(BUCKET).download(item.file_path);
	if (error || !data) throw new Error(error?.message ?? "File not found.");
	return new File([data], item.file_name, { type: item.mime ?? data.type });
}
/** "It's a …": file it again as the kind the person picked. */
async function fileAs(item, kind, ctx, accountId) {
	await T("shoebox_items").update({
		status: "reading",
		error: null
	}).eq("id", item.id);
	try {
		const file = await fileOf(item);
		if (kind === "statement") {
			const acct = ctx.accounts.find((a) => a.id === accountId);
			if (!acct) throw new Error("Pick the account.");
			await fileStatement(item.id, file, acct, ctx);
			return;
		}
		if (kind === "investment") {
			ctx.step(`${item.file_name}: reading the funds…`);
			const r = JSON.parse(await aiRead({ data: {
				feature: "investment",
				images: await fileToPages(file, 8, true)
			} }));
			await T("shoebox_items").update({ ai: r }).eq("id", item.id);
			await fileInvestment(item.id, r, ctx, item.file_name);
			return;
		}
		if (kind === "loan") {
			const want = "loan_statement";
			let r = item.ai ?? {};
			if (String(r["kind"]) !== want) {
				ctx.step(`${item.file_name}: AI is reading it…`);
				r = JSON.parse(await aiRead({ data: {
					feature: "sort",
					images: await fileToPages(file, 2, true),
					hint: "This is a loan or mortgage statement (kind loan_statement)."
				} }));
				await T("shoebox_items").update({ ai: r }).eq("id", item.id);
			}
			await fileLoan(item.id, r, ctx, item.file_name);
			return;
		}
		let r = item.ai ?? {};
		if (!r["vendor"] && !r["total"] && !/^text\//.test(item.mime ?? "")) {
			ctx.step(`${item.file_name}: AI is reading it…`);
			r = JSON.parse(await aiRead({ data: {
				feature: "receipt",
				images: await fileToPages(file, 3, true)
			} }));
		}
		if (kind === "receipt") await fileReceipt(item.id, r, ctx);
		else await fileBill(item.id, r, ctx, false);
	} catch (e) {
		await T("shoebox_items").update({
			status: "needs_you",
			error: e.message
		}).eq("id", item.id);
		throw e;
	}
}
async function skipItem(id) {
	await T("shoebox_items").update({ status: "skipped" }).eq("id", id);
}
/** What's waiting for you (or being read now): always all of it. */
async function loadWaiting() {
	const { data, error } = await T("shoebox_items").select("*").in("status", [
		"needs_you",
		"failed",
		"reading"
	]).is("archived_at", null).order("created_at", { ascending: false }).limit(500);
	if (error) throw new Error(error.message);
	return data ?? [];
}
/** Done and skipped items, newest first, with how many there are in all. */
async function loadDone(f) {
	let q = T("shoebox_items").select("*", { count: "exact" }).in("status", ["done", "skipped"]).order("created_at", { ascending: false }).limit(f.limit);
	q = f.removed ? q.not("archived_at", "is", null) : q.is("archived_at", null);
	if (f.kind) q = q.eq("kind", f.kind);
	const words = f.q.replace(/[,()*%"\\]/g, " ").trim();
	if (words) {
		const n = /^\$?[\d.]+$/.test(words.replace(/,/g, "")) ? Number(words.replace(/[$,]/g, "")) : NaN;
		const alts = [words];
		if (Number.isFinite(n) && n >= 1e3) alts.push(n.toLocaleString("en-US", { maximumFractionDigits: 2 }));
		q = q.or(alts.flatMap((w) => [`file_name.ilike."*${w}*"`, `summary.ilike."*${w}*"`]).join(","));
	} else if (!f.older && !f.removed) q = q.gte("created_at", (/* @__PURE__ */ new Date(Date.now() - 7776e6)).toISOString());
	const { data, error, count } = await q;
	if (error) throw new Error(error.message);
	return {
		rows: data ?? [],
		count: count ?? 0
	};
}
/** Take an item off the list (the file stays) or put it back. */
async function setRemoved(id, removed) {
	const { error } = await T("shoebox_items").update({ archived_at: removed ? (/* @__PURE__ */ new Date()).toISOString() : null }).eq("id", id);
	if (error) throw new Error(error.message);
}
/** Delete the item and its file for good. */
async function deleteItem(it) {
	if (it.file_path) await db.storage.from(BUCKET).remove([it.file_path]);
	const { error } = await T("shoebox_items").delete().eq("id", it.id);
	if (error) throw new Error(error.message);
}
/** A check you got, put in the bank: a deposit into the bank account, from the payer, to the
*  income category picked (Paychecks, Refunds…). It matches the bank line when it comes in. */
async function depositCheck(item, d) {
	if (!d.bankId) throw new Error("Pick the bank account it went into.");
	if (!d.accountId) throw new Error("Pick what the money is for (the category).");
	if (!(d.amount > 0)) throw new Error("Type the check's amount.");
	if (!isDay(d.date)) throw new Error("Pick the date it was deposited.");
	const { data: u } = await db.auth.getUser();
	const ai = item.ai ?? {};
	const no = ai["check_number"] ? `Check ${String(ai["check_number"])}` : "Check";
	const { data: dep, error } = await T("deposits").insert({
		account_id: d.bankId,
		deposit_date: d.date,
		memo: `${no}${d.payer ? ` from ${d.payer}` : ""}`,
		created_by: u.user?.id
	}).select("id").single();
	if (error) throw new Error(error.message);
	const depId = dep.id;
	const { error: le } = await T("deposit_lines").insert({
		deposit_id: depId,
		account_id: d.accountId,
		name: d.payer || null,
		description: ai["memo"] ? String(ai["memo"]) : no,
		amount: Math.round(d.amount * 100) / 100
	});
	if (le) {
		await T("deposits").delete().eq("id", depId);
		throw new Error(le.message);
	}
	await T("shoebox_items").update({
		status: "done",
		kind: "check",
		account_id: d.bankId,
		target_type: "deposit",
		target_id: depId,
		error: null,
		summary: `Deposited a check${d.payer ? ` from ${d.payer}` : ""} for $${d.amount.toFixed(2)} on ${d.date}. It's in the check register, and matches the bank line when it comes in.`
	}).eq("id", item.id);
}
//#endregion
export { takeIn as _, depositCheck as a, keepInShoebox as c, offWarning as d, openFromStatement as f, skipItem as g, setRemoved as h, deleteItem as i, loadDone as l, readStatement as m, addBill as n, fileAs as o, queueShoebox as p, canTake as r, fileOf as s, BUCKET as t, loadWaiting as u, takeShoebox as v };
