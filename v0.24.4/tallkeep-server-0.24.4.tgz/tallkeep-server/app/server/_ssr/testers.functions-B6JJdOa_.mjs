import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as getRequest } from "./request-response-C-WzAr0X.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/testers.functions-B6JJdOa_.js
/**
* Testers before launch, and "Report a problem".
*
* People ask to test on /testers. Tallkeep (Admin → Testers) checks the business and approves or
* declines. Approving makes a free license key that works until TESTER_UNTIL, plus a code for
* 50% off when they buy, and emails both. Problems reported from inside Tallkeep (Help → Report a
* problem) are kept here and emailed to hello@tallkeep.com.
*/
/** Tester licenses work through this day. */
var TESTER_UNTIL = "2027-01-31";
var TESTER_DISCOUNT_PCT = 50;
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var clean = (v, max) => String(v ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, max);
var USES = [
	"inventory",
	"sales",
	"accounting",
	"purchasing",
	"properties",
	"personal"
];
var FREE_MAIL = /@(gmail|yahoo|hotmail|outlook|live|aol|icloud|me|msn|proton|protonmail)\./i;
/** Requests per internet address in the last hour (kept in this server's memory). */
var recent = /* @__PURE__ */ new Map();
function fromHere() {
	let ip = "";
	try {
		const h = getRequest()?.headers;
		ip = h?.get("cf-connecting-ip") || h?.get("x-real-ip") || (h?.get("x-forwarded-for") ?? "").split(",")[0].trim() || "";
	} catch {
		return true;
	}
	if (!ip) return true;
	const now = Date.now();
	const list = (recent.get(ip) ?? []).filter((t) => now - t < 36e5);
	if (list.length >= 3) return false;
	list.push(now);
	recent.set(ip, list);
	if (recent.size > 5e3) recent.clear();
	return true;
}
var askToTest_createServerFn_handler = createServerRpc({
	id: "00611f6528b281a5c3872f2e4bc5790e9e151ff9e66a0d314caa44bf6b1514d9",
	name: "askToTest",
	filename: "src/lib/testers.functions.ts"
}, (opts) => askToTest.__executeServer(opts));
var askToTest = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(askToTest_createServerFn_handler, async ({ data }) => {
	if (data.fax) return { ok: true };
	const name = clean(data.name, 120);
	const email = clean(data.email, 200).toLowerCase();
	const company = clean(data.company, 160);
	if (!name) throw new Error("Type your name.");
	if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Type a valid email.");
	if (!company) throw new Error("Type your business name.");
	let website = clean(data.website, 200);
	if (website && !/^https?:\/\//i.test(website)) website = `https://${website}`;
	const db = await admin();
	const { data: had } = await db.from("tester_requests").select("id,status").eq("email", email).order("created_at", { ascending: false }).limit(1);
	if ((had ?? []).some((r) => r.status !== "declined")) return {
		ok: true,
		again: true
	};
	if (!fromHere()) throw new Error("You've asked a few times just now. Try again in an hour.");
	const { count } = await db.from("tester_requests").select("id", {
		count: "exact",
		head: true
	}).gte("created_at", (/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString());
	if ((count ?? 0) > 100) throw new Error("Many people are asking right now. Try again in an hour.");
	const row = {
		name,
		email,
		company,
		website: website || null,
		phone: clean(data.phone, 40) || null,
		location: clean(data.location, 120) || null,
		business: clean(data.business, 300) || null,
		uses: (data.uses ?? []).filter((u) => USES.includes(u)),
		people: Math.min(1e4, Math.max(0, Math.floor(Number(data.people) || 0))) || null,
		now_using: clean(data.nowUsing, 120) || null,
		setup: [
			"windows",
			"synology",
			"online"
		].includes(String(data.setup)) ? String(data.setup) : null,
		notes: clean(data.notes, 2e3) || null
	};
	const { error } = await db.from("tester_requests").insert(row);
	if (error) throw new Error(error.message);
	const { sendTallkeepMail } = await import("./license.server-Bu3IQdFy.mjs");
	await sendTallkeepMail({
		to: process.env["LICENSE_COPY_TO"] || "hello@tallkeep.com",
		replyTo: email,
		subject: `Early access request: ${company}`,
		text: [
			`${name} (${email}) asks for early access to Tallkeep.`,
			`Business: ${company}${website ? ` · ${website}` : ""}`,
			row.business ? `Does: ${row.business}` : "",
			row.location ? `Where: ${row.location}` : "",
			row.phone ? `Phone: ${row.phone}` : "",
			`Wants: ${row.uses.join(", ") || "-"} · people: ${row.people ?? "-"} · uses now: ${row.now_using ?? "-"} · on: ${row.setup ?? "-"}`,
			row.notes ? `\n${row.notes}` : "",
			"",
			"Approve or decline: https://app.tallkeep.com/admin/testers"
		].filter(Boolean).join("\n")
	}).catch(() => null);
	return { ok: true };
});
async function owner(userId) {
	const { requireOwner } = await import("./admin.functions-COu1nGjr.mjs");
	await requireOwner(userId);
	return admin();
}
var listTesters_createServerFn_handler = createServerRpc({
	id: "e494d86b25d6cb1e5b47bb29942a09b5106938cc3713eabb435e0244de7fe085",
	name: "listTesters",
	filename: "src/lib/testers.functions.ts"
}, (opts) => listTesters.__executeServer(opts));
var listTesters = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listTesters_createServerFn_handler, async ({ context }) => {
	const { data, error } = await (await owner(context.userId)).from("tester_requests").select("*").order("created_at", { ascending: false }).limit(500);
	if (error) throw new Error(error.message);
	return (data ?? []).map((r) => ({
		...r,
		freeEmail: FREE_MAIL.test(r.email),
		emailMatchesSite: !!r.website && (() => {
			try {
				const host = new URL(r.website).hostname.replace(/^www\./, "").toLowerCase();
				return r.email.toLowerCase().endsWith(`@${host}`);
			} catch {
				return false;
			}
		})()
	}));
});
var CODE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
var newCode = () => `TEST-${[...crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(6))].map((x) => CODE[x % 32]).join("")}`;
var reviewTester_createServerFn_handler = createServerRpc({
	id: "b8ba26946ba21d048bed7a9b47519e0bd6e1457294f097774b028d2543b4a032",
	name: "reviewTester",
	filename: "src/lib/testers.functions.ts"
}, (opts) => reviewTester.__executeServer(opts));
var reviewTester = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(reviewTester_createServerFn_handler, async ({ data, context }) => {
	const db = await owner(context.userId);
	const { data: r0 } = await db.from("tester_requests").select("*").eq("id", data.id).maybeSingle();
	const r = r0;
	if (!r) throw new Error("That request is gone.");
	if (data.action === "decline") {
		await db.from("tester_requests").update({
			status: "declined",
			reviewed_at: (/* @__PURE__ */ new Date()).toISOString()
		}).eq("id", r.id);
		return {
			ok: true,
			mailed: false,
			why: ""
		};
	}
	const { createLicense, sendTallkeepMail } = await import("./license.server-Bu3IQdFy.mjs");
	let licenseId = r.license_id;
	let key = "";
	let code = r.code;
	if (!licenseId) {
		const made = await createLicense(db, {
			to: r.company,
			email: r.email,
			companies: 3,
			users: 10,
			updatesUntil: TESTER_UNTIL,
			expires: TESTER_UNTIL,
			computers: 1,
			notes: `Tester (${r.name})`,
			createdBy: context.userId
		});
		licenseId = made.id;
		key = made.key;
		code = code ?? newCode();
		await db.from("tester_requests").update({
			status: "approved",
			reviewed_at: (/* @__PURE__ */ new Date()).toISOString(),
			license_id: licenseId,
			code
		}).eq("id", r.id);
	} else {
		const { data: l } = await db.from("desktop_licenses").select("license_key").eq("id", licenseId).maybeSingle();
		key = l?.license_key ?? "";
	}
	const until = (/* @__PURE__ */ new Date(`${TESTER_UNTIL}T12:00:00`)).toLocaleDateString("en-US", {
		month: "long",
		day: "numeric",
		year: "numeric"
	});
	const sent = await sendTallkeepMail({
		to: r.email,
		subject: "Welcome to Tallkeep Early Access: your free license",
		text: [
			`Hello ${r.name},`,
			"",
			`Welcome to Tallkeep Early Access, and thank you for helping us make it better! Your free license works until ${until}.`,
			"",
			"Your license key (copy all of it):",
			"",
			key,
			"",
			`License number: ${licenseId}. It covers up to 3 companies and 10 people, on 1 office computer.`,
			"",
			"Getting started:",
			`1. Download Tallkeep on the computer that will keep your books: ${data.origin}/api/public/download`,
			"2. Install it and create your company. If Windows says it protected your PC, click More info, then Run anyway.",
			"3. Open Settings → Plan & computer, paste the key and press Save the license key.",
			`   Running a Synology or Linux server instead? See ${data.origin}/manual/docker-synology-install`,
			"",
			"Found something that doesn't work right? Press F1 (or Help) in Tallkeep, then Report a problem. It tells us which page you were on, so we can fix it fast.",
			"",
			`When you decide to keep Tallkeep, you get ${TESTER_DISCOUNT_PCT}% off. Buy at ${data.origin}/buy?code=${code} (your code: ${code}).`,
			"",
			`The manual: ${data.origin}/manual`,
			"",
			"Thank you,",
			"Tallkeep"
		].join("\n")
	});
	return {
		ok: true,
		mailed: sent.ok,
		why: sent.why
	};
});
async function testerCode(code) {
	const c = String(code ?? "").trim().toUpperCase();
	if (!/^TEST-[A-Z0-9]{6}$/.test(c)) return null;
	const { data } = await (await admin()).from("tester_requests").select("id,code,status,code_used_at,company,code_session").eq("code", c).maybeSingle();
	const r = data;
	if (!r || r.status !== "approved" || r.code_used_at) return null;
	return r;
}
var checkTesterCode_createServerFn_handler = createServerRpc({
	id: "12384f99b5b064dc9d8791957ad225d3e81cc320063f1a7f3a36680e2d998e01",
	name: "checkTesterCode",
	filename: "src/lib/testers.functions.ts"
}, (opts) => checkTesterCode.__executeServer(opts));
var checkTesterCode = createServerFn({ method: "GET" }).inputValidator((d) => ({ code: String(d.code ?? "") })).handler(checkTesterCode_createServerFn_handler, async ({ data }) => {
	return await testerCode(data.code) ? {
		ok: true,
		pct: TESTER_DISCOUNT_PCT
	} : {
		ok: false,
		pct: 0
	};
});
async function saveProblem(d) {
	const message = clean(d.message, 8e3);
	if (!message) throw new Error("Tell us what went wrong.");
	const pic = d.picture && /^image\/(png|jpe?g|webp|gif)$/.test(d.picture.type) && d.picture.base64.length < 7e6 ? d.picture : null;
	let licenseId = null;
	if (d.licenseKey) {
		const { keyId } = await import("./license.server-Bu3IQdFy.mjs");
		licenseId = await keyId(String(d.licenseKey)).catch(() => null);
	}
	const row = {
		email: clean(d.email, 200) || null,
		name: clean(d.name, 120) || null,
		company: clean(d.company, 160) || null,
		license_id: licenseId,
		edition: clean(d.edition, 20) || null,
		version: clean(d.version, 40) || null,
		page: clean(d.page, 300) || null,
		message,
		has_picture: !!pic
	};
	const db = await admin();
	const { count } = await db.from("problem_reports").select("id", {
		count: "exact",
		head: true
	}).gte("created_at", (/* @__PURE__ */ new Date(Date.now() - 36e5)).toISOString());
	if ((count ?? 0) > 200) throw new Error("Too many reports right now. Try again in an hour.");
	const { error } = await db.from("problem_reports").insert(row);
	if (error) throw new Error(error.message);
	const { sendTallkeepMail } = await import("./license.server-Bu3IQdFy.mjs");
	await sendTallkeepMail({
		to: process.env["LICENSE_COPY_TO"] || "hello@tallkeep.com",
		...row.email ? { replyTo: row.email } : {},
		subject: `Problem report: ${row.company ?? row.email ?? "someone"} · ${row.page ?? ""}`.slice(0, 180),
		text: [
			message,
			"",
			`From: ${row.name ?? "-"} <${row.email ?? "-"}> · ${row.company ?? "-"}`,
			`Page: ${row.page ?? "-"}`,
			`Tallkeep: ${row.edition ?? "-"} ${row.version ?? ""}${licenseId ? ` · license ${licenseId}` : ""}`,
			"",
			"All reports: https://app.tallkeep.com/admin/testers"
		].join("\n"),
		...pic ? { attachments: [{
			filename: pic.name || "picture.png",
			content: pic.base64
		}] } : {}
	}).catch(() => null);
	return { ok: true };
}
var listProblems_createServerFn_handler = createServerRpc({
	id: "a0fe38d0ee0bb219de28cfe57f964c6a21fe31a49f0ec1912afe2e12dbe0c9df",
	name: "listProblems",
	filename: "src/lib/testers.functions.ts"
}, (opts) => listProblems.__executeServer(opts));
var listProblems = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listProblems_createServerFn_handler, async ({ context }) => {
	const { data, error } = await (await owner(context.userId)).from("problem_reports").select("*").order("created_at", { ascending: false }).limit(500);
	if (error) throw new Error(error.message);
	return data ?? [];
});
var setProblem_createServerFn_handler = createServerRpc({
	id: "889f4f23e0f328174ed54f2f0fbd7ecb2330a920d633a86ed599a3a931c44695",
	name: "setProblem",
	filename: "src/lib/testers.functions.ts"
}, (opts) => setProblem.__executeServer(opts));
var setProblem = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(setProblem_createServerFn_handler, async ({ data, context }) => {
	const db = await owner(context.userId);
	if (![
		"new",
		"fixed",
		"not_a_bug"
	].includes(data.status)) throw new Error("Pick a status.");
	await db.from("problem_reports").update({ status: data.status }).eq("id", data.id);
	return { ok: true };
});
var reportProblem_createServerFn_handler = createServerRpc({
	id: "2b55125109e43275df9d428a1a815dc1fc4a26ae3c1c4a252977a8c23afab6c6",
	name: "reportProblem",
	filename: "src/lib/testers.functions.ts"
}, (opts) => reportProblem.__executeServer(opts));
var reportProblem = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(reportProblem_createServerFn_handler, async ({ data }) => saveProblem({
	...data,
	edition: "online",
	licenseKey: ""
}));
//#endregion
export { askToTest_createServerFn_handler, checkTesterCode_createServerFn_handler, listProblems_createServerFn_handler, listTesters_createServerFn_handler, reportProblem_createServerFn_handler, reviewTester_createServerFn_handler, setProblem_createServerFn_handler };
