//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DQsWVSz6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-B3ydbbRX.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-7LncpXQK.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BcHQOCfI.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3ydbbRX.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DIFx_-qn.js",
			"/assets/log-out-CwsskY-z.js",
			"/assets/testers.functions-BfjjUOAb.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CIVtMPEP.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DZ7rIFd-.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-B24sHxQO.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/dist-DsJ21JMO.js",
			"/assets/dialog-Dblrtz2c.js",
			"/assets/queries-CNxCey3o.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/label-BmIybDoS.js",
			"/assets/textarea-DffArwi-.js",
			"/assets/shoebox-BvMwY2D3.js",
			"/assets/company-Bob9Ow-V.js",
			"/assets/reports-CzmJI1y4.js",
			"/assets/access-CVnIcuQf.js",
			"/assets/LicenseCard-PeKNjPOX.js",
			"/assets/Logo-CBLNjY2Z.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-8GmTTPuF.js",
			"/assets/log-out-CwsskY-z.js",
			"/assets/admin.functions-yMZQdCi8.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CBLNjY2Z.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-_TybevUq.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/label-BmIybDoS.js",
			"/assets/Logo-CBLNjY2Z.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-ClkFdDxj.js",
			"/assets/testers.functions-BfjjUOAb.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/buy.functions-D7pXVhs6.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DS_U7fCI.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/downloads.functions-DoTtFugt.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-ndzI3mf7.js",
			"/assets/testers.functions-BfjjUOAb.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/textarea-DffArwi-.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DOc3lRJn.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/label-BmIybDoS.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-gp0HoN-b.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/label-BmIybDoS.js",
			"/assets/Logo-CBLNjY2Z.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BsdkYH33.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/upgrade.functions-BQRQRhTW.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-DiMh2Bp1.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/label-BmIybDoS.js",
			"/assets/Logo-CBLNjY2Z.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-Br4nMBlN.js",
			"/assets/select-C71up0XN.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DAZ_VrEG.js", "/assets/StockDocList-BGsm3bm7.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CJggPXRc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/ai-D53f0J1x.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-zmkUqe4u.js",
			"/assets/BankConnections-DeI5zWg2.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CGLKlec-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-sMuzhvsL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DeI5zWg2.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/ai-D53f0J1x.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-BO7W-SPi.js",
			"/assets/TxnEditor-CzCNSo_f.js",
			"/assets/feedWaiting-DxAZiDYL.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BXyEPgzu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DUTwOa74.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/personal-BEt7GmdB.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/WhoPicker-CPUpKz7X.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BNMVJpfO.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-Cn6_WuIn.js", "/assets/AccountRegister-DSIyAdYl.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Cn7xkOG1.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-C_tDtKeF.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/money-BvkCtNYa.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BlhmI8qt.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-D53f0J1x.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BVNaXHN_.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-lJ0Ij8Rt.js", "/assets/StockDocList-BGsm3bm7.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-BD4o_Igb.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-vhuutkDJ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CsafVAPO.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-D6iiOO-S.js", "/assets/PartyList-Dn1txoSX.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DN-J06Qo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CIiZZvvA.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/storage.functions-Bjb9fPU7.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-rC5T1M42.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DAxyGCGh.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BjqWjS1C.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DPZaNn6a.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-C8E1CBz-.js", "/assets/ChangeHistory-DnnDukWy.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CLOQ1ewd.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/members-Dwup4x0_.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-C1gcFmZ4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/personal-BEt7GmdB.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/WhoPicker-CPUpKz7X.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DjbfkFE4.js", "/assets/SalesList-G_1lPyQH.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-C62ahrwy.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-6_1jBz4c.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BlhQcXGV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CgkHFUFU.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/loans-BO7W-SPi.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-4Bjj5cW6.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-BJ3reDJa.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CFV_4vSX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/personal-BEt7GmdB.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/WhoPicker-CPUpKz7X.js",
			"/assets/reminders-Du1bvh1W.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BBJPuUkP.js",
			"/assets/select-C71up0XN.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-kaG5Dj-Z.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/personal-BEt7GmdB.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/WhoPicker-CPUpKz7X.js",
			"/assets/generateCategoricalChart-DnkKzEUD.js",
			"/assets/Area-Bb21eOQ5.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-B9Ma2wxU.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/generateCategoricalChart-DnkKzEUD.js",
			"/assets/PlCharts-BjqWjS1C.js",
			"/assets/BarChart-CP7SqX_o.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DSTNuDTc.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-C9uShsrw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BPpgfeXP.js",
			"/assets/createServerFn-BkwjDrYc.js",
			"/assets/auth-middleware-DhMIl7jt.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/storage.functions-Bjb9fPU7.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-YLFGNHyc.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Jm6x8y4-.js",
			"/assets/select-C71up0XN.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/checkbox-0IoICtV1.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CKtmQ2Eg.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DWuIwf-v.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-C71up0XN.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-CIWJGPS0.js", "/assets/SalesList-G_1lPyQH.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BSYknwH_.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/ai-D53f0J1x.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bjb9fPU7.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-Bp2GWOio.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/money-BvkCtNYa.js",
			"/assets/badge-Bs0raSH4.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-AobL99dq.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BNsCxRi8.js", "/assets/AccountRegister-DSIyAdYl.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-8Oi6RmON.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/MoneyAccountPick-dgObaJoY.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-B2eG90bj.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-jbl8PkAv.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/RepeatInvoice-B585S2xy.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BUQeE-QH.js",
			"/assets/select-C71up0XN.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DnkKzEUD.js",
			"/assets/BarChart-CP7SqX_o.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BpEiCVYZ.js", "/assets/SalesList-G_1lPyQH.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CXYxS8Fx.js", "/assets/SalesList-G_1lPyQH.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BAJPsb7i.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-Cq0bWZQV.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/serials-DGLPqOJ9.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CcQGCFIk.js",
			"/assets/createServerFn-BkwjDrYc.js",
			"/assets/auth-middleware-DhMIl7jt.js",
			"/assets/select-C71up0XN.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-aJ1SsTzZ.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DWkFYXFc.js",
			"/assets/switch-BJ3reDJa.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-CsafVAPO.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-Ub3Zp4pi.js",
			"/assets/footers-BWLCJDOZ.js",
			"/assets/PrintFrame-C4eIjjdP.js",
			"/assets/checkbox-0IoICtV1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-CkA5HQLN.js",
			"/assets/FeaturePicker-COcFij6J.js",
			"/assets/support-Dn99NoKk.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BfEOgLHV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/FeaturePicker-COcFij6J.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DuU_JVY1.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-iYxZWRL6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/photos-Ub3Zp4pi.js",
			"/assets/stockmove-C_zOhL83.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-Bt7kCxwk.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/loans-BO7W-SPi.js",
			"/assets/feedWaiting-DxAZiDYL.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bjb9fPU7.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-BfiIfzO1.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/PrintFrame-C4eIjjdP.js",
			"/assets/DocPdf-BKT0bAcj.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-D5AIqzWL.js",
			"/assets/createServerFn-BkwjDrYc.js",
			"/assets/auth-middleware-DhMIl7jt.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/MoneyAccountPick-dgObaJoY.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Dn99NoKk.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BIDQS6Es.js",
			"/assets/select-C71up0XN.js",
			"/assets/StockDialogs-iYxZWRL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/stockmove-C_zOhL83.js",
			"/assets/checkbox-0IoICtV1.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DreVgvKR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/members-Dwup4x0_.js",
			"/assets/WhoPicker-CPUpKz7X.js",
			"/assets/reminders-Du1bvh1W.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-9TWmvDPr.js",
			"/assets/select-C71up0XN.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/tickets.functions-BFrcEVMJ.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-_SFhGwbs.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Dn99NoKk.js",
			"/assets/support.functions--f8WoB86.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Dx7skC59.js", "/assets/StockDocList-BGsm3bm7.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DXfzjhz6.js", "/assets/PartyList-Dn1txoSX.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B6OcyOVe.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/tickets.functions-BFrcEVMJ.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DLNF3Pvs.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/workorders-oLSRkvqr.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BRmonzqj.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BtvmBPa5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/AdminAccount-DO_fGnz4.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-C62N7suN.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/downloads.functions-DoTtFugt.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-XzFcaQ2S.js",
			"/assets/createServerFn-BkwjDrYc.js",
			"/assets/auth-middleware-DhMIl7jt.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-COR-STO4.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Cw2JJmXe.js",
			"/assets/testers.functions-BfjjUOAb.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-D47NMhKW.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-SlmYFsJM.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-D7pXVhs6.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-Cz6uoZ9s.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/textarea-DffArwi-.js",
			"/assets/support.functions--f8WoB86.js",
			"/assets/HelpParts-BpJJC72D.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BFq7hxcl.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CuPFFwq4.js",
			"/assets/manual._slug-BNmZ28jc.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BZM_8XNI.js",
			"/assets/createServerFn-BkwjDrYc.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CFHYC9K8.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-BQRQRhTW.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CoNkTI-2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-D53f0J1x.js",
			"/assets/personal-BEt7GmdB.js",
			"/assets/reminders-Du1bvh1W.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-ChMTK7Dk.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/AdminAccount-DO_fGnz4.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BnCXH_ch.js", "/assets/ManualFrame-CuPFFwq4.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-COcT62BB.js", "/assets/AccountRegister-DSIyAdYl.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DIX6JwkP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/OriginalLink-D4-2zG4Q.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/realestate-CEYVZakM.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Ba3rWlLp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BXK6PXBj.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/realestate-CEYVZakM.js",
			"/assets/money-BvkCtNYa.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B0L5OHmV.js",
			"/assets/select-C71up0XN.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/SideList-CBizh6GS.js",
			"/assets/PartyHistory-tlWp5C1S.js",
			"/assets/tabs-CehcIwlM.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-FC_PFxVv.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C71up0XN.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-aJ1SsTzZ.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DnnDukWy.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/SideList-CBizh6GS.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-CpMMyYuk.js",
			"/assets/MoneyAccountPick-dgObaJoY.js",
			"/assets/footers-BWLCJDOZ.js",
			"/assets/PrintFrame-C4eIjjdP.js",
			"/assets/serials-DGLPqOJ9.js",
			"/assets/SerialsBox-CKIbgX5A.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CfEKh__C.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-C71up0XN.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-iYxZWRL6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DnnDukWy.js",
			"/assets/switch-BJ3reDJa.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Bs0raSH4.js",
			"/assets/SideList-CBizh6GS.js",
			"/assets/tabs-CehcIwlM.js",
			"/assets/photos-Ub3Zp4pi.js",
			"/assets/stockmove-C_zOhL83.js",
			"/assets/serials-DGLPqOJ9.js",
			"/assets/SerialsBox-CKIbgX5A.js",
			"/assets/workorders-oLSRkvqr.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-6-VNZCqW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C71up0XN.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-aJ1SsTzZ.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DnnDukWy.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/SideList-CBizh6GS.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-CpMMyYuk.js",
			"/assets/MoneyAccountPick-dgObaJoY.js",
			"/assets/footers-BWLCJDOZ.js",
			"/assets/PrintFrame-C4eIjjdP.js",
			"/assets/checkbox-0IoICtV1.js",
			"/assets/serials-DGLPqOJ9.js",
			"/assets/workorders-oLSRkvqr.js",
			"/assets/RepeatInvoice-B585S2xy.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BFrcEVMJ.js",
			"/assets/users.functions-CkA5HQLN.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-iW2aulbY.js",
			"/assets/select-C71up0XN.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/SideList-CBizh6GS.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-x7BUuTeu.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/quickadd-DqNEXdD-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Dn99NoKk.js",
			"/assets/support.functions--f8WoB86.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-boHRtPZ3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DG2jNxOW.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/SideList-CBizh6GS.js",
			"/assets/PartyHistory-tlWp5C1S.js",
			"/assets/tabs-CehcIwlM.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DT3GC6gm.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/sales-BVNaXHN_.js",
			"/assets/footers-BWLCJDOZ.js",
			"/assets/tickets.functions-BFrcEVMJ.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Cgz7PH4F.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/input-Dcs2NLcl.js",
			"/assets/skeleton-BlM-hwaM.js",
			"/assets/AdminAccount-DO_fGnz4.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-IajS6RZW.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CdPXMBo3.js",
			"/assets/textarea-DffArwi-.js",
			"/assets/support-Dn99NoKk.js",
			"/assets/support.functions--f8WoB86.js",
			"/assets/HelpParts-BpJJC72D.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BoX1ecwa.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BlM-hwaM.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
