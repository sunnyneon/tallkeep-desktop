import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ut as Download, en as CircleCheck, lt as LoaderCircle, qt as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { getOrder } from "./buy.functions-C-0SF0L8.mjs";
import { t as BuyFrame } from "./buy-BAz28HOQ.mjs";
import { t as Route } from "./buy_.done-CdKuOpQC.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy_.done-DF-sRBrH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* What to do when Windows warns about a new program ("Windows protected your PC") until Tallkeep
* is code-signed. A small drawing of the warning, so people recognize it.
*/
function WindowsNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-xl border bg-muted/30 p-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "If Windows warns you when installing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted-foreground",
				children: [
					"Tallkeep is new, so Windows may say it doesn't know it yet. That's normal. Click",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "More info" }),
					", then ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Run anyway" }),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"aria-hidden": true,
				className: "mx-auto max-w-xs rounded-md bg-[#0b5cad] p-3 text-left text-[11px] leading-snug text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Windows protected your PC"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 opacity-90",
						children: "Microsoft Defender SmartScreen prevented an unrecognized app from starting…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 underline decoration-yellow-300 decoration-2 underline-offset-2",
						children: "① More info"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-sm border border-yellow-300 px-2 py-0.5 ring-2 ring-yellow-300",
							children: "② Run anyway"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-sm border border-white/60 px-2 py-0.5 opacity-80",
							children: "Don't run"
						})]
					})
				]
			})
		]
	});
}
/** After paying: the license key, and how to start. */
function DonePage() {
	const { session } = Route.useSearch();
	const [tries, setTries] = (0, import_react.useState)(0);
	const { data, error } = useQuery({
		queryKey: ["order", session],
		queryFn: async () => {
			const r = await getOrder({ data: { session } });
			setTries((t) => t + 1);
			return r;
		},
		refetchInterval: (q) => q.state.data?.status === "paid" || tries > 20 ? false : 3e3
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
		children: data?.status === "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Thank you!"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Here's your license key.",
					" ",
					data.email && data.mailed ? `We also emailed it to ${data.email}.` : "Copy it and keep it somewhere safe."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "break-all rounded-xl border bg-muted/40 p-3 font-mono text-xs",
				children: data.key
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => {
					copyText(data.key);
					toast.success("Key copied");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy the key"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "list-decimal space-y-1.5 pl-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Download Tallkeep on the computer that will keep your books." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Install it and create your company." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						"Open ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Settings → Plan & computer" }),
						", paste the key and press",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Save the license key" }),
						"."
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				size: "lg",
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "/api/public/download",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download Tallkeep for Windows"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WindowsNote, {})
		] }) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [
				"Something went wrong showing your key: ",
				error.message,
				". Your payment is safe. Email hello@tallkeep.com and we'll send it."
			]
		}) : data?.status === "unpaid" && tries > 20 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "We haven't heard from Stripe that the payment went through yet. If you paid, your key will arrive by email in a few minutes. Otherwise email hello@tallkeep.com."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Confirming your payment…"]
		})
	}) });
}
//#endregion
export { DonePage as component };
