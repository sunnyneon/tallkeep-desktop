import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { C as useRouter, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as kindLabel, f as useAccounts, i as accountLabel, o as balanceOf } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { D as Search, K as PanelLeftOpen, Nn as ArrowLeft, g as Trash2, q as PanelLeftClose } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { t as OriginalLink } from "./OriginalLink-CtC2_wGp.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/AccountRegister-BVjCN01v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Change or delete one transaction right from a register: a deposit, a line added from the bank
* feed, or a typed-in entry. The date, who it's from or to, the amount and the category (the
* other side). Deleting a bank-feed line puts it back in Bank Feeds to be looked at again.
* A split payment (like a loan payment: interest, escrow, principal) can only be deleted here.
*/
var T = (t) => db.from(t);
var rpc = (f, a) => db.rpc(f, a);
/** The kinds of transaction this window can change. */
var EDITABLE = /* @__PURE__ */ new Set([
	"deposit",
	"bank",
	"manual",
	"opening",
	"adjust",
	"history"
]);
function TxnEditor({ entryId, accountId, accounts, onClose }) {
	const qc = useQueryClient();
	const [e, setE] = (0, import_react.useState)(null);
	const [depLine, setDepLine] = (0, import_react.useState)(null);
	const [f, setF] = (0, import_react.useState)({
		date: "",
		memo: "",
		amount: "",
		other: ""
	});
	const [dir, setDir] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data, error } = await T("journal_entries").select("id,entry_date,memo,source_type,source_id,journal_lines(id,account_id,debit,credit,memo)").eq("id", entryId).maybeSingle();
			if (error || !data) return void toast.error(error?.message ?? "Not found.");
			const en = data;
			setE(en);
			const mine = en.journal_lines.find((l) => l.account_id === accountId);
			const other = en.journal_lines.find((l) => l.account_id !== accountId);
			const amt = mine ? Math.abs(Number(mine.debit) - Number(mine.credit)) : 0;
			setDir(mine ? Number(mine.debit) > 0 : null);
			let memo = en.memo ?? "";
			if (en.source_type === "deposit" && en.source_id) {
				const { data: dl } = await T("deposit_lines").select("id,name").eq("deposit_id", en.source_id);
				if ((dl ?? []).length === 1) {
					setDepLine(dl[0]);
					memo = dl[0].name ?? memo;
				}
			}
			setF({
				date: en.entry_date,
				memo,
				amount: amt ? amt.toFixed(2) : "",
				other: other?.account_id ?? ""
			});
		})();
	}, [entryId, accountId]);
	const twoLines = !!e && e.journal_lines.length === 2;
	const canChange = !!e && (e.source_type === "deposit" ? !!depLine : twoLines && EDITABLE.has(e.source_type));
	const done = () => {
		qc.invalidateQueries();
		onClose();
	};
	async function save() {
		if (!e) return;
		const amount = Number(f.amount.replace(/[$,\s]/g, ""));
		if (!(amount > 0)) return void toast.error("Type the amount.");
		if (!f.other) return void toast.error("Pick the category.");
		setBusy(true);
		try {
			if (e.source_type === "deposit" && e.source_id && depLine) {
				const a = await T("deposits").update({ deposit_date: f.date }).eq("id", e.source_id);
				if (a.error) throw a.error;
				const b = await T("deposit_lines").update({
					amount,
					account_id: f.other,
					name: f.memo || null
				}).eq("id", depLine.id);
				if (b.error) throw b.error;
			} else {
				const mine = e.journal_lines.find((l) => l.account_id === accountId);
				const other = e.journal_lines.find((l) => l.id !== mine.id);
				const was = Number(mine.debit) > 0;
				const into = dir ?? was;
				const a = await T("journal_entries").update({
					entry_date: f.date,
					memo: f.memo || null
				}).eq("id", e.id);
				if (a.error) throw a.error;
				const b = await T("journal_lines").update({
					debit: into ? amount : 0,
					credit: into ? 0 : amount
				}).eq("id", mine.id);
				if (b.error) throw b.error;
				const c = await T("journal_lines").update({
					account_id: f.other,
					debit: into ? 0 : amount,
					credit: into ? amount : 0
				}).eq("id", other.id);
				if (c.error) throw c.error;
				if (into !== was && e.source_type === "bank") {
					const { data: bt } = await T("bank_transactions").select("id,amount").eq("source_id", e.id);
					for (const x of bt ?? []) await T("bank_transactions").update({ amount: -Number(x.amount) }).eq("id", x.id);
				}
			}
			toast.success("Saved.");
			done();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function remove() {
		if (!e) return;
		const fromBank = e.source_type === "bank";
		if (!window.confirm(fromBank ? "Delete this? The bank line goes back to Bank Feeds, to be recorded again." : "Delete this transaction?")) return;
		setBusy(true);
		try {
			if (e.source_type === "deposit" && e.source_id) {
				const r = await T("deposits").delete().eq("id", e.source_id);
				if (r.error) throw r.error;
			} else if (fromBank) {
				const { data: t } = await T("bank_transactions").select("id").eq("source_id", e.id);
				if ((t ?? []).length) for (const x of t) {
					const r = await rpc("undo_bank_transaction", { _txn: x.id });
					if (r.error) throw r.error;
				}
				else {
					const r = await T("journal_entries").delete().eq("id", e.id);
					if (r.error) throw r.error;
				}
			} else {
				const r = await T("journal_entries").delete().eq("id", e.id);
				if (r.error) throw r.error;
			}
			toast.success("Deleted.");
			done();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	const cats = accounts.filter((a) => a.is_active && a.id !== accountId);
	const card = accounts.find((a) => a.id === accountId)?.type === "liability";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Change or delete" }) }), !e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					canChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: f.date,
									onChange: (x) => setF({
										...f,
										date: x.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Amount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "decimal",
									value: f.amount,
									onChange: (x) => setF({
										...f,
										amount: x.target.value
									})
								})]
							}),
							e.source_type !== "deposit" && dir !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1 text-sm sm:col-span-2",
								children: [[false, card ? "A charge (adds to what's owed)" : "Money out"], [true, card ? "A payment or refund (lowers what's owed)" : "Money in"]].map(([v, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setDir(v),
									className: `rounded-md border px-3 py-1 ${dir === v ? "border-primary bg-primary/10 font-medium" : "hover:bg-muted"}`,
									children: label
								}, String(v)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: e.source_type === "deposit" ? "From" : "Payee or memo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.memo,
									onChange: (x) => setF({
										...f,
										memo: x.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									value: f.other,
									onChange: (x) => setF({
										...f,
										other: x.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Pick one"
									}), cats.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: a.id,
										children: accountLabel(a)
									}, a.id))]
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"This one is split into ",
							e.journal_lines.length - 1,
							" parts, so it can only be deleted here."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "text-muted-foreground",
							children: e.journal_lines.filter((l) => l.account_id !== accountId).map((l) => {
								const a = accounts.find((x) => x.id === l.account_id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									a ? accountLabel(a) : "?",
									":",
									" ",
									fmtMoney(Math.abs(Number(l.debit) - Number(l.credit)))
								] }, l.id);
							})
						})]
					}),
					e.source_type === "deposit" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalLink, {
						type: "deposit",
						id: e.source_id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "text-destructive",
							disabled: busy,
							onClick: () => void remove(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: onClose,
								children: "Cancel"
							}), canChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: busy,
								onClick: () => void save(),
								children: busy ? "Saving…" : "Save"
							})]
						})]
					})
				]
			})]
		})
	});
}
/**
* Register for one account, like QuickBooks' check register: every check, deposit, payment,
* transfer and card charge in date order, with the payee, the other account, cleared status and a
* running balance. A search column on the left (it can be hidden) finds checks, deposits,
* numbers, payees or amounts, in one account or in all bank and card accounts at once.
*/
var SOURCE = {
	invoice: "Invoice",
	invoice_cogs: "Cost of goods",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	stock: "Stock change",
	bill: "Bill",
	bill_payment: "Bill payment",
	manual: "Journal entry",
	opening: "Opening balance",
	adjust: "Accountant adjustment",
	history: "From QuickBooks",
	rent_charge: "Rent charge",
	rent_payment: "Rent received",
	work_order: "Work order",
	check: "Check / payment",
	deposit: "Deposit",
	transfer: "Transfer",
	bank: "Bank feed",
	stay: "Short-term stay"
};
/** The kinds of transaction people look for. */
var TYPES = [
	{
		key: "all",
		label: "Every type",
		match: () => true
	},
	{
		key: "check",
		label: "Checks & payments",
		match: (s) => s === "check"
	},
	{
		key: "deposit",
		label: "Deposits",
		match: (s) => s === "deposit"
	},
	{
		key: "received",
		label: "Payments received",
		match: (s) => s === "payment" || s === "rent_payment" || s === "stay"
	},
	{
		key: "bills",
		label: "Bill & PO payments",
		match: (s) => s === "bill_payment" || s === "po_payment"
	},
	{
		key: "transfer",
		label: "Transfers",
		match: (s) => s === "transfer"
	},
	{
		key: "bank",
		label: "From the bank feed",
		match: (s) => s === "bank"
	},
	{
		key: "journal",
		label: "Journal & opening entries",
		match: (s) => [
			"manual",
			"opening",
			"adjust",
			"history"
		].includes(s)
	}
];
var NO_FILTERS = {
	q: "",
	amount: "",
	type: "all",
	from: "",
	to: "",
	cleared: "all"
};
var OPEN_KEY = "register-search-open";
async function loadLines(ids) {
	const out = [];
	for (let from = 0;; from += 1e3) {
		const { data, error } = await db.from("journal_lines").select("id,account_id,debit,credit,memo,customers(name),vendors(name),journal_entries!inner(id,entry_date,ref,memo,source_type,journal_lines(account_id,debit,credit,customers(name),vendors(name)))").in("account_id", ids).order("id").range(from, from + 999);
		if (error) throw error;
		out.push(...data ?? []);
		if (!data || data.length < 1e3) break;
	}
	return out;
}
async function loadCleared(ids) {
	const m = /* @__PURE__ */ new Map();
	for (const id of ids) {
		const { data } = await db.rpc("account_lines", {
			_account: id,
			_to: null
		});
		for (const r of data ?? []) if (r.cleared) m.set(r.line_id, r.reconciliation_id ? "R" : "C");
	}
	return m;
}
var isRegister = (a) => a.kind === "bank" || a.kind === "credit_card";
function AccountRegister({ accountId, onAccount, kind, start }) {
	const router = useRouter();
	const { data: accounts } = useAccounts();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const registers = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && isRegister(a)), [accounts]);
	const all = accountId === "all";
	const account = all ? null : accounts?.find((a) => a.id === accountId);
	const [last, setLast] = useSticky("register-last", {});
	(0, import_react.useEffect)(() => {
		if (accountId || !registers.length) return;
		const want = kind === "any" ? "bank" : kind;
		const prev = last[want];
		onAccount(prev && (prev === "all" || registers.some((a) => a.id === prev)) && prev || registers.find((a) => a.kind === want)?.id || registers[0].id);
	}, [accountId, registers]);
	(0, import_react.useEffect)(() => {
		if (!accountId) return;
		const k = all ? kind === "credit_card" ? "credit_card" : "bank" : account?.kind;
		if (k === "bank" || k === "credit_card") setLast((x) => ({
			...x,
			[k]: accountId
		}));
	}, [accountId, account?.kind]);
	const [f, setF] = useSticky("register-filters", {
		...NO_FILTERS,
		...start
	});
	(0, import_react.useEffect)(() => {
		if (start?.from || start?.to) setF({
			...NO_FILTERS,
			...start
		});
	}, [start?.from, start?.to]);
	const [newestFirst, setNewestFirst] = useSticky("register-newest-first", true);
	const [open, setOpen] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem(OPEN_KEY) !== "0";
		} catch {
			return true;
		}
	});
	const toggle = () => setOpen((v) => {
		try {
			localStorage.setItem(OPEN_KEY, v ? "0" : "1");
		} catch {}
		return !v;
	});
	const ids = (0, import_react.useMemo)(() => all ? registers.map((a) => a.id) : accountId ? [accountId] : [], [
		all,
		registers,
		accountId
	]);
	const { data, isLoading, error } = useQuery({
		queryKey: ["register", ids.join(",")],
		enabled: ids.length > 0,
		queryFn: async () => {
			const [lines, cleared] = await Promise.all([loadLines(ids), loadCleared(ids)]);
			return {
				lines,
				cleared
			};
		}
	});
	const name = (0, import_react.useMemo)(() => {
		const m = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
		return (id) => m.get(id) ?? "";
	}, [accounts]);
	const typeOf = (0, import_react.useMemo)(() => {
		const m = new Map((accounts ?? []).map((a) => [a.id, a.type]));
		return (id) => m.get(id) ?? "asset";
	}, [accounts]);
	const allRows = (0, import_react.useMemo)(() => {
		if (!data) return [];
		const sorted = [...data.lines].sort((a, b) => a.journal_entries.entry_date.localeCompare(b.journal_entries.entry_date) || Number(b.debit) - Number(a.debit));
		let running = 0;
		return sorted.map((l) => {
			const e = l.journal_entries;
			const amount = balanceOf(typeOf(l.account_id), Number(l.debit), Number(l.credit));
			running += amount;
			const others = e.journal_lines.filter((o) => o.account_id !== l.account_id);
			const otherIds = [...new Set(others.map((o) => o.account_id))];
			const party = l.vendors?.name ?? l.customers?.name ?? e.journal_lines.find((o) => o.vendors || o.customers)?.vendors?.name ?? e.journal_lines.find((o) => o.customers)?.customers?.name ?? "";
			return {
				id: l.id,
				entryId: e.id,
				accountId: l.account_id,
				date: e.entry_date,
				number: e.ref ?? "",
				payee: party || (e.source_type === "check" ? e.memo ?? "" : ""),
				type: SOURCE[e.source_type] ?? e.source_type,
				source: e.source_type,
				other: otherIds.length === 0 ? "" : otherIds.length === 1 ? name(otherIds[0]) : `Split (${otherIds.length} accounts)`,
				otherAll: otherIds.map(name).join(", "),
				memo: (l.memo || e.memo) ?? "",
				amount,
				cleared: data.cleared.get(l.id) ?? "",
				running
			};
		});
	}, [
		data,
		name,
		typeOf
	]);
	const rows = (0, import_react.useMemo)(() => {
		const words = f.q.toLowerCase().split(/\s+/).filter(Boolean);
		const amt = f.amount.replace(/[$,\s]/g, "");
		const amtN = amt && !Number.isNaN(Number(amt)) ? Math.abs(Number(amt)) : null;
		const type = TYPES.find((t) => t.key === f.type) ?? TYPES[0];
		const list = allRows.filter((r) => {
			if (f.from && r.date < f.from) return false;
			if (f.to && r.date > f.to) return false;
			if (!type.match(r.source)) return false;
			if (f.cleared === "no" && r.cleared) return false;
			if (f.cleared === "yes" && !r.cleared) return false;
			if (amtN !== null && Math.abs(Math.abs(r.amount) - amtN) > .005) return false;
			const hay = `${r.number} ${r.payee} ${r.memo} ${r.otherAll} ${r.type} ${all ? name(r.accountId) : ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
		return newestFirst ? list.reverse() : list;
	}, [
		allRows,
		f,
		newestFirst,
		all,
		name
	]);
	const filtered = JSON.stringify({ ...f }) !== JSON.stringify(NO_FILTERS);
	const card = all ? kind === "credit_card" : account?.kind === "credit_card";
	const upWord = card ? "Charge" : account && account.kind !== "bank" && !all ? "Increase" : "Deposit";
	const downWord = card ? "Payment" : account && account.kind !== "bank" && !all ? "Decrease" : "Payment";
	const ups = rows.reduce((s, r) => s + Math.max(r.amount, 0), 0);
	const downs = rows.reduce((s, r) => s + Math.max(-r.amount, 0), 0);
	const balance = allRows.length ? allRows[allRows.length - 1].running : 0;
	const shown = rows.slice(0, 1e3);
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	const searchColumn = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Search"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggle,
					title: "Hide the search",
					"aria-label": "Hide the search",
					className: "rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftClose, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Account"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: accountId ?? "",
					onChange: (e) => onAccount(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All bank and card accounts"
						}),
						registers.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: a.id,
							children: accountLabel(a)
						}, a.id)),
						account && !isRegister(account) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: account.id,
							children: accountLabel(account)
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Number, payee or memo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "h-9 pl-8",
						placeholder: "e.g. 1042 or Home Depot",
						value: f.q,
						onChange: (e) => set({ q: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Amount"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-9",
					inputMode: "decimal",
					placeholder: "e.g. 250.00",
					value: f.amount,
					onChange: (e) => set({ amount: e.target.value })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Type"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: f.type,
					onChange: (e) => set({ type: e.target.value }),
					children: TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: t.key,
						children: t.label
					}, t.key))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 px-2 text-xs",
						value: f.from,
						onChange: (e) => set({ from: e.target.value })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 px-2 text-xs",
						value: f.to,
						onChange: (e) => set({ to: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Cleared with the bank"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
					value: f.cleared,
					onChange: (e) => set({ cleared: e.target.value }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "Cleared or not"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "no",
							children: "Not cleared yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "yes",
							children: "Cleared"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data ? `${rows.length} found` : "" }), filtered && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "underline hover:text-foreground",
					onClick: () => setF(NO_FILTERS),
					children: "Clear search"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full",
		children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "sticky top-0 hidden h-screen w-72 shrink-0 overflow-y-auto border-r bg-card lg:block print:hidden",
			children: searchColumn
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: toggle,
			title: "Show the search",
			"aria-label": "Show the search",
			className: "sticky top-0 hidden h-screen w-8 shrink-0 items-start justify-center border-r bg-card pt-4 text-muted-foreground hover:text-foreground lg:flex print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeftOpen, { className: "h-4 w-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
				wide: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/accounts",
						className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Chart of Accounts"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
							children: all ? "All bank and card accounts" : account ? `${accountLabel(account)} register` : "Register"
						}), account && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: kindLabel(account.kind)
						})] }), !all && data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border bg-card px-4 py-2 text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: card ? "Balance owed" : "Ending balance"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-bold tabular-nums",
								children: fmtMoney(balance)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-2xl border bg-card lg:hidden",
						children: searchColumn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							rows.length,
							" shown · ",
							upWord.toLowerCase(),
							"s ",
							fmtMoney(ups),
							" ·",
							" ",
							downWord.toLowerCase(),
							"s ",
							fmtMoney(downs)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: newestFirst,
								onChange: (e) => setNewestFirst(e.target.checked)
							}), "Newest first"]
						})]
					}),
					isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: error.message
					}),
					data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto rounded-2xl border bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b bg-muted/40 text-xs text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Number · type"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: "Payee · memo"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-left font-semibold",
										children: all ? "Account" : "Account (other side)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: downWord
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-2 py-2 text-center font-semibold",
										title: "Cleared (C) or reconciled (R)",
										children: "✓"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: upWord
									}),
									!all && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right font-semibold",
										children: "Balance"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y",
								children: [shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "cursor-pointer hover:bg-muted",
									title: EDITABLE.has(r.source) ? "Change or delete" : "Open this transaction",
									onClick: () => EDITABLE.has(r.source) ? setEditing({
										entryId: r.entryId,
										accountId: r.accountId
									}) : router.history.push(`/go/entry/${r.entryId}`),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2",
											children: fmtDate(r.date)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "max-w-[160px] px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate font-medium",
												children: r.number
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted-foreground",
												children: r.type
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "max-w-[260px] px-3 py-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate",
												children: r.payee || r.memo
											}), r.payee && r.memo && r.memo !== r.payee && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs text-muted-foreground",
												children: r.memo
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-[200px] truncate px-3 py-2",
											title: all ? name(r.accountId) : r.otherAll,
											children: all ? name(r.accountId) : r.other
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right tabular-nums",
											children: r.amount < 0 ? fmtMoney(-r.amount) : ""
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-2 py-2 text-center text-xs font-semibold text-emerald-700",
											children: r.cleared
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right tabular-nums",
											children: r.amount > 0 ? fmtMoney(r.amount) : ""
										}),
										!all && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "whitespace-nowrap px-3 py-2 text-right font-medium tabular-nums",
											children: fmtMoney(r.running)
										})
									]
								}, r.id)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 8,
									className: "p-8 text-center text-muted-foreground",
									children: filtered ? "Nothing matches the search." : "No transactions yet."
								}) })]
							})]
						})
					}),
					rows.length > shown.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-center text-sm text-muted-foreground",
						children: [
							"Showing ",
							shown.length,
							" of ",
							rows.length,
							". Search or pick dates to narrow it down."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "✓: C = cleared with the bank, R = reconciled. Click a line to change, delete or open it."
					}),
					editing && accounts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxnEditor, {
						entryId: editing.entryId,
						accountId: editing.accountId,
						accounts,
						onClose: () => setEditing(null)
					})
				]
			})
		})]
	});
}
//#endregion
export { AccountRegister as t };
