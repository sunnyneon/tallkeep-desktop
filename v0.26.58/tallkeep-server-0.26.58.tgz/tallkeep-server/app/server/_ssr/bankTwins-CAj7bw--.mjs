//#region ../../node_modules/.nitro/vite/services/ssr/assets/bankTwins-CAj7bw--.js
/**
* A bank line can come in twice: once from the bank connection (fit_id "sf:…") and once from a
* statement file (PDF, CSV, OFX), worded differently ("Online Deposit Check #1" vs "Remote Online
* Deposit 1"). Lines already brought in by the *other* way with the same amount on the same day
* (or up to three days apart) are the same money: each one already here drops one new line.
*/
var fromBankFeed = (fit) => !!fit && fit.startsWith("sf:");
var shift = (d, days) => {
	const t = /* @__PURE__ */ new Date(`${d}T12:00:00Z`);
	t.setUTCDate(t.getUTCDate() + days);
	return t.toISOString().slice(0, 10);
};
function dropTwins(incoming, have, feed) {
	const pool = /* @__PURE__ */ new Map();
	const key = (d, a) => `${d}|${Number(a).toFixed(2)}`;
	for (const h of have) {
		if (fromBankFeed(h.fit_id) === feed) continue;
		const k = key(h.txn_date, h.amount);
		pool.set(k, (pool.get(k) ?? 0) + 1);
	}
	const haveIds = new Set(have.map((h) => h.fit_id).filter(Boolean));
	const take = (k) => {
		const n = pool.get(k) ?? 0;
		if (n <= 0) return false;
		pool.set(k, n - 1);
		return true;
	};
	const out = [];
	const later = [];
	for (const l of incoming) if (l.fit_id && haveIds.has(l.fit_id)) out.push(l);
	else if (take(key(l.txn_date, l.amount))) continue;
	else later.push(l);
	for (const l of later) if (![
		-1,
		1,
		-2,
		2,
		-3,
		3
	].some((d) => take(key(shift(l.txn_date, d), l.amount)))) out.push(l);
	return out;
}
//#endregion
export { dropTwins as t };
