-- 089: One bank deposit can match several entries in the books (24 November 2026).
--
-- A customer's one check often pays two invoices, so the books have two payments and the bank one
-- deposit. Review & Reconcile now matches the deposit to all of them; the others are kept here so
-- Undo clears them too.
alter table public.bank_transactions add column if not exists also_ids uuid[];

create or replace function public.undo_bank_transaction(_txn uuid)
returns void language plpgsql set search_path = public as $$
declare t record;
begin
  select * into t from public.bank_transactions where id = _txn;
  if t.id is null then return; end if;
  if t.source_id is not null then
    delete from public.cleared_items where account_id = t.account_id and item_key = t.source_id and reconciliation_id is null;
  end if;
  if t.also_ids is not null then
    delete from public.cleared_items where account_id = t.account_id and item_key = any (t.also_ids) and reconciliation_id is null;
  end if;
  if t.status = 'added' and t.source_id is not null then
    delete from public.journal_entries where id = t.source_id and source_type = 'bank';
  end if;
  update public.bank_transactions set status = 'new', source_type = null, source_id = null, also_ids = null where id = _txn;
end $$;
grant execute on function public.undo_bank_transaction(uuid) to authenticated;

notify pgrst, 'reload schema';
