-- 091: Two switch-over fixes found on SunRise LED's books (25 November 2026).
--
-- 1) "Paid before switch-over" payments: moving from inFlow marks every old invoice paid with a
--    payment dated the switch-over day. When that day is after the books start, the money of
--    years of old invoices (paid long ago, and already in the opening balances) landed in the
--    bank account and Accounts Receivable. Those payments now take their invoice's date when the
--    invoice is from before the books start, so they stay out of the books like the invoice.
-- 2) The QuickBooks chart step matched accounts by number first, so QuickBooks' "1200 Accounts
--    Receivable" took over Tallkeep's "1200 Inventory" (the account stock is written to) and
--    made it a receivable. Stock now goes to QuickBooks' Inventory Asset account when there is
--    one, or the account becomes Inventory again.
-- Then the books of the companies this touched are written again.

create or replace function public.close_out_sales(_as_of timestamptz, _mark_shipped boolean default true)
returns json language plpgsql security definer set search_path = public as $$
declare n_inv int := 0; n_pay int := 0; amt numeric := 0; n_ship int := 0; co uuid := public.active_company();
        start date := (select books_start_date from public.company_settings where company_id = co);
begin
  if not public.has_role(auth.uid(), 'admin') then raise exception 'Only an admin can do this'; end if;
  update public.sales_orders
     set status = 'invoiced', invoice_date = coalesce(invoice_date, order_date)
   where status = 'open' and number not like 'RMA-%' and company_id = co;
  get diagnostics n_inv = row_count;
  select count(*), coalesce(sum(balance), 0) into n_pay, amt
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%' and company_id = co;
  -- An invoice from before the books start was paid before them too: its payment takes the
  -- invoice's date and stays out of the books (the opening balances have that money).
  insert into public.payments (company_id, sales_order_id, paid_on, amount, method, remarks, created_by)
  select co, id,
         case when start is not null and coalesce(invoice_date, order_date)::date < start
              then coalesce(invoice_date, order_date) else _as_of end,
         balance, 'Paid before switch-over', 'Marked paid when moving from inFlow', auth.uid()
    from public.sales_orders
   where status in ('invoiced','paid','completed') and balance > 0.005 and number not like 'RMA-%' and company_id = co;
  update public.sales_orders set status = 'paid'
   where status = 'invoiced' and balance <= 0.005 and number not like 'RMA-%' and company_id = co;
  if _mark_shipped then
    update public.sales_orders set stock_taken_at = _as_of
     where stock_taken_at is null and status in ('paid','completed','invoiced') and number not like 'RMA-%' and company_id = co;
    get diagnostics n_ship = row_count;
  end if;
  return json_build_object('invoiced', n_inv, 'payments', n_pay, 'amount', amt, 'shipped', n_ship);
end $$;

do $$
declare r record; q uuid; cos uuid[] := '{}';
begin
  -- 1) Old invoices' switch-over payments take the invoice's date.
  for r in
    select p.id, p.company_id, coalesce(o.invoice_date, o.order_date) as d
      from public.payments p
      join public.sales_orders o on o.id = p.sales_order_id
      join public.company_settings s on s.company_id = p.company_id
     where p.method = 'Paid before switch-over'
       and s.books_start_date is not null
       and coalesce(o.invoice_date, o.order_date)::date < s.books_start_date
       and p.paid_on::date >= s.books_start_date
  loop
    update public.payments set paid_on = r.d where id = r.id;
    if not r.company_id = any (cos) then cos := cos || r.company_id; end if;
  end loop;

  -- 2) The Inventory account QuickBooks' chart step turned into a receivable.
  for r in select id, company_id from public.accounts where key = 'inventory' and kind = 'ar' loop
    select id into q from public.accounts
     where company_id = r.company_id and key is null and id <> r.id
       and lower(trim(name)) in ('inventory asset', 'inventory')
     order by is_active desc, number nulls last limit 1;
    if q is not null then
      update public.accounts set key = null, name = 'Inventory (old, not used)', kind = 'inventory'
       where id = r.id;
      update public.accounts set key = 'inventory', kind = 'inventory', type = 'asset' where id = q;
    else
      update public.accounts set name = 'Inventory', kind = 'inventory' where id = r.id;
    end if;
    if not r.company_id = any (cos) then cos := cos || r.company_id; end if;
  end loop;

  foreach q in array cos loop
    perform public.rebuild_books_company(q);
    -- Nothing left on the old one: hide it.
    update public.accounts a set is_active = false
     where a.company_id = q and a.key is null and a.name = 'Inventory (old, not used)'
       and not exists (select 1 from public.journal_lines l where l.account_id = a.id);
  end loop;
end $$;

notify pgrst, 'reload schema';
