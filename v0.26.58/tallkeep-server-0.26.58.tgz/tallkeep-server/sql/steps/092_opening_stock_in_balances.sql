-- 092: Starting stock already in the opening balances (25 November 2026).
--
-- SunRise LED's opening balances come from its 2025 tax return, which has the inventory it reported
-- ($96,118). The stock brought in from inFlow (and every product's first count) was also added to
-- the books as opening stock, so the stock was counted twice. A company can now say its opening
-- balances already hold its stock: then starting stock isn't added to the books.
-- A stock count or adjustment whose remarks start with "Starting stock" fixes the starting stock
-- (items sold long ago that inFlow still shows): it is starting stock too, not a loss this year.

alter table public.company_settings
  add column if not exists opening_stock_in_balances boolean not null default false;

create or replace function public.post_stock_move(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare m record; co uuid; value numeric; other uuid; opening boolean;
begin
  delete from public.journal_entries where source_type = 'stock' and source_id = _id;
  select sm.*, p.cost, p.company_id as co, p.name as pname into m
    from public.stock_moves sm join public.products p on p.id = sm.product_id where sm.id = _id;
  if m.id is null or m.reason not in ('adjust', 'count', 'import') then return; end if;
  co := m.co;
  if not public.books_open(co, m.created_at::date) then return; end if;
  value := round(m.qty_change * m.cost, 2);
  opening := coalesce(m.note, '') ilike 'opening stock%' or m.reason = 'import'
    or (m.ref_type = 'stock_doc' and exists (
          select 1 from public.stock_docs d
           where d.id = m.ref_id and coalesce(d.remarks, '') ilike 'starting stock%'))
    or not exists (select 1 from public.stock_moves x
                    where x.product_id = m.product_id
                      and (x.created_at < m.created_at or (x.created_at = m.created_at and x.id < m.id)));
  -- The opening balances already hold the stock: starting stock isn't added again.
  if opening and coalesce((select s.opening_stock_in_balances from public.company_settings s
                            where s.company_id = co), false) then
    return;
  end if;
  other := case when opening then public.acct(co, 'opening') else public.acct(co, 'inv_adjust') end;
  perform public.write_entry(co, m.created_at::date, 'stock', m.id, null,
    case when opening then 'Opening stock: ' else 'Stock ' || m.reason || ': ' end || m.pname,
    case when value >= 0 then jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'inventory'), 'debit', value),
        jsonb_build_object('account', other, 'credit', value))
      else jsonb_build_array(
        jsonb_build_object('account', other, 'debit', -value),
        jsonb_build_object('account', public.acct(co, 'inventory'), 'credit', -value)) end);
end $$;

notify pgrst, 'reload schema';
