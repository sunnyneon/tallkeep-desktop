-- 093: The same bank line from the bank connection and from a statement file (25 November 2026).
--
-- The bank connection brings in about the last month when it's first linked, and the statement
-- file for that month has the same lines worded differently ("Online Deposit Check #1" vs "Remote
-- Online Deposit 1"), so both were kept and some money was counted twice. From now on a line the
-- other way already brought in (same amount, same day or a day apart) isn't added again. This puts
-- right the twins already here: one of each pair is put back and set aside as Ignored, keeping the
-- one already in the books (matched first), or else the statement's. Reconciled lines are left alone.

do $$
declare f record; s record; used uuid[] := '{}'; keep_feed boolean; gone uuid;
  reconciled boolean;
begin
  for f in
    select b.* from public.bank_transactions b
     where b.fit_id like 'sf:%' and b.status <> 'ignored'
     order by b.account_id, b.txn_date, b.amount, b.id
  loop
    select b.* into s from public.bank_transactions b
     where b.account_id = f.account_id and coalesce(b.fit_id, '') not like 'sf:%'
       and b.status <> 'ignored' and b.amount = f.amount
       and abs(b.txn_date - f.txn_date) <= 1 and not (b.id = any (used))
     order by abs(b.txn_date - f.txn_date), b.id
     limit 1;
    if s.id is null then continue; end if;
    used := used || s.id;
    -- Keep the one already in the books (matched first); otherwise keep the statement's line.
    keep_feed := (f.status in ('matched', 'added') and s.status = 'new')
              or (f.status = 'matched' and s.status <> 'matched');
    if f.status = 'matched' and s.status = 'matched' then continue; end if;
    gone := case when keep_feed then s.id else f.id end;
    select exists (
      select 1 from public.bank_transactions b
        join public.cleared_items c on c.account_id = b.account_id
         and (c.item_key = b.source_id or c.item_key = any (coalesce(b.also_ids, '{}')))
       where b.id = gone and c.reconciliation_id is not null) into reconciled;
    if reconciled then continue; end if;
    if (select status from public.bank_transactions where id = gone) in ('added', 'matched') then
      perform public.undo_bank_transaction(gone);
    end if;
    update public.bank_transactions set status = 'ignored' where id = gone;
  end loop;
end $$;

notify pgrst, 'reload schema';
