-- 090: Put back what a QuickBooks list import changed (25 November 2026).
--
-- Step 1 of the QuickBooks import used to write QuickBooks' details over customers, vendors and
-- items that were already in Tallkeep (from inFlow): prices, costs, item kinds, emails and phones.
-- Change history (step 69) kept what each one was before, so this puts those details back for
-- the changes you made yourself between two times. Customers, vendors and items the import
-- added stay; only the details it changed on ones already here go back.

-- What you changed in these lists between two times: one row per list.
create or replace function public.list_changes(_from timestamptz, _to timestamptz)
returns table (table_name text, rows bigint, first_at timestamptz, last_at timestamptz)
language sql stable security definer set search_path = public as $$
  select c.table_name, count(distinct c.row_id), min(c.at), max(c.at)
    from public.change_log c
   where c.company_id = public.active_company()
     and c.user_id = auth.uid()
     and c.action = 'update'
     and c.table_name in ('customers', 'vendors', 'products', 'tax_rates')
     and c.at >= _from and c.at < _to
     and public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')
   group by c.table_name
   order by c.table_name;
$$;
revoke all on function public.list_changes(timestamptz, timestamptz) from public, anon;
grant execute on function public.list_changes(timestamptz, timestamptz) to authenticated;

-- Put each changed detail back to what it was before the first change in that time.
create or replace function public.undo_list_changes(_from timestamptz, _to timestamptz)
returns integer language plpgsql security definer set search_path = public as $$
declare r record; k text; cols text; n integer := 0; was jsonb;
begin
  if not (public.is_staff(auth.uid()) and public.has_zone(auth.uid(), 'Accounting')) then
    raise exception 'Only staff with Accounting can do this.';
  end if;
  for r in
    select c.table_name, c.row_id
      from public.change_log c
     where c.company_id = public.active_company() and c.user_id = auth.uid() and c.action = 'update'
       and c.table_name in ('customers', 'vendors', 'products', 'tax_rates')
       and c.at >= _from and c.at < _to and c.row_id is not null
     group by c.table_name, c.row_id
  loop
    -- Oldest value of each detail in that time (what it was before it all started).
    select jsonb_object_agg(e.key, e.value) into was
      from (
        select distinct on (j.key) j.key, j.value
          from public.change_log c, jsonb_each(c.before) j
         where c.company_id = public.active_company() and c.user_id = auth.uid()
           and c.action = 'update' and c.table_name = r.table_name and c.row_id = r.row_id
           and c.at >= _from and c.at < _to
         order by j.key, c.at, c.id
      ) e
     where e.key not in ('id', 'company_id');
    if was is null or was = '{}'::jsonb then continue; end if;
    select string_agg(format('%I', k2), ', ') into cols from jsonb_object_keys(was) k2;
    execute format(
      'update public.%I t set (%s) = (select %s from jsonb_populate_record(null::public.%I, $1)) '
      'where t.id = $2 and t.company_id = public.active_company()',
      r.table_name, cols, cols, r.table_name)
      using was, r.row_id;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.undo_list_changes(timestamptz, timestamptz) from public, anon;
grant execute on function public.undo_list_changes(timestamptz, timestamptz) to authenticated;

notify pgrst, 'reload schema';
