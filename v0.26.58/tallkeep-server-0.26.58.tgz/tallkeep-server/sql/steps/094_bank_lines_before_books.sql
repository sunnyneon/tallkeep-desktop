-- 094: Bank lines dated before the books start (25 November 2026).
--
-- A statement often starts before the books do (a card statement from Dec 3 to Jan 2). Its lines
-- before the start date are already in the opening balances, but they could be added to the
-- books again (SunRise LED's Chase 4098: nine December lines counted twice). Now such lines come
-- in set aside as Ignored, can't be added, and the ones already added are taken back out
-- (reconciled ones are left alone).

create or replace function public.bank_line_before_books()
returns trigger language plpgsql security definer set search_path = public as $$
declare start date;
begin
  select s.books_start_date into start from public.company_settings s
   join public.accounts a on a.company_id = s.company_id where a.id = new.account_id;
  if start is not null and new.txn_date < start and new.status = 'new' then
    new.status := 'ignored';
  end if;
  return new;
end $$;
drop trigger if exists bank_line_before_books on public.bank_transactions;
create trigger bank_line_before_books before insert on public.bank_transactions
  for each row execute function public.bank_line_before_books();

create or replace function public.add_bank_transaction(_txn uuid, _other uuid, _memo text)
returns uuid language plpgsql set search_path = public as $$
declare t record; e uuid; start date;
begin
  select * into t from public.bank_transactions where id = _txn;
  if t.id is null then raise exception 'Bank line not found'; end if;
  if t.status <> 'new' then raise exception 'This bank line was already handled'; end if;
  select s.books_start_date into start from public.company_settings s
   join public.accounts a on a.company_id = s.company_id where a.id = t.account_id;
  if start is not null and t.txn_date < start then
    raise exception 'This line is from before your books start, so the opening balances already have it. Choose Ignore.';
  end if;
  insert into public.journal_entries (entry_date, memo, source_type, ref, created_by)
  values (t.txn_date, coalesce(nullif(_memo, ''), t.description), 'bank', t.ref, auth.uid()) returning id into e;
  insert into public.journal_lines (entry_id, account_id, debit, credit, memo) values
    (e, t.account_id, greatest(t.amount, 0), greatest(-t.amount, 0), t.description),
    (e, _other, greatest(-t.amount, 0), greatest(t.amount, 0), t.description);
  update public.bank_transactions set status = 'added', source_type = 'bank', source_id = e where id = _txn;
  insert into public.cleared_items (account_id, item_key) values (t.account_id, e) on conflict do nothing;
  return e;
end $$;
grant execute on function public.add_bank_transaction(uuid, uuid, text) to authenticated;

do $$
declare r record;
begin
  for r in
    select b.id, b.status from public.bank_transactions b
      join public.accounts a on a.id = b.account_id
      join public.company_settings s on s.company_id = a.company_id
     where s.books_start_date is not null and b.txn_date < s.books_start_date
       and b.status in ('new', 'added')
       and not exists (select 1 from public.cleared_items c
                        where c.account_id = b.account_id and c.item_key = b.source_id
                          and c.reconciliation_id is not null)
  loop
    if r.status = 'added' then perform public.undo_bank_transaction(r.id); end if;
    update public.bank_transactions set status = 'ignored' where id = r.id;
  end loop;
end $$;

notify pgrst, 'reload schema';
