import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, Nn as ArrowLeft, R as Plus, en as CircleCheck, g as Trash2, kn as Ban, nn as ChevronsUpDown, ut as ListPlus } from "../_libs/lucide-react.mjs";
import { o as useLocations, t as byId } from "./queries-Chjya1cy.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-C_XVL5mk.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as KIND } from "./stockdocs-mmIhxNRj.mjs";
import { a as CommandItem, c as PopoverContent, i as CommandInput, l as PopoverTrigger, n as CommandEmpty, o as CommandList, s as Popover, t as Command$1 } from "./SearchSelect-BLD0hN-C.mjs";
import { u as nextNumber } from "./sales-CAB3s83f.mjs";
import { t as SideLayout } from "./SideList-CptILfOc.mjs";
import { t as ScanAddButton } from "./ScanAdd-BohPUN1I.mjs";
import { t as Route } from "./stock-doc._id-D0wqoing.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stock-doc._id-BErnBzUt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var newLine = (no) => ({
	id: crypto.randomUUID(),
	line_no: no,
	product_id: null,
	description: null,
	location_id: null,
	shelf: "",
	to_location_id: null,
	to_shelf: "",
	qty: null,
	old_qty: null,
	new_qty: null,
	_new: true
});
function StockDocPage() {
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const isNew = id === "new";
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const { data: loaded, isLoading } = useQuery({
		queryKey: ["stock-doc", id],
		enabled: !isNew,
		queryFn: async () => {
			const { data, error } = await db.from("stock_docs").select("*, stock_doc_lines(*)").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: products } = useQuery({
		queryKey: ["products", "pick-stock"],
		queryFn: () => fetchAll("products", "id,name,description,item_type,default_location_id,default_shelf")
	});
	const { data: stock } = useQuery({
		queryKey: ["stock", "map"],
		queryFn: () => fetchAll("stock", "product_id,location_id,shelf,qty")
	});
	const stockMap = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		(stock ?? []).forEach((s) => m.set(`${s.product_id}|${s.location_id}|${s.shelf}`, Number(s.qty)));
		return m;
	}, [stock]);
	const cur = (l) => l.product_id && l.location_id ? stockMap.get(`${l.product_id}|${l.location_id}|${l.shelf}`) ?? 0 : null;
	const pName = (0, import_react.useMemo)(() => byId(products), [products]);
	const [doc, setDoc] = (0, import_react.useState)({
		kind: search.kind ?? "adjust",
		doc_date: (/* @__PURE__ */ new Date()).toISOString(),
		status: "open",
		counted_by: null,
		remarks: null,
		completed_at: null
	});
	const [lines, setLines] = (0, import_react.useState)([newLine(1)]);
	const [removed, setRemoved] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const saving = (0, import_react.useRef)(false);
	const completing = (0, import_react.useRef)(false);
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [addLoc, setAddLoc] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!loaded) return;
		const { stock_doc_lines, ...d } = loaded;
		setDoc(d);
		setLines([...stock_doc_lines].sort((a, b) => a.line_no - b.line_no));
		setRemoved([]);
		setDirty(false);
	}, [loaded]);
	const kind = doc.kind;
	const k = KIND[kind];
	const done = doc.status !== "open";
	const patch = (p) => {
		setDoc((d) => ({
			...d,
			...p
		}));
		setDirty(true);
	};
	const patchLine = (i, p) => {
		setLines((ls) => ls.map((l, j) => j === i ? {
			...l,
			...p
		} : l));
		setDirty(true);
	};
	/** Add every product that has stock in a place (like inFlow's "Add items by location"). */
	function addByLocation() {
		if (!addLoc) {
			toast.error("Choose a place first.");
			return;
		}
		const have = new Set(lines.map((l) => `${l.product_id}|${l.location_id}|${l.shelf}`));
		const add = (stock ?? []).filter((s) => s.location_id === addLoc && Number(s.qty) !== 0 && !have.has(`${s.product_id}|${s.location_id}|${s.shelf}`)).sort((a, b) => a.shelf.localeCompare(b.shelf) || (pName.get(a.product_id) ?? "").localeCompare(pName.get(b.product_id) ?? "")).map((s, i) => ({
			...newLine(lines.length + i + 1),
			product_id: s.product_id,
			location_id: s.location_id,
			shelf: s.shelf,
			...kind === "transfer" ? { qty: Number(s.qty) } : { old_qty: Number(s.qty) }
		}));
		if (!add.length) {
			toast("Nothing in stock there that isn't already on the list.");
			return;
		}
		setLines((ls) => [...ls.filter((l) => l.product_id), ...add]);
		setDirty(true);
		toast.success(`Added ${add.length} items.`);
	}
	async function save() {
		if (saving.current) return null;
		saving.current = true;
		setBusy(true);
		try {
			let did = doc.id;
			const row = {
				kind: doc.kind,
				doc_date: doc.doc_date,
				counted_by: doc.counted_by,
				remarks: doc.remarks
			};
			if (!did) {
				const number = await nextNumber(k.counter);
				const { data: u } = await db.auth.getUser();
				const { data, error } = await db.from("stock_docs").insert({
					...row,
					number,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				did = data.id;
			} else {
				const { error } = await db.from("stock_docs").update(row).eq("id", did);
				if (error) throw error;
			}
			if (removed.length) {
				const { error } = await db.from("stock_doc_lines").delete().in("id", removed);
				if (error) throw error;
			}
			const rows = lines.filter((l) => l.product_id).map((l, i) => {
				const { _new, ...r } = l;
				return {
					...r,
					doc_id: did,
					line_no: i + 1,
					old_qty: kind === "transfer" ? null : cur(l) ?? r.old_qty
				};
			});
			if (rows.length) {
				const { error } = await db.from("stock_doc_lines").upsert(rows, { onConflict: "id" });
				if (error) throw error;
			}
			setDirty(false);
			qc.invalidateQueries({ queryKey: ["stock-docs", kind] });
			qc.invalidateQueries({ queryKey: ["stock-doc", did] });
			if (isNew) navigate({
				to: "/stock-doc/$id",
				params: { id: did },
				search: {},
				replace: true
			});
			return did;
		} catch (e) {
			toast.error(e.message);
			return null;
		} finally {
			saving.current = false;
			setBusy(false);
		}
	}
	async function complete() {
		if (completing.current) return;
		completing.current = true;
		try {
			await completeOnce();
		} finally {
			completing.current = false;
		}
	}
	async function completeOnce() {
		const did = await save();
		if (!did) return;
		setBusy(true);
		const { error } = await db.rpc("complete_stock_doc", { _doc_id: did });
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Done. Stock is updated.");
		[
			"stock",
			"products",
			"stock-docs",
			"stock-doc"
		].forEach((q) => qc.invalidateQueries({ queryKey: [q] }));
	}
	async function cancel() {
		if (!doc.id) return;
		const { error } = await db.from("stock_docs").update({ status: "cancelled" }).eq("id", doc.id);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Cancelled.");
		qc.invalidateQueries({ queryKey: ["stock-doc", id] });
		qc.invalidateQueries({ queryKey: ["stock-docs", kind] });
	}
	if (!isNew && (isLoading || !loaded)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" })] });
	const shown = lines;
	const activeLocs = (locations ?? []).filter((l) => l.is_active);
	/** A scanned item: one more of it (a new line the first time). */
	const scanned = (p) => {
		const prod = products?.find((x) => x.id === p.id);
		setLines((ls) => {
			const i = ls.findIndex((l) => l.product_id === p.id);
			if (i >= 0) return ls.map((l, j) => j !== i ? l : kind === "transfer" ? {
				...l,
				qty: (Number(l.qty) || 0) + 1
			} : {
				...l,
				new_qty: (Number(l.new_qty) || 0) + 1
			});
			const base = {
				...newLine(ls.length + 1),
				product_id: p.id,
				location_id: prod?.default_location_id ?? activeLocs[0]?.id ?? null,
				shelf: prod?.default_shelf ?? "",
				...kind === "transfer" ? { qty: 1 } : { new_qty: 1 }
			};
			const empty = ls.findIndex((l) => !l.product_id);
			if (empty >= 0) return ls.map((l, j) => j === empty ? {
				...base,
				id: l.id,
				line_no: l.line_no,
				...l._new ? {} : { _new: false }
			} : l);
			return [...ls, base];
		});
		setDirty(true);
		if (!prod) qc.invalidateQueries({ queryKey: ["products", "pick-stock"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
		kind: {
			type: "stockdoc",
			kind: doc.kind
		},
		currentId: id,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
			wide: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: k.url,
					className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground print:hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }),
						" ",
						k.title
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
						children: isNew ? `New ${k.one.toLowerCase()}` : `${k.one} ${doc.number}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground print:hidden",
						children: k.help
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 print:hidden",
						children: [
							!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => window.print(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print"]
							}),
							!done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void save().then((ok) => ok && toast.success("Saved.")),
								disabled: busy,
								children: dirty || isNew ? "Save" : "Saved"
							}),
							!done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: complete,
								disabled: busy || !lines.some((l) => l.product_id),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
									" ",
									kind === "count" ? "Complete and fix stock" : "Save and complete"
								]
							}),
							!done && !isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								onClick: cancel,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "h-4 w-4" }), " Cancel"]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 rounded-2xl border bg-card p-4 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: doc.number ?? "(given when saved)",
								disabled: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: kind === "count" ? "Start date" : "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: doc.doc_date.slice(0, 10),
								disabled: done,
								onChange: (e) => patch({ doc_date: (/* @__PURE__ */ new Date(e.target.value + "T12:00:00")).toISOString() })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Status",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: doc.status === "open" ? "Open" : doc.status === "completed" ? `Completed ${fmtDate(doc.completed_at)}` : "Cancelled",
								disabled: true
							})
						}),
						kind === "count" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Counted by",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: doc.counted_by ?? "",
								disabled: done,
								onChange: (e) => patch({ counted_by: e.target.value || null })
							})
						})
					]
				}),
				!done && kind !== "adjust" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end gap-2 rounded-2xl border bg-card p-3 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-56 flex-1 space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Add every item that is in one place"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: addLoc,
							onValueChange: setAddLoc,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a place" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: activeLocs.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: l.id,
								children: l.name
							}, l.id)) })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: addByLocation,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListPlus, { className: "h-4 w-4" }), " Add items by location"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-x-auto rounded-2xl border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2",
									children: "Item"
								}),
								kind === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right",
										children: "Quantity"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "From location"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "From shelf"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "To location"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "To shelf"
									})
								] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Location"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2",
										children: "Shelf"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right",
										children: kind === "count" ? "System qty" : "Old qty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right",
										children: kind === "count" ? "Counted qty" : "New qty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 text-right",
										children: "Difference"
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-10 print:hidden" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y",
							children: shown.map((l, i) => {
								const before = done ? l.old_qty : cur(l) ?? l.old_qty;
								const diff = l.new_qty != null && before != null ? Number(l.new_qty) - Number(before) : null;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "align-top",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "min-w-64 px-3 py-2",
											children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: l.product_id ? pName.get(l.product_id) : l.description
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductPicker, {
												products: products ?? [],
												value: l.product_id,
												onPick: (pid) => patchLine(i, { product_id: pid })
											})
										}),
										kind === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumCell, {
													value: l.qty,
													disabled: done,
													onChange: (v) => patchLine(i, { qty: v })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocCell, {
													value: l.location_id,
													locs: activeLocs,
													names: locName,
													disabled: done,
													onChange: (v) => patchLine(i, { location_id: v })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													className: "h-9 w-24",
													value: l.shelf,
													disabled: done,
													onChange: (e) => patchLine(i, { shelf: e.target.value })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocCell, {
													value: l.to_location_id,
													locs: activeLocs,
													names: locName,
													disabled: done,
													onChange: (v) => patchLine(i, { to_location_id: v })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													className: "h-9 w-24",
													value: l.to_shelf,
													disabled: done,
													onChange: (e) => patchLine(i, { to_shelf: e.target.value })
												})
											})
										] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocCell, {
													value: l.location_id,
													locs: activeLocs,
													names: locName,
													disabled: done,
													onChange: (v) => patchLine(i, { location_id: v })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													className: "h-9 w-24",
													value: l.shelf,
													disabled: done,
													onChange: (e) => patchLine(i, { shelf: e.target.value })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-right text-muted-foreground",
												children: before == null ? "" : fmtQty(before)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumCell, {
													value: l.new_qty,
													disabled: done,
													onChange: (v) => patchLine(i, { new_qty: v })
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: `px-3 py-2 text-right font-semibold ${diff && diff < 0 ? "text-destructive" : diff ? "text-emerald-600" : ""}`,
												children: diff == null ? "" : `${diff > 0 ? "+" : ""}${fmtQty(diff)}`
											})
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-1 py-2 print:hidden",
											children: !done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												variant: "ghost",
												size: "icon",
												"aria-label": "Remove line",
												onClick: () => {
													if (!l._new) setRemoved((r) => [...r, l.id]);
													setLines((ls) => ls.filter((_, j) => j !== i));
													setDirty(true);
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
											})
										})
									]
								}, l.id);
							})
						})]
					}), !done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 print:hidden",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => {
									setLines((ls) => [...ls, newLine(ls.length + 1)]);
									setDirty(true);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanAddButton, {
								onProduct: scanned,
								hint: kind === "transfer" ? "Scan each item you move. Each scan adds one." : "Scan each item as you count it. Each scan counts one."
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Remarks",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							value: doc.remarks ?? "",
							disabled: done,
							onChange: (e) => patch({ remarks: e.target.value || null })
						})
					})
				})
			]
		})
	});
}
function NumCell({ value, onChange, disabled }) {
	const [s, setS] = (0, import_react.useState)(value == null ? "" : String(value));
	(0, import_react.useEffect)(() => {
		if ((s === "" ? null : Number(s)) !== value) setS(value == null ? "" : String(value));
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		className: "ml-auto h-9 w-24 text-right",
		inputMode: "decimal",
		value: s,
		disabled,
		onChange: (e) => {
			setS(e.target.value);
			const t = e.target.value.trim();
			onChange(t === "" ? null : Number.isFinite(Number(t)) ? Number(t) : value);
		}
	});
}
function LocCell({ value, locs, names, onChange, disabled }) {
	if (disabled) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value ? names.get(value) : "" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value: value ?? "",
		onValueChange: onChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
			className: "h-9 w-36",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Place" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: locs.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: l.id,
			children: l.name
		}, l.id)) })]
	});
}
function ProductPicker({ products, value, onPick }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const current = products.find((p) => p.id === value);
	const sorted = (0, import_react.useMemo)(() => products.filter((p) => p.item_type === "stocked").sort((a, b) => a.name.localeCompare(b.name)), [products]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "w-full justify-between font-normal",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: current?.name ?? "Choose a product"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[min(480px,90vw)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: "Type to search products" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No product found." }), sorted.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandItem, {
				value: `${p.name} ${p.id}`,
				keywords: [p.description ?? ""],
				onSelect: () => {
					onPick(p.id);
					setOpen(false);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: p.name
				})
			}, p.id))] })] })
		})]
	});
}
//#endregion
export { StockDocPage as component };
