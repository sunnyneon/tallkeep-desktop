import { n as db } from "./db-zltnVrwr.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as BUCKET } from "./shoebox-DPjYh4sk.mjs";
import { Ft as FileText } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/OriginalLink-B2Oav33w.js
var import_jsx_runtime = require_jsx_runtime();
/** "See the original": the file a bill, deposit or other record came from (dropped in the Shoebox). */
var T = (t) => db.from(t);
function OriginalLink({ type, id }) {
	const q = useQuery({
		queryKey: [
			"original",
			type,
			id
		],
		enabled: !!id,
		queryFn: async () => {
			const { data } = await T("shoebox_items").select("file_path,file_name").eq("target_type", type).eq("target_id", id).not("file_path", "is", null).limit(1).maybeSingle();
			return data ?? null;
		}
	});
	if (!q.data) return null;
	const open = async () => {
		const { data, error } = await db.storage.from(BUCKET).createSignedUrl(q.data.file_path, 300);
		if (error || !data) return void toast.error(error?.message ?? "Couldn't open the file.");
		window.open(data.signedUrl, "_blank");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		onClick: () => void open(),
		title: q.data.file_name,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }), " See the original"]
	});
}
//#endregion
export { OriginalLink as t };
