import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-8tQCpcOj.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { r as matchLoanStatement } from "./loans-IovjuDQY.mjs";
import { _ as takeShoebox, a as depositCheck, g as takeIn, h as skipItem, i as deleteItem, l as loadDone, m as setRemoved, n as addBill, o as fileAs, r as canTake, s as fileOf, t as BUCKET, u as loadWaiting } from "./shoebox-DY2vjnZ1.mjs";
import { $t as CircleQuestionMark, D as Search, Ft as FileText, I as Receipt, Kt as CreditCard, On as Banknote, P as RefreshCw, d as Upload, dn as Camera, en as CircleCheck, g as Trash2, gt as Landmark, ln as ChartLine, lt as LoaderCircle, yt as Inbox } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as queueScans } from "./scanQueue-C9-xAAQ0.mjs";
import { n as getStorage } from "./storage.functions-DrtGbnLU.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/shoebox-CGw_Gmkc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIND = {
	statement: {
		label: "Statement",
		icon: CreditCard
	},
	receipt: {
		label: "Receipt",
		icon: Receipt
	},
	bill: {
		label: "Bill",
		icon: FileText
	},
	check: {
		label: "Check",
		icon: Banknote
	},
	loan: {
		label: "Loan statement",
		icon: Landmark
	},
	investment: {
		label: "Investment statement",
		icon: ChartLine
	},
	unknown: {
		label: "Not sure yet",
		icon: CircleQuestionMark
	}
};
function ShoeboxPage() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: feedWaiting = 0 } = useQuery({
		queryKey: ["bank-feed-waiting"],
		refetchInterval: 15e3,
		queryFn: async () => {
			const { count } = await db.from("bank_transactions").select("id", {
				count: "exact",
				head: true
			}).eq("status", "new");
			return count ?? 0;
		}
	});
	const { data: accounts } = useAccounts();
	const { data: vendors } = useQuery({
		queryKey: ["vendors-lite"],
		queryFn: () => fetchAll("vendors", "id,name")
	});
	const { data: rules } = useQuery({
		queryKey: ["bank-rules"],
		queryFn: () => fetchAll("bank_rules", "id,contains,account_id")
	});
	const { data: waiting, isLoading } = useQuery({
		queryKey: ["shoebox", "waiting"],
		queryFn: loadWaiting
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("");
	const [older, setOlder] = (0, import_react.useState)(false);
	const [removed, setRemovedView] = (0, import_react.useState)(false);
	const [limit, setLimit] = (0, import_react.useState)(50);
	const [typed, setTyped] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setQ(typed), 300);
		return () => clearTimeout(t);
	}, [typed]);
	(0, import_react.useEffect)(() => setLimit(50), [
		q,
		kind,
		older,
		removed
	]);
	const doneQ = useQuery({
		queryKey: [
			"shoebox",
			"done",
			q,
			kind,
			older,
			removed,
			limit
		],
		queryFn: () => loadDone({
			q,
			kind,
			older,
			removed,
			limit
		}),
		placeholderData: (prev) => prev
	});
	const [busy, setBusy] = (0, import_react.useState)("");
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("needs");
	const ready = !!accounts && !!vendors && !!rules;
	const ctx = () => ({
		accounts: accounts ?? [],
		vendors: vendors ?? [],
		rules: rules ?? [],
		step: setBusy
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["shoebox"] });
		qc.invalidateQueries({ queryKey: ["receipts"] });
		qc.invalidateQueries({ queryKey: ["bills"] });
		qc.invalidateQueries({ queryKey: ["bank-txns"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	async function add(files) {
		const ok = files.filter(canTake);
		const bad = files.length - ok.length;
		if (bad) toast.error(`${bad} file${bad === 1 ? "" : "s"} skipped: use PDFs, photos, or bank files (CSV, OFX, QFX, QBO).`);
		if (!ok.length) return;
		const room = await getStorage().catch(() => null);
		if (room?.limit && room.used >= room.limit) {
			toast.error("Your files take all the space your plan includes. Delete files you don't need (Documents), or pick a bigger plan in Plan & billing.");
			return;
		}
		let same = 0;
		for (const [i, f] of ok.entries()) {
			setBusy(`${i + 1} of ${ok.length}: ${f.name}…`);
			try {
				if (!await takeIn(f, ctx())) same++;
			} catch (e) {
				toast.error(`${f.name}: ${e.message}`);
			}
			qc.invalidateQueries({ queryKey: ["shoebox"] });
		}
		setBusy("");
		refresh();
		if (same) toast.message(`${same} file${same === 1 ? " was" : "s were"} already in the Shoebox. To read ${same === 1 ? "it" : "them"} again, press Read it again on ${same === 1 ? "it" : "them"} under Done.`);
		setTab("needs");
	}
	const took = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!ready || took.current) return;
		took.current = true;
		const files = takeShoebox();
		if (files.length) add(files);
	}, [ready]);
	const needs = (waiting ?? []).filter((i) => i.status === "needs_you" || i.status === "failed");
	const working = (waiting ?? []).filter((i) => i.status === "reading");
	const done = doneQ.data?.rows ?? [];
	const doneCount = doneQ.data?.count ?? 0;
	const list = tab === "needs" ? [...working, ...needs] : done;
	const items = tab === "needs" ? waiting : doneQ.data?.rows;
	const month = (d) => new Date(d).toLocaleDateString("en-US", {
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Shoebox",
			text: "Drop bank and card statements, receipts, bills, checks and mortgage or loan statements here, many at once. Tallkeep works out what each one is, puts it where it belongs, and enters what it's sure of. The rest waits here for one click."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onDragOver: (e) => {
				e.preventDefault();
				setDrag(true);
			},
			onDragLeave: (e) => {
				if (!e.currentTarget.contains(e.relatedTarget)) setDrag(false);
			},
			onDrop: (e) => {
				e.preventDefault();
				setDrag(false);
				add([...e.dataTransfer.files]);
			},
			className: cn("flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed p-8 text-center transition", drag ? "border-[var(--section)] bg-[var(--section-soft)]" : "bg-card"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-10 w-10 text-[var(--section)]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold",
					children: busy ? "Working on it…" : "Drop files here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-lg text-sm text-muted-foreground",
					children: busy || "PDF statements and bills, photos of receipts and checks, or files from your bank's website (CSV, OFX, QFX, QBO). You can also drop files on any Tallkeep page."
				}),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
							" Choose files",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								multiple: true,
								accept: "image/*,.pdf,application/pdf,.csv,.ofx,.qfx,.qbo",
								className: "hidden",
								disabled: !ready,
								onChange: (e) => {
									add([...e.target.files ?? []]);
									e.target.value = "";
								}
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-4 py-2 text-sm font-medium hover:bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
							" Take a photo",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								capture: "environment",
								className: "hidden",
								disabled: !ready,
								onChange: (e) => {
									add([...e.target.files ?? []]);
									e.target.value = "";
								}
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab("needs"),
					className: cn("rounded-full border px-3 py-1.5 text-sm font-medium", tab === "needs" ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card"),
					children: [
						"Needs you (",
						needs.length + working.length,
						")"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab("done"),
					className: cn("rounded-full border px-3 py-1.5 text-sm font-medium", tab === "done" ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card"),
					children: ["Done", tab === "done" ? ` (${doneCount})` : ""]
				}),
				feedWaiting > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/banking",
					search: { tab: "review" },
					className: "ml-auto flex items-center gap-1.5 rounded-full border border-amber-300 bg-amber-50 px-3 py-1.5 text-sm font-medium text-amber-900 hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
					children: [
						feedWaiting,
						" ",
						feedWaiting === 1 ? "line waits" : "lines wait",
						" for you in Bank Feeds: review them →"
					]
				})
			]
		}),
		tab === "done" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-w-[220px] flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-8",
						placeholder: "Find a file: Fidelity, a name, an amount like 6974…",
						value: typed,
						onChange: (e) => setTyped(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "What it is",
					className: "h-9 rounded-md border bg-background px-2 text-sm",
					value: kind,
					onChange: (e) => setKind(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Every kind"
					}), Object.keys(KIND).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: k,
						children: KIND[k].label
					}, k))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: older,
							onChange: (e) => setOlder(e.target.checked)
						}),
						"Older than ",
						90,
						" days too"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: removed,
						onChange: (e) => setRemovedView(e.target.checked)
					}), "Removed from the list"]
				})
			]
		}),
		tab === "done" && !q && !older && !removed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Showing the last ",
				90,
				" days. Older files are kept: search for them, or tick \"Older than ",
				90,
				" days too\"."
			]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
		items && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
			children: tab === "needs" ? "Nothing waiting for you. Everything you dropped is in the books or where it belongs." : q || kind ? "Nothing found." : "Nothing yet."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: list.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [tab === "done" && (i === 0 || month(list[i - 1].created_at) !== month(it.created_at)) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-2 text-sm font-semibold text-muted-foreground",
					children: month(it.created_at)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemCard, {
					it,
					ctx,
					busy: !!busy,
					setBusy,
					onChanged: refresh,
					onCheck: async () => {
						try {
							queueScans([await fileOf(it)], "check");
							await skipItem(it.id);
							navigate({ to: "/checks-received" });
						} catch (e) {
							toast.error(e.message);
						}
					}
				})]
			}, it.id))
		}),
		tab === "done" && done.length < doneCount && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				onClick: () => setLimit((n) => n + 50),
				children: [
					"Show more (",
					doneCount - done.length,
					" more)"
				]
			})
		})
	] });
}
function ItemCard({ it, ctx, busy, setBusy, onChanged, onCheck }) {
	const K = KIND[it.kind];
	const { data: accounts } = useAccounts();
	const regs = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card")), [accounts]);
	const { data: features } = useFeatures();
	const personal = !!features?.includes("personal");
	const income = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.type === "income" || a.kind === "other_income")), [accounts]);
	const ai0 = it.ai ?? {};
	const [dep, setDep] = (0, import_react.useState)(() => ({
		bankId: regs.find((a) => a.kind === "bank")?.id ?? "",
		date: /^\d{4}-\d{2}-\d{2}$/.test(String(ai0["date"] ?? "")) ? String(ai0["date"]) : (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"),
		amount: ai0["amount"] != null ? String(ai0["amount"]) : "",
		payer: ai0["payer"] ? String(ai0["payer"]) : "",
		accountId: ""
	}));
	const spend = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.type === "expense" || a.kind === "fixed_asset" || a.kind === "other_asset")), [accounts]);
	const [acct, setAcct] = (0, import_react.useState)(it.account_id ?? "");
	const [statementPick, setStatementPick] = (0, import_react.useState)(it.kind === "statement");
	const d0 = (it.ai ?? {})["draft"] ?? {};
	const [bill, setBill] = (0, import_react.useState)({
		vendor: d0.vendor ?? "",
		total: d0.total != null ? String(d0.total) : "",
		billDate: d0.billDate ?? "",
		dueDate: d0.dueDate ?? "",
		ref: d0.ref ?? "",
		accountId: d0.accountId ?? ""
	});
	const run = async (what, fn) => {
		setBusy(what);
		try {
			await fn();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
			onChanged();
		}
	};
	const see = async () => {
		if (!it.file_path) return;
		const { data } = await db.storage.from(BUCKET).createSignedUrl(it.file_path, 300);
		if (data?.signedUrl) window.open(data.signedUrl, "_blank", "noopener");
	};
	const status = it.status === "reading" ? {
		text: "Reading…",
		cls: "bg-sky-100 text-sky-900"
	} : it.status === "done" ? {
		text: "Done",
		cls: "bg-emerald-100 text-emerald-900"
	} : it.status === "skipped" ? {
		text: "Skipped",
		cls: "bg-muted text-muted-foreground"
	} : it.status === "failed" ? {
		text: "Didn't work",
		cls: "bg-red-100 text-red-900"
	} : {
		text: "Needs you",
		cls: "bg-amber-100 text-amber-900"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(K.icon, { className: "mt-0.5 h-5 w-5 shrink-0 text-[var(--section)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: it.file_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("rounded px-1.5 py-0.5 text-xs font-medium", status.cls),
									children: status.text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										K.label,
										" · ",
										fmtDateTime(it.created_at)
									]
								})
							]
						}),
						it.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: it.summary
						}),
						it.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-destructive",
							children: it.error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex flex-wrap gap-3 text-sm",
							children: [
								it.file_path && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "text-primary underline",
									onClick: () => void see(),
									children: "See the file"
								}),
								it.target_type === "receipt" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/receipts",
									className: "text-primary underline",
									children: "Open Receipts"
								}),
								it.target_type === "bill" && it.target_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/bills/$id",
									params: { id: it.target_id },
									search: {},
									className: "text-primary underline",
									children: "Open the bill"
								}),
								it.target_type === "deposit" && it.account_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/register",
									search: { account: it.account_id },
									className: "text-primary underline",
									children: "Open the check register"
								}),
								it.target_type === "investment" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/investments",
									className: "text-primary underline",
									children: "Open Investments"
								}),
								it.target_type === "loan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/loans",
									className: "text-primary underline",
									children: "Open Mortgage & Loans"
								}),
								it.target_type === "bank_import" && it.account_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/banking",
									search: {
										account: it.account_id,
										tab: "review"
									},
									className: "text-primary underline",
									children: "Open Bank Feeds"
								})
							]
						})
					]
				})]
			}),
			(it.status === "needs_you" || it.status === "failed" || it.status === "skipped" && !it.target_type) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t pt-3",
				children: [
					statementPick && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "Account",
							className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
							value: acct,
							onChange: (e) => setAcct(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Which bank or card account?"
							}), regs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: accountLabel(a)
							}, a.id))]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							disabled: busy || !acct,
							onClick: () => void run(`${it.file_name}: bringing in the lines…`, () => fileAs(it, "statement", ctx(), acct)),
							children: "Bring in the lines"
						})]
					}),
					it.kind === "bill" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "From (vendor)",
								list: "shoebox-vendors",
								value: bill.vendor,
								onChange: (e) => setBill({
									...bill,
									vendor: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "shoebox-vendors",
								children: ctx().vendors.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: v.name }, v.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Amount due",
								inputMode: "decimal",
								value: bill.total,
								onChange: (e) => setBill({
									...bill,
									total: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Bill number",
								value: bill.ref,
								onChange: (e) => setBill({
									...bill,
									ref: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["Bill date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: bill.billDate,
									onChange: (e) => setBill({
										...bill,
										billDate: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["Due date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: bill.dueDate,
									onChange: (e) => setBill({
										...bill,
										dueDate: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["What it's for", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-10 w-full rounded-md border bg-background px-2 text-sm text-foreground",
									value: bill.accountId,
									onChange: (e) => setBill({
										...bill,
										accountId: e.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Choose an account…"
									}), spend.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: a.id,
										children: accountLabel(a)
									}, a.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: busy,
									onClick: () => void run("Adding the bill…", () => addBill(it.id, {
										vendor: bill.vendor,
										total: Number(bill.total.replace(/[$,\s]/g, "")) || null,
										billDate: bill.billDate || null,
										dueDate: bill.dueDate || null,
										ref: bill.ref || null,
										accountId: bill.accountId || null
									}, ctx())),
									children: "Add the bill"
								})
							})
						]
					}),
					it.kind !== "check" && it.kind !== "bill" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "What is it? Click one, and Tallkeep reads it again and puts it in the right place:"
					}),
					it.kind === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-xl border bg-muted/30 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: personal ? "Put this check in the bank:" : "Not for an invoice? Record it as a deposit:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										"aria-label": "Bank account",
										className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
										value: dep.bankId,
										onChange: (e) => setDep({
											...dep,
											bankId: e.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Into which account?"
										}), regs.filter((a) => a.kind === "bank").map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: a.id,
											children: accountLabel(a)
										}, a.id))]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "From",
										placeholder: "From (who wrote it)",
										value: dep.payer,
										onChange: (e) => setDep({
											...dep,
											payer: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "Amount",
										inputMode: "decimal",
										placeholder: "Amount",
										value: dep.amount,
										onChange: (e) => setDep({
											...dep,
											amount: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "Date deposited",
										type: "date",
										value: dep.date,
										onChange: (e) => setDep({
											...dep,
											date: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										"aria-label": "What it's for",
										className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
										value: dep.accountId,
										onChange: (e) => setDep({
											...dep,
											accountId: e.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "What is it for?"
										}), income.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: a.id,
											children: accountLabel(a)
										}, a.id))]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: recording the deposit…`, () => depositCheck(it, {
									...dep,
									amount: Number(dep.amount.replace(/[$,\s]/g, ""))
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-4 w-4" }), " Record the deposit"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							it.kind === "check" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: onCheck,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-4 w-4" }), " It pays invoices: open in Checks Received"]
							}),
							it.kind !== "bill" && it.kind !== "check" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a receipt…`, () => fileAs(it, "receipt", ctx())),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-4 w-4" }), " It's a receipt (already paid)"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a bill…`, () => fileAs(it, "bill", ctx())),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }), " It's a bill (to pay)"]
							})] }),
							!statementPick && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => setStatementPick(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-4 w-4" }), " It's a bank or card statement"]
							}),
							it.kind !== "loan" && it.kind !== "check" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a loan statement…`, () => fileAs(it, "loan", ctx())),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4" }), " It's a loan or mortgage statement"]
							}),
							it.kind !== "investment" && it.kind !== "check" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as an investment statement…`, () => fileAs(it, "investment", ctx())),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, { className: "h-4 w-4" }), " It's an investment or retirement statement (IRA, 401k)"]
							}),
							it.kind !== "check" && it.kind !== "statement" && personal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run("", async () => {
									const { error } = await db.from("shoebox_items").update({
										kind: "check",
										status: "needs_you",
										error: null
									}).eq("id", it.id);
									if (error) throw error;
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-4 w-4" }), " It's a check I got (to deposit)"]
							}),
							it.kind !== "check" && it.kind !== "statement" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: onCheck,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-4 w-4" }), " It's a check from a customer"]
							}),
							(it.status === "failed" || !!it.error) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: trying again…`, async () => {
									const f = await fileOf(it);
									await db.from("shoebox_items").delete().eq("id", it.id);
									await takeIn(f, ctx());
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), " Try again"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								disabled: busy,
								onClick: () => void run("", () => skipItem(it.id)),
								children: "Skip (leave it out of the books)"
							})
						]
					})
				]
			}),
			it.status === "done" && it.kind === "loan" && it.target_id && it.ai?.["loan_differs"] != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					disabled: busy,
					onClick: () => void run(`${it.file_name}: matching the statement…`, async () => {
						await matchLoanStatement(it.id, it.target_id);
						toast.success("The loan's balance now matches the statement.");
					}),
					children: "Make the books match the statement"
				})
			}),
			it.status === "done" && it.kind !== "unknown" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }), " Filed."]
			}),
			(it.status === "done" || it.status === "skipped") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					it.file_path && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						disabled: busy,
						onClick: () => void run(`${it.file_name}: reading it again…`, async () => {
							const f = await fileOf(it);
							await deleteItem(it);
							await takeIn(f, ctx());
						}),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), " Read it again"]
					}),
					it.archived_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						disabled: busy,
						onClick: () => void run("", () => setRemoved(it.id, false)),
						children: "Put it back on the list"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: busy,
						onClick: () => void run("", () => setRemoved(it.id, true)),
						children: "Remove from the list (the file is kept)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						className: "text-destructive",
						disabled: busy,
						onClick: () => {
							if (!window.confirm(`Delete ${it.file_name} for good? What it already put in the books stays (change or delete that where it went).`)) return;
							run("", () => deleteItem(it));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete the file"]
					})
				]
			})
		]
	});
}
//#endregion
export { ShoeboxPage as component };
