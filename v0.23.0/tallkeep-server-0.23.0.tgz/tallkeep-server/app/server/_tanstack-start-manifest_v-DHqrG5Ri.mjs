//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHqrG5Ri.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-DpjxAiVn.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-D5cgCzt_.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-ypaBJMyb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DpjxAiVn.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-C6nlkiIm.js",
			"/assets/log-out-ZBfunBd_.js",
			"/assets/testers.functions-Bm_BYe1A.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-D3_fXLpI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-OfVO2p0I.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DiUw2zie.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/queries-Dw_KgonS.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/label-CuRwyreD.js",
			"/assets/textarea-DOGcLXYQ.js",
			"/assets/dist-DNH6aKQH.js",
			"/assets/dialog-CDIs5JOI.js",
			"/assets/shoebox-DsJeclT2.js",
			"/assets/company-Bol4XNC8.js",
			"/assets/reports-D-ArNkrT.js",
			"/assets/access-CBHvPjm6.js",
			"/assets/LicenseCard-Cq7PH5mV.js",
			"/assets/Logo-BP-UOrLu.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-BReq-iJy.js",
			"/assets/log-out-ZBfunBd_.js",
			"/assets/admin.functions-CBxJBPhT.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-BP-UOrLu.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BKMm8UGU.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/label-CuRwyreD.js",
			"/assets/Logo-BP-UOrLu.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DZ5EhIK9.js",
			"/assets/testers.functions-Bm_BYe1A.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/buy.functions-34xkK74U.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DzM0UNFW.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/downloads.functions-Bwai0qnG.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-Dh9FNOau.js",
			"/assets/testers.functions-Bm_BYe1A.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/textarea-DOGcLXYQ.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-G15MuWWN.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/label-CuRwyreD.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DqYdMXUj.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/label-CuRwyreD.js",
			"/assets/Logo-BP-UOrLu.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CuutiEBY.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/upgrade.functions-UgHQKMwd.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-jF-I3EeH.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/label-CuRwyreD.js",
			"/assets/Logo-BP-UOrLu.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-DVbBAgxy.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Ba2WYmms.js", "/assets/StockDocList-DBl5mNNp.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CKRU7PDl.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/ai-vUJfXmv4.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CQ5H66NQ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DXJKLvHV.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/ai-vUJfXmv4.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DOC7O52z.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-ChPdyzHr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-gb2Vj6j5.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/personal-BItq6H-x.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/WhoPicker-aZlRyyvL.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CrEtUnc9.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-wWntzSB-.js", "/assets/AccountRegister-DRA-3yTT.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-C0Y_n2Uu.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-Cia0fcN1.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/money-DQlSq23C.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-Bw757kcz.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-vUJfXmv4.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-C2rIsxJx.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BQhUH0Db.js", "/assets/StockDocList-DBl5mNNp.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CH0ACyN5.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BmgOrfED.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DvH01J7Y.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BC5FRPYX.js", "/assets/PartyList-CdH-f1QQ.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CltgrRJj.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CegGuilC.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/storage.functions-C45Ktk7R.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-zGr0Hi3p.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DmYj3FLb.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Dr_pHSU2.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-COzRFS7U.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/members-CHC2LP3Y.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DEB4lyBY.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/personal-BItq6H-x.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/WhoPicker-aZlRyyvL.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-ChZy8Oiu.js", "/assets/SalesList-BAseZJia.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-ZUyyFTeU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-DmCIZo_d.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-oTYpy5Or.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CqxA1vMx.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/loans-DOC7O52z.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Dcvap-V1.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-D5z1xZ7S.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CB6I6Ob3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/personal-BItq6H-x.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/WhoPicker-aZlRyyvL.js",
			"/assets/reminders-CL9px0By.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Dj_g_o0a.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BzfKAZTb.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/personal-BItq6H-x.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/WhoPicker-aZlRyyvL.js",
			"/assets/generateCategoricalChart-BD16nNJ_.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-C-0rV_S-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-BD16nNJ_.js",
			"/assets/BarChart-BLV35EzG.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DLX3PwZR.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BYiA79e-.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-C9ew_XSN.js",
			"/assets/createServerFn-Bbje8Y1C.js",
			"/assets/auth-middleware-U5EZs87h.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/storage.functions-C45Ktk7R.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BlVPXVzQ.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CIK5b9VA.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/badge-BoXc8LVc.js",
			"/assets/checkbox-D6Ax0ayH.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-BawdwLXx.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-Doy4SVn_.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-OuPzypiW.js", "/assets/SalesList-BAseZJia.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DnWjE-uj.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/ai-vUJfXmv4.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-C45Ktk7R.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-4oYkYw_X.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/money-DQlSq23C.js",
			"/assets/badge-BoXc8LVc.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DLQ_Jf2O.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-Cfu_-lSS.js", "/assets/AccountRegister-DRA-3yTT.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-ldDhFf2J.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/badge-BoXc8LVc.js",
			"/assets/MoneyAccountPick-D3CD4KWu.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-eoyosLxb.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-F2cZFLPN.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BD16nNJ_.js",
			"/assets/BarChart-BLV35EzG.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-B9vIwUxP.js", "/assets/SalesList-BAseZJia.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-B0ddl4fH.js", "/assets/SalesList-BAseZJia.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-B4jWUUjM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CE3suQt2.js",
			"/assets/createServerFn-Bbje8Y1C.js",
			"/assets/auth-middleware-U5EZs87h.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-BPtYotE2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-CciNS0zk.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/QuickBooksImport-DvH01J7Y.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-Dd2jeLkj.js",
			"/assets/footers-CPaSDKUc.js",
			"/assets/PrintFrame-3YKf4VtH.js",
			"/assets/checkbox-D6Ax0ayH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DK-Tj_sF.js",
			"/assets/FeaturePicker-B2-rO3yG.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-COABDH7s.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/FeaturePicker-B2-rO3yG.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-C9pvovyn.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-D6dKM-ao.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/photos-Dd2jeLkj.js",
			"/assets/stockmove-kRrKZwCz.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DdJXwW2G.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/loans-DOC7O52z.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-C45Ktk7R.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-GhbAf8sa.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/PrintFrame-3YKf4VtH.js",
			"/assets/DocPdf-s2c0mBn-.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-B0C0_3oG.js",
			"/assets/createServerFn-Bbje8Y1C.js",
			"/assets/auth-middleware-U5EZs87h.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/badge-BoXc8LVc.js",
			"/assets/MoneyAccountPick-D3CD4KWu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BdcY4aP7.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/StockDialogs-D6dKM-ao.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/stockmove-kRrKZwCz.js",
			"/assets/checkbox-D6Ax0ayH.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-D_REq_sm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/members-CHC2LP3Y.js",
			"/assets/WhoPicker-aZlRyyvL.js",
			"/assets/reminders-CL9px0By.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BAP8sdeu.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/tickets.functions-ByqtCihr.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-D14wlrpW.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DocDzwtJ.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Cl7-jDWy.js", "/assets/StockDocList-DBl5mNNp.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-fyuT3yKR.js", "/assets/PartyList-CdH-f1QQ.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B95bDsRk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/tickets.functions-ByqtCihr.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-D7Y0yYd1.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/badge-BoXc8LVc.js",
			"/assets/workorders-DjcMi04R.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DmlkerPH.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-rkAmsqQe.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/AdminAccount-CDMZ6-Bc.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CcPlbgvg.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/downloads.functions-Bwai0qnG.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-Cule-P45.js",
			"/assets/createServerFn-Bbje8Y1C.js",
			"/assets/auth-middleware-U5EZs87h.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DVaiKNn_.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-CVwKoYa_.js",
			"/assets/testers.functions-Bm_BYe1A.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CYgRExhd.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-geB-mwdT.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-C9hH7n6J.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CYgRExhd.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-34xkK74U.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-1T2QeahU.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/textarea-DOGcLXYQ.js",
			"/assets/support.functions-DocDzwtJ.js",
			"/assets/HelpParts-CbDp1W50.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CBPwfdHy.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-Bs-hSnDP.js",
			"/assets/manual._slug-CzOSytfh.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-C-f6EJBl.js",
			"/assets/createServerFn-Bbje8Y1C.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-CYgRExhd.js",
			"/assets/skeleton-21arGzJr.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-6S7zoPTi.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-CYgRExhd.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-UgHQKMwd.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CGckgzHM.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-vUJfXmv4.js",
			"/assets/personal-BItq6H-x.js",
			"/assets/reminders-CL9px0By.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BMg-codS.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/AdminAccount-CDMZ6-Bc.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DygMAVM8.js", "/assets/ManualFrame-Bs-hSnDP.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CoaKyNlS.js", "/assets/AccountRegister-DRA-3yTT.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Plnvgek-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/OriginalLink-Ctgo5F6L.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/realestate-C5vHZy8C.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-aWvvrCDh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BVqlv4Ms.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/realestate-C5vHZy8C.js",
			"/assets/money-DQlSq23C.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BFMckA_A.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/SideList-Csi_JpNM.js",
			"/assets/PartyHistory-DqxcSHOk.js",
			"/assets/tabs-B34ZpKrC.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-lrtvdGGi.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-BPtYotE2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/SideList-Csi_JpNM.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-Bq2OlqbB.js",
			"/assets/MoneyAccountPick-D3CD4KWu.js",
			"/assets/footers-CPaSDKUc.js",
			"/assets/PrintFrame-3YKf4VtH.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Bdwr_pZE.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-D6dKM-ao.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-D5z1xZ7S.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/badge-BoXc8LVc.js",
			"/assets/SideList-Csi_JpNM.js",
			"/assets/tabs-B34ZpKrC.js",
			"/assets/photos-Dd2jeLkj.js",
			"/assets/stockmove-kRrKZwCz.js",
			"/assets/workorders-DjcMi04R.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-D9NXbcIC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-BPtYotE2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/SideList-Csi_JpNM.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-Bq2OlqbB.js",
			"/assets/MoneyAccountPick-D3CD4KWu.js",
			"/assets/footers-CPaSDKUc.js",
			"/assets/PrintFrame-3YKf4VtH.js",
			"/assets/checkbox-D6Ax0ayH.js",
			"/assets/workorders-DjcMi04R.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-ByqtCihr.js",
			"/assets/users.functions-DK-Tj_sF.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-BKxsRPoR.js",
			"/assets/select-CrWDTPRF.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/SideList-Csi_JpNM.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-AttaeVdc.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/quickadd-DhA1BIsA.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DocDzwtJ.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DPBEo-5K.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BX_ctKDx.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/SideList-Csi_JpNM.js",
			"/assets/PartyHistory-DqxcSHOk.js",
			"/assets/tabs-B34ZpKrC.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BgD7mPem.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/sales-C2rIsxJx.js",
			"/assets/footers-CPaSDKUc.js",
			"/assets/tickets.functions-ByqtCihr.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CAGOpivD.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-CYgRExhd.js",
			"/assets/input-Dnwz1AGO.js",
			"/assets/skeleton-21arGzJr.js",
			"/assets/AdminAccount-CDMZ6-Bc.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-C5-1ew6J.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-CYgRExhd.js",
			"/assets/textarea-DOGcLXYQ.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DocDzwtJ.js",
			"/assets/HelpParts-CbDp1W50.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-DlPAo59V.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-21arGzJr.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
