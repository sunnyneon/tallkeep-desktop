import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { listWaitlist } from "./admin.functions-CWOUAaID.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/waitlist-Dffiq6WF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WaitlistPage() {
	const q = useQuery({
		queryKey: ["admin-waitlist"],
		queryFn: () => listWaitlist()
	});
	const [kind, setKind] = (0, import_react.useState)("waitlist");
	const [find, setFind] = (0, import_react.useState)("");
	const all = q.data?.entries ?? [];
	const f = find.trim().toLowerCase();
	const rows = all.filter((e) => e.kind === kind).filter((e) => !f || `${e.name} ${e.email} ${e.company} ${e.message}`.toLowerCase().includes(f)).sort((a, b) => b.created_at.localeCompare(a.created_at));
	const download = () => {
		const esc = (v) => `"${(v ?? "").replace(/"/g, "\"\"")}"`;
		const csv = ["Date,Name,Email,Company,Message", ...rows.map((e) => [
			e.created_at,
			e.name,
			e.email,
			e.company,
			e.message
		].map(esc).join(","))].join("\n");
		const a = document.createElement("a");
		a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
		a.download = `tallkeep-${kind}.csv`;
		a.click();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Waitlist",
		text: "People who joined the list or sent a message on tallkeep.com.",
		actions: rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: download,
			className: "text-sm font-semibold text-primary underline",
			children: "Download this list (Excel)"
		})
	}), q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32" }) : !q.data?.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "rounded-2xl border bg-card p-6 text-muted-foreground",
		children: [
			"Not linked to the website yet. Add the secret ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "TALLKEEP_SITE_KEY" }),
			" to this app (the same value as the website's ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "ADMIN_API_KEY" }),
			") and the list shows here."
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-lg bg-muted p-1 text-sm",
					children: [["waitlist", "Waitlist"], ["message", "Messages"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setKind(k),
						className: cn("rounded-md px-3 py-1", kind === k && "bg-card font-semibold shadow-sm"),
						children: [
							label,
							" (",
							all.filter((e) => e.kind === k).length,
							")"
						]
					}, k))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: find,
					onChange: (e) => setFind(e.target.value),
					placeholder: "Find a name, email or company",
					className: "w-64"
				})]
			}),
			q.data.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-b p-4 text-sm text-red-700",
				children: ["Couldn't read the website: ", q.data.problem]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Company"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Message"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b align-top last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap p-3",
								children: fmtDateTime(e.created_at)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: e.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${e.email}`,
									className: "text-primary underline",
									children: e.email
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: e.company
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-md whitespace-pre-wrap p-3",
								children: e.message
							})
						]
					}, i)), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "p-6 text-center text-muted-foreground",
						children: "Nothing here yet."
					}) })] })]
				})
			})
		]
	})] });
}
//#endregion
export { WaitlistPage as component };
