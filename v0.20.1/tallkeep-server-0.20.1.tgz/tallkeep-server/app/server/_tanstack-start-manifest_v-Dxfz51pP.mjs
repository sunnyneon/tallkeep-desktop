//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dxfz51pP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-mQb1W1I4.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BOnD92nf.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CPMf25U9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mQb1W1I4.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BIfzWWN1.js",
			"/assets/log-out-Bn3M5Equ.js",
			"/assets/testers.functions-B5i_goJo.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-D3_fXLpI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-kjqQtM7b.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DjOkpAZ5.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/queries--EUx0VCF.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/label-EkY2EH2Q.js",
			"/assets/textarea-xp2iUc5A.js",
			"/assets/dist-Dtcr2ErU.js",
			"/assets/dialog-CQ4P0pI_.js",
			"/assets/shoebox-BXuXw5fO.js",
			"/assets/company-CJ01NU37.js",
			"/assets/reports-gi3P3Ahh.js",
			"/assets/access-URIUw7im.js",
			"/assets/LicenseCard-CTaTSjgF.js",
			"/assets/Logo-DhZkPVQ4.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CObov9XJ.js",
			"/assets/log-out-Bn3M5Equ.js",
			"/assets/admin.functions-CQYZdOrx.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DhZkPVQ4.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-B6LXbQUH.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/label-EkY2EH2Q.js",
			"/assets/Logo-DhZkPVQ4.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-SiUuInGQ.js",
			"/assets/testers.functions-B5i_goJo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/buy.functions-Cibs73bI.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-Cvgmqs3w.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/downloads.functions-BIqZJJI_.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-CNbSMINk.js",
			"/assets/testers.functions-B5i_goJo.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/textarea-xp2iUc5A.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CeTPYknB.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/label-EkY2EH2Q.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BJlUGCRa.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/label-EkY2EH2Q.js",
			"/assets/Logo-DhZkPVQ4.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CTkXnUAI.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/upgrade.functions-DPgTu7lk.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-C4TKKKzc.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/label-EkY2EH2Q.js",
			"/assets/Logo-DhZkPVQ4.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CDuRQ8sl.js",
			"/assets/select-DBKAok5A.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BH-zxAxx.js", "/assets/StockDocList-DdQQ-V5n.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BBv7r-Oq.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/ai.functions-DAyNhZwG.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-B0xSTfXE.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-j3k11mnS.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/statementDates-BY7IkzPi.js",
			"/assets/ai.functions-DAyNhZwG.js",
			"/assets/bankfile-Cbkga9Hp.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DrauHm0w.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DMyAJTse.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-C5Ax4dYr.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CRTvMoTF.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CCmoWXcQ.js", "/assets/AccountRegister-C2f7Gd6U.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-HqHIZTcT.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BH_zPfBM.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BGi-sTUc.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-DAyNhZwG.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BMoxvjWb.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-DuiNGGtz.js", "/assets/StockDocList-DdQQ-V5n.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D-NCP2nU.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-EVyQJAxR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BbwacfAV.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DGo0F__S.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CSDLnwbf.js", "/assets/PartyList-BnVu77P0.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CfVZDl-B.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CeKe8-_6.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/storage.functions-T0yXNBo3.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-YO73JuA3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-Cbkga9Hp.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DEdhH9jv.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Eg8PYL9w.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CeB0y8qz.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/members-BbwacfAV.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-Dm3DrY_L.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-C5Ax4dYr.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-4pkiYQCe.js", "/assets/SalesList-1AJFnKq8.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-Bts5dQAX.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-C-ni5RIQ.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-8VpWpWn-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-mvjC1zBF.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-DeBARDKY.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-hiVD42wA.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Df087EXq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-C5Ax4dYr.js",
			"/assets/reminders-PYdD1RAJ.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-AiMWyt3D.js",
			"/assets/select-DBKAok5A.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BJCDqUgs.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-C5Ax4dYr.js",
			"/assets/generateCategoricalChart-DQK0psuU.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-gf-Gkop4.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-DQK0psuU.js",
			"/assets/BarChart-BK6L1Owv.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DeV4j6GX.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-Bt2N2hif.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DsCAQl9e.js",
			"/assets/createServerFn-hW_B9_h2.js",
			"/assets/auth-middleware-CcOL8Xor.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/storage.functions-T0yXNBo3.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DabLVmc2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DRlowelV.js",
			"/assets/select-DBKAok5A.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/badge-CKP5JBim.js",
			"/assets/checkbox-qXpCIu7f.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-BEr6y5lY.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DAXDSjY_.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DBKAok5A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-Cwq9MMG2.js", "/assets/SalesList-1AJFnKq8.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-B608PPZc.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/ai.functions-DAyNhZwG.js",
			"/assets/bankfile-Cbkga9Hp.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-T0yXNBo3.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CEwsYVBA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CKP5JBim.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BbTpO4Nm.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-9mnkHs1S.js", "/assets/AccountRegister-C2f7Gd6U.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-B0bVH49Q.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CKP5JBim.js",
			"/assets/MoneyAccountPick-Dr10A8SZ.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-CXFTWk0w.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BdfevzKX.js",
			"/assets/select-DBKAok5A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DQK0psuU.js",
			"/assets/BarChart-BK6L1Owv.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-Cr5tMORw.js", "/assets/SalesList-1AJFnKq8.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-B9oIAX1m.js", "/assets/SalesList-1AJFnKq8.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-0gz7Ttfg.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DMv88EMF.js",
			"/assets/createServerFn-hW_B9_h2.js",
			"/assets/auth-middleware-CcOL8Xor.js",
			"/assets/select-DBKAok5A.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-CrwPqsyr.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/QuickBooksImport-DGo0F__S.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-qXpCIu7f.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-CBOZ8_HC.js",
			"/assets/FeaturePicker-FNKWOO3H.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BzhCDFuk.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/FeaturePicker-FNKWOO3H.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CKhzW4n6.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-kGhNQAFd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DrHllHUc.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/loans-DhR1zMtS.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-T0yXNBo3.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-C-DzkyDF.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/DocPdf-CoPZg48v.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-bkBVHSdA.js",
			"/assets/createServerFn-hW_B9_h2.js",
			"/assets/auth-middleware-CcOL8Xor.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CKP5JBim.js",
			"/assets/MoneyAccountPick-Dr10A8SZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CM-LBHmO.js",
			"/assets/select-DBKAok5A.js",
			"/assets/StockDialogs-kGhNQAFd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/checkbox-qXpCIu7f.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-pCPqWP2R.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-C5Ax4dYr.js",
			"/assets/reminders-PYdD1RAJ.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DXIWyfkx.js",
			"/assets/select-DBKAok5A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/tickets.functions-CR5R-REm.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-D8SjDyOO.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-gvNeyQwq.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CkN0Yvi9.js", "/assets/StockDocList-DdQQ-V5n.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-p_SPyALV.js", "/assets/PartyList-BnVu77P0.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-CbgPa6Ec.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/tickets.functions-CR5R-REm.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DTqEba4z.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/badge-CKP5JBim.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-FRZTeRD4.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-C30rJxEN.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/AdminAccount-DvoLEBbT.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CodeezxH.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/downloads.functions-BIqZJJI_.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-DqBr0KOr.js",
			"/assets/createServerFn-hW_B9_h2.js",
			"/assets/auth-middleware-CcOL8Xor.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BbzxrbUC.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-jhVq1EUe.js",
			"/assets/testers.functions-B5i_goJo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-OpGddHxS.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-B48-n53v.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-Cibs73bI.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CwRITNS8.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/textarea-xp2iUc5A.js",
			"/assets/support.functions-gvNeyQwq.js",
			"/assets/HelpParts-BTxC4Hr8.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CNkJR0Lf.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CQNdWNyK.js",
			"/assets/manual._slug-DkIM4UJP.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DppEa3qX.js",
			"/assets/createServerFn-hW_B9_h2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CwLuUdLg.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DPgTu7lk.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-LLZj5_E3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-DAyNhZwG.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/reminders-PYdD1RAJ.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DFf51OQS.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/AdminAccount-DvoLEBbT.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-vDH53paW.js", "/assets/ManualFrame-CQNdWNyK.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B7xKLZ2b.js", "/assets/AccountRegister-C2f7Gd6U.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CCumM4TF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/OriginalLink-BCLWTzEs.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-DPH91RzI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CP-ktWk4.js",
			"/assets/select-DBKAok5A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CP8PyU87.js",
			"/assets/PartyHistory-DE2JizSV.js",
			"/assets/tabs-SY-3HFiW.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-c9Pm7WDs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DBKAok5A.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CP8PyU87.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/MoneyAccountPick-Dr10A8SZ.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DurPeucC.js",
			"/assets/PrintFrame-DdqbEiyY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CcIQQWMV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DBKAok5A.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-kGhNQAFd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-hiVD42wA.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/badge-CKP5JBim.js",
			"/assets/SideList-CP8PyU87.js",
			"/assets/tabs-SY-3HFiW.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DgFP27h9.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DBKAok5A.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CP8PyU87.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/MoneyAccountPick-Dr10A8SZ.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DurPeucC.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-qXpCIu7f.js",
			"/assets/workorders-B0SB58LO.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-CR5R-REm.js",
			"/assets/users.functions-CBOZ8_HC.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D40x992l.js",
			"/assets/select-DBKAok5A.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CP8PyU87.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CX0Fg2eO.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-gvNeyQwq.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CJRokvLW.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-bITJ_qfa.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/SideList-CP8PyU87.js",
			"/assets/PartyHistory-DE2JizSV.js",
			"/assets/tabs-SY-3HFiW.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-Bv-7KwhZ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/tickets.functions-CR5R-REm.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CzTduuB2.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/input-CCvaf4a_.js",
			"/assets/skeleton-Ce1engHa.js",
			"/assets/AdminAccount-DvoLEBbT.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CoqxXyZm.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-D0RcCxsp.js",
			"/assets/textarea-xp2iUc5A.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-gvNeyQwq.js",
			"/assets/HelpParts-BTxC4Hr8.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Bm9cg9mx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-Ce1engHa.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
