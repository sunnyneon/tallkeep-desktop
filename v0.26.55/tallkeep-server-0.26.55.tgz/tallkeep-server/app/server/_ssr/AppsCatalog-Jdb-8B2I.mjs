import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, n as fmtDate, r as fmtDateTime } from "./format-CgElbAz-.mjs";
import { t as supabase } from "./client-DGBuL_KZ.mjs";
import { n as db } from "./db-adodfNYI.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as activeCompanyId } from "./company-DGga70DW.mjs";
import { a as FEATURE_KEYS, c as useLicensed, i as FEATURES, n as BUSINESS_TYPES, r as BUSINESS_TYPE_KEYS, s as useFeatures } from "./addons-Ct4lu9m9.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-ClBCcJiH.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { An as BellRing, At as Globe, D as Send, Dt as HardHat, F as RefreshCw, In as ArrowRight, Jt as CreditCard, Ln as ArrowRightLeft, On as Bitcoin, P as Repeat, Pt as FlaskConical, S as Smartphone, Vt as Factory, W as PenLine, Zt as CloudCog, a as Wallet, dt as LoaderCircle, gt as LifeBuoy, it as MessageSquareReply, j as ScanBarcode, qt as DatabaseBackup, rn as CircleCheck, st as Mail, vt as Landmark, xn as Building2 } from "../_libs/lucide-react.mjs";
import { a as featureHome } from "./nav-BIrQ7OjK.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { t as Switch } from "./switch-Dkd0-FGF.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as listBankLinks } from "./bankfeed.functions-veTUwPfW.mjs";
import { f as whoSells, r as EDITIONS, t as ADDONS_FOR_SALE } from "./editions-Dt3M8_qe.mjs";
import { a as syncCardPayments, n as disconnectStripe, o as useCardPay, t as connectStripe } from "./cardpay-Cw-5Dru6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/AppsCatalog-Jdb-8B2I.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Send today's invoice emails and reminders now, for the company this person works in. */
var runInvoiceMailNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("3fa78c0d4deecf4aa7060dfbd35fd6db8574d21f01040d6d7950d2bc21ca50f3"));
var localToday = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
var late = (due) => Math.round((Date.parse(`${localToday()}T12:00:00`) - Date.parse(`${due.slice(0, 10)}T12:00:00`)) / 864e5);
var parseDays = (v) => [...new Set(v.split(/[^\d]+/).map(Number).filter((n) => n > 0 && n < 1e3))].sort((a, b) => a - b);
/** Options → Features: overdue reminders, and what the invoice emails did. */
function RemindersCard() {
	const qc = useQueryClient();
	const { data: rules, error } = useQuery({
		queryKey: ["reminder-rules"],
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("reminders_on,reminder_days,reminders_from,reminder_note").maybeSingle();
			if (error) throw error;
			return data;
		},
		retry: false
	});
	const [f, setF] = (0, import_react.useState)(null);
	const [daysText, setDaysText] = (0, import_react.useState)("3, 10, 30");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (rules) {
			setF(rules);
			setDaysText((rules.reminder_days ?? [
				3,
				10,
				30
			]).join(", "));
		}
	}, [rules]);
	const { data: due } = useQuery({
		queryKey: ["reminders-due", f?.reminders_from],
		enabled: !!f,
		queryFn: async () => {
			let q = db.from("sales_orders").select("id,number,customer_name,balance,due_date,customer_id").eq("status", "invoiced").gt("balance", .009).not("due_date", "is", null).lt("due_date", `${localToday()}T00:00:00`).order("due_date").limit(500);
			if (f?.reminders_from) q = q.gte("due_date", f.reminders_from);
			const { data } = await q;
			return data ?? [];
		}
	});
	const { data: log } = useQuery({
		queryKey: ["invoice-emails"],
		queryFn: async () => {
			const { data, error } = await db.from("invoice_emails").select("*").order("at", { ascending: false }).limit(30);
			if (error) return [];
			const rows = data ?? [];
			const ids = [...new Set(rows.map((r) => r.sales_order_id))];
			const { data: o } = ids.length ? await db.from("sales_orders").select("id,number,customer_name").in("id", ids) : { data: [] };
			const by = new Map((o ?? []).map((x) => [x.id, x]));
			return rows.map((r) => ({
				...r,
				order: by.get(r.sales_order_id)
			}));
		}
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: "Overdue reminders need database step 72 (docs/db/072_invoice_emails.sql)."
	});
	if (!f) return null;
	const days = parseDays(daysText);
	const first = days[0] ?? 3;
	const waiting = (due ?? []).filter((d) => late(d.due_date) >= first);
	async function save(next) {
		setF(next);
		const { error } = await db.from("company_settings").update(next).eq("company_id", await activeCompanyId() ?? "");
		if (error) return void toast.error(error.message);
		toast.success("Saved.");
		qc.invalidateQueries({ queryKey: ["reminder-rules"] });
	}
	async function turn(on) {
		if (on) {
			const from = f.reminders_from ?? localToday();
			if (!window.confirm(`Turn on overdue reminders?\n\nCustomers get a friendly email ${days.join(", ")} days after an invoice's due date, until it's paid. Only invoices due from ${fmtDate(from)} on (you can change that date).`)) return;
			await save({
				...f,
				reminders_on: true,
				reminders_from: from,
				reminder_days: days
			});
		} else await save({
			...f,
			reminders_on: false
		});
	}
	async function sendNow() {
		setBusy(true);
		try {
			const r = await runInvoiceMailNow();
			toast.success(r.invoices || r.reminders || r.failed ? `Sent ${r.invoices} new invoice(s) and ${r.reminders} reminder(s)${r.failed ? `; ${r.failed} didn't go (see below)` : ""}.` : "Nothing to send today.");
			qc.invalidateQueries({ queryKey: ["invoice-emails"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Overdue reminders"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every morning, customers with an unpaid invoice past its due date get a friendly email with the invoice attached. It stops as soon as the invoice is paid. Turn it off for one customer on their page (Send overdue reminders)."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: f.reminders_on,
					onCheckedChange: (v) => void turn(v)
				}), "Send overdue reminders"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 text-sm sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Days after the due date"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: daysText,
							onChange: (e) => setDaysText(e.target.value),
							onBlur: () => {
								const d = parseDays(daysText);
								if (!d.length) return void setDaysText(f.reminder_days.join(", "));
								setDaysText(d.join(", "));
								if (d.join() !== f.reminder_days.join()) save({
									...f,
									reminder_days: d
								});
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "One reminder on each of these days (a late start sends only the latest one)."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Only invoices due from"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: f.reminders_from ?? "",
							onChange: (e) => void save({
								...f,
								reminders_from: e.target.value || null
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "Older ones are left alone, so turning this on doesn't email old debts."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "grid gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Add a line to the reminder (optional)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 2,
					placeholder: "e.g. You can also pay by check to 123 Main St, or call us at 555-0100.",
					value: f.reminder_note ?? "",
					onChange: (e) => setF({
						...f,
						reminder_note: e.target.value
					}),
					onBlur: () => {
						if ((f.reminder_note ?? "") !== (rules?.reminder_note ?? "")) save({
							...f,
							reminder_note: f.reminder_note?.trim() || null
						});
					}
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border bg-muted/40 px-3 py-2 text-sm",
				children: waiting.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: waiting.length }),
					" invoice",
					waiting.length === 1 ? " is" : "s are",
					" late enough for a reminder:",
					" ",
					waiting.slice(0, 5).map((d) => `${d.number} (${d.customer_name ?? ""}, ${fmtMoney(d.balance)})`).join(", "),
					waiting.length > 5 ? ", …" : "",
					". Ones already reminded at this step aren't sent again."
				] }) : "No invoice is late enough for a reminder right now."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void sendNow(),
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4" }), " Send today's invoice emails now"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Otherwise they go by themselves from 8 in the morning."
				})]
			}),
			!!log?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mb-1 text-sm font-semibold",
				children: "Recent invoice emails"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-md border text-sm",
				children: log.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-x-3 gap-y-0.5 px-3 py-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-36 text-xs text-muted-foreground",
							children: fmtDateTime(r.at)
						}),
						r.order ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/sales/$id",
							params: { id: r.sales_order_id },
							search: {},
							className: "text-primary underline-offset-2 hover:underline",
							children: r.order.number
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.order?.customer_name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [r.kind === "new" ? "New invoice" : `Reminder ${r.step}`, r.to_email ? ` to ${r.to_email}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: r.ok ? "text-emerald-700" : "text-red-700",
							children: r.ok ? "Sent" : `Didn't go: ${r.why ?? ""}`
						})
					]
				}, r.id))
			})] })
		]
	});
}
/** Where to buy what the license doesn't have (the office computer opens it in the browser). */
var BUY_URL = "https://app.tallkeep.com/buy?upgrade=1";
/** Pick the kind of business (which suggests features), then turn features on or off. */
function FeaturePicker({ type, features, onType, onToggle, disabled }) {
	const { data: licensed } = useLicensed();
	const group = (main) => FEATURE_KEYS.filter((k) => FEATURES[k].main === main);
	const box = (k) => {
		const locked = !!licensed && !licensed.includes(k);
		const w = locked ? whoSells(k) : null;
		const need = w?.addon ? `the ${ADDONS_FOR_SALE[w.addon].label} add-on` : w?.edition ? EDITIONS[w.edition].label : "";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: `flex items-start gap-3 px-4 py-3 text-sm ${locked ? "opacity-70" : "cursor-pointer"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "mt-0.5 h-4 w-4",
				checked: !locked && features.includes(k),
				disabled: disabled || locked,
				onChange: (e) => onToggle(k, e.target.checked)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: FEATURES[k].label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: FEATURES[k].text
					}),
					locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs",
						children: [
							"Comes with ",
							need,
							".",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: BUY_URL,
								target: "_blank",
								rel: "noreferrer",
								className: "font-medium text-[#C2410C] underline",
								children: "Add it to my license"
							})
						]
					})
				]
			})]
		}, k);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium",
					children: "What kind of business is it?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: BUSINESS_TYPE_KEYS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled,
						onClick: () => onType(t),
						className: `rounded-xl border p-3 text-left text-sm transition ${type === t ? "border-[var(--section)] bg-[var(--section-soft)]" : "hover:bg-muted/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: BUSINESS_TYPES[t].label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: BUSINESS_TYPES[t].text
						})]
					}, t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted-foreground",
					children: "Picking a kind turns on the features it usually needs. Change any of them below."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium",
				children: "Main parts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: group(true).map(box)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium",
				children: "Extras"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: group(false).map(box)
			})] })
		]
	});
}
async function call(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/email${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var HELP = {
	gmail: "Gmail needs an app password, not your normal password: Google Account → Security → 2-Step Verification (turn it on) → App passwords → make one named Tallkeep, and paste the 16 letters here.",
	outlook: "Use your Microsoft account email and an app password (Microsoft account → Security → App passwords). On Microsoft 365, your admin may need to allow SMTP sending for this mailbox.",
	ionos: "Use the full email address and its email password from IONOS.",
	yahoo: "Yahoo needs an app password: Account Security → Generate app password.",
	icloud: "iCloud needs an app-specific password: appleid.apple.com → Sign-In and Security → App-Specific Passwords.",
	zoho: "Use the full email address; with two-step sign-in on, make an app password in Zoho.",
	godaddy: "Use the full email address and its email password.",
	other: "Your email provider's help pages list the outgoing mail server (SMTP) and port."
};
/** Options → Company: the email account the office computer sends invoices and quotes from. */
function EmailSetupCard() {
	const qc = useQueryClient();
	const { data: st, error } = useQuery({
		queryKey: ["desktop-email"],
		queryFn: () => call("GET")
	});
	const [f, setF] = (0, import_react.useState)({
		provider: "gmail",
		host: "",
		port: "",
		user: "",
		pass: "",
		fromEmail: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [testTo, setTestTo] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!st) return;
		setF((x) => ({
			...x,
			provider: st.provider ?? "gmail",
			host: st.host,
			port: st.port ? String(st.port) : "",
			user: st.user,
			fromEmail: st.fromEmail !== st.user ? st.fromEmail : ""
		}));
		setTestTo((t) => t || st.user);
	}, [st]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: ["Email: ", error.message]
	});
	if (!st) return null;
	const preset = st.presets[f.provider];
	const pick = (provider) => {
		const p = st.presets[provider];
		setF({
			...f,
			provider,
			host: p?.host ?? "",
			port: p?.port ? String(p.port) : "587"
		});
	};
	async function save() {
		setBusy(true);
		try {
			const next = await call("PUT", "", {
				provider: f.provider,
				host: f.host || preset?.host,
				port: Number(f.port) || preset?.port || 587,
				user: f.user,
				pass: f.pass || void 0,
				fromEmail: f.fromEmail || f.user
			});
			qc.setQueryData(["desktop-email"], next);
			setF((x) => ({
				...x,
				pass: ""
			}));
			setEditing(false);
			toast.success("Email is set up. Send yourself a test to be sure.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function test() {
		setBusy(true);
		try {
			await call("POST", "/test", { to: testTo });
			toast.success(`Test email sent to ${testTo}.`);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["desktop-email"] });
		}
	}
	async function forget() {
		if (!window.confirm("Stop sending email from this account? Invoices can't be emailed until it's set up again.")) return;
		qc.setQueryData(["desktop-email"], await call("DELETE"));
	}
	const showForm = !st.ready || editing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-2 font-display text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-5 w-5" }), " Email"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Invoices, quotes, statements and support replies are sent from your own email account, through this office computer. Customers see them from you, and replies come back to you."
			})] }),
			st.ready && !editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [
								"Sending from ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.fromEmail }),
								st.provider && st.presets[st.provider] ? ` (${st.presets[st.provider].label})` : "",
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setEditing(true),
							children: "Change account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void forget(),
							children: "Stop sending"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: testTo,
							onChange: (e) => setTestTo(e.target.value),
							placeholder: "you@yourbusiness.com",
							className: "max-w-xs",
							"aria-label": "Send a test to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							disabled: busy || !testTo,
							onClick: () => void test(),
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Send a test email"]
						}),
						st.lastTest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground",
							children: ["Last test: ", st.lastTest.ok ? "worked" : `didn't work (${st.lastTest.why})`]
						})
					]
				})]
			}),
			showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					save();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Your email provider"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: f.provider,
									onChange: (e) => pick(e.target.value),
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									children: Object.entries(st.presets).map(([k, p]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: k,
										children: p.label
									}, k))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Email address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: f.user,
									onChange: (e) => setF({
										...f,
										user: e.target.value
									}),
									placeholder: "billing@yourbusiness.com",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: [
											"gmail",
											"yahoo",
											"icloud",
											"outlook"
										].includes(f.provider) ? "App password" : "Password"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										value: f.pass,
										onChange: (e) => setF({
											...f,
											pass: e.target.value
										}),
										placeholder: st.hasPassword ? "Leave empty to keep the saved one" : "",
										autoComplete: "new-password"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: HELP[f.provider] ?? HELP["other"]
									})
								]
							}),
							f.provider === "other" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Outgoing mail server (SMTP)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.host,
									onChange: (e) => setF({
										...f,
										host: e.target.value
									}),
									placeholder: "smtp.example.com"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Port"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.port,
									onChange: (e) => setF({
										...f,
										port: e.target.value
									}),
									placeholder: "587"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Send from a different address (optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "email",
										value: f.fromEmail,
										onChange: (e) => setF({
											...f,
											fromEmail: e.target.value
										}),
										placeholder: "Leave empty to send from the email address above"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: "Only if your provider lets this account send as that address (an alias)."
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "The password stays on this office computer only. Tallkeep checks it with your email provider before saving."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: busy,
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Check and save"]
						}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setEditing(false),
							children: "Cancel"
						})]
					})
				]
			})
		]
	});
}
/** Options → Company: let customers pay invoices by card, through the business's own Stripe. */
function CardPaymentsCard({ admin }) {
	const qc = useQueryClient();
	const { data: st, isLoading, error } = useCardPay();
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const r = new URLSearchParams(window.location.search).get("card");
		if (r === "connected") toast.success("Stripe account connected.");
		else if (r === "failed") toast.error("Stripe didn't connect. Try again.");
	}, []);
	async function connect(existing = false) {
		if (!st) return;
		setBusy(true);
		try {
			const { url } = st.onboardingUrl && !existing ? { url: st.onboardingUrl } : await connectStripe(st.company, existing);
			window.location.href = url;
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	async function disconnect() {
		if (!st) return;
		if (!window.confirm("Disconnect Stripe from this company? Pay now links already sent stop working. Payments already made stay in the books. You can connect again (or a different account) right after.")) return;
		setBusy(true);
		try {
			await disconnectStripe(st.company);
			toast.success("Stripe disconnected.");
			qc.invalidateQueries({ queryKey: ["card-pay"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function check() {
		setBusy(true);
		try {
			const r = await syncCardPayments();
			toast.success(r.recorded ? `${r.recorded} card payment${r.recorded === 1 ? "" : "s"} put in the books.` : "No new card payments.");
			if (r.recorded) qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 font-display text-xl font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-5 w-5" }), " Card payments (Pay now)"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Add a \"Pay now\" link to invoices you email, and let customers accept quotes online. Customers pay by card, Apple Pay, Google Pay or bank account on Stripe's secure page; the money goes to your own Stripe account, and Tallkeep marks the invoice paid and records Stripe's fee by itself. Each company connects its own Stripe."
		})] }), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Checking…"
		}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: error.message
		}) : st?.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1",
						children: [
							"Customers can pay ",
							st.businessName ? `${st.businessName}'s ` : "",
							"invoices online (card, Apple Pay, bank account). Payments appear here within a few minutes; bank payments take a few business days."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void check(),
						disabled: busy,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), "Check for payments now"]
					}),
					admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => void disconnect(),
						disabled: busy,
						children: "Disconnect Stripe"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Payments go into the ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Stripe" }),
					" account in your chart of accounts, with Stripe's fee in Card Processing Fees",
					st.appFeePct ? ` (that fee includes Tallkeep's ${st.appFeePct}%)` : "",
					". When Stripe pays out to your bank, record it as a transfer from Stripe to the bank."
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				st?.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-red-700",
					children: st.problem
				}),
				st?.linked && (st.why || st.needs?.length || st.submitted) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: st.why ?? (st.needs?.length ? "Stripe needs a few more details." : "Stripe has your details and is checking them.") }),
						!!st.needs?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1",
							children: [
								"Still needed: ",
								st.needs.join(", "),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs",
							children: "Card payments turn on by themselves when Stripe is done; open this page again to check."
						})
					]
				}),
				admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void connect(true),
						disabled: busy,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), st?.linked ? "Connect a different Stripe account" : "I have a Stripe account: sign in"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void connect(false),
						disabled: busy,
						children: !st?.linked ? "Create a new Stripe account" : st.needs?.length ? "Give Stripe the missing details" : "Open Stripe setup again"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "An admin can connect Stripe here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Already take cards with Stripe? Sign in and keep your account, payouts and history. New to Stripe? It asks for the business's details and the bank account for payouts (about 10 minutes). Stripe's usual card fee applies."
				})
			]
		})]
	});
}
/**
* Options → Apps: everything in Tallkeep that's turned on or set up, in one place (like an app
* store). Each app is a part of Tallkeep (a feature that shows in the menu), something to set up
* (email, reminders, Stripe), or a page to open (bank connections). New versions add new apps here.
*/
var APP_SECTIONS = [
	{
		key: "try",
		label: "Try Tallkeep"
	},
	{
		key: "paid",
		label: "Get paid"
	},
	{
		key: "email",
		label: "Customers & email"
	},
	{
		key: "books",
		label: "Banking & books"
	},
	{
		key: "parts",
		label: "More parts of Tallkeep"
	},
	{
		key: "computer",
		label: "This computer"
	}
];
var APPS = [
	{
		key: "payments",
		name: "Online payments",
		text: "A Pay now link on every invoice: card or bank, through your own Stripe account.",
		icon: CreditCard,
		colors: ["#7C6CF2", "#5146D8"],
		section: "paid",
		desktopOnly: true
	},
	{
		key: "reminders",
		name: "Overdue reminders",
		text: "Friendly emails to customers when an invoice is past due.",
		icon: BellRing,
		colors: ["#F5A23A", "#E07B12"],
		section: "paid"
	},
	{
		key: "followups",
		name: "Quote follow-ups",
		text: "Reminds you (or the customer) about quotes nobody answered.",
		icon: MessageSquareReply,
		colors: ["#2BB8A6", "#13897B"],
		section: "paid"
	},
	{
		key: "repeating",
		name: "Repeating invoices",
		text: "Invoices that make and send themselves every week, month or year.",
		icon: Repeat,
		colors: ["#4FB477", "#2E8A55"],
		section: "paid",
		link: "/repeating"
	},
	{
		key: "email",
		name: "Sending email",
		text: "Send quotes and invoices from your own email account.",
		icon: Mail,
		colors: ["#3B9BF0", "#1D6FD0"],
		section: "email",
		desktopOnly: true
	},
	{
		key: "wording",
		name: "Email wording",
		text: "Your own words for quote, invoice and reminder emails.",
		icon: PenLine,
		colors: ["#6A7BF0", "#4553C9"],
		section: "email"
	},
	{
		key: "support",
		name: "Support Desk",
		text: "Customers open tickets on your support page; you reply by email and invoice the work.",
		icon: LifeBuoy,
		colors: ["#F0697A", "#CC3D50"],
		section: "email",
		feature: "support"
	},
	{
		key: "tickets",
		name: "Website tickets",
		text: "Service tickets from your website become invoices here.",
		icon: Globe,
		colors: ["#33A8D6", "#1A7FAD"],
		section: "email",
		feature: "tickets"
	},
	{
		key: "bank",
		name: "Bank connections",
		text: "New bank and card lines come in every morning.",
		icon: Landmark,
		colors: ["#34B58A", "#178A64"],
		section: "books",
		link: "/bank-connections"
	},
	{
		key: "quickbooks",
		name: "Move from QuickBooks",
		text: "Bring in customers, vendors, products and history from QuickBooks.",
		icon: ArrowRightLeft,
		colors: ["#5DBB4F", "#3A8F2E"],
		section: "books"
	},
	{
		key: "crypto_tax",
		name: "Crypto tax",
		text: "Coinbase, Kraken and other exchanges: gains and income for the tax return.",
		icon: Bitcoin,
		colors: ["#F7B53B", "#DB8A0F"],
		section: "books",
		feature: "crypto_tax"
	},
	{
		key: "personal",
		name: "Personal money",
		text: "A budget, net worth and investments for a household.",
		icon: Wallet,
		colors: ["#E07BB5", "#B94C8D"],
		section: "books",
		feature: "personal"
	},
	{
		key: "serials",
		name: "Serial numbers",
		text: "One number per unit: who bought it and when, for warranty and returns.",
		icon: ScanBarcode,
		colors: ["#8B7CF0", "#6553CF"],
		section: "parts",
		link: "/serials"
	},
	{
		key: "work_orders",
		name: "Work Orders",
		text: "Build products from parts: recipes and work orders.",
		icon: Factory,
		colors: ["#A0815F", "#7A5C3D"],
		section: "parts",
		feature: "work_orders"
	},
	{
		key: "real_estate",
		name: "Real estate",
		text: "Properties, tenants, leases, rent and short-term stays.",
		icon: Building2,
		colors: ["#5C8FD6", "#3A68AD"],
		section: "parts",
		feature: "real_estate"
	},
	{
		key: "tech_pay",
		name: "Technician pay",
		text: "Technician pay requests, what's paid, and totals for taxes.",
		icon: HardHat,
		colors: ["#F28B4B", "#CF6224"],
		section: "parts",
		feature: "tech_pay"
	},
	{
		key: "connect",
		name: "Reach it from anywhere",
		text: "Your own web address for Tallkeep, from home or a phone. No setup.",
		icon: CloudCog,
		colors: ["#4CB6E8", "#2183C2"],
		section: "computer",
		desktopOnly: true
	},
	{
		key: "backup",
		name: "Nightly backup",
		text: "A copy of your books every night, to the folder you pick.",
		icon: DatabaseBackup,
		colors: ["#7F8DA3", "#556277"],
		section: "computer",
		desktopOnly: true,
		ownerOnly: true
	},
	{
		key: "phone",
		name: "Phone app",
		text: "Tallkeep on your phone's home screen, like an app.",
		icon: Smartphone,
		colors: ["#56C1A4", "#2F9479"],
		section: "computer",
		link: "/manual/use-on-a-phone"
	},
	{
		key: "sample",
		name: "Sample company",
		text: "Turn on a made-up sign shop to try anything without touching your books. Turn it off any time.",
		icon: FlaskConical,
		colors: ["#B07CE8", "#8550C4"],
		section: "try",
		ownerOnly: true
	}
];
var desktop = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1",
	"VITE_TALLKEEP_VERSION": "0.26.55"
}["VITE_TALLKEEP_DESKTOP"];
/** The office computer's own settings (email, Connect, backups, website link). */
async function office(path) {
	if (!desktop) return null;
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/${path}`, { headers: { authorization: `Bearer ${data.session?.access_token ?? ""}` } }).catch(() => null);
	if (!r?.ok) return null;
	return await r.json().catch(() => null);
}
async function count(table, filter) {
	let q = db.from(table).select("id", {
		count: "exact",
		head: true
	});
	if (filter) q = q.eq(filter[0], filter[1]);
	const { count: n, error } = await q;
	return error ? null : n ?? 0;
}
/** Is each app on, set up, or does it need a look? */
function useStatuses() {
	const { data: features } = useFeatures();
	const { data: card } = useCardPay();
	const { data: s } = useQuery({
		queryKey: ["apps", "settings"],
		staleTime: 3e4,
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			return data;
		}
	});
	const { data: n } = useQuery({
		queryKey: ["apps", "counts"],
		queryFn: async () => ({
			repeating: await count("recurring"),
			serials: await count("products", ["track_serials", true]),
			sample: await count("companies", ["is_sample", true])
		})
	});
	const { data: banks } = useQuery({
		queryKey: ["apps", "banks"],
		retry: false,
		queryFn: () => listBankLinks().catch(() => null)
	});
	const { data: pc } = useQuery({
		queryKey: ["apps", "office"],
		enabled: desktop,
		queryFn: async () => ({
			email: await office("email"),
			connect: await office("connect"),
			backup: await office("backups"),
			website: await office("website")
		})
	});
	const on = (yes, onLabel = "On", offLabel = "Not set up") => yes ? {
		state: "on",
		label: onLabel
	} : {
		state: "off",
		label: offLabel
	};
	const has = (f) => !!features?.includes(f);
	const out = {
		payments: card ? card.connected ? {
			state: "on",
			label: "Connected"
		} : card.linked || card.problem ? {
			state: "attention",
			label: "Finish setting up"
		} : {
			state: "off",
			label: "Not set up"
		} : void 0,
		reminders: s ? on(s.reminders_on) : void 0,
		followups: s ? on(s.followup_enabled) : void 0,
		wording: s ? Object.keys(s.email_wording ?? {}).length ? {
			state: "on",
			label: "Your own wording"
		} : {
			state: "none",
			label: "Standard wording"
		} : void 0,
		repeating: n?.repeating != null ? on(n.repeating > 0, `${n.repeating} repeating`, "None yet") : void 0,
		serials: n?.serials != null ? on(n.serials > 0, `${n.serials} product${n.serials === 1 ? "" : "s"}`, "No products use them") : void 0,
		sample: n?.sample != null ? on(n.sample > 0, "On", "Off") : void 0,
		bank: banks ? banks.some((b) => b.last_error) ? {
			state: "attention",
			label: "Needs a look"
		} : on(banks.length > 0, `${banks.length} connected`) : void 0,
		quickbooks: {
			state: "none",
			label: ""
		},
		phone: {
			state: "none",
			label: ""
		},
		email: pc?.email ? pc.email.ready ? pc.email.lastTest && !pc.email.lastTest.ok ? {
			state: "attention",
			label: "Last test failed"
		} : {
			state: "on",
			label: "Ready"
		} : {
			state: "off",
			label: "Not set up"
		} : void 0,
		connect: pc?.connect ? pc.connect.problem ? {
			state: "attention",
			label: "Needs a look"
		} : on(pc.connect.active, "On", "Off") : void 0,
		backup: pc?.backup ? pc.backup.last ? pc.backup.last.ok ? {
			state: "on",
			label: "Backing up"
		} : {
			state: "attention",
			label: "Last backup failed"
		} : {
			state: "none",
			label: "Not run yet"
		} : void 0
	};
	for (const a of APPS) if (a.feature && features) out[a.key] = on(has(a.feature), "On", "Off");
	if (desktop && has("tickets") && pc?.website && !pc.website.ready) out["tickets"] = {
		state: "attention",
		label: "Link to your website"
	};
	return out;
}
/** The app's icon: white symbol on a colored tile, with a dot when it's on or needs a look. */
function AppIcon({ app, status, big }) {
	const Icon = app.icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("relative shrink-0", big ? "h-16 w-16" : "h-14 w-14"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex h-full w-full items-center justify-center rounded-2xl shadow-md ring-1 ring-black/5",
			style: { background: `linear-gradient(135deg, ${app.colors[0]}, ${app.colors[1]})` },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("text-white drop-shadow-sm", big ? "h-8 w-8" : "h-7 w-7") })
		}), (status?.state === "on" || status?.state === "attention") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("absolute -right-1 -top-1 h-4 w-4 rounded-full border-2 border-card", status.state === "on" ? "bg-emerald-500" : "bg-amber-500"),
			"aria-label": status.label
		})]
	});
}
/**
* Options → Apps. `panels` are the setup boxes (from Settings) for apps set up in place.
*/
function AppsCatalog({ owner, panels }) {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const status = useStatuses();
	const { data: features } = useFeatures();
	const { data: licensed } = useLicensed();
	const [open, setOpen] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const read = () => {
			if (window.location.hash !== "#sample") return;
			const a = APPS.find((x) => x.key === "sample");
			if (a && (!a.ownerOnly || owner)) setOpen(a);
		};
		read();
		window.addEventListener("hashchange", read);
		return () => window.removeEventListener("hashchange", read);
	}, [owner]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const shown = APPS.filter((a) => (!a.desktopOnly || desktop) && (!a.ownerOnly || owner));
	async function setFeature(f, enable) {
		setBusy(true);
		const now = features ?? [];
		const next = enable ? Array.from(/* @__PURE__ */ new Set([...now, f])) : now.filter((x) => x !== f);
		const { error } = await db.from("company_settings").update({ addons: next }).eq("company_id", await activeCompanyId() ?? "");
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(`${FEATURES[f].label} is ${enable ? "on. It's in the menu now" : "off"}.`);
		qc.invalidateQueries({ queryKey: ["company-addons"] });
	}
	function pick(a) {
		if (a.link) if (a.link.startsWith("/manual/")) window.open(a.link, "_blank");
		else navigate({ to: a.link });
		else setOpen(a);
	}
	const button = (a) => {
		const st = status[a.key];
		if (a.link) return "Open";
		if (a.feature) return st?.state === "off" ? "Turn on" : "Open";
		return st?.state === "off" ? "Set up" : "Open";
	};
	const cur = open;
	const curFeature = cur?.feature;
	const notLicensed = !!curFeature && !!licensed && !licensed.includes(curFeature);
	const curOn = !!curFeature && !!features?.includes(curFeature);
	const home = curFeature ? featureHome(curFeature) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Apps"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Everything you can turn on or set up, in one place. A green dot means it's on; orange means it needs a look. New apps come with new versions of Tallkeep."
			})] }),
			APP_SECTIONS.map((sec) => {
				const apps = shown.filter((a) => a.section === sec.key);
				if (!apps.length) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold uppercase tracking-wide text-muted-foreground",
						children: sec.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
						children: apps.map((a) => {
							const st = status[a.key];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "button",
								tabIndex: 0,
								onClick: () => pick(a),
								onKeyDown: (e) => (e.key === "Enter" || e.key === " ") && pick(a),
								className: "group flex cursor-pointer gap-4 rounded-2xl border bg-card p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
									app: a,
									status: st
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold leading-tight",
											children: a.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 line-clamp-2 text-xs text-muted-foreground",
											children: a.text
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: cn("text-xs font-medium", st?.state === "on" ? "text-emerald-700 dark:text-emerald-400" : st?.state === "attention" ? "text-amber-700 dark:text-amber-400" : "text-muted-foreground"),
												children: [st?.label ?? "", a.price ? ` · ${a.price}` : ""]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: cn("rounded-full px-3 py-1 text-xs font-semibold transition", st?.state === "off" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground group-hover:bg-muted/70"),
												children: button(a)
											})]
										})
									]
								})]
							}, a.key);
						})
					})]
				}, sec.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!cur,
				onOpenChange: (v) => !v && setOpen(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto sm:max-w-3xl",
					children: cur && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "flex-row items-center gap-4 space-y-0 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
								app: cur,
								status: status[cur.key],
								big: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
									className: "text-xl",
									children: cur.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: curFeature ? FEATURES[curFeature].text : cur.text })]
							})]
						}),
						curFeature && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-center gap-2 rounded-2xl border bg-muted/30 p-4",
							children: notLicensed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "This isn't in your plan. Add it in Options → Plan & computer."
							}) : curOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mr-auto text-sm font-medium text-emerald-700 dark:text-emerald-400",
									children: "On: its pages are in the menu."
								}),
								home && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: home,
										onClick: () => setOpen(null),
										children: [
											"Open ",
											cur.name,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									disabled: busy,
									onClick: () => void setFeature(curFeature, false),
									children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Turn off"]
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-auto text-sm text-muted-foreground",
								children: "Off. Turning it on adds its pages to the menu; turning it off later hides them and keeps everything."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								disabled: busy,
								onClick: () => void setFeature(curFeature, true),
								children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Turn on"]
							})] })
						}),
						(!curFeature || curOn) && panels[cur.key]
					] })
				})
			})
		]
	});
}
//#endregion
export { EmailSetupCard as a, CardPaymentsCard as i, AppIcon as n, FeaturePicker as o, AppsCatalog as r, RemindersCard as s, APPS as t };
