import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as fmtDate } from "./format-CgElbAz-.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { Yt as Copy, dt as LoaderCircle, z as Plus } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { listCoupons, makeCoupon, offLabel, stopCoupon } from "./coupons.functions-DG5zQwlf.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/coupons-DpkrA80q.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var BLANK = {
	code: "",
	note: "",
	kind: "percent",
	amount: "25",
	forDesktop: true,
	forOnline: true,
	onlineForever: false,
	maxUses: "10",
	endsOn: ""
};
function copy(text) {
	navigator.clipboard.writeText(text).then(() => toast.success("Copied."), () => toast.error("Couldn't copy. Select the text and copy it."));
}
function CouponsAdmin() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["admin-coupons"],
		queryFn: () => listCoupons(),
		retry: false
	});
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [f, setF] = (0, import_react.useState)(BLANK);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save(ev) {
		ev.preventDefault();
		setBusy(true);
		try {
			await makeCoupon({ data: {
				code: f.code,
				note: f.note,
				kind: f.kind,
				amount: Number(f.amount),
				forDesktop: f.forDesktop,
				forOnline: f.forOnline,
				onlineForever: f.onlineForever,
				maxUses: f.maxUses ? Number(f.maxUses) : null,
				endsOn: f.endsOn || null
			} });
			toast.success(`${f.code.trim().toUpperCase()} is ready to share.`);
			setF(BLANK);
			setAdding(false);
			qc.invalidateQueries({ queryKey: ["admin-coupons"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function stop(id, code) {
		if (!window.confirm(`Turn off ${code}? Nobody can use it after this. It can't be turned back on.`)) return;
		try {
			await stopCoupon({ data: { id } });
			toast.success(`${code} is turned off.`);
			qc.invalidateQueries({ queryKey: ["admin-coupons"] });
		} catch (e) {
			toast.error(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Discount codes",
				text: "Make a code for friends and family. They type it when they buy, or you send them a link with it filled in.",
				actions: !adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setAdding(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Make a code"]
				})
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Code"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									autoFocus: true,
									placeholder: "FAMILY25",
									value: f.code,
									onChange: (e) => setF({
										...f,
										code: e.target.value.toUpperCase()
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "3 to 20 letters, numbers or dashes."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Note for you (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "For the family",
								value: f.note,
								onChange: (e) => setF({
									...f,
									note: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Discount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "w-28",
										inputMode: "decimal",
										required: true,
										value: f.amount,
										onChange: (e) => setF({
											...f,
											amount: e.target.value
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: "h-9 rounded-md border bg-background px-2",
										value: f.kind,
										onChange: (e) => setF({
											...f,
											kind: e.target.value
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "percent",
											children: "% off"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "amount",
											children: "$ off"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "Taken off the price at checkout, founders price included."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Works on"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: f.forDesktop,
										onChange: (e) => setF({
											...f,
											forDesktop: e.target.checked
										})
									}), "Desktop (buy once)"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: f.forOnline,
										onChange: (e) => setF({
											...f,
											forOnline: e.target.checked
										})
									}), "Online plans"]
								})
							]
						}),
						f.forOnline && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Online plans: how long"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-9 rounded-md border bg-background px-2",
								value: f.onlineForever ? "forever" : "once",
								onChange: (e) => setF({
									...f,
									onlineForever: e.target.value === "forever"
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "once",
									children: "First payment only"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "forever",
									children: "Every payment, for as long as they stay"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "How many people can use it"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								placeholder: "No limit",
								value: f.maxUses,
								onChange: (e) => setF({
									...f,
									maxUses: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Last day it works (optional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: f.endsOn,
								onChange: (e) => setF({
									...f,
									endsOn: e.target.value
								})
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Make this code"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => setAdding(false),
						children: "Cancel"
					})]
				})]
			}),
			q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32 w-full" }) : q.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
				children: /coupons/.test(q.error.message) ? "Discount codes need database step 80 (docs/db/080_coupons.sql)." : q.error.message
			}) : !q.data?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
				children: "No codes yet. Press Make a code."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card",
				children: q.data.map((c) => {
					const links = [...c.for_desktop ? [["Desktop", `https://app.tallkeep.com/buy?code=${c.code}`]] : [], ...c.for_online ? [["Online", `https://app.tallkeep.com/signup?code=${c.code}`]] : []];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-base font-semibold",
										children: c.code
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: offLabel(c)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: c.working ? "default" : "outline",
										children: !c.active ? "Turned off" : c.working ? "Working" : "Used up or ended"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [[c.for_desktop && "Desktop", c.for_online && "Online"].filter(Boolean).join(" and "), c.for_online && (c.online_forever ? " · online: every payment" : " · online: first payment")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-muted-foreground",
											children: [
												"Used ",
												c.used ?? "–",
												c.max_uses ? ` of ${c.max_uses}` : "",
												c.ends_on ? ` · until ${fmtDate(c.ends_on)}` : ""
											]
										}), c.active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => void stop(c.id, c.code),
											children: "Turn off"
										})]
									})
								]
							}),
							c.note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: c.note
							}),
							c.working && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-2",
								children: links.map(([label, url]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => copy(url),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-3.5 w-3.5" }),
										" Copy ",
										label.toLowerCase(),
										" link"
									]
								}, url))
							})
						]
					}, c.id);
				})
			})
		]
	});
}
//#endregion
export { CouponsAdmin as component };
