import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/queries-CStjB5rm.js
function useLocations() {
	return useQuery({
		queryKey: ["locations"],
		queryFn: async () => {
			const { data, error } = await db.from("locations").select("id,name,notes,is_active").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
}
function useShelves() {
	return useQuery({
		queryKey: ["shelves"],
		queryFn: () => fetchAll("shelves", "id,location_id,name")
	});
}
function useCategories() {
	return useQuery({
		queryKey: ["categories"],
		queryFn: async () => {
			const { data, error } = await db.from("categories").select("id,name,parent_id").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
}
async function loadMyAccess() {
	const r = await db.rpc("my_access");
	if (!r.error && r.data) return r.data;
	const { data: u } = await db.auth.getUser();
	if (!u.user) return {
		member: false,
		owner: false,
		admin: false,
		zones: null
	};
	const { data, error } = await db.from("user_roles").select("role, zones").eq("user_id", u.user.id);
	if (error) throw new Error(r.error?.message ?? error.message);
	const rows = data ?? [];
	const owner = rows.some((x) => x.role === "admin");
	const limited = rows.filter((x) => x.zones != null);
	return {
		member: rows.length > 0,
		owner,
		admin: owner,
		zones: owner || !rows.length || limited.length < rows.length ? null : Array.from(new Set(limited.flatMap((x) => x.zones ?? [])))
	};
}
function useMyAccess() {
	return useQuery({
		queryKey: ["my-access-now"],
		staleTime: 6e4,
		queryFn: loadMyAccess
	});
}
/** Admin of the company I'm working in (or of every company). */
function useIsAdmin() {
	const q = useMyAccess();
	return {
		...q,
		data: q.data ? q.data.admin : void 0
	};
}
/** Admin of every company: manages users, companies, the plan and backups. */
function useIsOwner() {
	const q = useMyAccess();
	return {
		...q,
		data: q.data ? q.data.owner : void 0
	};
}
/** Map of id -> name for quick labels. */
function byId(rows) {
	const m = /* @__PURE__ */ new Map();
	rows?.forEach((r) => m.set(r.id, r.name));
	return m;
}
function usePaymentTerms() {
	return useQuery({
		queryKey: ["payment_terms"],
		queryFn: async () => {
			const { data, error } = await db.from("payment_terms").select("id,name,days_due,is_active").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
}
function useTaxRates() {
	return useQuery({
		queryKey: ["tax_rates"],
		queryFn: async () => {
			const { data, error } = await db.from("tax_rates").select("id,name,rate,is_active").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
}
function usePriceLists() {
	return useQuery({
		queryKey: ["price_lists"],
		queryFn: async () => {
			const { data, error } = await db.from("price_lists").select("id,name,is_default,is_active").order("name");
			if (error) throw error;
			return data ?? [];
		}
	});
}
//#endregion
export { useIsOwner as a, usePriceLists as c, useIsAdmin as i, useShelves as l, loadMyAccess as n, useLocations as o, useCategories as r, usePaymentTerms as s, byId as t, useTaxRates as u };
