import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/register-B3Ymj1Mb.js
var $$splitComponentImporter = () => import("./register-Cd6aconW.mjs");
var Route = createFileRoute("/_authenticated/register")({
	validateSearch: (s) => typeof s["account"] === "string" ? { account: s["account"] } : {},
	head: () => ({ meta: [{ title: "Check Register · Tallkeep" }, {
		name: "description",
		content: "Every check, deposit and payment in a bank account, with the running balance."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
