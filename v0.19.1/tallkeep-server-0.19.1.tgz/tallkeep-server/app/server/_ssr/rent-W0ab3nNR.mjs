import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { R as Plus, fn as CalendarPlus, g as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-BSPpXJ2X.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as loadCharges, n as CHARGE_KIND, o as refreshRealEstate, s as useRealEstate } from "./realestate-DQ-XkZ06.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as MoneyAccountPick } from "./MoneyAccountPick-DbpNcfah.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/rent-W0ab3nNR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Rent() {
	const qc = useQueryClient();
	const { data: re } = useRealEstate();
	const [tab, setTab] = (0, import_react.useState)("owed");
	const [through, setThrough] = (0, import_react.useState)(today());
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [pay, setPay] = (0, import_react.useState)(null);
	const [addCharge, setAddCharge] = (0, import_react.useState)(false);
	const { data: charges, isLoading } = useQuery({
		queryKey: ["rent-charges", tab === "owed" ? "open" : "all"],
		queryFn: () => loadCharges(tab === "owed"),
		enabled: tab !== "payments"
	});
	const { data: payments } = useQuery({
		queryKey: ["rent-charges", "payments"],
		enabled: tab === "payments",
		queryFn: async () => {
			const { data, error } = await db.from("rent_payments").select("*, rent_charges(lease_id, kind, description)").order("paid_on", { ascending: false }).limit(1e3);
			if (error) throw error;
			return data ?? [];
		}
	});
	const who = (leaseId) => {
		const l = re?.lease.get(leaseId);
		if (!l) return {
			tenant: "",
			unit: ""
		};
		return {
			tenant: re.tenant.get(l.tenant_id)?.name ?? "",
			unit: re.unitLabel(l.unit_id)
		};
	};
	const totalOwed = (charges ?? []).reduce((s, c) => s + (c.status === "open" ? c.balance : 0), 0);
	async function charge() {
		setBusy(true);
		const { data, error } = await db.rpc("generate_rent", { _through: through });
		setBusy(false);
		if (error) return void toast.error(error.message);
		const r = data;
		toast.success(r.charged || r.late_fees ? `Charged ${r.charged} month${r.charged === 1 ? "" : "s"} of rent and ${r.late_fees} late fee${r.late_fees === 1 ? "" : "s"}.` : "Everything is already charged.");
		refreshRealEstate(qc);
	}
	async function voidCharge(c) {
		if (c.amount_paid > 0) return void toast.error("Remove its payments first.");
		if (!window.confirm(`Cancel this ${CHARGE_KIND[c.kind].toLowerCase()} of ${fmtMoney(c.amount)}?`)) return;
		const { error } = await db.from("rent_charges").update({ status: "void" }).eq("id", c.id);
		if (error) return void toast.error(error.message);
		toast.success("Charge cancelled.");
		refreshRealEstate(qc);
	}
	async function removePayment(p) {
		if (!window.confirm(`Remove this payment of ${fmtMoney(p.amount)}?`)) return;
		const { error } = await db.from("rent_payments").delete().eq("id", p.id);
		if (error) return void toast.error(error.message);
		toast.success("Payment removed.");
		refreshRealEstate(qc);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Rent",
			text: "Charge this month's rent for every lease with one button, then record what tenants pay. Late fees are added for rent still unpaid after the grace days.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => setAddCharge(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a charge"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setPay({
						lease_id: "",
						amount: 0
					}),
					children: "Record rent received"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3 rounded-2xl border bg-card p-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "Charge rent due up to"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: through,
						onChange: (e) => setThrough(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void charge(),
					disabled: busy,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarPlus, { className: "h-4 w-4" }),
						" ",
						busy ? "Charging…" : "Charge rent and late fees"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Safe to press again: a month is never charged twice."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: [
					["owed", "Owed"],
					["all", "All charges"],
					["payments", "Payments"]
				].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(k),
					className: `rounded-md px-3 py-1 ${tab === k ? "bg-[var(--section)] text-white" : ""}`,
					children: label
				}, k))
			}), tab === "owed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: ["Owed in total: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(totalOwed) })]
			})]
		}),
		tab !== "payments" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [
				isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
				charges && charges.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-8 text-center text-muted-foreground",
					children: tab === "owed" ? "Nobody owes anything." : "No charges yet."
				}),
				(charges ?? []).map((c) => {
					const w = who(c.lease_id);
					const late = c.status === "open" && c.due_date < today();
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-24 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: late ? "font-medium text-destructive" : "",
									children: fmtDate(c.due_date)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted-foreground",
									children: late ? "late" : "due"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: w.tenant
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										w.unit,
										" · ",
										c.description || CHARGE_KIND[c.kind]
									]
								})]
							}),
							c.status !== "open" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: c.status === "paid" ? "Paid" : "Cancelled"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-28 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-semibold",
									children: fmtMoney(c.status === "open" ? c.balance : c.amount)
								}), c.status === "open" && c.amount_paid > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: ["of ", fmtMoney(c.amount)]
								})]
							}),
							c.status === "open" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => setPay({
										lease_id: c.lease_id,
										amount: c.balance
									}),
									children: "Record payment"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void voidCharge(c),
									children: "Cancel charge"
								})]
							})
						]
					}, c.id);
				})
			]
		}),
		tab === "payments" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [(payments ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "No payments yet."
			}), (payments ?? []).map((p) => {
				const w = who(p.rent_charges.lease_id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-24 text-xs",
							children: fmtDate(p.paid_on)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: w.tenant
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									w.unit,
									" · ",
									p.rent_charges.description || CHARGE_KIND[p.rent_charges.kind],
									p.method ? ` · ${p.method}` : "",
									p.reference ? ` #${p.reference}` : ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-28 text-right font-semibold",
							children: fmtMoney(p.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							"aria-label": "Remove payment",
							onClick: () => void removePayment(p),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, p.id);
			})]
		}),
		pay && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentDialog, {
			start: pay,
			onClose: () => setPay(null)
		}),
		addCharge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChargeDialog, { onClose: () => setAddCharge(false) })
	] });
}
/** Money from a tenant: goes to their oldest charges first. */
function PaymentDialog({ start, onClose }) {
	const qc = useQueryClient();
	const { data: re } = useRealEstate();
	const [lease, setLease] = (0, import_react.useState)(start.lease_id);
	const [amount, setAmount] = (0, import_react.useState)(start.amount ? String(start.amount) : "");
	const [date, setDate] = (0, import_react.useState)(today());
	const [account, setAccount] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: open } = useQuery({
		queryKey: ["rent-charges", "open"],
		queryFn: () => loadCharges(true)
	});
	const mine = (0, import_react.useMemo)(() => (open ?? []).filter((c) => c.lease_id === lease).sort((a, b) => a.due_date.localeCompare(b.due_date)), [open, lease]);
	const owed = mine.reduce((s, c) => s + c.balance, 0);
	const options = (re?.leases ?? []).filter((l) => l.status === "active" || l.id === lease).map((l) => ({
		value: l.id,
		label: re.tenant.get(l.tenant_id)?.name ?? "",
		hint: re.unitLabel(l.unit_id)
	}));
	async function save() {
		let left = Math.round(Number(amount) * 100) / 100;
		if (!lease) return void toast.error("Pick the tenant.");
		if (!(left > 0)) return void toast.error("Type the amount received.");
		if (left > owed + .004) return void toast.error(`That's more than they owe (${fmtMoney(owed)}). Add a charge first, or record ${fmtMoney(owed)}.`);
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const rows = [];
			for (const c of mine) {
				if (left <= 0) break;
				const part = Math.min(left, c.balance);
				rows.push({
					charge_id: c.id,
					paid_on: date,
					amount: Math.round(part * 100) / 100,
					account_id: account || null,
					method: method.trim() || null,
					reference: ref.trim() || null,
					created_by: u.user?.id
				});
				left = Math.round((left - part) * 100) / 100;
			}
			const { error } = await db.from("rent_payments").insert(rows);
			if (error) throw error;
			toast.success("Payment recorded.");
			refreshRealEstate(qc);
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record rent received" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "It pays their oldest charges first." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tenant",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: lease,
							onChange: setLease,
							options,
							placeholder: "Pick the tenant"
						})
					}),
					lease && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground sm:col-span-2",
						children: [
							"They owe ",
							fmtMoney(owed),
							" on ",
							mine.length,
							" charge",
							mine.length === 1 ? "" : "s",
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Amount",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date received",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyAccountPick, {
						label: "Deposit to",
						value: account,
						onChange: setAccount
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "How (check, Zelle, cash…)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: method,
							onChange: (e) => setMethod(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Check or reference number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save payment"
			})] })
		] })
	});
}
/** A one-off charge: utilities, repairs the tenant pays for, pet fee… */
function ChargeDialog({ onClose }) {
	const qc = useQueryClient();
	const { data: re } = useRealEstate();
	const { data: accounts } = useAccounts();
	const [lease, setLease] = (0, import_react.useState)("");
	const [desc, setDesc] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today());
	const [account, setAccount] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const options = (re?.leases ?? []).filter((l) => l.status === "active").map((l) => ({
		value: l.id,
		label: re.tenant.get(l.tenant_id)?.name ?? "",
		hint: re.unitLabel(l.unit_id)
	}));
	const income = (accounts ?? []).filter((a) => a.is_active && a.type === "income").map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	async function save() {
		if (!lease) return void toast.error("Pick the tenant.");
		if (!desc.trim()) return void toast.error("Say what it's for.");
		if (!(Number(amount) > 0)) return void toast.error("Type the amount.");
		setBusy(true);
		const { error } = await db.from("rent_charges").insert({
			lease_id: lease,
			kind: "other",
			charge_date: date,
			due_date: date,
			description: desc.trim(),
			amount: Number(amount),
			account_id: account || null
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Charge added.");
		refreshRealEstate(qc);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add a charge" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Something extra a tenant owes, like utilities or a pet fee." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tenant",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: lease,
							onChange: setLease,
							options,
							placeholder: "Pick the tenant"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What for",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: desc,
							onChange: (e) => setDesc(e.target.value),
							placeholder: "Water bill March"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Amount",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							value: amount,
							onChange: (e) => setAmount(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Due",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Income account (empty = Rental Income)",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: account,
							onChange: setAccount,
							options: income,
							placeholder: "Rental Income"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Add charge"
			})] })
		] })
	});
}
//#endregion
export { Rent as component };
