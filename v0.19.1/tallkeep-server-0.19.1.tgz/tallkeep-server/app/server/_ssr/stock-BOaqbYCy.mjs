import { i as __toESM } from "../_runtime.mjs";
import { r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { $ as MoveRight, D as Search, n as X } from "../_libs/lucide-react.mjs";
import { o as useLocations, r as useCategories, t as byId } from "./queries-CStjB5rm.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { n as moveSpots } from "./stockmove-CB-XlxV_.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
import { t as PlacePicker } from "./StockDialogs-DWeNXSFk.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stock-BOaqbYCy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StockPage() {
	const { data: locations } = useLocations();
	const { data: cats } = useCategories();
	const catName = byId(cats);
	const navigate = useNavigate();
	const locName = byId(locations);
	const { data, isLoading } = useQuery({
		queryKey: ["stock"],
		queryFn: () => fetchAll("stock", "id,qty,shelf,location_id,products(id,name,cost,unit,description,category_id)")
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [loc, setLoc] = (0, import_react.useState)("all");
	const [shelfF, setShelfF] = (0, import_react.useState)("any");
	const [picked, setPicked] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [moving, setMoving] = (0, import_react.useState)(false);
	const pick = (id, on) => setPicked((p) => {
		const n = new Set(p);
		if (on) n.add(id);
		else n.delete(id);
		return n;
	});
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		return (data ?? []).filter((r) => Number(r.qty) !== 0 && r.products).filter((r) => loc === "all" || r.location_id === loc).filter((r) => shelfF === "any" || !r.shelf).filter((r) => {
			const hay = `${r.products.name} ${r.products.description ?? ""} ${r.shelf} ${locName.get(r.location_id) ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		}).sort((a, b) => (locName.get(a.location_id) ?? "").localeCompare(locName.get(b.location_id) ?? "") || a.shelf.localeCompare(b.shelf) || a.products.name.localeCompare(b.products.name));
	}, [
		data,
		q,
		loc,
		shelfF,
		locName
	]);
	const shown = rows.slice(0, 800);
	const allPicked = shown.length > 0 && shown.every((r) => picked.has(r.id));
	const units = rows.reduce((s, r) => s + Number(r.qty), 0);
	const value = rows.reduce((s, r) => s + Number(r.qty) * Number(r.products?.cost ?? 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Current Stock",
				text: "What you have and where it is."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Items shown",
						value: fmtQty(units)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Value at cost",
						value: fmtMoney(value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						label: "Spots with stock",
						value: String(rows.length)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search product, place or shelf",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: loc,
						onValueChange: setLoc,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "sm:w-56",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All places"
						}), (locations ?? []).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: l.id,
							children: l.name
						}, l.id))] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: shelfF,
						onValueChange: (v) => setShelfF(v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "sm:w-44",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "any",
							children: "Any shelf"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "none",
							children: "No shelf yet"
						})] })]
					})
				]
			}),
			picked.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-14 z-10 flex flex-wrap items-center gap-2 rounded-2xl border-2 border-[var(--section)] bg-card p-3 md:top-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-medium",
						children: [picked.size, " selected"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setMoving(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveRight, { className: "h-4 w-4" }), " Move selected to a shelf"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setPicked(/* @__PURE__ */ new Set()),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), " Clear selection"]
					})
				]
			}),
			moving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveDialog, {
				rows: (data ?? []).filter((r) => picked.has(r.id)),
				onClose: () => setMoving(false),
				onDone: () => {
					setMoving(false);
					setPicked(/* @__PURE__ */ new Set());
				}
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card md:hidden",
				children: rows.slice(0, 500).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1 pl-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: picked.has(r.id),
						onCheckedChange: (v) => pick(r.id, v === true),
						"aria-label": "Select",
						className: "h-5 w-5"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/products/$id",
						params: { id: r.products.id },
						className: "flex min-w-0 flex-1 items-center gap-3 px-3 py-3 hover:bg-muted/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-28 shrink-0 text-sm sm:w-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: locName.get(r.location_id)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: r.shelf || "No shelf"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "min-w-0 flex-1 truncate",
								children: r.products.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: Number(r.qty) < 0 ? "font-semibold text-destructive" : "font-semibold",
								children: fmtQty(r.qty)
							})
						]
					})]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-2xl border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "w-10 px-3 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: allPicked,
									"aria-label": "Select all shown",
									onCheckedChange: (v) => setPicked((p) => {
										const n = new Set(p);
										shown.forEach((r) => v === true ? n.add(r.id) : n.delete(r.id));
										return n;
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Description"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Category"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Location"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Shelf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Quantity"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "cursor-pointer hover:bg-muted/50",
							onClick: () => navigate({
								to: "/products/$id",
								params: { id: r.products.id }
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									onClick: (e) => e.stopPropagation(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: picked.has(r.id),
										onCheckedChange: (v) => pick(r.id, v === true),
										"aria-label": "Select"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[260px] truncate px-3 py-2 font-medium",
									style: { color: "var(--section)" },
									children: r.products.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[380px] truncate px-3 py-2 text-muted-foreground",
									children: r.products.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[160px] truncate px-3 py-2",
									children: r.products.category_id ? catName.get(r.products.category_id) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: locName.get(r.location_id)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.shelf
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `px-3 py-2 text-right font-semibold ${Number(r.qty) < 0 ? "text-destructive" : ""}`,
									children: fmtQty(r.qty)
								})
							]
						}, r.id))
					})]
				})
			}),
			rows.length > 500 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Showing the first 500. Search or pick a place to narrow it down."
			})
		]
	});
}
function Card({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl font-bold",
			children: value
		})]
	});
}
function MoveDialog({ rows, onClose, onDone }) {
	const qc = useQueryClient();
	const [loc, setLoc] = (0, import_react.useState)("");
	const [shelf, setShelf] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const total = rows.reduce((s, r) => s + Math.max(0, Number(r.qty)), 0);
	async function go() {
		if (!loc) {
			toast.error("Choose a place first.");
			return;
		}
		setBusy(true);
		try {
			const moves = await moveSpots(rows.filter((r) => r.products).map((r) => ({
				product_id: r.products.id,
				location_id: r.location_id,
				shelf: r.shelf,
				qty: Number(r.qty)
			})), loc, shelf);
			toast.success(`Moved ${moves.length} items.`);
			qc.invalidateQueries({ queryKey: ["stock"] });
			qc.invalidateQueries({ queryKey: ["products"] });
			qc.invalidateQueries({ queryKey: ["shelves"] });
			onDone();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
				"Move ",
				rows.length,
				" selected to a shelf"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"Everything in the selected spots (",
				fmtQty(total),
				" in all) moves to the place and shelf you choose."
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlacePicker, {
				label: "Move to",
				locationId: loc,
				shelf,
				onLocation: setLoc,
				onShelf: setShelf
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void go(),
				disabled: busy,
				children: busy ? "Moving…" : `Move ${rows.length} items`
			})] })
		] })
	});
}
//#endregion
export { StockPage as component };
