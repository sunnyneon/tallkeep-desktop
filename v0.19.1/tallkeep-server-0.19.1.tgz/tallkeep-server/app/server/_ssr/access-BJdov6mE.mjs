import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as featureOf, c as navItems, l as pathIn, o as groupForPath } from "./nav-CnPYkcwq.mjs";
import { n as loadMyAccess } from "./queries-CStjB5rm.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/access-BJdov6mE.js
/** Sections a user can be limited to. Home and Settings need full access. */
var ZONES = [
	"Sales",
	"Purchasing",
	"Inventory",
	"Properties",
	"Accounting",
	"Reports"
];
/** Can this user open pages in this menu group? zones null = everything. */
function canSeeGroup(a, g) {
	if (!a || a.isAdmin || a.zones == null) return true;
	if (g === "General" || g === "Options") return false;
	return a.zones.includes(g);
}
var canSeePath = (a, path) => canSeeGroup(a, groupForPath(path));
/** First menu page this user may open (where we send them instead). */
var firstAllowedUrl = (a) => navItems.find((i) => canSeeGroup(a, i.group))?.url ?? "/";
function useAccess(userId) {
	return useQuery({
		queryKey: ["my-access", userId],
		enabled: !!userId,
		staleTime: 3e5,
		retry: 30,
		retryDelay: 3e3,
		queryFn: async () => {
			const a = await loadMyAccess();
			return {
				isAdmin: a.admin,
				zones: a.zones,
				member: a.member
			};
		}
	});
}
/** Is this menu item's feature on for the company? (true while loading) */
var featureOn = (features, i) => {
	const f = featureOf(i);
	if (features && i.hideWith && features.includes(i.hideWith)) return false;
	return !features || !f || features.includes(f);
};
/** A page that belongs to a feature the company has turned off. */
var addonOffForPath = (addons, path) => {
	if (!addons) return false;
	const item = navItems.find((i) => i.url !== "/" && pathIn(path, i.url));
	if (item) return !featureOn(addons, {
		group: item.group,
		...item.addon ? { addon: item.addon } : {}
	});
	return !featureOn(addons, { group: groupForPath(path) });
};
//#endregion
export { featureOn as a, canSeePath as i, addonOffForPath as n, firstAllowedUrl as o, canSeeGroup as r, useAccess as s, ZONES as t };
