//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dwbdb2gR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CdeRkAjo.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BOnD92nf.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CPMf25U9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CdeRkAjo.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-yx2CG2yb.js",
			"/assets/log-out-BoNPATY-.js",
			"/assets/testers.functions-Dl82dOK-.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-pPcpZu3e.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DFK2xZoT.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CswWJ6Jc.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/label-BdCoFzUJ.js",
			"/assets/textarea-CYs4a5th.js",
			"/assets/dist-Bd020aod.js",
			"/assets/dialog-CCnUawDF.js",
			"/assets/shoebox-DFO0NHV1.js",
			"/assets/company-CJ01NU37.js",
			"/assets/reports-gi3P3Ahh.js",
			"/assets/access-CNVYN3jR.js",
			"/assets/UpdateBar-J0ELsqE4.js",
			"/assets/Logo-Bbc3U_oT.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Dhnl57xa.js",
			"/assets/log-out-BoNPATY-.js",
			"/assets/admin.functions-Cy28SjWw.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-Bbc3U_oT.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Cj6FbgFp.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/label-BdCoFzUJ.js",
			"/assets/Logo-Bbc3U_oT.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-jJJ2d9W0.js",
			"/assets/testers.functions-Dl82dOK-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/buy.functions-wk6bTHGI.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-EWa7rACv.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/downloads.functions-N35ehnKx.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-RQEb1UBO.js",
			"/assets/testers.functions-Dl82dOK-.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/textarea-CYs4a5th.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DGoNs6JV.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/label-BdCoFzUJ.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-Bs_5q44C.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/label-BdCoFzUJ.js",
			"/assets/Logo-Bbc3U_oT.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CwNjwDI2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/upgrade.functions-D4lA3MSw.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-KTUnjBBs.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/label-BdCoFzUJ.js",
			"/assets/Logo-Bbc3U_oT.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CyEvYav7.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-CrVt5aKA.js", "/assets/StockDocList-bQsZpcMe.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-OQjebJXN.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/ai.functions-BR2YNKuM.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-f9Y4B9vZ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BhPizBo_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/ai.functions-BR2YNKuM.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BUWJ2ovb.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-BMGbBOml.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-B8FbMtbS.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DkbPJ32Y.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-N5_QBKz6.js", "/assets/AccountRegister-B3ODA1Oe.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-10n72Qyc.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CksxbOS7.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CMiOTL4B.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-BR2YNKuM.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BMoxvjWb.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Da1bFeaS.js", "/assets/StockDocList-bQsZpcMe.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CaYb33ZU.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-aIUTSHA0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BbwacfAV.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-B5KxK4pZ.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-B94IkyLu.js", "/assets/PartyList-CcNTAftX.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BIed5-sv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-mgJP48Cc.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/storage.functions-DXobqBHk.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-B4dr9O-7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CE2qtn3t.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-w6j5YBiE.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CQ4HMGCE.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/members-BbwacfAV.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BlLN-KNp.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-B8FbMtbS.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CoDe084i.js", "/assets/SalesList-0F-D65SB.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-DgcL2ZrB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-DraM3-UM.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CM2jWSdY.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-QobREdpF.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Dco1ZRqw.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/switch-D3EPWq_u.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-fpBhbG1i.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-B8FbMtbS.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DsnJuBQ7.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DFgIq2z8.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-B8FbMtbS.js",
			"/assets/generateCategoricalChart-QNcnBRbp.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-9aFp5FBp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-QNcnBRbp.js",
			"/assets/BarChart-Cua8w-0S.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CapPVrZX.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-_d_dsICk.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DwCwN5MJ.js",
			"/assets/createServerFn-ekJFSD29.js",
			"/assets/auth-middleware-DzggCAhq.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/storage.functions-DXobqBHk.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DlUfpBxI.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DaEbE9Nz.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/badge-CxjaVe9O.js",
			"/assets/checkbox-y9UEwO_r.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-CbcSDkVi.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BsH8TU8B.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DDpfwehu.js", "/assets/SalesList-0F-D65SB.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-G3M2n0KA.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/ai.functions-BR2YNKuM.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DXobqBHk.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BGUyyDvx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-CxjaVe9O.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-C8o1gH-J.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-C2sJUsIi.js", "/assets/AccountRegister-B3ODA1Oe.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BgZ7Wv-W.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CxjaVe9O.js",
			"/assets/MoneyAccountPick--2mBXHxk.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-B84FI2Lz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CDCDFrOS.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-QNcnBRbp.js",
			"/assets/BarChart-Cua8w-0S.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CD9ThJv0.js", "/assets/SalesList-0F-D65SB.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-ikkoL1Ku.js", "/assets/SalesList-0F-D65SB.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-B0ySlK-p.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-D3z0HfVd.js",
			"/assets/createServerFn-ekJFSD29.js",
			"/assets/auth-middleware-DzggCAhq.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/dist-B37VG6n9.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/QuickBooksImport-B5KxK4pZ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-y9UEwO_r.js",
			"/assets/users.functions-WCzy6-ss.js",
			"/assets/FeaturePicker-C81ZtfAx.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DxHagDX2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/FeaturePicker-C81ZtfAx.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-C2BR-_Lv.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BWv84PV1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CUJVhPJD.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/loans-DhR1zMtS.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DXobqBHk.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-wYSqijrc.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/DocPdf-eOII2zXG.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-T24NsA88.js",
			"/assets/createServerFn-ekJFSD29.js",
			"/assets/auth-middleware-DzggCAhq.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-CxjaVe9O.js",
			"/assets/MoneyAccountPick--2mBXHxk.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-Hpwo4RJo.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/StockDialogs-BWv84PV1.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/checkbox-y9UEwO_r.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Bjyj61pZ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-B8FbMtbS.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CKXX0vtU.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/tickets.functions-CgF5O5tn.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-BHlNNiTX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-211S7vZe.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-B-l7iqdv.js", "/assets/StockDocList-bQsZpcMe.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-D5rJz9XU.js", "/assets/PartyList-CcNTAftX.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BFLHWP58.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/tickets.functions-CgF5O5tn.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CldILEmk.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/badge-CxjaVe9O.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CO6jUO9W.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DNBxH7Ss.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/AdminAccount-CmiaTW41.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CKdQ6j0x.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/downloads.functions-N35ehnKx.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-DDZJnuVX.js",
			"/assets/createServerFn-ekJFSD29.js",
			"/assets/auth-middleware-DzggCAhq.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-C0sYqPlv.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BhuOgCZh.js",
			"/assets/testers.functions-Dl82dOK-.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CU92kJh4.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-D0hzNdjP.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/buy.functions-wk6bTHGI.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-JtYB_Awf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/textarea-CYs4a5th.js",
			"/assets/support.functions-211S7vZe.js",
			"/assets/HelpParts-CjlYaB_j.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-D9l3JfO7.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BOhIQWov.js",
			"/assets/manual._slug-jHOZEQeX.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DEZUShzv.js",
			"/assets/createServerFn-ekJFSD29.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-C9xYcqBZ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/upgrade.functions-D4lA3MSw.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BhqbAoEY.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DQwqTdou.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/AdminAccount-CmiaTW41.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CNkaJYd6.js", "/assets/ManualFrame-BOhIQWov.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-BPBeDNml.js", "/assets/AccountRegister-B3ODA1Oe.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DGZqLHCE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/OriginalLink-D8j-tByt.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/realestate-hdRlfiWs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CtJQxFMK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BEfhqnXB.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-x5tJex6l.js",
			"/assets/PartyHistory-B01Lxymz.js",
			"/assets/tabs-zpAkYRkf.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-8cnYxhqx.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-x5tJex6l.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/MoneyAccountPick--2mBXHxk.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DzmQZuPT.js",
			"/assets/PrintFrame-DdqbEiyY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-lFUp5dpO.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-BWv84PV1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/switch-D3EPWq_u.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/badge-CxjaVe9O.js",
			"/assets/SideList-x5tJex6l.js",
			"/assets/tabs-zpAkYRkf.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/stockmove-qokIsYoe.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-gjLtDnMy.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-x5tJex6l.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/MoneyAccountPick--2mBXHxk.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-DzmQZuPT.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-y9UEwO_r.js",
			"/assets/workorders-B0SB58LO.js",
			"/assets/tickets.functions-CgF5O5tn.js",
			"/assets/users.functions-WCzy6-ss.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DawtgyUs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/select-5_3Fzazv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-Wn2gbqUm.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-x5tJex6l.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CPiAV6OX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/quickadd-CG8MsGOh.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-211S7vZe.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CxsBb2di.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CLBzsOof.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/SideList-x5tJex6l.js",
			"/assets/PartyHistory-B01Lxymz.js",
			"/assets/tabs-zpAkYRkf.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-B3T6UHka.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/tickets.functions-CgF5O5tn.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CYAppct5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/input-DRMd8cSL.js",
			"/assets/skeleton-PolLSP1h.js",
			"/assets/AdminAccount-CmiaTW41.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-ehdGsjh_.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-kM7hLuuj.js",
			"/assets/textarea-CYs4a5th.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-211S7vZe.js",
			"/assets/HelpParts-CjlYaB_j.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CcfgqOVP.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PolLSP1h.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
