import { r as fetchAll } from "./db-CSUHuVe9.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as inBooks, t as fetchBooksStart } from "./booksStart-C1IZWhsB.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/balances-B6cTYnQu.js
/**
* What we owe each vendor and what each customer owes us, the same way as What we owe / Who owes
* us and the Balance Sheet: bills (less vendor credits not used yet) plus received purchase orders
* still unpaid; invoices still unpaid.
*/
/** What a purchase order owes right now, the same as the Balance Sheet: all of what's left to pay
*  once it's fully received; for a part receipt, what came in less what's paid (NEW-01). Uses the
*  database's owed_now (step 083); without it, only fully received orders count. */
function poOwed(p) {
	if (p.status === "cancelled") return 0;
	if (p.owed_now != null) return Math.max(0, Number(p.owed_now));
	return p.stock_received_at || [
		"received",
		"paid",
		"completed"
	].includes(p.status) ? Math.max(0, Number(p.balance)) : 0;
}
/** Purchase orders with owed_now when the database has it. */
async function fetchPos(cols) {
	try {
		return await fetchAll("purchase_orders", `${cols},owed_now`);
	} catch {
		return await fetchAll("purchase_orders", cols);
	}
}
async function vendorBalances() {
	const [bills, pos] = await Promise.all([fetchAll("bills", "vendor_id,balance,status"), fetchPos("vendor_id,balance,status,stock_received_at")]);
	const out = /* @__PURE__ */ new Map();
	const at = (id) => {
		const r = out.get(id) ?? {
			bills: 0,
			pos: 0,
			credits: 0,
			total: 0
		};
		out.set(id, r);
		return r;
	};
	for (const b of bills) {
		if (!b.vendor_id || b.status !== "open" || Math.abs(Number(b.balance)) < .005) continue;
		const r = at(b.vendor_id);
		if (Number(b.balance) < 0) r.credits += Number(b.balance);
		else r.bills += Number(b.balance);
		r.total += Number(b.balance);
	}
	for (const p of pos) {
		const owed = poOwed(p);
		if (!p.vendor_id || owed <= .005) continue;
		const r = at(p.vendor_id);
		r.pos += owed;
		r.total += owed;
	}
	return out;
}
async function customerBalances() {
	const [rows, start] = await Promise.all([fetchAll("sales_orders", "customer_id,balance,status,number,invoice_date,order_date"), fetchBooksStart()]);
	const out = /* @__PURE__ */ new Map();
	for (const o of rows) {
		if (!o.customer_id || ![
			"invoiced",
			"paid",
			"completed"
		].includes(o.status)) continue;
		if (o.number.startsWith("RMA-") || Number(o.balance) <= .005) continue;
		if (!inBooks(o, start)) continue;
		const r = out.get(o.customer_id) ?? { total: 0 };
		r.total += Number(o.balance);
		out.set(o.customer_id, r);
	}
	return out;
}
function usePartyBalances(kind) {
	return useQuery({
		queryKey: ["party-balances", kind],
		queryFn: async () => kind === "vendors" ? new Map([...await vendorBalances()].map(([k, v]) => [k, v.total])) : new Map([...await customerBalances()].map(([k, v]) => [k, v.total]))
	});
}
//#endregion
export { vendorBalances as i, poOwed as n, usePartyBalances as r, fetchPos as t };
