//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-SMlp9DG_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/notice-emails",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-Dreq56_G.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DVrg5Z9Z.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CJ1gf3P0.js",
			"/assets/company-C9tLvC4X.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Dreq56_G.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route--TVsyOGV.js",
			"/assets/createServerFn-CXtitEJ_.js",
			"/assets/log-out-Bah1UAcs.js",
			"/assets/auth-middleware-BgXNfCG0.js",
			"/assets/testers.functions-DJ1EsLy8.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DdzfwygP.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-CnHnsYNI.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/accounting-Bb5ZViaF.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-BDEULeS7.js",
			"/assets/button-BnltDnVE.js",
			"/assets/dist-CbCsRYke.js",
			"/assets/dialog-CSL9U_xz.js",
			"/assets/queries-DLmE24IW.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/label-BcwTw59M.js",
			"/assets/textarea-BPlzkEg1.js",
			"/assets/shoebox-n9xRb6V8.js",
			"/assets/reports-pBT1FVX3.js",
			"/assets/access-BbB22uhi.js",
			"/assets/theme-ughCw8IT.js",
			"/assets/Logo-CkRL1NWm.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-B_scgsSn.js",
			"/assets/log-out-Bah1UAcs.js",
			"/assets/admin.functions-C5OsFZq4.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CkRL1NWm.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BGVDGR9F.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/label-BcwTw59M.js",
			"/assets/Logo-CkRL1NWm.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Q3McZpdx.js",
			"/assets/testers.functions-DJ1EsLy8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/coupons.functions-WemNgjcs.js",
			"/assets/buy.functions-D7LfiVRi.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-IN05rge5.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/downloads.functions-D18FAVBs.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BoNbgZh8.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/label-BcwTw59M.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DX8E6foB.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/label-BcwTw59M.js",
			"/assets/Logo-CkRL1NWm.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-DP7PaSfQ.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/upgrade.functions-Iw8brJo4.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CFMhIdAA.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/label-BcwTw59M.js",
			"/assets/Logo-CkRL1NWm.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-if0f5wEU.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DCtsuby6.js", "/assets/StockDocList-CE-HrM3Q.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-5uaTmf76.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/ai-CjcJj8_k.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-C0814eCa.js",
			"/assets/BankConnections-CYdrSr7K.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BcRjddTi.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-CUT1-cy7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-CYdrSr7K.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/ai-CjcJj8_k.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/loans-Bi-6C1Ih.js",
			"/assets/TxnEditor-BkETAPs1.js",
			"/assets/feedWaiting-DDDPg4wm.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-t9BhcVMu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-gstkXeMQ.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DQy2qW_O.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/personal-0BmGD6vZ.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/WhoPicker-DZIqAuPx.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BZTV1zZo.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BoAnIhRi.js", "/assets/AccountRegister-ZRJkAhyV.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Cp0p_4V1.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-HmoqGQjf.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/money-9hyISjC2.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DESq5ciT.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CjcJj8_k.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-Dbpy0HEE.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-D1OYUXLJ.js", "/assets/StockDocList-CE-HrM3Q.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DIhfRDxu.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-JS9eU88a.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/QuickBooksImport-CYf1oTUj.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BfiV5vqf.js", "/assets/PartyList-Cj5oM_Rx.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-cemBJwNY.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-BGGQ5vls.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/storage.functions-HG6fofHc.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BazS6clC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-Cvtq392j.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/booksStart-B1HvntxL.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-_b9oLokD.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Bu3ItOYF.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BNFzct5g.js", "/assets/ChangeHistory-D2_nGXTw.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-N4Xs-sF2.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/members-_LMRwGfE.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-C5f_zcLK.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/personal-0BmGD6vZ.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/WhoPicker-DZIqAuPx.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-D7mxj1Ri.js", "/assets/SalesList-Fr9xE5VW.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-zgc4Xk0E.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-D9vmg8Xa.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CHNKTJ0F.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BmBt2F5o.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/loans-Bi-6C1Ih.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-jKrdHKkW.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-sCGHx-Lv.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BHvM8eP2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/personal-0BmGD6vZ.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/WhoPicker-DZIqAuPx.js",
			"/assets/reminders-CgLGPRrG.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-mRimJoTl.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-B87pqZX3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/personal-0BmGD6vZ.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/WhoPicker-DZIqAuPx.js",
			"/assets/generateCategoricalChart-155wtwZx.js",
			"/assets/Area-CPgrnTlJ.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-bDU4pXaJ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/generateCategoricalChart-155wtwZx.js",
			"/assets/PlCharts-_b9oLokD.js",
			"/assets/BarChart-DDRvcYeR.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-iAGRyjek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/balances-gstkXeMQ.js",
			"/assets/money-9hyISjC2.js",
			"/assets/DecimalInput-DFL9Q2T3.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DZ4yroJm.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CZVm3g6U.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/storage.functions-HG6fofHc.js",
			"/assets/coupons.functions-WemNgjcs.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-kn8sM7s7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-CmG0NTvm.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/DecimalInput-DFL9Q2T3.js",
			"/assets/StockDialogs-C26wv83C.js",
			"/assets/checkbox-3WGH8k4E.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DEq0sJHD.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CNnzBQ4S.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-B9KkwS6a.js", "/assets/SalesList-Fr9xE5VW.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BakbaC6v.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/ai-CjcJj8_k.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-HG6fofHc.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-b5sa4cbK.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/money-9hyISjC2.js",
			"/assets/badge-BQCVsw9w.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Dzy9JBts.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CQUnqi3-.js", "/assets/AccountRegister-ZRJkAhyV.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Dw0texP5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/MoneyAccountPick-BysFwkwT.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-Oe59DrQ5.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-CraBvnx0.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/RepeatInvoice-YI-VFki0.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-rgzU9K9T.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-155wtwZx.js",
			"/assets/BarChart-DDRvcYeR.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-D6xesUz_.js", "/assets/SalesList-Fr9xE5VW.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-BFoEta9h.js", "/assets/SalesList-Fr9xE5VW.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BsRQAvlh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-asNDnSO8.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/serials-D0Mdexe1.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-D2Me71VL.js",
			"/assets/AppsCatalog-8FzA0-8c.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BUf9tOKU.js",
			"/assets/switch-sCGHx-Lv.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/QuickBooksImport-CYf1oTUj.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DFcteQh-.js",
			"/assets/footers-BYHwS_sC.js",
			"/assets/PrintFrame-B6VPuJPr.js",
			"/assets/checkbox-3WGH8k4E.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B7y2Ux15.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company--Q_uFHvT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-8FzA0-8c.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-CYdrSr7K.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-B1CsaqP5.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/StockDialogs-C26wv83C.js",
			"/assets/photos-DFcteQh-.js",
			"/assets/stockmove-D2JkLa8T.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-pxHTfIqN.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/loans-Bi-6C1Ih.js",
			"/assets/feedWaiting-DDDPg4wm.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-HG6fofHc.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-aDyYGoVb.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/PrintFrame-B6VPuJPr.js",
			"/assets/DocPdf-CiVIuZIo.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-B327DaOl.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/MoneyAccountPick-BysFwkwT.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B7y2Ux15.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-D9r7hSs5.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/StockDialogs-C26wv83C.js",
			"/assets/stockmove-D2JkLa8T.js",
			"/assets/checkbox-3WGH8k4E.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-mjpVUhBi.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/members-_LMRwGfE.js",
			"/assets/WhoPicker-DZIqAuPx.js",
			"/assets/reminders-CgLGPRrG.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CfU1sTkA.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/tickets.functions-CmC55_Zq.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DxtX6BdD.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B7y2Ux15.js",
			"/assets/support.functions-CSIDd64z.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-NDbyO-0j.js", "/assets/StockDocList-CE-HrM3Q.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-Bz4d-kJX.js", "/assets/PartyList-Cj5oM_Rx.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-DGSVPvrH.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/tickets.functions-CmC55_Zq.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-PY2tSlaM.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/workorders-i9eyG95P.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-ByaRiOgt.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-BHPuuYNL.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/coupons.functions-WemNgjcs.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-jpGgDB-L.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/AdminAccount-Ieggdf0a.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-DI6qmeGz.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/downloads.functions-D18FAVBs.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BnSZseng.js",
			"/assets/createServerFn-CXtitEJ_.js",
			"/assets/auth-middleware-BgXNfCG0.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CKRiAn6D.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-xCKCy6Cb.js",
			"/assets/testers.functions-DJ1EsLy8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-qfnKgrsz.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-CD2OclHL.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BnltDnVE.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-D7LfiVRi.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-BycMn_aG.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/textarea-BPlzkEg1.js",
			"/assets/support.functions-CSIDd64z.js",
			"/assets/HelpParts-xfmru1hv.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BXbEgo2p.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-B7y7NQ56.js",
			"/assets/manual._slug-fUfCOqpg.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CSZqndie.js",
			"/assets/createServerFn-CXtitEJ_.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-2hmM6wM5.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BnltDnVE.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-Iw8brJo4.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-C5lPQhdk.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CjcJj8_k.js",
			"/assets/personal-0BmGD6vZ.js",
			"/assets/reminders-CgLGPRrG.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BAMeXB0t.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/AdminAccount-Ieggdf0a.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CYBMwGU5.js", "/assets/ManualFrame-B7y7NQ56.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-xeeKR6TM.js", "/assets/AccountRegister-ZRJkAhyV.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-LtF8rsXc.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/OriginalLink-9ahfMLHB.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/realestate-DhCO-BHm.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Cbs93r-S.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/realestate-DhCO-BHm.js",
			"/assets/money-9hyISjC2.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CvWFsj9w.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-B1HvntxL.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/SideList-BX15UZTX.js",
			"/assets/PartyHistory-BjZ7GoS7.js",
			"/assets/tabs-CJbIbIbH.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-B5r8sUUh.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/ChangeHistory-D2_nGXTw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/SideList-BX15UZTX.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-DFL9Q2T3.js",
			"/assets/StockDialogs-C26wv83C.js",
			"/assets/NewProductDialog-DV2SCyoc.js",
			"/assets/MoneyAccountPick-BysFwkwT.js",
			"/assets/footers-BYHwS_sC.js",
			"/assets/PrintFrame-B6VPuJPr.js",
			"/assets/serials-D0Mdexe1.js",
			"/assets/SerialsBox-5xGwWUMm.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Bsgz1LdG.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-D2_nGXTw.js",
			"/assets/switch-sCGHx-Lv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BQCVsw9w.js",
			"/assets/SideList-BX15UZTX.js",
			"/assets/tabs-CJbIbIbH.js",
			"/assets/StockDialogs-C26wv83C.js",
			"/assets/photos-DFcteQh-.js",
			"/assets/stockmove-D2JkLa8T.js",
			"/assets/serials-D0Mdexe1.js",
			"/assets/SerialsBox-5xGwWUMm.js",
			"/assets/workorders-i9eyG95P.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-B-JWrYns.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/ChangeHistory-D2_nGXTw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/booksStart-B1HvntxL.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/SideList-BX15UZTX.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-DFL9Q2T3.js",
			"/assets/NewProductDialog-DV2SCyoc.js",
			"/assets/MoneyAccountPick-BysFwkwT.js",
			"/assets/footers-BYHwS_sC.js",
			"/assets/PrintFrame-B6VPuJPr.js",
			"/assets/cardpay-Ded8bDrM.js",
			"/assets/checkbox-3WGH8k4E.js",
			"/assets/serials-D0Mdexe1.js",
			"/assets/workorders-i9eyG95P.js",
			"/assets/RepeatInvoice-YI-VFki0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-CmC55_Zq.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CDnEl7Sw.js",
			"/assets/select-BTPU6lh_.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/SideList-BX15UZTX.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-hTR63JRo.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/quickadd-LL5pIANW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B7y2Ux15.js",
			"/assets/support.functions-CSIDd64z.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DTWpTFlo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DXuyi4Nw.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/SideList-BX15UZTX.js",
			"/assets/PartyHistory-BjZ7GoS7.js",
			"/assets/tabs-CJbIbIbH.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-Bafj4co0.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/sales-Dbpy0HEE.js",
			"/assets/footers-BYHwS_sC.js",
			"/assets/tickets.functions-CmC55_Zq.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CTySBs4-.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/input-BKPYWLkv.js",
			"/assets/skeleton-PD5z1eCu.js",
			"/assets/AdminAccount-Ieggdf0a.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CVXs25B1.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-BnltDnVE.js",
			"/assets/textarea-BPlzkEg1.js",
			"/assets/support-B7y2Ux15.js",
			"/assets/support.functions-CSIDd64z.js",
			"/assets/HelpParts-xfmru1hv.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-D2tW868C.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PD5z1eCu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
