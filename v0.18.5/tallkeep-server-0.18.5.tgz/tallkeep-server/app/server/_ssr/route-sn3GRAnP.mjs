import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-C9I0PyVu.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link, g as Outlet, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { En as BadgeDollarSign, Ht as Download, Nt as FlaskConical, Yt as ClipboardList, _t as KeyRound, c as Users, ht as LayoutDashboard, ot as LogOut } from "../_libs/lucide-react.mjs";
import { amIOwner } from "./admin.functions-BzYNQ-Or.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
import { t as Route } from "./route-DItbaYfE.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/route-sn3GRAnP.js
var import_jsx_runtime = require_jsx_runtime();
/** Tallkeep's own admin panel (admin.tallkeep.com). Separate from any company's books. */
var MENU = [
	{
		title: "Overview",
		url: "/admin",
		icon: LayoutDashboard
	},
	{
		title: "Customers",
		url: "/admin/customers",
		icon: Users
	},
	{
		title: "Waitlist",
		url: "/admin/waitlist",
		icon: ClipboardList
	},
	{
		title: "Downloads",
		url: "/admin/downloads",
		icon: Download
	},
	{
		title: "Prices",
		url: "/admin/prices",
		icon: BadgeDollarSign
	},
	{
		title: "Desktop licenses",
		url: "/admin/licenses",
		icon: KeyRound
	},
	{
		title: "Early access & problems",
		url: "/admin/testers",
		icon: FlaskConical
	}
];
function AdminLayout() {
	const { user } = Route.useRouteContext();
	const owner = useQuery({
		queryKey: ["am-i-owner"],
		queryFn: () => amIOwner()
	});
	const path = useRouterState({ select: (s) => s.location.pathname });
	const on = (url) => url === "/admin" ? path === "/admin" || path === "/admin/" : path.startsWith(url);
	const signOut = async () => {
		await supabase.auth.signOut();
		window.location.href = "/auth";
	};
	let body = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	if (owner.isLoading) body = null;
	else if (!owner.data) body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-16 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-bold",
				children: "This page is for Tallkeep owners"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted-foreground",
				children: [
					"You're signed in as ",
					user.email,
					", which doesn't have access to the admin panel."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "mt-4 inline-block font-semibold text-primary underline",
				children: "Open my books instead"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden w-60 shrink-0 flex-col bg-[#0F2A44] p-4 text-white md:flex",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-xs font-semibold uppercase tracking-wider text-white/60",
					children: "Admin panel"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-6 space-y-1",
					children: MENU.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: m.url,
						className: cn("flex items-center gap-3 rounded-lg px-3 py-2 text-sm", on(m.url) ? "bg-white/15 font-semibold" : "text-white/80 hover:bg-white/10"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.icon, { className: "h-4 w-4" }), m.title]
					}, m.url))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto space-y-2 text-xs text-white/70",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate",
						children: user.email
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: signOut,
						className: "flex items-center gap-2 hover:text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" }), " Sign out"]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-1 overflow-x-auto border-b bg-[#0F2A44] p-2 md:hidden",
				children: MENU.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: m.url,
					className: cn("whitespace-nowrap rounded-lg px-3 py-1.5 text-sm text-white", on(m.url) ? "bg-white/15 font-semibold" : "text-white/80"),
					children: m.title
				}, m.url))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: body })]
		})]
	});
}
//#endregion
export { AdminLayout as component };
