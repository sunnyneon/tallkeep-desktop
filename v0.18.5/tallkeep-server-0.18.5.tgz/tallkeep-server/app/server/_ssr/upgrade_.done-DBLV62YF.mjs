import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Kt as Copy, Qt as CircleCheck, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as BuyFrame } from "./buy-VCYMTf5j.mjs";
import { t as Route } from "./upgrade_.done-DenO_85Z.mjs";
import { getUpgradeOrder } from "./upgrade.functions-D8MS8wJ8.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade_.done-DBLV62YF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** After paying for a renewal or upgrade: the new key. */
function DonePage() {
	const { session } = Route.useSearch();
	const [tries, setTries] = (0, import_react.useState)(0);
	const { data, error } = useQuery({
		queryKey: ["upgrade-order", session],
		queryFn: async () => {
			const r = await getUpgradeOrder({ data: { session } });
			setTries((t) => t + 1);
			return r;
		},
		refetchInterval: (q) => q.state.data?.status === "paid" || tries > 20 ? false : 3e3
	});
	const n = (v, one, many) => v == null ? `any number of ${many}` : `${v} ${v === 1 ? one : many}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
		children: data?.status === "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Your license is updated"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"License ",
					data.id,
					" now covers ",
					n(data.companies, "company", "companies"),
					" and",
					" ",
					n(data.users, "person", "people"),
					data.updatesUntil ? `, with updates until ${(/* @__PURE__ */ new Date(`${data.updatesUntil}T12:00:00`)).toLocaleDateString(void 0, {
						month: "short",
						day: "numeric",
						year: "numeric"
					})}` : "",
					".",
					data.mailed && data.email ? ` We emailed the new key to ${data.email}.` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-muted/40 p-3 text-sm",
				children: [
					"Your office computer picks up the new key by itself within a day. To use it now: in Tallkeep open ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Settings → Plan & computer" }),
					" and press",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Check for my updated key" }),
					"."
				]
			}),
			data.showKey && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer",
						children: "Show the new key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 break-all rounded-xl border bg-muted/40 p-3 font-mono text-xs",
						children: data.key
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						className: "mt-2",
						variant: "outline",
						size: "sm",
						onClick: () => {
							navigator.clipboard.writeText(data.key);
							toast.success("Key copied");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy the key"]
					})
				]
			})
		] }) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm",
			children: [
				"Something went wrong: ",
				error.message,
				". Your payment is safe. Email hello@tallkeep.com and we'll finish it."
			]
		}) : data?.status === "unpaid" && tries > 20 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm",
			children: "We haven't heard from Stripe that the payment went through yet. If you paid, your new key will arrive by email in a few minutes."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Confirming your payment…"]
		})
	}) });
}
//#endregion
export { DonePage as component };
