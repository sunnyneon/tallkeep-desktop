import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { kn as ArrowLeft } from "../_libs/lucide-react.mjs";
import { r as articleBySlug, t as ARTICLES } from "./manual-C1hviOEM.mjs";
import { t as Route } from "./manual._slug-DKRlK4AS.mjs";
import { t as ManualText } from "./ManualText-DsNAkNOQ.mjs";
import { t as ManualFrame } from "./ManualFrame-fKzJX247.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/manual._slug-Ca5iyv9a.js
var import_jsx_runtime = require_jsx_runtime();
/** One manual article, open to everyone. */
function ArticlePage() {
	const { slug } = Route.useParams();
	const navigate = useNavigate();
	const a = articleBySlug(slug);
	const inSection = ARTICLES.filter((x) => x.section === a.section);
	const i = inSection.findIndex((x) => x.slug === a.slug);
	const prev = inSection[i - 1];
	const next = inSection[i + 1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualFrame, {
		current: a.slug,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "max-w-3xl space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/manual",
					className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " All topics"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
						children: a.section
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-bold",
						children: a.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted-foreground",
						children: a.summary
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManualText, {
					body: a.body,
					onOpen: (s) => void navigate({
						to: "/manual/$slug",
						params: { slug: s }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-between gap-3 border-t pt-4 text-sm print:hidden",
					children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/manual/$slug",
						params: { slug: prev.slug },
						className: "text-primary hover:underline",
						children: ["← ", prev.title]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/manual/$slug",
						params: { slug: next.slug },
						className: "text-primary hover:underline",
						children: [next.title, " →"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Still stuck?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "mailto:hello@tallkeep.com?subject=Tallkeep%20help",
							className: "text-primary underline",
							children: "Email us"
						}),
						" ",
						"and we'll help."
					]
				})
			]
		})
	});
}
//#endregion
export { ArticlePage as component };
