import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { cn as Camera, d as Upload, g as Trash2, in as Check } from "../_libs/lucide-react.mjs";
import { n as fileToPages } from "./ai-DoFpV1D-.mjs";
import { t as aiRead } from "./ai.functions-DXGxYyOi.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as SearchSelect } from "./SearchSelect-KZGKVtkS.mjs";
import { n as takeScans } from "./scanQueue-C9-xAAQ0.mjs";
import { d as payStatus } from "./sales-CAB3s83f.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/checks-received-D5mPD2Ub.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
var clean = (s) => s.toLowerCase().replace(/\b(inc|llc|ltd|co|corp|corporation|company)\b\.?/g, "").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
/** The customer whose name best matches the name printed on the check. */
function matchCustomer(payer, customers) {
	const p = clean(payer);
	if (!p) return "";
	const exact = customers.find((c) => clean(c.name) === p);
	if (exact) return exact.id;
	const inside = customers.find((c) => {
		const n = clean(c.name);
		return n.length > 2 && (p.includes(n) || n.includes(p));
	});
	if (inside) return inside.id;
	const words = new Set(p.split(" ").filter((w) => w.length > 2));
	let best = {
		id: "",
		score: 0
	};
	for (const c of customers) {
		const hit = clean(c.name).split(" ").filter((w) => words.has(w));
		const score = hit.length + (hit.some((w) => w.length > 5) ? .5 : 0);
		if (score > best.score) best = {
			id: c.id,
			score
		};
	}
	return best.score >= 1.5 ? best.id : "";
}
/** Spread the check over open invoices: an invoice named in the memo or owing exactly the
* amount first, then oldest first. */
function spread(amount, memo, invoices) {
	const out = {};
	if (!(amount > 0)) return out;
	const m = memo.toLowerCase();
	const named = invoices.find((i) => m && m.includes(i.number.toLowerCase()));
	const exact = invoices.find((i) => Math.abs(Number(i.balance) - amount) < .005);
	const order = [
		...named ? [named] : [],
		...exact && exact !== named ? [exact] : [],
		...[...invoices].filter((i) => i !== named && i !== exact).sort((a, b) => a.order_date.localeCompare(b.order_date))
	];
	let left = amount;
	for (const i of order) {
		if (left <= .005) break;
		const take = Math.min(left, Number(i.balance));
		if (take > 0) {
			out[i.id] = take.toFixed(2);
			left -= take;
		}
	}
	return out;
}
function ChecksReceived() {
	const qc = useQueryClient();
	const [scans, setScans] = (0, import_react.useState)([]);
	const { data: customers } = useQuery({
		queryKey: ["customers-lite"],
		queryFn: async () => (await fetchAll("customers", "id,name")).sort((a, b) => a.name.localeCompare(b.name))
	});
	const { data: invoices } = useQuery({
		queryKey: ["open-invoices-by-customer"],
		queryFn: async () => {
			const rows = await fetchAll("sales_orders", "id,number,order_date,status,total,amount_paid,balance,customer_id");
			const by = /* @__PURE__ */ new Map();
			for (const r of rows) {
				const ps = payStatus(r);
				if (ps !== "Unpaid" && ps !== "Partial") continue;
				by.set(r.customer_id, [...by.get(r.customer_id) ?? [], r]);
			}
			return by;
		}
	});
	const customerOpts = (0, import_react.useMemo)(() => (customers ?? []).map((c) => ({
		value: c.id,
		label: c.name
	})), [customers]);
	const openFor = (id) => invoices?.get(id) ?? [];
	const patch = (key, p) => setScans((list) => list.map((s) => s.key === key ? {
		...s,
		...p
	} : s));
	async function addFiles(files) {
		for (const f of files) {
			const key = crypto.randomUUID();
			const scan = {
				key,
				preview: f.type.startsWith("image/") ? URL.createObjectURL(f) : "",
				state: "reading",
				payer: "",
				amount: "",
				date: today(),
				checkNo: "",
				memo: "",
				customerId: "",
				apply: {}
			};
			setScans((list) => [scan, ...list]);
			try {
				const pages = await fileToPages(f, 1);
				const r = JSON.parse(await aiRead({ data: {
					feature: "check",
					images: pages
				} }));
				const payer = String(r["payer"] ?? "");
				const amount = r["amount"] == null ? 0 : Math.abs(Number(r["amount"]));
				const memo = String(r["memo"] ?? "");
				const customerId = matchCustomer(payer, customers ?? []);
				patch(key, {
					state: "ready",
					payer,
					amount: amount ? amount.toFixed(2) : "",
					date: /^\d{4}-\d{2}-\d{2}$/.test(String(r["date"] ?? "")) ? String(r["date"]) : today(),
					checkNo: String(r["check_number"] ?? ""),
					memo,
					customerId,
					apply: customerId ? spread(amount, memo, openFor(customerId)) : {}
				});
			} catch (e) {
				patch(key, {
					state: "failed",
					error: e.message
				});
			}
		}
	}
	async function record(s) {
		const rows = Object.entries(s.apply).map(([id, v]) => ({
			id,
			amount: Number(v)
		})).filter((r) => r.amount > 0);
		if (!s.customerId) return void toast.error("Pick the customer who sent this check.");
		if (!rows.length) return void toast.error("Put an amount on at least one invoice.");
		const { data: u } = await db.auth.getUser();
		const { error } = await db.from("payments").insert(rows.map((r) => ({
			sales_order_id: r.id,
			amount: r.amount,
			paid_on: (/* @__PURE__ */ new Date(s.date + "T12:00:00")).toISOString(),
			method: "Check",
			reference: s.checkNo || null,
			created_by: u.user?.id
		})));
		if (error) return void toast.error(error.message);
		toast.success(`Payment of ${fmtMoney(rows.reduce((t, r) => t + r.amount, 0))} recorded.`);
		patch(s.key, { state: "saved" });
		qc.invalidateQueries({ queryKey: ["open-invoices-by-customer"] });
		qc.invalidateQueries({ queryKey: ["sales"] });
	}
	const took = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (took.current || !customers || !invoices) return;
		took.current = true;
		const files = takeScans("check");
		if (files.length) addFiles(files);
	}, [customers, invoices]);
	const pick = (list) => {
		const files = [...list ?? []];
		if (files.length) addFiles(files);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Checks Received",
			text: "Take a photo of each check from a customer. AI reads who paid and how much and puts it on their invoices. Recorded checks wait in Make Deposits until you take them to the bank.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-medium text-primary-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
					" Take a photo of a check",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						capture: "environment",
						multiple: true,
						className: "hidden",
						onChange: (e) => pick(e.target.files)
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-2 text-sm font-medium",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
					" Choose check photos",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*,.pdf,application/pdf",
						multiple: true,
						className: "hidden",
						onChange: (e) => pick(e.target.files)
					})
				]
			})] })
		}),
		scans.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-muted-foreground",
			children: "No checks scanned yet. Lay the check flat in good light, front side up, and take a photo."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: scans.map((s) => {
				const open = openFor(s.customerId);
				const applied = Object.values(s.apply).reduce((t, v) => t + (Number(v) || 0), 0);
				const amount = Number(s.amount) || 0;
				const diff = amount - applied;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 md:flex-row",
						children: [s.preview && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: s.preview,
							alt: "Check",
							className: "h-32 w-full rounded-lg border object-contain md:w-64"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 space-y-3",
							children: [
								s.state === "reading" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm",
									children: "AI is reading the check…"
								}),
								s.state === "failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-red-700",
									children: ["Couldn't read it: ", s.error]
								}),
								s.state === "saved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-sm font-medium text-emerald-700",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }),
										" Recorded: ",
										fmtMoney(amount),
										" from ",
										s.payer,
										".",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/deposits",
											className: "text-primary underline",
											children: "Make the deposit"
										})
									]
								}),
								(s.state === "ready" || s.state === "failed") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-3 sm:grid-cols-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "space-y-1 text-sm sm:col-span-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: "Customer"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
													value: s.customerId,
													options: customerOpts,
													placeholder: s.payer ? `Check from "${s.payer}": pick the customer` : "Pick the customer",
													onChange: (id) => patch(s.key, {
														customerId: id,
														apply: spread(amount, s.memo, openFor(id))
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "space-y-1 text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: "Amount ($)"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													inputMode: "decimal",
													value: s.amount,
													onChange: (e) => patch(s.key, {
														amount: e.target.value,
														apply: spread(Number(e.target.value), s.memo, open)
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "space-y-1 text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: "Check date"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													type: "date",
													value: s.date,
													onChange: (e) => patch(s.key, { date: e.target.value })
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "space-y-1 text-sm",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: "Check #"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: s.checkNo,
													onChange: (e) => patch(s.key, { checkNo: e.target.value })
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "space-y-1 text-sm sm:col-span-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium",
													children: "Memo on the check"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: s.memo,
													onChange: (e) => patch(s.key, { memo: e.target.value })
												})]
											})
										]
									}),
									s.customerId && open.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-amber-800",
										children: "This customer has no open invoices. Make the invoice first, then record this check on it."
									}),
									open.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl border",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "border-b px-3 py-2 text-xs font-medium text-muted-foreground",
											children: "Put it on these invoices"
										}), open.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3 border-b px-3 py-2 text-sm last:border-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "min-w-0 truncate",
												children: [
													i.number,
													" · ",
													fmtDate(i.order_date),
													" · owes ",
													fmtMoney(i.balance)
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												inputMode: "decimal",
												className: "w-28 text-right",
												value: s.apply[i.id] ?? "",
												placeholder: "0.00",
												onChange: (e) => patch(s.key, { apply: {
													...s.apply,
													[i.id]: e.target.value
												} })
											})]
										}, i.id))]
									}),
									open.length > 0 && Math.abs(diff) > .005 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-amber-800",
										children: diff > 0 ? `${fmtMoney(diff)} of the check isn't on an invoice yet. Only what's on invoices is recorded.` : `The invoices add up to ${fmtMoney(-diff)} more than the check.`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: () => record(s),
											disabled: applied <= 0,
											children: [
												"Record ",
												fmtMoney(applied),
												" as paid"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											variant: "ghost",
											onClick: () => setScans((l) => l.filter((x) => x.key !== s.key)),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Remove this check"]
										})]
									})
								] })
							]
						})]
					})
				}, s.key);
			})
		})
	] });
}
//#endregion
export { ChecksReceived as component };
