import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/financials-Bsmp3sXb.js
var TABS = [
	{
		k: "pl",
		label: "Profit & Loss"
	},
	{
		k: "pm",
		label: "P&L by month / vs last year"
	},
	{
		k: "bs",
		label: "Balance Sheet"
	},
	{
		k: "tb",
		label: "Trial Balance"
	},
	{
		k: "gl",
		label: "General Ledger"
	},
	{
		k: "ar",
		label: "Who owes us"
	},
	{
		k: "ap",
		label: "What we owe"
	},
	{
		k: "tax",
		label: "Sales tax"
	},
	{
		k: "v1099",
		label: "1099 vendors"
	},
	{
		k: "sbc",
		label: "Sales by customer"
	},
	{
		k: "ebv",
		label: "Expenses by vendor"
	}
];
var $$splitComponentImporter = () => import("./financials-BgYhjo7e.mjs");
var Route = createFileRoute("/_authenticated/financials")({
	validateSearch: (s) => {
		const out = {};
		if (TABS.some((t) => t.k === s["tab"])) out.tab = s["tab"];
		if (typeof s["from"] === "string") out.from = s["from"];
		if (typeof s["to"] === "string") out.to = s["to"];
		return out;
	},
	head: () => ({ meta: [{ title: "Financial Reports · Tallkeep" }, {
		name: "description",
		content: "Profit & Loss, Balance Sheet, Trial Balance, General Ledger and more."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { TABS as n, Route as t };
