import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { a as FEATURE_KEYS, c as useLicensed, i as FEATURES, n as BUSINESS_TYPES, r as BUSINESS_TYPE_KEYS } from "./addons-8tQCpcOj.mjs";
import { r as EDITIONS, t as ADDONS_FOR_SALE, u as whoSells } from "./editions-Fg8o4E4M.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/FeaturePicker-ByGDULWW.js
var import_jsx_runtime = require_jsx_runtime();
/** Where to buy what the license doesn't have (the office computer opens it in the browser). */
var BUY_URL = "https://app.tallkeep.com/buy?upgrade=1";
/** Pick the kind of business (which suggests features), then turn features on or off. */
function FeaturePicker({ type, features, onType, onToggle, disabled }) {
	const { data: licensed } = useLicensed();
	const group = (main) => FEATURE_KEYS.filter((k) => FEATURES[k].main === main);
	const box = (k) => {
		const locked = !!licensed && !licensed.includes(k);
		const w = locked ? whoSells(k) : null;
		const need = w?.addon ? `the ${ADDONS_FOR_SALE[w.addon].label} add-on` : w?.edition ? EDITIONS[w.edition].label : "";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: `flex items-start gap-3 px-4 py-3 text-sm ${locked ? "opacity-70" : "cursor-pointer"}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "mt-0.5 h-4 w-4",
				checked: !locked && features.includes(k),
				disabled: disabled || locked,
				onChange: (e) => onToggle(k, e.target.checked)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: FEATURES[k].label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: FEATURES[k].text
					}),
					locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs",
						children: [
							"Comes with ",
							need,
							".",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: BUY_URL,
								target: "_blank",
								rel: "noreferrer",
								className: "font-medium text-[#C2410C] underline",
								children: "Add it to my license"
							})
						]
					})
				]
			})]
		}, k);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm font-medium",
					children: "What kind of business is it?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: BUSINESS_TYPE_KEYS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled,
						onClick: () => onType(t),
						className: `rounded-xl border p-3 text-left text-sm transition ${type === t ? "border-[var(--section)] bg-[var(--section-soft)]" : "hover:bg-muted/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: BUSINESS_TYPES[t].label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: BUSINESS_TYPES[t].text
						})]
					}, t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted-foreground",
					children: "Picking a kind turns on the features it usually needs. Change any of them below."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium",
				children: "Main parts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: group(true).map(box)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium",
				children: "Extras"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: group(false).map(box)
			})] })
		]
	});
}
//#endregion
export { FeaturePicker as t };
