import { n as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/editions-Fg8o4E4M.js
var editions_Fg8o4E4M_exports = /* @__PURE__ */ __exportAll({
	a: () => 10,
	c: () => editions_exports,
	d: () => whoSells,
	i: () => EDITION_KEYS,
	l: () => licensedFeatures,
	n: () => ADDON_KEYS,
	o: () => bundle,
	r: () => EDITIONS,
	s: () => catalog,
	t: () => ADDONS_FOR_SALE,
	u: () => onlineBundle
});
var editions_exports = /* @__PURE__ */ __exportAll$1({
	ADDONS_FOR_SALE: () => ADDONS_FOR_SALE,
	ADDON_KEYS: () => ADDON_KEYS,
	EARLY_ACCESS_PCT: () => 50,
	EDITIONS: () => EDITIONS,
	EDITION_KEYS: () => EDITION_KEYS,
	ONLINE_EXTRA: () => ONLINE_EXTRA,
	YEARLY_MONTHS: () => 10,
	bundle: () => bundle,
	catalog: () => catalog,
	licensedFeatures: () => licensedFeatures,
	onlineBundle: () => onlineBundle,
	whoSells: () => whoSells
});
var EDITIONS = {
	personal: {
		label: "Personal",
		text: "Your own or your family's money: bank and cards, bills, budget, net worth, investments.",
		features: ["accounting", "personal"],
		companies: 1,
		users: 2,
		price: 99,
		founders: 59,
		month: 9,
		aiPages: 50
	},
	service: {
		label: "Service Business",
		text: "No stock to keep: quotes, invoices, vendors, banking, full accounting. Includes Personal.",
		features: [
			"sales",
			"purchasing",
			"accounting",
			"support",
			"tickets",
			"tech_pay",
			"personal"
		],
		companies: 2,
		users: 3,
		price: 499,
		founders: 299,
		month: 39,
		aiPages: 200
	},
	full: {
		label: "Full Business",
		text: "Everything in Service Business, plus inventory and work orders. Includes Personal.",
		features: [
			"sales",
			"purchasing",
			"inventory",
			"accounting",
			"work_orders",
			"support",
			"tickets",
			"tech_pay",
			"personal"
		],
		companies: 2,
		users: 3,
		price: 799,
		founders: 499,
		month: 59,
		aiPages: 300
	}
};
var EDITION_KEYS = Object.keys(EDITIONS);
var ADDONS_FOR_SALE = {
	real_estate: {
		label: "Real Estate",
		text: "Properties, tenants, leases, rent, deposits, rent roll, Airbnb and VRBO. Its own books.",
		features: ["real_estate"],
		companies: 1,
		price: 199,
		founders: 119,
		month: 15
	},
	crypto_tax: {
		label: "Crypto Tax",
		text: "Exchange history in; gains (FIFO, HIFO, LIFO), crypto income and Form 8949 rows out.",
		features: ["crypto_tax"],
		companies: 0,
		price: 99,
		founders: 59,
		month: 9
	}
};
var ADDON_KEYS = Object.keys(ADDONS_FOR_SALE);
/** Online: more people or companies than the plan includes, a month each. */
var ONLINE_EXTRA = {
	user: 5,
	company: 10
};
/**
* The parts of the app a license opens. null = everything (keys made before editions, early
* access keys, trials and online plans).
*/
function licensedFeatures(edition, addons) {
	const e = EDITIONS[edition];
	if (!e) return null;
	const extra = (addons ?? []).flatMap((a) => ADDONS_FOR_SALE[a]?.features ?? []);
	return [.../* @__PURE__ */ new Set([...e.features, ...extra])];
}
/** The edition that opens a feature, cheapest first (for "Needs Full Business"). */
function whoSells(f) {
	const a = ADDON_KEYS.find((k) => ADDONS_FOR_SALE[k].features.includes(f));
	if (a) return { addon: a };
	return { edition: EDITION_KEYS.find((k) => EDITIONS[k].features.includes(f)) };
}
/** Only numbers above 0 count (an empty box in the owner panel keeps the built-in price). */
var set = (o) => Object.fromEntries(Object.entries(o ?? {}).filter(([, v]) => typeof v === "number" && v > 0));
function catalog(o) {
	return {
		editions: Object.fromEntries(EDITION_KEYS.map((k) => [k, {
			...EDITIONS[k],
			...set(o?.editions?.[k])
		}])),
		addons: Object.fromEntries(ADDON_KEYS.map((k) => [k, {
			...ADDONS_FOR_SALE[k],
			...set(o?.addons?.[k])
		}])),
		extra: {
			...ONLINE_EXTRA,
			...set(o?.online_extra)
		}
	};
}
/** What an online plan costs a month (or a year), and what it includes. */
function onlineBundle(cat, edition, addons, extraUsers, extraCompanies, yearly) {
	const e = cat.editions[edition];
	const month = e.month + addons.reduce((s, a) => s + cat.addons[a].month, 0) + extraUsers * cat.extra.user + extraCompanies * cat.extra.company;
	return {
		month,
		total: yearly ? month * 10 : month,
		companies: e.companies + addons.reduce((s, a) => s + cat.addons[a].companies, 0) + extraCompanies,
		users: e.users + extraUsers,
		aiPages: e.aiPages
	};
}
/** What an edition with add-ons costs (founders or regular), and the companies and people it includes. */
function bundle(cat, edition, addons, founders) {
	const e = cat.editions[edition];
	const price = (x) => founders ? x.founders : x.price;
	return {
		total: price(e) + addons.reduce((s, a) => s + price(cat.addons[a]), 0),
		regular: e.price + addons.reduce((s, a) => s + cat.addons[a].price, 0),
		companies: e.companies + addons.reduce((s, a) => s + cat.addons[a].companies, 0),
		users: e.users
	};
}
//#endregion
export { bundle as a, licensedFeatures as c, EDITION_KEYS as i, onlineBundle as l, ADDON_KEYS as n, catalog as o, EDITIONS as r, editions_Fg8o4E4M_exports as s, ADDONS_FOR_SALE as t, whoSells as u };
