import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel, m as yearStart, o as balanceOf } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ht as Download, L as Printer } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as loadCharges, s as useRealEstate } from "./realestate-DQ-XkZ06.mjs";
import { n as downloadCsv } from "./csv-B2RT0TZd.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/rent-roll-X00ooaGX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RentRoll() {
	const [tab, setTab] = (0, import_react.useState)("roll");
	const [from, setFrom] = (0, import_react.useState)(yearStart());
	const [to, setTo] = (0, import_react.useState)(today());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Rent Roll",
				text: "Every unit with its tenant, rent and what's owed, and the profit of each property (for your accountant's Schedule E)."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex rounded-lg border p-0.5 text-sm",
					children: [["roll", "Rent roll"], ["pl", "Profit by property"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(k),
						className: `rounded-md px-3 py-1 ${tab === k ? "bg-[var(--section)] text-white" : ""}`,
						children: label
					}, k))
				}),
				tab === "pl" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value)
					})]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => window.print(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print or save PDF"]
				})
			]
		}),
		tab === "roll" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Roll, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PropertyProfit, {
			from,
			to
		})
	] });
}
function Roll() {
	const { data: re, isLoading } = useRealEstate();
	const { data: charges } = useQuery({
		queryKey: ["rent-charges", "all"],
		queryFn: () => loadCharges(false)
	});
	if (isLoading || !re) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const owed = /* @__PURE__ */ new Map();
	const deposits = /* @__PURE__ */ new Map();
	for (const c of charges ?? []) {
		if (c.status === "open") owed.set(c.lease_id, (owed.get(c.lease_id) ?? 0) + c.balance);
		if (c.kind === "deposit" && c.status !== "void") deposits.set(c.lease_id, (deposits.get(c.lease_id) ?? 0) + c.amount_paid);
	}
	const rows = re.properties.filter((p) => p.is_active).flatMap((p) => re.units.filter((u) => u.property_id === p.id && u.is_active).map((u) => {
		const l = re.current(u.id);
		return {
			property: p.name,
			unit: u.name,
			tenant: l ? re.tenant.get(l.tenant_id)?.name ?? "" : "Vacant",
			start: l?.start_date ?? "",
			end: l ? l.end_date ?? "Month to month" : "",
			rent: l?.rent ?? 0,
			asking: u.market_rent ?? 0,
			deposit: l ? deposits.get(l.id) ?? 0 : 0,
			owed: l ? owed.get(l.id) ?? 0 : 0
		};
	}));
	const sum = (k) => rows.reduce((s, r) => s + r[k], 0);
	const vacant = rows.filter((r) => r.tenant === "Vacant").length;
	const csv = () => downloadCsv(`rent-roll-${today()}`, [
		[
			"Property",
			"Unit",
			"Tenant",
			"Lease start",
			"Lease end",
			"Rent",
			"Deposit held",
			"Owed now"
		],
		...rows.map((r) => [
			r.property,
			r.unit,
			r.tenant,
			r.start,
			r.end,
			r.rent,
			r.deposit,
			r.owed
		]),
		[
			"Total",
			"",
			"",
			"",
			"",
			sum("rent"),
			sum("deposit"),
			sum("owed")
		]
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl rounded-2xl border bg-card p-6 print:border-0 print:p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Rent roll"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						fmtDate(today()),
						" · ",
						rows.length,
						" units, ",
						vacant,
						" vacant · ",
						fmtMoney(sum("rent")),
						" a month"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					className: "print:hidden",
					onClick: csv,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download CSV"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-xs sm:text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "Property · unit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "Tenant"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "Lease"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "Rent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "Deposit held"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "Owed now"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-1 pr-2",
								children: [
									r.property,
									" · ",
									r.unit
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: `py-1 pr-2 ${r.tenant === "Vacant" ? "text-amber-600" : ""}`,
								children: [r.tenant, r.tenant === "Vacant" && r.asking ? ` (asking ${fmtMoney(r.asking)})` : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 pr-2",
								children: r.start ? `${fmtDate(r.start)} – ${/^\d/.test(r.end) ? fmtDate(r.end) : r.end}` : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: r.rent ? fmtMoney(r.rent) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: r.deposit ? fmtMoney(r.deposit) : ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `py-1 text-right tabular-nums ${r.owed > 0 ? "text-destructive" : ""}`,
								children: r.owed ? fmtMoney(r.owed) : ""
							})
						]
					}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t-2 font-semibold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1",
								colSpan: 3,
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: fmtMoney(sum("rent"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: fmtMoney(sum("deposit"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-1 text-right tabular-nums",
								children: fmtMoney(sum("owed"))
							})
						]
					})] })]
				})
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-4 text-center text-muted-foreground",
				children: "Add properties and units first."
			})
		]
	});
}
function PropertyProfit({ from, to }) {
	const { data: re } = useRealEstate();
	const { data: accounts } = useAccounts();
	const { data, isLoading, error } = useQuery({
		queryKey: [
			"account-totals",
			"property",
			from,
			to
		],
		queryFn: async () => {
			const { data, error } = await db.rpc("property_totals", {
				_from: from,
				_to: to
			});
			if (error) throw error;
			return data ?? [];
		}
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6 text-sm text-destructive",
		children: error.message
	});
	if (isLoading || !re || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const acc = new Map(accounts.map((a) => [a.id, a]));
	const props = re.properties.map((p) => {
		const lines = (data ?? []).filter((r) => r.property_id === p.id).map((r) => ({
			a: acc.get(r.account_id),
			d: Number(r.debit),
			c: Number(r.credit)
		})).filter((x) => x.a && (x.a.type === "income" || x.a.type === "expense")).map((x) => ({
			a: x.a,
			amount: balanceOf(x.a.type, x.d, x.c)
		})).filter((x) => Math.abs(x.amount) > .004);
		const income = lines.filter((x) => x.a.type === "income");
		const expenses = lines.filter((x) => x.a.type === "expense");
		const sum = (l) => l.reduce((s, x) => s + x.amount, 0);
		return {
			p,
			income,
			expenses,
			inc: sum(income),
			exp: sum(expenses)
		};
	}).filter((x) => x.p.is_active || x.income.length || x.expenses.length);
	const csv = () => downloadCsv(`profit-by-property-${from}-to-${to}`, [[
		"Property",
		"Account",
		"Amount"
	], ...props.flatMap((x) => [
		...x.income.map((l) => [
			x.p.name,
			accountLabel(l.a),
			l.amount
		]),
		[
			x.p.name,
			"Total income",
			x.inc
		],
		...x.expenses.map((l) => [
			x.p.name,
			accountLabel(l.a),
			l.amount
		]),
		[
			x.p.name,
			"Total expenses",
			x.exp
		],
		[
			x.p.name,
			"Net profit",
			x.inc - x.exp
		]
	])]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						fmtDate(from),
						" to ",
						fmtDate(to),
						". Rent goes to its property by itself; for expenses, pick the property on each bill line."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: csv,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download CSV"]
				})]
			}),
			props.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border bg-card p-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-2 font-display text-lg font-semibold",
						children: x.p.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "Income"
					}),
					x.income.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: accountLabel(l.a),
						v: l.amount
					}, l.a.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: "Total income",
						v: x.inc,
						bold: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-semibold",
						children: "Expenses"
					}),
					x.expenses.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: accountLabel(l.a),
						v: l.amount
					}, l.a.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: "Total expenses",
						v: x.exp,
						bold: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 rounded-lg bg-muted/50 px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
							label: "Net profit",
							v: x.inc - x.exp,
							bold: true
						})
					})
				]
			}, x.p.id)),
			props.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
				children: "No properties yet."
			})
		]
	});
}
function Line({ label, v, bold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between py-1 ${bold ? "border-t font-semibold" : "pl-4"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: fmtMoney(v)
		})]
	});
}
//#endregion
export { RentRoll as component };
