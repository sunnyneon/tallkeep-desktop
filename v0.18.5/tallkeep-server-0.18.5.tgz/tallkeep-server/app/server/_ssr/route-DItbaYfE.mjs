import { t as supabase } from "./client-C9I0PyVu.mjs";
import { J as redirect, _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/route-DItbaYfE.js
var $$splitComponentImporter = () => import("./route-sn3GRAnP.mjs");
/** Tallkeep's own admin panel (admin.tallkeep.com). Separate from any company's books. */
var Route = createFileRoute("/admin")({
	ssr: false,
	beforeLoad: async () => {
		const { data } = await supabase.auth.getUser();
		if (!data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	head: () => ({ meta: [{ title: "Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
