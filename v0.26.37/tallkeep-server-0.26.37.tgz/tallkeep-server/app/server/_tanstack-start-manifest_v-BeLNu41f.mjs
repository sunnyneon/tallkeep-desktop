//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BeLNu41f.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-wR6mK07V.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DW-PEJtC.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-B0hFzWF9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-wR6mK07V.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DKBKcESB.js",
			"/assets/log-out-BmzPbybC.js",
			"/assets/testers.functions-qmAElQ1E.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-CaRkJSHq.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-hvyUxVoy.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-BGDNUIXE.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/dist-C0nucPhw.js",
			"/assets/dialog-Df7UoMbj.js",
			"/assets/queries-BdZnnKyx.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/label-BxCXH67y.js",
			"/assets/textarea-h1y0mpJE.js",
			"/assets/shoebox-BX_aBgw7.js",
			"/assets/company-DDT0Ppw-.js",
			"/assets/reports-B6rNfjbW.js",
			"/assets/access-Car0HOC8.js",
			"/assets/theme-CX0Uxsvg.js",
			"/assets/Logo-DnRZjYxG.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CYxq0YRc.js",
			"/assets/log-out-BmzPbybC.js",
			"/assets/admin.functions-9P2Bho8f.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DnRZjYxG.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Bz4iWbdz.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/label-BxCXH67y.js",
			"/assets/Logo-DnRZjYxG.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Dj2ncAjN.js",
			"/assets/testers.functions-qmAElQ1E.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/coupons.functions-DEmz5msZ.js",
			"/assets/buy.functions-BW3TWEMQ.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-VD7C8kUe.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/downloads.functions-ChnAUYNG.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Bet_JXZs.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/label-BxCXH67y.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-AsCdGhvp.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/label-BxCXH67y.js",
			"/assets/Logo-DnRZjYxG.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-CfzE68fB.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/upgrade.functions-DTm4uCno.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-TuFIg-Gw.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/label-BxCXH67y.js",
			"/assets/Logo-DnRZjYxG.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BOIjBm2Q.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Dmad57dm.js", "/assets/StockDocList-D27yqNaz.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-SMYABTfy.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/ai-BA4sC6T3.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-CZ-BYIOv.js",
			"/assets/BankConnections-wwiNC7hG.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-B0yGaeJZ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DRfoZ17w.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-wwiNC7hG.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/ai-BA4sC6T3.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DW_qD8PB.js",
			"/assets/TxnEditor-B3wIj43h.js",
			"/assets/feedWaiting-B81ERxjl.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DlTGT-Nt.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-BVb8XwN2.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-BiBjv-y5.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/personal-BTPBGUqy.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/WhoPicker-CjQYyhxZ.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DeH0m6tB.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-Bmr-iRaE.js", "/assets/AccountRegister-C1sOcbF7.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DuxQXpJj.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BLBsyYwx.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/money-C7gxj7H_.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-JbBJEsBS.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BA4sC6T3.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DEbZVCwW.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BbUDqmIU.js", "/assets/StockDocList-D27yqNaz.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-CBIzyjCl.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-D1WYPveL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-BkuoRVCV.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BuJCOlUL.js", "/assets/PartyList-DdDW394t.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CncjGC4I.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-B2peFBgQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/storage.functions-Bnz3cwEQ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-h72q4fD8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CNtQl-vX.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-vCQrVuUX.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Csh5NOdP.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BNSwVNUF.js", "/assets/ChangeHistory-91IFlJgD.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CjXrLx4W.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/members-BBaEfgVx.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-BG9j-7YV.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/personal-BTPBGUqy.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/WhoPicker-CjQYyhxZ.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-8STvF2AR.js", "/assets/SalesList-8Yq_wgtT.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-Bh8Kyy8m.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Boho8Leu.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-e15jwJxv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-Dpc3tftt.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/loans-DW_qD8PB.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CpJS_LNJ.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-C7PetPh4.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-DVPRrLDp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/personal-BTPBGUqy.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/WhoPicker-CjQYyhxZ.js",
			"/assets/reminders-DnhE4L8I.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-ByeSoapV.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BNhcK3Bb.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/personal-BTPBGUqy.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/WhoPicker-CjQYyhxZ.js",
			"/assets/generateCategoricalChart-CKWz36fo.js",
			"/assets/Area-DEKOiTsl.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DBqHXwBp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/generateCategoricalChart-CKWz36fo.js",
			"/assets/PlCharts-vCQrVuUX.js",
			"/assets/BarChart-ajCI2NzZ.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BeEOWeWB.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/balances-BVb8XwN2.js",
			"/assets/money-C7gxj7H_.js",
			"/assets/DecimalInput-C4yzMku_.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CgsV3X_n.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-ENnVnljb.js",
			"/assets/createServerFn-Cxji9tsf.js",
			"/assets/auth-middleware-Cy_fHDUU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/storage.functions-Bnz3cwEQ.js",
			"/assets/coupons.functions-DEmz5msZ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DHV49EYh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-C9s0Nn_N.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/DecimalInput-C4yzMku_.js",
			"/assets/StockDialogs-epy-hKk9.js",
			"/assets/checkbox-XrDFLJYY.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DNQMyPuO.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-A6Su-0EP.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DogGVg5T.js", "/assets/SalesList-8Yq_wgtT.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-ByThF069.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/ai-BA4sC6T3.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bnz3cwEQ.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-Ct25uAtq.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/money-C7gxj7H_.js",
			"/assets/badge-BiOp-5cP.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-CtOoRmhd.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CVrai2Iu.js", "/assets/AccountRegister-C1sOcbF7.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DyBaSLrA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/MoneyAccountPick-DW4IT6u2.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-wFq95diP.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-Dp3eX5yV.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/RepeatInvoice-BuEjVfJD.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Y75J4-JZ.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-CKWz36fo.js",
			"/assets/BarChart-ajCI2NzZ.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-BW8NIw7W.js", "/assets/SalesList-8Yq_wgtT.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-C7s707wV.js", "/assets/SalesList-8Yq_wgtT.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BiWaKinA.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-DTfmhATj.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/serials-Da7pUdah.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CY9PTw-0.js",
			"/assets/createServerFn-Cxji9tsf.js",
			"/assets/auth-middleware-Cy_fHDUU.js",
			"/assets/AppsCatalog-Cuf-cqIo.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CmkqyeAf.js",
			"/assets/switch-C7PetPh4.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-BkuoRVCV.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-CCs8SuCh.js",
			"/assets/footers-CT-N4jqR.js",
			"/assets/PrintFrame-BcF4KmnK.js",
			"/assets/checkbox-XrDFLJYY.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-GwAoykUm.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-D5iz_ndW.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-Cuf-cqIo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-wwiNC7hG.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-Dtbne8sN.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/StockDialogs-epy-hKk9.js",
			"/assets/photos-CCs8SuCh.js",
			"/assets/stockmove-B0C8A7H3.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CL9v5HBz.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/loans-DW_qD8PB.js",
			"/assets/feedWaiting-B81ERxjl.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Bnz3cwEQ.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CZfrZirU.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/PrintFrame-BcF4KmnK.js",
			"/assets/DocPdf-CqLa5BgL.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-BRn3Gtu4.js",
			"/assets/createServerFn-Cxji9tsf.js",
			"/assets/auth-middleware-Cy_fHDUU.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/MoneyAccountPick-DW4IT6u2.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-GwAoykUm.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-yFwfJVT4.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/StockDialogs-epy-hKk9.js",
			"/assets/stockmove-B0C8A7H3.js",
			"/assets/checkbox-XrDFLJYY.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BS85Agzh.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/members-BBaEfgVx.js",
			"/assets/WhoPicker-CjQYyhxZ.js",
			"/assets/reminders-DnhE4L8I.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CrVvYIBL.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/tickets.functions-B09y-Wcl.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Be0yMbN3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-GwAoykUm.js",
			"/assets/support.functions-DTfpCLmv.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CNHHu8uu.js", "/assets/StockDocList-D27yqNaz.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-Bnk4qFMG.js", "/assets/PartyList-DdDW394t.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-C6gFMeu2.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/tickets.functions-B09y-Wcl.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-xmTgLlg7.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/workorders-DU_zcSmo.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CVEmr-T6.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-D7Vvi0J4.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/coupons.functions-DEmz5msZ.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BXNkmq-i.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/AdminAccount-ZTockB2Z.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CEWQW9kq.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/downloads.functions-ChnAUYNG.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-CDmymy34.js",
			"/assets/createServerFn-Cxji9tsf.js",
			"/assets/auth-middleware-Cy_fHDUU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-7y1rBqTj.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BTI2dsdE.js",
			"/assets/testers.functions-qmAElQ1E.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CLxXfCaM.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-ehexU6We.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BW3TWEMQ.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CTQOPPS1.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/textarea-h1y0mpJE.js",
			"/assets/support.functions-DTfpCLmv.js",
			"/assets/HelpParts-PxjJ4-oU.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-7Dcdi-_t.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-CLxQByv_.js",
			"/assets/manual._slug-BohUN_0W.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Ct3HNPOo.js",
			"/assets/createServerFn-Cxji9tsf.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DLZQhi6A.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DTm4uCno.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-srdNBgtn.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BA4sC6T3.js",
			"/assets/personal-BTPBGUqy.js",
			"/assets/reminders-DnhE4L8I.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-H4cc_F1j.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/AdminAccount-ZTockB2Z.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-YwrXfe1j.js", "/assets/ManualFrame-CLxQByv_.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B0VPQnsV.js", "/assets/AccountRegister-C1sOcbF7.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-D-X-bdHr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/OriginalLink-DfpHgmqN.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/realestate-QvyOrZLO.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CFM0PNHn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/realestate-QvyOrZLO.js",
			"/assets/money-C7gxj7H_.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DkCQFb3t.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-B9Ypi60i.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/SideList-De6gF7G6.js",
			"/assets/PartyHistory-pTClcCb4.js",
			"/assets/tabs-BtPdpXt6.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CYreBIwL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/ChangeHistory-91IFlJgD.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/SideList-De6gF7G6.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-C4yzMku_.js",
			"/assets/StockDialogs-epy-hKk9.js",
			"/assets/NewProductDialog-DmgRwaBj.js",
			"/assets/MoneyAccountPick-DW4IT6u2.js",
			"/assets/footers-CT-N4jqR.js",
			"/assets/PrintFrame-BcF4KmnK.js",
			"/assets/serials-Da7pUdah.js",
			"/assets/SerialsBox-DC6wplQI.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-C06b3S3s.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-91IFlJgD.js",
			"/assets/switch-C7PetPh4.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BiOp-5cP.js",
			"/assets/SideList-De6gF7G6.js",
			"/assets/tabs-BtPdpXt6.js",
			"/assets/StockDialogs-epy-hKk9.js",
			"/assets/photos-CCs8SuCh.js",
			"/assets/stockmove-B0C8A7H3.js",
			"/assets/serials-Da7pUdah.js",
			"/assets/SerialsBox-DC6wplQI.js",
			"/assets/workorders-DU_zcSmo.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BuCKtdJk.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/ChangeHistory-91IFlJgD.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/booksStart-B9Ypi60i.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/SideList-De6gF7G6.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-C4yzMku_.js",
			"/assets/NewProductDialog-DmgRwaBj.js",
			"/assets/MoneyAccountPick-DW4IT6u2.js",
			"/assets/footers-CT-N4jqR.js",
			"/assets/PrintFrame-BcF4KmnK.js",
			"/assets/cardpay-CNRV3w6r.js",
			"/assets/checkbox-XrDFLJYY.js",
			"/assets/serials-Da7pUdah.js",
			"/assets/workorders-DU_zcSmo.js",
			"/assets/RepeatInvoice-BuEjVfJD.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-B09y-Wcl.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CeFuYPJy.js",
			"/assets/select-CTfjRwQy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/SideList-De6gF7G6.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-ClHHf4ML.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/quickadd-BXmJ_sGT.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-GwAoykUm.js",
			"/assets/support.functions-DTfpCLmv.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-Bbsi3VUU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CBhCTnME.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/SideList-De6gF7G6.js",
			"/assets/PartyHistory-pTClcCb4.js",
			"/assets/tabs-BtPdpXt6.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DW8S_CHo.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/accounting-C_rxzavJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/sales-DEbZVCwW.js",
			"/assets/footers-CT-N4jqR.js",
			"/assets/tickets.functions-B09y-Wcl.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BhhDx5XP.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/input-CElS7Mrs.js",
			"/assets/skeleton-PTG3yZhk.js",
			"/assets/AdminAccount-ZTockB2Z.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-yfvc5w8y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-BCyBOgXS.js",
			"/assets/textarea-h1y0mpJE.js",
			"/assets/support-GwAoykUm.js",
			"/assets/support.functions-DTfpCLmv.js",
			"/assets/HelpParts-PxjJ4-oU.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BXGzAdkQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-PTG3yZhk.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
