import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/coupons.functions-g-i9T74O.js
/**
* Discount codes (friends and family, step 080). The owner makes them in the admin panel; each is
* also a Stripe coupon, which counts the uses and stops the code at its limit or end date.
* Customers type the code on the Buy page (desktop) or the Plan page (online).
*/
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
async function owner(userId) {
	const { requireOwner } = await import("./admin.functions-CHEGymV3.mjs");
	await requireOwner(userId);
	return admin();
}
var cleanCode = (c) => String(c ?? "").trim().toUpperCase().replace(/\s+/g, "").slice(0, 20);
function offLabel(c) {
	return c.percent_off != null ? `${Number(c.percent_off)}% off` : `$${Number(c.amount_off)} off`;
}
/** Ends after this day, Central time. */
var ended = (d) => !!d && Date.now() > (/* @__PURE__ */ new Date(`${d}T23:59:59-06:00`)).getTime();
/**
* The code, if it can be used now for this kind of purchase. Server only: Stripe's own count
* decides whether any uses are left.
*/
async function couponFor(code, kind) {
	const { data } = await (await admin()).from("coupons").select("*").eq("code", cleanCode(code)).maybeSingle();
	const c = data;
	if (!c || !c.active) return {
		ok: false,
		why: "That discount code isn't right."
	};
	if (kind === "desktop" && !c.for_desktop) return {
		ok: false,
		why: "That discount code is for online plans only."
	};
	if (kind === "online" && !c.for_online) return {
		ok: false,
		why: "That discount code is for the desktop version only."
	};
	if (ended(c.ends_on)) return {
		ok: false,
		why: "That discount code has ended."
	};
	const { stripe } = await import("./pay.server-jfyp4KBB.mjs");
	if (!(await stripe(`coupons/${c.stripe_coupon}`).catch(() => null))?.valid) return {
		ok: false,
		why: "That discount code has been used up or has ended."
	};
	return {
		ok: true,
		coupon: c
	};
}
var checkCoupon_createServerFn_handler = createServerRpc({
	id: "81ebdc76d7715e2ec6681729423a391a581eb56db9bb3dbc43f9403df008c1e2",
	name: "checkCoupon",
	filename: "src/lib/coupons.functions.ts"
}, (opts) => checkCoupon.__executeServer(opts));
var checkCoupon = createServerFn({ method: "GET" }).inputValidator((d) => ({
	code: cleanCode(d.code),
	kind: d.kind === "online" ? "online" : "desktop"
})).handler(checkCoupon_createServerFn_handler, async ({ data }) => {
	if (!/^[A-Z0-9-]{3,20}$/.test(data.code)) return {
		ok: false,
		why: "That discount code isn't right."
	};
	const r = await couponFor(data.code, data.kind).catch(() => ({
		ok: false,
		why: "Couldn't check the code. Try again in a minute."
	}));
	if (!r.ok) return {
		ok: false,
		why: r.why
	};
	const c = r.coupon;
	return {
		ok: true,
		code: c.code,
		label: offLabel(c),
		percentOff: c.percent_off != null ? Number(c.percent_off) : null,
		amountOff: c.amount_off != null ? Number(c.amount_off) : null,
		forever: c.online_forever
	};
});
var listCoupons_createServerFn_handler = createServerRpc({
	id: "a44e41254623c4d16ca20558834ecb427ea77f1edd06af1f90288510a5f2cec0",
	name: "listCoupons",
	filename: "src/lib/coupons.functions.ts"
}, (opts) => listCoupons.__executeServer(opts));
var listCoupons = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listCoupons_createServerFn_handler, async ({ context }) => {
	const { data, error } = await (await owner(context.userId)).from("coupons").select("*").order("created_at", { ascending: false });
	if (error) throw new Error(error.message);
	const { stripe } = await import("./pay.server-jfyp4KBB.mjs");
	return Promise.all((data ?? []).map(async (c) => {
		const s = c.active ? await stripe(`coupons/${c.stripe_coupon}`).catch(() => null) : null;
		return {
			...c,
			used: s?.times_redeemed ?? null,
			working: c.active && !!s?.valid && !ended(c.ends_on)
		};
	}));
});
var makeCoupon_createServerFn_handler = createServerRpc({
	id: "7b34d63ea96b170441073a82e6c0dfeaf7194cadc7a8470d3c30f5a2a2aa0bbb",
	name: "makeCoupon",
	filename: "src/lib/coupons.functions.ts"
}, (opts) => makeCoupon.__executeServer(opts));
var makeCoupon = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const code = cleanCode(d.code);
	if (!/^[A-Z0-9-]{3,20}$/.test(code)) throw new Error("The code: 3 to 20 letters, numbers or dashes, like FAMILY25.");
	const amount = Number(d.amount);
	if (d.kind === "percent" && !(amount > 0 && amount <= 100)) throw new Error("Percent off: 1 to 100.");
	if (d.kind === "amount" && !(amount > 0 && amount <= 1e4)) throw new Error("Dollars off: more than 0.");
	if (!d.forDesktop && !d.forOnline) throw new Error("Pick desktop, online, or both.");
	const maxUses = d.maxUses ? Math.floor(Number(d.maxUses)) : null;
	if (maxUses != null && !(maxUses > 0 && maxUses <= 1e5)) throw new Error("How many people can use it: 1 or more, or leave it empty.");
	const endsOn = d.endsOn || null;
	if (endsOn && !/^\d{4}-\d{2}-\d{2}$/.test(endsOn)) throw new Error("Pick an end date.");
	if (endsOn && ended(endsOn)) throw new Error("The end date has already passed.");
	return {
		code,
		note: String(d.note ?? "").trim().slice(0, 200) || null,
		kind: d.kind === "amount" ? "amount" : "percent",
		amount: Math.round(amount * 100) / 100,
		forDesktop: !!d.forDesktop,
		forOnline: !!d.forOnline,
		onlineForever: !!d.onlineForever,
		maxUses,
		endsOn
	};
}).handler(makeCoupon_createServerFn_handler, async ({ data, context }) => {
	const db = await owner(context.userId);
	const { data: same } = await db.from("coupons").select("id").eq("code", data.code).maybeSingle();
	if (same) throw new Error(`There's already a code ${data.code}. Pick another name.`);
	const { stripe } = await import("./pay.server-jfyp4KBB.mjs");
	const form = {
		name: data.code,
		duration: data.onlineForever ? "forever" : "once",
		"metadata[tallkeep_code]": data.code,
		max_redemptions: data.maxUses ?? void 0,
		redeem_by: data.endsOn ? Math.floor((/* @__PURE__ */ new Date(`${data.endsOn}T23:59:59-06:00`)).getTime() / 1e3) : void 0
	};
	if (data.kind === "percent") form["percent_off"] = data.amount;
	else {
		form["amount_off"] = Math.round(data.amount * 100);
		form["currency"] = "usd";
	}
	const s = await stripe("coupons", form);
	const { error } = await db.from("coupons").insert({
		code: data.code,
		note: data.note,
		percent_off: data.kind === "percent" ? data.amount : null,
		amount_off: data.kind === "amount" ? data.amount : null,
		for_desktop: data.forDesktop,
		for_online: data.forOnline,
		online_forever: data.onlineForever,
		max_uses: data.maxUses,
		ends_on: data.endsOn,
		stripe_coupon: s.id
	});
	if (error) {
		await stripe(`coupons/${s.id}`, void 0, null, "DELETE").catch(() => null);
		throw new Error(/coupons/.test(error.message) && /exist|schema cache/.test(error.message) ? "Discount codes need database step 80 (docs/db/080_coupons.sql)." : error.message);
	}
	return { ok: true };
});
var stopCoupon_createServerFn_handler = createServerRpc({
	id: "fea8d2c8e298f5cdcd63c09456ca7e1cbaac5986c9fb9709f7bec4c9549bf574",
	name: "stopCoupon",
	filename: "src/lib/coupons.functions.ts"
}, (opts) => stopCoupon.__executeServer(opts));
var stopCoupon = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^[0-9a-f-]{36}$/.test(d.id)) throw new Error("Bad request");
	return d;
}).handler(stopCoupon_createServerFn_handler, async ({ data, context }) => {
	const db = await owner(context.userId);
	const { data: c } = await db.from("coupons").select("*").eq("id", data.id).maybeSingle();
	if (!c) throw new Error("That code isn't there any more.");
	const { stripe } = await import("./pay.server-jfyp4KBB.mjs");
	await stripe(`coupons/${c.stripe_coupon}`, void 0, null, "DELETE").catch((e) => {
		if (!/No such coupon/i.test(e.message)) throw e;
	});
	const { error } = await db.from("coupons").update({ active: false }).eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
//#endregion
export { checkCoupon_createServerFn_handler, listCoupons_createServerFn_handler, makeCoupon_createServerFn_handler, stopCoupon_createServerFn_handler };
