import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-list-lyNNrYkK.js
var $$splitComponentImporter = () => import("./sales-list-BImigpBw.mjs");
var Route = createFileRoute("/_authenticated/sales-list")({
	validateSearch: (s) => s["pay"] === "late" ? { pay: "late" } : {},
	head: () => ({ meta: [{ title: "Sales List · Tallkeep" }, {
		name: "description",
		content: "All quotes, invoices and RMAs in one list."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
