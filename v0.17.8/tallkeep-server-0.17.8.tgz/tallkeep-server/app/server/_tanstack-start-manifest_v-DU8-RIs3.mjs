//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DU8-RIs3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CcJuoUcy.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BOnD92nf.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CPMf25U9.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CcJuoUcy.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-gj5h7ZXs.js",
			"/assets/log-out-DSGynSlO.js",
			"/assets/testers.functions-CnIGxvrs.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-BIqzB3K-.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/BarcodeScanner-Dfg2zLEB.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/label-BZ3AE0CV.js",
			"/assets/textarea-QXjER0NZ.js",
			"/assets/dist-DU3MdUZg.js",
			"/assets/dialog-CowvGxup.js",
			"/assets/command-DBgce_X2.js",
			"/assets/company-CJ01NU37.js",
			"/assets/reports-gi3P3Ahh.js",
			"/assets/access-CoJunK4y.js",
			"/assets/shoebox-0mL25C8N.js",
			"/assets/UpdateBar-DmtGQ_LL.js",
			"/assets/Logo-Crlhdyht.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-ZHip4NaG.js",
			"/assets/log-out-DSGynSlO.js",
			"/assets/admin.functions-DuaZ78V3.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-Crlhdyht.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BvFvuaBe.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/label-BZ3AE0CV.js",
			"/assets/Logo-Crlhdyht.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BbMAWuBR.js",
			"/assets/testers.functions-CnIGxvrs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/buy.functions-DUSG2ks6.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CQwITGZH.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/downloads.functions-BMcKreLQ.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-C8ROKc5J.js",
			"/assets/testers.functions-CnIGxvrs.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/textarea-QXjER0NZ.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-7r_3W1MT.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/label-BZ3AE0CV.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-D89fnOII.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/label-BZ3AE0CV.js",
			"/assets/Logo-Crlhdyht.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-rvFdfxWz.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/upgrade.functions-DF9Vt6dU.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-DIeGBquG.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/label-BZ3AE0CV.js",
			"/assets/Logo-Crlhdyht.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-C2kZZr44.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DTquDnob.js", "/assets/StockDocList-BR4ENAE_.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CGh_Ku-D.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/ai.functions-Cx7qJUcE.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-jG6R7tYl.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/SearchSelect-CXiFeJr_.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BrmzA4fg.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/ai.functions-Cx7qJUcE.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DtGKhGsv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-Y3bnUf8G.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-Dy_WP0Tf.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-7I7sI4u6.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-OlCKmb4E.js", "/assets/AccountRegister-CPwua-cL.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-z6y3EIeF.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-y3T-XykW.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BIFbcDB3.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai.functions-Cx7qJUcE.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-BMoxvjWb.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-D63M-6UR.js", "/assets/StockDocList-BR4ENAE_.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-C16oYSRX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-DYyxE2Jo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BbwacfAV.js",
			"/assets/QuickBooksImport-BzNbbQqD.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DAEgOiH-.js", "/assets/PartyList-Dsv_wSC4.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-y3ILM593.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-DRubkGa3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-D_jXbXwY.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-8UNYEoAz.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CGfOpivT.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/members-BbwacfAV.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-C2iFdWKA.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-Dy_WP0Tf.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-DQ8y3Fol.js", "/assets/SalesList-BrX-5UCt.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-DiRpNZKT.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BgsAq-Ps.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-AvzdZX6q.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/loans-DhR1zMtS.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Mglu_NFe.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-wc4EmwOl.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Bl5vRQX6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-Dy_WP0Tf.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Btt5cJbC.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BtnPazI6.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-Dy_WP0Tf.js",
			"/assets/generateCategoricalChart-4DpMGd4I.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DE0tG_w3.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-4DpMGd4I.js",
			"/assets/BarChart-BaJdrVGz.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DqmrjPoA.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DCKKiHmW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-8SCd6Wdx.js",
			"/assets/createServerFn-Cxi2fPQF.js",
			"/assets/auth-middleware-B4EV8HrU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CwbwKQlg.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-D9U1mph7.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/badge-u1wcG0AL.js",
			"/assets/checkbox-BNYLIjzJ.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-Ves-Bkfs.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-6gd-wivT.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BTedHtjn.js", "/assets/SalesList-BrX-5UCt.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BDGJ0h35.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/ai.functions-Cx7qJUcE.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/bankfile-CQXrRFI-.js",
			"/assets/scanQueue-tUCNVqIP.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BEo5kBiY.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js",
			"/assets/badge-u1wcG0AL.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-B0l5EoRP.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-B1ukmWoV.js", "/assets/AccountRegister-CPwua-cL.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DVrbBCJK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-u1wcG0AL.js",
			"/assets/MoneyAccountPick-D0QcGsqt.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-lQSWsNW7.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BNrMtaWk.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-4DpMGd4I.js",
			"/assets/BarChart-BaJdrVGz.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-DgzOa6_6.js", "/assets/SalesList-BrX-5UCt.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DWmq2aRz.js", "/assets/SalesList-BrX-5UCt.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-MJcQ14If.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BmZtR8Yd.js",
			"/assets/createServerFn-Cxi2fPQF.js",
			"/assets/auth-middleware-B4EV8HrU.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/dist-DXsZC5Xb.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/QuickBooksImport-BzNbbQqD.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-BNYLIjzJ.js",
			"/assets/users.functions-vH_wKpq6.js",
			"/assets/FeaturePicker-CbEUQHs-.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-C1IQWj_S.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/FeaturePicker-CbEUQHs-.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CTHvzQwt.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/stockmove-DtRtY65W.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/photos-DS6FdkZl.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-D8Ezrbre.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/loans-DhR1zMtS.js",
			"/assets/scanQueue-tUCNVqIP.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CnBPMMGO.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/DocPdf-BllgfnmZ.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-6qjLjkwD.js",
			"/assets/createServerFn-Cxi2fPQF.js",
			"/assets/auth-middleware-B4EV8HrU.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/badge-u1wcG0AL.js",
			"/assets/MoneyAccountPick-D0QcGsqt.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DdopF115.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/stockmove-DtRtY65W.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/checkbox-BNYLIjzJ.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-Cyn82ixT.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/members-BbwacfAV.js",
			"/assets/WhoPicker-Dy_WP0Tf.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-053DsB6m.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/tickets.functions-mcxpsfEL.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-BxtYkD_Y.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DVChOMWb.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DDD4O5Ij.js", "/assets/StockDocList-BR4ENAE_.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DgLWQEQw.js", "/assets/PartyList-Dsv_wSC4.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-DNWAr9TH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/tickets.functions-mcxpsfEL.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-C4P62Pzs.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/badge-u1wcG0AL.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-cSZWx4T2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/csv-hyIDYwWI.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-DCC9gUHm.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/AdminAccount-BRavQntA.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BUEvjF6J.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/downloads.functions-BMcKreLQ.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-SosfkGEd.js",
			"/assets/createServerFn-Cxi2fPQF.js",
			"/assets/auth-middleware-B4EV8HrU.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-Cw_j0fvK.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DUsXf69Y.js",
			"/assets/testers.functions-CnIGxvrs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-nnmIExx0.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BbKoHyrm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/buy.functions-DUSG2ks6.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-D0ducC8X.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/textarea-QXjER0NZ.js",
			"/assets/support.functions-DVChOMWb.js",
			"/assets/HelpParts-CzdUkwAm.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CTq-lvnH.js",
			"/assets/ManualFrame-DrjfgOKT.js",
			"/assets/manual._slug-DWBGvZn7.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BmfoTJoF.js",
			"/assets/createServerFn-Cxi2fPQF.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Bp1h7Q1C.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/upgrade.functions-DF9Vt6dU.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CZ8YeIto.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/personal-DcpXUzH-.js",
			"/assets/reminders-f1ViETXE.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BuqLd5w7.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/AdminAccount-BRavQntA.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-D69HM2CC.js", "/assets/ManualFrame-DrjfgOKT.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-nOWKdYLX.js", "/assets/AccountRegister-CPwua-cL.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-BhjjWZme.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/realestate-hdRlfiWs.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C4_GFhsg.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CJ5_MgL6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/realestate-hdRlfiWs.js",
			"/assets/money-CvRmnkJl.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-B_yeovJQ.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CuOcTkst.js",
			"/assets/PartyHistory-CaIIzDDL.js",
			"/assets/tabs-sRaN1zUq.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DVCf3eUC.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/popover-SHIchrPv.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CuOcTkst.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/MoneyAccountPick-D0QcGsqt.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-Co8hcFap.js",
			"/assets/PrintFrame-DdqbEiyY.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-B6EKNWu2.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/popover-SHIchrPv.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/stockmove-DtRtY65W.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/switch-wc4EmwOl.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/badge-u1wcG0AL.js",
			"/assets/SideList-CuOcTkst.js",
			"/assets/tabs-sRaN1zUq.js",
			"/assets/photos-DS6FdkZl.js",
			"/assets/workorders-B0SB58LO.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BXt20rfB.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/popover-SHIchrPv.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-NQcMBejt.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CuOcTkst.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/MoneyAccountPick-D0QcGsqt.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/NewProductDialog-Co8hcFap.js",
			"/assets/PrintFrame-DdqbEiyY.js",
			"/assets/checkbox-BNYLIjzJ.js",
			"/assets/workorders-B0SB58LO.js",
			"/assets/tickets.functions-mcxpsfEL.js",
			"/assets/users.functions-vH_wKpq6.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-Dm1SK24q.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/select-A5nGvzpo.js",
			"/assets/popover-SHIchrPv.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/queries-DiQMynbB.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/SideList-CuOcTkst.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-XyCjIDts.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SearchSelect-CXiFeJr_.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DVChOMWb.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-D3mY9WxU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DNoCnWnH.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/SideList-CuOcTkst.js",
			"/assets/PartyHistory-CaIIzDDL.js",
			"/assets/tabs-sRaN1zUq.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-DlJubXdb.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/sales-BMoxvjWb.js",
			"/assets/footers-D5WPnV5t.js",
			"/assets/tickets.functions-mcxpsfEL.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DWAEpXZx.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/input-y6Yhifz8.js",
			"/assets/skeleton-BdyhWCaK.js",
			"/assets/AdminAccount-BRavQntA.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BhV6j1jx.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-bwN7w-tQ.js",
			"/assets/textarea-QXjER0NZ.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-DVChOMWb.js",
			"/assets/HelpParts-CzdUkwAm.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-B4kpsS6H.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BdyhWCaK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
