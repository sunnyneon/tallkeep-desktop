import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ft as FileText, Gt as CreditCard, I as Receipt, P as RefreshCw, Qt as CircleCheck, Zt as CircleQuestionMark, cn as Camera, d as Upload, gt as Landmark, lt as LoaderCircle, wn as Banknote, yt as Inbox } from "../_libs/lucide-react.mjs";
import { r as matchLoanStatement } from "./loans-IovjuDQY.mjs";
import { a as fileOf, c as skipItem, i as fileAs, l as takeIn, n as addBill, o as loadItems, r as canTake, t as BUCKET, u as takeShoebox } from "./shoebox-KKzplNPr.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as queueScans } from "./scanQueue-C9-xAAQ0.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/shoebox-DIk5RUxy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIND = {
	statement: {
		label: "Statement",
		icon: CreditCard
	},
	receipt: {
		label: "Receipt",
		icon: Receipt
	},
	bill: {
		label: "Bill",
		icon: FileText
	},
	check: {
		label: "Check",
		icon: Banknote
	},
	loan: {
		label: "Loan statement",
		icon: Landmark
	},
	unknown: {
		label: "Not sure yet",
		icon: CircleQuestionMark
	}
};
function ShoeboxPage() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: accounts } = useAccounts();
	const { data: vendors } = useQuery({
		queryKey: ["vendors-lite"],
		queryFn: () => fetchAll("vendors", "id,name")
	});
	const { data: rules } = useQuery({
		queryKey: ["bank-rules"],
		queryFn: () => fetchAll("bank_rules", "id,contains,account_id")
	});
	const { data: items, isLoading } = useQuery({
		queryKey: ["shoebox"],
		queryFn: loadItems
	});
	const [busy, setBusy] = (0, import_react.useState)("");
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [tab, setTab] = (0, import_react.useState)("needs");
	const ready = !!accounts && !!vendors && !!rules;
	const ctx = () => ({
		accounts: accounts ?? [],
		vendors: vendors ?? [],
		rules: rules ?? [],
		step: setBusy
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["shoebox"] });
		qc.invalidateQueries({ queryKey: ["receipts"] });
		qc.invalidateQueries({ queryKey: ["bills"] });
		qc.invalidateQueries({ queryKey: ["bank-txns"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	async function add(files) {
		const ok = files.filter(canTake);
		const bad = files.length - ok.length;
		if (bad) toast.error(`${bad} file${bad === 1 ? "" : "s"} skipped: use PDFs, photos, or bank files (CSV, OFX, QFX, QBO).`);
		if (!ok.length) return;
		let same = 0;
		for (const [i, f] of ok.entries()) {
			setBusy(`${i + 1} of ${ok.length}: ${f.name}…`);
			try {
				if (!await takeIn(f, ctx())) same++;
			} catch (e) {
				toast.error(`${f.name}: ${e.message}`);
			}
			qc.invalidateQueries({ queryKey: ["shoebox"] });
		}
		setBusy("");
		refresh();
		if (same) toast.message(`${same} file${same === 1 ? " was" : "s were"} already in the Shoebox.`);
		setTab("needs");
	}
	const took = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!ready || took.current) return;
		took.current = true;
		const files = takeShoebox();
		if (files.length) add(files);
	}, [ready]);
	const needs = (items ?? []).filter((i) => i.status === "needs_you" || i.status === "failed");
	const working = (items ?? []).filter((i) => i.status === "reading");
	const done = (items ?? []).filter((i) => i.status === "done" || i.status === "skipped");
	const list = tab === "needs" ? [...working, ...needs] : done;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Shoebox",
			text: "Drop bank and card statements, receipts, bills, checks and mortgage or loan statements here, many at once. Tallkeep works out what each one is, puts it where it belongs, and enters what it's sure of. The rest waits here for one click."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onDragOver: (e) => {
				e.preventDefault();
				setDrag(true);
			},
			onDragLeave: (e) => {
				if (!e.currentTarget.contains(e.relatedTarget)) setDrag(false);
			},
			onDrop: (e) => {
				e.preventDefault();
				setDrag(false);
				add([...e.dataTransfer.files]);
			},
			className: cn("flex flex-col items-center gap-3 rounded-2xl border-2 border-dashed p-8 text-center transition", drag ? "border-[var(--section)] bg-[var(--section-soft)]" : "bg-card"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-10 w-10 text-[var(--section)]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold",
					children: busy ? "Working on it…" : "Drop files here"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-lg text-sm text-muted-foreground",
					children: busy || "PDF statements and bills, photos of receipts and checks, or files from your bank's website (CSV, OFX, QFX, QBO). You can also drop files on any Tallkeep page."
				}),
				busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-6 w-6 animate-spin text-muted-foreground" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
							" Choose files",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								multiple: true,
								accept: "image/*,.pdf,application/pdf,.csv,.ofx,.qfx,.qbo",
								className: "hidden",
								disabled: !ready,
								onChange: (e) => {
									add([...e.target.files ?? []]);
									e.target.value = "";
								}
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-4 py-2 text-sm font-medium hover:bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
							" Take a photo",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								capture: "environment",
								className: "hidden",
								disabled: !ready,
								onChange: (e) => {
									add([...e.target.files ?? []]);
									e.target.value = "";
								}
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setTab("needs"),
				className: cn("rounded-full border px-3 py-1.5 text-sm font-medium", tab === "needs" ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card"),
				children: [
					"Needs you (",
					needs.length + working.length,
					")"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setTab("done"),
				className: cn("rounded-full border px-3 py-1.5 text-sm font-medium", tab === "done" ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card"),
				children: [
					"Done (",
					done.length,
					")"
				]
			})]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
		items && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
			children: tab === "needs" ? "Nothing waiting for you. Everything you dropped is in the books or where it belongs." : "Nothing yet."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: list.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemCard, {
				it,
				ctx,
				busy: !!busy,
				setBusy,
				onChanged: refresh,
				onCheck: async () => {
					try {
						queueScans([await fileOf(it)], "check");
						await skipItem(it.id);
						navigate({ to: "/checks-received" });
					} catch (e) {
						toast.error(e.message);
					}
				}
			}, it.id))
		})
	] });
}
function ItemCard({ it, ctx, busy, setBusy, onChanged, onCheck }) {
	const K = KIND[it.kind];
	const { data: accounts } = useAccounts();
	const regs = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card")), [accounts]);
	const spend = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && (a.type === "expense" || a.kind === "fixed_asset" || a.kind === "other_asset")), [accounts]);
	const [acct, setAcct] = (0, import_react.useState)(it.account_id ?? "");
	const [statementPick, setStatementPick] = (0, import_react.useState)(it.kind === "statement");
	const d0 = (it.ai ?? {})["draft"] ?? {};
	const [bill, setBill] = (0, import_react.useState)({
		vendor: d0.vendor ?? "",
		total: d0.total != null ? String(d0.total) : "",
		billDate: d0.billDate ?? "",
		dueDate: d0.dueDate ?? "",
		ref: d0.ref ?? "",
		accountId: d0.accountId ?? ""
	});
	const run = async (what, fn) => {
		setBusy(what);
		try {
			await fn();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
			onChanged();
		}
	};
	const see = async () => {
		if (!it.file_path) return;
		const { data } = await db.storage.from(BUCKET).createSignedUrl(it.file_path, 300);
		if (data?.signedUrl) window.open(data.signedUrl, "_blank", "noopener");
	};
	const status = it.status === "reading" ? {
		text: "Reading…",
		cls: "bg-sky-100 text-sky-900"
	} : it.status === "done" ? {
		text: "Done",
		cls: "bg-emerald-100 text-emerald-900"
	} : it.status === "skipped" ? {
		text: "Skipped",
		cls: "bg-muted text-muted-foreground"
	} : it.status === "failed" ? {
		text: "Didn't work",
		cls: "bg-red-100 text-red-900"
	} : {
		text: "Needs you",
		cls: "bg-amber-100 text-amber-900"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(K.icon, { className: "mt-0.5 h-5 w-5 shrink-0 text-[var(--section)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: it.file_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("rounded px-1.5 py-0.5 text-xs font-medium", status.cls),
									children: status.text
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										K.label,
										" · ",
										fmtDateTime(it.created_at)
									]
								})
							]
						}),
						it.summary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: it.summary
						}),
						it.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-destructive",
							children: it.error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex flex-wrap gap-3 text-sm",
							children: [
								it.file_path && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "text-primary underline",
									onClick: () => void see(),
									children: "See the file"
								}),
								it.target_type === "receipt" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/receipts",
									className: "text-primary underline",
									children: "Open Receipts"
								}),
								it.target_type === "bill" && it.target_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/bills/$id",
									params: { id: it.target_id },
									search: {},
									className: "text-primary underline",
									children: "Open the bill"
								}),
								it.target_type === "bank_import" && it.account_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/banking",
									search: { account: it.account_id },
									className: "text-primary underline",
									children: "Open Bank Feeds"
								})
							]
						})
					]
				})]
			}),
			(it.status === "needs_you" || it.status === "failed") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 border-t pt-3",
				children: [
					statementPick && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							"aria-label": "Account",
							className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
							value: acct,
							onChange: (e) => setAcct(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Which bank or card account?"
							}), regs.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: a.id,
								children: accountLabel(a)
							}, a.id))]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							disabled: busy || !acct,
							onClick: () => void run(`${it.file_name}: bringing in the lines…`, () => fileAs(it, "statement", ctx(), acct)),
							children: "Bring in the lines"
						})]
					}),
					it.kind === "bill" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "From (vendor)",
								list: "shoebox-vendors",
								value: bill.vendor,
								onChange: (e) => setBill({
									...bill,
									vendor: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "shoebox-vendors",
								children: ctx().vendors.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: v.name }, v.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Amount due",
								inputMode: "decimal",
								value: bill.total,
								onChange: (e) => setBill({
									...bill,
									total: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Bill number",
								value: bill.ref,
								onChange: (e) => setBill({
									...bill,
									ref: e.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["Bill date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: bill.billDate,
									onChange: (e) => setBill({
										...bill,
										billDate: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["Due date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: bill.dueDate,
									onChange: (e) => setBill({
										...bill,
										dueDate: e.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-xs text-muted-foreground",
								children: ["What it's for", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-10 w-full rounded-md border bg-background px-2 text-sm text-foreground",
									value: bill.accountId,
									onChange: (e) => setBill({
										...bill,
										accountId: e.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Choose an account…"
									}), spend.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: a.id,
										children: accountLabel(a)
									}, a.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									disabled: busy,
									onClick: () => void run("Adding the bill…", () => addBill(it.id, {
										vendor: bill.vendor,
										total: Number(bill.total.replace(/[$,\s]/g, "")) || null,
										billDate: bill.billDate || null,
										dueDate: bill.dueDate || null,
										ref: bill.ref || null,
										accountId: bill.accountId || null
									}, ctx())),
									children: "Add the bill"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							it.kind === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								disabled: busy,
								onClick: onCheck,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banknote, { className: "h-4 w-4" }), " Open in Checks Received"]
							}),
							it.kind !== "bill" && it.kind !== "check" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a receipt…`, () => fileAs(it, "receipt", ctx())),
								children: "It's a receipt (already paid)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a bill…`, () => fileAs(it, "bill", ctx())),
								children: "It's a bill (to pay)"
							})] }),
							!statementPick && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => setStatementPick(true),
								children: "It's a bank or card statement"
							}),
							it.kind !== "loan" && it.kind !== "check" && !/^text\//.test(it.mime ?? "") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: reading it as a loan statement…`, () => fileAs(it, "loan", ctx())),
								children: "It's a loan or mortgage statement"
							}),
							it.kind !== "check" && it.kind !== "statement" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: onCheck,
								children: "It's a check from a customer"
							}),
							(it.status === "failed" || it.kind === "unknown" && !!it.error) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: busy,
								onClick: () => void run(`${it.file_name}: trying again…`, async () => {
									const f = await fileOf(it);
									await db.from("shoebox_items").delete().eq("id", it.id);
									await takeIn(f, ctx());
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), " Try again"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "ghost",
								disabled: busy,
								onClick: () => void run("", () => skipItem(it.id)),
								children: "Skip (leave it out of the books)"
							})
						]
					})
				]
			}),
			it.status === "done" && it.kind === "loan" && it.target_id && it.ai?.["loan_differs"] != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					disabled: busy,
					onClick: () => void run(`${it.file_name}: matching the statement…`, async () => {
						await matchLoanStatement(it.id, it.target_id);
						toast.success("The loan's balance now matches the statement.");
					}),
					children: "Make the books match the statement"
				})
			}),
			it.status === "done" && it.kind !== "unknown" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-300",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-3.5 w-3.5" }), " Filed."]
			})
		]
	});
}
//#endregion
export { ShoeboxPage as component };
