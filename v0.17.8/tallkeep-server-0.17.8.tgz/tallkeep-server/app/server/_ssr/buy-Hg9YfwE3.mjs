import { t as cn } from "./utils-C_uf36nf.mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as EDITION_KEYS, n as ADDON_KEYS } from "./editions-Fg8o4E4M.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy-Hg9YfwE3.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./buy-pE0n31AJ.mjs");
/** Buy Tallkeep: pick a plan and add-ons, or upgrade a license. Pay with Stripe; the key comes by email. */
var Route = createFileRoute("/buy")({
	ssr: false,
	validateSearch: (s) => ({
		...typeof s["code"] === "string" ? { code: s["code"] } : {},
		...EDITION_KEYS.includes(s["plan"]) ? { plan: s["plan"] } : {},
		...ADDON_KEYS.includes(s["addon"]) ? { addon: s["addon"] } : {},
		...s["upgrade"] ? { upgrade: true } : {}
	}),
	head: () => ({ meta: [{ title: "Buy Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function BuyFrame({ children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("mx-auto space-y-6", wide ? "max-w-3xl" : "max-w-xl"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "https://tallkeep.com",
				className: "inline-block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-light.svg",
					alt: "Tallkeep",
					className: "h-9 dark:hidden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-dark.svg",
					alt: "Tallkeep",
					className: "hidden h-9 dark:block"
				})]
			}), children]
		})
	});
}
//#endregion
export { Route as n, BuyFrame as t };
