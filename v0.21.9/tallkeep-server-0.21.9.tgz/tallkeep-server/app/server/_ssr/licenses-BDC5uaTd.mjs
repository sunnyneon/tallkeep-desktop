import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-H-rYYOp-.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { _t as KeyRound, at as Mail, qt as Copy } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as EDITION_KEYS, n as ADDON_KEYS, r as EDITIONS, t as ADDONS_FOR_SALE } from "./editions-CIhnK_Ff.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/licenses-BDC5uaTd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Tallkeep Desktop license keys (owner panel only).
*
* A key is "TK1.<payload>.<signature>": the payload says who it's for and what it covers, signed
* with our private key (the LICENSE_PRIVATE_KEY secret). Tallkeep Desktop checks it with the
* matching public key (desktop/server/lib/license.mjs), with no internet needed.
*/
var makeLicenseKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!String(d.to ?? "").trim()) throw new Error("Type the business name.");
	const n = (v) => v == null || v === "" ? null : Number(v);
	const companies = n(d.companies);
	const users = n(d.users);
	if (companies != null && !(Number.isInteger(companies) && companies > 0)) throw new Error("Companies: a whole number, or empty for any number.");
	if (users != null && !(Number.isInteger(users) && users > 0)) throw new Error("People: a whole number, or empty for any number.");
	if (d.updatesUntil && !/^\d{4}-\d{2}-\d{2}$/.test(d.updatesUntil)) throw new Error("Pick the date updates end.");
	const computers = n(d.computers) ?? 1;
	if (!(Number.isInteger(computers) && computers > 0)) throw new Error("Computers: at least 1.");
	return {
		...d,
		to: d.to.trim(),
		companies,
		users,
		computers
	};
}).handler(createSsrRpc("5e3f2155d8f79d4f9c40c121fe96e1948d07bb54af205475ce054a65585c1bfd"));
var listLicenseKeys = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("85f1fef7a0411d309d5893fece878801f90949dbde3de658a2916053fd00a251"));
/** Switch a key off (refund, leaked) or back on. Office computers notice within a day. */
var setLicenseOn = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("43ed8732e31f6b7059578c4384ff3dc669315e2dcbc0ceef914318206731cc1b"));
/** Free a computer's place (the customer replaced their office computer). */
var releaseComputer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("487a6c1ba9a7b71ab5ed23fb488dba33912c2df9640f2ac290d7ad153199a3a7"));
/** Record a key made outside this panel (checked: it must carry our signature). */
var addExistingKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("c3cb615a6833d9c11d076131e61d553f76bf27f094f99d46dcd824156aa301fa"));
/** Email a license key to its customer again (with a copy to Tallkeep). */
var emailLicenseKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("a3cdd7c9324ad5eab526048b501809bed2b6d4ed00f1862b877dbd2ec9fe2fba"));
var inAYear = () => {
	const d = /* @__PURE__ */ new Date();
	d.setFullYear(d.getFullYear() + 1);
	return d.toLocaleDateString("en-CA");
};
var copy = (text, what) => {
	copyText(text);
	toast.success(`${what} copied.`);
};
var many = (n, one, more) => n == null ? `any number of ${more}` : `${n} ${n === 1 ? one : more}`;
function LicensesPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["admin-licenses"],
		queryFn: () => listLicenseKeys()
	});
	const [f, setF] = (0, import_react.useState)({
		to: "",
		email: "",
		companies: "1",
		users: "3",
		computers: "1",
		updatesUntil: inAYear(),
		notes: "",
		edition: "full",
		addons: []
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [made, setMade] = (0, import_react.useState)(null);
	const set = (k) => (e) => setF({
		...f,
		[k]: e.target.value
	});
	async function make(e) {
		e.preventDefault();
		setBusy(true);
		try {
			const r = await makeLicenseKey({ data: {
				to: f.to,
				email: f.email,
				companies: f.companies ? Number(f.companies) : null,
				users: f.users ? Number(f.users) : null,
				computers: f.computers ? Number(f.computers) : 1,
				updatesUntil: f.updatesUntil || null,
				notes: f.notes,
				edition: f.edition || null,
				addons: f.addons
			} });
			setMade({
				...r,
				to: f.to
			});
			setF({
				...f,
				to: "",
				email: "",
				notes: ""
			});
			qc.invalidateQueries({ queryKey: ["admin-licenses"] });
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Desktop licenses",
			text: "Make a license key for a Tallkeep Desktop customer. They paste it in Settings → Plan & computer. Empty companies or people means any number."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: make,
			className: "grid gap-3 rounded-2xl border bg-card p-4 sm:grid-cols-2 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Business name (shows on the license)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: f.to,
						onChange: set("to")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Their email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						value: f.email,
						onChange: set("email")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Plan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						value: f.edition,
						onChange: (e) => {
							const ed = e.target.value;
							setF({
								...f,
								edition: ed,
								...ed ? {
									companies: String(EDITIONS[ed].companies + f.addons.reduce((s, a) => s + ADDONS_FOR_SALE[a].companies, 0)),
									users: String(EDITIONS[ed].users)
								} : {}
							});
						},
						children: [EDITION_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: EDITIONS[k].label
						}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Everything (like before plans)"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Add-ons"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-4 pt-1.5",
						children: ADDON_KEYS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: f.addons.includes(a),
								onChange: (e) => setF({
									...f,
									addons: e.target.checked ? [...f.addons, a] : f.addons.filter((x) => x !== a)
								})
							}), ADDONS_FOR_SALE[a].label]
						}, a))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Companies"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						value: f.companies,
						onChange: set("companies")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "People (users)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						value: f.users,
						onChange: set("users")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Office computers it can run on"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						value: f.computers,
						onChange: set("computers")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Updates included until"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: f.updatesUntil,
						onChange: set("updatesUntil")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Notes (only you see these)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.notes,
						onChange: set("notes"),
						placeholder: "Paid $799 on Jan 5, invoice 1042"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-4 w-4" }),
							" ",
							busy ? "Making…" : "Make the license key"
						]
					})
				})
			]
		}),
		made && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-2xl border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-950 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: [
						"License ",
						made.id,
						" for ",
						made.to,
						" is ready. Send them this key:"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all rounded-lg bg-white p-2 font-mono text-xs dark:bg-black/30",
					children: made.key
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => copy(made.key, "License key"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy the key"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddExisting, { onDone: () => void qc.invalidateQueries({ queryKey: ["admin-licenses"] }) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [
				q.isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-24" }),
				q.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-destructive",
					children: q.error.message
				}),
				q.data?.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-muted-foreground",
					children: "No license keys made yet."
				}),
				(q.data ?? []).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseLine, {
					l,
					onChanged: () => void qc.invalidateQueries({ queryKey: ["admin-licenses"] })
				}, l.id))
			]
		})
	] });
}
function LicenseLine({ l, onChanged }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const run = async (p, msg) => {
		setBusy(true);
		try {
			await p;
			toast.success(msg);
			onChanged();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const live = l.activations.filter((a) => !a.released_at);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							l.to_name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: ["· ", l.id]
							}),
							l.revoked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 rounded-full bg-red-100 px-2 py-0.5 text-xs text-red-800 dark:bg-red-950 dark:text-red-200",
								children: "Switched off"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							l.edition && EDITIONS[l.edition] ? `${EDITIONS[l.edition].label}${(l.addons ?? []).length ? ` + ${(l.addons ?? []).map((a) => ADDONS_FOR_SALE[a]?.label ?? a).join(" + ")}` : ""} · ` : "Everything · ",
							many(l.companies, "company", "companies"),
							", ",
							many(l.users, "person", "people"),
							",",
							" ",
							l.computers,
							" office computer",
							l.computers === 1 ? "" : "s",
							l.updates_until ? ` · updates until ${fmtDate(l.updates_until)}` : "",
							" · made",
							" ",
							fmtDate(l.created_at),
							l.email ? ` · ${l.email}` : "",
							l.notes ? ` · ${l.notes}` : ""
						]
					})]
				}),
				l.email && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: async () => {
						try {
							const r = await emailLicenseKey({ data: { id: l.id } });
							toast.success(`Key emailed to ${r.to}.`);
						} catch (e) {
							toast.error(e.message);
						}
						onChanged();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email the key"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => copy(l.license_key, "License key"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy key"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: l.revoked ? "outline" : "ghost",
					disabled: busy,
					onClick: () => {
						if (!l.revoked && !window.confirm(`Switch off ${l.id} for ${l.to_name}? Within a day their Tallkeep says the license isn't valid and their books become read-only.`)) return;
						run(setLicenseOn({ data: {
							id: l.id,
							on: l.revoked
						} }), l.revoked ? "License switched back on." : "License switched off.");
					},
					children: l.revoked ? "Switch back on" : "Switch off"
				})
			]
		}), live.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1 rounded-lg bg-muted/40 px-3 py-2 text-xs",
			children: live.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: a.machine_name ?? "A computer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							"last checked ",
							fmtDate(a.last_seen),
							a.app_version ? ` · Tallkeep ${a.app_version}` : "",
							" · since",
							" ",
							fmtDate(a.first_seen)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						className: "ml-auto underline",
						onClick: () => void run(releaseComputer({ data: { id: a.id } }), "Computer released: the key can be used on another computer now."),
						children: "Release this computer"
					})
				]
			}, a.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Not used on any computer yet."
		})]
	});
}
/** Keys made outside this panel (like the owner's own): record them so office computers accept them. */
function AddExisting({ onDone }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "rounded-2xl border bg-card p-4 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "cursor-pointer font-medium",
			children: "Add a key made outside this page"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 space-y-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Office computers only accept keys listed here. Paste a key Tallkeep made somewhere else (like your own) to list it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 3,
					value: key,
					onChange: (e) => setKey(e.target.value),
					className: "w-full rounded-md border bg-background p-2 font-mono text-xs",
					placeholder: "TK1.…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					disabled: busy || !key.trim(),
					onClick: async () => {
						setBusy(true);
						try {
							const r = await addExistingKey({ data: { key } });
							toast.success(`License ${r.id} listed.`);
							setKey("");
							onDone();
						} catch (e) {
							toast.error(e.message);
						} finally {
							setBusy(false);
						}
					},
					children: "List this key"
				})
			]
		})]
	});
}
//#endregion
export { LicensesPage as component };
