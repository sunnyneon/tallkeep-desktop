import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales._id-DV2epT_A.js
var $$splitComponentImporter = () => import("./sales._id-Ej-Og16c.mjs");
var Route = createFileRoute("/_authenticated/sales/$id")({
	validateSearch: (s) => {
		const out = {};
		if (s["kind"] === "quote" || s["kind"] === "order" || s["kind"] === "rma") out.kind = s["kind"];
		if (typeof s["customer"] === "string") out.customer = s["customer"];
		if (typeof s["product"] === "string") out.product = s["product"];
		if (s["followup"] != null) out.followup = s["followup"] === "pay" ? "pay" : "1";
		if (s["paid"]) out.paid = 1;
		if (typeof s["ticket"] === "string") out.ticket = s["ticket"];
		return out;
	},
	head: () => ({ meta: [{ title: "Quote / Invoice · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
