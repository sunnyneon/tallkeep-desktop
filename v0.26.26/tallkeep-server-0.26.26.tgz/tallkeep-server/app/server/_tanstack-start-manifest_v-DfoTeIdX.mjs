//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DfoTeIdX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BNCsCadC.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-_gLPQvcD.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CS4_7rg8.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BNCsCadC.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DGRPInfr.js",
			"/assets/log-out-BL-3wlgH.js",
			"/assets/testers.functions-DyqAZeXU.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CzFWKVQD.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Cbujj3jt.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-C5E94cmj.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-C7QUIL0S.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/dist-DEbOMHt2.js",
			"/assets/dialog-DflxVs3o.js",
			"/assets/queries-Bvu6cStN.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/label-D3WbQ41w.js",
			"/assets/textarea-NYMQ1qNO.js",
			"/assets/shoebox-BRAvd5k_.js",
			"/assets/company-Dt9aO3YA.js",
			"/assets/reports-BoE9jZLZ.js",
			"/assets/access-DQkr2CPu.js",
			"/assets/LicenseCard-D3vXt5li.js",
			"/assets/Logo-DJ4gbAmm.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Cd8mMonO.js",
			"/assets/log-out-BL-3wlgH.js",
			"/assets/admin.functions-Cj1aUitJ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DJ4gbAmm.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CgQKqU0L.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/label-D3WbQ41w.js",
			"/assets/Logo-DJ4gbAmm.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DOmZ4dWn.js",
			"/assets/testers.functions-DyqAZeXU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/coupons.functions-CSAx3FHg.js",
			"/assets/buy.functions-DOXgrX_W.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DerxgreL.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/downloads.functions-Ci1_yGm6.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BefWJnhv.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/label-D3WbQ41w.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BuUfI7B9.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/label-D3WbQ41w.js",
			"/assets/Logo-DJ4gbAmm.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-uACgK-xg.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/upgrade.functions-LlhLLkNF.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-C9EnDCt6.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/label-D3WbQ41w.js",
			"/assets/Logo-DJ4gbAmm.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-D3BM88pN.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-L-ABJeO4.js", "/assets/StockDocList-BmGpG6Av.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CvvTtunm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/ai-DgmnQXE_.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BVLSwESW.js",
			"/assets/BankConnections-M51KdI5O.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-Clve_5eW.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BPhSmkXw.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-M51KdI5O.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/ai-DgmnQXE_.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-qrHkx3q8.js",
			"/assets/TxnEditor-COz8HdOr.js",
			"/assets/feedWaiting-DXAdlDOg.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DDkAJCcO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-D_oCsmAy.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/personal-DPn6On6B.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/WhoPicker-DFfudX7i.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CRvNNYFS.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-Cuk9VoHL.js", "/assets/AccountRegister-B_9omon2.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BB0FqFHv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-B-QMDh1K.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/money-DhoEu3YR.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DIMfkGOj.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DgmnQXE_.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DgxKk_AA.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-BbwO2RM1.js", "/assets/StockDocList-BmGpG6Av.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D9NqGZbI.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-Bg2O110h.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CetVHeB9.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-B3m5yzLd.js", "/assets/PartyList-DQlp1Zik.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Dby1BfTW.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-B300S6p0.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/storage.functions-2A5tp2oN.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-DlBuV37W.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-B5vju6Gh.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-D0rH6rIu.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-UMW3-TuT.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BR9FTT0p.js", "/assets/ChangeHistory-Dyjt8UVs.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BqJxjzh_.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/members-Ckh0G07U.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DOQ3puHB.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/personal-DPn6On6B.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/WhoPicker-DFfudX7i.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BklIvRdp.js", "/assets/SalesList-BnU6XKb7.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-SrqYOV4V.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-ChLGX6hU.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DAh_udZ0.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-FS1BECkP.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/loans-qrHkx3q8.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-ChikeXsE.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-q5pN5eHn.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-C8CIdXaX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/personal-DPn6On6B.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/WhoPicker-DFfudX7i.js",
			"/assets/reminders-v8fVoEak.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-hufIRp7h.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CRnJzy0n.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/personal-DPn6On6B.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/WhoPicker-DFfudX7i.js",
			"/assets/generateCategoricalChart-BeCDaJNl.js",
			"/assets/Area-DKdk0G8W.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-4pYhEVRM.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/generateCategoricalChart-BeCDaJNl.js",
			"/assets/PlCharts-D0rH6rIu.js",
			"/assets/BarChart-DBni_8o3.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BWIsXUqx.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CHeVUdv_.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DaOTI6jE.js",
			"/assets/createServerFn-DihzJb65.js",
			"/assets/auth-middleware-D1xOFX_0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/storage.functions-2A5tp2oN.js",
			"/assets/coupons.functions-CSAx3FHg.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BsiMEP8O.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BoOwkzKb.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/checkbox-CPvXXOxl.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-tbwOb9zP.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-BadFds9z.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-UAaoZTUu.js", "/assets/SalesList-BnU6XKb7.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-Cr4t_q_c.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/ai-DgmnQXE_.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-2A5tp2oN.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-UVRCPJot.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/money-DhoEu3YR.js",
			"/assets/badge-Cl3SjUz9.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Cofjbyvg.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-uKLSB1J0.js", "/assets/AccountRegister-B_9omon2.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-saVg1Gfh.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/MoneyAccountPick-hipOUBD1.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-Dw_PqymZ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-grPA7oAd.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/RepeatInvoice-D7Jzm8us.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BwpbCpSu.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-BeCDaJNl.js",
			"/assets/BarChart-DBni_8o3.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-Dz3Uamv4.js", "/assets/SalesList-BnU6XKb7.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-HB0-5t9s.js", "/assets/SalesList-BnU6XKb7.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CjdJ-1vk.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-G_ut0Nlt.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/serials-aGNjdLLw.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DbI810QT.js",
			"/assets/createServerFn-DihzJb65.js",
			"/assets/auth-middleware-D1xOFX_0.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/emailWording-B6XyhS26.js",
			"/assets/scan-barcode-i-o7I6qZ.js",
			"/assets/send-BwSadvej.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-BuAfANdh.js",
			"/assets/switch-q5pN5eHn.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/bankfeed.functions-CLR8OclF.js",
			"/assets/QuickBooksImport-CetVHeB9.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-BYJ7pZVJ.js",
			"/assets/footers-CrpNDZrN.js",
			"/assets/PrintFrame-CQtL1CY3.js",
			"/assets/checkbox-CPvXXOxl.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-BUOR3lIj.js",
			"/assets/FeaturePicker-CD4ffH8o.js",
			"/assets/support-B71ZgzZu.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-Bwv46ZvC.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/FeaturePicker-CD4ffH8o.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-Be4dByaA.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CH5Mxvbd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/photos-BYJ7pZVJ.js",
			"/assets/stockmove-CEU6pgW1.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-ytYoWZvY.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/loans-qrHkx3q8.js",
			"/assets/feedWaiting-DXAdlDOg.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-2A5tp2oN.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-C2K9EKbx.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/PrintFrame-CQtL1CY3.js",
			"/assets/DocPdf-DsBF5RpM.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-BaMjIKmy.js",
			"/assets/createServerFn-DihzJb65.js",
			"/assets/auth-middleware-D1xOFX_0.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/MoneyAccountPick-hipOUBD1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B71ZgzZu.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BxmoksG9.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/StockDialogs-CH5Mxvbd.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/stockmove-CEU6pgW1.js",
			"/assets/checkbox-CPvXXOxl.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DDxWPREo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/members-Ckh0G07U.js",
			"/assets/WhoPicker-DFfudX7i.js",
			"/assets/reminders-v8fVoEak.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CO8D7lyQ.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/tickets.functions-DMPnqHyZ.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-D2bKgouP.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B71ZgzZu.js",
			"/assets/support.functions-C_ZsAATz.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-Cj8cOcWW.js", "/assets/StockDocList-BmGpG6Av.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-BgwEyNmC.js", "/assets/PartyList-DQlp1Zik.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-D111_xib.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/tickets.functions-DMPnqHyZ.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CgGbW-5h.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/workorders-B2-x1qmy.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BGKLC-IC.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-ZVMESa-b.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/coupons.functions-CSAx3FHg.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CRg2Sy3n.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/AdminAccount-DSa2NmMp.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BKIFAZt3.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/downloads.functions-Ci1_yGm6.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-9QpX6kZq.js",
			"/assets/createServerFn-DihzJb65.js",
			"/assets/auth-middleware-D1xOFX_0.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DsxymIwz.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-7N2b6tVu.js",
			"/assets/testers.functions-DyqAZeXU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-BP96PJD-.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-zfRgLE38.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DOXgrX_W.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DOo76AGw.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/textarea-NYMQ1qNO.js",
			"/assets/support.functions-C_ZsAATz.js",
			"/assets/HelpParts-DnxyFe8x.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BX6pOQnr.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DciJKRc_.js",
			"/assets/manual._slug-DfsvBofJ.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-BscVP47C.js",
			"/assets/createServerFn-DihzJb65.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CjMiCJUa.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-LlhLLkNF.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Dpz9MxT6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DgmnQXE_.js",
			"/assets/personal-DPn6On6B.js",
			"/assets/reminders-v8fVoEak.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BznzWavp.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/AdminAccount-DSa2NmMp.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DjqjE5ee.js", "/assets/ManualFrame-DciJKRc_.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CoTENPKf.js", "/assets/AccountRegister-B_9omon2.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-b4auSD_L.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/OriginalLink-FQGASwzV.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/realestate-U1hEmGFt.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C7GOR1up.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-PTeoakek.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/realestate-U1hEmGFt.js",
			"/assets/money-DhoEu3YR.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-Bu_g6odr.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/SideList-Q0p2NUf_.js",
			"/assets/PartyHistory-B1YZgUQt.js",
			"/assets/tabs-lLjSv17G.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DSwuudCM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-B6XyhS26.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Dyjt8UVs.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/SideList-Q0p2NUf_.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-CyteWGb9.js",
			"/assets/MoneyAccountPick-hipOUBD1.js",
			"/assets/footers-CrpNDZrN.js",
			"/assets/PrintFrame-CQtL1CY3.js",
			"/assets/serials-aGNjdLLw.js",
			"/assets/SerialsBox-DCmxEgCn.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BnOlEBBd.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CH5Mxvbd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Dyjt8UVs.js",
			"/assets/switch-q5pN5eHn.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-Cl3SjUz9.js",
			"/assets/SideList-Q0p2NUf_.js",
			"/assets/tabs-lLjSv17G.js",
			"/assets/photos-BYJ7pZVJ.js",
			"/assets/stockmove-CEU6pgW1.js",
			"/assets/serials-aGNjdLLw.js",
			"/assets/SerialsBox-DCmxEgCn.js",
			"/assets/workorders-B2-x1qmy.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DBKgbkt0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-B6XyhS26.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Dyjt8UVs.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/SideList-Q0p2NUf_.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-CyteWGb9.js",
			"/assets/MoneyAccountPick-hipOUBD1.js",
			"/assets/footers-CrpNDZrN.js",
			"/assets/PrintFrame-CQtL1CY3.js",
			"/assets/checkbox-CPvXXOxl.js",
			"/assets/serials-aGNjdLLw.js",
			"/assets/workorders-B2-x1qmy.js",
			"/assets/RepeatInvoice-D7Jzm8us.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DMPnqHyZ.js",
			"/assets/users.functions-BUOR3lIj.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-hThFIpB-.js",
			"/assets/select-Cdtk_ZCm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/SideList-Q0p2NUf_.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CtYrIwlS.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/quickadd-Cra30Uqg.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-B71ZgzZu.js",
			"/assets/support.functions-C_ZsAATz.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-p1My9aEf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-cY4VE7hR.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/SideList-Q0p2NUf_.js",
			"/assets/PartyHistory-B1YZgUQt.js",
			"/assets/tabs-lLjSv17G.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CK28bMjt.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/sales-DgxKk_AA.js",
			"/assets/footers-CrpNDZrN.js",
			"/assets/tickets.functions-DMPnqHyZ.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DbIs3wGa.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/input-DtAdGWbJ.js",
			"/assets/skeleton-DeGmUA-d.js",
			"/assets/AdminAccount-DSa2NmMp.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BvSb_7Hw.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-Bqg4fwes.js",
			"/assets/textarea-NYMQ1qNO.js",
			"/assets/support-B71ZgzZu.js",
			"/assets/support.functions-C_ZsAATz.js",
			"/assets/HelpParts-DnxyFe8x.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CGb3dlaH.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DeGmUA-d.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
