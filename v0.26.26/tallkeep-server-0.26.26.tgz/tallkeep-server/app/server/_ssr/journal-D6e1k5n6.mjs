import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/journal-D6e1k5n6.js
var $$splitComponentImporter = () => import("./journal-B25cFFEy.mjs");
var Route = createFileRoute("/_authenticated/journal")({
	validateSearch: (s) => s["opening"] ? { opening: 1 } : s["adjust"] ? { adjust: 1 } : {},
	head: () => ({ meta: [{ title: "Journal Entries · Tallkeep" }, {
		name: "description",
		content: "Every entry in the books, and entries typed by hand."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
