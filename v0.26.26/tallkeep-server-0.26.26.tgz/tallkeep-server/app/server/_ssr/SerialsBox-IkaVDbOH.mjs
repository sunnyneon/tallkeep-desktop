import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { i as WandSparkles } from "../_libs/lucide-react.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as parseSerials, i as makeSerials } from "./serials-BobbzlbM.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/SerialsBox-IkaVDbOH.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Serial numbers for units coming in: type or scan one per line, or let Tallkeep make them.
* `count` is how many units; the box says how many are still missing.
*/
function SerialsBox({ count, value, onChange }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const have = parseSerials(value).length;
	const missing = Math.max(Math.floor(count) - have, 0);
	async function make() {
		setBusy(true);
		try {
			const made = await makeSerials(missing);
			onChange([...parseSerials(value), ...made].join("\n"));
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			rows: Math.min(Math.max(Math.floor(count), 2), 6),
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder: "Type or scan the serial numbers, one per line",
			className: "font-mono text-xs"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2 text-xs",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: have === Math.floor(count) ? "text-emerald-700 dark:text-emerald-400" : have > count ? "text-amber-700 dark:text-amber-400" : "text-muted-foreground",
				children: [
					have,
					" of ",
					Math.floor(count),
					" serial numbers",
					have > count ? " (more than the units)" : ""
				]
			}), missing > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "outline",
				className: "h-7",
				onClick: () => void make(),
				disabled: busy,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "h-3.5 w-3.5" }), busy ? "Making…" : `Make ${missing === Math.floor(count) ? "them" : `the other ${missing}`} for me`]
			})]
		})]
	});
}
//#endregion
export { SerialsBox as t };
