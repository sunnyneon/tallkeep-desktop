import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C9I0PyVu.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { P as RefreshCw, lt as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/DockerUpdatesCard-Bd7W8GNY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useMyAccount() {
	return useQuery({
		queryKey: ["my-account"],
		staleTime: 6e5,
		queryFn: async () => {
			const { data, error } = await db.from("orgs").select("*").maybeSingle();
			if (error) return null;
			return data ?? null;
		}
	});
}
/** Whole days left in the free trial (0 when it has ended). */
var trialDaysLeft = (a) => a?.status === "trial" && a.trial_ends_at ? Math.max(0, Math.ceil((Date.parse(a.trial_ends_at) - Date.now()) / 864e5)) : null;
/** Can this account still add and change things? (Same rule as the database.) */
var canWrite = (a) => !a || a.is_platform && a.edition !== "desktop" || a.status === "active" || a.status === "past_due" || a.status === "trial" && (!a.trial_ends_at || Date.parse(a.trial_ends_at) > Date.now());
/** Where people choose or change their plan. */
var PLANS_URL = "https://tallkeep.com/pricing";
var bridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
function useUpdateStatus() {
	const [st, setSt] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const b = bridge();
		if (!b.updateStatus) return;
		const read = () => void b.updateStatus().then(setSt).catch(() => {});
		read();
		const t = setInterval(read, 6e4);
		window.addEventListener("focus", read);
		return () => {
			clearInterval(t);
			window.removeEventListener("focus", read);
		};
	}, []);
	return [st, setSt];
}
async function installUpdate() {
	const r = await bridge().installUpdate?.();
	if (r && !r.ok && !r.canceled) toast.error(r.error ?? "The update didn't start.");
}
/** Settings → Plan & computer: the version here, and checking for a new one. */
function UpdatesCard() {
	const [st, setSt] = useUpdateStatus();
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!st) return null;
	const dl = st.downloading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: st.officeComputer ? "Update Tallkeep" : "Update the Tallkeep app on this computer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"This computer has Tallkeep ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.current }),
					".",
					" ",
					st.officeComputer ? "It looks for a new version every few hours and downloads it by itself; you choose when to install it." : "It follows the office computer: when that one is updated, this one offers the same update."
				]
			}),
			dl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
					" Downloading ",
					dl.version,
					dl.size ? ` (${Math.round(dl.got / dl.size * 100)}%)` : "…"
				]
			}),
			st.renew && !st.ready && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: [
					"Tallkeep ",
					st.renew.version,
					" is out. Your license includes updates until",
					" ",
					(/* @__PURE__ */ new Date(`${st.renew.until}T12:00:00`)).toLocaleDateString(),
					", so this computer keeps the version it has.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://app.tallkeep.com/upgrade",
						target: "_blank",
						rel: "noreferrer",
						className: "underline",
						children: "Renew updates"
					}),
					" ",
					"to get it."
				]
			}),
			st.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [
						"Tallkeep ",
						st.ready.version,
						" is ready.",
						st.ready.notes ? ` ${sentence(st.ready.notes)}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void installUpdate(),
					children: "Update now"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				disabled: busy || st.checking || !!dl,
				onClick: async () => {
					setBusy(true);
					try {
						const r = await bridge().checkUpdate();
						setSt(r);
						if (r.error) toast.error(`Couldn't check: ${r.error}`);
						else if (!r.ready) toast.success("You have the newest Tallkeep.");
					} finally {
						setBusy(false);
					}
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: busy ? "h-4 w-4 animate-spin" : "h-4 w-4" }), busy ? "Checking…" : "Check for updates"]
			}),
			st.error && !busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["Last check didn't work: ", st.error]
			})
		]
	});
}
/** Release notes as a sentence (ends with a period). */
var sentence = (t) => /[.!?]$/.test(t.trim()) ? t.trim() : `${t.trim()}.`;
/** Updates for Tallkeep in Docker (no Tallkeep window): what's new, and Update now. */
async function post(body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch("/tallkeep/self-update", {
		method: "POST",
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
/** Waits for Tallkeep to come back after an update, then reloads the page. */
function waitAndReload() {
	const started = Date.now();
	const tick = async () => {
		try {
			if ((await fetch("/tallkeep/health", { cache: "no-store" })).ok && Date.now() - started > 8e3) return window.location.reload();
		} catch {}
		if (Date.now() - started < 6e5) setTimeout(() => void tick(), 3e3);
	};
	setTimeout(() => void tick(), 5e3);
}
function DockerUpdatesCard() {
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [updating, setUpdating] = (0, import_react.useState)(false);
	const { data: st } = useQuery({
		queryKey: ["docker-updates"],
		queryFn: async () => {
			const r = await fetch("/tallkeep/self-update");
			return r.ok ? await r.json() : null;
		}
	});
	if (!st) return null;
	const check = async () => {
		setBusy(true);
		try {
			const r = await post({ check: true });
			qc.setQueryData(["docker-updates"], r);
			if (r.error) toast.error(`Couldn't check: ${r.error}`);
			else if (!r.latest) toast.success("You have the newest Tallkeep.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const update = async () => {
		setUpdating(true);
		try {
			await post({});
			waitAndReload();
		} catch (e) {
			toast.error(e.message);
			setUpdating(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Update the server (where the books are)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"The server that keeps everyone's books has Tallkeep ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.current ?? "?" }),
					". It looks for a new version every few hours; you choose when to install it. Update the server first, then each computer's app."
				]
			}),
			updating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: "Updating… Tallkeep saves a backup of the books, closes for a minute or two and opens again. This page reloads by itself."
			}) : st.renew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: [
					"Tallkeep ",
					st.renew.version,
					" is out. Your license includes updates until",
					" ",
					(/* @__PURE__ */ new Date(`${st.renew.until}T12:00:00`)).toLocaleDateString(),
					", so this server keeps the version it has.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://app.tallkeep.com/upgrade",
						target: "_blank",
						rel: "noreferrer",
						className: "underline",
						children: "Renew updates"
					}),
					" ",
					"to get it."
				]
			}) : st.latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [
						"Tallkeep ",
						st.latest,
						" is ready.",
						st.notes ? ` ${sentence(st.notes)}` : "",
						" Everyone is disconnected for a minute or two while it updates."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void update(),
					children: "Update now"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				disabled: busy,
				onClick: () => void check(),
				children: busy ? "Checking…" : "Check for updates"
			})
		]
	});
}
//#endregion
export { installUpdate as a, trialDaysLeft as c, waitAndReload as d, canWrite as i, useMyAccount as l, PLANS_URL as n, post as o, UpdatesCard as r, sentence as s, DockerUpdatesCard as t, useUpdateStatus as u };
