import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-D4U1xvG1.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/upgrade.functions-DM0nDfDp.js
/**
* Renew or upgrade a Tallkeep Desktop license (no sign-in): renew updates for another year, add
* companies, add people. The customer finds their license by its number and email, pays with
* Stripe, and the license gets a new key (same number), emailed and picked up by the office
* computer at its next check.
*/
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
/** The new "updates until" after renewing: a year past today or the current date, whichever is later. */
function renewedUntil(current, years = 1) {
	const base = current && current > today() ? current : today();
	const d = /* @__PURE__ */ new Date(`${base}T12:00:00Z`);
	d.setUTCFullYear(d.getUTCFullYear() + years);
	return d.toISOString().slice(0, 10);
}
/** Find a license by its number plus the email it was sent to, or the business name on it. */
var getUpgradeInfo = createServerFn({ method: "POST" }).inputValidator((d) => d).handler(createSsrRpc("b3d9b550fd57f1619d6614223abb41699073a11378cef344750801aba49c44e7"));
var startUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => {
	const n = (v) => Math.max(0, Math.min(100, Math.floor(Number(v) || 0)));
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	return {
		...d,
		renew: !!d.renew,
		addCompanies: n(d.addCompanies),
		addUsers: n(d.addUsers)
	};
}).handler(createSsrRpc("724d38f1c752f08b3df6330bde3f49cb5f5e4cc51e2a7909d81ced3a8bd86e60"));
/** Apply a paid upgrade (once). Asks Stripe itself whether it's paid. */
async function fulfillUpgrade(session) {
	if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return { status: "unpaid" };
	const db = await admin();
	const done = async () => {
		const { data: u } = await db.from("license_upgrades").select("license_id").eq("stripe_session", session).maybeSingle();
		if (!u) return null;
		const { data: l } = await db.from("desktop_licenses").select("*").eq("id", u.license_id).maybeSingle();
		const lic = l;
		return {
			status: "paid",
			id: lic.id,
			key: showKey ? lic.license_key : "",
			email: lic.email,
			companies: lic.companies,
			users: lic.users,
			updatesUntil: lic.updates_until,
			mailed: /key emailed/.test(lic.notes ?? ""),
			showKey
		};
	};
	const { stripe } = await import("./pay.server-DWS4W2Z4.mjs");
	const s = await stripe(`checkout/sessions/${session}`);
	const m = s.metadata ?? {};
	const showKey = m["by_name"] !== "1";
	const had = await done();
	if (had) return had;
	if (s.payment_status !== "paid" || m["product"] !== "tallkeep_upgrade") return { status: "unpaid" };
	const renew = m["renew"] === "1" ? 1 : 0;
	const addC = Number(m["add_companies"]) || 0;
	const addU = Number(m["add_users"]) || 0;
	const ins = await db.from("license_upgrades").insert({
		license_id: m["license"],
		stripe_session: session,
		renew_years: renew,
		add_companies: addC,
		add_users: addU,
		paid_cents: s.amount_total ?? null
	});
	if (ins.error) {
		const again = await done();
		if (again) return again;
		throw new Error(ins.error.message);
	}
	const { data: l } = await db.from("desktop_licenses").select("*").eq("id", m["license"]).maybeSingle();
	const lic = l;
	const next = {
		companies: lic.companies == null ? null : lic.companies + addC,
		users: lic.users == null ? null : lic.users + addU,
		updatesUntil: renew ? renewedUntil(lic.updates_until) : lic.updates_until
	};
	const { signLicenseKey, mailLicense, mailNote } = await import("./license.server-Bu3IQdFy.mjs");
	const key = await signLicenseKey({
		id: lic.id,
		to: lic.to_name,
		email: lic.email,
		...next,
		expires: lic.expires ?? null,
		edition: lic.edition ?? null,
		addons: lic.addons ?? null
	});
	const what = [
		renew ? `renewed to ${next.updatesUntil}` : "",
		addC ? `+${addC} compan${addC === 1 ? "y" : "ies"}` : "",
		addU ? `+${addU} ${addU === 1 ? "person" : "people"}` : ""
	].filter(Boolean).join(", ");
	const sent = lic.email ? await mailLicense({
		to: lic.email,
		name: lic.to_name,
		id: lic.id,
		key,
		companies: next.companies,
		users: next.users,
		updatesUntil: next.updatesUntil,
		origin: "https://app.tallkeep.com",
		updated: true
	}) : {
		ok: false,
		why: "no email address"
	};
	const notes = String(lic.notes ?? "").replace(/ ?·? ?key email(ed [0-9-]+| didn't go \([^)]*\))/g, "").trim();
	await db.from("desktop_licenses").update({
		license_key: key,
		companies: next.companies,
		users: next.users,
		updates_until: next.updatesUntil,
		notes: [
			notes,
			`${today()} paid online $${((s.amount_total ?? 0) / 100).toFixed(2)}: ${what}`,
			mailNote(sent)
		].filter(Boolean).join(" · ")
	}).eq("id", lic.id);
	return {
		status: "paid",
		id: lic.id,
		key: showKey ? key : "",
		email: lic.email,
		...next,
		mailed: sent.ok,
		showKey
	};
}
var getUpgradeOrder = createServerFn({ method: "GET" }).inputValidator((d) => ({ session: String(d.session ?? "") })).handler(createSsrRpc("059a3c99824bb5684bd30d408e4be244c5916b85e8f697267342e19e20e6a210"));
//#endregion
export { fulfillUpgrade, getUpgradeInfo, getUpgradeOrder, renewedUntil, startUpgrade };
