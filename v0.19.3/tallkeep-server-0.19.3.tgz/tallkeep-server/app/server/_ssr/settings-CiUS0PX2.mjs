import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as supabase } from "./client-C9I0PyVu.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as BUSINESS_TYPES, o as useAddons, t as ADDONS } from "./addons-8tQCpcOj.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-D4U1xvG1.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { n as switchCompany, r as useMyCompanies, t as activeCompanyId } from "./company-tZQlC9nr.mjs";
import { Gt as DatabaseBackup, Kt as CreditCard, M as RotateCcw, Mt as FolderOpen, Ot as Globe, P as RefreshCw, R as Plus, Ut as Download, _t as KeyRound, at as Mail, d as Upload, en as CircleCheck, g as Trash2, lt as LoaderCircle, qt as Copy } from "../_libs/lucide-react.mjs";
import { a as useIsOwner, i as useIsAdmin } from "./queries-Chjya1cy.mjs";
import { t as ZONES } from "./access-BYpSPlK4.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-C_XVL5mk.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { n as siteKind, r as versionLabel } from "./version-h8UQk6fq.mjs";
import { r as EDITIONS, t as ADDONS_FOR_SALE } from "./editions-Ccs--JHP.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { n as QuickBooksImport } from "./QuickBooksImport-BldwTUur.mjs";
import { o as stageOf, t as DEFAULT_RULES } from "./followups-CAmQFMgv.mjs";
import { c as publicOrigin, l as slugFrom } from "./support-Bri7jlNl.mjs";
import "./photos-PwQoyCNs.mjs";
import { r as PLACEMENTS, s as useFooters, t as FOOTER_KINDS } from "./footers-BNGmbiMB.mjs";
import { a as useCardPay, i as syncCardPayments, n as disconnectStripe, t as connectStripe } from "./cardpay-CotP51jv.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
import { n as useCompanyLogo } from "./PrintFrame-PJ2rEoZR.mjs";
import { c as trialDaysLeft, i as canWrite, l as useMyAccount, r as UpdatesCard, t as DockerUpdatesCard } from "./DockerUpdatesCard-Bd7W8GNY.mjs";
import { a as removeUser, i as listUsers, n as changeUser, o as setCompanyAccess, t as addUser } from "./users.functions-B8slpU7M.mjs";
import { t as FeaturePicker } from "./FeaturePicker-Xxboe_jo.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/settings-CiUS0PX2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function call$2(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/email${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var HELP = {
	gmail: "Gmail needs an app password, not your normal password: Google Account → Security → 2-Step Verification (turn it on) → App passwords → make one named Tallkeep, and paste the 16 letters here.",
	outlook: "Use your Microsoft account email and an app password (Microsoft account → Security → App passwords). On Microsoft 365, your admin may need to allow SMTP sending for this mailbox.",
	ionos: "Use the full email address and its email password from IONOS.",
	yahoo: "Yahoo needs an app password: Account Security → Generate app password.",
	icloud: "iCloud needs an app-specific password: appleid.apple.com → Sign-In and Security → App-Specific Passwords.",
	zoho: "Use the full email address; with two-step sign-in on, make an app password in Zoho.",
	godaddy: "Use the full email address and its email password.",
	other: "Your email provider's help pages list the outgoing mail server (SMTP) and port."
};
/** Settings → Company: the email account the office computer sends invoices and quotes from. */
function EmailSetupCard() {
	const qc = useQueryClient();
	const { data: st, error } = useQuery({
		queryKey: ["desktop-email"],
		queryFn: () => call$2("GET")
	});
	const [f, setF] = (0, import_react.useState)({
		provider: "gmail",
		host: "",
		port: "",
		user: "",
		pass: "",
		fromEmail: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [testTo, setTestTo] = (0, import_react.useState)("");
	const [editing, setEditing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!st) return;
		setF((x) => ({
			...x,
			provider: st.provider ?? "gmail",
			host: st.host,
			port: st.port ? String(st.port) : "",
			user: st.user,
			fromEmail: st.fromEmail !== st.user ? st.fromEmail : ""
		}));
		setTestTo((t) => t || st.user);
	}, [st]);
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: ["Email: ", error.message]
	});
	if (!st) return null;
	const preset = st.presets[f.provider];
	const pick = (provider) => {
		const p = st.presets[provider];
		setF({
			...f,
			provider,
			host: p?.host ?? "",
			port: p?.port ? String(p.port) : "587"
		});
	};
	async function save() {
		setBusy(true);
		try {
			const next = await call$2("PUT", "", {
				provider: f.provider,
				host: f.host || preset?.host,
				port: Number(f.port) || preset?.port || 587,
				user: f.user,
				pass: f.pass || void 0,
				fromEmail: f.fromEmail || f.user
			});
			qc.setQueryData(["desktop-email"], next);
			setF((x) => ({
				...x,
				pass: ""
			}));
			setEditing(false);
			toast.success("Email is set up. Send yourself a test to be sure.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function test() {
		setBusy(true);
		try {
			await call$2("POST", "/test", { to: testTo });
			toast.success(`Test email sent to ${testTo}.`);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["desktop-email"] });
		}
	}
	async function forget() {
		if (!window.confirm("Stop sending email from this account? Invoices can't be emailed until it's set up again.")) return;
		qc.setQueryData(["desktop-email"], await call$2("DELETE"));
	}
	const showForm = !st.ready || editing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-2 font-display text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-5 w-5" }), " Email"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Invoices, quotes, statements and support replies are sent from your own email account, through this office computer. Customers see them from you, and replies come back to you."
			})] }),
			st.ready && !editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [
								"Sending from ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.fromEmail }),
								st.provider && st.presets[st.provider] ? ` (${st.presets[st.provider].label})` : "",
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setEditing(true),
							children: "Change account"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void forget(),
							children: "Stop sending"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: testTo,
							onChange: (e) => setTestTo(e.target.value),
							placeholder: "you@yourbusiness.com",
							className: "max-w-xs",
							"aria-label": "Send a test to"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							disabled: busy || !testTo,
							onClick: () => void test(),
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Send a test email"]
						}),
						st.lastTest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground",
							children: ["Last test: ", st.lastTest.ok ? "worked" : `didn't work (${st.lastTest.why})`]
						})
					]
				})]
			}),
			showForm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					save();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Your email provider"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: f.provider,
									onChange: (e) => pick(e.target.value),
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									children: Object.entries(st.presets).map(([k, p]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: k,
										children: p.label
									}, k))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Email address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: f.user,
									onChange: (e) => setF({
										...f,
										user: e.target.value
									}),
									placeholder: "billing@yourbusiness.com",
									required: true
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: [
											"gmail",
											"yahoo",
											"icloud",
											"outlook"
										].includes(f.provider) ? "App password" : "Password"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										value: f.pass,
										onChange: (e) => setF({
											...f,
											pass: e.target.value
										}),
										placeholder: st.hasPassword ? "Leave empty to keep the saved one" : "",
										autoComplete: "new-password"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: HELP[f.provider] ?? HELP["other"]
									})
								]
							}),
							f.provider === "other" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Outgoing mail server (SMTP)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.host,
									onChange: (e) => setF({
										...f,
										host: e.target.value
									}),
									placeholder: "smtp.example.com"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "Port"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.port,
									onChange: (e) => setF({
										...f,
										port: e.target.value
									}),
									placeholder: "587"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: "Send from a different address (optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "email",
										value: f.fromEmail,
										onChange: (e) => setF({
											...f,
											fromEmail: e.target.value
										}),
										placeholder: "Leave empty to send from the email address above"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-xs text-muted-foreground",
										children: "Only if your provider lets this account send as that address (an alias)."
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "The password stays on this office computer only. Tallkeep checks it with your email provider before saving."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: busy,
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Check and save"]
						}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setEditing(false),
							children: "Cancel"
						})]
					})
				]
			})
		]
	});
}
/** Settings → Company: let customers pay invoices by card, through the business's own Stripe. */
function CardPaymentsCard({ admin }) {
	const qc = useQueryClient();
	const { data: st, isLoading, error } = useCardPay();
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const r = new URLSearchParams(window.location.search).get("card");
		if (r === "connected") toast.success("Stripe account connected.");
		else if (r === "failed") toast.error("Stripe didn't connect. Try again.");
	}, []);
	async function connect(existing = false) {
		if (!st) return;
		setBusy(true);
		try {
			const { url } = st.onboardingUrl && !existing ? { url: st.onboardingUrl } : await connectStripe(st.company, existing);
			window.location.href = url;
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	async function disconnect() {
		if (!st) return;
		if (!window.confirm("Disconnect Stripe from this company? Pay now links already sent stop working. Payments already made stay in the books. You can connect again (or a different account) right after.")) return;
		setBusy(true);
		try {
			await disconnectStripe(st.company);
			toast.success("Stripe disconnected.");
			qc.invalidateQueries({ queryKey: ["card-pay"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function check() {
		setBusy(true);
		try {
			const r = await syncCardPayments();
			toast.success(r.recorded ? `${r.recorded} card payment${r.recorded === 1 ? "" : "s"} put in the books.` : "No new card payments.");
			if (r.recorded) qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 font-display text-xl font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-5 w-5" }), " Card payments (Pay now)"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Add a \"Pay now\" link to invoices you email. Customers pay by card on Stripe's secure page; the money goes to your own Stripe account, and Tallkeep marks the invoice paid and records Stripe's fee by itself. Each company connects its own Stripe."
		})] }), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Checking…"
		}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: error.message
		}) : st?.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1",
						children: [
							"Customers can pay ",
							st.businessName ? `${st.businessName}'s ` : "",
							"invoices by card. Payments appear here within a few minutes."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void check(),
						disabled: busy,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-4 w-4" }), "Check for payments now"]
					}),
					admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => void disconnect(),
						disabled: busy,
						children: "Disconnect Stripe"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Payments go into the ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Stripe" }),
					" account in your chart of accounts, with Stripe's fee in Card Processing Fees",
					st.appFeePct ? ` (that fee includes Tallkeep's ${st.appFeePct}%)` : "",
					". When Stripe pays out to your bank, record it as a transfer from Stripe to the bank."
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				st?.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-red-700",
					children: st.problem
				}),
				st?.linked && (st.why || st.needs?.length || st.submitted) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: st.why ?? (st.needs?.length ? "Stripe needs a few more details." : "Stripe has your details and is checking them.") }),
						!!st.needs?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1",
							children: [
								"Still needed: ",
								st.needs.join(", "),
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs",
							children: "Card payments turn on by themselves when Stripe is done; open this page again to check."
						})
					]
				}),
				admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void connect(true),
						disabled: busy,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), st?.linked ? "Connect a different Stripe account" : "I have a Stripe account: sign in"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void connect(false),
						disabled: busy,
						children: !st?.linked ? "Create a new Stripe account" : st.needs?.length ? "Give Stripe the missing details" : "Open Stripe setup again"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "An admin can connect Stripe here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Already take cards with Stripe? Sign in and keep your account, payouts and history. New to Stripe? It asks for the business's details and the bank account for payouts (about 10 minutes). Stripe's usual card fee applies."
				})
			]
		})]
	});
}
async function call$1(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/connect${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var back = () => `${window.location.origin}/settings#plan`;
/** Settings → Plan & computer: Tallkeep Connect (use Tallkeep from anywhere). */
function ConnectCard({ admin }) {
	const qc = useQueryClient();
	const { data: st, error } = useQuery({
		queryKey: ["tallkeep-connect"],
		queryFn: () => call$1("GET"),
		refetchInterval: (q) => q.state.data?.active && !q.state.data.running ? 5e3 : 6e4
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)(null);
	const confirmed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const q = new URLSearchParams(window.location.search);
		const session = q.get("session");
		if (q.get("connect") !== "done" || !session || confirmed.current) return;
		confirmed.current = true;
		setBusy(true);
		call$1("POST", "/confirm", { session }).then((r) => {
			toast.success(r.active ? "Tallkeep Connect is on. Your web address is ready in a moment." : "Thank you! Tallkeep Connect turns on in a minute.");
			window.history.replaceState(null, "", "/settings#plan");
		}).catch((e) => toast.error(e.message)).finally(() => {
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		});
	}, [qc]);
	async function go(path) {
		setBusy(true);
		try {
			const r = await call$1("POST", path, { returnUrl: back() });
			if (r.url) {
				window.location.href = r.url;
				return;
			}
			toast.success("Tallkeep Connect is on for this computer. Your web address works in a minute.");
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	async function rename() {
		if (!newName) return;
		setBusy(true);
		try {
			const r = await call$1("POST", "/rename", { name: newName });
			toast.success(`Your address is now https://${r.hostname}. It can take a minute to start working.`);
			setNewName(null);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function check() {
		setBusy(true);
		try {
			qc.setQueryData(["tallkeep-connect"], await call$1("POST", "/check", {}));
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (error) return null;
	if (!st) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 font-display text-xl font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "h-5 w-5" }), " Tallkeep Connect"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Use Tallkeep from anywhere: phones away from the office, people working from home, and links customers and Airbnb can open. Your books stay on this computer; Connect gives it a secure web address. Nothing to set up on your router."
		})] }), st.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
					children: [
						st.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-5 w-5 animate-spin" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [st.running ? "On. Open Tallkeep from anywhere at:" : st.downloading ? "Getting ready (one-time download)…" : "Connecting…", st.url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block break-all font-mono text-base font-semibold",
								children: st.url
							})]
						}),
						st.url && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								copyText(st.url);
								toast.success("Address copied");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy"]
						})
					]
				}),
				st.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-red-700",
					children: st.problem
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Sign in there with the same email and password. Keep this computer on, with Tallkeep open. On a phone, open the address in the browser and choose \"Add to Home Screen\".", st.status === "past_due" ? " Your last payment didn't go through: update your card." : ""]
				}),
				admin && newName !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-2 rounded-xl border p-3",
					onSubmit: (e) => {
						e.preventDefault();
						rename();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm font-medium",
							htmlFor: "connect-name",
							children: "Pick a short address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "https://"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "connect-name",
									value: newName,
									onChange: (e) => setNewName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "")),
									className: "w-48 font-mono",
									maxLength: 40,
									autoFocus: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-sm text-muted-foreground",
									children: [".", (st.hostname ?? "x.tallkeep.app").split(".").slice(1).join(".")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									size: "sm",
									disabled: busy || newName.length < 3,
									children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Save address"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									onClick: () => setNewName(null),
									children: "Cancel"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Letters, numbers and dashes. The old address stops working, so update phones and bookmarks (and the calendar link in Airbnb, if you gave it one)."
						})
					]
				}),
				admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setNewName((st.hostname ?? "").split(".")[0] ?? ""),
							disabled: busy,
							children: "Change address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void go("/manage"),
							disabled: busy,
							children: "Change card or cancel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void check(),
							disabled: busy,
							children: "Check again"
						})
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				st.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: st.problem
				}),
				admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void go("/subscribe"),
					disabled: busy,
					children: [
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
						"Turn on Tallkeep Connect",
						st.price ? ` (${`$${st.price}`}/month)` : ""
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "An admin can turn on Tallkeep Connect here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Monthly, cancel any time."
				})
			]
		})]
	});
}
/** Settings → Features: the support page and saved replies (when Support Desk is on). */
function SupportSettings() {
	const qc = useQueryClient();
	const { data: s } = useQuery({
		queryKey: ["support-settings"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("name,support_slug,support_notify_email,support_topics,support_intro").maybeSingle();
			return data;
		}
	});
	const { data: origin } = useQuery({
		queryKey: ["public-origin"],
		queryFn: publicOrigin
	});
	const [f, setF] = (0, import_react.useState)({
		slug: "",
		notify: "",
		topics: "",
		intro: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (s) setF({
			slug: s.support_slug ?? slugFrom(s.name ?? ""),
			notify: s.support_notify_email ?? "",
			topics: (s.support_topics ?? []).join(", "),
			intro: s.support_intro ?? ""
		});
	}, [s]);
	async function save() {
		const slug = f.slug.trim().toLowerCase();
		if (slug && !/^[a-z0-9-]{2,60}$/.test(slug)) return void toast.error("Use letters, numbers and dashes for the address, like sunrise-led.");
		setBusy(true);
		const { error } = await db.from("company_settings").update({
			support_slug: slug || null,
			support_notify_email: f.notify.trim() || null,
			support_topics: f.topics.split(",").map((x) => x.trim()).filter(Boolean).slice(0, 20),
			support_intro: f.intro.trim() || null
		}).eq("company_id", await activeCompanyId() ?? "");
		setBusy(false);
		if (error) return void toast.error(/duplicate|unique/i.test(error.message) ? "Another business already uses that address. Try another." : error.message);
		toast.success("Support page saved.");
		qc.invalidateQueries({ queryKey: ["support-settings"] });
		qc.invalidateQueries({ queryKey: ["support-slug"] });
	}
	const url = origin && f.slug ? `${origin}/help/${f.slug.trim().toLowerCase()}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Support Desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Customers open tickets on your support page. Put its link on your website, invoices or email signature."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Support page address"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [origin, "/help/"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "w-56",
						value: f.slug,
						onChange: (e) => setF({
							...f,
							slug: e.target.value
						}),
						placeholder: "your-business"
					})]
				})]
			}),
			url && s?.support_slug && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: url,
					target: "_blank",
					rel: "noreferrer",
					className: "underline",
					children: "Open your support page"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => {
						copyText(url);
						toast.success("Link copied.");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy link"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Email new tickets and replies to"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.notify,
						onChange: (e) => setF({
							...f,
							notify: e.target.value
						}),
						placeholder: "support@yourbusiness.com (more than one: separate with commas)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Empty: the company email. When a ticket is assigned, replies go to that person."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Topics customers pick from"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.topics,
						onChange: (e) => setF({
							...f,
							topics: e.target.value
						}),
						placeholder: "Repair, Installation, Question about an invoice"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Separate with commas. Empty: no topic list."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "A line at the top of the page"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 2,
					value: f.intro,
					onChange: (e) => setF({
						...f,
						intro: e.target.value
					}),
					placeholder: "Tell us what you need and we'll get back to you within one business day."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save the support page"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedReplies, {})
		]
	});
}
function SavedReplies() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["ticket-templates"],
		queryFn: async () => {
			const { data } = await db.from("ticket_templates").select("id,title,body").order("title");
			return data ?? [];
		}
	});
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const refresh = () => void qc.invalidateQueries({ queryKey: ["ticket-templates"] });
	async function add() {
		if (!title.trim() || !body.trim()) return void toast.error("Type a name and the reply.");
		const { error } = await db.from("ticket_templates").insert({
			title: title.trim(),
			body: body.trim()
		});
		if (error) return void toast.error(error.message);
		setTitle("");
		setBody("");
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 border-t pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Saved replies"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Answers you send often. Pick one when replying to a ticket, then change what you need."
			}),
			(data ?? []).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border p-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "line-clamp-2 whitespace-pre-wrap text-muted-foreground",
						children: t.body
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					"aria-label": `Delete ${t.title}`,
					onClick: async () => {
						const { error } = await db.from("ticket_templates").delete().eq("id", t.id);
						if (error) return void toast.error(error.message);
						refresh();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			}, t.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-lg border p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "Name, like Parts ordered"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 3,
						value: body,
						onChange: (e) => setBody(e.target.value),
						placeholder: "The reply"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void add(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add saved reply"]
					})
				]
			})
		]
	});
}
/**
* Office computer (Windows): run Tallkeep as a Windows service, so the books stay open when no one
* is signed in. Only shows in the Tallkeep window on the office computer.
*/
var bridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
function ServiceCard() {
	const [st, setSt] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const refresh = () => void bridge().serviceStatus?.().then(setSt);
	(0, import_react.useEffect)(refresh, []);
	if (!st?.available) return null;
	const on = st.state !== "none";
	const change = async (turnOn) => {
		setBusy(true);
		try {
			const r = await (turnOn ? bridge().installService() : bridge().removeService());
			if (r.ok) toast.success(turnOn ? "Tallkeep now runs as a Windows service." : "The service is off. This window keeps the books again.");
			else if (!r.canceled) toast.error(r.error ?? "That didn't work.");
		} finally {
			setBusy(false);
			refresh();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Keep running without anyone signed in"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Runs Tallkeep as a Windows service: the books open when the computer starts, before anyone signs in, and stay open when you sign out or Windows restarts for an update. The computer doesn't go to sleep while it keeps the books."
			})] }),
			on ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [
					"On.",
					" ",
					st.state === "running" ? "The Tallkeep service keeps the books open." : `The service is ${st.state}.`,
					" ",
					"This window only shows them: closing it changes nothing for others."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Off. The books are open while this Tallkeep window is open (it starts when you sign in)."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: on ? "outline" : "default",
					disabled: busy,
					onClick: () => void change(!on),
					children: busy ? "Waiting for Windows…" : on ? "Turn off the service" : "Turn on the service"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Windows asks for permission. Tallkeep closes for a minute while it switches."
				})]
			}),
			on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Backups to a network folder (like a Synology): the service signs in to the network as this computer, not as you. If backups there stop working, open Services in Windows → Tallkeep → Log On, and enter your Windows account."
			})
		]
	});
}
/** Renew updates or add companies/people (Tallkeep's server). */
var UPGRADE_URL = "https://app.tallkeep.com/upgrade";
function useDesktopLicense() {
	return useQuery({
		queryKey: ["desktop-license"],
		queryFn: async () => {
			const r = await fetch("/tallkeep/license");
			if (!r.ok) throw new Error("Couldn't read the license.");
			return await r.json();
		}
	});
}
var many = (n, one, more) => n == null ? `any number of ${more}` : `${n} ${n === 1 ? one : more}`;
/** Settings → Plan & computer on an office computer: the trial or the license, and the key box. */
function LicenseCard() {
	const qc = useQueryClient();
	const { data: lic } = useDesktopLicense();
	const [key, setKey] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [changing, setChanging] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		try {
			const { data } = await supabase.auth.getSession();
			const r = await fetch("/tallkeep/license", {
				method: "POST",
				headers: {
					authorization: `Bearer ${data.session?.access_token ?? ""}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({ key })
			});
			const out = await r.json().catch(() => ({}));
			if (!r.ok) throw new Error(out.message ?? "That didn't work.");
			toast.success(out.checked ? "License checked with Tallkeep and saved. Thank you!" : "License saved. Tallkeep will check it when this computer is online.");
			setKey("");
			setChanging(false);
			await qc.invalidateQueries({ queryKey: ["desktop-license"] });
			await qc.invalidateQueries({ queryKey: ["my-account"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function checkNow() {
		setBusy(true);
		try {
			const { data } = await supabase.auth.getSession();
			const before = lic?.updatesUntil;
			const r = await fetch("/tallkeep/license", {
				method: "POST",
				headers: {
					authorization: `Bearer ${data.session?.access_token ?? ""}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({ check: true })
			});
			const out = await r.json().catch(() => ({}));
			if (!r.ok) throw new Error(out.message ?? "That didn't work.");
			if (!out.checked) toast.error("Couldn't reach Tallkeep. Check the internet connection and try again.");
			else if (out.updatesUntil !== before || out.companies !== lic?.companies || out.users !== lic?.users) toast.success("Your updated license is in. Thank you!");
			else toast.success("Checked with Tallkeep: your license is up to date.");
			await qc.invalidateQueries({ queryKey: ["desktop-license"] });
			await qc.invalidateQueries({ queryKey: ["my-account"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (!lic) return null;
	const upgradeUrl = lic.mode === "licensed" || lic.mode === "invalid" ? `${UPGRADE_URL}?${new URLSearchParams({
		license: lic.id ?? "",
		email: lic.email ?? ""
	})}` : UPGRADE_URL;
	const licensed = lic.mode === "licensed";
	const invalid = lic.mode === "invalid";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-2 font-display text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-5 w-5" }), " Your license"]
			}),
			invalid ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-900 dark:border-red-800 dark:bg-red-950/40 dark:text-red-100",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "License not valid."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [lic.message, lic.reason === "elsewhere" && lic.computers?.length ? ` (${lic.computers.join(", ")})` : ""] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your books are read-only: you can still open, print and download everything. Enter a valid license key, or contact Tallkeep." })
				]
			}) : licensed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Licensed to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: lic.to }),
						lic.email ? ` (${lic.email})` : "",
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Plan:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [lic.edition && EDITIONS[lic.edition] ? EDITIONS[lic.edition].label : "Everything", (lic.addons ?? []).map((a) => ` + ${ADDONS_FOR_SALE[a]?.label ?? a}`).join("")] }),
						".",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://app.tallkeep.com/buy?upgrade=1",
							target: "_blank",
							rel: "noreferrer",
							className: "text-[#C2410C] underline",
							children: "Add to my license"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Includes ",
						many(lic.companies, "company", "companies"),
						" and",
						" ",
						many(lic.users, "person", "people"),
						"."
					] }),
					lic.expires && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-lg bg-sky-50 p-2 text-sky-900 dark:bg-sky-950/40 dark:text-sky-100",
						children: [
							"Early access license: works until ",
							fmtDate(lic.expires),
							". Thank you for testing! Use",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Report a problem" }),
							" in Help (F1) for anything that doesn't work right."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lic.updatesUntil ? /* @__PURE__ */ new Date(`${lic.updatesUntil}T12:00:00`) >= /* @__PURE__ */ new Date() ? `Updates included until ${fmtDate(lic.updatesUntil)}.` : `Updates ended on ${fmtDate(lic.updatesUntil)}. Tallkeep keeps working; renew to get new versions.` : "Updates included." }),
					lic.offline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-amber-700 dark:text-amber-300",
						children: [
							"Not checked with Tallkeep yet (no internet?). It keeps working ",
							lic.offlineDaysLeft,
							" ",
							"more day",
							lic.offlineDaysLeft === 1 ? "" : "s",
							" without a check."
						]
					}) : lic.checkedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Checked with Tallkeep ",
							fmtDate(lic.checkedAt),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: ["License ", lic.id]
					})
				]
			}) : lic.mode === "trial" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Free trial:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
						lic.daysLeft,
						" day",
						lic.daysLeft === 1 ? "" : "s",
						" left"
					] }),
					" ",
					"(until ",
					fmtDate(lic.trialEnds),
					"). The trial includes ",
					lic.companies,
					" companies and",
					" ",
					lic.users,
					" people. Then the books become read-only until you enter a license key."
				]
			}) : lic.mode === "ended" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
				children: [
					"The free trial ended on ",
					fmtDate(lic.trialEnds),
					". Your books are read-only: you can still open, print and download everything. Enter a license key to keep working."
				]
			}) : null,
			(!licensed || invalid || changing) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "license-key",
						children: "License key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "license-key",
						rows: 3,
						value: key,
						onChange: (e) => setKey(e.target.value),
						placeholder: "Paste the key from your email (it starts with TK1.)",
						className: "font-mono text-xs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => void save(),
								disabled: busy || !key.trim(),
								children: busy ? "Checking…" : "Save the license key"
							}),
							!licensed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://tallkeep.com/pricing",
									target: "_blank",
									rel: "noreferrer",
									children: "Buy Tallkeep"
								})
							}),
							changing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setChanging(false),
								children: "Cancel"
							})
						]
					})
				]
			}),
			licensed && !changing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: upgradeUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "Renew updates"
						})
					}),
					(lic.companies != null || lic.users != null) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: upgradeUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "Add companies or people"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void checkNow(),
						disabled: busy,
						children: busy ? "Checking…" : "Check for my updated key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setChanging(true),
						children: "Enter a new license key"
					})
				]
			})
		]
	});
}
/**
* Put the books back from a backup in the backup folder, from a browser. Used where there's no
* Tallkeep window with a file picker: Tallkeep in Docker (a Synology, a server) or as a Windows
* service, and from other computers in the office.
*/
async function call(path, body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/backups/${path}`, {
		method: "POST",
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
function BackupPutBack({ name }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [look, setLook] = (0, import_react.useState)(null);
	const [company, setCompany] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const start = async () => {
		setBusy(true);
		try {
			const l = await call("inspect", { name });
			setLook(l);
			setCompany(l.companyOnly?.id ?? "");
			setOpen(true);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const go = async () => {
		setBusy(true);
		try {
			await call("restore", {
				name,
				company: company || null
			});
			toast.success("The books are back as they were in that backup.");
			setTimeout(() => window.location.reload(), 1200);
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	};
	const when = look?.made ? new Date(look.made).toLocaleString() : name;
	const cos = look?.companies ?? [];
	const chosen = look?.companyOnly ?? cos.find((c) => c.id === company) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "sm",
		variant: "ghost",
		className: "h-7",
		disabled: busy,
		onClick: () => void start(),
		children: "Put back…"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !busy && setOpen(v),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Put the books back?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"This backup is from ",
					when,
					"."
				] })] }),
				!look?.companyOnly && cos.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "putback-company",
						children: "What to put back"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "putback-company",
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						value: company,
						onChange: (e) => setCompany(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All companies"
						}), cos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: c.id,
							children: ["Only ", c.name]
						}, c.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						chosen ? `Everything entered in ${chosen.name} after that backup will be replaced, for everyone. The other companies stay as they are.` : "Everything entered after that backup will be replaced, in every company, for everyone.",
						" ",
						"Tallkeep saves a backup of the books as they are now first, so you can undo this."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: busy,
					onClick: () => setOpen(false),
					children: "Keep the books as they are"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					disabled: busy,
					onClick: () => void go(),
					children: busy ? "Putting back…" : chosen ? `Put ${chosen.name} back` : "Put all the books back"
				})] })
			]
		})
	})] });
}
/** Admin: run today's quote follow-ups now (same as the daily job). */
var runFollowupsNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("1c07c766055e3d99b4ce098f5bad7d8d0756bbe632b9e9d2384ee4f72ef8ecfc"));
var listBackups = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d1de4cd6c5fed7ab6d4819651136ceb161a48b3ea783c0171bce0c384b4914f4"));
var backupNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("68245375509608cf53f821532abc75914db1edaec535ba1975049ebadeb65f05"));
var backupLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("dbbb396530bca0dd8e8e455c118509c777c88ea9fb7ca04effe9f4459aa5d083"));
var uploadBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d.fileBase64 || d.fileBase64.length > 2e7) throw new Error("That file is too big.");
	return d;
}).handler(createSsrRpc("aab17122cc1986c06006ca74c6e3931f6572464fb86f3077a1ed4f46448288f6"));
var summarizeBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("d977603f5bbf94db864ead1e021883062b18ace6c6570fb34ac0f34bc925208b"));
var restoreFromBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.confirm !== "RESTORE") throw new Error("Type RESTORE to confirm.");
	return d;
}).handler(createSsrRpc("2c5a14efae666c66f9050e983d7ee7530c86790708cd112a473bd68c78ed1c0e"));
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-all",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
/** Import order matters: things must exist before others point at them. */
var STEPS = [
	{
		table: "categories",
		label: "Categories",
		conflict: "id"
	},
	{
		table: "locations",
		label: "Places",
		conflict: "id"
	},
	{
		table: "shelves",
		label: "Shelves",
		conflict: "id"
	},
	{
		table: "price_lists",
		label: "Price lists",
		conflict: "id"
	},
	{
		table: "payment_terms",
		label: "Payment terms",
		conflict: "id"
	},
	{
		table: "tax_rates",
		label: "Tax rates",
		conflict: "id"
	},
	{
		table: "products",
		label: "Products",
		conflict: "id"
	},
	{
		table: "product_prices",
		label: "Product prices",
		conflict: "product_id,price_list_id"
	},
	{
		table: "serial_numbers",
		label: "Serial numbers",
		conflict: "id"
	},
	{
		table: "stock",
		label: "Stock",
		conflict: "id"
	},
	{
		table: "customers",
		label: "Customers",
		conflict: "id"
	},
	{
		table: "vendors",
		label: "Vendors",
		conflict: "id"
	},
	{
		table: "vendor_items",
		label: "Vendor prices",
		conflict: "id"
	},
	{
		table: "sales_orders",
		label: "Quotes, orders & invoices",
		conflict: "id"
	},
	{
		table: "sales_order_lines",
		label: "Order lines",
		conflict: "id"
	},
	{
		table: "purchase_orders",
		label: "Purchase orders",
		conflict: "id"
	},
	{
		table: "purchase_order_lines",
		label: "Purchase order lines",
		conflict: "id"
	},
	{
		table: "payments",
		label: "Payments",
		conflict: "id"
	},
	{
		table: "stock_docs",
		label: "Adjustments, transfers & count sheets",
		conflict: "id"
	},
	{
		table: "stock_doc_lines",
		label: "Their lines",
		conflict: "id"
	},
	{
		table: "stock_moves",
		label: "Movement history",
		conflict: "id"
	},
	{
		table: "doc_counters",
		label: "Next document numbers",
		conflict: "company_id,kind"
	},
	{
		table: "company_settings",
		label: "Company details",
		conflict: "company_id"
	}
];
/** Settings in groups, each with its own color, picked from a side menu (like inFlow's options). */
var SETTINGS_GROUPS = [
	{
		key: "company",
		label: "Company",
		color: "#6366B8",
		text: "Details, companies, footers"
	},
	{
		key: "people",
		label: "People",
		color: "#4E9A72",
		text: "Users and what they see"
	},
	{
		key: "features",
		label: "Features",
		color: "#E8A13A",
		text: "Parts of the app, follow-ups"
	},
	{
		key: "accounting",
		label: "Accounting",
		color: "#1F8FA6",
		text: "Books, start fresh"
	},
	{
		key: "data",
		label: "Import & backups",
		color: "#9C7E62",
		text: "inFlow, QuickBooks, backups"
	},
	{
		key: "plan",
		label: "Plan & computer",
		color: "#687282",
		text: "Your plan, this computer"
	}
];
var OLD_ANCHORS = {
	import: "data",
	quickbooks: "data"
};
function SettingsPage() {
	const { data: isAdmin, isLoading } = useIsAdmin();
	const { data: owner } = useIsOwner();
	const { data: account } = useMyAccount();
	const { data: features } = useAddons();
	const desktop = !!{
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
		"VITE_SUPABASE_URL": "http://localhost:4600",
		"VITE_TALLKEEP_DESKTOP": "1"
	}["VITE_TALLKEEP_DESKTOP"];
	const showPlan = desktop || !!account && !account.is_platform;
	const groups = SETTINGS_GROUPS.filter((g) => (g.key !== "plan" || showPlan) && (owner || g.key !== "plan" && g.key !== "people"));
	const [group, setGroup] = (0, import_react.useState)("company");
	(0, import_react.useEffect)(() => {
		const read = () => {
			const h = window.location.hash.slice(1);
			const g = OLD_ANCHORS[h] ?? h;
			if (SETTINGS_GROUPS.some((x) => x.key === g)) setGroup(g);
			if (OLD_ANCHORS[h]) setTimeout(() => document.getElementById(h)?.scrollIntoView(), 300);
		};
		read();
		window.addEventListener("hashchange", read);
		return () => window.removeEventListener("hashchange", read);
	}, []);
	const pick = (g) => {
		setGroup(g);
		history.replaceState(null, "", `#${g}`);
	};
	const current = groups.find((g) => g.key === group) ?? groups[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Settings",
			text: `Company info, users and options. ${siteKind()} · ${versionLabel()}`
		}), isLoading ? null : isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 md:flex-row md:items-start",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex gap-2 overflow-x-auto pb-1 md:sticky md:top-4 md:w-56 md:shrink-0 md:flex-col md:overflow-visible",
				children: groups.map((g) => {
					const on = g.key === current.key;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => pick(g.key),
						className: cn("shrink-0 rounded-xl border px-3 py-2 text-left transition-colors", on ? "text-white shadow-sm" : "bg-card hover:bg-muted"),
						style: on ? {
							backgroundColor: g.color,
							borderColor: g.color
						} : { borderLeft: `4px solid ${g.color}` },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-semibold",
							children: g.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("hidden text-xs md:block", on ? "text-white/85" : "text-muted-foreground"),
							children: g.text
						})]
					}, g.key);
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 space-y-6 border-t-4 pt-4 md:border-t-0 md:border-l-4 md:pl-6 md:pt-0",
				style: { borderColor: current.color },
				children: [
					current.key === "company" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailSetupCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardPaymentsCard, { admin: !!owner }),
						owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompaniesCard, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootersCard, {})
					] }),
					current.key === "people" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersCard, {}),
					current.key === "features" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddonsCard, {}),
						features?.includes("support") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportSettings, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FollowupCard, {})
					] }),
					current.key === "accounting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountingCard, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseOutCard, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UndoCloseOutCard, {})
					] }),
					current.key === "data" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						desktop && owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightlyBackupCard, {}),
						(account?.is_platform || desktop) && owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupCard, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							id: "quickbooks",
							className: "scroll-mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickBooksImport, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							id: "import",
							className: "scroll-mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportCard, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotosCard, {})
					] }),
					current.key === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						account && !account.is_platform && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeComputerCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectCard, { admin: !!owner }),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdatesCard, {}),
						desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockerUpdatesCard, {})
					] })
				]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-muted-foreground",
			children: "Only an admin can change settings."
		})]
	});
}
function ImportCard() {
	const qc = useQueryClient();
	const [bundle, setBundle] = (0, import_react.useState)(null);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)({});
	const [current, setCurrent] = (0, import_react.useState)("");
	const [sure, setSure] = (0, import_react.useState)(false);
	const [finished, setFinished] = (0, import_react.useState)(false);
	async function pick(file) {
		if (!file) return;
		try {
			const data = JSON.parse(await file.text());
			if (!Array.isArray(data["products"])) throw new Error("bad file");
			setBundle(data);
			setFileName(file.name);
			setDone({});
			setFinished(false);
		} catch {
			toast.error("That file is not an inFlow import file.");
		}
	}
	async function run() {
		if (!bundle) return;
		setRunning(true);
		setFinished(false);
		try {
			for (const s of STEPS) {
				let rows = bundle[s.table] ?? [];
				if (s.table === "categories") rows = rows.map((r) => ({
					...r,
					parent_id: null
				}));
				if (s.table === "company_settings") rows = rows.map(({ id: _i, ...r }) => r);
				setCurrent(s.label);
				for (let i = 0; i < rows.length; i += 500) {
					const chunk = rows.slice(i, i + 500);
					const { error } = await db.from(s.table).upsert(chunk, { onConflict: s.conflict });
					if (error) throw new Error(`${s.label}: ${error.message}`);
					setDone((d) => ({
						...d,
						[s.table]: Math.min(i + 500, rows.length)
					}));
				}
				if (rows.length === 0) setDone((d) => ({
					...d,
					[s.table]: 0
				}));
				if (s.table === "categories") for (const c of (bundle["categories"] ?? []).filter((c) => c.parent_id)) await db.from("categories").update({ parent_id: c.parent_id }).eq("id", c.id);
				if (s.table === "stock") {
					const moves = rows.map((r) => ({
						id: r.id,
						product_id: r.product_id,
						location_id: r.location_id,
						shelf: r.shelf,
						qty_change: r.qty,
						reason: "import",
						note: "Stock on hand in inFlow"
					}));
					for (let i = 0; i < moves.length; i += 500) {
						const { error } = await db.from("stock_moves").upsert(moves.slice(i, i + 500), {
							onConflict: "id",
							ignoreDuplicates: true
						});
						if (error) throw new Error(`Stock history: ${error.message}`);
					}
				}
			}
			setFinished(true);
			toast.success("All your inFlow data is in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setRunning(false);
			setCurrent("");
		}
	}
	const total = STEPS.reduce((s, x) => s + (bundle?.[x.table]?.length ?? 0), 0);
	const doneCount = Object.values(done).reduce((a, b) => a + b, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring data over from inFlow"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Choose the file ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "inflow-import.json" }),
					" (saved on the Synology in ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inflow → Export" }),
					"), then press the button. Running it again updates the same records — it won't make copies — but it ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "resets stock counts" }),
					" to what inFlow had."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: fileName || "Choose the inflow-import.json file"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: ".json,application/json",
						className: "hidden",
						onChange: (e) => pick(e.target.files?.[0])
					})
				]
			}),
			bundle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-1 text-sm sm:grid-cols-2",
					children: STEPS.map((s) => {
						const n = bundle[s.table]?.length ?? 0;
						const d = done[s.table];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg px-2 py-1 odd:bg-muted/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-muted-foreground",
								children: [d === n && d !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-600" }) : current === s.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, n.toLocaleString()]
							})]
						}, s.table);
					})
				}),
				running && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: total ? doneCount / total * 100 : 0 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: sure,
						onCheckedChange: (v) => setSure(v === true),
						className: "mt-0.5"
					}), "I understand stock counts will be set to what inFlow had."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: run,
					disabled: !sure || running,
					children: running ? `Importing ${current}…` : finished ? "Import again" : "Import inFlow data"
				}),
				finished && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-emerald-700",
					children: "Done. Open Products to see everything."
				})
			] })
		]
	});
}
function CompanyCard() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["company"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			return data;
		}
	});
	const [f, setF] = (0, import_react.useState)({
		id: 1,
		name: "",
		address: null,
		phone: null,
		fax: null,
		email: null,
		website: null,
		quote_footer: null,
		invoice_footer: null
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (data) setF(data);
	}, [data]);
	const text = (k) => ({
		value: f[k] ?? "",
		onChange: (e) => setF((x) => ({
			...x,
			[k]: e.target.value || null
		}))
	});
	async function save(e) {
		e.preventDefault();
		setBusy(true);
		const { error } = await db.from("company_settings").upsert({
			...f,
			name: f.name || "My company"
		}, { onConflict: "company_id" });
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Company details saved.");
		qc.invalidateQueries({ queryKey: ["company"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Company details"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Printed at the top of every quote and invoice."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoPicker, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Company name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("email") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Website",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Legal name, if different",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("legal_name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tax ID (EIN)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("tax_id") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mailing address for payments, if different",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("mailing_address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name customers see on emails",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: f.name,
							...text("email_from_name")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Customer email replies go to",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "the person who sends it",
							...text("email_reply_to")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				children: busy ? "Saving…" : "Save company details"
			})
		]
	});
}
/** Upload the product pictures saved from inFlow (files named <product id>.jpg). */
function PhotosCard() {
	const qc = useQueryClient();
	const [files, setFiles] = (0, import_react.useState)([]);
	const [done, setDone] = (0, import_react.useState)(0);
	const [failed, setFailed] = (0, import_react.useState)(0);
	const [running, setRunning] = (0, import_react.useState)(false);
	async function run() {
		setRunning(true);
		setDone(0);
		setFailed(0);
		const ids = new Set((await fetchAll("products", "id")).map((p) => p.id));
		const queue = files.filter((f) => ids.has(f.name.replace(/\.[^.]+$/, "")));
		setFailed(files.length - queue.length);
		let i = 0;
		async function worker() {
			while (i < queue.length) {
				const f = queue[i++];
				const id = f.name.replace(/\.[^.]+$/, "");
				const path = `products/${id}.jpg`;
				if (!(await db.storage.from("product-photos").upload(path, f, {
					contentType: "image/jpeg",
					upsert: true
				})).error && !(await db.from("products").update({ picture_path: path }).eq("id", id)).error) setDone((d) => d + 1);
				else setFailed((x) => x + 1);
			}
		}
		await Promise.all([
			worker(),
			worker(),
			worker(),
			worker()
		]);
		setRunning(false);
		qc.invalidateQueries({ queryKey: ["product"] });
		toast.success("Photos are in.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring product photos over from inFlow"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Choose the whole product-photos folder" }),
					", go to the Synology folder",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inflow → Export" }),
					", click ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "product-photos" }),
					" once and press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Upload" }),
					" (the browser will ask to confirm — say yes)."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault();
					setFiles(Array.from(e.dataTransfer.files).filter((f) => /\.jpe?g$/i.test(f.name)));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-5 w-5 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: "Choose the whole product-photos folder"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							className: "hidden",
							webkitdirectory: "",
							directory: "",
							onChange: (e) => setFiles(Array.from(e.target.files ?? []).filter((f) => /\.jpe?g$/i.test(f.name)))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: files.length ? `${files.length} pictures chosen` : "…or pick pictures (Ctrl + A), or drag them here"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							multiple: true,
							className: "hidden",
							onChange: (e) => setFiles(Array.from(e.target.files ?? []))
						})
					]
				})]
			}),
			files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				(running || done > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: (done + failed) / files.length * 100 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						done,
						" uploaded",
						failed ? ` · ${failed} skipped` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: run,
					disabled: running,
					children: running ? "Uploading…" : "Upload product photos"
				})
			] })
		]
	});
}
/** Saved footers to pick from on each quote, order, invoice, RMA or purchase order. */
function FootersCard() {
	const qc = useQueryClient();
	const { data: footers } = useFooters();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const refresh = () => qc.invalidateQueries({ queryKey: ["doc-footers"] });
	async function add() {
		setAdding(true);
		const { error } = await db.from("doc_footers").insert({
			name: "New footer",
			body: "",
			sort: (footers?.length ?? 0) + 1
		});
		setAdding(false);
		if (error) toast.error(error.message);
		else refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Saved footers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Text for your documents: a line at the bottom of every page, a note at the end, or a whole page attached after it (like your Terms & Conditions). Save as many as you like and pick them on each document. Tick where each one is filled in automatically."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: add,
					disabled: adding,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a footer"]
				})]
			}),
			footers && footers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed p-4 text-sm text-muted-foreground",
				children: "No saved footers yet. Press Add a footer and paste your text in."
			}),
			(footers ?? []).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterRow, {
				footer: f,
				onSaved: refresh
			}, f.id))
		]
	});
}
function FooterRow({ footer, onSaved }) {
	const [f, setF] = (0, import_react.useState)(footer);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setF(footer), [footer]);
	const dirty = JSON.stringify(f) !== JSON.stringify(footer);
	async function save() {
		setBusy(true);
		const { error } = await db.from("doc_footers").update({
			name: f.name.trim() || "Footer",
			body: f.body,
			default_for: f.default_for,
			placement: f.placement
		}).eq("id", f.id);
		setBusy(false);
		if (error) toast.error(error.message);
		else {
			toast.success("Footer saved.");
			onSaved();
		}
	}
	async function remove() {
		if (!window.confirm(`Delete the footer "${f.name}"? Documents that already use it keep their text.`)) return;
		const { error } = await db.from("doc_footers").delete().eq("id", f.id);
		if (error) toast.error(error.message);
		else onSaved();
	}
	const toggle = (k, on) => setF((x) => ({
		...x,
		default_for: on ? [...x.default_for, k] : x.default_for.filter((y) => y !== k)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-xl border p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "font-medium",
					value: f.name,
					placeholder: "Name, e.g. Quote terms",
					onChange: (e) => setF({
						...f,
						name: e.target.value
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Delete this footer",
					onClick: remove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Prints at:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: f.placement,
					onValueChange: (v) => setF({
						...f,
						placement: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-8 w-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PLACEMENTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p.key,
						children: p.label
					}, p.key)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				rows: f.placement === "attach" ? 10 : 4,
				value: f.body,
				placeholder: "The text printed at the end of the document",
				onChange: (e) => setF({
					...f,
					body: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-4 gap-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "Fill in automatically on new:"
					}),
					FOOTER_KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							checked: f.default_for.includes(k.key),
							onCheckedChange: (v) => toggle(k.key, v === true)
						}), k.label]
					}, k.key)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "ml-auto",
						onClick: save,
						disabled: busy || !dirty,
						children: busy ? "Saving…" : dirty ? "Save footer" : "Saved"
					})
				]
			})
		]
	});
}
/** Company logo printed on quotes, invoices and purchase orders. */
function LogoPicker() {
	const qc = useQueryClient();
	const logo = useCompanyLogo();
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function upload(file) {
		if (!file) return;
		setBusy(true);
		const ext = file.name.split(".").pop()?.toLowerCase() || "png";
		const path = `company/${await activeCompanyId() ?? "none"}/logo-${Date.now()}.${ext}`;
		const err = (await db.storage.from("product-photos").upload(path, file, {
			contentType: file.type,
			upsert: true
		})).error ?? (await db.from("company_settings").update({ logo_path: path }).eq("company_id", await activeCompanyId() ?? "")).error;
		setBusy(false);
		if (err) toast.error(err.message);
		else {
			toast.success("Logo saved.");
			qc.invalidateQueries({ queryKey: ["company-logo"] });
		}
	}
	async function reset() {
		const { error } = await db.from("company_settings").update({ logo_path: null }).eq("company_id", await activeCompanyId() ?? "");
		if (error) toast.error(error.message);
		else qc.invalidateQueries({ queryKey: ["company-logo"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-4 rounded-xl border p-3",
		children: [logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: logo,
			alt: "Company logo",
			className: "h-14 max-w-[260px] object-contain"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground",
			children: "No logo yet"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 text-sm hover:bg-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
					" ",
					busy ? "Saving…" : "Change logo",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: (e) => void upload(e.target.files?.[0])
					})
				]
			}), logo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: () => void reset(),
				children: "Remove logo"
			})]
		})]
	});
}
/** Who can sign in. Admins can add people, set admin or staff, reset passwords. */
function UsersCard() {
	const qc = useQueryClient();
	const { data: users, isLoading, error } = useQuery({
		queryKey: ["app-users"],
		queryFn: () => listUsers()
	});
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [f, setF] = (0, import_react.useState)({
		name: "",
		email: "",
		password: "",
		role: "staff",
		access: []
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: companies } = useMyCompanies();
	const working = companies?.find((c) => c.active)?.id;
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["app-users"] });
		qc.invalidateQueries({ queryKey: ["company-members"] });
	};
	const startAdding = () => {
		setF((x) => ({
			...x,
			access: working ? [{
				company_id: working,
				is_admin: false,
				zones: null
			}] : []
		}));
		setAdding(true);
	};
	async function add(e) {
		e.preventDefault();
		if (f.role !== "admin" && !f.access.length) {
			toast.error("Tick at least one company they can open.");
			return;
		}
		setBusy(true);
		try {
			await addUser({ data: {
				name: f.name,
				email: f.email,
				password: f.password,
				role: f.role,
				zones: null,
				access: f.role === "admin" ? [] : f.access
			} });
			toast.success(`${f.email} can sign in now. Give them the password you typed.`);
			setF({
				name: "",
				email: "",
				password: "",
				role: "staff",
				access: []
			});
			setAdding(false);
			refresh();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Users"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						"People who can sign in. An ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "admin of every company" }),
						" also manages users, the plan and backups. Everyone else opens only the companies ticked for them, and in each one is its admin (settings and deleting there), sees every section, or only some sections."
					]
				})] }), !adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: startAdding,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add user"]
				})]
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: add,
				className: "grid gap-3 rounded-xl border p-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.name,
							onChange: (e) => setF({
								...f,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email (they sign in with this)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							required: true,
							value: f.email,
							onChange: (e) => setF({
								...f,
								email: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "First password (at least 8 characters)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "text",
							required: true,
							autoComplete: "new-password",
							value: f.password,
							onChange: (e) => setF({
								...f,
								password: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Can do",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: f.role,
							onValueChange: (v) => setF({
								...f,
								role: v
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "staff",
								children: "Only the companies I tick below"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "admin",
								children: "Admin of every company (also users and plan)"
							})] })]
						})
					}),
					f.role !== "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessTable, {
							value: f.access,
							onChange: (company_id, next) => setF({
								...f,
								access: [...f.access.filter((x) => x.company_id !== company_id), ...next ? [next] : []]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							children: busy ? "Adding…" : "Add this user"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setAdding(false),
							children: "Cancel"
						})]
					})
				]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: (users ?? []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRow, {
					u,
					onChanged: refresh
				}, u.id))
			})
		]
	});
}
var LEVEL_LABEL = {
	admin: "Admin of this company",
	all: "Every section",
	some: "Only some sections"
};
var levelOf = (a) => a.is_admin ? "admin" : a.zones ? "some" : "all";
/** For each company: does this person open it, and as what? */
function AccessTable({ value, onChange }) {
	const { data: companies } = useMyCompanies();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "divide-y rounded-lg border bg-muted/30",
		children: (companies ?? []).map((c) => {
			const a = value.find((x) => x.company_id === c.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-48 flex-1 items-center gap-2 font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "h-4 w-4",
							checked: !!a,
							onChange: (e) => onChange(c.id, e.target.checked ? {
								company_id: c.id,
								is_admin: false,
								zones: null
							} : null)
						}), c.name]
					}),
					a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						"aria-label": `Access in ${c.name}`,
						className: "h-8 rounded-md border bg-background px-2 text-sm",
						value: levelOf(a),
						onChange: (e) => {
							const l = e.target.value;
							onChange(c.id, {
								company_id: c.id,
								is_admin: l === "admin",
								zones: l === "some" ? a.zones ?? ["Inventory"] : null
							});
						},
						children: Object.keys(LEVEL_LABEL).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: l,
							children: LEVEL_LABEL[l]
						}, l))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Can't open"
					}),
					a?.zones && !a.is_admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "basis-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZonePicker, {
							zones: a.zones,
							onChange: (zones) => onChange(c.id, {
								...a,
								zones
							})
						})
					})
				]
			}, c.id);
		})
	});
}
/** Tick the sections this person may open. Home and Settings need an admin. */
function ZonePicker({ zones, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-x-4 gap-y-2 pl-6 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: "Can open:"
		}), ZONES.map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "h-4 w-4",
				checked: zones.includes(z),
				onChange: (e) => {
					const next = e.target.checked ? [...zones, z] : zones.filter((x) => x !== z);
					if (next.length === 0) {
						toast.error("Tick at least one section.");
						return;
					}
					onChange(next);
				}
			}), z]
		}, z))]
	});
}
function UserRow({ u, onChanged }) {
	const [pw, setPw] = (0, import_react.useState)(null);
	const [access, setAccess] = (0, import_react.useState)(u.access);
	(0, import_react.useEffect)(() => setAccess(u.access), [u.access]);
	async function run(p, msg) {
		try {
			await p;
			toast.success(msg);
			onChanged();
		} catch (err) {
			toast.error(err.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-3 px-4 py-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full max-w-xs rounded-md border border-transparent bg-transparent px-1 font-medium hover:border-input focus:border-input",
					defaultValue: u.name,
					placeholder: "Type their name (shows as Sales rep)",
					onBlur: (e) => {
						const name = e.target.value.trim();
						if (name !== u.name) run(changeUser({ data: {
							id: u.id,
							name
						} }), "Name saved.");
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: [`${u.email} · `, u.last_sign_in_at ? `last signed in ${fmtDate(u.last_sign_in_at)}` : "has not signed in yet"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: u.role,
				onValueChange: (v) => void run(changeUser({ data: {
					id: u.id,
					role: v,
					zones: null
				} }), v === "admin" ? "Now an admin of every company." : "Saved. Tick the companies below."),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-8 w-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "admin",
					children: "Admin of every company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "staff",
					children: "Chosen companies"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "order-last basis-full",
				children: u.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Opens every company; also manages users, the plan and backups."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [access.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-xs font-medium text-amber-700 dark:text-amber-300",
					children: "Can't open any company yet. Tick at least one:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessTable, {
					value: access,
					onChange: (company_id, next) => {
						const before = access;
						setAccess([...access.filter((x) => x.company_id !== company_id), ...next ? [next] : []]);
						setCompanyAccess({ data: {
							id: u.id,
							company_id,
							open: !!next,
							is_admin: next?.is_admin ?? false,
							zones: next?.zones ?? null
						} }).then(() => {
							toast.success("Saved.");
							onChanged();
						}).catch((err) => {
							setAccess(before);
							toast.error(err.message);
						});
					}
				})] })
			}),
			pw == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => setPw(""),
				children: "New password"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-1",
				onSubmit: (e) => {
					e.preventDefault();
					run(changeUser({ data: {
						id: u.id,
						password: pw
					} }), "Password changed.").then(() => setPw(null));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 w-40",
					placeholder: "New password",
					autoComplete: "new-password",
					value: pw,
					onChange: (e) => setPw(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					type: "submit",
					children: "Save password"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "ghost",
				"aria-label": "Remove this user",
				onClick: () => {
					if (window.confirm(`Remove ${u.email}? They won't be able to sign in. Their past work stays.`)) run(removeUser({ data: { id: u.id } }), "User removed.");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
			})
		]
	});
}
/** One-time: everything sold before today is invoiced and paid. */
function CloseOutCard() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["close-out-preview"],
		queryFn: () => fetchAll("sales_orders", "id,number,status,balance,stock_taken_at")
	});
	const [day, setDay] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const [ship, setShip] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const live = (data ?? []).filter((r) => ![
		"quote",
		"rma",
		"cancelled"
	].includes(r.status) && !r.number.startsWith("RMA-"));
	const notInvoiced = live.filter((r) => r.status === "open").length;
	const owing = live.filter((r) => Number(r.balance) > .005);
	const owed = owing.reduce((s, r) => s + Number(r.balance), 0);
	const notShipped = live.filter((r) => !r.stock_taken_at).length;
	const nothing = notInvoiced === 0 && owing.length === 0 && (!ship || notShipped === 0);
	async function run() {
		const msg = `Mark all ${live.length} sales orders and invoices as invoiced and paid as of ${day}?\n\nThis adds a "Paid before switch-over" payment to ${owing.length} invoices ($${owed.toFixed(2)} in all). Quotes and RMAs are not touched.`;
		if (!window.confirm(msg)) return;
		setBusy(true);
		const { data: r, error } = await db.rpc("close_out_sales", {
			_as_of: (/* @__PURE__ */ new Date(day + "T12:00:00")).toISOString(),
			_mark_shipped: ship
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		const x = r;
		toast.success(`Done: ${x.invoiced} invoiced, ${x.payments} marked paid${ship ? `, ${x.shipped} marked shipped` : ""}.`);
		qc.invalidateQueries();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Start fresh: mark all invoices paid"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Use once, when everything sold so far is invoiced and paid. Quotes and RMAs stay as they are. Stock is not changed."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: notInvoiced }), " not invoiced yet"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: owing.length }),
							" still owe money (",
							owed.toLocaleString("en-US", {
								style: "currency",
								currency: "USD"
							}),
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: notShipped }), " not marked shipped"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: ["Paid as of", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 w-40",
						value: day,
						onChange: (e) => setDay(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: ship,
						onCheckedChange: (v) => setShip(v === true)
					}), "Also mark them shipped"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "destructive",
				onClick: () => void run(),
				disabled: busy || !data || nothing,
				children: busy ? "Working…" : nothing ? "Everything is already paid" : "Mark all invoices invoiced and paid"
			})
		]
	});
}
/** Quote follow-ups: remind at 14 and 30 days, close at 45 (quotes are good for 30 days). */
function FollowupCard() {
	const qc = useQueryClient();
	const { data: rules } = useQuery({
		queryKey: ["followup-rules"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			const r = { ...DEFAULT_RULES };
			if (data) Object.keys(r).forEach((k) => {
				const v = data[k];
				if (v != null) r[k] = v;
			});
			return r;
		}
	});
	const { data: quotes } = useQuery({
		queryKey: ["followup-quotes"],
		queryFn: () => fetchAll("sales_orders", "id,number,status,order_date,followup_count,customer_name,contact_name,email,total")
	});
	const [f, setF] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (rules) setF(rules);
	}, [rules]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!f) return null;
	const stages = (quotes ?? []).map((q) => stageOf(q, f));
	const n1 = stages.filter((x) => x === "first").length;
	const n2 = stages.filter((x) => x === "second").length;
	const nClose = stages.filter((x) => x === "close").length;
	async function save(next) {
		setF(next);
		const { error } = await db.from("company_settings").update(next).eq("company_id", await activeCompanyId() ?? "");
		if (error) toast.error(error.message);
		else {
			toast.success("Saved.");
			qc.invalidateQueries({ queryKey: ["followup-rules"] });
		}
	}
	async function runNow() {
		if (nClose > 0 && !window.confirm(`This closes ${nClose} quotes older than ${f.quote_close_days} days. You can reopen any of them later. Go ahead?`)) return;
		setBusy(true);
		try {
			const r = await runFollowupsNow();
			toast.success(`Done: ${r.closed} closed, ${r.due} on today's follow-up list${r.emailed ? `, ${r.emailed} customers emailed` : ""}.`);
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const num = (k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		className: "h-8 w-16 text-right",
		inputMode: "numeric",
		value: f[k],
		onChange: (e) => setF({
			...f,
			[k]: Number(e.target.value) || 0
		}),
		onBlur: () => void save(f)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Quote follow-ups"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every morning: quotes that need a follow-up show on Home and are emailed to the office. Old quotes are closed (you can reopen them)."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					checked: f.followup_enabled,
					onCheckedChange: (v) => void save({
						...f,
						followup_enabled: v === true
					})
				}), "Turn on daily follow-ups"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-5 gap-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"1st follow-up after ",
							num("followup_days1"),
							" days"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"2nd after ",
							num("followup_days2"),
							" days"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"Close the quote after ",
							num("quote_close_days"),
							" days"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					checked: f.followup_auto_email,
					onCheckedChange: (v) => void save({
						...f,
						followup_auto_email: v === true
					})
				}), "Also email the customer automatically (a short, polite note — no PDF)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n1 }), " need a 1st follow-up"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n2 }), " need a 2nd follow-up"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: nClose }), " would be closed"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void runNow(),
				disabled: busy,
				children: busy ? "Working…" : "Run today's follow-ups now"
			})
		]
	});
}
/** Undo "Start fresh" for single invoices that weren't really paid. */
function UndoCloseOutCard() {
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["close-out-payments"],
		queryFn: async () => {
			const { data: pays, error: e1 } = await db.from("payments").select("id, amount, paid_on, sales_order_id").eq("method", "Paid before switch-over").limit(2e3);
			if (e1) throw new Error(e1.message);
			const ids = [...new Set((pays ?? []).map((p) => p.sales_order_id).filter(Boolean))];
			const orders = /* @__PURE__ */ new Map();
			for (let i = 0; i < ids.length; i += 150) {
				const { data: so, error: e2 } = await db.from("sales_orders").select("id, number, customer_name, total").in("id", ids.slice(i, i + 150));
				if (e2) throw new Error(e2.message);
				(so ?? []).forEach((o) => orders.set(o.id, o));
			}
			return (pays ?? []).map((p) => ({
				id: p.id,
				amount: p.amount,
				paid_on: p.paid_on,
				sales_orders: p.sales_order_id && orders.get(p.sales_order_id) || null
			})).sort((x, y) => (x.sales_orders?.number ?? "").localeCompare(y.sales_orders?.number ?? "", void 0, { numeric: true })).reverse();
		}
	});
	const [q, setQ] = (0, import_react.useState)("");
	if (isLoading || error || !data || data.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: "Invoices marked paid by Start fresh"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-muted-foreground",
			children: isLoading ? "Loading…" : error ? `Couldn't load the list: ${error.message}` : "None — Start fresh hasn't marked any invoices paid."
		})]
	});
	const words = q.toLowerCase().split(/\s+/).filter(Boolean);
	const rows = data.filter((p) => {
		const hay = `${p.sales_orders?.number ?? ""} ${p.sales_orders?.customer_name ?? ""}`.toLowerCase();
		return words.every((w) => hay.includes(w));
	});
	async function undo(p) {
		if (!window.confirm(`Mark ${p.sales_orders?.number} unpaid again? It will owe ${fmtMoney(p.amount)}.`)) return;
		const { error } = await db.from("payments").delete().eq("id", p.id);
		if (error) toast.error(error.message);
		else {
			toast.success(`${p.sales_orders?.number} is unpaid again.`);
			qc.invalidateQueries();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Invoices marked paid by Start fresh"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					data.length,
					" invoices got a “Paid before switch-over” payment. If one wasn't really paid, press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Mark unpaid again" }),
					" and it shows as owed."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Search invoice # or customer",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-96 divide-y overflow-y-auto rounded-xl border",
				children: rows.slice(0, 200).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-3 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-28 font-medium",
							children: p.sales_orders?.number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate",
							children: p.sales_orders?.customer_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-right font-semibold",
							children: fmtMoney(p.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void undo(p),
							children: "Mark unpaid again"
						})
					]
				}, p.id))
			})
		]
	});
}
/** Nightly backups of all office data, kept 30 days (+ the 1st of each month for a year). */
function BackupCard() {
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["backups"],
		queryFn: () => listBackups()
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [showAll, setShowAll] = (0, import_react.useState)(false);
	const [restoring, setRestoring] = (0, import_react.useState)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const files = data ?? [];
	const kb = (n) => n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} KB`;
	async function now() {
		setBusy(true);
		try {
			const r = await backupNow();
			const rows = Object.values(r.counts).reduce((a, b) => a + b, 0);
			toast.success(`Backup saved: ${r.name} (${rows.toLocaleString()} records).`);
			qc.invalidateQueries({ queryKey: ["backups"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function pickFile(file) {
		if (!file) return;
		if (!file.name.endsWith(".json.gz")) {
			toast.error("Choose a backup file that ends in .json.gz");
			return;
		}
		setUploading(true);
		try {
			const buf = new Uint8Array(await file.arrayBuffer());
			let bin = "";
			for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode(...buf.subarray(i, i + 32768));
			const { name } = await uploadBackup({ data: { fileBase64: btoa(bin) } });
			setRestoring({
				name,
				label: file.name
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setUploading(false);
		}
	}
	async function download(name) {
		try {
			const { url } = await backupLink({ data: { name } });
			window.location.href = url;
		} catch (e) {
			toast.error(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "flex items-center gap-2 font-display text-xl font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, { className: "h-5 w-5" }),
						" ",
						DESKTOP_APP ? "Move books from Tallkeep online" : "Backups"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: DESKTOP_APP ? "Bring your books over from Tallkeep online: download a backup there, then restore it here. These are also a second kind of copy, made inside the app." : "Every night all office data (products, stock, customers, quotes, invoices, purchase orders, payments and settings) is saved as one file. The last 30 days are kept, plus the 1st of each month for a year. Your Synology also downloads a copy each night."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => void now(),
					disabled: busy,
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, { className: "h-4 w-4" }), busy ? "Saving backup…" : "Back up now"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error.message.includes("not found") ? "The backup storage isn't set up yet." : error.message
			}),
			!isLoading && !error && files.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No backups yet. Press Back up now to make the first one."
			}),
			files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: (showAll ? files : files.slice(0, 5)).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 font-medium",
							children: backupLabel(f.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: kb(f.size)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void download(f.name),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setRestoring({
								name: f.name,
								label: backupLabel(f.name)
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Restore…"]
						})
					]
				}, f.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [files.length > 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => setShowAll(!showAll),
					children: showAll ? "Show fewer" : `Show all ${files.length} backups`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex cursor-pointer items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium hover:bg-muted",
					children: [
						uploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
						uploading ? "Reading the file…" : DESKTOP_APP ? "Restore a backup from Tallkeep online…" : "Restore from a file (e.g. from the Synology)…",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".gz",
							className: "hidden",
							disabled: uploading,
							onChange: (e) => {
								pickFile(e.target.files?.[0]);
								e.target.value = "";
							}
						})
					]
				})]
			}),
			restoring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RestoreDialog, {
				name: restoring.name,
				label: restoring.label,
				onClose: () => setRestoring(null),
				onDone: () => {
					setRestoring(null);
					qc.invalidateQueries();
				}
			})
		]
	});
}
function backupLabel(name) {
	const day = fmtDate(`${name.slice(7, 17)}T12:00:00`);
	const m = name.match(/-before-restore-(\d{2})(\d{2})\./);
	return m ? `${day} · saved before a restore (${m[1]}:${m[2]})` : day;
}
/** Choose what to put back from one backup, see the numbers, type RESTORE, go. */
function RestoreDialog({ name, label, onClose, onDone }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["backup-summary", name],
		queryFn: () => summarizeBackup({ data: { name } })
	});
	const [parts, setParts] = (0, import_react.useState)([]);
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const total = (rows, k) => rows.reduce((s, r) => s + r[k], 0);
	async function go() {
		setBusy(true);
		try {
			const r = await restoreFromBackup({ data: {
				name,
				parts,
				confirm
			} });
			const back = Object.values(r.restored).reduce((a, b) => a + b, 0);
			const gone = Object.values(r.removed).reduce((a, b) => a + b, 0);
			toast.success(`Restored ${back.toLocaleString()} records and removed ${gone.toLocaleString()} added since. Your data from before is saved as a backup, so this can be undone.` + (r.newLogins ? ` ${r.newLogins} login${r.newLogins === 1 ? "" : "s"} added: set each one's password in Settings → Users.` : ""), { duration: 2e4 });
			onDone();
		} catch (e) {
			toast.error(e.message, { duration: 12e3 });
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && !busy && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Restore from backup: ", label] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"Tick what to put back the way it was",
					data?.made_at ? ` on ${new Date(data.made_at).toLocaleString()}` : "",
					". Records added since then are removed, changed ones are set back, deleted ones come back. Before anything changes, today's data is saved as a backup, so you can undo this."
				] })] }),
				isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Reading the backup…"
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: error.message
				}),
				data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-xl border",
					children: data.parts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer items-start gap-3 px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-0.5 h-4 w-4",
							checked: parts.includes(p.key),
							onChange: (e) => setParts((s) => e.target.checked ? [...s, p.key] : s.filter((x) => x !== p.key))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: p.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [
									"In the backup: ",
									total(p.tables, "backup").toLocaleString(),
									" records · in the app now: ",
									total(p.tables, "now").toLocaleString()
								]
							})]
						})]
					}, p.key))
				}),
				parts.length > 0 && parts.length < 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Restoring only some parts: anything else that points to a removed record keeps working, but loses that link (for example an invoice line for a product that is removed keeps its description). For a full \"go back to that day\", tick all of them."
				}),
				parts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Type RESTORE to confirm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: confirm,
						onChange: (e) => setConfirm(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					disabled: busy,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "destructive",
					onClick: () => void go(),
					disabled: busy || !parts.length || confirm !== "RESTORE",
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), busy ? "Restoring… don't close this page" : "Restore the ticked parts"]
				})] })
			]
		})
	});
}
/** Companies: add one, rename, choose who may open it. Admins can open every company. */
function CompaniesCard() {
	const qc = useQueryClient();
	const { data: companies, error } = useMyCompanies();
	const { data: users } = useQuery({
		queryKey: ["app-users"],
		queryFn: () => listUsers()
	});
	const { data: members } = useQuery({
		queryKey: ["company-members"],
		queryFn: async () => {
			const { data } = await db.from("company_members").select("company_id,user_id");
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["my-companies"] });
		qc.invalidateQueries({ queryKey: ["company-members"] });
	};
	if (error || !companies?.length) return null;
	async function rename(id, next) {
		const { error: err } = await db.from("companies").update({ name: next }).eq("id", id);
		if (err) toast.error(err.message);
		else {
			toast.success("Name saved.");
			refresh();
		}
	}
	async function toggle(companyId, userId, on) {
		const { error: err } = on ? await db.from("company_members").insert({
			company_id: companyId,
			user_id: userId
		}) : await db.from("company_members").delete().eq("company_id", companyId).eq("user_id", userId);
		if (err) toast.error(err.message);
		else refresh();
	}
	const staff = (users ?? []).filter((u) => u.role !== "admin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Companies"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Each company has its own products, customers, invoices, numbers and settings. Admins can open every company; tick who else may open each one (or do it in Settings → People). Switch company at the top of the menu."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: companies.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "min-w-0 flex-1 rounded-md border border-transparent bg-transparent px-1 font-medium hover:border-input focus:border-input",
							defaultValue: c.name,
							onBlur: (e) => {
								const next = e.target.value.trim();
								if (next && next !== c.name) rename(c.id, next);
							}
						}), c.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary",
							children: "Working in this one"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void switchCompany(c.id),
							children: "Switch to this company"
						})]
					}), staff.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Who can open it:"
						}), staff.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "h-4 w-4",
								checked: (members ?? []).some((m) => m.company_id === c.id && m.user_id === u.id),
								onChange: (e) => void toggle(c.id, u.id, e.target.checked)
							}), u.name || u.email]
						}, u.id))]
					})]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/setup-company",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Set up a new company"]
				})
			})
		]
	});
}
/** Turn optional parts on or off for the company you're working in. */
function AddonsCard() {
	const qc = useQueryClient();
	const { data: on } = useAddons();
	const { data: type } = useQuery({
		queryKey: ["company-addons", "type"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("business_type").maybeSingle();
			return data?.business_type ?? null;
		}
	});
	async function save(patch, msg) {
		const { error } = await db.from("company_settings").update(patch).eq("company_id", await activeCompanyId() ?? "");
		if (error) return void toast.error(error.message);
		toast.success(msg);
		qc.invalidateQueries({ queryKey: ["company-addons"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: "Features"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "What this company uses. Turning a feature off hides it from the menu; nothing is deleted, and turning it back on brings everything back."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturePicker, {
			type: type ?? null,
			features: on ?? [],
			onType: (t) => {
				if (!window.confirm(`Set this company to "${BUSINESS_TYPES[t].label}" and turn on its usual features? Features you turned on yourself stay on.`)) return;
				save({
					business_type: t,
					addons: Array.from(/* @__PURE__ */ new Set([...on ?? [], ...BUSINESS_TYPES[t].features]))
				}, `Set to ${BUSINESS_TYPES[t].label}.`);
			},
			onToggle: (k, enable) => {
				save({ addons: enable ? [...on ?? [], k] : (on ?? []).filter((x) => x !== k) }, `${ADDONS[k].label} turned ${enable ? "on" : "off"}.`);
			}
		})]
	});
}
/** Books start date, default bank account, and rebuilding the books. */
function AccountingCard() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data, error } = useQuery({
		queryKey: ["books-settings"],
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("books_start_date,default_bank_account_id").maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const [start, setStart] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setStart(data?.books_start_date ?? ""), [data]);
	if (error) return null;
	const banks = (accounts ?? []).filter((a) => a.kind === "bank" && a.is_active);
	async function rebuild(msg) {
		const { data: r, error: e } = await db.rpc("rebuild_books");
		if (e) throw e;
		toast.success(`${msg} ${r.entries} entries in the books.`);
		qc.invalidateQueries();
	}
	async function saveStart() {
		setBusy(true);
		try {
			const { error: e } = await db.from("company_settings").update({ books_start_date: start || null }).eq("company_id", await activeCompanyId() ?? "");
			if (e) throw e;
			await rebuild(start ? "Books start date saved." : "Books turned off.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function setBank(id) {
		const { error: e } = await db.from("company_settings").update({ default_bank_account_id: id }).eq("company_id", await activeCompanyId() ?? "");
		if (e) toast.error(e.message);
		else {
			toast.success("Saved. Payments go to this account unless you pick another.");
			qc.invalidateQueries({ queryKey: ["books-settings"] });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Accounting"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "From the start date, every invoice, payment, received purchase order, bill and stock change writes itself into the books. Before that date nothing is posted; enter what each account held as opening balances."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Books start on"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: start,
							onChange: (e) => setStart(e.target.value),
							className: "w-44"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void saveStart(),
						disabled: busy || start === (data?.books_start_date ?? ""),
						children: busy ? "Saving…" : "Save start date"
					}),
					data?.books_start_date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/journal",
							search: { opening: 1 },
							children: "Enter opening balances"
						})
					})
				]
			}),
			banks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block max-w-sm space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: "Customer payments go into"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: data?.default_bank_account_id ?? "",
					onValueChange: (v) => void setBank(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a bank account" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: banks.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: a.id,
						children: accountLabel(a)
					}, a.id)) })]
				})]
			}),
			data?.books_start_date && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 border-t pt-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					disabled: busy,
					onClick: () => {
						setBusy(true);
						rebuild("Books rebuilt.").catch((e) => toast.error(e.message)).finally(() => setBusy(false));
					},
					children: "Rebuild the books"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Writes every automatic entry again from the documents. Use it after a restore or if a report looks wrong. Entries typed by hand are kept."
				})]
			})
		]
	});
}
/** Your plan: what it includes and how much of it you use. */
function PlanCard() {
	const { data: account } = useMyAccount();
	const { data: companies } = useMyCompanies();
	const { data: people } = useQuery({
		queryKey: ["org-people-count"],
		queryFn: async () => {
			const { count } = await db.from("org_members").select("user_id", {
				count: "exact",
				head: true
			});
			return count ?? 0;
		}
	});
	if (!account) return null;
	const days = trialDaysLeft(account);
	const writable = canWrite(account);
	const status = !writable ? "Read-only" : account.status === "trial" ? `Free trial, ${days} day${days === 1 ? "" : "s"} left` : account.status === "past_due" ? "Payment is late" : "Active";
	const of = (n, max) => max == null ? `${n ?? 0}` : `${n ?? 0} of ${max}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Your plan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					account.edition === "desktop" ? "Desktop" : "Cloud",
					" · ",
					status
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Companies"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-lg font-semibold",
						children: of(companies?.length, account.companies_allowed)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "People"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-lg font-semibold",
						children: of(people, account.users_allowed)
					})]
				})]
			}),
			!writable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Your books are read-only. You can still open, print and download everything."
			}),
			!DESKTOP_APP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/plan",
				className: "inline-block text-sm font-semibold text-primary underline",
				children: writable ? "Plan & billing" : "Choose a plan"
			})
		]
	});
}
/** Desktop version: the address other office computers and phones use to open these books. */
var DESKTOP_APP = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1"
}["VITE_TALLKEEP_DESKTOP"];
var officeBridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
async function backupCall(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/backups${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var hourLabel = (h) => new Date(2e3, 0, 1, h).toLocaleTimeString([], {
	hour: "numeric",
	minute: "2-digit"
});
var sizeLabel = (n) => n === void 0 ? "" : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
var whenLabel = (iso) => new Date(iso).toLocaleString([], {
	dateStyle: "medium",
	timeStyle: "short"
});
/** Desktop: a copy of all the books every night, in a folder the office picks. */
function NightlyBackupCard() {
	const qc = useQueryClient();
	const { data, error } = useQuery({
		queryKey: ["nightly-backups"],
		queryFn: () => backupCall("GET"),
		refetchInterval: (q) => q.state.data?.busy ? 2e3 : 3e4
	});
	const [folder, setFolder] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [office, setOffice] = (0, import_react.useState)(false);
	const [oneCo, setOneCo] = (0, import_react.useState)("");
	const { data: cos = [] } = useQuery({
		queryKey: ["backup-companies"],
		queryFn: async () => {
			const { data: rows } = await supabase.from("companies").select("id,name").order("name");
			return rows ?? [];
		}
	});
	(0, import_react.useEffect)(() => {
		officeBridge().isOffice?.().then((v) => setOffice(!!v));
	}, []);
	(0, import_react.useEffect)(() => {
		if (data) setFolder(data.folder === data.defaultFolder ? "" : data.folder);
	}, [data?.folder, data?.defaultFolder]);
	const save = async (change) => {
		setSaving(true);
		try {
			qc.setQueryData(["nightly-backups"], await backupCall("PUT", "", change));
			toast.success("Saved.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setSaving(false);
		}
	};
	const runNow = async (company) => {
		setRunning(true);
		try {
			await backupCall("POST", "/run", company ? { company } : {});
			toast.success(company ? `Backup of ${cos.find((c) => c.id === company)?.name ?? "the company"} made.` : "Backup made.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setRunning(false);
			qc.invalidateQueries({ queryKey: ["nightly-backups"] });
		}
	};
	const pick = async () => {
		const f = await officeBridge().chooseFolder?.(data?.folder);
		if (f) {
			setFolder(f);
			await save({ folder: f });
		}
	};
	const restore = async () => {
		const r = await officeBridge().restoreBooks?.(data?.folder);
		if (r && !r.ok && !r.canceled) toast.error(r.error ?? "That didn't work.");
	};
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: ["Nightly backups: ", error.message]
	});
	const last = data?.last;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Nightly backup"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Every night Tallkeep saves a copy of all your books (every company, user and attached file) to a folder. The newest 30 are kept. From any backup you can put back all the companies, or just one. Pick a folder on another drive, like your Synology, so a broken computer can't take your books with it."
			})] }),
			last && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("rounded-xl border p-3 text-sm", last.ok ? "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100" : "border-red-300 bg-red-50 text-red-900 dark:border-red-800 dark:bg-red-950/40 dark:text-red-100"),
				children: last.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Last backup: ",
					whenLabel(last.at),
					" · ",
					sizeLabel(last.size)
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"The last backup didn't work (",
					whenLabel(last.at),
					"): ",
					last.error,
					data?.lastOk && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						" Last good one: ",
						whenLabel(data.lastOk.at),
						"."
					] })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: (e) => {
					e.preventDefault();
					save({ folder });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "backup-folder",
						children: "Backup folder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "backup-folder",
								value: folder,
								onChange: (e) => setFolder(e.target.value),
								placeholder: data?.defaultFolder ?? "",
								className: "min-w-0 flex-1 font-mono text-sm"
							}),
							office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => void pick(),
								disabled: saving,
								children: "Choose folder…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: saving,
								children: "Save folder"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"The folder is on the office computer. For a Synology, type its network path, like",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: "\\\\SYNOLOGY\\Backups\\Tallkeep"
							}),
							". Leave empty to keep backups on this computer only."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "backup-hour",
						children: "Back up every night at"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "backup-hour",
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						value: data?.hour ?? 1,
						onChange: (e) => void save({ hour: Number(e.target.value) }),
						disabled: saving,
						children: Array.from({ length: 24 }, (_, h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: h,
							children: hourLabel(h)
						}, h))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "If the computer is off then, it backs up soon after Tallkeep opens."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void runNow(),
					disabled: running || data?.busy,
					children: running || data?.busy ? "Backing up…" : "Back up all companies now"
				}), office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void restore(),
					children: "Put the books back from a backup…"
				})]
			}),
			cos.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						"aria-label": "Company to back up",
						className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
						value: oneCo,
						onChange: (e) => setOneCo(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Pick a company…"
						}), cos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !oneCo || running || data?.busy,
						onClick: () => void runNow(oneCo),
						children: "Back up only this company"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "A file with just that company, to keep or move to another Tallkeep."
					})
				]
			}),
			!!data?.files.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Newest backups in the folder"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y rounded-xl border text-sm",
					children: data.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 px-3 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate font-mono text-xs",
							children: f.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex shrink-0 items-center gap-2 text-muted-foreground",
							children: [sizeLabel(f.size), !office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupPutBack, { name: f.name })]
						})]
					}, f.name))
				})]
			})
		]
	});
}
function OfficeComputerCard() {
	const { data } = useQuery({
		queryKey: ["office-computer"],
		queryFn: async () => {
			return await (await fetch("/tallkeep/health")).json();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "This office computer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Your books are kept on this computer",
					data?.name ? ` (${data.name})` : "",
					". Other computers and phones on the office network open Tallkeep at:"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: (data?.addresses ?? []).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "font-mono text-lg font-semibold",
					children: a
				}, a))
			}),
			data?.connectUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"From anywhere (Tallkeep Connect):",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono font-semibold",
						children: data.connectUrl
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: data?.edition === "docker" ? "Tallkeep runs in Docker on this server, day and night, whether anyone is signed in or not." : data?.edition === "service" ? "Tallkeep runs as a Windows service: it keeps working even when no one is signed in to this computer. Keep the computer on." : "Keep this computer on, with Tallkeep open, while others work. Tallkeep keeps it from going to sleep (the screen can still turn off)."
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
