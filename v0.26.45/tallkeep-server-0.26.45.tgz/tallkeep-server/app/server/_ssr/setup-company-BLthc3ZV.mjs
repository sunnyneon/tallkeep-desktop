import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as db } from "./db-Bj3LfF9o.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { r as setWindowCompany, t as activeCompanyId } from "./company-BtzrFFFT.mjs";
import { n as BUSINESS_TYPES } from "./addons-gAbfjeRS.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { In as ArrowRight, Rn as ArrowLeft, dt as LoaderCircle, l as UserPlus, ln as ChevronDown, un as Check } from "../_libs/lucide-react.mjs";
import { a as useIsOwner } from "./queries-rvPoPDT4.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as addUser, s as listUsers, t as Field } from "./PartyForm-DO5dX3rw.mjs";
import { t as BankConnections } from "./BankConnections-CS3GG42k.mjs";
import { t as Route } from "./setup-company-BIhJJIje.mjs";
import { a as EmailSetupCard, i as CardPaymentsCard, n as AppIcon, o as FeaturePicker, s as RemindersCard, t as APPS } from "./AppsCatalog-CizPLw-2.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/setup-company-BLthc3ZV.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** The Welcome steps' People and Apps pages (first start of a new install). */
var desktop = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1",
	"VITE_TALLKEEP_VERSION": "0.26.45"
}["VITE_TALLKEEP_DESKTOP"];
function Head({ title, text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-xl font-semibold",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm text-muted-foreground",
		children: text
	})] });
}
var CAN = [
	{
		key: "admin",
		label: "Everything",
		text: "Like you: every page, Options and people."
	},
	{
		key: "changes",
		label: "Day-to-day work",
		text: "Quotes, invoices, stock and bills. No Options."
	},
	{
		key: "look",
		label: "Look only (free)",
		text: "Sees everything, changes nothing. For your accountant."
	}
];
/** Who else uses Tallkeep: add them now with a password you give them. */
function WelcomePeople({ companyId }) {
	const qc = useQueryClient();
	const { data: users } = useQuery({
		queryKey: ["users"],
		queryFn: () => listUsers()
	});
	const blank = {
		name: "",
		email: "",
		password: "",
		can: "changes"
	};
	const [f, setF] = (0, import_react.useState)(blank);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function add() {
		setBusy(true);
		try {
			await addUser({ data: {
				name: f.name,
				email: f.email,
				password: f.password,
				role: f.can === "admin" ? "admin" : "staff",
				zones: null,
				access: f.can === "admin" ? [] : [{
					company_id: companyId,
					is_admin: false,
					zones: null,
					read_only: f.can === "look"
				}]
			} });
			toast.success(`${f.email} can sign in now. Give them the password you typed.`);
			setF(blank);
			qc.invalidateQueries({ queryKey: ["users"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
				title: "Who else uses Tallkeep?",
				text: "Add the people who work with you. They sign in with their email and the password you give them, and can change it. Look-only people (like your accountant) are free."
			}),
			!!users?.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y rounded-xl border text-sm",
				children: users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center gap-2 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: u.name || u.email
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: u.email
						}),
						u.owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto rounded-full bg-muted px-2 py-0.5 text-xs",
							children: "Owner (you)"
						})
					]
				}, u.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-xl border bg-muted/20 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.name,
									onChange: (e) => setF({
										...f,
										name: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: f.email,
									onChange: (e) => setF({
										...f,
										email: e.target.value
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Password for them (8 or more)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									autoComplete: "new-password",
									value: f.password,
									onChange: (e) => setF({
										...f,
										password: e.target.value
									})
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-3",
						children: CAN.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setF({
								...f,
								can: c.key
							}),
							className: cn("rounded-xl border p-3 text-left text-sm transition", f.can === c.key ? "border-[var(--section)] bg-[var(--section-soft)]" : "hover:bg-muted/50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: c.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: c.text
							})]
						}, c.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void add(),
						disabled: busy || !f.email.trim() || f.password.length < 8,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), "Add this person"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Just you for now? Press Continue. Add people any time in Options → People."
			})
		]
	});
}
/** The few apps worth setting up on day one. Each opens in place; skip any of them. */
function WelcomeApps({ personal }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	const items = [
		...desktop && !personal ? [{
			key: "email",
			panel: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailSetupCard, {})
		}] : [],
		...desktop && !personal ? [{
			key: "payments",
			panel: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardPaymentsCard, { admin: true })
		}] : [],
		{
			key: "bank",
			panel: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BankConnections, { compact: true })
		},
		...!personal ? [{
			key: "reminders",
			panel: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindersCard, {})
		}] : []
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Head, {
			title: "Set up the important apps",
			text: "Each takes a minute. Skip any of them: they wait for you in Options → Apps, without a green dot until they're set up."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: items.map(({ key, panel }) => {
				const app = APPS.find((a) => a.key === key);
				if (!app) return null;
				const isOpen = open === key;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen(isOpen ? null : key),
						className: "flex w-full items-center gap-4 p-4 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { app }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: app.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: app.text
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex shrink-0 items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground",
								children: [isOpen ? "Close" : "Set up now", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: cn("h-3.5 w-3.5 transition", isOpen && "rotate-180") })]
							})
						]
					}), isOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t p-4",
						children: panel
					})]
				}, key);
			})
		})]
	});
}
var BUSINESS_STEPS = [
	"kind",
	"details",
	"email",
	"numbers",
	"apps",
	"data"
];
var WELCOME_STEPS = [
	"kind",
	"details",
	"email",
	"numbers",
	"people",
	"apps",
	"data"
];
var PERSONAL_STEPS = [
	"kind",
	"details",
	"apps",
	"data"
];
/** The Welcome steps are done (or skipped): Tallkeep opens normally from now on. */
async function welcomeDone(companyId) {
	if (!companyId) return;
	await db.from("company_settings").update({ welcome_done_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("company_id", companyId);
}
/** Document numbers each company keeps; label = what people call it. */
var COUNTERS = [
	{
		kind: "quote",
		label: "Quotes",
		prefix: "SQ-"
	},
	{
		kind: "sales_order",
		label: "Invoices",
		prefix: "INV-"
	},
	{
		kind: "purchase_order",
		label: "Purchase orders",
		prefix: "PO-"
	},
	{
		kind: "rma",
		label: "Returns (RMA)",
		prefix: "RMA-"
	},
	{
		kind: "stock_adjust",
		label: "Stock adjustments",
		prefix: "SA-"
	},
	{
		kind: "stock_transfer",
		label: "Stock transfers",
		prefix: "ST-"
	},
	{
		kind: "stock_count",
		label: "Count sheets",
		prefix: "CS-"
	}
];
function SetupCompany() {
	const { welcome } = Route.useSearch();
	const { data: isAdmin, isLoading } = useIsOwner();
	const [step, setStep] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [companyId, setCompanyId] = (0, import_react.useState)(null);
	const [info, setInfo] = (0, import_react.useState)({
		name: "",
		legal_name: "",
		tax_id: "",
		phone: "",
		email: "",
		website: "",
		address: "",
		mailing_address: ""
	});
	const [mail, setMail] = (0, import_react.useState)({
		from: "",
		replyTo: ""
	});
	const [start, setStart] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const startField = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		label: "Books start on",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			type: "date",
			value: start,
			onChange: (e) => setStart(e.target.value)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted-foreground",
			children: "The first day in these books: today, unless you pick an earlier day (like January 1) to bring in more of this year. What the accounts held the day before gives the opening balances."
		})]
	});
	const [numbers, setNumbers] = (0, import_react.useState)(COUNTERS.map((c) => ({
		...c,
		next: 1001
	})));
	const [bizType, setBizType] = (0, import_react.useState)(null);
	const [addons, setAddons] = (0, import_react.useState)([]);
	const [loaded, setLoaded] = (0, import_react.useState)(!welcome);
	(0, import_react.useEffect)(() => {
		if (!welcome) return;
		(async () => {
			const id = await activeCompanyId();
			if (!id) return setLoaded(true);
			setCompanyId(id);
			const { data } = await db.from("company_settings").select("*").eq("company_id", id).maybeSingle();
			const cs = data ?? {};
			const str = (k) => typeof cs[k] === "string" ? cs[k] : "";
			setInfo({
				name: str("name"),
				legal_name: str("legal_name"),
				tax_id: str("tax_id"),
				phone: str("phone"),
				email: str("email"),
				website: str("website"),
				address: str("address"),
				mailing_address: str("mailing_address")
			});
			setMail({
				from: str("email_from_name") || str("name"),
				replyTo: str("email_reply_to") || str("email")
			});
			if (str("books_start_date")) setStart(str("books_start_date"));
			const t = str("business_type");
			if (t && t in BUSINESS_TYPES) setBizType(t);
			if (Array.isArray(cs["addons"])) setAddons(cs["addons"]);
			const { data: ctr } = await db.from("doc_counters").select("kind, prefix, next_number").eq("company_id", id);
			const by = new Map((ctr ?? []).map((c) => [c.kind, c]));
			setNumbers((ns) => ns.map((n) => {
				const c = by.get(n.kind);
				return c ? {
					...n,
					prefix: c.prefix ?? n.prefix,
					next: Number(c.next_number) || n.next
				} : n;
			}));
			setLoaded(true);
		})();
	}, [welcome]);
	const personal = bizType === "personal";
	const steps = personal ? PERSONAL_STEPS : welcome ? WELCOME_STEPS : BUSINESS_STEPS;
	const at = steps[step] ?? "kind";
	const last = steps.length - 1;
	const label = {
		kind: "Kind",
		details: personal ? "About you" : "Company",
		email: "Email",
		numbers: "Numbers",
		people: "People",
		apps: "Apps",
		data: personal ? "Get started" : "Your data"
	};
	if (isLoading || !loaded) return null;
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6 text-muted-foreground",
		children: "Only an admin of every company can set up a new company."
	}) });
	const text = (k) => ({
		value: info[k],
		onChange: (e) => setInfo((x) => ({
			...x,
			[k]: e.target.value
		}))
	});
	const orNull = (v) => v.trim() || null;
	async function settings(patch) {
		const { error } = await db.from("company_settings").update(patch).eq("company_id", companyId);
		if (error) throw error;
	}
	async function next() {
		setBusy(true);
		try {
			if (at === "kind") {
				if (!bizType) throw new Error("Pick what kind of company it is.");
				if (companyId) await settings({
					business_type: bizType,
					addons
				});
			}
			if (at === "details") {
				if (!info.name.trim()) throw new Error(personal ? "Type a name for these books." : "Type the company name.");
				let id = companyId;
				if (!id) {
					const { data, error } = await db.rpc("create_company", { _name: info.name.trim() });
					if (error) throw error;
					id = data;
					setCompanyId(id);
					const sw = await db.rpc("set_active_company", { _c: id });
					if (sw.error) throw sw.error;
					setWindowCompany(id);
				}
				const { error } = await db.from("company_settings").update({
					name: info.name.trim(),
					legal_name: orNull(info.legal_name),
					tax_id: orNull(info.tax_id),
					phone: orNull(info.phone),
					email: orNull(info.email),
					website: orNull(info.website),
					address: orNull(info.address),
					mailing_address: orNull(info.mailing_address),
					business_type: bizType,
					addons,
					books_start_date: start || null
				}).eq("company_id", id);
				if (error) throw error;
				if (start) await db.rpc("rebuild_books");
				await db.from("companies").update({ name: info.name.trim() }).eq("id", id);
				setMail((m) => ({
					from: m.from || info.name.trim(),
					replyTo: m.replyTo || info.email.trim()
				}));
			}
			if (at === "email") await settings({
				email_from_name: orNull(mail.from),
				email_reply_to: orNull(mail.replyTo)
			});
			if (at === "numbers") {
				const rows = numbers.map((n) => ({
					company_id: companyId,
					kind: n.kind,
					prefix: n.prefix.trim(),
					next_number: Math.max(1, Math.floor(Number(n.next) || 1))
				}));
				const { error } = await db.from("doc_counters").upsert(rows, { onConflict: "company_id,kind" });
				if (error) throw error;
			}
			setStep((s) => s + 1);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function finish(to) {
		await welcomeDone(companyId);
		window.location.href = to;
	}
	const canSkip = at !== "kind" && at !== "data" && !(at === "details" && !companyId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		welcome && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold tracking-tight sm:text-4xl",
			children: "Welcome to Tallkeep"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: welcome ? "Welcome to Tallkeep" : "Set up a new company",
			text: welcome ? "A few short questions to get you started. Skip anything you like: it's all in Options later." : "A few short steps. You can change any of this later in Options.",
			actions: welcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: () => void finish("/"),
				children: "Skip the rest and open Tallkeep"
			}) : void 0
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "flex flex-wrap gap-2",
			children: steps.map((k, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: `flex items-center gap-1.5 rounded-full px-3 py-1 text-sm ${i === step ? "bg-[var(--section)] font-medium text-white" : i < step ? "bg-muted text-foreground" : "bg-muted/50 text-muted-foreground"}`,
				children: [
					i < step ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [i + 1, "."] }),
					" ",
					label[k]
				]
			}, k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
			children: [
				at === "kind" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "What is this company for?",
					text: "Pick one. Tallkeep sets up only what it needs; you can change it any time in Options → Features.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturePicker, {
						type: bizType,
						features: addons,
						onType: (t) => {
							setBizType(t);
							setAddons([...BUSINESS_TYPES[t].features]);
						},
						onToggle: (k, on) => setAddons((a) => on ? [...a, k] : a.filter((x) => x !== k))
					})
				}),
				at === "details" && personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "About you",
					text: "A name for these books, and how to reach you. Only the name is needed.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Name for these books",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									autoFocus: true,
									placeholder: "e.g. Kalyani Family",
									...text("name")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									...text("email")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Address",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("address")
								})
							}),
							startField
						]
					})
				}),
				at === "details" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "Company details",
					text: "Printed on quotes, invoices and purchase orders. Only the name is required now.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Company name (as customers know it)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									autoFocus: true,
									placeholder: "e.g. Sunny Neon Inc.",
									...text("name")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Legal name, if different",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("legal_name") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Tax ID (EIN)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "12-3456789",
									...text("tax_id")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									...text("email")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Website",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Address",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("address")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mailing address for payments, if different",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 3,
									...text("mailing_address")
								})
							}),
							startField
						]
					})
				}),
				at === "email" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					title: "Email",
					text: "How quotes, invoices and follow-ups look in your customers' inbox.",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name customers see as the sender",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: mail.from,
								onChange: (e) => setMail({
									...mail,
									from: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Customer replies go to",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								value: mail.replyTo,
								onChange: (e) => setMail({
									...mail,
									replyTo: e.target.value
								})
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Emails are sent from our shared address for now; when this company has its own email domain, we can send from it."
					})]
				}),
				at === "numbers" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: "Document numbers",
					text: "Start where your old system left off, so numbers continue without gaps or repeats.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y rounded-xl border",
						children: numbers.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 px-4 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-40 font-medium",
									children: n.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs text-muted-foreground",
									children: ["Starts with", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-20",
										value: n.prefix,
										onChange: (e) => setNumbers((ns) => ns.map((x, j) => j === i ? {
											...x,
											prefix: e.target.value
										} : x))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-xs text-muted-foreground",
									children: ["Next number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-28",
										type: "number",
										min: 1,
										value: n.next,
										onChange: (e) => setNumbers((ns) => ns.map((x, j) => j === i ? {
											...x,
											next: Number(e.target.value)
										} : x))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										"first one: ",
										n.prefix,
										String(Math.max(1, Math.floor(Number(n.next) || 1))).padStart(6, "0")
									]
								})
							]
						}, n.kind))
					})
				}),
				at === "people" && companyId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomePeople, { companyId }),
				at === "apps" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeApps, { personal }),
				at === "data" && personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: `${info.name.trim() || "Your books"} ${info.name.trim() ? "is" : "are"} ready`,
					text: "You're now working in these books. Where would you like to start?",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Drop in bank and card statements",
								text: "Drag PDFs or photos into the Shoebox; Tallkeep reads them and records each line.",
								onClick: () => void finish("/shoebox")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Put in what you have today",
								text: "The balance of each bank account, card, loan and your home, from the Chart of Accounts.",
								onClick: () => void finish("/accounts")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Start with a budget",
								text: "Plan what to spend each month in each category.",
								onClick: () => void finish("/budget")
							})
						]
					})
				}),
				at === "data" && !personal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					title: `${info.name.trim() || "Your company"} is ready`,
					text: "You're now working in this company. Bring in your data, or start with an empty company.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Bring in data from inFlow",
								text: "Products, customers, vendors, orders and stock from an inFlow export.",
								onClick: () => void finish("/settings#import")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Bring in data from QuickBooks",
								text: "Customers, vendors, items, stock on hand and open invoices, step by step.",
								onClick: () => void finish("/settings#quickbooks")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								title: "Start empty",
								text: "Add products and customers as you go.",
								onClick: () => void finish("/")
							})
						]
					})
				}),
				step < last && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between gap-2 border-t pt-4",
					children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => setStep((s) => s - 1),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
					}) : welcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							children: "Cancel"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-wrap justify-end gap-2",
						children: [canSkip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setStep((s) => s + 1),
							disabled: busy,
							children: "Skip, set up later"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => void next(),
							disabled: busy,
							children: [busy ? "Saving…" : at === "details" && !companyId ? personal ? "Create my books" : "Create the company" : at === "kind" || at === "people" || at === "apps" ? "Continue" : "Save and continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						})]
					})]
				})
			]
		})
	] });
}
function Section({ title, text, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: text
		})] }), children]
	});
}
function Choice({ title, text, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		disabled,
		className: "rounded-xl border p-4 text-left text-sm transition-colors hover:border-[var(--section)] disabled:cursor-not-allowed disabled:opacity-50",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-xs text-muted-foreground",
			children: text
		})]
	});
}
//#endregion
export { SetupCompany as component };
