//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D0615qCf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/notice-emails",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BoHtEJk0.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bj7TfEFb.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BD-8Yh7d.js",
			"/assets/company-PTYyseyT.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BoHtEJk0.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CNDSS_Io.js",
			"/assets/createServerFn-GK1EadMh.js",
			"/assets/log-out-B8h8CCbM.js",
			"/assets/auth-middleware-C7pkLYev.js",
			"/assets/testers.functions-CEpCdHBr.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-FkOIw31K.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-Cafer9ko.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/accounting-F33_vDPC.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-CunnCv4Y.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/dist-D3Yo9jy0.js",
			"/assets/dialog-CBt4jz2P.js",
			"/assets/queries-CQt3Nsb3.js",
			"/assets/input--jdryr8T.js",
			"/assets/label-BOOhXacA.js",
			"/assets/textarea-CSRD9aUz.js",
			"/assets/shoebox-UocPwatb.js",
			"/assets/reports-BKheYWMq.js",
			"/assets/access-CseZuwAq.js",
			"/assets/theme-d2gEvMht.js",
			"/assets/Logo-ClQG3335.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-BgJheAt_.js",
			"/assets/log-out-B8h8CCbM.js",
			"/assets/admin.functions-DJMOOknH.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-ClQG3335.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DB3w0rfT.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/label-BOOhXacA.js",
			"/assets/Logo-ClQG3335.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-CjzImR7-.js",
			"/assets/testers.functions-CEpCdHBr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/coupons.functions-B-JD1UIQ.js",
			"/assets/buy.functions-Boy5AL0s.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DZzRVAVQ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/downloads.functions-CiJa02Iv.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-2UTY8KPX.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/label-BOOhXacA.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BWwPoe_C.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/label-BOOhXacA.js",
			"/assets/Logo-ClQG3335.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BPPzo3M8.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/upgrade.functions-B59oy5Fa.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-VqJrMn5W.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/label-BOOhXacA.js",
			"/assets/Logo-ClQG3335.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-uvZ5jn5Z.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-BGSte18s.js", "/assets/StockDocList-CL0ad_sz.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-AqtP7gmZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/ai-BHR0vB3Y.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BjcreIWD.js",
			"/assets/BankConnections-Bsm8CvQl.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CHM5REHv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DNUwfNvQ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-Bsm8CvQl.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/ai-BHR0vB3Y.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/loans-UH1TvG2K.js",
			"/assets/TxnEditor-QBGhseB9.js",
			"/assets/feedWaiting-BLc3jadZ.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Ds3miGax.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-bXRTNtHH.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-veLHUFLg.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/personal-DZqXbt4a.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/WhoPicker-D_EqVNbq.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CgCn68OC.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CWe84NJF.js", "/assets/AccountRegister-Cyoh-KtV.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CzWgw_Rs.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CX-MTaXE.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/money-BHf7C-uI.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-CIW-gWNx.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BHR0vB3Y.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-JgZNxg5D.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-B663ermm.js", "/assets/StockDocList-CL0ad_sz.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-hvs1Qmnb.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-C2FWjI83.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/QuickBooksImport-Bs7eZNAr.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-wePXBHoF.js", "/assets/PartyList-Dv29lgk3.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-_Jh9WRIL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DIo8gjRS.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/storage.functions-DC4btj_B.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BdMntSg4.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-CaLKiMdr.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/booksStart-D_KTTJNO.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-CtOlGSwe.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BolBWbGo.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-DWRPdWWH.js", "/assets/ChangeHistory-BK4GPGoD.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-DUsj23AH.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/members-Cdt_Qpxg.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-wHwryj0R.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/personal-DZqXbt4a.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/WhoPicker-D_EqVNbq.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-D3LmAMRa.js", "/assets/SalesList-Bf-O9Q8Z.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CRRDRtoA.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BAJ-VdsZ.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DAaOLHU8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CV8hcVwk.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/loans-UH1TvG2K.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-C_EtH0Jj.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-B2PsNKWc.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-gQwg31Fv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/personal-DZqXbt4a.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/WhoPicker-D_EqVNbq.js",
			"/assets/reminders-D8PR7zdE.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-Cj_6zdgw.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CLE9YAtQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/personal-DZqXbt4a.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/WhoPicker-D_EqVNbq.js",
			"/assets/generateCategoricalChart-CvRkqwhD.js",
			"/assets/Area-D18LaIzQ.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-t33ftHu8.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/generateCategoricalChart-CvRkqwhD.js",
			"/assets/PlCharts-CtOlGSwe.js",
			"/assets/BarChart-Cpdbv1mX.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DdpPIVb8.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/balances-bXRTNtHH.js",
			"/assets/money-BHf7C-uI.js",
			"/assets/DecimalInput-HJC_CQl3.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BH0tmh8h.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DG91dg6t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/storage.functions-DC4btj_B.js",
			"/assets/coupons.functions-B-JD1UIQ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DbU50z0o.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DIhjBcvN.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/DecimalInput-HJC_CQl3.js",
			"/assets/StockDialogs-Biu48LX9.js",
			"/assets/checkbox-D99ixxU0.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-BzRIGmVQ.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DdP1KDnB.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DwWY_wgO.js", "/assets/SalesList-Bf-O9Q8Z.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-Bvlsz2R9.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/ai-BHR0vB3Y.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DC4btj_B.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-D8GnqhGW.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/money-BHf7C-uI.js",
			"/assets/badge-CC0KgTu0.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-UMmY-qS3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-DPYau_sq.js", "/assets/AccountRegister-Cyoh-KtV.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-B1gkrEB2.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/MoneyAccountPick-BPPrv3ss.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DjuPbNYu.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-TLkf5Ov8.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/RepeatInvoice-CDYulOi0.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Da64UipG.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-CvRkqwhD.js",
			"/assets/BarChart-Cpdbv1mX.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-pdLbxi9Z.js", "/assets/SalesList-Bf-O9Q8Z.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-8eDhhKI6.js", "/assets/SalesList-Bf-O9Q8Z.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-DSMyiGk9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-CpMUbLEk.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/serials-W3gUB_zy.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BvcyM16K.js",
			"/assets/AppsCatalog-CaWBBvG_.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-D5h7gEZi.js",
			"/assets/switch-B2PsNKWc.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/QuickBooksImport-Bs7eZNAr.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DRG7_tny.js",
			"/assets/footers-C-Pe-sSj.js",
			"/assets/PrintFrame-BtiY6uhL.js",
			"/assets/checkbox-D99ixxU0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Ba1ywxd4.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-T-HSI-H4.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-CaWBBvG_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-Bsm8CvQl.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BF84qRxA.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/StockDialogs-Biu48LX9.js",
			"/assets/photos-DRG7_tny.js",
			"/assets/stockmove-CpJ3YDi3.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-C9Q4pJ3S.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/loans-UH1TvG2K.js",
			"/assets/feedWaiting-BLc3jadZ.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DC4btj_B.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DenBhcw7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/PrintFrame-BtiY6uhL.js",
			"/assets/DocPdf-BHaRKY7K.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DD60sE0O.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/MoneyAccountPick-BPPrv3ss.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Ba1ywxd4.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BCd9I6Mn.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/StockDialogs-Biu48LX9.js",
			"/assets/stockmove-CpJ3YDi3.js",
			"/assets/checkbox-D99ixxU0.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-CYwclQHg.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/members-Cdt_Qpxg.js",
			"/assets/WhoPicker-D_EqVNbq.js",
			"/assets/reminders-D8PR7zdE.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-51Ds-wDs.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/tickets.functions-DEVIN2Ic.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-EQfA1fL0.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Ba1ywxd4.js",
			"/assets/support.functions-oALHh-sA.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-hGOZbQir.js", "/assets/StockDocList-CL0ad_sz.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-C_oyMZuK.js", "/assets/PartyList-Dv29lgk3.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-CpqOlAut.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/tickets.functions-DEVIN2Ic.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-Di--ggx7.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/workorders-OuD7SZLE.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DcDze3s2.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-TZBj4Glj.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/coupons.functions-B-JD1UIQ.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BWb-VVox.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/AdminAccount-PqjnWLNy.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-DBUjZjt1.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/downloads.functions-CiJa02Iv.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C3yMZLn-.js",
			"/assets/createServerFn-GK1EadMh.js",
			"/assets/auth-middleware-C7pkLYev.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-D3XdJTk7.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Ccv3mHuP.js",
			"/assets/testers.functions-CEpCdHBr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-Ddv9o5I1.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-SUqCdjfH.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-Boy5AL0s.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DiF-b8yk.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/textarea-CSRD9aUz.js",
			"/assets/support.functions-oALHh-sA.js",
			"/assets/HelpParts-DDP3H8jk.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BUyGTZYh.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-GaAe-ESH.js",
			"/assets/manual._slug-DJ6NbtfZ.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DQ8KFa5Q.js",
			"/assets/createServerFn-GK1EadMh.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-CuAT5i4N.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-B59oy5Fa.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CMJk8fFX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-BHR0vB3Y.js",
			"/assets/personal-DZqXbt4a.js",
			"/assets/reminders-D8PR7zdE.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BoZY7oub.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/AdminAccount-PqjnWLNy.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-6_MDWKPS.js", "/assets/ManualFrame-GaAe-ESH.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CrX7ekD0.js", "/assets/AccountRegister-Cyoh-KtV.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DtiUjxNB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/OriginalLink-DUURW8-H.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/realestate-B0fHNAFz.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-DzpG1Clx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/realestate-B0fHNAFz.js",
			"/assets/money-BHf7C-uI.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DSrf-747.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-D_KTTJNO.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/SideList-cO9IPuwT.js",
			"/assets/PartyHistory-B-66pNsh.js",
			"/assets/tabs-DqKNQF5O.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CQCAn2I4.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/ChangeHistory-BK4GPGoD.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/SideList-cO9IPuwT.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-HJC_CQl3.js",
			"/assets/StockDialogs-Biu48LX9.js",
			"/assets/NewProductDialog-BB9obRZq.js",
			"/assets/MoneyAccountPick-BPPrv3ss.js",
			"/assets/footers-C-Pe-sSj.js",
			"/assets/PrintFrame-BtiY6uhL.js",
			"/assets/serials-W3gUB_zy.js",
			"/assets/SerialsBox-Bt9Ne3Bb.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Cyu1-YXv.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BK4GPGoD.js",
			"/assets/switch-B2PsNKWc.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CC0KgTu0.js",
			"/assets/SideList-cO9IPuwT.js",
			"/assets/tabs-DqKNQF5O.js",
			"/assets/StockDialogs-Biu48LX9.js",
			"/assets/photos-DRG7_tny.js",
			"/assets/stockmove-CpJ3YDi3.js",
			"/assets/serials-W3gUB_zy.js",
			"/assets/SerialsBox-Bt9Ne3Bb.js",
			"/assets/workorders-OuD7SZLE.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BAZQrS4w.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/ChangeHistory-BK4GPGoD.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/booksStart-D_KTTJNO.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/SideList-cO9IPuwT.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-HJC_CQl3.js",
			"/assets/NewProductDialog-BB9obRZq.js",
			"/assets/MoneyAccountPick-BPPrv3ss.js",
			"/assets/footers-C-Pe-sSj.js",
			"/assets/PrintFrame-BtiY6uhL.js",
			"/assets/cardpay-Dz-sBxaB.js",
			"/assets/checkbox-D99ixxU0.js",
			"/assets/serials-W3gUB_zy.js",
			"/assets/workorders-OuD7SZLE.js",
			"/assets/RepeatInvoice-CDYulOi0.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DEVIN2Ic.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D228lnvi.js",
			"/assets/select-DNRbJKLA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/SideList-cO9IPuwT.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BqiB2mZ5.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/quickadd-C16HQkpR.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-Ba1ywxd4.js",
			"/assets/support.functions-oALHh-sA.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-CFFdKZjV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DV8GEuNr.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/SideList-cO9IPuwT.js",
			"/assets/PartyHistory-B-66pNsh.js",
			"/assets/tabs-DqKNQF5O.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-D8Lum0k6.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/sales-JgZNxg5D.js",
			"/assets/footers-C-Pe-sSj.js",
			"/assets/tickets.functions-DEVIN2Ic.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-VZm4mx2X.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/input--jdryr8T.js",
			"/assets/skeleton-afN-PnPb.js",
			"/assets/AdminAccount-PqjnWLNy.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CYsLZx9Z.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-DQmkIFDr.js",
			"/assets/textarea-CSRD9aUz.js",
			"/assets/support-Ba1ywxd4.js",
			"/assets/support.functions-oALHh-sA.js",
			"/assets/HelpParts-DDP3H8jk.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BZ92oXR6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-afN-PnPb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
