import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-dTuQI17S.mjs";
import { i as EDITION_KEYS, n as ADDON_KEYS } from "./editions-Ccs--JHP.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy.functions-DLhDO-NE.js
/**
* Buying Tallkeep Desktop online: the Buy page (no sign-in) works out the price, sends the
* customer to Stripe to pay, and once Stripe says it's paid, makes the license key and emails it.
* Needs the STRIPE_SECRET_KEY secret (and LICENSE_PRIVATE_KEY, RESEND_API_KEY).
*/
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var getBuyInfo = createServerFn({ method: "GET" }).handler(createSsrRpc("222764ceb133430e5ba744ea2a49ff737733dc9183d46b15301b1c7e2ef2bb4a"));
async function stripe(path, form) {
	const key = process.env["STRIPE_SECRET_KEY"];
	if (!key) throw new Error("Buying online isn't open yet.");
	const base = process.env["STRIPE_API_BASE"] || "https://api.stripe.com";
	let res;
	try {
		res = await fetch(`${base}/v1/${path}`, {
			method: form ? "POST" : "GET",
			headers: {
				Authorization: `Bearer ${key}`,
				...form ? { "Content-Type": "application/x-www-form-urlencoded" } : {}
			},
			body: form ?? null
		});
	} catch {
		throw new Error("Couldn't reach the payment service. Try again in a minute.");
	}
	const body = await res.json();
	if (!res.ok) throw new Error(body.error?.message ?? `Stripe said ${res.status}`);
	return body;
}
var cleanAddons = (a) => [...new Set((Array.isArray(a) ? a : []).filter((x) => ADDON_KEYS.includes(x)))];
var startCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	const to = String(d.to ?? "").trim().slice(0, 100);
	const email = String(d.email ?? "").trim().slice(0, 200);
	if (!to) throw new Error("Type your name or your business name.");
	if (!/^\S+@\S+\.\S+$/.test(email)) throw new Error("Type your email address.");
	if (!EDITION_KEYS.includes(d.edition)) throw new Error("Pick Personal, Service or Full.");
	const extraCompanies = Math.floor(Number(d.extraCompanies) || 0);
	const extraUsers = Math.floor(Number(d.extraUsers) || 0);
	if (!(extraCompanies >= 0 && extraCompanies <= 100)) throw new Error("Extra companies: 0 to 100.");
	if (!(extraUsers >= 0 && extraUsers <= 500)) throw new Error("Extra people: 0 to 500.");
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	const code = String(d.code ?? "").trim().toUpperCase().slice(0, 20);
	return {
		to,
		email,
		edition: d.edition,
		addons: cleanAddons(d.addons),
		extraCompanies,
		extraUsers,
		origin: d.origin,
		code
	};
}).handler(createSsrRpc("f9954db22f4c3a8f70b27c51d850a744ed1538ae448929e6afd51e15b23278e7"));
/** What a license has now (for the Upgrade form). */
var lookUpLicense = createServerFn({ method: "POST" }).inputValidator((d) => ({ key: String(d.key ?? "").slice(0, 4e3) })).handler(createSsrRpc("6bff944da1ec056947accb2562117e32d4a984b372336f1ff590ca9320773259"));
/** Price of moving from what's owned to the new edition and add-ons (today's prices). */
var startUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!EDITION_KEYS.includes(d.edition)) throw new Error("Pick Personal, Service or Full.");
	if (!/^\S+@\S+\.\S+$/.test(String(d.email ?? ""))) throw new Error("Type your email address.");
	if (!/^https?:\/\/[^/\s]+$/.test(String(d.origin ?? ""))) throw new Error("Bad address.");
	return {
		key: String(d.key ?? "").slice(0, 4e3),
		email: String(d.email).trim(),
		edition: d.edition,
		addons: cleanAddons(d.addons),
		origin: d.origin
	};
}).handler(createSsrRpc("46cc758b5b42e5b4c6456feb57bf9342a9a5cd96381845478fe01d1e281ecc64"));
/** The upgrade price, for the form (no payment). */
var quoteUpgrade = createServerFn({ method: "POST" }).inputValidator((d) => ({
	key: String(d.key ?? "").slice(0, 4e3),
	edition: EDITION_KEYS.includes(d.edition) ? d.edition : "full",
	addons: cleanAddons(d.addons)
})).handler(createSsrRpc("42c096807572ac95bb24b4bd4c91a75b9435bd09acd83552f994694d9c8870d5"));
/**
* Make the key for a paid checkout (once). Asks Stripe itself whether it's paid, so a made-up
* request can't make a key. Called by the thank-you page and by Stripe's webhook.
*/
async function fulfill(session) {
	if (!/^cs_[A-Za-z0-9_]+$/.test(session)) return { status: "unpaid" };
	const db = await admin();
	const existing = async () => {
		const { data } = await db.from("desktop_licenses").select("id,license_key,email,notes").eq("stripe_session", session).maybeSingle();
		return data;
	};
	const { wasMailed } = await import("./license.server-Bu3IQdFy.mjs");
	const had = await existing();
	if (had) return {
		status: "paid",
		id: had.id,
		key: had.license_key,
		email: had.email,
		mailed: wasMailed(had.notes)
	};
	const s = await stripe(`checkout/sessions/${session}`);
	if (s.payment_status !== "paid") return { status: "unpaid" };
	if (s.metadata?.["product"] === "tallkeep_edition_upgrade") return fulfillUpgrade(session, s);
	if (s.metadata?.["product"] !== "tallkeep_desktop") return { status: "unpaid" };
	const m = s.metadata;
	const email = s.customer_details?.email || s.customer_email || null;
	const until = /* @__PURE__ */ new Date();
	until.setFullYear(until.getFullYear() + 1);
	const { createLicense, mailLicense, mailNote } = await import("./license.server-Bu3IQdFy.mjs");
	const lic = {
		to: m["to"] || s.customer_details?.name || "Tallkeep customer",
		email,
		companies: Number(m["companies"]) || 1,
		users: Number(m["users"]) || 1,
		updatesUntil: until.toISOString().slice(0, 10),
		computers: 1,
		notes: `Paid online $${((s.amount_total ?? 0) / 100).toFixed(2)}`,
		stripeSession: session,
		paidCents: s.amount_total ?? null,
		edition: EDITION_KEYS.includes(m["edition"]) ? m["edition"] : null,
		addons: m["edition"] ? cleanAddons((m["addons"] ?? "").split(",").filter(Boolean)) : null
	};
	let made;
	try {
		made = await createLicense(db, lic);
	} catch (e) {
		const again = await existing();
		if (again) return {
			status: "paid",
			id: again.id,
			key: again.license_key,
			email: again.email,
			mailed: wasMailed(again.notes)
		};
		throw e;
	}
	const sent = email ? await mailLicense({
		to: email,
		name: lic.to,
		id: made.id,
		key: made.key,
		companies: lic.companies,
		users: lic.users,
		updatesUntil: lic.updatesUntil,
		origin: m["origin"] || "https://app.tallkeep.com"
	}) : {
		ok: false,
		why: "no email address"
	};
	if (!sent.ok) console.error("[buy] license email", sent.why);
	if (m["tester_code"]) {
		const { markTesterCodeUsed } = await import("./testers.functions-CNToLQxP.mjs").then((n) => n.c);
		await markTesterCodeUsed(m["tester_code"], session).catch(() => null);
	}
	await db.from("desktop_licenses").update({ notes: `${lic.notes} · ${mailNote(sent)}` }).eq("id", made.id);
	const mailed = sent.ok;
	return {
		status: "paid",
		id: made.id,
		key: made.key,
		email,
		mailed
	};
}
async function fulfillUpgrade(session, s) {
	const db = await admin();
	const m = s.metadata ?? {};
	const id = m["license"] ?? "";
	const { data: done } = await db.from("desktop_licenses").select("id,license_key,email,upgrades").eq("id", id).maybeSingle();
	const row = done;
	if (!row) return { status: "unpaid" };
	if ((row.upgrades ?? []).some((u) => u.session === session)) return {
		status: "paid",
		id: row.id,
		key: row.license_key,
		email: row.email,
		mailed: true
	};
	const { upgradeLicense, mailLicense } = await import("./license.server-Bu3IQdFy.mjs");
	const num = (x) => x ? Number(x) || null : null;
	const up = await upgradeLicense(db, id, {
		edition: m["edition"] ?? "full",
		addons: cleanAddons((m["addons"] ?? "").split(",").filter(Boolean)),
		companies: num(m["companies"]),
		users: num(m["users"]),
		paidCents: s.amount_total ?? null,
		session
	});
	const email = s.customer_details?.email || s.customer_email || up.email;
	const sent = email ? await mailLicense({
		to: email,
		name: up.to,
		id: up.id,
		key: up.key,
		companies: num(m["companies"]),
		users: num(m["users"]),
		updatesUntil: up.updatesUntil,
		origin: m["origin"] || "https://app.tallkeep.com"
	}) : {
		ok: false,
		why: "no email address"
	};
	return {
		status: "paid",
		id: up.id,
		key: up.key,
		email,
		mailed: sent.ok
	};
}
var getOrder = createServerFn({ method: "GET" }).inputValidator((d) => ({ session: String(d.session ?? "") })).handler(createSsrRpc("9c23602d2497e87db527c2f51f96da388bc05788ddb83ab0c420cfc762bcd869"));
//#endregion
export { fulfill, getBuyInfo, getOrder, lookUpLicense, quoteUpgrade, startCheckout, startUpgrade };
