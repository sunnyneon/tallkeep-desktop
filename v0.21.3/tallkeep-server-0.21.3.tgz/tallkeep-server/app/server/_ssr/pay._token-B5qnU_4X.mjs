import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay._token-B5qnU_4X.js
var $$splitComponentImporter = () => import("./pay._token-CSu9YVzS.mjs");
/** A customer pays an invoice by card: no sign-in, Stripe's secure checkout. */
var Route = createFileRoute("/pay/$token")({
	ssr: false,
	validateSearch: (s) => typeof s["session"] === "string" ? { session: s["session"] } : {},
	head: () => ({ meta: [{ title: "Pay invoice" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
