import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-wPWcKL7O.mjs";
import { en as CircleCheck, lt as LoaderCircle, st as Lock } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Route } from "./pay._token-B5qnU_4X.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay._token-CSu9YVzS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** The customer's "Pay now" page (no sign-in). See pay.server.ts. */
var tokenOk = (t) => typeof t === "string" && /^[A-Za-z0-9_-]{10,40}$/.test(t);
var getPayPage = createServerFn({ method: "GET" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	return {
		token: d.token,
		session: /^cs_[A-Za-z0-9_]+$/.test(d.session ?? "") ? d.session : void 0
	};
}).handler(createSsrRpc("65167bf74740ab17c0fbab7a39a651e64108b27c734b7bc92f51ab7af27647c0"));
var startPayCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	if (!/^https?:\/\/[^/\s]+$/.test(d.origin)) throw new Error("Bad address.");
	return d;
}).handler(createSsrRpc("1451e52a03e1d052f3d1a13763407804acbc263dab8122da9b78e14acc3f6c68"));
/** A customer pays an invoice by card: no sign-in, Stripe's secure checkout. */
var money = (cents, cur) => (cents / 100).toLocaleString("en-US", {
	style: "currency",
	currency: cur.toUpperCase()
});
function PayPage() {
	const { token } = Route.useParams();
	const { session } = Route.useSearch();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data, isLoading, error } = useQuery({
		queryKey: [
			"pay",
			token,
			session
		],
		queryFn: () => getPayPage({ data: {
			token,
			session
		} }),
		refetchInterval: (q) => session && q.state.data?.status === "open" ? 3e3 : false
	});
	async function pay() {
		setBusy(true);
		try {
			const r = await startPayCheckout({ data: {
				token,
				origin: window.location.origin
			} });
			window.location.href = r.url;
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) : error || !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "This payment link isn't right or has ended. Please contact the business that sent it."
				}) : data.status === "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-12 w-12 text-emerald-600" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-2xl font-semibold",
							children: "Paid. Thank you!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								data.business,
								" received ",
								money(data.paidCents ?? data.amountCents, data.currency),
								data.number ? ` for invoice ${data.number}` : "",
								". You can keep this page as your receipt."
							]
						})
					]
				}) : data.status === "canceled" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"This invoice can't be paid here anymore. Please contact ",
						data.business,
						"."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: data.business
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-2xl font-semibold",
							children: ["Invoice ", data.number ?? ""]
						}),
						data.customer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: ["For ", data.customer]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-muted/40 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Amount due"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-semibold",
							children: money(data.amountCents, data.currency)
						})]
					}),
					session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Confirming your payment…"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						className: "w-full",
						onClick: () => void pay(),
						disabled: busy,
						children: [
							busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
							"Pay ",
							money(data.amountCents, data.currency),
							" by card"
						]
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: "Secure payment by Stripe. Your card details go to Stripe, never to the business or Tallkeep."
			})]
		})
	});
}
//#endregion
export { PayPage as component };
