import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/stays-q4Frvncx.js
var $$splitComponentImporter = () => import("./stays-DlsX1E1A.mjs");
var Route = createFileRoute("/_authenticated/stays")({
	validateSearch: (s) => typeof s["unit"] === "string" ? { unit: s["unit"] } : {},
	head: () => ({ meta: [{ title: "Short-Term Stays · Tallkeep" }, {
		name: "description",
		content: "Airbnb, VRBO and direct bookings: calendar, guests, payouts and occupancy."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
