import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-wPWcKL7O.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { D as Text, d as Image, h as Link, j as View, s as Document, y as Page } from "../_libs/@react-pdf/image+[...].mjs";
import { t as StyleSheet } from "../_libs/react-pdf__renderer.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/DocPdf-CLhkFiK8.js
var import_jsx_runtime = require_jsx_runtime();
/** Emails a day for one company: free trial, and paid plans. Tallkeep's own account: no limit. */
/** Stop when the company has sent its emails for today; else count this one. */
/** Send a quote / invoice / PO as a PDF from the company (see mailer.server.ts). */
var sendDocEmail = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const ok = (e) => /^\S+@\S+\.\S+$/.test(e);
	if (!d.to.length || !d.to.every(ok)) throw new Error("Type a valid email for the customer.");
	if (!d.cc.every(ok)) throw new Error("One of the copy addresses isn't a valid email.");
	if (d.to.length + d.cc.length > 10) throw new Error("Send to 10 addresses at most.");
	if (!d.pdfBase64) throw new Error("The PDF is missing.");
	if (d.pdfBase64.length > 14e6) throw new Error("The PDF is too big to email.");
	return d;
}).handler(createSsrRpc("a7f32f276406e2d7206bbca2e8c5fc871d65fb4425fcac828b84b5aae9eb123f"));
var RED = "#E30613";
var s = StyleSheet.create({
	page: {
		paddingTop: 34,
		paddingBottom: 60,
		paddingHorizontal: 44,
		fontSize: 9.5,
		fontFamily: "Helvetica",
		color: "#111"
	},
	row: { flexDirection: "row" },
	between: {
		flexDirection: "row",
		justifyContent: "space-between"
	},
	bold: { fontFamily: "Helvetica-Bold" },
	title: {
		fontSize: 24,
		fontFamily: "Helvetica-Bold",
		color: RED,
		textAlign: "right"
	},
	small: {
		fontSize: 8,
		color: "#555"
	},
	th: {
		fontFamily: "Helvetica-Bold",
		fontSize: 8.5,
		paddingVertical: 4
	},
	td: { paddingVertical: 5 },
	pageFooter: {
		position: "absolute",
		bottom: 24,
		left: 44,
		right: 44,
		textAlign: "center",
		fontSize: 8.5,
		fontFamily: "Helvetica-Oblique",
		color: "#333"
	},
	pageNo: {
		position: "absolute",
		bottom: 12,
		right: 44,
		fontSize: 7,
		color: "#888"
	}
});
function DocPdf({ d }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Document, {
		title: `${d.title} ${d.facts[0]?.[1] ?? ""}`,
		author: d.company.name,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
			size: "LETTER",
			style: s.page,
			wrap: true,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: s.between,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
						style: { maxWidth: "55%" },
						children: [
							d.logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
								src: d.logo,
								style: {
									height: 40,
									objectFit: "contain",
									marginBottom: 6,
									alignSelf: "flex-start"
								}
							}) : null,
							d.company.addressLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
								style: {
									fontSize: 7,
									fontFamily: "Helvetica-Bold",
									color: "#666",
									marginBottom: 1
								},
								children: d.company.addressLabel
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
								style: s.bold,
								children: d.company.name
							}),
							d.company.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: d.company.address }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: [
								d.company.phone,
								d.company.email,
								d.company.website
							].filter(Boolean).join(" · ") })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: s.title,
							children: d.title
						}),
						d.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: {
								textAlign: "right",
								fontSize: 8
							},
							children: d.subtitle
						}) : null,
						d.facts.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, {
							style: {
								textAlign: "right",
								marginTop: 2
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Text, {
								style: s.bold,
								children: [k, " "]
							}), v]
						}, k))
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: [s.row, { marginTop: 18 }],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
						style: {
							width: "50%",
							paddingRight: 12
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [
								s.bold,
								s.small,
								{ marginBottom: 3 }
							],
							children: d.leftTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: d.left })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
						style: { width: "50%" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [
								s.bold,
								s.small,
								{ marginBottom: 3 }
							],
							children: d.rightTitle
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: d.right })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: [s.row, {
						marginTop: 16,
						borderBottomWidth: 1.5,
						borderColor: "#000"
					}],
					fixed: true,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.th, { flex: 1 }],
							children: d.columns?.[0] ?? "Item"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.th, {
								width: d.columns ? 60 : 40,
								textAlign: "right"
							}],
							children: d.columns?.[1] ?? "Qty"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.th, {
								width: 70,
								textAlign: "right"
							}],
							children: d.columns?.[2] ?? "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.th, {
								width: d.columns ? 60 : 40,
								textAlign: "right"
							}],
							children: d.columns?.[3] ?? "Disc."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.th, {
								width: 75,
								textAlign: "right"
							}],
							children: d.columns?.[4] ?? "Total"
						})
					]
				}),
				d.lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: [s.row, {
						borderBottomWidth: .5,
						borderColor: "#ccc"
					}],
					wrap: false,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.td, {
								flex: 1,
								paddingRight: 8
							}],
							children: l.desc
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.td, {
								width: d.columns ? 60 : 40,
								textAlign: "right"
							}],
							children: l.qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.td, {
								width: 70,
								textAlign: "right"
							}],
							children: l.price
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.td, {
								width: d.columns ? 60 : 40,
								textAlign: "right"
							}],
							children: l.disc
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: [s.td, {
								width: 75,
								textAlign: "right"
							}],
							children: l.total
						})
					]
				}, i)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: [s.between, { marginTop: 12 }],
					wrap: false,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
						style: { width: "55%" },
						children: d.remarks ?? ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
						style: { width: 190 },
						children: [d.totals.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
							style: [
								s.between,
								{ paddingVertical: 2 },
								t.big ? {
									borderTopWidth: 1,
									borderColor: "#000",
									marginTop: 2,
									paddingTop: 4
								} : {}
							],
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
								style: t.big ? [s.bold, { fontSize: 11 }] : {},
								children: t.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
								style: t.big ? [s.bold, { fontSize: 11 }] : {},
								children: t.value
							})]
						}, t.label)), d.payUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							src: d.payUrl,
							style: {
								marginTop: 8,
								paddingVertical: 6,
								backgroundColor: "#0E7C78",
								color: "#fff",
								textAlign: "center",
								fontFamily: "Helvetica-Bold",
								fontSize: 10,
								textDecoration: "none",
								borderRadius: 4
							},
							children: "Pay now by card"
						}) : null]
					})]
				}),
				d.endFooter ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: {
						marginTop: 18,
						paddingTop: 6,
						borderTopWidth: .5,
						borderColor: "#ccc",
						fontSize: 8.5,
						color: "#444"
					},
					children: d.endFooter
				}) : null,
				d.pageFooter ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: s.pageFooter,
					fixed: true,
					children: d.pageFooter
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: s.pageNo,
					fixed: true,
					render: ({ pageNumber, totalPages }) => `${pageNumber} / ${totalPages}`
				})
			]
		}), d.attach ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AttachPage, {
			text: d.attach,
			logo: d.logo,
			company: d.company.name
		}) : null]
	});
}
function AttachPage({ text, logo, company }) {
	const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
	const first = lines[0] ?? "";
	const title = first === first.toUpperCase() && first.length < 60 ? first : null;
	const rest = title ? lines.slice(1) : lines;
	const isItem = (l) => /^\d+\.\s/.test(l);
	const firstItem = rest.findIndex(isItem);
	const before = firstItem > 0 ? rest.slice(0, firstItem) : [];
	const items = rest.filter(isItem);
	const after = rest.filter((l, i) => !isItem(l) && i > firstItem);
	const half = Math.ceil(items.length / 2);
	const ack = after.some((l) => /ACKNOWLEDG/i.test(l));
	const item = (l, i) => {
		const m = l.match(/^(\d+\.\s.+?)\s[-–]\s(.*)$/);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
			style: { marginBottom: 5 },
			children: m ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: s.bold,
					children: m[1]
				}),
				" – ",
				m[2]
			] }) : l
		}, i);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		size: "LETTER",
		style: [s.page, {
			fontSize: 8,
			paddingBottom: 40
		}],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
				style: [s.between, {
					alignItems: "flex-end",
					borderBottomWidth: 1.5,
					borderColor: "#000",
					paddingBottom: 5
				}],
				children: [logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, {
					src: logo,
					style: {
						height: 28,
						objectFit: "contain"
					}
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {}), title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: {
						fontSize: 15,
						fontFamily: "Helvetica-Bold",
						color: RED
					},
					children: title
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, { children: company })]
			}),
			before.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
				style: [s.bold, { marginTop: 6 }],
				children: l
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
				style: [s.row, { marginTop: 8 }],
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {
					style: {
						width: "50%",
						paddingRight: 10
					},
					children: items.slice(0, half).map(item)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {
					style: {
						width: "50%",
						paddingLeft: 10
					},
					children: items.slice(half).map((l, i) => item(l, i + half))
				})]
			}),
			after.map((l, i) => {
				const m = l.match(/^([A-Z][A-Z\s&]+)\s[-–]\s(.*)$/);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					style: { marginTop: 6 },
					children: m ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
							style: s.bold,
							children: m[1]
						}),
						" – ",
						m[2]
					] }) : l
				}, i);
			}),
			ack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, {
				style: [s.row, { marginTop: 26 }],
				children: [
					"Customer initials",
					"Authorized signature",
					"Print name / title",
					"Date"
				].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(View, {
					style: {
						flex: 1,
						marginHorizontal: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(View, { style: {
						height: 22,
						borderBottomWidth: .8,
						borderColor: "#000"
					} }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
						style: {
							textAlign: "center",
							marginTop: 3,
							fontSize: 7.5
						},
						children: x
					})]
				}, x))
			}) : null
		]
	});
}
/** Make the PDF file (loaded only when needed — it's a big library). */
async function makePdf(d) {
	const { pdf } = await import("../_libs/react-pdf__renderer.mjs").then((n) => n.n);
	return pdf(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocPdf, { d })).toBlob();
}
async function blobToBase64(b) {
	const buf = new Uint8Array(await b.arrayBuffer());
	let bin = "";
	for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode(...buf.subarray(i, i + 32768));
	return btoa(bin);
}
//#endregion
export { makePdf as n, sendDocEmail as r, blobToBase64 as t };
