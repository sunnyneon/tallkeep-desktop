import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as fmtDateTime, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-BPH3ctlo.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { I as RefreshCw, Wt as ExternalLink, f as Unlink, h as TriangleAlert, mt as Link2, vt as Landmark } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/BankConnections-D2NYH8VU.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var listBankLinks = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("52743db9114c316defd0de80423075d8f3ce16d64637a0cab7bda678b037e7ee"));
var connectBank = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const code = String(d?.code ?? "").trim();
	if (!code) throw new Error("Paste the setup code from SimpleFIN.");
	if (code.length > 2e3) throw new Error("That code is too long. Copy just the setup code.");
	return { code };
}).handler(createSsrRpc("d4666967c9fdc9d7c8c16b3f6ce6b24652dd0a13c9bb7f80369329f45e85ac53"));
var setBankLinkAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which account?");
	if (d.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.startDate)) throw new Error("Pick a start date.");
	return {
		id: d.id,
		accountId: d.accountId || null,
		startDate: d.startDate || null
	};
}).handler(createSsrRpc("d45861089fecb1b6200c8e8e07147efcd9537a6f08a01f71fd821a171136d514"));
var pullBankNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("1ddc9bf46ce82113f0b8564806dc316e90df9282ae9ed81c6724e024d1d0757a"));
var removeBankLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which connection?");
	return { id: d.id };
}).handler(createSsrRpc("d9c39b8ea424292e98f3177e30e500e9266a64f5d23e5d8ca85b07aafc9b746d"));
var SIMPLEFIN = "https://beta-bridge.simplefin.org/";
var isoDay = (d) => d.toLocaleDateString("en-CA");
/** Banking: banks connected through SimpleFIN, which send new lines in every day. */
function BankConnections() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: links, error } = useQuery({
		queryKey: ["bank-links"],
		retry: false,
		queryFn: () => listBankLinks()
	});
	const { data: booksStart } = useQuery({
		queryKey: ["books-start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
	const [connecting, setConnecting] = (0, import_react.useState)(false);
	const [pulling, setPulling] = (0, import_react.useState)(false);
	const [removing, setRemoving] = (0, import_react.useState)(null);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["bank-links"] });
		qc.invalidateQueries({ queryKey: ["bank-txns"] });
		qc.invalidateQueries({ queryKey: ["bank-feed-waiting"] });
	};
	const thirty = isoDay(/* @__PURE__ */ new Date(Date.now() - 2592e6));
	const defaultStart = booksStart && booksStart > thirty ? booksStart : thirty;
	async function pull() {
		setPulling(true);
		try {
			const r = await pullBankNow();
			if (r.errors.length) toast.error(r.errors[0]);
			else toast.success(r.added ? `Brought in ${r.added} new line${r.added === 1 ? "" : "s"}. They're in For review.` : "No new lines yet.");
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setPulling(false);
		}
	}
	async function map(id, accountId, startDate) {
		try {
			await setBankLinkAccount({ data: {
				id,
				accountId,
				startDate
			} });
			refresh();
			if (accountId) await pull();
		} catch (e) {
			toast.error(e.message);
		}
	}
	async function remove(id) {
		try {
			await removeBankLink({ data: { id } });
			toast.success("Connection removed. Lines already brought in stay.");
			setRemoving(null);
			refresh();
		} catch (e) {
			toast.error(e.message);
		}
	}
	if (error) {
		const msg = String(error.message ?? "");
		if (/bank_link|does not exist|schema cache/i.test(msg)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
			children: "Bank connections need database step 76 (docs/db/076_bank_connections.sql)."
		});
		if (/don't have access/i.test(msg)) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground",
			children: ["Bank connections couldn't load: ", msg]
		});
	}
	if (!links) return null;
	const banks = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card"));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3 rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "flex items-center gap-2 font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { className: "h-4 w-4 text-[var(--section)]" }), " Bank connections"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-0.5 text-sm text-muted-foreground",
						children: links.length ? "New lines from your bank come in by themselves every morning. Tallkeep can only read them; it can never move money." : "Skip the statement files: connect your bank once and new lines come in by themselves every day. Read-only: it can never move money."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [links.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void pull(),
						disabled: pulling,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-4 w-4 ${pulling ? "animate-spin" : ""}` }), pulling ? "Getting lines…" : "Get new lines now"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => setConnecting(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" }),
							" ",
							links.length ? "Connect another bank" : "Connect a bank"
						]
					})]
				})]
			}),
			links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2 border-b bg-muted/30 px-3 py-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							l.name ?? "SimpleFIN",
							" · connected ",
							fmtDate(l.created_at),
							" ·",
							" ",
							l.last_pulled_at ? `last checked ${fmtDateTime(l.last_pulled_at)}` : "not checked yet"
						] }), removing === l.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [
								"Remove this connection?",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "destructive",
									onClick: () => void remove(l.id),
									children: "Yes, remove it"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => setRemoving(null),
									children: "Keep it"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setRemoving(l.id),
							className: "inline-flex items-center gap-1 rounded-md px-2 py-1 hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unlink, { className: "h-3.5 w-3.5" }), " Remove"]
						})]
					}),
					l.last_error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-start gap-2 border-b bg-amber-50 px-3 py-2 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							l.last_error,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SIMPLEFIN,
								target: "_blank",
								rel: "noreferrer",
								className: "underline",
								children: "Open SimpleFIN"
							}),
							" ",
							"to fix it."
						] })]
					}),
					l.accounts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-3 text-sm text-muted-foreground",
						children: "No accounts shared yet. Add your bank in SimpleFIN, then press Get new lines now."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y",
						children: l.accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_19rem_10rem] sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: a.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [a.bank_name, a.balance == null ? null : `balance ${fmtMoney(a.balance)}`].filter(Boolean).join(" · ")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-0.5 text-xs text-muted-foreground",
									children: ["Put its lines in", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: a.account_id ?? "",
										onChange: (e) => void map(a.id, e.target.value || null, a.start_date ?? defaultStart),
										className: "h-9 rounded-md border bg-background px-2 text-sm text-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "Don't bring in"
										}), banks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: b.id,
											children: accountLabel(b)
										}, b.id))]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "grid gap-0.5 text-xs text-muted-foreground",
									children: ["Lines from", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										className: "h-9",
										disabled: !a.account_id,
										value: a.start_date ?? defaultStart,
										onChange: (e) => e.target.value && void map(a.id, a.account_id, e.target.value)
									})]
								})
							]
						}, a.id))
					})
				]
			}, l.id)),
			connecting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectDialog, {
				onClose: () => setConnecting(false),
				onDone: () => {
					setConnecting(false);
					refresh();
				}
			})
		]
	});
}
function ConnectDialog({ onClose, onDone }) {
	const [code, setCode] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function go() {
		setBusy(true);
		try {
			const r = await connectBank({ data: { code } });
			toast.success(r.accounts ? `Connected. ${r.accounts} account${r.accounts === 1 ? "" : "s"} found: pick where each one's lines go.` : "Connected. Add your bank in SimpleFIN, then press Get new lines now.");
			onDone();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Connect a bank" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Tallkeep connects to banks through SimpleFIN Bridge. It costs $15 a year (or $1.50 a month), paid to SimpleFIN, and covers up to 25 banks and cards." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-2 pl-5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: SIMPLEFIN,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 font-medium text-primary underline",
								children: ["Open SimpleFIN Bridge ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5" })]
							}),
							" ",
							"and make an account."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Add your banks and cards there (you sign in to each bank on SimpleFIN's page)." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Choose ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "New app connection" }),
							" (or ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Setup token" }),
							"), name it Tallkeep, and copy the code it shows."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Paste the code below and press Connect." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 3,
					value: code,
					onChange: (e) => setCode(e.target.value),
					placeholder: "Paste the setup code here",
					className: "font-mono text-xs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "The code works once. Tallkeep keeps the private read-only address it gets in return; you can remove the connection here, or in SimpleFIN, any time."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void go(),
					disabled: busy || !code.trim(),
					children: busy ? "Connecting…" : "Connect"
				})] })
			]
		})
	});
}
//#endregion
export { BankConnections as t };
