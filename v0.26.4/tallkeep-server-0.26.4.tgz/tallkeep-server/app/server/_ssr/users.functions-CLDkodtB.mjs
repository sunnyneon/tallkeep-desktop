import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/users.functions-CLDkodtB.js
/** The account (customer) a person belongs to. */
async function orgOf(userId) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("org_members").select("org_id").eq("user_id", userId).maybeSingle();
	return data?.org_id ?? null;
}
/** People in an account. */
async function orgPeople(org) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("org_members").select("user_id").eq("org_id", org);
	return new Set((data ?? []).map((r) => r.user_id));
}
/** The account's Owner (database step 75); null when there is none or the step isn't run. */
async function ownerOf(org) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("orgs").select("owner_id").eq("id", org).maybeSingle();
	if (error) return null;
	return data?.owner_id ?? null;
}
/** Only admins may manage users, and only the people in their own account. With `owner`,
*  only the account's Owner (an account without one: any admin). */
async function adminClient(userId, owner = false) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
	if (error) throw new Error(error.message);
	if (!data) throw new Error("Only an admin can manage users.");
	const org = await orgOf(userId);
	if (!org) throw new Error("Your account is not set up yet.");
	if (owner) {
		const o = await ownerOf(org);
		if (o && o !== userId) throw new Error("Only the account's Owner can add, remove or change people.");
	}
	return {
		org,
		auth: supabaseAdmin.auth,
		from: supabaseAdmin.from.bind(supabaseAdmin)
	};
}
/** Stop when the account is read-only or its plan has no room for another person. */
async function roomForOneMore(org) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("orgs").select("*").eq("id", org).maybeSingle();
	const o = data;
	if (!o || o.is_platform && o.edition !== "desktop") return;
	if (!(o.status === "active" || o.status === "past_due" || o.status === "trial" && (!o.trial_ends_at || Date.parse(o.trial_ends_at) > Date.now()))) throw new Error(o.edition === "desktop" ? "Tallkeep is read-only: the free trial has ended. Enter your license key in Settings → Plan & computer." : "Your account is read-only. Choose a plan to keep working.");
	const max = o.users_allowed;
	if (max != null && (await orgPeople(org)).size >= max) throw new Error(o.edition === "desktop" ? `Your license includes ${max} ${max === 1 ? "person" : "people"}. Add a user to your license at tallkeep.com first.` : `Your plan includes ${max} ${max === 1 ? "person" : "people"}. Add another user to your plan first.`);
}
/** Stop if this person isn't in the admin's account. */
async function sameAccount(org, id) {
	if (await orgOf(id) !== org) throw new Error("That person isn't in your account.");
}
var cleanZones = (z) => {
	if (z == null) return null;
	const ok = z.filter((x) => [
		"Sales",
		"Purchasing",
		"Inventory",
		"Properties",
		"Accounting",
		"Reports"
	].includes(x));
	if (ok.length === 0) throw new Error("Tick at least one section.");
	return ok;
};
async function setRole(admin, id, role, zones = null) {
	const del = await admin.from("user_roles").delete().eq("user_id", id);
	if (del.error) throw new Error(del.error.message);
	const z = role === "admin" ? null : cleanZones(zones);
	const row = z ? {
		user_id: id,
		role,
		zones: z
	} : {
		user_id: id,
		role
	};
	const ins = await admin.from("user_roles").insert(row);
	if (ins.error) throw new Error(ins.error.message);
}
var listUsers_createServerFn_handler = createServerRpc({
	id: "d96fc76850779782acfe0d57c8df91435fcd2dbdbbe157b34f6d9842c0ffc4b6",
	name: "listUsers",
	filename: "src/lib/users.functions.ts"
}, (opts) => listUsers.__executeServer(opts));
var listUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listUsers_createServerFn_handler, async ({ context }) => {
	const admin = await adminClient(context.userId);
	const { data, error } = await admin.auth.admin.listUsers({
		page: 1,
		perPage: 1e3
	});
	if (error) throw new Error(error.message);
	const people = await orgPeople(admin.org);
	const ownerId = await ownerOf(admin.org);
	const { data: roleRows } = await admin.from("user_roles").select("*").in("user_id", [...people]);
	const roles = roleRows ?? [];
	const roleOf = /* @__PURE__ */ new Map();
	const zonesOf = /* @__PURE__ */ new Map();
	roles.forEach((r) => {
		if (r.role === "admin" || !roleOf.has(r.user_id)) {
			roleOf.set(r.user_id, r.role);
			zonesOf.set(r.user_id, r.role === "admin" ? null : r.zones ?? null);
		}
	});
	const { data: memberRows } = await admin.from("company_members").select("*").in("user_id", [...people]);
	const accessOf = /* @__PURE__ */ new Map();
	for (const m of memberRows ?? []) accessOf.set(m.user_id, [...accessOf.get(m.user_id) ?? [], {
		company_id: m.company_id,
		is_admin: !!m.is_admin,
		zones: m.zones ?? null,
		read_only: !!m.read_only
	}]);
	return data.users.filter((u) => people.has(u.id)).map((u) => ({
		id: u.id,
		email: u.email ?? "",
		name: String(u.user_metadata?.["name"] ?? ""),
		role: roleOf.get(u.id) ?? "staff",
		zones: zonesOf.get(u.id) ?? null,
		access: accessOf.get(u.id) ?? [],
		last_sign_in_at: u.last_sign_in_at ?? null,
		created_at: u.created_at,
		owner: u.id === ownerId
	})).sort((a, b) => a.email.localeCompare(b.email));
});
var addUser_createServerFn_handler = createServerRpc({
	id: "57ddaa5e4421dbf7df4d9f414643f1bb27a4c291bf5708d6c31cd31cadffedf0",
	name: "addUser",
	filename: "src/lib/users.functions.ts"
}, (opts) => addUser.__executeServer(opts));
var addUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^\S+@\S+\.\S+$/.test(d.email)) throw new Error("Type a valid email.");
	if ((d.password ?? "").length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(addUser_createServerFn_handler, async ({ data, context }) => {
	const admin = await adminClient(context.userId, true);
	await roomForOneMore(admin.org);
	const { data: made, error } = await admin.auth.admin.createUser({
		email: data.email.trim().toLowerCase(),
		password: data.password,
		email_confirm: true,
		user_metadata: { name: data.name.trim() }
	});
	if (error) throw new Error(error.message);
	const { error: me } = await admin.from("org_members").insert({
		org_id: admin.org,
		user_id: made.user.id
	});
	if (me) {
		await admin.auth.admin.deleteUser(made.user.id);
		throw new Error(me.message);
	}
	await setRole(admin, made.user.id, data.role, data.zones ?? null);
	const loose = admin;
	const { data: mine } = await loose.from("companies").select("id").eq("org_id", admin.org);
	const ours = new Set((mine ?? []).map((c) => c.id));
	const rows = (data.access ?? (data.companies ?? []).map((company_id) => ({
		company_id,
		is_admin: false,
		zones: null
	}))).filter((a) => ours.has(a.company_id));
	const picked = rows.map((r) => r.company_id);
	if (picked.length) {
		const full = rows.some((r) => r.is_admin || r.zones || r.read_only);
		const { error: ce } = await loose.from("company_members").insert(rows.map((r) => ({
			company_id: r.company_id,
			user_id: made.user.id,
			...full ? {
				is_admin: !!r.is_admin,
				zones: r.is_admin ? null : cleanZones(r.zones),
				...r.read_only && !r.is_admin ? { read_only: true } : {}
			} : {}
		})));
		if (ce) throw new Error(ce.message);
		await loose.from("user_company").insert({
			user_id: made.user.id,
			company_id: picked[0]
		});
	}
	return { id: made.user.id };
});
var changeUser_createServerFn_handler = createServerRpc({
	id: "bf7e244e8d039b3b242642889b54fe2c274ff956811728d8b7818fd4aa2b3bd6",
	name: "changeUser",
	filename: "src/lib/users.functions.ts"
}, (opts) => changeUser.__executeServer(opts));
var changeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.password != null && d.password.length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(changeUser_createServerFn_handler, async ({ data, context }) => {
	const own = data.id === context.userId && !data.role;
	const admin = await adminClient(context.userId, !own);
	await sameAccount(admin.org, data.id);
	if (data.role && data.role !== "admin" && await ownerOf(admin.org) === data.id) throw new Error("The Owner stays an admin. Hand over the Owner role first.");
	if (data.role) {
		if (data.id === context.userId && data.role !== "admin") throw new Error("You can't remove your own admin rights.");
		await setRole(admin, data.id, data.role, data.zones ?? null);
	}
	if (data.password || data.name != null) {
		const { error } = await admin.auth.admin.updateUserById(data.id, {
			...data.password ? { password: data.password } : {},
			...data.name != null ? { user_metadata: { name: data.name } } : {}
		});
		if (error) throw new Error(error.message);
	}
	return { ok: true };
});
var setCompanyAccess_createServerFn_handler = createServerRpc({
	id: "3428c6d6ad7cd8fa7491ab7411d6d8472cd18aba914aa7ac7fd3b8eec2fb01e4",
	name: "setCompanyAccess",
	filename: "src/lib/users.functions.ts"
}, (opts) => setCompanyAccess.__executeServer(opts));
var setCompanyAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(setCompanyAccess_createServerFn_handler, async ({ data, context }) => {
	const admin = await adminClient(context.userId, true);
	await sameAccount(admin.org, data.id);
	const loose = admin;
	const { data: co } = await loose.from("companies").select("id").eq("id", data.company_id).eq("org_id", admin.org).maybeSingle();
	if (!co) throw new Error("That company isn't in your account.");
	const del = await loose.from("company_members").delete().eq("company_id", data.company_id).eq("user_id", data.id);
	if (del.error) throw new Error(del.error.message);
	if (!data.open) return { ok: true };
	const ins = await loose.from("company_members").insert({
		company_id: data.company_id,
		user_id: data.id,
		is_admin: !!data.is_admin,
		zones: data.is_admin ? null : cleanZones(data.zones ?? null),
		...data.read_only && !data.is_admin ? { read_only: true } : {}
	});
	if (ins.error) throw new Error(/read_only/.test(ins.error.message) ? "Run database step 70 first (docs/db/070_look_only.sql)." : /is_admin|zones/.test(ins.error.message) ? "Run database step 45 first (docs/db/045_company_access.sql)." : ins.error.message);
	return { ok: true };
});
var removeUser_createServerFn_handler = createServerRpc({
	id: "9361df1a94e7b3318a7f52ef7419757434e15b7dead8b1cb6636b5adf3d5a46d",
	name: "removeUser",
	filename: "src/lib/users.functions.ts"
}, (opts) => removeUser.__executeServer(opts));
var removeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(removeUser_createServerFn_handler, async ({ data, context }) => {
	if (data.id === context.userId) throw new Error("You can't remove yourself.");
	const admin = await adminClient(context.userId, true);
	await sameAccount(admin.org, data.id);
	if (await ownerOf(admin.org) === data.id) throw new Error("The Owner can't be removed.");
	const { error } = await admin.auth.admin.deleteUser(data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var handOverOwner_createServerFn_handler = createServerRpc({
	id: "b87d33d66f88c754a25edb36b521a4273fbe7196266c87d0ade8aaec6f498df0",
	name: "handOverOwner",
	filename: "src/lib/users.functions.ts"
}, (opts) => handOverOwner.__executeServer(opts));
var handOverOwner = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(handOverOwner_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("hand_over_owner", { _to: data.id });
	if (error) throw new Error(error.message);
	return { ok: true };
});
var listRepNames_createServerFn_handler = createServerRpc({
	id: "64019a9e45f7e8b0375e3d14f1984dc6e6493f506a342471c10221dced5b5d46",
	name: "listRepNames",
	filename: "src/lib/users.functions.ts"
}, (opts) => listRepNames.__executeServer(opts));
var listRepNames = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listRepNames_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data: me } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", context.userId).limit(1).maybeSingle();
	if (!me) return [];
	const org = await orgOf(context.userId);
	if (!org) return [];
	const ids = await orgPeople(org);
	const { data } = await supabaseAdmin.auth.admin.listUsers({
		page: 1,
		perPage: 1e3
	});
	return data.users.filter((u) => ids.has(u.id)).map((u) => String(u.user_metadata?.["name"] ?? "").trim() || (u.email ?? "")).filter(Boolean).sort();
});
//#endregion
export { addUser_createServerFn_handler, changeUser_createServerFn_handler, handOverOwner_createServerFn_handler, listRepNames_createServerFn_handler, listUsers_createServerFn_handler, removeUser_createServerFn_handler, setCompanyAccess_createServerFn_handler };
