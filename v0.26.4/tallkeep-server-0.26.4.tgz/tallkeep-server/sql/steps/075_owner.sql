-- 075: The Owner. One person per account sits above the admins: only the Owner can add or
-- remove people and change what they can do, connect or disconnect Stripe, and enter the license
-- key (and, later, delete a company). Admins do everything else. The Owner can hand the role to
-- another admin. An account with no Owner yet (older data) lets its admins act as Owner.

alter table public.orgs add column if not exists owner_id uuid;

-- Who starts as Owner: the person who made the account, if still an admin in it; else the
-- longest-standing admin.
update public.orgs o
   set owner_id = coalesce(
     (select o.created_by
        where exists (select 1 from public.org_members m where m.org_id = o.id and m.user_id = o.created_by)
          and public.has_role(o.created_by, 'admin')),
     (select m.user_id from public.org_members m
       where m.org_id = o.id and public.has_role(m.user_id, 'admin')
       order by m.created_at limit 1))
 where o.owner_id is null;

-- Is this person their account's Owner?
create or replace function public.is_owner(_uid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select _uid is not null and public.has_role(_uid, 'admin') and exists (
    select 1 from public.org_members m join public.orgs o on o.id = m.org_id
     where m.user_id = _uid and (o.owner_id = _uid or o.owner_id is null))
$$;
grant execute on function public.is_owner(uuid) to authenticated, service_role;

-- The Owner of the signed-in person's account (to show on Settings → People).
create or replace function public.account_owner()
returns uuid language sql stable security definer set search_path = public as $$
  select o.owner_id from public.org_members m join public.orgs o on o.id = m.org_id
   where m.user_id = auth.uid() limit 1
$$;
grant execute on function public.account_owner() to authenticated;

-- Hand the Owner role to another admin in the same account.
create or replace function public.hand_over_owner(_to uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); org uuid;
begin
  if not public.is_owner(me) then raise exception 'Only the Owner can hand over the Owner role.'; end if;
  select m.org_id into org from public.org_members m where m.user_id = me limit 1;
  if not exists (select 1 from public.org_members where org_id = org and user_id = _to) then
    raise exception 'That person isn''t in your account.';
  end if;
  if not public.has_role(_to, 'admin') then
    raise exception 'Make them an admin first, then hand over the Owner role.';
  end if;
  update public.orgs set owner_id = _to where id = org;
end $$;
grant execute on function public.hand_over_owner(uuid) to authenticated;

notify pgrst, 'reload schema';
