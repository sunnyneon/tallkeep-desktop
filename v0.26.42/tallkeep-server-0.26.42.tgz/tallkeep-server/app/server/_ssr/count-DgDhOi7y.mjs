import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as StockDocList } from "./StockDocList-pM5nO2mn.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/count-DgDhOi7y.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockDocList, { kind: "count" });
//#endregion
export { SplitComponent as component };
