import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as PartyList } from "./PartyList-C2aMBYCQ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers-Diq_w1Xx.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartyList, { kind: "customers" });
//#endregion
export { SplitComponent as component };
