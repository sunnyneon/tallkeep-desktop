import { n as db } from "./db-CB2G25F5.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/company-Cx1dxI4m.js
/**
* Each window works in its own company. The window remembers which company it shows (for this
* tab only) and sends it with every database request, so switching company in another window,
* on another computer or on the phone never moves where this window saves.
* The database checks you may use that company; without it (older database) nothing changes.
*/
var KEY = "tk-window-company";
var HEADER = "x-tallkeep-company";
var current = null;
var installed = false;
var read = () => {
	try {
		return sessionStorage.getItem(KEY);
	} catch {
		return null;
	}
};
/** The company this window shows (null until known). */
var windowCompany = () => current;
/** Remember the company this window works in. */
function setWindowCompany(id) {
	current = id;
	try {
		if (id) sessionStorage.setItem(KEY, id);
		else sessionStorage.removeItem(KEY);
	} catch {}
}
/** Send the window's company with every database request. Call once, in the browser. */
function installWindowCompany() {
	if (installed || typeof window === "undefined") return;
	installed = true;
	current = read();
	const orig = window.fetch.bind(window);
	window.fetch = (input, init) => {
		if (!current) return orig(input, init);
		const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
		if (!/\/rest\/v1\//.test(url)) return orig(input, init);
		const headers = new Headers(init?.headers ?? (typeof input !== "string" && !(input instanceof URL) ? input.headers : void 0));
		headers.set(HEADER, current);
		return orig(input, {
			...init,
			headers
		});
	};
}
/** The companies I can open; the active one has active = true. */
function useMyCompanies(enabled = true) {
	return useQuery({
		queryKey: ["my-companies"],
		enabled,
		staleTime: 3e5,
		retry: 4,
		retryDelay: (n) => Math.min(1e3 * 2 ** n, 8e3),
		placeholderData: (prev) => prev,
		queryFn: async () => {
			const { data, error } = await db.rpc("my_companies");
			if (error) {
				if (/could not find the function|does not exist/i.test(error.message)) return [];
				throw new Error(error.message);
			}
			const list = data ?? [];
			const active = list.find((c) => c.active)?.id;
			if (active && !windowCompany()) setWindowCompany(active);
			return list;
		}
	});
}
/** Id of the company I'm working in (records are saved to it). */
async function activeCompanyId() {
	const { data, error } = await db.rpc("active_company");
	if (error) return null;
	const id = data ?? null;
	if (id && !windowCompany()) setWindowCompany(id);
	return id;
}
/** Switch company, close the open tabs and start at Home with the new company's records. */
async function switchCompany(id) {
	const from = windowCompany();
	const { error } = await db.rpc("set_active_company", { _c: id });
	if (error) throw error;
	if (from && from !== id) try {
		sessionStorage.setItem(CAME_FROM, from);
		localStorage.setItem(CAME_FROM, from);
	} catch {}
	setWindowCompany(id);
	try {
		localStorage.removeItem("open-tabs");
	} catch {}
	window.location.assign("/");
}
var CAME_FROM = "tk-came-from";
/** The company this window was in before the last switch (null if not known). */
function cameFrom() {
	try {
		return sessionStorage.getItem(CAME_FROM) ?? localStorage.getItem(CAME_FROM);
	} catch {
		return null;
	}
}
/** Open the sample company, making it first if it isn't there yet (the account's Owner). */
async function openSample() {
	const find = async () => {
		const { data } = await db.from("companies").select("id").eq("is_sample", true).maybeSingle();
		return data?.id ?? null;
	};
	let id = await find();
	if (!id) {
		const { error } = await db.rpc("sample_company", {
			_on: true,
			_fresh: false
		});
		if (error) throw error;
		id = await find();
	}
	if (!id) throw new Error("The sample company couldn't be made. Try Options → Apps → Sample company.");
	await switchCompany(id);
}
//#endregion
export { setWindowCompany as a, windowCompany as c, openSample as i, cameFrom as n, switchCompany as o, installWindowCompany as r, useMyCompanies as s, activeCompanyId as t };
