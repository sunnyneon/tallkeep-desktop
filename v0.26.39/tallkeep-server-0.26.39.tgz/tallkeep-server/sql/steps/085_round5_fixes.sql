-- 085: Fixes from the fifth test round (20 November 2026).
--
-- 1) Money received on something that isn't invoiced yet (a quote's deposit, an order not
--    invoiced) is a Customer Deposit, not a payment on Accounts Receivable. Once it's invoiced,
--    the same payment moves to Accounts Receivable by itself. Before, it lowered Accounts
--    Receivable with no invoice behind it, so the Balance Sheet and "Customers owe" disagreed.
--    Companies without a Customer Deposits account keep using Accounts Receivable.
update public.accounts a set key = 'customer_deposits'
 where a.number = '2300' and lower(a.name) = 'customer deposits' and a.key is null
   and not exists (select 1 from public.accounts b where b.company_id = a.company_id and b.key = 'customer_deposits');

create or replace function public.post_payment(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare p record; co uuid; bank uuid; who uuid; ref text; st text; credit_to uuid;
begin
  delete from public.journal_entries where source_type in ('payment', 'po_payment') and source_id = _id;
  select * into p from public.payments where id = _id;
  if p.id is null or p.check_id is not null then return; end if;
  if p.sales_order_id is not null then
    select company_id, customer_id, number, status into co, who, ref, st
      from public.sales_orders where id = p.sales_order_id;
  else
    select company_id, vendor_id, number into co, who, ref from public.purchase_orders where id = p.purchase_order_id;
  end if;
  if co is null or not public.books_open(co, p.paid_on::date) then return; end if;
  bank := coalesce(p.account_id,
    (select default_bank_account_id from public.company_settings where company_id = co),
    public.acct(co, 'bank'));
  if p.sales_order_id is not null then
    credit_to := case when st in ('invoiced', 'paid', 'completed') or ref like 'RMA-%'
                      then public.acct(co, 'ar')
                      else coalesce(public.acct(co, 'customer_deposits'), public.acct(co, 'ar')) end;
    if coalesce(p.fee, 0) <> 0 then perform public.seed_card_accounts(co); end if;
    perform public.write_entry(co, p.paid_on::date, 'payment', p.id, ref,
      case when credit_to = public.acct(co, 'ar') then 'Payment for ' else 'Deposit on ' end || ref,
      jsonb_build_array(
        jsonb_build_object('account', bank, 'debit', p.amount - coalesce(p.fee, 0), 'customer', who),
        jsonb_build_object('account', public.acct(co, 'card_fees'), 'debit', coalesce(p.fee, 0), 'customer', who,
                           'memo', 'Card fee'),
        jsonb_build_object('account', credit_to, 'credit', p.amount, 'customer', who)));
  else
    perform public.write_entry(co, p.paid_on::date, 'po_payment', p.id, ref, 'Paid ' || ref,
      jsonb_build_array(
        jsonb_build_object('account', public.acct(co, 'ap'), 'debit', p.amount, 'vendor', who),
        jsonb_build_object('account', bank, 'credit', p.amount, 'vendor', who)));
  end if;
end $$;

-- When a document is invoiced (or goes back), its payments are written again on the right account.
create or replace function public.repost_order_payments()
returns trigger language plpgsql security definer set search_path = public as $$
declare r record;
begin
  if new.status is distinct from old.status then
    for r in select id from public.payments where sales_order_id = new.id loop
      perform public.post_payment(r.id);
    end loop;
  end if;
  return null;
end $$;
drop trigger if exists sales_orders_repost_payments on public.sales_orders;
create trigger sales_orders_repost_payments after update of status on public.sales_orders
  for each row execute function public.repost_order_payments();

-- 2) A quote, order or invoice with money paid on it can't be cancelled (D23): remove the
--    payment first. The page also asks before cancelling, and Undo cancel brings it back.
create or replace function public.sales_cancel_ok()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.status = 'cancelled' and old.status is distinct from 'cancelled' and auth.uid() is not null
     and exists (select 1 from public.payments p where p.sales_order_id = new.id and p.amount <> 0) then
    raise exception 'This has a payment on it. Remove the payment first, then cancel it.' using errcode = 'P0001';
  end if;
  return new;
end $$;
drop trigger if exists sales_cancel_ok on public.sales_orders;
create trigger sales_cancel_ok before update of status on public.sales_orders
  for each row execute function public.sales_cancel_ok();

-- Payments already written for documents that aren't invoiced are written again now.
do $$
declare r record;
begin
  for r in select p.id from public.payments p join public.sales_orders o on o.id = p.sales_order_id
            where o.status not in ('invoiced', 'paid', 'completed') loop
    perform public.post_payment(r.id);
  end loop;
end $$;

notify pgrst, 'reload schema';
