//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-zfPnkOvR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-ClLMPmnp.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DTeT-72p.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CdCjeZMA.js",
			"/assets/company-DH5yJR9m.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ClLMPmnp.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BSl1d2nX.js",
			"/assets/log-out-BfaID5Ck.js",
			"/assets/testers.functions-TB4agL6Q.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BNccps7B.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-C8s1saWW.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-C1DdHYVB.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/dist-DluqlcYo.js",
			"/assets/dialog-BATOLbhZ.js",
			"/assets/queries-yrRO0H4y.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/label-PlTLWnXu.js",
			"/assets/textarea-Cc90UZhb.js",
			"/assets/shoebox-B3Lm3nHL.js",
			"/assets/reports-DW-d2lTh.js",
			"/assets/access-ABP98ENu.js",
			"/assets/theme-OYodnxI7.js",
			"/assets/Logo-t_3Au7ZW.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-DpWJTOrA.js",
			"/assets/log-out-BfaID5Ck.js",
			"/assets/admin.functions-B4ynrIJO.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-t_3Au7ZW.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-CBM6jOzr.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/label-PlTLWnXu.js",
			"/assets/Logo-t_3Au7ZW.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Djg9nU_d.js",
			"/assets/testers.functions-TB4agL6Q.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/coupons.functions-Dmg1v-kZ.js",
			"/assets/buy.functions-CZQfgDg5.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-CCxbMTbJ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/downloads.functions-Dq7Xneul.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BCUyHqal.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/label-PlTLWnXu.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BNW_4WUu.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/label-PlTLWnXu.js",
			"/assets/Logo-t_3Au7ZW.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-0KB43rNf.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/upgrade.functions-CGvEuI64.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CL4z_YcO.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/label-PlTLWnXu.js",
			"/assets/Logo-t_3Au7ZW.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CLgIdJEt.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-te3eNGoM.js", "/assets/StockDocList-CsfIzCrm.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BY9yvxoN.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/ai-mqreXx_W.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BDFSD8S2.js",
			"/assets/BankConnections-DmJMRFvF.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-6tbWUVNB.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-4B8CCF7l.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DmJMRFvF.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/ai-mqreXx_W.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-B6hhaPbK.js",
			"/assets/TxnEditor-DdB3gxAI.js",
			"/assets/feedWaiting-Bh7Bzef-.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-CXJcFfrF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-CcqcdJ91.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DPLhf3eX.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/personal-kGaWRiHG.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/WhoPicker-BL_OZQ4U.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DURWTAm_.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CIHH5XCI.js", "/assets/AccountRegister-CsFRtdvN.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DkHTnKh9.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-SlWDv9xy.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/money-CBvDkMHh.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-VqmT4_AT.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-mqreXx_W.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DmvlrOea.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-DVsAmGnU.js", "/assets/StockDocList-CsfIzCrm.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DRdz241H.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-D992RVJ0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-CYgCGPBc.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DLVTUNL9.js", "/assets/PartyList-CHqUuHc2.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-CfxndLvb.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-BZ9Rl9Ei.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/storage.functions-phsju5Xt.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CxfA7UtU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BMrEafNA.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/booksStart-5S_aOQtv.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-ByAR1mLJ.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-DbvkZG_J.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-C3FXEPvV.js", "/assets/ChangeHistory-DbkK0ySS.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-B9QB3Wv8.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/members-BL2fdCvH.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-DyofW_ws.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/personal-kGaWRiHG.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/WhoPicker-BL_OZQ4U.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BhVs5IYi.js", "/assets/SalesList-C3kK0Xww.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-B7oVasNB.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CQqfPTOe.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-C6E0D74g.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BzotMJBW.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/loans-B6hhaPbK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-Bv7yxi8W.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-D2eWY86A.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Ddt1JD3h.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/personal-kGaWRiHG.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/WhoPicker-BL_OZQ4U.js",
			"/assets/reminders-B25O-Agy.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-MaesWaa5.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BVelRXoD.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/personal-kGaWRiHG.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/WhoPicker-BL_OZQ4U.js",
			"/assets/generateCategoricalChart-BrMv0O-D.js",
			"/assets/Area-D1C5OKpD.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-8nxxxyqi.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/generateCategoricalChart-BrMv0O-D.js",
			"/assets/PlCharts-ByAR1mLJ.js",
			"/assets/BarChart-BqI2feLr.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-BAqXL_Z-.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/balances-CcqcdJ91.js",
			"/assets/money-CBvDkMHh.js",
			"/assets/DecimalInput-XbYDFWtM.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DhP02B8E.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DIXCJhpl.js",
			"/assets/createServerFn-Cb-ZZ7Oq.js",
			"/assets/auth-middleware-BtKLUsxR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/storage.functions-phsju5Xt.js",
			"/assets/coupons.functions-Dmg1v-kZ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-6m1dkOha.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-vcg9rvvp.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/DecimalInput-XbYDFWtM.js",
			"/assets/StockDialogs-BMB-Y5_3.js",
			"/assets/checkbox-Bsezfd9_.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-OhThQmHH.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DwvKybBx.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-n-Q89rnK.js", "/assets/SalesList-C3kK0Xww.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BV0XQM5K.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/ai-mqreXx_W.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-phsju5Xt.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CneW1Mhu.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/money-CBvDkMHh.js",
			"/assets/badge-GKU_VXLO.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-k-atvpR6.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-T9_pbpW4.js", "/assets/AccountRegister-CsFRtdvN.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-DafyNdJv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/MoneyAccountPick-CiP1GMy1.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-D2zDbEHe.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-C2NjST69.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/RepeatInvoice-DjvKoTUB.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-3ztpaOfa.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-BrMv0O-D.js",
			"/assets/BarChart-BqI2feLr.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-DasK-Y7j.js", "/assets/SalesList-C3kK0Xww.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CJGCnvtF.js", "/assets/SalesList-C3kK0Xww.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-B6ywUdL3.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-D3cqWJox.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/serials-DG1QQoTf.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Sk8KTSZa.js",
			"/assets/createServerFn-Cb-ZZ7Oq.js",
			"/assets/auth-middleware-BtKLUsxR.js",
			"/assets/AppsCatalog-85mYW5vB.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-5D9GAY-8.js",
			"/assets/switch-D2eWY86A.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-CYgCGPBc.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-N6eQnIi8.js",
			"/assets/footers-B_NkQJHW.js",
			"/assets/PrintFrame-C0sVDBi4.js",
			"/assets/checkbox-Bsezfd9_.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-zxWzT-iU.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BR-yW3OV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-85mYW5vB.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-DmJMRFvF.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BR3uoJQV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/StockDialogs-BMB-Y5_3.js",
			"/assets/photos-N6eQnIi8.js",
			"/assets/stockmove-qRsVCF5K.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CQwqwWJ6.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/loans-B6hhaPbK.js",
			"/assets/feedWaiting-Bh7Bzef-.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-phsju5Xt.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Ddo89hLV.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/PrintFrame-C0sVDBi4.js",
			"/assets/DocPdf-B_GANndK.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-IdwdUivO.js",
			"/assets/createServerFn-Cb-ZZ7Oq.js",
			"/assets/auth-middleware-BtKLUsxR.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/MoneyAccountPick-CiP1GMy1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-zxWzT-iU.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DCuBc9ay.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/StockDialogs-BMB-Y5_3.js",
			"/assets/stockmove-qRsVCF5K.js",
			"/assets/checkbox-Bsezfd9_.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-HTj2Tp4o.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/members-BL2fdCvH.js",
			"/assets/WhoPicker-BL_OZQ4U.js",
			"/assets/reminders-B25O-Agy.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-9Zt-iEUH.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/tickets.functions-BLjq1cTc.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-D8n9Qh83.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-zxWzT-iU.js",
			"/assets/support.functions-CbZsz0Ji.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-C65H54_b.js", "/assets/StockDocList-CsfIzCrm.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DgWAAPiq.js", "/assets/PartyList-CHqUuHc2.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B6wf7bWQ.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/tickets.functions-BLjq1cTc.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CEpR4OPG.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/workorders-KS53NYTi.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-C_iPKoDl.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-BQPx5X2v.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/coupons.functions-Dmg1v-kZ.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-y3Gi_Ezd.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/AdminAccount-Bhl9MecV.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-x_1b82K7.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/downloads.functions-Dq7Xneul.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B8E0d9Yo.js",
			"/assets/createServerFn-Cb-ZZ7Oq.js",
			"/assets/auth-middleware-BtKLUsxR.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CXEEOG8t.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Cnrz8TN6.js",
			"/assets/testers.functions-TB4agL6Q.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-Cv6WNpMD.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-D70vutmy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CZQfgDg5.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-s7_FjFaU.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/textarea-Cc90UZhb.js",
			"/assets/support.functions-CbZsz0Ji.js",
			"/assets/HelpParts-Bk3PG_uT.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CB8yM3fK.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-3-WmOwdA.js",
			"/assets/manual._slug-Dd0wE_j8.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-B3VzI1lr.js",
			"/assets/createServerFn-Cb-ZZ7Oq.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DgyAOInX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-CGvEuI64.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-pPBL03nV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-mqreXx_W.js",
			"/assets/personal-kGaWRiHG.js",
			"/assets/reminders-B25O-Agy.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-PXqcNhwP.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/AdminAccount-Bhl9MecV.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BneniLBD.js", "/assets/ManualFrame-3-WmOwdA.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CTYIli5F.js", "/assets/AccountRegister-CsFRtdvN.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Cee8Q1nW.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/OriginalLink-C5PLw_Lo.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/realestate-fajIrgHI.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Cn4beXCl.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/realestate-fajIrgHI.js",
			"/assets/money-CBvDkMHh.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-IZtoS3LD.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-5S_aOQtv.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/SideList-B83-GjLj.js",
			"/assets/PartyHistory-BfQAd6jt.js",
			"/assets/tabs-DtvnNlCI.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-994JwYhd.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/ChangeHistory-DbkK0ySS.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/SideList-B83-GjLj.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-XbYDFWtM.js",
			"/assets/StockDialogs-BMB-Y5_3.js",
			"/assets/NewProductDialog-ByU6_hnq.js",
			"/assets/MoneyAccountPick-CiP1GMy1.js",
			"/assets/footers-B_NkQJHW.js",
			"/assets/PrintFrame-C0sVDBi4.js",
			"/assets/serials-DG1QQoTf.js",
			"/assets/SerialsBox-w54WouxU.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-2fuUVGpu.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DbkK0ySS.js",
			"/assets/switch-D2eWY86A.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-GKU_VXLO.js",
			"/assets/SideList-B83-GjLj.js",
			"/assets/tabs-DtvnNlCI.js",
			"/assets/StockDialogs-BMB-Y5_3.js",
			"/assets/photos-N6eQnIi8.js",
			"/assets/stockmove-qRsVCF5K.js",
			"/assets/serials-DG1QQoTf.js",
			"/assets/SerialsBox-w54WouxU.js",
			"/assets/workorders-KS53NYTi.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-BXwM8Gbm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/ChangeHistory-DbkK0ySS.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/booksStart-5S_aOQtv.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/SideList-B83-GjLj.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-XbYDFWtM.js",
			"/assets/NewProductDialog-ByU6_hnq.js",
			"/assets/MoneyAccountPick-CiP1GMy1.js",
			"/assets/footers-B_NkQJHW.js",
			"/assets/PrintFrame-C0sVDBi4.js",
			"/assets/cardpay-D9x2v-gr.js",
			"/assets/checkbox-Bsezfd9_.js",
			"/assets/serials-DG1QQoTf.js",
			"/assets/workorders-KS53NYTi.js",
			"/assets/RepeatInvoice-DjvKoTUB.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BLjq1cTc.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CxaCfr1c.js",
			"/assets/select-Cs5xVaxm.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/SideList-B83-GjLj.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-CgFMjQqX.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/quickadd-DjWptN0F.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-zxWzT-iU.js",
			"/assets/support.functions-CbZsz0Ji.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BcHWsFdx.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-CDoKvE68.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/SideList-B83-GjLj.js",
			"/assets/PartyHistory-BfQAd6jt.js",
			"/assets/tabs-DtvnNlCI.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-zILBJfuG.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/accounting-7nwNAPkA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/sales-DmvlrOea.js",
			"/assets/footers-B_NkQJHW.js",
			"/assets/tickets.functions-BLjq1cTc.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-C0bTMkJX.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/input-_HyKhQq6.js",
			"/assets/skeleton-BtJU9PaZ.js",
			"/assets/AdminAccount-Bhl9MecV.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-nEDoMt28.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-Bva2OrJ6.js",
			"/assets/textarea-Cc90UZhb.js",
			"/assets/support-zxWzT-iU.js",
			"/assets/support.functions-CbZsz0Ji.js",
			"/assets/HelpParts-Bk3PG_uT.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CSnOCJer.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-BtJU9PaZ.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
