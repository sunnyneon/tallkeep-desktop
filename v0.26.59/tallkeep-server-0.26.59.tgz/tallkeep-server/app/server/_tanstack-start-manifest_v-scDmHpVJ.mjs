//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-scDmHpVJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/notice-emails",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BgRxe1As.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Cf3kijFT.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-LDlqx7ZR.js",
			"/assets/company-BuNay96v.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BgRxe1As.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CT6-anmk.js",
			"/assets/createServerFn-C5JuoSrz.js",
			"/assets/useRouterState-Cj2aQdx8.js",
			"/assets/auth-middleware-D1RAY25Y.js",
			"/assets/testers.functions-7999dUU8.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Cy3ENFT6.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/log-out-u24zIYYN.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-Cn773epn.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/accounting-CAODcN3D.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-jlmBNrVq.js",
			"/assets/button-DguD8olg.js",
			"/assets/dist-BmU6tsGW.js",
			"/assets/dialog-BMO52GxE.js",
			"/assets/queries-4Of6yNeP.js",
			"/assets/input-DohnJmJG.js",
			"/assets/label-60tjv2jp.js",
			"/assets/textarea-DsSaH5FD.js",
			"/assets/shoebox-DKLFqAUY.js",
			"/assets/reports-Bu693bkM.js",
			"/assets/access-D7WMxpKb.js",
			"/assets/theme-DSmdUDbZ.js",
			"/assets/Logo-DFI5dnf6.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-Co9y-6ON.js",
			"/assets/useRouterState-Cj2aQdx8.js",
			"/assets/admin.functions-DNWw3REI.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/log-out-u24zIYYN.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DFI5dnf6.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BYWEB1pm.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/label-60tjv2jp.js",
			"/assets/Logo-DFI5dnf6.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-BYd3_sB0.js",
			"/assets/testers.functions-7999dUU8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/coupons.functions-CIZmrpdM.js",
			"/assets/buy.functions-isgsSVSN.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DxbaqSfc.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/downloads.functions-BLjOYe8M.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-Vuefq4Iq.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/label-60tjv2jp.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-oQKh5tXf.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/label-60tjv2jp.js",
			"/assets/Logo-DFI5dnf6.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BE6FX9zo.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/upgrade.functions-iOC4o_uR.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-XPyFHEX2.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/label-60tjv2jp.js",
			"/assets/Logo-DFI5dnf6.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-D8LdAIn6.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-D4ZBX27X.js", "/assets/StockDocList-BPDZ_6oQ.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-C_s-kfuC.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/ai-CM5Vw46s.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-D5ARSLNy.js",
			"/assets/BankConnections-DA8kcjy3.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CZBkvOID.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-Bj_c3nAF.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-DA8kcjy3.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/ai-CM5Vw46s.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/loans-DbiSw5Uh.js",
			"/assets/TxnEditor-0reAaD4o.js",
			"/assets/feedWaiting-CSD6wV0H.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-DsRFlsYs.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-JZZAhP71.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-Cz-osTND.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/personal-C2jQydob.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/WhoPicker-Bkl7krO1.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BDiJlfTD.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-C1JK0sfA.js", "/assets/AccountRegister-B7ZshvSi.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Bt1FlKeT.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CNQMYh04.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/money-DfqUm6W8.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-C1lNxevr.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CM5Vw46s.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-3LthKArK.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CgipsBIk.js", "/assets/StockDocList-BPDZ_6oQ.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Zld6eyfl.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BjtRLyf0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/QuickBooksImport-CHQk5p6s.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-M7NW3S8b.js", "/assets/PartyList-NLURRQLz.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DTAkRoC-.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-BjHDagL1.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/storage.functions-oDo8L0Mo.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BD4WWTLm.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-Bvf_wu0z.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/booksStart-DT1W46vy.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-DGXaLSrz.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BX07yfMl.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CXUtWxoR.js", "/assets/ChangeHistory-D57duwFR.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-T_1z1Z-q.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/members-DKPaLFP6.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-Czy8Uauf.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/personal-C2jQydob.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/WhoPicker-Bkl7krO1.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-B8PN-nFw.js", "/assets/SalesList-ClAJ_7y2.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BDG1L-0T.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CCQhOkjV.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-C6zEFhBy.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CAxGpFi7.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/loans-DbiSw5Uh.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-C2rZ-juR.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-D5HeBuTY.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BS1Pm8OX.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/personal-C2jQydob.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/WhoPicker-Bkl7krO1.js",
			"/assets/reminders-DFa_IP0v.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DQQJo923.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CGln8wEL.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/personal-C2jQydob.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/WhoPicker-Bkl7krO1.js",
			"/assets/generateCategoricalChart-CI7YQwg9.js",
			"/assets/Area-CyTjHLQu.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-3FpQOEKE.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/generateCategoricalChart-CI7YQwg9.js",
			"/assets/PlCharts-DGXaLSrz.js",
			"/assets/BarChart-9JYcps1w.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-tf4EhFDf.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/balances-JZZAhP71.js",
			"/assets/money-DfqUm6W8.js",
			"/assets/DecimalInput-Bex5Dn81.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DHeuc00R.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-9ljXE_H7.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/storage.functions-oDo8L0Mo.js",
			"/assets/coupons.functions-CIZmrpdM.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-Ab-xymQM.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Co_fnony.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/DecimalInput-Bex5Dn81.js",
			"/assets/StockDialogs-BAkiz9Mk.js",
			"/assets/checkbox-DFBNSbqH.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-Bjaru8to.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-0QVJDHPS.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-3LthKArK.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-DMAMl8D9.js", "/assets/SalesList-ClAJ_7y2.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-DO5HM2kY.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/ai-CM5Vw46s.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-oDo8L0Mo.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-RAhE-DPN.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/money-DfqUm6W8.js",
			"/assets/badge-CZOGqx39.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Ct04NkdR.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CoFLTFwb.js", "/assets/AccountRegister-B7ZshvSi.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-CzAcYbYW.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/MoneyAccountPick-CQFayhmL.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-CnykHVfZ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-CIn0Ejl7.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/RepeatInvoice-CZseFjAz.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Ba5Fysly.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/sales-3LthKArK.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-CI7YQwg9.js",
			"/assets/BarChart-9JYcps1w.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CaptjsdZ.js", "/assets/SalesList-ClAJ_7y2.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-CbcjAEPf.js", "/assets/SalesList-ClAJ_7y2.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-B-51_-fA.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-gU6GILr3.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/serials-CHCUCDEN.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Bue4iUCl.js",
			"/assets/AppsCatalog-BTXcZQ92.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-aUYmvnfM.js",
			"/assets/switch-D5HeBuTY.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/QuickBooksImport-CHQk5p6s.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-EW3h9LbE.js",
			"/assets/footers-BKMFTBwT.js",
			"/assets/PrintFrame-DZ7YO94V.js",
			"/assets/checkbox-DFBNSbqH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BYntZpmM.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BAn4NpK2.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-BTXcZQ92.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-DA8kcjy3.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CNnRBuhB.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/StockDialogs-BAkiz9Mk.js",
			"/assets/photos-EW3h9LbE.js",
			"/assets/stockmove-OmsmaSYe.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CZ0wLaGE.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/loans-DbiSw5Uh.js",
			"/assets/feedWaiting-CSD6wV0H.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-oDo8L0Mo.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DbkqmNlh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/PrintFrame-DZ7YO94V.js",
			"/assets/DocPdf-bLyQF1Wa.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-csZIxeoI.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/MoneyAccountPick-CQFayhmL.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BYntZpmM.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C8-u-VQ8.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/StockDialogs-BAkiz9Mk.js",
			"/assets/stockmove-OmsmaSYe.js",
			"/assets/checkbox-DFBNSbqH.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-B2rgccWc.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/members-DKPaLFP6.js",
			"/assets/WhoPicker-Bkl7krO1.js",
			"/assets/reminders-DFa_IP0v.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CLVXMubU.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/tickets.functions-C94R-wzW.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-m-omE5Fz.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BYntZpmM.js",
			"/assets/support.functions-Dfq67Por.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-D51wCsUT.js", "/assets/StockDocList-BPDZ_6oQ.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-DcZge4jA.js", "/assets/PartyList-NLURRQLz.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets--79WQznN.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/tickets.functions-C94R-wzW.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-u0e-xHrc.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/workorders-_bHdmC6e.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CM-CMfhV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-s_wrvowy.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/coupons.functions-CIZmrpdM.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-Vw7yh_Rn.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/AdminAccount-JiIVaF4I.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CwTtvzpC.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/downloads.functions-BLjOYe8M.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B_m4kqF2.js",
			"/assets/createServerFn-C5JuoSrz.js",
			"/assets/auth-middleware-D1RAY25Y.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CdeirhCX.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-DHmG_LlC.js",
			"/assets/testers.functions-7999dUU8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-BHwQ-33w.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-C3yUZI-0.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DguD8olg.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-isgsSVSN.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DtioRYOS.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/textarea-DsSaH5FD.js",
			"/assets/support.functions-Dfq67Por.js",
			"/assets/HelpParts-bbd1wkmm.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BHkQsq5_.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BOeC0x28.js",
			"/assets/manual._slug-_es2ocYz.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-D1WWiYxI.js",
			"/assets/createServerFn-C5JuoSrz.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-B15mQPbX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DguD8olg.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-iOC4o_uR.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-Dpqrtcaq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CM5Vw46s.js",
			"/assets/personal-C2jQydob.js",
			"/assets/reminders-DFa_IP0v.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-vu0Txu2Q.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/AdminAccount-JiIVaF4I.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-4kYNSeWD.js", "/assets/ManualFrame-BOeC0x28.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-XhaV9Ziy.js", "/assets/AccountRegister-B7ZshvSi.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DQVBSFch.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/OriginalLink-BDUrE9Xv.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/realestate-Bm6HwfZS.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-Dlu0B44N.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/realestate-Bm6HwfZS.js",
			"/assets/money-DfqUm6W8.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-IOkh__Wf.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-DT1W46vy.js",
			"/assets/sales-3LthKArK.js",
			"/assets/SideList-4XuNV6NY.js",
			"/assets/PartyHistory-65A3jFc7.js",
			"/assets/tabs-BKCYmLtZ.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DxLqfQEL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/ChangeHistory-D57duwFR.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/sales-3LthKArK.js",
			"/assets/SideList-4XuNV6NY.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-Bex5Dn81.js",
			"/assets/StockDialogs-BAkiz9Mk.js",
			"/assets/NewProductDialog-CRVNN_-w.js",
			"/assets/MoneyAccountPick-CQFayhmL.js",
			"/assets/footers-BKMFTBwT.js",
			"/assets/PrintFrame-DZ7YO94V.js",
			"/assets/serials-CHCUCDEN.js",
			"/assets/SerialsBox-CcIRZxwU.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-u9-h0CJN.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-D57duwFR.js",
			"/assets/switch-D5HeBuTY.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CZOGqx39.js",
			"/assets/SideList-4XuNV6NY.js",
			"/assets/tabs-BKCYmLtZ.js",
			"/assets/StockDialogs-BAkiz9Mk.js",
			"/assets/photos-EW3h9LbE.js",
			"/assets/stockmove-OmsmaSYe.js",
			"/assets/serials-CHCUCDEN.js",
			"/assets/SerialsBox-CcIRZxwU.js",
			"/assets/workorders-_bHdmC6e.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-C1Na3DhA.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-KhuM1FMx.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/ChangeHistory-D57duwFR.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/booksStart-DT1W46vy.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/sales-3LthKArK.js",
			"/assets/SideList-4XuNV6NY.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-Bex5Dn81.js",
			"/assets/NewProductDialog-CRVNN_-w.js",
			"/assets/MoneyAccountPick-CQFayhmL.js",
			"/assets/footers-BKMFTBwT.js",
			"/assets/PrintFrame-DZ7YO94V.js",
			"/assets/cardpay-BhJUurE6.js",
			"/assets/checkbox-DFBNSbqH.js",
			"/assets/serials-CHCUCDEN.js",
			"/assets/workorders-_bHdmC6e.js",
			"/assets/RepeatInvoice-CZseFjAz.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-C94R-wzW.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D6ilbhkc.js",
			"/assets/select-QCNlnFqJ.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-3LthKArK.js",
			"/assets/SideList-4XuNV6NY.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-twV2S7WL.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/quickadd--wKt21sy.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BYntZpmM.js",
			"/assets/support.functions-Dfq67Por.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BiT_EwQz.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-B8JVA06E.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/SideList-4XuNV6NY.js",
			"/assets/PartyHistory-65A3jFc7.js",
			"/assets/tabs-BKCYmLtZ.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-5Gk-ziC3.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/sales-3LthKArK.js",
			"/assets/footers-BKMFTBwT.js",
			"/assets/tickets.functions-C94R-wzW.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CrpeiUzJ.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/input-DohnJmJG.js",
			"/assets/skeleton-6DnhQmem.js",
			"/assets/AdminAccount-JiIVaF4I.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-DUlMnQYq.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-DguD8olg.js",
			"/assets/textarea-DsSaH5FD.js",
			"/assets/support-BYntZpmM.js",
			"/assets/support.functions-Dfq67Por.js",
			"/assets/HelpParts-bbd1wkmm.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-DXqLrB1K.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-6DnhQmem.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
