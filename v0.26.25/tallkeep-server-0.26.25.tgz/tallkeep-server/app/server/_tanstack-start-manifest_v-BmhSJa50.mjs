//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BmhSJa50.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BdJiIKdY.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-DXVpr6Wk.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-4E1pO-le.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BdJiIKdY.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CuJWZG1M.js",
			"/assets/log-out-Bg-gvBFO.js",
			"/assets/testers.functions-DwzhkYbE.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DFtFBoUK.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-DU-HMIvN.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-DbKq593l.js",
			"/assets/button-T3CvU33F.js",
			"/assets/dist-DP-Y5d9Q.js",
			"/assets/dialog-0Wd2OlWu.js",
			"/assets/queries-fFdTFzI0.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/label-DWPPrJEh.js",
			"/assets/textarea-DkSbBLnj.js",
			"/assets/shoebox-DYtM2-7L.js",
			"/assets/company-Da37LYrM.js",
			"/assets/reports-IFBKsrp3.js",
			"/assets/access-CHwr4Mr6.js",
			"/assets/LicenseCard-DCtJ-LNy.js",
			"/assets/Logo-ttbT5C8O.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-SsYB-Pqr.js",
			"/assets/log-out-Bg-gvBFO.js",
			"/assets/admin.functions-DwX1MO3U.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-ttbT5C8O.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BKFL1HS-.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/label-DWPPrJEh.js",
			"/assets/Logo-ttbT5C8O.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-CTTrCGO4.js",
			"/assets/testers.functions-DwzhkYbE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/coupons.functions-drRHfAMQ.js",
			"/assets/buy.functions-BWMxgH58.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-B8zlrq8v.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/downloads.functions-DAOSMglX.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DP3_cS5O.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/label-DWPPrJEh.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-Dt0tjTXJ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/label-DWPPrJEh.js",
			"/assets/Logo-ttbT5C8O.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-Cx-Qtqdw.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/upgrade.functions-DNdLgPIt.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-FUL1gIan.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/label-DWPPrJEh.js",
			"/assets/Logo-ttbT5C8O.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-BrM5cJmW.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-B0-Qc6k9.js", "/assets/StockDocList-DgyxDiyK.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-MXTGhAmG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/ai-D5lTvSNa.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-DW4i_Ebz.js",
			"/assets/BankConnections-BOnNwETz.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-8JyVnJ2L.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BjGMEI5W.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-BOnNwETz.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/ai-D5lTvSNa.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DTw9-fr4.js",
			"/assets/TxnEditor-BnopI1dt.js",
			"/assets/feedWaiting-4jhOqMaZ.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-Ff78zZTC.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DC6JUEIC.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/personal-BoaYx94A.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/WhoPicker-tUNpXwfh.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-CfZ52C1G.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-DCq3Ao5v.js", "/assets/AccountRegister-BOWLcLm5.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-DGE19ym_.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BJtKUt1e.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/money-vT_MGBxO.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-Dz0m8TV-.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-D5lTvSNa.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-Ch_s1pLP.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-FpVCJOvA.js", "/assets/StockDocList-DgyxDiyK.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-Cq-xvOY6.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-D2FL96TE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-Crumu6Dk.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-2zVl0Ve-.js", "/assets/PartyList-CjvT-4fu.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-D_Y60sl5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-NLruMM4M.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/storage.functions-BXOafZ1X.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CkGCs6jq.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-D2igkc8H.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BYjqjcL8.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CXiLMDeY.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CN2p2VK1.js", "/assets/ChangeHistory-B-OS0TUV.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CmS1eqms.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/members-DUGTZzWW.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-Bdm_olDh.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/personal-BoaYx94A.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/WhoPicker-tUNpXwfh.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-HFAZ6vWl.js", "/assets/SalesList-oe-B1ZhC.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-CRnrit7s.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BkJOOOQe.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BpAH6XAG.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-B6R7oj8f.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/loans-DTw9-fr4.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-D1h1aAMq.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Ul8tQzYp.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-Dl71v_Z1.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/personal-BoaYx94A.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/WhoPicker-tUNpXwfh.js",
			"/assets/reminders-DJJKzZy7.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DB_dG0BQ.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-B-KaEsV1.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/personal-BoaYx94A.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/WhoPicker-tUNpXwfh.js",
			"/assets/generateCategoricalChart-otv3hJMU.js",
			"/assets/Area-BuyOiaiW.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-D0bzXv4V.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/generateCategoricalChart-otv3hJMU.js",
			"/assets/PlCharts-BYjqjcL8.js",
			"/assets/BarChart-C1JAQ6GU.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CqN0pO-f.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CxPm931L.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BXfJu5NE.js",
			"/assets/createServerFn-BkJz-PnA.js",
			"/assets/auth-middleware-GzrANzou.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/storage.functions-BXOafZ1X.js",
			"/assets/coupons.functions-drRHfAMQ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-Bxn_hat6.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DapMiZB6.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/checkbox-CLkoo0Y1.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DZ0DLl4x.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-loq_jEmP.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-COgw9NYa.js", "/assets/SalesList-oe-B1ZhC.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-60DOnqSV.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/ai-D5lTvSNa.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BXOafZ1X.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-w4bcdMCz.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/money-vT_MGBxO.js",
			"/assets/badge-BP_rp1WM.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-CidewcR7.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-CpxuBgWM.js", "/assets/AccountRegister-BOWLcLm5.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BTxbbpqd.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/MoneyAccountPick-Cy3WpYvw.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-Cb7VpTwn.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BaR3WyIO.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/RepeatInvoice-DpaI79Og.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CTBFupu7.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-otv3hJMU.js",
			"/assets/BarChart-C1JAQ6GU.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CdkCLHpJ.js", "/assets/SalesList-oe-B1ZhC.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-B_bHGNZw.js", "/assets/SalesList-oe-B1ZhC.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-DoClUEVd.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-ByETLliA.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/serials-CqBwNZpj.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings--7IAjYhM.js",
			"/assets/createServerFn-BkJz-PnA.js",
			"/assets/auth-middleware-GzrANzou.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-47h6ONPw.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-Bb9GPwLp.js",
			"/assets/switch-Ul8tQzYp.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-Crumu6Dk.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-CEpDAqIy.js",
			"/assets/footers-D5pDj3D3.js",
			"/assets/PrintFrame-DQ-42xni.js",
			"/assets/checkbox-CLkoo0Y1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DKd6vTvh.js",
			"/assets/FeaturePicker-OQJU-vV3.js",
			"/assets/support-DTGS2-EK.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-w0Y_545M.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/FeaturePicker-OQJU-vV3.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-e9buKgVI.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CLymDsu_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/photos-CEpDAqIy.js",
			"/assets/stockmove-BsZSY6N_.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BcZcp0qf.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/loans-DTw9-fr4.js",
			"/assets/feedWaiting-4jhOqMaZ.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BXOafZ1X.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-DXWJBS_g.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/PrintFrame-DQ-42xni.js",
			"/assets/DocPdf-AQByLk1K.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DKg_PmDu.js",
			"/assets/createServerFn-BkJz-PnA.js",
			"/assets/auth-middleware-GzrANzou.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/MoneyAccountPick-Cy3WpYvw.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DTGS2-EK.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BWUSovLr.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/StockDialogs-CLymDsu_.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/stockmove-BsZSY6N_.js",
			"/assets/checkbox-CLkoo0Y1.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DgvIfGmU.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/members-DUGTZzWW.js",
			"/assets/WhoPicker-tUNpXwfh.js",
			"/assets/reminders-DJJKzZy7.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-BPeJc-AH.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/tickets.functions-DdvXr3LW.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-Dev9Z18H.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DTGS2-EK.js",
			"/assets/support.functions-_KH2A3WZ.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-BqoFEs0G.js", "/assets/StockDocList-DgyxDiyK.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CxX4oHA3.js", "/assets/PartyList-CjvT-4fu.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-neU3Pybn.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/tickets.functions-DdvXr3LW.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-CNGsPRba.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/workorders-CEUflkbz.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-CmqK4-Y1.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-UGmCOUeZ.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/coupons.functions-drRHfAMQ.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BDdL8eSh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/AdminAccount-CHY2QZaX.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-CcgxIUn1.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/downloads.functions-DAOSMglX.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B5MZjTNR.js",
			"/assets/createServerFn-BkJz-PnA.js",
			"/assets/auth-middleware-GzrANzou.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-BgE10j9q.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Cr-dXZcB.js",
			"/assets/testers.functions-DwzhkYbE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-OABUpH0j.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BD-fVLoR.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-T3CvU33F.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BWMxgH58.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-n_8sKWvW.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/textarea-DkSbBLnj.js",
			"/assets/support.functions-_KH2A3WZ.js",
			"/assets/HelpParts-CK4V_rey.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CTSTujMG.js",
			"/assets/ManualFrame-De45fwmr.js",
			"/assets/manual._slug-kwAkaW9M.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CDz-DY6U.js",
			"/assets/createServerFn-BkJz-PnA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-JwJL2uxE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-T3CvU33F.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DNdLgPIt.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CFGHDqrA.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-D5lTvSNa.js",
			"/assets/personal-BoaYx94A.js",
			"/assets/reminders-DJJKzZy7.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DI72rM8A.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/AdminAccount-CHY2QZaX.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CqIDv9j4.js", "/assets/ManualFrame-De45fwmr.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CM0W_cKn.js", "/assets/AccountRegister-BOWLcLm5.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-DVxx2By4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/OriginalLink-Nq4xNij3.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/realestate-Dj3j00JK.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-ghmXJ_9P.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-MVSmjkyM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/realestate-Dj3j00JK.js",
			"/assets/money-vT_MGBxO.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-D4AGziqS.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/SideList-gHIcEHlM.js",
			"/assets/PartyHistory-C14clz6A.js",
			"/assets/tabs-Drx8l1l1.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CAIXma06.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-47h6ONPw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B-OS0TUV.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/SideList-gHIcEHlM.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-GIjJBXKN.js",
			"/assets/MoneyAccountPick-Cy3WpYvw.js",
			"/assets/footers-D5pDj3D3.js",
			"/assets/PrintFrame-DQ-42xni.js",
			"/assets/serials-CqBwNZpj.js",
			"/assets/SerialsBox-BLb1VROy.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-C64c9OCI.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-CLymDsu_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B-OS0TUV.js",
			"/assets/switch-Ul8tQzYp.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BP_rp1WM.js",
			"/assets/SideList-gHIcEHlM.js",
			"/assets/tabs-Drx8l1l1.js",
			"/assets/photos-CEpDAqIy.js",
			"/assets/stockmove-BsZSY6N_.js",
			"/assets/serials-CqBwNZpj.js",
			"/assets/SerialsBox-BLb1VROy.js",
			"/assets/workorders-CEUflkbz.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-NL6wqI7O.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-47h6ONPw.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-B-OS0TUV.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/SideList-gHIcEHlM.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-GIjJBXKN.js",
			"/assets/MoneyAccountPick-Cy3WpYvw.js",
			"/assets/footers-D5pDj3D3.js",
			"/assets/PrintFrame-DQ-42xni.js",
			"/assets/checkbox-CLkoo0Y1.js",
			"/assets/serials-CqBwNZpj.js",
			"/assets/workorders-CEUflkbz.js",
			"/assets/RepeatInvoice-DpaI79Og.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DdvXr3LW.js",
			"/assets/users.functions-DKd6vTvh.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-D6wfoSsG.js",
			"/assets/select-BfgjsI0k.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/SideList-gHIcEHlM.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-6MAMap4W.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/quickadd-CsMQ95Jv.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DTGS2-EK.js",
			"/assets/support.functions-_KH2A3WZ.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-BswTFeYK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DilrYXhs.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/SideList-gHIcEHlM.js",
			"/assets/PartyHistory-C14clz6A.js",
			"/assets/tabs-Drx8l1l1.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CBeHRqBE.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/sales-Ch_s1pLP.js",
			"/assets/footers-D5pDj3D3.js",
			"/assets/tickets.functions-DdvXr3LW.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-qzziDnzk.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-T3CvU33F.js",
			"/assets/input-DsYAhIJt.js",
			"/assets/skeleton-CO4Qzere.js",
			"/assets/AdminAccount-CHY2QZaX.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-CYm7iNDe.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-T3CvU33F.js",
			"/assets/textarea-DkSbBLnj.js",
			"/assets/support-DTGS2-EK.js",
			"/assets/support.functions-_KH2A3WZ.js",
			"/assets/HelpParts-CK4V_rey.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-Cus8xFBI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CO4Qzere.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
