import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-D1Pm-s70.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/coupons.functions-BN0rCVUY.js
/**
* Discount codes (friends and family, step 080). The owner makes them in the admin panel; each is
* also a Stripe coupon, which counts the uses and stops the code at its limit or end date.
* Customers type the code on the Buy page (desktop) or the Plan page (online).
*/
async function admin() {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	return supabaseAdmin;
}
var cleanCode = (c) => String(c ?? "").trim().toUpperCase().replace(/\s+/g, "").slice(0, 20);
/** "25% off" or "$100 off". */
function offLabel(c) {
	return c.percent_off != null ? `${Number(c.percent_off)}% off` : `$${Number(c.amount_off)} off`;
}
/** Ends after this day, Central time. */
var ended = (d) => !!d && Date.now() > (/* @__PURE__ */ new Date(`${d}T23:59:59-06:00`)).getTime();
/**
* The code, if it can be used now for this kind of purchase. Server only: Stripe's own count
* decides whether any uses are left.
*/
async function couponFor(code, kind) {
	const { data } = await (await admin()).from("coupons").select("*").eq("code", cleanCode(code)).maybeSingle();
	const c = data;
	if (!c || !c.active) return {
		ok: false,
		why: "That discount code isn't right."
	};
	if (kind === "desktop" && !c.for_desktop) return {
		ok: false,
		why: "That discount code is for online plans only."
	};
	if (kind === "online" && !c.for_online) return {
		ok: false,
		why: "That discount code is for the desktop version only."
	};
	if (ended(c.ends_on)) return {
		ok: false,
		why: "That discount code has ended."
	};
	const { stripe } = await import("./pay.server-Bz1c_WJg.mjs");
	if (!(await stripe(`coupons/${c.stripe_coupon}`).catch(() => null))?.valid) return {
		ok: false,
		why: "That discount code has been used up or has ended."
	};
	return {
		ok: true,
		coupon: c
	};
}
/** For the Buy and Plan pages: is this code good, and how much does it take off? */
var checkCoupon = createServerFn({ method: "GET" }).inputValidator((d) => ({
	code: cleanCode(d.code),
	kind: d.kind === "online" ? "online" : "desktop"
})).handler(createSsrRpc("81ebdc76d7715e2ec6681729423a391a581eb56db9bb3dbc43f9403df008c1e2"));
/** The discounted amount (what the checkout will show). */
function applyOff(total, c) {
	if (!c) return total;
	const off = c.percentOff != null ? total * c.percentOff / 100 : c.amountOff ?? 0;
	return Math.max(0, Math.round((total - off) * 100) / 100);
}
var listCoupons = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("a44e41254623c4d16ca20558834ecb427ea77f1edd06af1f90288510a5f2cec0"));
var makeCoupon = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const code = cleanCode(d.code);
	if (!/^[A-Z0-9-]{3,20}$/.test(code)) throw new Error("The code: 3 to 20 letters, numbers or dashes, like FAMILY25.");
	const amount = Number(d.amount);
	if (d.kind === "percent" && !(amount > 0 && amount <= 100)) throw new Error("Percent off: 1 to 100.");
	if (d.kind === "amount" && !(amount > 0 && amount <= 1e4)) throw new Error("Dollars off: more than 0.");
	if (!d.forDesktop && !d.forOnline) throw new Error("Pick desktop, online, or both.");
	const maxUses = d.maxUses ? Math.floor(Number(d.maxUses)) : null;
	if (maxUses != null && !(maxUses > 0 && maxUses <= 1e5)) throw new Error("How many people can use it: 1 or more, or leave it empty.");
	const endsOn = d.endsOn || null;
	if (endsOn && !/^\d{4}-\d{2}-\d{2}$/.test(endsOn)) throw new Error("Pick an end date.");
	if (endsOn && ended(endsOn)) throw new Error("The end date has already passed.");
	return {
		code,
		note: String(d.note ?? "").trim().slice(0, 200) || null,
		kind: d.kind === "amount" ? "amount" : "percent",
		amount: Math.round(amount * 100) / 100,
		forDesktop: !!d.forDesktop,
		forOnline: !!d.forOnline,
		onlineForever: !!d.onlineForever,
		maxUses,
		endsOn
	};
}).handler(createSsrRpc("7b34d63ea96b170441073a82e6c0dfeaf7194cadc7a8470d3c30f5a2a2aa0bbb"));
/** Stop a code: nobody can use it from now on. People who already used it keep their price. */
var stopCoupon = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^[0-9a-f-]{36}$/.test(d.id)) throw new Error("Bad request");
	return d;
}).handler(createSsrRpc("fea8d2c8e298f5cdcd63c09456ca7e1cbaac5986c9fb9709f7bec4c9549bf574"));
//#endregion
export { applyOff, checkCoupon, couponFor, listCoupons, makeCoupon, offLabel, stopCoupon };
