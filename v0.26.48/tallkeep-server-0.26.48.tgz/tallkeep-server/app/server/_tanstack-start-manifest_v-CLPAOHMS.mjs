//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CLPAOHMS.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/notice-emails",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-B3yVXb9m.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-BUaA4qFk.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-DyaYQvBs.js",
			"/assets/company-Bg4AVpt8.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3yVXb9m.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CkektAXJ.js",
			"/assets/createServerFn-J_m5yMBY.js",
			"/assets/log-out-Cnc0SZGN.js",
			"/assets/auth-middleware-BBhEoTgC.js",
			"/assets/testers.functions-KgnjiuSD.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-CkHJ_jSs.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DijDlpw5.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-6ppsgyNy.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/accounting-D2g-KBXr.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-B5mY7b2V.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/dist-B1RFGsXc.js",
			"/assets/dialog-BedEV0tN.js",
			"/assets/queries-C0I5ELHh.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/label-CiDhJZqG.js",
			"/assets/textarea-BqQiAj1B.js",
			"/assets/shoebox-Oc7BASz3.js",
			"/assets/reports-BkmPOC1o.js",
			"/assets/access-Dz-RDmSk.js",
			"/assets/theme-CPXEkhdV.js",
			"/assets/Logo-CvszJ9cA.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-BIFTV6wV.js",
			"/assets/log-out-Cnc0SZGN.js",
			"/assets/admin.functions-DvA4i9rV.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CvszJ9cA.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-BRV0Q9KB.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/label-CiDhJZqG.js",
			"/assets/Logo-CvszJ9cA.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-C3e9C9dT.js",
			"/assets/testers.functions-KgnjiuSD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/coupons.functions-Bs4MfdhD.js",
			"/assets/buy.functions-DCI9L37b.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-44hCeF5N.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/downloads.functions-t7NwIDe1.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BCWDs3x6.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/label-CiDhJZqG.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-PGLoExkq.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/label-CiDhJZqG.js",
			"/assets/Logo-CvszJ9cA.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BA-qRaH7.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/upgrade.functions-B0h1R2Q2.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-BBOGtV3l.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/label-CiDhJZqG.js",
			"/assets/Logo-CvszJ9cA.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CW6oWa_a.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DKcCmaAp.js", "/assets/StockDocList-BZZVBvNE.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-DueSkrSN.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/ai-CgsZL7SZ.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BO37UdoV.js",
			"/assets/BankConnections-CcwBUF1f.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-BfGiw3Ap.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-B2OXW5ck.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-CcwBUF1f.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/ai-CgsZL7SZ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/loans-BwJthuFN.js",
			"/assets/TxnEditor-CawbRCA8.js",
			"/assets/feedWaiting-DeregHUu.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-C77G00OU.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-CDLM7xMm.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-C1AmGajM.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/personal-D2XeGCSU.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/WhoPicker-UNud08g8.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-BTIlct0k.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BjGvLNee.js", "/assets/AccountRegister-DSPMUX_i.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-HV_1TJze.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BYWLsF1x.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/money-BBIifUfN.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BMCAbG9I.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CgsZL7SZ.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-B3_TBEon.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-IJqHu2F3.js", "/assets/StockDocList-BZZVBvNE.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D7IhKEhP.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CHKYHICT.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/QuickBooksImport-D-QZrSts.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-CVSyvBE2.js", "/assets/PartyList-BziJwFy3.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Cwpqmxnt.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Bg36htN5.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/storage.functions-Dml2LPeB.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-Dd11ssn8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BWVtQaAD.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/booksStart-1DWT0dMm.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-BGeB_jOG.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BepiBviQ.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CfdNFjeC.js", "/assets/ChangeHistory-xGiR5mjj.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-z7D7p4QE.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/members-9OaUrFLC.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-C84IsDOj.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/personal-D2XeGCSU.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/WhoPicker-UNud08g8.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-B49mMxwM.js", "/assets/SalesList-C2i3rY2F.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BC1eDPm-.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CqYWCV9h.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-DYHKIdZn.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-BZQvhBwr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/loans-BwJthuFN.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-VzOowf8k.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Hu2T1zXo.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-x-7zfjJa.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/personal-D2XeGCSU.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/WhoPicker-UNud08g8.js",
			"/assets/reminders-CZDd9lPg.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DvVNAhpb.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-BvBmlFwm.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/personal-D2XeGCSU.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/WhoPicker-UNud08g8.js",
			"/assets/generateCategoricalChart-BFMPreCb.js",
			"/assets/Area-Bg-ZYaxN.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-Bxjjr0Hy.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/generateCategoricalChart-BFMPreCb.js",
			"/assets/PlCharts-BGeB_jOG.js",
			"/assets/BarChart-DmM8sjqj.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CahrnIb8.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/balances-CDLM7xMm.js",
			"/assets/money-BBIifUfN.js",
			"/assets/DecimalInput-BHE4JB-O.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BmvtWT-X.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-jmFCC4NL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/storage.functions-Dml2LPeB.js",
			"/assets/coupons.functions-Bs4MfdhD.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-DYkPXtye.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-7UOcPC32.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/DecimalInput-BHE4JB-O.js",
			"/assets/StockDialogs-lBigwDSB.js",
			"/assets/checkbox-RFsSZUWM.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-BO-LMPb1.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-DY_s-mJw.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BnbrOgz2.js", "/assets/SalesList-C2i3rY2F.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BLGvgWv0.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/ai-CgsZL7SZ.js",
			"/assets/bankfile-Cp_S7cap.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Dml2LPeB.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BAlsBVvB.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/money-BBIifUfN.js",
			"/assets/badge-BD-sdDbr.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-B_zXZDE9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BzsNWF-1.js", "/assets/AccountRegister-DSPMUX_i.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-Czr9vweK.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/MoneyAccountPick-30bNHYR9.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-B0TI-qLr.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DlVuh_tS.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/RepeatInvoice-B7QepkcI.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CGmHred8.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-BFMPreCb.js",
			"/assets/BarChart-DmM8sjqj.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-CE0oLyft.js", "/assets/SalesList-C2i3rY2F.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-DhjRP41M.js", "/assets/SalesList-C2i3rY2F.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-DuinUa_j.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-Bur7Z42g.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/serials-Df12SOE1.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DqBugWS-.js",
			"/assets/AppsCatalog-CX2915c6.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DnAdQ-t4.js",
			"/assets/switch-Hu2T1zXo.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/QuickBooksImport-D-QZrSts.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-bZXE37Bn.js",
			"/assets/footers-Blagk5Nm.js",
			"/assets/PrintFrame-Cpgbl1XU.js",
			"/assets/checkbox-RFsSZUWM.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CucZz99C.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-DvrQMcTb.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-CX2915c6.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-CcwBUF1f.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-LGY5LjW-.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/StockDialogs-lBigwDSB.js",
			"/assets/photos-bZXE37Bn.js",
			"/assets/stockmove-C9xvY4NL.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CSBmujii.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/loans-BwJthuFN.js",
			"/assets/feedWaiting-DeregHUu.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-Dml2LPeB.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CheRnQcW.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/PrintFrame-Cpgbl1XU.js",
			"/assets/DocPdf-sMJ3DHFf.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-tq4vc8gH.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickbooks-ClprSeAo.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/MoneyAccountPick-30bNHYR9.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CucZz99C.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-BxTlVMvU.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/StockDialogs-lBigwDSB.js",
			"/assets/stockmove-C9xvY4NL.js",
			"/assets/checkbox-RFsSZUWM.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-C_ipjdU4.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/members-9OaUrFLC.js",
			"/assets/WhoPicker-UNud08g8.js",
			"/assets/reminders-CZDd9lPg.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CwTTdDLh.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/tickets.functions-BUOJRfGP.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CD5QMWU2.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CucZz99C.js",
			"/assets/support.functions-D_Ox2QiX.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-DZ8Gf3xG.js", "/assets/StockDocList-BZZVBvNE.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-ZAmKz8e4.js", "/assets/PartyList-BziJwFy3.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BRekSocc.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/tickets.functions-BUOJRfGP.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-cnQanMAI.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/workorders-DYYlFz6j.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-3UtW-ULk.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/cryptotax-C3_MCr2c.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-CAMQ_jEH.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/coupons.functions-Bs4MfdhD.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-BxwY34cs.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/AdminAccount-DFipQcJj.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BgvESSP0.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/downloads.functions-t7NwIDe1.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-KKaSRAvI.js",
			"/assets/createServerFn-J_m5yMBY.js",
			"/assets/auth-middleware-BBhEoTgC.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-kEkr_VK1.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-C_XDtjxW.js",
			"/assets/testers.functions-KgnjiuSD.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-DgtqqkLA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BsImXHnE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-DCI9L37b.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-CaJLJ6RE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/textarea-BqQiAj1B.js",
			"/assets/support.functions-D_Ox2QiX.js",
			"/assets/HelpParts-D63mpqnF.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-CjVXnuFe.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DA29clVx.js",
			"/assets/manual._slug-CnbSB8jn.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-DNZi2TXu.js",
			"/assets/createServerFn-J_m5yMBY.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-DQDGD52c.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-B0h1R2Q2.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DuucEGD1.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CgsZL7SZ.js",
			"/assets/personal-D2XeGCSU.js",
			"/assets/reminders-CZDd9lPg.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CSmMAECn.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/AdminAccount-DFipQcJj.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-DMu3PUt-.js", "/assets/ManualFrame-DA29clVx.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-CcMa_mXe.js", "/assets/AccountRegister-DSPMUX_i.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-B-tOxSig.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/OriginalLink-DXd4ppSH.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/realestate-BOae6dtw.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-BZ0sRz5m.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/realestate-BOae6dtw.js",
			"/assets/money-BBIifUfN.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CJwOddsV.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-1DWT0dMm.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/SideList-CKIMm8PV.js",
			"/assets/PartyHistory-B2cFT1_L.js",
			"/assets/tabs-Pu4A5LJA.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-BHvg2v2l.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/ChangeHistory-xGiR5mjj.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/SideList-CKIMm8PV.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-BHE4JB-O.js",
			"/assets/StockDialogs-lBigwDSB.js",
			"/assets/NewProductDialog-Bfwp7uKA.js",
			"/assets/MoneyAccountPick-30bNHYR9.js",
			"/assets/footers-Blagk5Nm.js",
			"/assets/PrintFrame-Cpgbl1XU.js",
			"/assets/serials-Df12SOE1.js",
			"/assets/SerialsBox-aKp2AeUn.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-CWuaPjAe.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-xGiR5mjj.js",
			"/assets/switch-Hu2T1zXo.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-BD-sdDbr.js",
			"/assets/SideList-CKIMm8PV.js",
			"/assets/tabs-Pu4A5LJA.js",
			"/assets/StockDialogs-lBigwDSB.js",
			"/assets/photos-bZXE37Bn.js",
			"/assets/stockmove-C9xvY4NL.js",
			"/assets/serials-Df12SOE1.js",
			"/assets/SerialsBox-aKp2AeUn.js",
			"/assets/workorders-DYYlFz6j.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-B-5VP4AL.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/truck-CwDCldzf.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/ChangeHistory-xGiR5mjj.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/booksStart-1DWT0dMm.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/SideList-CKIMm8PV.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-BHE4JB-O.js",
			"/assets/NewProductDialog-Bfwp7uKA.js",
			"/assets/MoneyAccountPick-30bNHYR9.js",
			"/assets/footers-Blagk5Nm.js",
			"/assets/PrintFrame-Cpgbl1XU.js",
			"/assets/cardpay-BUiPJ21k.js",
			"/assets/checkbox-RFsSZUWM.js",
			"/assets/serials-Df12SOE1.js",
			"/assets/workorders-DYYlFz6j.js",
			"/assets/RepeatInvoice-B7QepkcI.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BUOJRfGP.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-XHSz4o30.js",
			"/assets/select-BXL8c7SV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/SideList-CKIMm8PV.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-yEiaURWT.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/quickadd-Al1oz7nj.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CucZz99C.js",
			"/assets/support.functions-D_Ox2QiX.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-HMFY3lM8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DWa9Nj4h.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/SideList-CKIMm8PV.js",
			"/assets/PartyHistory-B2cFT1_L.js",
			"/assets/tabs-Pu4A5LJA.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-D_xsEfwj.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/sales-B3_TBEon.js",
			"/assets/footers-Blagk5Nm.js",
			"/assets/tickets.functions-BUOJRfGP.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DekFEGLv.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/input-DK4rSVGh.js",
			"/assets/skeleton-tB6ii2FW.js",
			"/assets/AdminAccount-DFipQcJj.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-B7_6hGnU.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-5wfF0Rjg.js",
			"/assets/textarea-BqQiAj1B.js",
			"/assets/support-CucZz99C.js",
			"/assets/support.functions-D_Ox2QiX.js",
			"/assets/HelpParts-D63mpqnF.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-gKE0MbMS.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-tB6ii2FW.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
