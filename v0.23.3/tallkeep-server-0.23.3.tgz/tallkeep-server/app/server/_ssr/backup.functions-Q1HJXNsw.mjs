import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/backup.functions-Q1HJXNsw.js
async function requireAdmin(userId) {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
	if (!data) throw new Error("Only an admin can do this.");
	const { data: m } = await supabaseAdmin.from("org_members").select("orgs(is_platform)").eq("user_id", userId).maybeSingle();
	if (!m?.orgs?.is_platform) throw new Error("Backups are kept for you by Tallkeep.");
}
var listBackups_createServerFn_handler = createServerRpc({
	id: "d1de4cd6c5fed7ab6d4819651136ceb161a48b3ea783c0171bce0c384b4914f4",
	name: "listBackups",
	filename: "src/lib/backup.functions.ts"
}, (opts) => listBackups.__executeServer(opts));
var listBackups = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listBackups_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const { listBackupFiles } = await import("./backup.server-BRasnfEA.mjs");
	return listBackupFiles();
});
var backupNow_createServerFn_handler = createServerRpc({
	id: "68245375509608cf53f821532abc75914db1edaec535ba1975049ebadeb65f05",
	name: "backupNow",
	filename: "src/lib/backup.functions.ts"
}, (opts) => backupNow.__executeServer(opts));
var backupNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(backupNow_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const { makeBackup } = await import("./backup.server-BRasnfEA.mjs");
	return makeBackup("Backup now button");
});
var backupLink_createServerFn_handler = createServerRpc({
	id: "dbbb396530bca0dd8e8e455c118509c777c88ea9fb7ca04effe9f4459aa5d083",
	name: "backupLink",
	filename: "src/lib/backup.functions.ts"
}, (opts) => backupLink.__executeServer(opts));
var backupLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(backupLink_createServerFn_handler, async ({ data, context }) => {
	await requireAdmin(context.userId);
	const { signedLink } = await import("./backup.server-BRasnfEA.mjs");
	return { url: await signedLink(data.name) };
});
var uploadBackup_createServerFn_handler = createServerRpc({
	id: "aab17122cc1986c06006ca74c6e3931f6572464fb86f3077a1ed4f46448288f6",
	name: "uploadBackup",
	filename: "src/lib/backup.functions.ts"
}, (opts) => uploadBackup.__executeServer(opts));
var uploadBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d.fileBase64 || d.fileBase64.length > 2e7) throw new Error("That file is too big.");
	return d;
}).handler(uploadBackup_createServerFn_handler, async ({ data, context }) => {
	await requireAdmin(context.userId);
	const { saveUploadedBackup } = await import("./backup.server-BRasnfEA.mjs");
	return { name: await saveUploadedBackup(data.fileBase64) };
});
var summarizeBackup_createServerFn_handler = createServerRpc({
	id: "d977603f5bbf94db864ead1e021883062b18ace6c6570fb34ac0f34bc925208b",
	name: "summarizeBackup",
	filename: "src/lib/backup.functions.ts"
}, (opts) => summarizeBackup.__executeServer(opts));
var summarizeBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(summarizeBackup_createServerFn_handler, async ({ data, context }) => {
	await requireAdmin(context.userId);
	const { backupSummary } = await import("./backup.server-BRasnfEA.mjs");
	return backupSummary(data.name);
});
var restoreFromBackup_createServerFn_handler = createServerRpc({
	id: "2c5a14efae666c66f9050e983d7ee7530c86790708cd112a473bd68c78ed1c0e",
	name: "restoreFromBackup",
	filename: "src/lib/backup.functions.ts"
}, (opts) => restoreFromBackup.__executeServer(opts));
var restoreFromBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.confirm !== "RESTORE") throw new Error("Type RESTORE to confirm.");
	return d;
}).handler(restoreFromBackup_createServerFn_handler, async ({ data, context }) => {
	await requireAdmin(context.userId);
	const { restoreBackup, RESTORE_PARTS } = await import("./backup.server-BRasnfEA.mjs");
	const parts = data.parts.filter((p) => p in RESTORE_PARTS);
	return restoreBackup(data.name, parts);
});
//#endregion
export { backupLink_createServerFn_handler, backupNow_createServerFn_handler, listBackups_createServerFn_handler, restoreFromBackup_createServerFn_handler, summarizeBackup_createServerFn_handler, uploadBackup_createServerFn_handler };
