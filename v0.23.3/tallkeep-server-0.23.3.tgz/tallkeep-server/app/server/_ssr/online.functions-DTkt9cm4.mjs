import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/online.functions-DTkt9cm4.js
/**
* Plan & billing for online accounts: see the plan, pick one and pay (Stripe Checkout), change
* it, and open Stripe's billing page (card, invoices, cancel). Needs STRIPE_SECRET_KEY.
*/
var getMyPlan_createServerFn_handler = createServerRpc({
	id: "b168eb565a3c4c37801f615d46b1b01ff96ab06ee481f6e9aa59fd2226349aca",
	name: "getMyPlan",
	filename: "src/lib/online.functions.ts"
}, (opts) => getMyPlan.__executeServer(opts));
var getMyPlan = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyPlan_createServerFn_handler, async ({ context }) => {
	const s = await import("./online.server-DkUxq57c.mjs");
	const { YEARLY_MONTHS } = await import("./editions-CIhnK_Ff.mjs").then((n) => n.c).then((n) => n.l);
	const o = await s.myOrg(context.userId, false);
	const { data: r } = await (await s.admin()).from("user_roles").select("role").eq("user_id", context.userId).eq("role", "admin").maybeSingle();
	const cat = await s.onlineCatalog();
	return {
		admin: !!r,
		status: o.status,
		trialEndsAt: o.trial_ends_at,
		plan: o.plan,
		addons: o.plan_addons ?? [],
		billing: o.billing,
		paidUntil: o.paid_until,
		endsAt: o.ends_at,
		closedAt: o.closed_at,
		companiesAllowed: o.companies_allowed,
		usersAllowed: o.users_allowed,
		aiPagesMonth: o.ai_pages_month,
		subscribed: !!o.stripe_subscription && o.status !== "canceled",
		catalog: cat,
		yearlyMonths: YEARLY_MONTHS,
		ready: !!process.env["STRIPE_SECRET_KEY"]
	};
});
var startPlan_createServerFn_handler = createServerRpc({
	id: "933c1ca8d375ab289a5dfd5976fb3f49a00e899e5cf12e5fab59401ca0776648",
	name: "startPlan",
	filename: "src/lib/online.functions.ts"
}, (opts) => startPlan.__executeServer(opts));
var startPlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(startPlan_createServerFn_handler, async ({ data, context }) => {
	const s = await import("./online.server-DkUxq57c.mjs");
	const { stripe } = await import("./pay.server-M8NRQT-4.mjs");
	const o = await s.myOrg(context.userId, true);
	if (o.is_platform) throw new Error("Our own account doesn't need a plan.");
	if (o.stripe_subscription && o.status !== "canceled") throw new Error("You already have a plan. Use Change plan instead.");
	const pick = s.cleanPick(data);
	const lines = await s.planLines(pick);
	const origin = /^https?:\/\/[^/]+$/.test(data.origin) ? data.origin : "https://app.tallkeep.com";
	const form = {
		mode: "subscription",
		billing_address_collection: "required",
		client_reference_id: o.id,
		success_url: `${origin}/plan?session={CHECKOUT_SESSION_ID}`,
		cancel_url: `${origin}/plan`,
		allow_promotion_codes: "true",
		...s.pickMetadata(pick, o.id, "metadata"),
		...s.pickMetadata(pick, o.id, "subscription_data[metadata]")
	};
	lines.forEach((l, i) => {
		form[`line_items[${i}][price_data][currency]`] = "usd";
		form[`line_items[${i}][price_data][product]`] = l.product;
		form[`line_items[${i}][price_data][unit_amount]`] = String(l.cents);
		form[`line_items[${i}][price_data][recurring][interval]`] = pick.yearly ? "year" : "month";
		form[`line_items[${i}][quantity]`] = String(l.qty);
	});
	if (o.stripe_customer) form["customer"] = o.stripe_customer;
	else if (context.claims?.email) form["customer_email"] = String(context.claims.email);
	return { url: (await stripe("checkout/sessions", form)).url };
});
var confirmPlan_createServerFn_handler = createServerRpc({
	id: "7f27d5ec54cebdfb5629c9cd0bc5f278a3edf0eda72aaee7f43bdad2dd29802e",
	name: "confirmPlan",
	filename: "src/lib/online.functions.ts"
}, (opts) => confirmPlan.__executeServer(opts));
var confirmPlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^cs_[A-Za-z0-9_]+$/.test(d.session)) throw new Error("Bad request");
	return d;
}).handler(confirmPlan_createServerFn_handler, async ({ data, context }) => {
	const s = await import("./online.server-DkUxq57c.mjs");
	const { stripe } = await import("./pay.server-M8NRQT-4.mjs");
	const o = await s.myOrg(context.userId, false);
	const cs = await stripe(`checkout/sessions/${data.session}`);
	if (cs.metadata?.["org"] !== o.id || !cs.subscription) return { active: false };
	const row = await s.syncOnline(cs.subscription);
	return { active: row?.status === "active" || row?.status === "past_due" };
});
var changePlan_createServerFn_handler = createServerRpc({
	id: "e6ad388e4f4d689ee36066da5516f97d165c190e2072efb91cd8bedf5f8a581f",
	name: "changePlan",
	filename: "src/lib/online.functions.ts"
}, (opts) => changePlan.__executeServer(opts));
var changePlan = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(changePlan_createServerFn_handler, async ({ data, context }) => {
	const s = await import("./online.server-DkUxq57c.mjs");
	const { stripe } = await import("./pay.server-M8NRQT-4.mjs");
	const o = await s.myOrg(context.userId, true);
	if (!o.stripe_subscription || o.status === "canceled") throw new Error("Pick a plan first.");
	if (data.resume) {
		await stripe(`subscriptions/${encodeURIComponent(o.stripe_subscription)}`, { cancel_at_period_end: "false" });
		await s.syncOnline(o.stripe_subscription);
		return { ok: true };
	}
	const pick = s.cleanPick(data);
	const db = await s.admin();
	const [{ count: cos }, { count: people }] = await Promise.all([db.from("companies").select("id", {
		count: "exact",
		head: true
	}).eq("org_id", o.id), db.from("org_members").select("user_id", {
		count: "exact",
		head: true
	}).eq("org_id", o.id)]);
	const { onlineBundle } = await import("./editions-CIhnK_Ff.mjs").then((n) => n.c).then((n) => n.l);
	const b = onlineBundle(await s.onlineCatalog(), pick.plan, pick.addons, pick.extraUsers, pick.extraCompanies, pick.yearly);
	if ((cos ?? 0) > b.companies) throw new Error(`You have ${cos} companies; this plan includes ${b.companies}. Add companies to the plan first.`);
	if ((people ?? 0) > b.users) throw new Error(`You have ${people} people; this plan includes ${b.users}. Add people to the plan first.`);
	const sub = await s.readSub(o.stripe_subscription);
	const lines = await s.planLines(pick);
	const form = {
		proration_behavior: "always_invoice",
		cancel_at_period_end: "false",
		...s.pickMetadata(pick, o.id, "metadata")
	};
	let i = 0;
	for (const it of sub.items?.data ?? []) {
		form[`items[${i}][id]`] = it.id;
		form[`items[${i}][deleted]`] = "true";
		i++;
	}
	for (const l of lines) {
		form[`items[${i}][price_data][currency]`] = "usd";
		form[`items[${i}][price_data][product]`] = l.product;
		form[`items[${i}][price_data][unit_amount]`] = String(l.cents);
		form[`items[${i}][price_data][recurring][interval]`] = pick.yearly ? "year" : "month";
		form[`items[${i}][quantity]`] = String(l.qty);
		i++;
	}
	await stripe(`subscriptions/${encodeURIComponent(o.stripe_subscription)}`, form);
	await s.syncOnline(o.stripe_subscription);
	return { ok: true };
});
var billingPage_createServerFn_handler = createServerRpc({
	id: "83d5228d9d2f21cc7666fad6650ccbd34fb718c930a17044834da3eee01e2c62",
	name: "billingPage",
	filename: "src/lib/online.functions.ts"
}, (opts) => billingPage.__executeServer(opts));
var billingPage = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(billingPage_createServerFn_handler, async ({ data, context }) => {
	const s = await import("./online.server-DkUxq57c.mjs");
	const { stripe } = await import("./pay.server-M8NRQT-4.mjs");
	const o = await s.myOrg(context.userId, true);
	if (!o.stripe_customer) throw new Error("Pick a plan first.");
	const origin = /^https?:\/\/[^/]+$/.test(data.origin) ? data.origin : "https://app.tallkeep.com";
	return { url: (await stripe("billing_portal/sessions", {
		customer: o.stripe_customer,
		return_url: `${origin}/plan`
	})).url };
});
//#endregion
export { billingPage_createServerFn_handler, changePlan_createServerFn_handler, confirmPlan_createServerFn_handler, getMyPlan_createServerFn_handler, startPlan_createServerFn_handler };
