import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/register-BFhWSjS5.js
var $$splitComponentImporter = () => import("./register-DwBdO5xz.mjs");
var Route = createFileRoute("/_authenticated/register")({
	validateSearch: (s) => typeof s["account"] === "string" ? { account: s["account"] } : {},
	head: () => ({ meta: [{ title: "Check Register · Tallkeep" }, {
		name: "description",
		content: "Every check, deposit and payment in a bank account, with the running balance."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
