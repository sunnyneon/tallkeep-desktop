import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as SalesList } from "./SalesList-CfNc9yha.mjs";
import { t as Route } from "./sales-list-DBH4JLY0.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-list-GWxt34vS.js
var import_jsx_runtime = require_jsx_runtime();
function SalesListPage() {
	const { pay } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesList, {
		title: "Sales List",
		text: "All quotes, invoices and RMAs. Use the buttons to show just one kind.",
		newKind: "quote",
		newLabel: "New quote",
		initial: {
			show: "all",
			inv: "all",
			pay: "all",
			cancelled: false
		},
		preset: pay ? {
			show: "orders",
			inv: "all",
			pay,
			cancelled: false
		} : void 0
	});
}
//#endregion
export { SalesListPage as component };
