import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, n as fmtDate } from "./format-CgElbAz-.mjs";
import { t as supabase } from "./client-B0-rkFMZ.mjs";
import { n as db, r as fetchAll } from "./db-iarOtr4g.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useMyCompanies, i as switchCompany, t as activeCompanyId } from "./company-BeFli3N-.mjs";
import { n as BUSINESS_TYPES, o as useAddons, t as ADDONS } from "./addons-Cr2K7fBW.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as accountLabel, p as useAccounts, s as dayBefore, u as loadAccounts } from "./accounting-CH-I30Eo.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-DM6IYjuX.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { a as num, o as parseCsv } from "./quickbooks-C8hql6PT.mjs";
import { At as Globe, Gt as Download, N as RotateCcw, Nt as FolderOpen, Yt as Copy, dt as LoaderCircle, g as Trash2, ln as ChevronDown, m as TriangleAlert, n as X, o as Volume2, on as ChevronUp, qt as DatabaseBackup, rn as CircleCheck, tt as Moon, u as Upload, z as Plus } from "../_libs/lucide-react.mjs";
import { a as useIsOwner, d as useTaxRates, i as useIsAdmin } from "./queries-DVi6EtjC.mjs";
import { t as ZONES } from "./access-QkYq46LF.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { t as Switch } from "./switch-Dkd0-FGF.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as handOverOwner, c as peopleCount, i as changeUser, l as removeUser, r as addUser, s as listUsers, t as Field, u as setCompanyAccess } from "./PartyForm-BZxe_KOa.mjs";
import { n as siteKind, r as versionLabel } from "./version-DqRiRJDf.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { n as QuickBooksImport } from "./QuickBooksImport-CjSDoqdE.mjs";
import { r as makeZip, t as downloadBlob } from "./csv-D0ewwTlm.mjs";
import { a as fillWording, i as WORDING_KINDS, n as FIELD_HELP, r as SAMPLE_VALUES, t as DEFAULT_WORDING } from "./emailWording-D3tWNGRw.mjs";
import { o as stageOf, t as DEFAULT_RULES } from "./followups-CAmQFMgv.mjs";
import { c as publicOrigin, l as slugFrom } from "./support--KTH96Ik.mjs";
import "./photos-CgVLifBr.mjs";
import { r as PLACEMENTS, s as useFooters, t as FOOTER_KINDS } from "./footers-HhgtB165.mjs";
import { t as Checkbox } from "./checkbox-DO7eC_vL.mjs";
import { n as useCompanyLogo } from "./PrintFrame-YpJit6qi.mjs";
import { _ as useMyAccount, f as setSoundOn, h as trialDaysLeft, i as UpdatesCard, l as play, m as soundOn, n as LicenseCard, o as canWrite, p as setTheme, s as getTheme, t as DockerUpdatesCard } from "./theme-D1ynM4fp.mjs";
import { a as EmailSetupCard, i as CardPaymentsCard, o as FeaturePicker, r as AppsCatalog, s as RemindersCard } from "./AppsCatalog-BlYvFHQp.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/settings-DoBIqmX8.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Sales tax rates: the list you pick from on quotes, invoices and purchase orders. Change a name
* or rate, add one, or stop offering one (it stays on the documents that already use it).
*/
function TaxRatesCard() {
	const qc = useQueryClient();
	const { data: rates } = useTaxRates();
	const [showOff, setShowOff] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [rate, setRate] = (0, import_react.useState)("");
	const refresh = () => void qc.invalidateQueries({ queryKey: ["tax_rates"] });
	async function save(r, patch) {
		const { error } = await db.from("tax_rates").update(patch).eq("id", r.id);
		if (error) return void toast.error(error.message);
		toast.success("Saved.");
		refresh();
	}
	async function add() {
		const n = name.trim();
		const v = Number(rate);
		if (!n) return void toast.error("Type a name, like Dallas Sales Tax.");
		if (!Number.isFinite(v) || v < 0 || v > 30) return void toast.error("Type the rate as a percent, like 8.25.");
		const { error } = await db.from("tax_rates").insert({
			name: n,
			rate: v,
			is_active: true
		});
		if (error) return void toast.error(error.message);
		toast.success(`${n} added.`);
		setName("");
		setRate("");
		refresh();
	}
	const list = (rates ?? []).filter((r) => showOff || r.is_active);
	const { data: usedTaxes } = useQuery({
		queryKey: ["tax_rates", "used"],
		queryFn: async () => {
			const { data } = await db.from("sales_orders").select("tax_name,tax_rate").gt("tax_rate", 0).order("order_date", { ascending: false }).limit(500);
			const seen = /* @__PURE__ */ new Map();
			for (const r of data ?? []) {
				const name = (r.tax_name ?? "Sales tax").trim() || "Sales tax";
				seen.set(`${name}|${Number(r.tax_rate)}`, {
					name,
					rate: Number(r.tax_rate)
				});
			}
			return [...seen.values()];
		}
	});
	const missing = (usedTaxes ?? []).filter((u) => !(rates ?? []).some((r) => r.name === u.name && Number(r.rate) === u.rate));
	async function addUsed(u) {
		const { error } = await db.from("tax_rates").insert({
			name: u.name,
			rate: u.rate,
			is_active: true
		});
		if (error) return void toast.error(error.message);
		toast.success(`${u.name} added to the list.`);
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Sales tax rates"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "The list you pick from on quotes, invoices and purchase orders. Click a name or rate to change it. A change applies to new documents; documents already made keep their tax."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y rounded-xl border",
				children: [
					list.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "min-w-0 flex-1",
								defaultValue: r.name,
								"aria-label": "Name",
								onBlur: (e) => {
									const v = e.target.value.trim();
									if (v && v !== r.name) save(r, { name: v });
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									className: "w-24 text-right",
									inputMode: "decimal",
									defaultValue: String(r.rate),
									"aria-label": "Rate (%)",
									onBlur: (e) => {
										const v = Number(e.target.value);
										if (!Number.isFinite(v) || v < 0 || v > 30) {
											toast.error("Type the rate as a percent, like 8.25.");
											e.target.value = String(r.rate);
											return;
										}
										if (v !== Number(r.rate)) save(r, { rate: v });
									}
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "%"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => void save(r, { is_active: !r.is_active }),
								children: r.is_active ? "Stop offering it" : "Offer it again"
							})
						]
					}, r.id)),
					missing.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 p-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: u.name }),
								" · ",
								u.rate,
								"%",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "is on your invoices but not in this list yet."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void addUsed(u),
							children: "Add it to the list"
						})]
					}, `${u.name}|${u.rate}`)),
					!list.length && !missing.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-3 text-sm text-muted-foreground",
						children: "No sales taxes yet."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "min-w-0 flex-1",
						placeholder: "New sales tax, like Dallas Sales Tax",
						value: name,
						onChange: (e) => setName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "w-24 text-right",
						inputMode: "decimal",
						placeholder: "8.25",
						value: rate,
						onChange: (e) => setRate(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && void add()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground",
						children: "%"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void add(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add sales tax"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: showOff,
					onChange: (e) => setShowOff(e.target.checked)
				}), "Show the ones no longer offered"]
			})
		]
	});
}
/**
* A settings box that folds up to its title, so a long page is quick to scan. Closed, it shows
* the box's own title and first line; click anywhere on it to open. Remembers open/closed.
*/
var KEY = "tk-folds";
var read = () => {
	try {
		return JSON.parse(localStorage.getItem(KEY) ?? "{}");
	} catch {
		return {};
	}
};
function Fold({ id, open: startOpen = false, children }) {
	const [open, setOpen] = (0, import_react.useState)(startOpen);
	(0, import_react.useEffect)(() => {
		const saved = read()[id];
		if (typeof window !== "undefined" && window.location.hash === `#${id}`) setOpen(true);
		else if (saved !== void 0) setOpen(saved);
	}, [id]);
	const set = (v) => {
		setOpen(v);
		try {
			localStorage.setItem(KEY, JSON.stringify({
				...read(),
				[id]: v
			}));
		} catch {}
	};
	if (open) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id,
		className: "relative mt-4 scroll-mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => set(false),
			className: "absolute -top-3 right-5 z-10 flex items-center gap-1 rounded-full border bg-card px-2.5 py-0.5 text-xs text-muted-foreground shadow-sm hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-3.5 w-3.5" }), " Fold"]
		}), children]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id,
		className: "relative scroll-mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				inert: true,
				"aria-hidden": true,
				className: "pointer-events-none max-h-[5.75rem] select-none overflow-hidden rounded-2xl",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 bottom-0 h-8 rounded-b-2xl bg-gradient-to-t from-card to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => set(true),
				"aria-label": "Open this box",
				className: "absolute inset-0 flex items-end justify-center rounded-2xl pb-1.5 hover:bg-muted/30",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1 rounded-full border bg-card px-2.5 py-1 text-xs font-medium text-[var(--section)] shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-3.5 w-3.5" }), " Open"]
				})
			})
		]
	});
}
/** Options → Features: the wording Tallkeep starts each email with, per company. */
function EmailWordingCard() {
	const qc = useQueryClient();
	const { data: saved, error } = useQuery({
		queryKey: ["email-wording"],
		retry: false,
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("email_wording").maybeSingle();
			if (error) throw error;
			return data?.email_wording ?? {};
		}
	});
	const [kind, setKind] = (0, import_react.useState)("quote");
	const [f, setF] = (0, import_react.useState)(DEFAULT_WORDING.quote);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const box = (0, import_react.useRef)(null);
	const own = saved?.[kind];
	(0, import_react.useEffect)(() => {
		setF(own?.subject || own?.body ? {
			...DEFAULT_WORDING[kind],
			...own
		} : DEFAULT_WORDING[kind]);
	}, [kind, own]);
	const info = WORDING_KINDS.find((k) => k.kind === kind);
	const sample = (0, import_react.useMemo)(() => ({
		...SAMPLE_VALUES,
		number: kind === "po" ? "PO-001018" : kind.startsWith("quote") ? "SQ-001042" : "INV-001042"
	}), [kind]);
	const preview = (0, import_react.useMemo)(() => ({
		subject: fillWording(f.subject, sample),
		body: fillWording(f.body, sample)
	}), [f, sample]);
	const changed = f.subject !== (own?.subject || DEFAULT_WORDING[kind].subject) || f.body !== (own?.body || DEFAULT_WORDING[kind].body);
	async function write(next, done) {
		setBusy(true);
		const { error } = await db.from("company_settings").update({ email_wording: next }).eq("company_id", await activeCompanyId() ?? "");
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(done);
		qc.invalidateQueries({ queryKey: ["email-wording"] });
		qc.invalidateQueries({ queryKey: ["company-settings"] });
	}
	const isDefault = (w) => w.subject.trim() === DEFAULT_WORDING[kind].subject && w.body.trim() === DEFAULT_WORDING[kind].body;
	function save() {
		const next = { ...saved ?? {} };
		if (isDefault(f)) delete next[kind];
		else next[kind] = {
			subject: f.subject.trim(),
			body: f.body.trim()
		};
		write(next, "Saved. New emails start with this wording.");
	}
	function putBack() {
		const next = { ...saved ?? {} };
		delete next[kind];
		setF(DEFAULT_WORDING[kind]);
		write(next, "Back to Tallkeep's wording.");
	}
	function addField(field) {
		const el = box.current;
		const at = el ? el.selectionStart : f.body.length;
		const end = el ? el.selectionEnd : at;
		const text = `{${field}}`;
		setF((x) => ({
			...x,
			body: x.body.slice(0, at) + text + x.body.slice(end)
		}));
		requestAnimationFrame(() => {
			el?.focus();
			el?.setSelectionRange(at + text.length, at + text.length);
		});
	}
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: "Email wording needs database step 74 (docs/db/074_email_wording.sql)."
	});
	if (!saved) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Email wording"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"The subject and message each email starts with. You can still change any email before it goes. Words in curly brackets, like ",
					"{number}",
					", are filled in for each one."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				role: "tablist",
				"aria-label": "Which email",
				children: WORDING_KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": k.kind === kind,
					onClick: () => setKind(k.kind),
					className: `rounded-full border px-3.5 py-1.5 text-sm ${k.kind === kind ? "border-primary bg-primary text-primary-foreground" : "bg-background hover:bg-muted"}`,
					children: [k.label, saved[k.kind] ? " ·" : ""]
				}, k.kind))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					info.when,
					" ",
					own ? "Using your own wording." : "Using Tallkeep's wording."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Subject"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.subject,
								onChange: (e) => setF({
									...f,
									subject: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Message"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								ref: box,
								rows: 10,
								value: f.body,
								onChange: (e) => setF({
									...f,
									body: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1",
								children: "Fill-in words (press one to add it to the message):"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1.5",
								children: info.fields.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									title: FIELD_HELP[x],
									onClick: () => addField(x),
									className: "rounded-md border bg-muted/50 px-2 py-0.5 font-mono text-[11px] hover:bg-muted",
									children: `{${x}}`
								}, x))
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 rounded-xl border bg-muted/30 p-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase text-muted-foreground",
							children: "How it looks"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: preview.subject
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-line",
							children: preview.body
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					disabled: busy || !changed,
					children: "Save this wording"
				}), own && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: putBack,
					disabled: busy,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Put back Tallkeep's wording"]
				})]
			})
		]
	});
}
/**
* Import templates: plain spreadsheets (.csv, they open in Excel) anyone can fill in from any
* program — accounts with opening balances, customers, vendors, products with stock, and what
* customers and vendors still owe. This file makes the templates and reads them back with
* checks; TemplateImport.tsx shows the preview and saves. Browser-safe.
*/
var TEMPLATES = [
	{
		kind: "accounts",
		file: "1-accounts.csv",
		label: "Accounts and opening balances",
		cols: [
			{
				key: "number",
				title: "Number",
				help: "Optional, like 1000."
			},
			{
				key: "name",
				title: "Name",
				required: true,
				help: "Like Business Checking."
			},
			{
				key: "type",
				title: "Type",
				required: true,
				help: "One of the types in the read-me."
			},
			{
				key: "opening",
				title: "Opening balance",
				help: "What it had the day before your books start. Leave empty for income and expenses."
			}
		],
		example: [[
			"Example: 1000",
			"Business Checking",
			"Bank",
			"12500.00"
		], [
			"Example: 2100",
			"Visa Card",
			"Credit card",
			"850.00"
		]]
	},
	{
		kind: "customers",
		file: "2-customers.csv",
		label: "Customers",
		cols: [
			{
				key: "name",
				title: "Name",
				required: true,
				help: "Company or person."
			},
			{
				key: "contact",
				title: "Contact",
				help: ""
			},
			{
				key: "email",
				title: "Email",
				help: ""
			},
			{
				key: "phone",
				title: "Phone",
				help: ""
			},
			{
				key: "billing",
				title: "Billing address",
				help: ""
			},
			{
				key: "shipping",
				title: "Shipping address",
				help: ""
			},
			{
				key: "notes",
				title: "Notes",
				help: ""
			}
		],
		example: [[
			"Example: Lone Oak Auto",
			"Sam Patel",
			"sam@example.com",
			"555-201-1001",
			"770 Hwy 5, Springfield, TX 75004",
			"",
			""
		]]
	},
	{
		kind: "vendors",
		file: "3-vendors.csv",
		label: "Vendors",
		cols: [
			{
				key: "name",
				title: "Name",
				required: true,
				help: ""
			},
			{
				key: "contact",
				title: "Contact",
				help: ""
			},
			{
				key: "email",
				title: "Email",
				help: ""
			},
			{
				key: "phone",
				title: "Phone",
				help: ""
			},
			{
				key: "address",
				title: "Address",
				help: ""
			},
			{
				key: "tax_id",
				title: "Tax ID",
				help: "For 1099s."
			},
			{
				key: "is_1099",
				title: "Gets a 1099",
				help: "yes or no"
			},
			{
				key: "notes",
				title: "Notes",
				help: ""
			}
		],
		example: [[
			"Example: Acme Supply",
			"Dana Lee",
			"orders@example.com",
			"555-300-2000",
			"12 Main St, Dallas, TX 75201",
			"",
			"no",
			""
		]]
	},
	{
		kind: "products",
		file: "4-products.csv",
		label: "Products and stock",
		cols: [
			{
				key: "name",
				title: "Name",
				required: true,
				help: "Item name or code."
			},
			{
				key: "description",
				title: "Description",
				help: ""
			},
			{
				key: "kind",
				title: "Kind",
				help: "Stocked or Service (empty = Stocked)."
			},
			{
				key: "category",
				title: "Category",
				help: ""
			},
			{
				key: "barcode",
				title: "Barcode",
				help: ""
			},
			{
				key: "price",
				title: "Price",
				help: "Selling price."
			},
			{
				key: "cost",
				title: "Cost",
				help: "What you pay for one."
			},
			{
				key: "stock",
				title: "Stock on hand",
				help: "How many you have now."
			},
			{
				key: "location",
				title: "Location",
				help: "Where the stock is (empty = your first location)."
			},
			{
				key: "shelf",
				title: "Shelf",
				help: ""
			},
			{
				key: "reorder",
				title: "Reorder at",
				help: "Warn when stock falls to this."
			}
		],
		example: [[
			"Example: LED Module 3-pack",
			"White LED modules for sign boxes",
			"Stocked",
			"Parts",
			"",
			"6.50",
			"2.10",
			"500",
			"Warehouse",
			"A-3",
			"100"
		]]
	},
	{
		kind: "invoices",
		file: "5-open-invoices.csv",
		label: "What customers still owe",
		cols: [
			{
				key: "who",
				title: "Customer",
				required: true,
				help: ""
			},
			{
				key: "number",
				title: "Invoice number",
				help: ""
			},
			{
				key: "date",
				title: "Date",
				required: true,
				help: "Before your books start."
			},
			{
				key: "due",
				title: "Due date",
				help: ""
			},
			{
				key: "amount",
				title: "Amount owed",
				required: true,
				help: "What's still unpaid."
			}
		],
		example: [[
			"Example: Lone Oak Auto",
			"1042",
			"2025-12-15",
			"2026-01-14",
			"971.20"
		]]
	},
	{
		kind: "bills",
		file: "6-open-bills.csv",
		label: "What you still owe vendors",
		cols: [
			{
				key: "who",
				title: "Vendor",
				required: true,
				help: ""
			},
			{
				key: "number",
				title: "Bill number",
				help: ""
			},
			{
				key: "date",
				title: "Date",
				required: true,
				help: "Before your books start."
			},
			{
				key: "due",
				title: "Due date",
				help: ""
			},
			{
				key: "amount",
				title: "Amount owed",
				required: true,
				help: "What's still unpaid."
			}
		],
		example: [[
			"Example: Acme Supply",
			"A-7781",
			"2025-12-20",
			"2026-01-19",
			"420.00"
		]]
	}
];
/** The account types people can type, and what they mean in Tallkeep. */
var ACCOUNT_TYPES = {
	bank: {
		kind: "bank",
		type: "asset"
	},
	"credit card": {
		kind: "credit_card",
		type: "liability"
	},
	"accounts receivable": {
		kind: "ar",
		type: "asset"
	},
	"other current asset": {
		kind: "other_asset",
		type: "asset"
	},
	"other asset": {
		kind: "other_asset",
		type: "asset"
	},
	inventory: {
		kind: "inventory",
		type: "asset"
	},
	"fixed asset": {
		kind: "fixed_asset",
		type: "asset"
	},
	"accounts payable": {
		kind: "ap",
		type: "liability"
	},
	"other current liability": {
		kind: "other_liability",
		type: "liability"
	},
	"other liability": {
		kind: "other_liability",
		type: "liability"
	},
	"long term liability": {
		kind: "long_term_liability",
		type: "liability"
	},
	loan: {
		kind: "long_term_liability",
		type: "liability"
	},
	equity: {
		kind: "equity",
		type: "equity"
	},
	income: {
		kind: "income",
		type: "income"
	},
	"other income": {
		kind: "other_income",
		type: "income"
	},
	"cost of goods sold": {
		kind: "cogs",
		type: "expense"
	},
	expense: {
		kind: "expense",
		type: "expense"
	},
	"other expense": {
		kind: "other_expense",
		type: "expense"
	}
};
var lc = (s) => s.toLowerCase().replace(/\s+/g, " ").trim();
var csvCell = (c) => /[",\n]/.test(c) ? `"${c.replace(/"/g, "\"\"")}"` : c;
/** The templates and a read-me, as files for a .zip. */
function templateFiles() {
	const files = TEMPLATES.map((t) => ({
		name: t.file,
		text: [t.cols.map((c) => c.title), ...t.example].map((r) => r.map(csvCell).join(",")).join("\r\n") + "\r\n"
	}));
	return [{
		name: "READ ME FIRST.txt",
		text: [
			"TALLKEEP IMPORT TEMPLATES",
			"",
			"Fill in the files you need (you don't need all of them), save them as .csv, and drop them in",
			"Tallkeep: Settings > Import & backups > From any program. Tallkeep shows what it will do",
			"before anything is saved, and running it again updates the same records instead of copying.",
			"",
			"Rows that start with \"Example:\" are skipped. Delete them or leave them.",
			"",
			...TEMPLATES.flatMap((t) => [
				`${t.file}  (${t.label})`,
				...t.cols.map((c) => `  ${c.title}${c.required ? " (needed)" : ""}${c.help ? ": " + c.help : ""}`),
				""
			]),
			"ACCOUNT TYPES",
			"  " + Object.keys(ACCOUNT_TYPES).map((k) => k.replace(/\b\w/g, (m) => m.toUpperCase())).join(", "),
			"",
			"OPENING BALANCES",
			"  Type the balance each account had the day BEFORE your books start in Tallkeep, as a",
			"  plain number (what you have in the bank, what you owe on a card or loan). Tallkeep puts",
			"  the difference in Opening Balance Equity. Leave Accounts Receivable and Accounts Payable",
			"  empty when you fill in files 5 and 6: Tallkeep adds those up for you. Leave Inventory",
			"  empty when you fill in stock in file 4: Tallkeep values your stock at cost.",
			"",
			"DATES",
			"  Write dates like 2026-01-31 or 1/31/2026."
		].join("\r\n")
	}, ...files];
}
function toDate(v) {
	const s = (v ?? "").trim();
	if (!s) return null;
	let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
	if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
	m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
	if (m) return `${m[3].length === 2 ? `20${m[3]}` : m[3]}-${m[1].padStart(2, "0")}-${m[2].padStart(2, "0")}`;
	return "bad";
}
/** Read one filled-in template; which one it is comes from its column titles. */
function readTemplate(fileName, text, booksStart) {
	const csv = parseCsv(text.replace(/^﻿/, "")).filter((r) => r.some((c) => c));
	if (!csv.length) return null;
	const head = csv[0].map(lc);
	const marks = {
		accounts: ["type", "opening balance"],
		customers: ["billing address", "shipping address"],
		vendors: ["gets a 1099", "tax id"],
		products: [
			"stock on hand",
			"kind",
			"barcode",
			"reorder at"
		],
		invoices: ["customer", "invoice number"],
		bills: ["vendor", "bill number"]
	};
	const fits = TEMPLATES.filter((x) => x.cols.filter((c) => c.required).every((c) => head.includes(lc(c.title))));
	const byName = (x) => lc(fileName).includes(x.kind.replace(/s$/, "")) || lc(fileName).startsWith(x.file.slice(0, 2));
	const t = fits.find((x) => marks[x.kind].some((m) => head.includes(m))) ?? fits.find(byName) ?? (fits.length === 1 ? fits[0] : void 0);
	if (!t) return null;
	const at = (title) => head.indexOf(lc(title));
	const rows = [];
	const problems = [];
	const seen = /* @__PURE__ */ new Set();
	csv.slice(1).forEach((r, i) => {
		const line = i + 2;
		const rec = {};
		for (const c of t.cols) {
			const j = at(c.title);
			rec[c.key] = j >= 0 ? (r[j] ?? "").trim() : "";
		}
		const first = Object.values(rec).find((v) => v) ?? "";
		if (!first || /^example:/i.test(first)) return;
		const miss = t.cols.filter((c) => c.required && !rec[c.key]).map((c) => c.title);
		if (miss.length) return void problems.push(`Row ${line}: needs ${miss.join(" and ")}.`);
		for (const k of [
			"opening",
			"price",
			"cost",
			"stock",
			"reorder",
			"amount"
		]) if (rec[k] && Number.isNaN(num(rec[k]))) return void problems.push(`Row ${line}: "${rec[k]}" isn't a number.`);
		if (t.kind === "accounts") {
			const ty = ACCOUNT_TYPES[lc(rec["type"])];
			if (!ty) return void problems.push(`Row ${line}: "${rec["type"]}" isn't an account type (see the read-me).`);
			if (rec["opening"] && ["income", "expense"].includes(ty.type) && num(rec["opening"]) !== 0) return void problems.push(`Row ${line}: ${rec["name"]} is ${ty.type === "income" ? "an income" : "an expense"} account; those start at zero, so leave its opening balance empty.`);
		}
		if (t.kind === "products" && rec["kind"] && !/^(stocked|service)/i.test(rec["kind"])) return void problems.push(`Row ${line}: Kind should be Stocked or Service.`);
		if (t.kind === "invoices" || t.kind === "bills") {
			for (const k of ["date", "due"]) {
				const d = toDate(rec[k]);
				if (d === "bad") return void problems.push(`Row ${line}: "${rec[k]}" isn't a date.`);
				rec[k] = d ?? "";
			}
			if (booksStart && rec["date"] >= booksStart) return void problems.push(`Row ${line}: dated on or after your books start (${booksStart}). Enter newer ones as regular ${t.kind === "invoices" ? "invoices" : "bills"}.`);
			if (!(num(rec["amount"]) > 0)) return void problems.push(`Row ${line}: the amount owed should be more than zero.`);
		}
		const key = t.kind === "invoices" || t.kind === "bills" ? `${lc(rec["who"])}|${rec["number"]}|${rec["date"]}` : lc(rec["name"]);
		if (seen.has(key)) return void problems.push(`Row ${line}: "${rec["name"] ?? rec["who"]}" is in the file twice.`);
		seen.add(key);
		rows.push(rec);
	});
	return {
		kind: t.kind,
		file: fileName,
		rows,
		problems
	};
}
var uuid = () => crypto.randomUUID();
var r2 = (n) => Math.round(n * 100) / 100;
var MEMO = "Opening balances from the import templates";
var ORDER = [
	"accounts",
	"customers",
	"vendors",
	"products",
	"invoices",
	"bills"
];
/** Rows that fill in different boxes go in separate batches: in one batch, a box one row
*  leaves out would be sent as empty for it (and empty isn't allowed for some, like cost). */
async function insertChunks(table, rows) {
	const groups = /* @__PURE__ */ new Map();
	for (const r of rows) {
		const k = Object.keys(r).sort().join(",");
		groups.set(k, [...groups.get(k) ?? [], r]);
	}
	for (const list of groups.values()) for (let i = 0; i < list.length; i += 500) {
		const { error } = await db.from(table).insert(list.slice(i, i + 500));
		if (error) throw new Error(`${table}: ${error.message}`);
	}
}
async function updateEach(table, rows) {
	for (const { id, ...r } of rows) {
		if (!Object.keys(r).length) continue;
		const { error } = await db.from(table).update(r).eq("id", id);
		if (error) throw new Error(`${table}: ${error.message}`);
	}
}
/** An account in the file → ours: by number first, then by name. */
function accountMatcher(accounts) {
	const byNum = new Map(accounts.filter((a) => a.number).map((a) => [a.number.trim(), a.id]));
	const byName = new Map(accounts.map((a) => [lc(a.name), a.id]));
	return (r) => (r["number"] ? byNum.get(r["number"].trim()) : void 0) ?? byName.get(lc(r["name"] ?? "")) ?? null;
}
/** Only the boxes that were filled in (an empty cell never wipes what's there). */
var filled = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== "" && v != null));
/** Options → Import & backups: bring data in from any program with the spreadsheet templates. */
function TemplateImport() {
	const qc = useQueryClient();
	const [files, setFiles] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)("");
	const [start, setStart] = (0, import_react.useState)("");
	const { data: booksStart } = useQuery({
		queryKey: ["books-start"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("books_start_date").maybeSingle();
			return data?.books_start_date ?? null;
		}
	});
	const begin = booksStart ?? (start || null);
	const { data: have } = useQuery({
		queryKey: ["template-import-have", files.length],
		enabled: files.length > 0,
		queryFn: async () => {
			const [c, v, p, a] = await Promise.all([
				fetchAll("customers", "name"),
				fetchAll("vendors", "name"),
				fetchAll("products", "name"),
				loadAccounts()
			]);
			const find = accountMatcher(a);
			return {
				customers: new Set(c.map((x) => lc(x.name))),
				vendors: new Set(v.map((x) => lc(x.name))),
				products: new Set(p.map((x) => lc(x.name))),
				account: (r) => !!find(r)
			};
		}
	});
	async function pick(list) {
		if (!list?.length) return;
		const next = [...files];
		for (const f of Array.from(list)) {
			const c = readTemplate(f.name, await f.text(), begin);
			if (!c) {
				toast.error(`${f.name} doesn't look like one of the templates.`);
				continue;
			}
			const i = next.findIndex((x) => x.kind === c.kind);
			if (i >= 0) next[i] = c;
			else next.push(c);
		}
		next.sort((a, b) => ORDER.indexOf(a.kind) - ORDER.indexOf(b.kind));
		setFiles(next);
		setDone("");
	}
	const count = (c) => {
		if (!have || c.kind === "invoices" || c.kind === "bills") return null;
		const known = c.rows.filter((r) => c.kind === "accounts" ? have.account(r) : have[c.kind].has(lc(r["name"]))).length;
		return {
			known,
			fresh: c.rows.length - known
		};
	};
	const problems = files.reduce((s, f) => s + f.problems.length, 0);
	const needStart = !booksStart && files.some((f) => f.kind === "invoices" || f.kind === "bills" || f.kind === "accounts");
	async function run() {
		if (needStart && !start) return void toast.error("Pick the day your books start in Tallkeep.");
		if (problems && !window.confirm("Rows with problems will be skipped. Go ahead with the rest?")) return;
		const get = (k) => files.find((f) => f.kind === k)?.rows ?? [];
		const said = [];
		try {
			if (needStart) {
				setBusy("Setting the start date…");
				const { error } = await db.from("company_settings").update({ books_start_date: start }).eq("company_id", await activeCompanyId() ?? "");
				if (error) throw error;
			}
			const startOn = booksStart ?? start;
			let accounts = await loadAccounts();
			let find = accountMatcher(accounts);
			const acctRows = get("accounts");
			if (acctRows.length) {
				setBusy("Accounts…");
				const fresh = acctRows.filter((r) => !find(r));
				await insertChunks("accounts", fresh.map((r) => ({
					name: r["name"],
					number: r["number"] || null,
					...ACCOUNT_TYPES[lc(r["type"])]
				})));
				said.push(`${fresh.length} new accounts`);
				accounts = await loadAccounts();
				find = accountMatcher(accounts);
			}
			for (const kind of ["customers", "vendors"]) {
				const rows = get(kind);
				if (!rows.length) continue;
				setBusy(kind === "customers" ? "Customers…" : "Vendors…");
				const old = await fetchAll(kind, "id,name");
				const id = new Map(old.map((x) => [lc(x.name), x.id]));
				const fields = (r) => kind === "customers" ? {
					contact_name: r["contact"],
					email: r["email"],
					phone: r["phone"],
					billing_address: r["billing"],
					shipping_address: r["shipping"],
					address: r["billing"],
					remarks: r["notes"]
				} : {
					contact_name: r["contact"],
					email: r["email"],
					phone: r["phone"],
					address: r["address"],
					tax_id: r["tax_id"],
					...r["is_1099"] ? { is_1099: /^y/i.test(r["is_1099"]) } : {},
					remarks: r["notes"]
				};
				const fresh = rows.filter((r) => !id.has(lc(r["name"])));
				await insertChunks(kind, fresh.map((r) => filled({
					name: r["name"],
					...fields(r)
				})));
				await updateEach(kind, rows.filter((r) => id.has(lc(r["name"]))).map((r) => ({
					id: id.get(lc(r["name"])),
					...filled(fields(r))
				})));
				said.push(`${fresh.length} new ${kind}, ${rows.length - fresh.length} updated`);
			}
			const prodRows = get("products");
			if (prodRows.length) {
				setBusy("Products…");
				const cats = await fetchAll("categories", "id,name");
				const catId = new Map(cats.map((c) => [lc(c.name), c.id]));
				const newCats = [...new Set(prodRows.map((r) => r["category"]).filter(Boolean))].filter((n) => !catId.has(lc(n))).map((n) => ({
					id: uuid(),
					name: n
				}));
				await insertChunks("categories", newCats);
				newCats.forEach((c) => catId.set(lc(c.name), c.id));
				const locs = await fetchAll("locations", "id,name");
				const locId = new Map(locs.map((l) => [lc(l.name), l.id]));
				const newLocs = [...new Set(prodRows.map((r) => r["location"]).filter(Boolean))].filter((n) => !locId.has(lc(n))).map((n) => ({
					id: uuid(),
					name: n
				}));
				if (!locs.length && !newLocs.length && prodRows.some((r) => r["stock"])) newLocs.push({
					id: uuid(),
					name: "Main"
				});
				await insertChunks("locations", newLocs);
				newLocs.forEach((l) => locId.set(lc(l.name), l.id));
				const firstLoc = locs[0]?.id ?? newLocs[0]?.id;
				const old = await fetchAll("products", "id,name");
				const pid = new Map(old.map((p) => [lc(p.name), p.id]));
				const fields = (r) => ({
					description: r["description"],
					item_type: r["kind"] ? /^serv/i.test(r["kind"]) ? "service" : "stocked" : "",
					category_id: r["category"] ? catId.get(lc(r["category"])) : "",
					barcode: r["barcode"],
					price: r["price"] ? num(r["price"]) : "",
					cost: r["cost"] ? num(r["cost"]) : "",
					reorder_point: r["reorder"] ? num(r["reorder"]) : ""
				});
				const fresh = prodRows.filter((r) => !pid.has(lc(r["name"])));
				const made = fresh.map((r) => ({
					id: uuid(),
					name: r["name"],
					item_type: "stocked",
					...filled(fields(r))
				}));
				await insertChunks("products", made);
				made.forEach((p) => pid.set(lc(p.name), p.id));
				await updateEach("products", prodRows.filter((r) => !fresh.includes(r)).map((r) => ({
					id: pid.get(lc(r["name"])),
					...filled(fields(r))
				})));
				setBusy("Stock on hand…");
				let counted = 0;
				for (const r of prodRows.filter((x) => x["stock"] && !/^serv/i.test(x["kind"] ?? ""))) {
					const loc = r["location"] ? locId.get(lc(r["location"])) : firstLoc;
					if (!loc) continue;
					const { error } = await db.rpc("set_stock_count", {
						_product_id: pid.get(lc(r["name"])),
						_location_id: loc,
						_shelf: r["shelf"] ?? "",
						_counted: num(r["stock"]),
						_note: "Opening stock from the import templates"
					});
					if (error) throw new Error(`Stock for ${r["name"]}: ${error.message}`);
					counted++;
				}
				said.push(`${fresh.length} new products, ${prodRows.length - fresh.length} updated, stock set on ${counted}`);
			}
			let owedToUs = 0;
			let weOwe = 0;
			const inv = get("invoices");
			if (inv.length) {
				setBusy("Open invoices…");
				const cust = await fetchAll("customers", "id,name");
				const cid = new Map(cust.map((c) => [lc(c.name), c.id]));
				const newC = [...new Set(inv.map((r) => r["who"]))].filter((n) => !cid.has(lc(n))).map((n) => ({
					id: uuid(),
					name: n
				}));
				await insertChunks("customers", newC);
				newC.forEach((c) => cid.set(lc(c.name), c.id));
				const nums = new Set((await fetchAll("sales_orders", "number")).map((o) => o.number));
				const orders = inv.map((r, i) => ({
					r,
					number: `OB-${r["number"] || String(i + 1).padStart(4, "0")}`
				})).filter((x) => !nums.has(x.number)).map(({ r, number }) => {
					const amt = r2(num(r["amount"]));
					return {
						id: uuid(),
						number,
						status: "invoiced",
						customer_id: cid.get(lc(r["who"])) ?? null,
						customer_name: r["who"],
						order_date: r["date"],
						invoice_date: r["date"],
						due_date: r["due"] || r["date"],
						subtotal: amt,
						total: amt,
						balance: amt,
						amount_paid: 0,
						stock_taken_at: r["date"],
						remarks: `Still owed from before Tallkeep${r["number"] ? ` (invoice ${r["number"]})` : ""}`,
						custom: { source: "template" }
					};
				});
				await insertChunks("sales_orders", orders);
				await insertChunks("sales_order_lines", orders.map((o) => ({
					id: uuid(),
					sales_order_id: o.id,
					line_no: 1,
					description: "Balance from before Tallkeep",
					qty: 1,
					unit_price: o.total,
					taxable: false,
					line_total: o.total
				})));
				owedToUs = r2(inv.reduce((s, r) => s + num(r["amount"]), 0));
				said.push(`${orders.length} open invoices${inv.length > orders.length ? ` (${inv.length - orders.length} were already here)` : ""}`);
			}
			const bills = get("bills");
			if (bills.length) {
				setBusy("Open bills…");
				const vend = await fetchAll("vendors", "id,name");
				const vid = new Map(vend.map((v) => [lc(v.name), v.id]));
				const newV = [...new Set(bills.map((r) => r["who"]))].filter((n) => !vid.has(lc(n))).map((n) => ({
					id: uuid(),
					name: n
				}));
				await insertChunks("vendors", newV);
				newV.forEach((v) => vid.set(lc(v.name), v.id));
				const old = await fetchAll("bills", "vendor_name,ref,bill_date");
				const seen = new Set(old.map((b) => `${lc(b.vendor_name ?? "")}|${b.ref ?? ""}|${String(b.bill_date).slice(0, 10)}`));
				const todo = bills.filter((r) => !seen.has(`${lc(r["who"])}|${r["number"] ?? ""}|${r["date"]}`));
				const made = todo.map((r) => ({
					id: uuid(),
					vendor_id: vid.get(lc(r["who"])) ?? null,
					vendor_name: r["who"],
					ref: r["number"] || null,
					bill_date: r["date"],
					due_date: r["due"] || r["date"],
					memo: "Still owed from before Tallkeep"
				}));
				await insertChunks("bills", made);
				await insertChunks("bill_lines", made.map((b, i) => ({
					bill_id: b.id,
					line_no: 1,
					description: "Balance from before Tallkeep",
					amount: r2(num(todo[i]["amount"]))
				})));
				weOwe = r2(bills.reduce((s, r) => s + num(r["amount"]), 0));
				said.push(`${made.length} open bills${bills.length > made.length ? ` (${bills.length - made.length} were already here)` : ""}`);
			}
			const lines = [];
			const byKind = (k) => accounts.find((a) => a.kind === k && a.is_active !== false);
			const add = (id, amount, debitSide) => {
				if (!id || !amount) return;
				const v = r2(amount);
				const dr = debitSide ? v > 0 : v < 0;
				lines.push({
					account_id: id,
					debit: dr ? Math.abs(v) : 0,
					credit: dr ? 0 : Math.abs(v)
				});
			};
			let arGiven = false;
			let apGiven = false;
			for (const r of acctRows.filter((x) => x["opening"])) {
				const ty = ACCOUNT_TYPES[lc(r["type"])];
				if (ty.kind === "ar") arGiven = true;
				if (ty.kind === "ap") apGiven = true;
				add(find(r), num(r["opening"]), ty.type === "asset");
			}
			if (!arGiven && owedToUs) add(byKind("ar")?.id, owedToUs, true);
			if (!apGiven && weOwe) add(byKind("ap")?.id, weOwe, false);
			if (lines.length) {
				setBusy("Opening balances…");
				const diff = r2(lines.reduce((s, l) => s + l.debit - l.credit, 0));
				const equity = accounts.find((a) => a.key === "opening")?.id ?? byKind("equity")?.id;
				if (diff && equity) lines.push({
					account_id: equity,
					debit: diff < 0 ? -diff : 0,
					credit: diff > 0 ? diff : 0
				});
				const { error: delErr } = await db.from("journal_entries").delete().eq("source_type", "opening").eq("memo", MEMO);
				if (delErr) throw delErr;
				const { data: u } = await db.auth.getUser();
				const id = uuid();
				const { error } = await db.from("journal_entries").insert({
					id,
					entry_date: dayBefore(startOn),
					memo: MEMO,
					source_type: "opening",
					created_by: u.user?.id
				});
				if (error) throw error;
				await insertChunks("journal_lines", lines.map((l) => ({
					entry_id: id,
					...l
				})));
				said.push(`opening balances for ${fmtDate(dayBefore(startOn))}`);
			}
			setDone(`Done: ${said.join("; ")}.`);
			toast.success("Your data is in.");
			setFiles([]);
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring data from any program"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Coming from another program, or from your own spreadsheets? Fill in our templates (they open in Excel or Google Sheets), then drop them here. You see what will happen before anything is saved, and running it again updates the same records instead of copying them."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "space-y-1.5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "1." }),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => downloadBlob("Tallkeep import templates.zip", makeZip(templateFiles())),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download the templates"]
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								"(",
								TEMPLATES.map((t) => t.label.toLowerCase()).join(", "),
								", and a read-me)"
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "2." }),
						" Fill in the ones you need. Save each one as ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: ".csv" }),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "3." }), " Drop them here:"] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Choose the filled-in .csv files (one or several)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: ".csv,text/csv",
						multiple: true,
						className: "hidden",
						onChange: (e) => void pick(e.target.files)
					})
				]
			}),
			files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					files.map((f) => {
						const t = TEMPLATES.find((x) => x.kind === f.kind);
						const c = count(f);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl border p-3 text-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-2",
								children: [
									f.problems.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 h-4 w-4 shrink-0 text-amber-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-4 w-4 shrink-0 text-emerald-600" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "font-medium",
												children: [
													t.label,
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "font-normal text-muted-foreground",
														children: ["· ", f.file]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-muted-foreground",
												children: [
													f.rows.length,
													" ready",
													c ? ` (${c.fresh} new, ${c.known} already here: filled-in boxes update them)` : "",
													f.kind === "invoices" || f.kind === "bills" ? `, ${fmtMoney(f.rows.reduce((s, r) => s + num(r["amount"]), 0))} in all` : "",
													f.problems.length ? `, ${f.problems.length} skipped:` : ""
												]
											}),
											f.problems.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
												className: "mt-1 list-disc pl-5 text-amber-800 dark:text-amber-300",
												children: [f.problems.slice(0, 8).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: p }, p)), f.problems.length > 8 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
													"and ",
													f.problems.length - 8,
													" more"
												] })]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `Take ${t.label} off the list`,
										className: "rounded p-1 hover:bg-muted",
										onClick: () => setFiles(files.filter((x) => x.kind !== f.kind)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
									})
								]
							})
						}, f.kind);
					}),
					needStart && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex flex-wrap items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: "Your books start in Tallkeep on"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								className: "w-44",
								value: start,
								onChange: (e) => setStart(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Opening balances are for the day before."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void run(),
						disabled: !!busy || files.every((f) => !f.rows.length),
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, busy || "Bring it in"]
					})
				]
			}),
			done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-start gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-900 dark:bg-emerald-900/30 dark:text-emerald-100",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-4 w-4 shrink-0" }),
					" ",
					done
				]
			})
		]
	});
}
/**
* The sample company: a made-up sign shop to try things in, record tutorials with, and see how
* quotes, invoices, stock and the books connect. On: it's in the company list (marked Sample).
* Off: it's removed. Start it over: back to new.
*/
function SampleCompanyCard() {
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: sample, refetch } = useQuery({
		queryKey: ["sample-company"],
		queryFn: async () => {
			const { data, error } = await db.from("companies").select("id,name").eq("is_sample", true).maybeSingle();
			if (error) return null;
			return data;
		}
	});
	async function set(on, fresh = false) {
		if (!on && !window.confirm("Remove the sample company and everything in it?")) return;
		if (fresh && !window.confirm("Start the sample over? Everything you changed in it is replaced.")) return;
		setBusy(true);
		const { data, error } = await db.rpc("sample_company", {
			_on: on,
			_fresh: fresh
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		const { data: now } = await refetch();
		qc.invalidateQueries({ queryKey: ["my-companies"] });
		qc.invalidateQueries({ queryKey: ["apps"] });
		const id = now?.id;
		toast.success(!on ? "The sample company was removed." : fresh ? "The sample started over." : "The sample company is ready. It's in the company list, marked Sample.", on && id ? { action: {
			label: "Open it",
			onClick: () => void switchCompany(id).catch((e) => toast.error(e.message))
		} } : void 0);
		return data;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Sample company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Bright Signs Co., a made-up sign shop with customers, products, quotes, invoices, purchase orders, bills, bank lines and a few months of books, all connected. Try anything in it; it never mixes with your real books and doesn't count toward your plan."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: !!sample,
					disabled: busy,
					onCheckedChange: (v) => void set(v),
					"aria-label": "Sample company on or off",
					title: sample ? "On: switch off to remove it" : "Off: switch on to make it"
				})]
			}),
			sample && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						disabled: busy,
						onClick: () => void switchCompany(sample.id).catch((e) => toast.error(e.message)),
						children: "Open the sample company"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						disabled: busy,
						onClick: () => void set(true, true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Start it over"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: busy,
						onClick: () => window.confirm("Turn off the sample company? It's removed with everything in it. Your real books aren't touched. You can turn it on again any time.") && void set(false),
						children: "Turn it off"
					})
				]
			}),
			busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				role: "status",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Working… this takes a few seconds."]
			})
		]
	});
}
async function call$1(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/connect${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var back = () => `${window.location.origin}/settings#plan`;
/** Options → Plan & computer: Tallkeep Connect (use Tallkeep from anywhere). */
function ConnectCard({ admin }) {
	const qc = useQueryClient();
	const { data: st, error } = useQuery({
		queryKey: ["tallkeep-connect"],
		queryFn: () => call$1("GET"),
		refetchInterval: (q) => q.state.data?.active && !q.state.data.running ? 5e3 : 6e4
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)(null);
	const confirmed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const q = new URLSearchParams(window.location.search);
		const session = q.get("session");
		if (q.get("connect") !== "done" || !session || confirmed.current) return;
		confirmed.current = true;
		setBusy(true);
		call$1("POST", "/confirm", { session }).then((r) => {
			toast.success(r.active ? "Tallkeep Connect is on. Your web address is ready in a moment." : "Thank you! Tallkeep Connect turns on in a minute.");
			window.history.replaceState(null, "", "/settings#plan");
		}).catch((e) => toast.error(e.message)).finally(() => {
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		});
	}, [qc]);
	async function go(path) {
		setBusy(true);
		try {
			const r = await call$1("POST", path, { returnUrl: back() });
			if (r.url) {
				window.location.href = r.url;
				return;
			}
			toast.success("Tallkeep Connect is on for this computer. Your web address works in a minute.");
			setBusy(false);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	}
	async function rename() {
		if (!newName) return;
		setBusy(true);
		try {
			const r = await call$1("POST", "/rename", { name: newName });
			toast.success(`Your address is now https://${r.hostname}. It can take a minute to start working.`);
			setNewName(null);
			qc.invalidateQueries({ queryKey: ["tallkeep-connect"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function check() {
		setBusy(true);
		try {
			qc.setQueryData(["tallkeep-connect"], await call$1("POST", "/check", {}));
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (error) return null;
	if (!st) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "flex items-center gap-2 font-display text-xl font-semibold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "h-5 w-5" }), " Tallkeep Connect"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Use Tallkeep from anywhere: phones away from the office, people working from home, and links customers and Airbnb can open. Your books stay on this computer; Connect gives it a secure web address. Nothing to set up on your router."
		})] }), st.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
					children: [
						st.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-5 w-5 animate-spin" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [st.running ? "On. Open Tallkeep from anywhere at:" : st.downloading ? "Getting ready (one-time download)…" : "Connecting…", st.url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block break-all font-mono text-base font-semibold",
								children: st.url
							})]
						}),
						st.url && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								copyText(st.url);
								toast.success("Address copied");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy"]
						})
					]
				}),
				st.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-red-700",
					children: st.problem
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Sign in there with the same email and password. Keep this computer on, with Tallkeep open. On a phone, open the address in the browser and choose \"Add to Home Screen\".", st.status === "past_due" ? " Your last payment didn't go through: update your card." : ""]
				}),
				admin && newName !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-2 rounded-xl border p-3",
					onSubmit: (e) => {
						e.preventDefault();
						rename();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm font-medium",
							htmlFor: "connect-name",
							children: "Pick a short address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm text-muted-foreground",
									children: "https://"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "connect-name",
									value: newName,
									onChange: (e) => setNewName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "")),
									className: "w-48 font-mono",
									maxLength: 40,
									autoFocus: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-sm text-muted-foreground",
									children: [".", (st.hostname ?? "x.tallkeep.app").split(".").slice(1).join(".")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									size: "sm",
									disabled: busy || newName.length < 3,
									children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Save address"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									variant: "ghost",
									onClick: () => setNewName(null),
									children: "Cancel"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Letters, numbers and dashes. The old address stops working, so update phones and bookmarks (and the calendar link in Airbnb, if you gave it one)."
						})
					]
				}),
				admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setNewName((st.hostname ?? "").split(".")[0] ?? ""),
							disabled: busy,
							children: "Change address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void go("/manage"),
							disabled: busy,
							children: "Change card or cancel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void check(),
							disabled: busy,
							children: "Check again"
						})
					]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2",
			children: [
				st.problem && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: st.problem
				}),
				admin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => void go("/subscribe"),
					disabled: busy,
					children: [
						busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
						"Turn on Tallkeep Connect",
						st.price ? ` (${`$${st.price}`}/month)` : ""
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "An admin can turn on Tallkeep Connect here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Monthly, cancel any time."
				})
			]
		})]
	});
}
/** Options → just for you: the dark look and the sound when something is saved (this computer). */
function MyLookCard() {
	const [dark, setDark] = (0, import_react.useState)(false);
	const [sound, setSound] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setDark(getTheme() === "dark");
		setSound(soundOn());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-x-8 gap-y-3 rounded-2xl border bg-card px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-semibold",
				children: "Just for you"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4 text-muted-foreground" }),
					"Dark look",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: dark,
						onCheckedChange: (v) => {
							setTheme(v ? "dark" : "light");
							setDark(v);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "h-4 w-4 text-muted-foreground" }),
					"Sound when something is saved",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: sound,
						onCheckedChange: (v) => {
							setSoundOn(v);
							setSound(v);
							if (v) play("saved", true);
						}
					})
				]
			})
		]
	});
}
/** Options → Features: the support page and saved replies (when Support Desk is on). */
function SupportSettings() {
	const qc = useQueryClient();
	const { data: s } = useQuery({
		queryKey: ["support-settings"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("name,support_slug,support_notify_email,support_topics,support_intro").maybeSingle();
			return data;
		}
	});
	const { data: origin } = useQuery({
		queryKey: ["public-origin"],
		queryFn: publicOrigin
	});
	const [f, setF] = (0, import_react.useState)({
		slug: "",
		notify: "",
		topics: "",
		intro: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (s) setF({
			slug: s.support_slug ?? slugFrom(s.name ?? ""),
			notify: s.support_notify_email ?? "",
			topics: (s.support_topics ?? []).join(", "),
			intro: s.support_intro ?? ""
		});
	}, [s]);
	async function save() {
		const slug = f.slug.trim().toLowerCase();
		if (slug && !/^[a-z0-9-]{2,60}$/.test(slug)) return void toast.error("Use letters, numbers and dashes for the address, like sunrise-led.");
		setBusy(true);
		const { error } = await db.from("company_settings").update({
			support_slug: slug || null,
			support_notify_email: f.notify.trim() || null,
			support_topics: f.topics.split(",").map((x) => x.trim()).filter(Boolean).slice(0, 20),
			support_intro: f.intro.trim() || null
		}).eq("company_id", await activeCompanyId() ?? "");
		setBusy(false);
		if (error) return void toast.error(/duplicate|unique/i.test(error.message) ? "Another business already uses that address. Try another." : error.message);
		toast.success("Support page saved.");
		qc.invalidateQueries({ queryKey: ["support-settings"] });
		qc.invalidateQueries({ queryKey: ["support-slug"] });
	}
	const url = origin && f.slug ? `${origin}/help/${f.slug.trim().toLowerCase()}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Support Desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Customers open tickets on your support page. Put its link on your website, invoices or email signature."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Support page address"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [origin, "/help/"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "w-56",
						value: f.slug,
						onChange: (e) => setF({
							...f,
							slug: e.target.value
						}),
						placeholder: "your-business"
					})]
				})]
			}),
			url && s?.support_slug && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: url,
					target: "_blank",
					rel: "noreferrer",
					className: "underline",
					children: "Open your support page"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => {
						copyText(url);
						toast.success("Link copied.");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy link"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Email new tickets and replies to"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.notify,
						onChange: (e) => setF({
							...f,
							notify: e.target.value
						}),
						placeholder: "support@yourbusiness.com (more than one: separate with commas)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Empty: the company email. When a ticket is assigned, replies go to that person."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Topics customers pick from"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.topics,
						onChange: (e) => setF({
							...f,
							topics: e.target.value
						}),
						placeholder: "Repair, Installation, Question about an invoice"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Separate with commas. Empty: no topic list."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "A line at the top of the page"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					rows: 2,
					value: f.intro,
					onChange: (e) => setF({
						...f,
						intro: e.target.value
					}),
					placeholder: "Tell us what you need and we'll get back to you within one business day."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save the support page"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedReplies, {})
		]
	});
}
function SavedReplies() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["ticket-templates"],
		queryFn: async () => {
			const { data } = await db.from("ticket_templates").select("id,title,body").order("title");
			return data ?? [];
		}
	});
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const refresh = () => void qc.invalidateQueries({ queryKey: ["ticket-templates"] });
	async function add() {
		if (!title.trim() || !body.trim()) return void toast.error("Type a name and the reply.");
		const { error } = await db.from("ticket_templates").insert({
			title: title.trim(),
			body: body.trim()
		});
		if (error) return void toast.error(error.message);
		setTitle("");
		setBody("");
		refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 border-t pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "Saved replies"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Answers you send often. Pick one when replying to a ticket, then change what you need."
			}),
			(data ?? []).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-2 rounded-lg border p-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "line-clamp-2 whitespace-pre-wrap text-muted-foreground",
						children: t.body
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					"aria-label": `Delete ${t.title}`,
					onClick: async () => {
						const { error } = await db.from("ticket_templates").delete().eq("id", t.id);
						if (error) return void toast.error(error.message);
						refresh();
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			}, t.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-lg border p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "Name, like Parts ordered"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 3,
						value: body,
						onChange: (e) => setBody(e.target.value),
						placeholder: "The reply"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void add(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add saved reply"]
					})
				]
			})
		]
	});
}
/**
* Office computer (Windows): run Tallkeep as a Windows service, so the books stay open when no one
* is signed in. Only shows in the Tallkeep window on the office computer.
*/
var bridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
function ServiceCard() {
	const [st, setSt] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const refresh = () => void bridge().serviceStatus?.().then(setSt);
	(0, import_react.useEffect)(refresh, []);
	if (!st?.available) return null;
	const on = st.state !== "none";
	const change = async (turnOn) => {
		setBusy(true);
		try {
			const r = await (turnOn ? bridge().installService() : bridge().removeService());
			if (r.ok) toast.success(turnOn ? "Tallkeep now runs as a Windows service." : "The service is off. This window keeps the books again.");
			else if (!r.canceled) toast.error(r.error ?? "That didn't work.");
		} finally {
			setBusy(false);
			refresh();
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Keep running without anyone signed in"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Runs Tallkeep as a Windows service: the books open when the computer starts, before anyone signs in, and stay open when you sign out or Windows restarts for an update. The computer doesn't go to sleep while it keeps the books."
			})] }),
			on ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [
					"On.",
					" ",
					st.state === "running" ? "The Tallkeep service keeps the books open." : `The service is ${st.state}.`,
					" ",
					"This window only shows them: closing it changes nothing for others."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Off. The books are open while this Tallkeep window is open (it starts when you sign in)."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: on ? "outline" : "default",
					disabled: busy,
					onClick: () => void change(!on),
					children: busy ? "Waiting for Windows…" : on ? "Turn off the service" : "Turn on the service"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Windows asks for permission. Tallkeep closes for a minute while it switches."
				})]
			}),
			on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Backups to a network folder (like a Synology): the service signs in to the network as this computer, not as you. If backups there stop working, open Services in Windows → Tallkeep → Log On, and enter your Windows account."
			})
		]
	});
}
/**
* Put the books back from a backup in the backup folder, from a browser. Used where there's no
* Tallkeep window with a file picker: Tallkeep in Docker (a Synology, a server) or as a Windows
* service, and from other computers in the office.
*/
async function call(path, body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/backups/${path}`, {
		method: "POST",
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
function BackupPutBack({ name }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [look, setLook] = (0, import_react.useState)(null);
	const [company, setCompany] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const start = async () => {
		setBusy(true);
		try {
			const l = await call("inspect", { name });
			setLook(l);
			setCompany(l.companyOnly?.id ?? "");
			setOpen(true);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const go = async () => {
		setBusy(true);
		try {
			await call("restore", {
				name,
				company: company || null
			});
			toast.success("The books are back as they were in that backup.");
			setTimeout(() => window.location.reload(), 1200);
		} catch (e) {
			toast.error(e.message);
			setBusy(false);
		}
	};
	const when = look?.made ? new Date(look.made).toLocaleString() : name;
	const cos = look?.companies ?? [];
	const chosen = look?.companyOnly ?? cos.find((c) => c.id === company) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		size: "sm",
		variant: "ghost",
		className: "h-7",
		disabled: busy,
		onClick: () => void start(),
		children: "Put back…"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (v) => !busy && setOpen(v),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Put the books back?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"This backup is from ",
					when,
					"."
				] })] }),
				!look?.companyOnly && cos.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "putback-company",
						children: "What to put back"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "putback-company",
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						value: company,
						onChange: (e) => setCompany(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All companies"
						}), cos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: c.id,
							children: ["Only ", c.name]
						}, c.id))]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						chosen ? `Everything entered in ${chosen.name} after that backup will be replaced, for everyone. The other companies stay as they are.` : "Everything entered after that backup will be replaced, in every company, for everyone.",
						" ",
						"Tallkeep saves a backup of the books as they are now first, so you can undo this."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: busy,
					onClick: () => setOpen(false),
					children: "Keep the books as they are"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					disabled: busy,
					onClick: () => void go(),
					children: busy ? "Putting back…" : chosen ? `Put ${chosen.name} back` : "Put all the books back"
				})] })
			]
		})
	})] });
}
/** Admin: run today's quote follow-ups now (same as the daily job). */
var runFollowupsNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("1c07c766055e3d99b4ce098f5bad7d8d0756bbe632b9e9d2384ee4f72ef8ecfc"));
var listBackups = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d1de4cd6c5fed7ab6d4819651136ceb161a48b3ea783c0171bce0c384b4914f4"));
var backupNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("68245375509608cf53f821532abc75914db1edaec535ba1975049ebadeb65f05"));
var backupLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("dbbb396530bca0dd8e8e455c118509c777c88ea9fb7ca04effe9f4459aa5d083"));
var uploadBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d.fileBase64 || d.fileBase64.length > 2e7) throw new Error("That file is too big.");
	return d;
}).handler(createSsrRpc("aab17122cc1986c06006ca74c6e3931f6572464fb86f3077a1ed4f46448288f6"));
var summarizeBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("d977603f5bbf94db864ead1e021883062b18ace6c6570fb34ac0f34bc925208b"));
var restoreFromBackup = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.confirm !== "RESTORE") throw new Error("Type RESTORE to confirm.");
	return d;
}).handler(createSsrRpc("2c5a14efae666c66f9050e983d7ee7530c86790708cd112a473bd68c78ed1c0e"));
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-all",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
/** Import order matters: things must exist before others point at them. */
var STEPS = [
	{
		table: "categories",
		label: "Categories",
		conflict: "id"
	},
	{
		table: "locations",
		label: "Places",
		conflict: "id"
	},
	{
		table: "shelves",
		label: "Shelves",
		conflict: "id"
	},
	{
		table: "price_lists",
		label: "Price lists",
		conflict: "id"
	},
	{
		table: "payment_terms",
		label: "Payment terms",
		conflict: "id"
	},
	{
		table: "tax_rates",
		label: "Tax rates",
		conflict: "id"
	},
	{
		table: "products",
		label: "Products",
		conflict: "id"
	},
	{
		table: "product_prices",
		label: "Product prices",
		conflict: "product_id,price_list_id"
	},
	{
		table: "serial_numbers",
		label: "Serial numbers",
		conflict: "id"
	},
	{
		table: "stock",
		label: "Stock",
		conflict: "id"
	},
	{
		table: "customers",
		label: "Customers",
		conflict: "id"
	},
	{
		table: "vendors",
		label: "Vendors",
		conflict: "id"
	},
	{
		table: "vendor_items",
		label: "Vendor prices",
		conflict: "id"
	},
	{
		table: "sales_orders",
		label: "Quotes, orders & invoices",
		conflict: "id"
	},
	{
		table: "sales_order_lines",
		label: "Order lines",
		conflict: "id"
	},
	{
		table: "purchase_orders",
		label: "Purchase orders",
		conflict: "id"
	},
	{
		table: "purchase_order_lines",
		label: "Purchase order lines",
		conflict: "id"
	},
	{
		table: "payments",
		label: "Payments",
		conflict: "id"
	},
	{
		table: "stock_docs",
		label: "Adjustments, transfers & count sheets",
		conflict: "id"
	},
	{
		table: "stock_doc_lines",
		label: "Their lines",
		conflict: "id"
	},
	{
		table: "stock_moves",
		label: "Movement history",
		conflict: "id"
	},
	{
		table: "doc_counters",
		label: "Next document numbers",
		conflict: "company_id,kind"
	},
	{
		table: "company_settings",
		label: "Company details",
		conflict: "company_id"
	}
];
/** Settings in groups, each with its own color, picked from a side menu (like inFlow's options). */
var SETTINGS_GROUPS = [
	{
		key: "apps",
		label: "Apps",
		color: "#2E8A55",
		text: "Turn on and set up"
	},
	{
		key: "company",
		label: "Company",
		color: "#6366B8",
		text: "Details, companies, footers"
	},
	{
		key: "people",
		label: "People",
		color: "#4E9A72",
		text: "Users and what they see"
	},
	{
		key: "features",
		label: "Features",
		color: "#E8A13A",
		text: "Kind of business, main parts"
	},
	{
		key: "accounting",
		label: "Accounting",
		color: "#1F8FA6",
		text: "Books, start fresh"
	},
	{
		key: "data",
		label: "Import & backups",
		color: "#9C7E62",
		text: "Any program, QuickBooks, backups"
	},
	{
		key: "plan",
		label: "Plan & computer",
		color: "#687282",
		text: "Your plan, this computer"
	}
];
var OLD_ANCHORS = {
	import: "data",
	quickbooks: "data",
	"sales-tax": "company",
	sample: "apps"
};
function SettingsPage() {
	const { data: isAdmin, isLoading } = useIsAdmin();
	const { data: owner } = useIsOwner();
	const { data: account } = useMyAccount();
	const { data: features } = useAddons();
	const desktop = !!{
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/",
		"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
		"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
		"VITE_SUPABASE_URL": "http://localhost:4600",
		"VITE_TALLKEEP_DESKTOP": "1",
		"VITE_TALLKEEP_VERSION": "0.26.51"
	}["VITE_TALLKEEP_DESKTOP"];
	const showPlan = desktop || !!account && !account.is_platform;
	const groups = SETTINGS_GROUPS.filter((g) => (g.key !== "plan" || showPlan) && (owner || g.key !== "plan" && g.key !== "people"));
	const [group, setGroup] = (0, import_react.useState)("apps");
	(0, import_react.useEffect)(() => {
		const read = () => {
			const q = new URLSearchParams(window.location.search);
			if (q.get("card")) return setGroup("company");
			if (q.get("connect")) return setGroup("plan");
			const h = window.location.hash.slice(1);
			const g = OLD_ANCHORS[h] ?? h;
			if (SETTINGS_GROUPS.some((x) => x.key === g)) setGroup(g);
			if (OLD_ANCHORS[h]) setTimeout(() => document.getElementById(h)?.scrollIntoView(), 300);
		};
		read();
		window.addEventListener("hashchange", read);
		return () => window.removeEventListener("hashchange", read);
	}, []);
	const pick = (g) => {
		setGroup(g);
		history.replaceState(null, "", `#${g}`);
	};
	const current = groups.find((g) => g.key === group) ?? groups[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Options",
				text: `Apps, company info, users and your plan. ${siteKind()} · ${versionLabel()}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyLookCard, {}),
			isLoading ? null : isAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-6 md:flex-row md:items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex gap-2 overflow-x-auto pb-1 md:sticky md:top-4 md:w-56 md:shrink-0 md:flex-col md:overflow-visible",
					children: groups.map((g) => {
						const on = g.key === current.key;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => pick(g.key),
							className: cn("shrink-0 rounded-xl border px-3 py-2 text-left transition-colors", on ? "text-white shadow-sm" : "bg-card hover:bg-muted"),
							style: on ? {
								backgroundColor: g.color,
								borderColor: g.color
							} : { borderLeft: `4px solid ${g.color}` },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-semibold",
								children: g.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("hidden text-xs md:block", on ? "text-white/85" : "text-muted-foreground"),
								children: g.text
							})]
						}, g.key);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 space-y-6 border-t-4 pt-4 md:border-t-0 md:border-l-4 md:pl-6 md:pt-0",
					style: { borderColor: current.color },
					children: [
						current.key === "apps" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppsCatalog, {
							owner: !!owner,
							panels: {
								payments: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardPaymentsCard, { admin: !!owner }),
								reminders: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindersCard, {}),
								followups: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FollowupCard, {}),
								email: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailSetupCard, {}),
								wording: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailWordingCard, {}),
								support: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SupportSettings, {}),
								quickbooks: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickBooksImport, {}),
								connect: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectCard, { admin: !!owner }),
								backup: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightlyBackupCard, {}),
								sample: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleCompanyCard, {})
							}
						}),
						current.key === "company" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "company-details",
								open: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompanyCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "card-payments",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardPaymentsCard, { admin: !!owner })
							}),
							owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "companies",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompaniesCard, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "sales-tax",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaxRatesCard, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "footers",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FootersCard, {})
							})
						] }),
						current.key === "people" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersCard, {}),
						current.key === "features" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddonsCard, {}),
						current.key === "accounting" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountingCard, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-card p-4 sm:p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-xl font-semibold",
									children: "Bank connections"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: "Connect your bank once and new bank and card lines come in every morning."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/bank-connections",
										children: "Open Bank Connections"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseOutCard, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UndoCloseOutCard, {})
						] }),
						current.key === "data" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							desktop && owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "nightly-backup",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightlyBackupCard, {})
							}),
							(account?.is_platform || desktop) && owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "backup",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupCard, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "templates",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TemplateImport, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "import",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImportCard, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "quickbooks",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickBooksImport, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "photos",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotosCard, {})
							})
						] }),
						current.key === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							account && !account.is_platform && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "plan",
								open: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "license",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicenseCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "office-computer",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OfficeComputerCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "service",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "connect",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectCard, { admin: !!owner })
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "app-updates",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdatesCard, {})
							}),
							desktop && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fold, {
								id: "server-updates",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DockerUpdatesCard, {})
							})
						] })
					]
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-6 text-muted-foreground",
				children: "The rest of Options is for an admin."
			})
		]
	});
}
function ImportCard() {
	const qc = useQueryClient();
	const [bundle, setBundle] = (0, import_react.useState)(null);
	const [fileName, setFileName] = (0, import_react.useState)("");
	const [running, setRunning] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)({});
	const [current, setCurrent] = (0, import_react.useState)("");
	const [sure, setSure] = (0, import_react.useState)(false);
	const [finished, setFinished] = (0, import_react.useState)(false);
	async function pick(file) {
		if (!file) return;
		try {
			const data = JSON.parse(await file.text());
			if (!Array.isArray(data["products"])) throw new Error("bad file");
			setBundle(data);
			setFileName(file.name);
			setDone({});
			setFinished(false);
		} catch {
			toast.error("That file is not an inFlow import file.");
		}
	}
	async function run() {
		if (!bundle) return;
		setRunning(true);
		setFinished(false);
		try {
			for (const s of STEPS) {
				let rows = bundle[s.table] ?? [];
				if (s.table === "categories") rows = rows.map((r) => ({
					...r,
					parent_id: null
				}));
				if (s.table === "company_settings") rows = rows.map(({ id: _i, ...r }) => r);
				setCurrent(s.label);
				for (let i = 0; i < rows.length; i += 500) {
					const chunk = rows.slice(i, i + 500);
					const { error } = await db.from(s.table).upsert(chunk, { onConflict: s.conflict });
					if (error) throw new Error(`${s.label}: ${error.message}`);
					setDone((d) => ({
						...d,
						[s.table]: Math.min(i + 500, rows.length)
					}));
				}
				if (rows.length === 0) setDone((d) => ({
					...d,
					[s.table]: 0
				}));
				if (s.table === "categories") for (const c of (bundle["categories"] ?? []).filter((c) => c.parent_id)) await db.from("categories").update({ parent_id: c.parent_id }).eq("id", c.id);
				if (s.table === "stock") {
					const moves = rows.map((r) => ({
						id: r.id,
						product_id: r.product_id,
						location_id: r.location_id,
						shelf: r.shelf,
						qty_change: r.qty,
						reason: "import",
						note: "Stock on hand in inFlow"
					}));
					for (let i = 0; i < moves.length; i += 500) {
						const { error } = await db.from("stock_moves").upsert(moves.slice(i, i + 500), {
							onConflict: "id",
							ignoreDuplicates: true
						});
						if (error) throw new Error(`Stock history: ${error.message}`);
					}
				}
			}
			setFinished(true);
			toast.success("All your inFlow data is in.");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setRunning(false);
			setCurrent("");
		}
	}
	const total = STEPS.reduce((s, x) => s + (bundle?.[x.table]?.length ?? 0), 0);
	const doneCount = Object.values(done).reduce((a, b) => a + b, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring data over from inFlow"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Choose the file ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "inflow-import.json" }),
					" (saved on the Synology in ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inflow → Export" }),
					"), then press the button. Running it again updates the same records — it won't make copies — but it ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "resets stock counts" }),
					" to what inFlow had."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5 text-muted-foreground" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: fileName || "Choose the inflow-import.json file"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: ".json,application/json",
						className: "hidden",
						onChange: (e) => pick(e.target.files?.[0])
					})
				]
			}),
			bundle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-1 text-sm sm:grid-cols-2",
					children: STEPS.map((s) => {
						const n = bundle[s.table]?.length ?? 0;
						const d = done[s.table];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between rounded-lg px-2 py-1 odd:bg-muted/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5 text-muted-foreground",
								children: [d === n && d !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-600" }) : current === s.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : null, n.toLocaleString()]
							})]
						}, s.table);
					})
				}),
				running && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: total ? doneCount / total * 100 : 0 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-start gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: sure,
						onCheckedChange: (v) => setSure(v === true),
						className: "mt-0.5"
					}), "I understand stock counts will be set to what inFlow had."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: run,
					disabled: !sure || running,
					children: running ? `Importing ${current}…` : finished ? "Import again" : "Import inFlow data"
				}),
				finished && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-emerald-700",
					children: "Done. Open Products to see everything."
				})
			] })
		]
	});
}
function CompanyCard() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["company"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			return data;
		}
	});
	const [f, setF] = (0, import_react.useState)({
		id: 1,
		name: "",
		address: null,
		phone: null,
		fax: null,
		email: null,
		website: null,
		quote_footer: null,
		invoice_footer: null
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (data) setF(data);
	}, [data]);
	const text = (k) => ({
		value: f[k] ?? "",
		onChange: (e) => setF((x) => ({
			...x,
			[k]: e.target.value || null
		}))
	});
	async function save(e) {
		e.preventDefault();
		setBusy(true);
		const name = f.name || "My company";
		const { data: saved, error } = await db.from("company_settings").upsert({
			...f,
			name
		}, { onConflict: "company_id" }).select("company_id").single();
		if (!error && saved?.company_id) await db.from("companies").update({ name }).eq("id", saved.company_id);
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Company details saved.");
		qc.invalidateQueries({ queryKey: ["company"] });
		qc.invalidateQueries({ queryKey: ["my-companies"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Company details"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Printed at the top of every quote and invoice."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoPicker, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Company name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("phone") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("email") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Website",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Legal name, if different",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("legal_name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tax ID (EIN)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("tax_id") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mailing address for payments, if different",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("mailing_address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name customers see on emails",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: f.name,
							...text("email_from_name")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Customer email replies go to",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "the person who sends it",
							...text("email_reply_to")
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				children: busy ? "Saving…" : "Save company details"
			})
		]
	});
}
/** Upload the product pictures saved from inFlow (files named <product id>.jpg). */
function PhotosCard() {
	const qc = useQueryClient();
	const [files, setFiles] = (0, import_react.useState)([]);
	const [done, setDone] = (0, import_react.useState)(0);
	const [failed, setFailed] = (0, import_react.useState)(0);
	const [running, setRunning] = (0, import_react.useState)(false);
	async function run() {
		setRunning(true);
		setDone(0);
		setFailed(0);
		const ids = new Set((await fetchAll("products", "id")).map((p) => p.id));
		const queue = files.filter((f) => ids.has(f.name.replace(/\.[^.]+$/, "")));
		setFailed(files.length - queue.length);
		let i = 0;
		async function worker() {
			while (i < queue.length) {
				const f = queue[i++];
				const id = f.name.replace(/\.[^.]+$/, "");
				const path = `products/${id}.jpg`;
				if (!(await db.storage.from("product-photos").upload(path, f, {
					contentType: "image/jpeg",
					upsert: true
				})).error && !(await db.from("products").update({ picture_path: path }).eq("id", id)).error) setDone((d) => d + 1);
				else setFailed((x) => x + 1);
			}
		}
		await Promise.all([
			worker(),
			worker(),
			worker(),
			worker()
		]);
		setRunning(false);
		qc.invalidateQueries({ queryKey: ["product"] });
		toast.success("Photos are in.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Bring product photos over from inFlow"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Choose the whole product-photos folder" }),
					", go to the Synology folder",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Inflow → Export" }),
					", click ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "product-photos" }),
					" once and press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Upload" }),
					" (the browser will ask to confirm — say yes)."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				onDragOver: (e) => e.preventDefault(),
				onDrop: (e) => {
					e.preventDefault();
					setFiles(Array.from(e.dataTransfer.files).filter((f) => /\.jpe?g$/i.test(f.name)));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-5 w-5 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: "Choose the whole product-photos folder"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							className: "hidden",
							webkitdirectory: "",
							directory: "",
							onChange: (e) => setFiles(Array.from(e.target.files ?? []).filter((f) => /\.jpe?g$/i.test(f.name)))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-dashed p-4 hover:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-5 w-5 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: files.length ? `${files.length} pictures chosen` : "…or pick pictures (Ctrl + A), or drag them here"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							multiple: true,
							className: "hidden",
							onChange: (e) => setFiles(Array.from(e.target.files ?? []))
						})
					]
				})]
			}),
			files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				(running || done > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: (done + failed) / files.length * 100 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						done,
						" uploaded",
						failed ? ` · ${failed} skipped` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: run,
					disabled: running,
					children: running ? "Uploading…" : "Upload product photos"
				})
			] })
		]
	});
}
/** Saved footers to pick from on each quote, order, invoice, RMA or purchase order. */
function FootersCard() {
	const qc = useQueryClient();
	const { data: footers } = useFooters();
	const [adding, setAdding] = (0, import_react.useState)(false);
	const refresh = () => qc.invalidateQueries({ queryKey: ["doc-footers"] });
	async function add() {
		setAdding(true);
		const { error } = await db.from("doc_footers").insert({
			name: "New footer",
			body: "",
			sort: (footers?.length ?? 0) + 1
		});
		setAdding(false);
		if (error) toast.error(error.message);
		else refresh();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Saved footers"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Text for your documents: a line at the bottom of every page, a note at the end, or a whole page attached after it (like your Terms & Conditions). Save as many as you like and pick them on each document. Tick where each one is filled in automatically."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: add,
					disabled: adding,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a footer"]
				})]
			}),
			footers && footers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed p-4 text-sm text-muted-foreground",
				children: "No saved footers yet. Press Add a footer and paste your text in."
			}),
			(footers ?? []).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterRow, {
				footer: f,
				onSaved: refresh
			}, f.id))
		]
	});
}
function FooterRow({ footer, onSaved }) {
	const [f, setF] = (0, import_react.useState)(footer);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setF(footer), [footer]);
	const dirty = JSON.stringify(f) !== JSON.stringify(footer);
	async function save() {
		setBusy(true);
		const { error } = await db.from("doc_footers").update({
			name: f.name.trim() || "Footer",
			body: f.body,
			default_for: f.default_for,
			placement: f.placement
		}).eq("id", f.id);
		setBusy(false);
		if (error) toast.error(error.message);
		else {
			toast.success("Footer saved.");
			onSaved();
		}
	}
	async function remove() {
		if (!window.confirm(`Delete the footer "${f.name}"? Documents that already use it keep their text.`)) return;
		const { error } = await db.from("doc_footers").delete().eq("id", f.id);
		if (error) toast.error(error.message);
		else onSaved();
	}
	const toggle = (k, on) => setF((x) => ({
		...x,
		default_for: on ? [...x.default_for, k] : x.default_for.filter((y) => y !== k)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-xl border p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "font-medium",
					value: f.name,
					placeholder: "Name, e.g. Quote terms",
					onChange: (e) => setF({
						...f,
						name: e.target.value
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Delete this footer",
					onClick: remove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: "Prints at:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: f.placement,
					onValueChange: (v) => setF({
						...f,
						placement: v
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "h-8 w-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: PLACEMENTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: p.key,
						children: p.label
					}, p.key)) })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				rows: f.placement === "attach" ? 10 : 4,
				value: f.body,
				placeholder: "The text printed at the end of the document",
				onChange: (e) => setF({
					...f,
					body: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-4 gap-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "Fill in automatically on new:"
					}),
					FOOTER_KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
							checked: f.default_for.includes(k.key),
							onCheckedChange: (v) => toggle(k.key, v === true)
						}), k.label]
					}, k.key)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						className: "ml-auto",
						onClick: save,
						disabled: busy || !dirty,
						children: busy ? "Saving…" : dirty ? "Save footer" : "Saved"
					})
				]
			})
		]
	});
}
/** Company logo printed on quotes, invoices and purchase orders. */
function LogoPicker() {
	const qc = useQueryClient();
	const logo = useCompanyLogo();
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function upload(file) {
		if (!file) return;
		setBusy(true);
		const ext = file.name.split(".").pop()?.toLowerCase() || "png";
		const path = `company/${await activeCompanyId() ?? "none"}/logo-${Date.now()}.${ext}`;
		const err = (await db.storage.from("product-photos").upload(path, file, {
			contentType: file.type,
			upsert: true
		})).error ?? (await db.from("company_settings").update({ logo_path: path }).eq("company_id", await activeCompanyId() ?? "")).error;
		setBusy(false);
		if (err) toast.error(err.message);
		else {
			toast.success("Logo saved.");
			qc.invalidateQueries({ queryKey: ["company-logo"] });
		}
	}
	async function reset() {
		const { error } = await db.from("company_settings").update({ logo_path: null }).eq("company_id", await activeCompanyId() ?? "");
		if (error) toast.error(error.message);
		else qc.invalidateQueries({ queryKey: ["company-logo"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-4 rounded-xl border p-3",
		children: [logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: logo,
			alt: "Company logo",
			className: "h-14 max-w-[260px] object-contain"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground",
			children: "No logo yet"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 text-sm hover:bg-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
					" ",
					busy ? "Saving…" : "Change logo",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						className: "hidden",
						onChange: (e) => void upload(e.target.files?.[0])
					})
				]
			}), logo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: () => void reset(),
				children: "Remove logo"
			})]
		})]
	});
}
/** Who can sign in. Admins can add people, set admin or staff, reset passwords. */
function UsersCard() {
	const qc = useQueryClient();
	const { data: users, isLoading, error } = useQuery({
		queryKey: ["app-users"],
		queryFn: () => listUsers()
	});
	const { data: me } = useQuery({
		queryKey: ["my-user-id"],
		queryFn: async () => (await db.auth.getUser()).data.user?.id ?? null
	});
	const owner = (users ?? []).find((u) => u.owner);
	const canManage = !owner || owner.id === me;
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [f, setF] = (0, import_react.useState)({
		name: "",
		email: "",
		password: "",
		role: "staff",
		access: []
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: companies } = useMyCompanies();
	const working = companies?.find((c) => c.active)?.id;
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["app-users"] });
		qc.invalidateQueries({ queryKey: ["org-people-count"] });
		qc.invalidateQueries({ queryKey: ["company-members"] });
	};
	const startAdding = () => {
		setF((x) => ({
			...x,
			access: working ? [{
				company_id: working,
				is_admin: false,
				zones: null
			}] : []
		}));
		setAdding(true);
	};
	async function add(e) {
		e.preventDefault();
		if (f.role !== "admin" && !f.access.length) {
			toast.error("Tick at least one company they can open.");
			return;
		}
		setBusy(true);
		try {
			await addUser({ data: {
				name: f.name,
				email: f.email,
				password: f.password,
				role: f.role,
				zones: null,
				access: f.role === "admin" ? [] : f.access
			} });
			toast.success(`${f.email} can sign in now. Give them the password you typed.`);
			setF({
				name: "",
				email: "",
				password: "",
				role: "staff",
				access: []
			});
			setAdding(false);
			refresh();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "Users"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						"People who can sign in. The ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Owner" }),
						" is the only one who adds, removes or changes people, connects Stripe and enters the license key. An ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "admin of every company" }),
						" ",
						"does everything else, like the plan and backups. Everyone else opens only the companies ticked for them, and in each one is its admin (settings and deleting there), sees every section, or only some sections. Tick ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Can look, can't change" }),
						" for an accountant: they open, print and download, but can't change anything there."
					]
				})] }), !adding && canManage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: startAdding,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add user"]
				})]
			}),
			!canManage && owner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-lg bg-muted/60 px-3 py-2 text-sm",
				children: [
					"Only the Owner, ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: owner.name || owner.email }),
					", can add, remove or change people."
				]
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: add,
				className: "grid gap-3 rounded-xl border p-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.name,
							onChange: (e) => setF({
								...f,
								name: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email (they sign in with this)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							required: true,
							value: f.email,
							onChange: (e) => setF({
								...f,
								email: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "First password (at least 8 characters)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "text",
							required: true,
							autoComplete: "new-password",
							value: f.password,
							onChange: (e) => setF({
								...f,
								password: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Can do",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: f.role,
							onValueChange: (v) => setF({
								...f,
								role: v
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "staff",
								children: "Only the companies I tick below"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "admin",
								children: "Admin of every company (also users and plan)"
							})] })]
						})
					}),
					f.role !== "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessTable, {
							value: f.access,
							onChange: (company_id, next) => setF({
								...f,
								access: [...f.access.filter((x) => x.company_id !== company_id), ...next ? [next] : []]
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy,
							children: busy ? "Adding…" : "Add this user"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setAdding(false),
							children: "Cancel"
						})]
					})
				]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error.message
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: (users ?? []).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRow, {
					u,
					onChanged: refresh,
					canManage,
					isMe: u.id === me,
					meIsOwner: !!owner && owner.id === me
				}, u.id))
			})
		]
	});
}
var LEVEL_LABEL = {
	admin: "Admin of this company",
	all: "Every section",
	some: "Only some sections"
};
var levelOf = (a) => a.is_admin ? "admin" : a.zones ? "some" : "all";
/** For each company: does this person open it, and as what? */
function AccessTable({ value, onChange }) {
	const { data: companies } = useMyCompanies();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "divide-y rounded-lg border bg-muted/30",
		children: (companies ?? []).map((c) => {
			const a = value.find((x) => x.company_id === c.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-w-48 flex-1 items-center gap-2 font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "h-4 w-4",
							checked: !!a,
							onChange: (e) => onChange(c.id, e.target.checked ? {
								company_id: c.id,
								is_admin: false,
								zones: null
							} : null)
						}), c.name]
					}),
					a ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						"aria-label": `Access in ${c.name}`,
						className: "h-8 rounded-md border bg-background px-2 text-sm",
						value: levelOf(a),
						onChange: (e) => {
							const l = e.target.value;
							onChange(c.id, {
								company_id: c.id,
								is_admin: l === "admin",
								zones: l === "some" ? a.zones ?? ["Inventory"] : null,
								read_only: l === "admin" ? false : !!a.read_only
							});
						},
						children: Object.keys(LEVEL_LABEL).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: l,
							children: LEVEL_LABEL[l]
						}, l))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "Can't open"
					}),
					a && !a.is_admin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-1.5 text-sm",
						title: "For an accountant or bookkeeper: they can open, print and download, but can't add, change or delete anything in this company.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "h-4 w-4",
							checked: !!a.read_only,
							onChange: (e) => onChange(c.id, {
								...a,
								read_only: e.target.checked
							})
						}), "Can look, can't change (free)"]
					}),
					a?.zones && !a.is_admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "basis-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZonePicker, {
							zones: a.zones,
							onChange: (zones) => onChange(c.id, {
								...a,
								zones
							})
						})
					})
				]
			}, c.id);
		})
	});
}
/** Tick the sections this person may open. Home and Settings need an admin. */
function ZonePicker({ zones, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-x-4 gap-y-2 pl-6 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: "Can open:"
		}), ZONES.map((z) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "h-4 w-4",
				checked: zones.includes(z),
				onChange: (e) => {
					const next = e.target.checked ? [...zones, z] : zones.filter((x) => x !== z);
					if (next.length === 0) {
						toast.error("Tick at least one section.");
						return;
					}
					onChange(next);
				}
			}), z]
		}, z))]
	});
}
function UserRow({ u, onChanged, canManage, isMe, meIsOwner }) {
	const [pw, setPw] = (0, import_react.useState)(null);
	const [access, setAccess] = (0, import_react.useState)(u.access);
	(0, import_react.useEffect)(() => setAccess(u.access), [u.access]);
	async function run(p, msg) {
		try {
			await p;
			toast.success(msg);
			onChanged();
		} catch (err) {
			toast.error(err.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-3 px-4 py-3 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full max-w-xs rounded-md border border-transparent bg-transparent px-1 font-medium hover:border-input focus:border-input",
					defaultValue: u.name,
					placeholder: "Type their name (shows as Sales rep)",
					onBlur: (e) => {
						const name = e.target.value.trim();
						if (name !== u.name) run(changeUser({ data: {
							id: u.id,
							name
						} }), "Name saved.");
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted-foreground",
					children: [`${u.email} · `, u.last_sign_in_at ? `last signed in ${fmtDate(u.last_sign_in_at)}` : "has not signed in yet"]
				})]
			}),
			u.owner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full bg-lime-200 px-2.5 py-1 text-xs font-semibold text-lime-950 dark:bg-lime-900 dark:text-lime-100",
				children: "Owner"
			}),
			meIsOwner && !u.owner && u.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => {
					if (window.confirm(`Make ${u.name || u.email} the Owner? They will be the only one who can add or change people, connect Stripe and enter the license key. You stay an admin.`)) run(handOverOwner({ data: { id: u.id } }), "The Owner role is handed over.");
				},
				children: "Make Owner"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				disabled: !canManage || !!u.owner,
				value: u.role,
				onValueChange: (v) => void run(changeUser({ data: {
					id: u.id,
					role: v,
					zones: null
				} }), v === "admin" ? "Now an admin of every company." : "Saved. Tick the companies below."),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "h-8 w-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "admin",
					children: "Admin of every company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "staff",
					children: "Chosen companies"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "order-last basis-full",
				children: u.role === "admin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: u.owner ? "Opens every company; the only one who adds or changes people, connects Stripe and enters the license key." : "Opens every company; also manages the plan and backups."
				}) : !canManage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Opens ",
						access.length,
						" ",
						access.length === 1 ? "company" : "companies",
						"."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [access.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-xs font-medium text-amber-700 dark:text-amber-300",
					children: "Can't open any company yet. Tick at least one:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessTable, {
					value: access,
					onChange: (company_id, next) => {
						const before = access;
						setAccess([...access.filter((x) => x.company_id !== company_id), ...next ? [next] : []]);
						setCompanyAccess({ data: {
							id: u.id,
							company_id,
							open: !!next,
							is_admin: next?.is_admin ?? false,
							zones: next?.zones ?? null,
							read_only: !!next?.read_only
						} }).then(() => {
							toast.success("Saved.");
							onChanged();
						}).catch((err) => {
							setAccess(before);
							toast.error(err.message);
						});
					}
				})] })
			}),
			!(canManage || isMe) ? null : pw == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => setPw(""),
				children: "New password"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-1",
				onSubmit: (e) => {
					e.preventDefault();
					run(changeUser({ data: {
						id: u.id,
						password: pw
					} }), "Password changed.").then(() => setPw(null));
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 w-40",
					placeholder: "New password",
					autoComplete: "new-password",
					value: pw,
					onChange: (e) => setPw(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					type: "submit",
					children: "Save password"
				})]
			}),
			canManage && !u.owner && !isMe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "ghost",
				"aria-label": "Remove this user",
				onClick: () => {
					if (window.confirm(`Remove ${u.email}? They won't be able to sign in. Their past work stays.`)) run(removeUser({ data: { id: u.id } }), "User removed.");
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
			})
		]
	});
}
/** One-time: everything sold before today is invoiced and paid. */
function CloseOutCard() {
	const qc = useQueryClient();
	const { data } = useQuery({
		queryKey: ["close-out-preview"],
		queryFn: () => fetchAll("sales_orders", "id,number,status,balance,stock_taken_at")
	});
	const [day, setDay] = (0, import_react.useState)(() => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const [ship, setShip] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const live = (data ?? []).filter((r) => ![
		"quote",
		"rma",
		"cancelled"
	].includes(r.status) && !r.number.startsWith("RMA-"));
	const notInvoiced = live.filter((r) => r.status === "open").length;
	const owing = live.filter((r) => Number(r.balance) > .005);
	const owed = owing.reduce((s, r) => s + Number(r.balance), 0);
	const notShipped = live.filter((r) => !r.stock_taken_at).length;
	const nothing = notInvoiced === 0 && owing.length === 0 && (!ship || notShipped === 0);
	async function run() {
		const msg = `Mark all ${live.length} sales orders and invoices as invoiced and paid as of ${day}?\n\nThis adds a "Paid before switch-over" payment to ${owing.length} invoices ($${owed.toFixed(2)} in all). Quotes and RMAs are not touched.`;
		if (!window.confirm(msg)) return;
		setBusy(true);
		const { data: r, error } = await db.rpc("close_out_sales", {
			_as_of: (/* @__PURE__ */ new Date(day + "T12:00:00")).toISOString(),
			_mark_shipped: ship
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		const x = r;
		toast.success(`Done: ${x.invoiced} invoiced, ${x.payments} marked paid${ship ? `, ${x.shipped} marked shipped` : ""}.`);
		qc.invalidateQueries();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Start fresh: mark all invoices paid"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Use once, when everything sold so far is invoiced and paid. Quotes and RMAs stay as they are. Stock is not changed."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: notInvoiced }),
							" ",
							notInvoiced === 1 ? "order" : "orders",
							" not invoiced yet"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: owing.length }),
							" invoices and orders still owe money, in the books or not (",
							owed.toLocaleString("en-US", {
								style: "currency",
								currency: "USD"
							}),
							")"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: notShipped }), " not marked shipped"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: ["Paid as of", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						className: "h-9 w-40",
						value: day,
						onChange: (e) => setDay(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
						checked: ship,
						onCheckedChange: (v) => setShip(v === true)
					}), "Also mark them shipped"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "destructive",
				onClick: () => void run(),
				disabled: busy || !data || nothing,
				children: busy ? "Working…" : nothing ? "Everything is already paid" : "Mark all invoices invoiced and paid"
			})
		]
	});
}
/** Quote follow-ups: remind at 14 and 30 days, close at 45 (quotes are good for 30 days). */
function FollowupCard() {
	const qc = useQueryClient();
	const { data: rules } = useQuery({
		queryKey: ["followup-rules"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			const r = { ...DEFAULT_RULES };
			if (data) Object.keys(r).forEach((k) => {
				const v = data[k];
				if (v != null) r[k] = v;
			});
			return r;
		}
	});
	const { data: quotes } = useQuery({
		queryKey: ["followup-quotes"],
		queryFn: () => fetchAll("sales_orders", "id,number,status,order_date,followup_count,customer_name,contact_name,email,total")
	});
	const [f, setF] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (rules) setF(rules);
	}, [rules]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!f) return null;
	const stages = (quotes ?? []).map((q) => stageOf(q, f));
	const n1 = stages.filter((x) => x === "first").length;
	const n2 = stages.filter((x) => x === "second").length;
	const nClose = stages.filter((x) => x === "close").length;
	async function save(next) {
		setF(next);
		const { error } = await db.from("company_settings").update(next).eq("company_id", await activeCompanyId() ?? "");
		if (error) toast.error(error.message);
		else {
			toast.success("Saved.");
			qc.invalidateQueries({ queryKey: ["followup-rules"] });
		}
	}
	async function runNow() {
		if (nClose > 0 && !window.confirm(`This closes ${nClose} quotes older than ${f.quote_close_days} days. You can reopen any of them later. Go ahead?`)) return;
		setBusy(true);
		try {
			const r = await runFollowupsNow();
			toast.success(`Done: ${r.closed} closed, ${r.due} on today's follow-up list${r.emailed ? `, ${r.emailed} customers emailed` : ""}.`);
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const num = (k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		className: "h-8 w-16 text-right",
		inputMode: "numeric",
		value: f[k],
		onChange: (e) => setF({
			...f,
			[k]: Number(e.target.value) || 0
		}),
		onBlur: () => void save(f)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Quote follow-ups"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every morning: quotes that need a follow-up show on Home and are emailed to the office. Old quotes are closed (you can reopen them)."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					checked: f.followup_enabled,
					onCheckedChange: (v) => void save({
						...f,
						followup_enabled: v === true
					})
				}), "Turn on daily follow-ups"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-x-5 gap-y-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"1st follow-up after ",
							num("followup_days1"),
							" days"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"2nd after ",
							num("followup_days2"),
							" days"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [
							"Close the quote after ",
							num("quote_close_days"),
							" days"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					checked: f.followup_auto_email,
					onCheckedChange: (v) => void save({
						...f,
						followup_auto_email: v === true
					})
				}), "Also email the customer automatically (a short, polite note — no PDF)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n1 }), " need a 1st follow-up"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n2 }), " need a 2nd follow-up"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: nClose }), " would be closed"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void runNow(),
				disabled: busy,
				children: busy ? "Working…" : "Run today's follow-ups now"
			})
		]
	});
}
/** Undo "Start fresh" for single invoices that weren't really paid. */
function UndoCloseOutCard() {
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["close-out-payments"],
		queryFn: async () => {
			const { data: pays, error: e1 } = await db.from("payments").select("id, amount, paid_on, sales_order_id").eq("method", "Paid before switch-over").limit(2e3);
			if (e1) throw new Error(e1.message);
			const ids = [...new Set((pays ?? []).map((p) => p.sales_order_id).filter(Boolean))];
			const orders = /* @__PURE__ */ new Map();
			for (let i = 0; i < ids.length; i += 150) {
				const { data: so, error: e2 } = await db.from("sales_orders").select("id, number, customer_name, total").in("id", ids.slice(i, i + 150));
				if (e2) throw new Error(e2.message);
				(so ?? []).forEach((o) => orders.set(o.id, o));
			}
			return (pays ?? []).map((p) => ({
				id: p.id,
				amount: p.amount,
				paid_on: p.paid_on,
				sales_orders: p.sales_order_id && orders.get(p.sales_order_id) || null
			})).sort((x, y) => (x.sales_orders?.number ?? "").localeCompare(y.sales_orders?.number ?? "", void 0, { numeric: true })).reverse();
		}
	});
	const [q, setQ] = (0, import_react.useState)("");
	if (isLoading || error || !data || data.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: "Invoices marked paid by Start fresh"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-muted-foreground",
			children: isLoading ? "Loading…" : error ? `Couldn't load the list: ${error.message}` : "None — Start fresh hasn't marked any invoices paid."
		})]
	});
	const words = q.toLowerCase().split(/\s+/).filter(Boolean);
	const rows = data.filter((p) => {
		const hay = `${p.sales_orders?.number ?? ""} ${p.sales_orders?.customer_name ?? ""}`.toLowerCase();
		return words.every((w) => hay.includes(w));
	});
	async function undo(p) {
		if (!window.confirm(`Mark ${p.sales_orders?.number} unpaid again? It will owe ${fmtMoney(p.amount)}.`)) return;
		const { error } = await db.from("payments").delete().eq("id", p.id);
		if (error) toast.error(error.message);
		else {
			toast.success(`${p.sales_orders?.number} is unpaid again.`);
			qc.invalidateQueries();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Invoices marked paid by Start fresh"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					data.length,
					" invoices got a “Paid before switch-over” payment. If one wasn't really paid, press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Mark unpaid again" }),
					" and it shows as owed."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Search invoice # or customer",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "max-h-96 divide-y overflow-y-auto rounded-xl border",
				children: rows.slice(0, 200).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-3 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-28 font-medium",
							children: p.sales_orders?.number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate",
							children: p.sales_orders?.customer_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-24 text-right font-semibold",
							children: fmtMoney(p.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void undo(p),
							children: "Mark unpaid again"
						})
					]
				}, p.id))
			})
		]
	});
}
/** Nightly backups of all office data, kept 30 days (+ the 1st of each month for a year). */
function BackupCard() {
	const qc = useQueryClient();
	const { data, isLoading, error } = useQuery({
		queryKey: ["backups"],
		queryFn: () => listBackups()
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [showAll, setShowAll] = (0, import_react.useState)(false);
	const [restoring, setRestoring] = (0, import_react.useState)(null);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const files = data ?? [];
	const kb = (n) => n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.round(n / 1e3)} KB`;
	async function now() {
		setBusy(true);
		try {
			const r = await backupNow();
			const rows = Object.values(r.counts).reduce((a, b) => a + b, 0);
			toast.success(`Backup saved: ${r.name} (${rows.toLocaleString()} records).`);
			qc.invalidateQueries({ queryKey: ["backups"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function pickFile(file) {
		if (!file) return;
		if (!file.name.endsWith(".json.gz")) {
			toast.error("Choose a backup file that ends in .json.gz");
			return;
		}
		setUploading(true);
		try {
			const buf = new Uint8Array(await file.arrayBuffer());
			let bin = "";
			for (let i = 0; i < buf.length; i += 32768) bin += String.fromCharCode(...buf.subarray(i, i + 32768));
			const { name } = await uploadBackup({ data: { fileBase64: btoa(bin) } });
			setRestoring({
				name,
				label: file.name
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setUploading(false);
		}
	}
	async function download(name) {
		try {
			const { url } = await backupLink({ data: { name } });
			window.location.href = url;
		} catch (e) {
			toast.error(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "flex items-center gap-2 font-display text-xl font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, { className: "h-5 w-5" }),
						" ",
						DESKTOP_APP ? "Move books from Tallkeep online" : "Backups"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: DESKTOP_APP ? "Bring your books over from Tallkeep online: download a backup there, then restore it here. These are also a second kind of copy, made inside the app." : "Every night all office data (products, stock, customers, quotes, invoices, purchase orders, payments and settings) is saved as one file. The last 30 days are kept, plus the 1st of each month for a year. Your Synology also downloads a copy each night."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => void now(),
					disabled: busy,
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, { className: "h-4 w-4" }), busy ? "Saving backup…" : "Back up now"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: error.message.includes("not found") ? "The backup storage isn't set up yet." : error.message
			}),
			!isLoading && !error && files.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No backups yet. Press Back up now to make the first one."
			}),
			files.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: (showAll ? files : files.slice(0, 5)).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 font-medium",
							children: backupLabel(f.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: kb(f.size)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void download(f.name),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => setRestoring({
								name: f.name,
								label: backupLabel(f.name)
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Restore…"]
						})
					]
				}, f.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [files.length > 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => setShowAll(!showAll),
					children: showAll ? "Show fewer" : `Show all ${files.length} backups`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex cursor-pointer items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium hover:bg-muted",
					children: [
						uploading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
						uploading ? "Reading the file…" : DESKTOP_APP ? "Restore a backup from Tallkeep online…" : "Restore from a file (e.g. from the Synology)…",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: ".gz",
							className: "hidden",
							disabled: uploading,
							onChange: (e) => {
								pickFile(e.target.files?.[0]);
								e.target.value = "";
							}
						})
					]
				})]
			}),
			restoring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RestoreDialog, {
				name: restoring.name,
				label: restoring.label,
				onClose: () => setRestoring(null),
				onDone: () => {
					setRestoring(null);
					qc.invalidateQueries();
				}
			})
		]
	});
}
function backupLabel(name) {
	const day = fmtDate(`${name.slice(7, 17)}T12:00:00`);
	const m = name.match(/-before-restore-(\d{2})(\d{2})\./);
	return m ? `${day} · saved before a restore (${m[1]}:${m[2]})` : day;
}
/** Choose what to put back from one backup, see the numbers, type RESTORE, go. */
function RestoreDialog({ name, label, onClose, onDone }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["backup-summary", name],
		queryFn: () => summarizeBackup({ data: { name } })
	});
	const [parts, setParts] = (0, import_react.useState)([]);
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const total = (rows, k) => rows.reduce((s, r) => s + r[k], 0);
	async function go() {
		setBusy(true);
		try {
			const r = await restoreFromBackup({ data: {
				name,
				parts,
				confirm
			} });
			const back = Object.values(r.restored).reduce((a, b) => a + b, 0);
			const gone = Object.values(r.removed).reduce((a, b) => a + b, 0);
			toast.success(`Restored ${back.toLocaleString()} records and removed ${gone.toLocaleString()} added since. Your data from before is saved as a backup, so this can be undone.` + (r.newLogins ? ` ${r.newLogins} login${r.newLogins === 1 ? "" : "s"} added: set each one's password in Options → People.` : ""), { duration: 2e4 });
			onDone();
		} catch (e) {
			toast.error(e.message, { duration: 12e3 });
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && !busy && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Restore from backup: ", label] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"Tick what to put back the way it was",
					data?.made_at ? ` on ${new Date(data.made_at).toLocaleString()}` : "",
					". Records added since then are removed, changed ones are set back, deleted ones come back. Before anything changes, today's data is saved as a backup, so you can undo this."
				] })] }),
				isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Reading the backup…"
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: error.message
				}),
				data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-xl border",
					children: data.parts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex cursor-pointer items-start gap-3 px-4 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							className: "mt-0.5 h-4 w-4",
							checked: parts.includes(p.key),
							onChange: (e) => setParts((s) => e.target.checked ? [...s, p.key] : s.filter((x) => x !== p.key))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: p.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted-foreground",
								children: [
									"In the backup: ",
									total(p.tables, "backup").toLocaleString(),
									" records · in the app now: ",
									total(p.tables, "now").toLocaleString()
								]
							})]
						})]
					}, p.key))
				}),
				parts.length > 0 && parts.length < 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Restoring only some parts: anything else that points to a removed record keeps working, but loses that link (for example an invoice line for a product that is removed keeps its description). For a full \"go back to that day\", tick all of them."
				}),
				parts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Type RESTORE to confirm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: confirm,
						onChange: (e) => setConfirm(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					disabled: busy,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "destructive",
					onClick: () => void go(),
					disabled: busy || !parts.length || confirm !== "RESTORE",
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), busy ? "Restoring… don't close this page" : "Restore the ticked parts"]
				})] })
			]
		})
	});
}
/** Companies: add one, rename, choose who may open it. Admins can open every company. */
function CompaniesCard() {
	const qc = useQueryClient();
	const { data: companies, error } = useMyCompanies();
	const { data: users } = useQuery({
		queryKey: ["app-users"],
		queryFn: () => listUsers()
	});
	const { data: members } = useQuery({
		queryKey: ["company-members"],
		queryFn: async () => {
			const { data } = await db.from("company_members").select("company_id,user_id");
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["my-companies"] });
		qc.invalidateQueries({ queryKey: ["company-members"] });
	};
	if (error || !companies?.length) return null;
	async function rename(id, next) {
		const { error: err } = await db.from("companies").update({ name: next }).eq("id", id);
		if (err) toast.error(err.message);
		else {
			toast.success("Name saved.");
			refresh();
		}
	}
	async function toggle(companyId, userId, on) {
		const { error: err } = on ? await db.from("company_members").insert({
			company_id: companyId,
			user_id: userId
		}) : await db.from("company_members").delete().eq("company_id", companyId).eq("user_id", userId);
		if (err) toast.error(err.message);
		else refresh();
	}
	const staff = (users ?? []).filter((u) => u.role !== "admin");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Companies"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Each company has its own products, customers, invoices, numbers and settings. Admins can open every company; tick who else may open each one (or do it in Options → People). Switch company at the top of the menu."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y rounded-xl border",
				children: companies.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "min-w-0 flex-1 rounded-md border border-transparent bg-transparent px-1 font-medium hover:border-input focus:border-input",
							defaultValue: c.name,
							onBlur: (e) => {
								const next = e.target.value.trim();
								if (next && next !== c.name) rename(c.id, next);
							}
						}), c.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary",
							children: "Working in this one"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => void switchCompany(c.id),
							children: "Switch to this company"
						})]
					}), staff.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Who can open it:"
						}), staff.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "h-4 w-4",
								checked: (members ?? []).some((m) => m.company_id === c.id && m.user_id === u.id),
								onChange: (e) => void toggle(c.id, u.id, e.target.checked)
							}), u.name || u.email]
						}, u.id))]
					})]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/setup-company",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Set up a new company"]
				})
			})
		]
	});
}
/** Turn optional parts on or off for the company you're working in. */
function AddonsCard() {
	const qc = useQueryClient();
	const { data: on } = useAddons();
	const { data: type } = useQuery({
		queryKey: ["company-addons", "type"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("business_type").maybeSingle();
			return data?.business_type ?? null;
		}
	});
	async function save(patch, msg) {
		const { error } = await db.from("company_settings").update(patch).eq("company_id", await activeCompanyId() ?? "");
		if (error) return void toast.error(error.message);
		toast.success(msg);
		qc.invalidateQueries({ queryKey: ["company-addons"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl font-semibold",
			children: "Features"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "What this company uses. Turning a feature off hides it from the menu; nothing is deleted, and turning it back on brings everything back."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturePicker, {
			type: type ?? null,
			features: on ?? [],
			onType: (t) => {
				if (!window.confirm(`Set this company to "${BUSINESS_TYPES[t].label}" and turn on its usual features? Features you turned on yourself stay on.`)) return;
				save({
					business_type: t,
					addons: Array.from(/* @__PURE__ */ new Set([...on ?? [], ...BUSINESS_TYPES[t].features]))
				}, `Set to ${BUSINESS_TYPES[t].label}.`);
			},
			onToggle: (k, enable) => {
				save({ addons: enable ? [...on ?? [], k] : (on ?? []).filter((x) => x !== k) }, `${ADDONS[k].label} turned ${enable ? "on" : "off"}.`);
			}
		})]
	});
}
/** Books start date, default bank account, and rebuilding the books. */
function AccountingCard() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data, error } = useQuery({
		queryKey: ["books-settings"],
		queryFn: async () => {
			const { data, error } = await db.from("company_settings").select("books_start_date,default_bank_account_id").maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const [start, setStart] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setStart(data?.books_start_date ?? ""), [data]);
	(0, import_react.useEffect)(() => {
		const show = () => {
			const el = document.getElementById("books-start");
			if (!el) return;
			el.scrollIntoView({
				block: "center",
				behavior: "smooth"
			});
			el.focus();
		};
		if (window.location.hash === "#accounting") setTimeout(show, 300);
		window.addEventListener("tallkeep:books-start", show);
		return () => window.removeEventListener("tallkeep:books-start", show);
	}, []);
	if (error) return null;
	const banks = (accounts ?? []).filter((a) => a.kind === "bank" && a.is_active);
	async function rebuild(msg) {
		const { data: r, error: e } = await db.rpc("rebuild_books");
		if (e) throw e;
		const { data: cs } = await db.from("company_settings").select("books_start_date").maybeSingle();
		const day = cs?.books_start_date;
		let left = 0;
		if (day) {
			const { count } = await db.from("sales_orders").select("id", {
				count: "exact",
				head: true
			}).in("status", [
				"invoiced",
				"paid",
				"completed"
			]).or(`invoice_date.lt.${day},and(invoice_date.is.null,order_date.lt.${day})`);
			left = count ?? 0;
		}
		toast.success(`${msg} ${r.entries} entries in the books.` + (left ? ` ${left} invoice${left === 1 ? " is" : "s are"} dated before the books start and left out.` : ""));
		qc.invalidateQueries();
	}
	async function saveStart() {
		setBusy(true);
		try {
			const { error: e } = await db.from("company_settings").update({ books_start_date: start || null }).eq("company_id", await activeCompanyId() ?? "");
			if (e) throw e;
			await rebuild(start ? "Books start date saved." : "Books turned off.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function setBank(id) {
		const { error: e } = await db.from("company_settings").update({ default_bank_account_id: id }).eq("company_id", await activeCompanyId() ?? "");
		if (e) toast.error(e.message);
		else {
			toast.success("Saved. Payments go to this account unless you pick another.");
			qc.invalidateQueries({ queryKey: ["books-settings"] });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Accounting"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "From the start date, every invoice, payment, received purchase order, bill and stock change writes itself into the books. Before that date nothing is posted; enter what each account held as opening balances."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: "Books start on"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "books-start",
							type: "date",
							value: start,
							onChange: (e) => setStart(e.target.value),
							className: `w-44 ${!data?.books_start_date ? "ring-2 ring-amber-400" : ""}`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void saveStart(),
						disabled: busy || start === (data?.books_start_date ?? ""),
						children: busy ? "Saving…" : "Save start date"
					}),
					data?.books_start_date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/journal",
							search: { opening: 1 },
							children: "Enter opening balances"
						})
					})
				]
			}),
			banks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block max-w-sm space-y-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: "Customer payments go into"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: data?.default_bank_account_id ?? "",
					onValueChange: (v) => void setBank(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a bank account" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: banks.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: a.id,
						children: accountLabel(a)
					}, a.id)) })]
				})]
			}),
			!data?.books_start_date && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-100",
				children: [
					"Pick the day and press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Save start date" }),
					". Then ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Rebuild the books" }),
					" shows here and writes everything from that day into the books. Coming from QuickBooks? Use the day after your last QuickBooks entry, so nothing counts twice."
				]
			}),
			data?.books_start_date && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 border-t pt-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					size: "sm",
					disabled: busy,
					onClick: () => {
						setBusy(true);
						rebuild("Books rebuilt.").catch((e) => toast.error(e.message)).finally(() => setBusy(false));
					},
					children: "Rebuild the books"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "Writes every automatic entry again from the documents. Use it after a restore or if a report looks wrong. Entries typed by hand are kept."
				})]
			})
		]
	});
}
/** Your plan: what it includes and how much of it you use. */
function PlanCard() {
	const { data: account } = useMyAccount();
	const { data: companies } = useMyCompanies();
	const { data: counts } = useQuery({
		queryKey: ["org-people-count"],
		queryFn: () => peopleCount()
	});
	const people = counts?.working;
	if (!account) return null;
	const days = trialDaysLeft(account);
	const writable = canWrite(account);
	const status = !writable ? "Read-only" : account.status === "trial" ? `Free trial, ${days} day${days === 1 ? "" : "s"} left` : account.status === "past_due" ? "Payment is late" : "Active";
	const of = (n, max) => max == null ? `${n ?? 0}` : `${n ?? 0} of ${max}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Your plan"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					account.edition === "desktop" ? "Desktop" : "Cloud",
					" · ",
					status
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:max-w-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Companies"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-lg font-semibold",
						children: of(companies?.length, account.companies_allowed)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "People who can make changes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-lg font-semibold",
							children: of(people, account.users_allowed)
						}),
						!!counts?.lookOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-xs text-muted-foreground",
							children: [
								"+ ",
								counts.lookOnly,
								" look-only (free)"
							]
						})
					]
				})]
			}),
			!writable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "Your books are read-only. You can still open, print and download everything."
			}),
			!DESKTOP_APP && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/plan",
				className: "inline-block text-sm font-semibold text-primary underline",
				children: writable ? "Plan & billing" : "Choose a plan"
			})
		]
	});
}
/** Desktop version: the address other office computers and phones use to open these books. */
var DESKTOP_APP = !!{
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_PROJECT_ID": "rmxenvanqycmhesadcen",
	"VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_tallkeep_desktop",
	"VITE_SUPABASE_URL": "http://localhost:4600",
	"VITE_TALLKEEP_DESKTOP": "1",
	"VITE_TALLKEEP_VERSION": "0.26.51"
}["VITE_TALLKEEP_DESKTOP"];
var officeBridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
async function backupCall(method, path = "", body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch(`/tallkeep/backups${path}`, {
		method,
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: body === void 0 ? null : JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
var hourLabel = (h) => new Date(2e3, 0, 1, h).toLocaleTimeString([], {
	hour: "numeric",
	minute: "2-digit"
});
var sizeLabel = (n) => n === void 0 ? "" : n > 1e6 ? `${(n / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;
var whenLabel = (iso) => new Date(iso).toLocaleString([], {
	dateStyle: "medium",
	timeStyle: "short"
});
/** Desktop: a copy of all the books every night, in a folder the office picks. */
function NightlyBackupCard() {
	const qc = useQueryClient();
	const { data, error } = useQuery({
		queryKey: ["nightly-backups"],
		queryFn: () => backupCall("GET"),
		refetchInterval: (q) => q.state.data?.busy ? 2e3 : 3e4
	});
	const [folder, setFolder] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [office, setOffice] = (0, import_react.useState)(false);
	const [oneCo, setOneCo] = (0, import_react.useState)("");
	const { data: cos = [] } = useQuery({
		queryKey: ["backup-companies"],
		queryFn: async () => {
			const { data: rows } = await supabase.from("companies").select("id,name").order("name");
			return rows ?? [];
		}
	});
	(0, import_react.useEffect)(() => {
		officeBridge().isOffice?.().then((v) => setOffice(!!v));
	}, []);
	(0, import_react.useEffect)(() => {
		if (data) setFolder(data.folder === data.defaultFolder ? "" : data.folder);
	}, [data?.folder, data?.defaultFolder]);
	const save = async (change) => {
		setSaving(true);
		try {
			qc.setQueryData(["nightly-backups"], await backupCall("PUT", "", change));
			toast.success("Saved.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setSaving(false);
		}
	};
	const runNow = async (company) => {
		setRunning(true);
		try {
			await backupCall("POST", "/run", company ? { company } : {});
			toast.success(company ? `Backup of ${cos.find((c) => c.id === company)?.name ?? "the company"} made.` : "Backup made.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setRunning(false);
			qc.invalidateQueries({ queryKey: ["nightly-backups"] });
		}
	};
	const pick = async () => {
		const f = await officeBridge().chooseFolder?.(data?.folder);
		if (f) {
			setFolder(f);
			await save({ folder: f });
		}
	};
	const restore = async () => {
		const r = await officeBridge().restoreBooks?.(data?.folder);
		if (r && !r.ok && !r.canceled) toast.error(r.error ?? "That didn't work.");
	};
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 text-sm text-muted-foreground sm:p-6",
		children: ["Nightly backups: ", error.message]
	});
	const last = data?.last;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Nightly backup"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Every night Tallkeep saves a copy of all your books (every company, user and attached file) to a folder. The newest 30 are kept. From any backup you can put back all the companies, or just one. Pick a folder on another drive, like your Synology, so a broken computer can't take your books with it."
			})] }),
			last && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("rounded-xl border p-3 text-sm", last.ok ? "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100" : "border-red-300 bg-red-50 text-red-900 dark:border-red-800 dark:bg-red-950/40 dark:text-red-100"),
				children: last.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"Last backup: ",
					whenLabel(last.at),
					" · ",
					sizeLabel(last.size)
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					"The last backup didn't work (",
					whenLabel(last.at),
					"): ",
					last.error,
					data?.lastOk && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						" Last good one: ",
						whenLabel(data.lastOk.at),
						"."
					] })
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-2",
				onSubmit: (e) => {
					e.preventDefault();
					save({ folder });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "backup-folder",
						children: "Backup folder"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "backup-folder",
								value: folder,
								onChange: (e) => setFolder(e.target.value),
								placeholder: data?.defaultFolder ?? "",
								className: "min-w-0 flex-1 font-mono text-sm"
							}),
							office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => void pick(),
								disabled: saving,
								children: "Choose folder…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: saving,
								children: "Save folder"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"The folder is on the office computer. For a Synology, type its network path, like",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: "\\\\SYNOLOGY\\Backups\\Tallkeep"
							}),
							". Leave empty to keep backups on this computer only."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "backup-hour",
						children: "Back up every night at"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						id: "backup-hour",
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						value: data?.hour ?? 1,
						onChange: (e) => void save({ hour: Number(e.target.value) }),
						disabled: saving,
						children: Array.from({ length: 24 }, (_, h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: h,
							children: hourLabel(h)
						}, h))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "If the computer is off then, it backs up soon after Tallkeep opens."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void runNow(),
					disabled: running || data?.busy,
					children: running || data?.busy ? "Backing up…" : "Back up all companies now"
				}), office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void restore(),
					children: "Put the books back from a backup…"
				})]
			}),
			cos.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						"aria-label": "Company to back up",
						className: "h-9 min-w-0 rounded-md border bg-background px-2 text-sm",
						value: oneCo,
						onChange: (e) => setOneCo(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Pick a company…"
						}), cos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: !oneCo || running || data?.busy,
						onClick: () => void runNow(oneCo),
						children: "Back up only this company"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: "A file with just that company, to keep or move to another Tallkeep."
					})
				]
			}),
			!!data?.files.length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Newest backups in the folder"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y rounded-xl border text-sm",
					children: data.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 px-3 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate font-mono text-xs",
							children: f.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex shrink-0 items-center gap-2 text-muted-foreground",
							children: [sizeLabel(f.size), !office && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupPutBack, { name: f.name })]
						})]
					}, f.name))
				})]
			})
		]
	});
}
function OfficeComputerCard() {
	const { data } = useQuery({
		queryKey: ["office-computer"],
		queryFn: async () => {
			return await (await fetch("/tallkeep/health")).json();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "This office computer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Your books are kept on this computer",
					data?.name ? ` (${data.name})` : "",
					". Other computers and phones on the office network open Tallkeep at:"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: (data?.addresses ?? []).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "font-mono text-lg font-semibold",
					children: a
				}, a))
			}),
			data?.connectUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"From anywhere (Tallkeep Connect):",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono font-semibold",
						children: data.connectUrl
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: data?.edition === "docker" ? "Tallkeep runs in Docker on this server, day and night, whether anyone is signed in or not." : data?.edition === "service" ? "Tallkeep runs as a Windows service: it keeps working even when no one is signed in to this computer. Keep the computer on." : "Keep this computer on, with Tallkeep open, while others work. Tallkeep keeps it from going to sleep (the screen can still turn off)."
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
