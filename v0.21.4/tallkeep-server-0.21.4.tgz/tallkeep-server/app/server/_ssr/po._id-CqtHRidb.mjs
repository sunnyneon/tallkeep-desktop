import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, M as RotateCcw, Nn as ArrowLeft, R as Plus, Wt as DollarSign, Y as PackagePlus, at as Mail, g as Trash2, kn as Ban, nn as ChevronsUpDown, qt as Copy, sn as Check } from "../_libs/lucide-react.mjs";
import { c as usePaymentTerms, d as useTaxRates, i as useIsAdmin, o as useLocations } from "./queries-Chjya1cy.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-C_XVL5mk.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { a as CommandItem, c as PopoverContent, i as CommandInput, l as PopoverTrigger, n as CommandEmpty, o as CommandList, s as Popover, t as Command$1, u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as addVendor, n as addLocation, r as addTerms } from "./quickadd-Xo4-V0Jo.mjs";
import { n as PAY_STYLE, t as INV_STYLE, u as nextNumber } from "./sales-CAB3s83f.mjs";
import { t as SideLayout } from "./SideList-CptILfOc.mjs";
import { i as poTotals, n as poLineTotal, r as poPayStatus, t as poInvStatus } from "./purchasing-CjrJJbX-.mjs";
import { t as Route } from "./po._id-fdv5UKhf.mjs";
import { t as ScanAddButton } from "./ScanAdd-C1OT5gLg.mjs";
import { t as MoneyAccountPick } from "./MoneyAccountPick-DbpNcfah.mjs";
import { a as defaultsFor, n as NO_FOOTERS, s as useFooters } from "./footers-BNGmbiMB.mjs";
import { n as FooterPicker, r as NewProductDialog, t as EmailDocDialog } from "./NewProductDialog-CoTMPmVL.mjs";
import { n as useCompanyLogo, t as PrintFrame } from "./PrintFrame-PJ2rEoZR.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/po._id-CqtHRidb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = () => ({
	status: "open",
	vendor_id: null,
	vendor_name: null,
	vendor_order_number: null,
	contact_name: null,
	phone: null,
	vendor_address: null,
	ship_to_address: null,
	location_id: null,
	order_date: (/* @__PURE__ */ new Date()).toISOString(),
	due_date: null,
	payment_terms_id: null,
	carrier: null,
	tax_name: null,
	tax_rate: 0,
	subtotal: 0,
	tax: 0,
	freight: 0,
	total: 0,
	amount_paid: 0,
	balance: 0,
	remarks: null,
	custom: {},
	stock_received_at: null,
	...NO_FOOTERS
});
var newLine = (no) => ({
	id: crypto.randomUUID(),
	line_no: no,
	product_id: null,
	vendor_code: null,
	description: "",
	qty: 1,
	unit: null,
	unit_cost: 0,
	discount: 0,
	discount_is_percent: true,
	line_total: 0,
	qty_received: 0,
	_new: true
});
function POPage() {
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const isNew = id === "new";
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: isAdmin } = useIsAdmin();
	const { data: locations } = useLocations();
	const { data: terms } = usePaymentTerms();
	const { data: taxes } = useTaxRates();
	const { data: loaded, isLoading } = useQuery({
		queryKey: ["po", id],
		enabled: !isNew,
		queryFn: async () => {
			const { data, error } = await db.from("purchase_orders").select("*, purchase_order_lines(*), payments(*)").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "full"],
		queryFn: () => fetchAll("vendors", "*")
	});
	const { data: products } = useQuery({
		queryKey: ["products", "pick-po"],
		queryFn: () => fetchAll("products", "id,name,description,cost,unit,item_type")
	});
	const { data: company } = useQuery({
		queryKey: ["company"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			return data ?? {
				name: "",
				address: null,
				phone: null,
				email: null,
				website: null
			};
		}
	});
	const [po, setPo] = (0, import_react.useState)(blank());
	const [lines, setLines] = (0, import_react.useState)([newLine(1)]);
	const [removed, setRemoved] = (0, import_react.useState)([]);
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const { data: myEmail } = useQuery({
		queryKey: ["my-email"],
		queryFn: async () => (await db.auth.getUser()).data.user?.email ?? ""
	});
	(0, import_react.useEffect)(() => {
		if (!loaded) return;
		const { purchase_order_lines, payments: _p, ...o } = loaded;
		setPo(o);
		setLines([...purchase_order_lines].sort((a, b) => a.line_no - b.line_no));
		setRemoved([]);
		setDirty(false);
	}, [loaded]);
	const { data: footers } = useFooters();
	const logo = useCompanyLogo();
	(0, import_react.useEffect)(() => {
		if (!po.number) return;
		const before = document.title;
		document.title = po.number;
		return () => {
			document.title = before;
		};
	}, [po.number]);
	(0, import_react.useEffect)(() => {
		if (!isNew || !footers || po.footer_id || po.page_footer_id || po.attach_id) return;
		setPo((o) => ({
			...o,
			...defaultsFor(footers, "po")
		}));
	}, [isNew, footers]);
	const { data: vendorItems } = useQuery({
		queryKey: ["vendor-items", po.vendor_id],
		enabled: !!po.vendor_id,
		queryFn: async () => {
			const { data, error } = await db.from("vendor_items").select("product_id,vendor_code,cost").eq("vendor_id", po.vendor_id ?? "");
			if (error) throw error;
			const m = /* @__PURE__ */ new Map();
			(data ?? []).forEach((r) => m.set(r.product_id, {
				code: r.vendor_code,
				cost: Number(r.cost)
			}));
			return m;
		}
	});
	(0, import_react.useEffect)(() => {
		if (isNew && search.vendor && vendors && !po.vendor_id) pickVendor(search.vendor);
	}, [
		isNew,
		search.vendor,
		vendors
	]);
	(0, import_react.useEffect)(() => {
		if (!isNew || !search.product || !products || lines[0]?.product_id) return;
		if (search.vendor && !vendorItems) return;
		pickProduct(0, search.product);
	}, [
		isNew,
		search.product,
		products,
		vendorItems
	]);
	const t = (0, import_react.useMemo)(() => poTotals(lines, Number(po.tax_rate), Number(po.freight)), [
		lines,
		po.tax_rate,
		po.freight
	]);
	const locked = po.status === "cancelled";
	const patch = (p) => {
		setPo((o) => ({
			...o,
			...p
		}));
		setDirty(true);
	};
	const patchLine = (i, p) => {
		setLines((ls) => ls.map((l, j) => j === i ? {
			...l,
			...p
		} : l));
		setDirty(true);
	};
	function pickVendor(vid) {
		const v = vendors?.find((x) => x.id === vid);
		if (!v) return;
		patch({
			vendor_id: v.id,
			vendor_name: v.name,
			contact_name: v.contact_name,
			phone: v.phone,
			vendor_address: v.address,
			payment_terms_id: v.payment_terms_id
		});
	}
	function pickProduct(i, pid, fresh) {
		const p = fresh ?? products?.find((x) => x.id === pid);
		if (!p) return;
		const vi = vendorItems?.get(p.id);
		patchLine(i, {
			product_id: p.id,
			description: p.description ? `${p.name} — ${p.description}` : p.name,
			unit: p.unit,
			unit_cost: vi?.cost ?? Number(p.cost),
			vendor_code: vi?.code ?? null
		});
	}
	/** A scanned item: one more of it, or a new line (the first empty one) the first time. */
	async function scanned(f) {
		if (locked) return;
		const i = lines.findIndex((l) => l.product_id === f.id);
		if (i >= 0) return patchLine(i, { qty: (Number(lines[i].qty) || 0) + 1 });
		let p = products?.find((x) => x.id === f.id);
		if (!p) {
			const { data } = await db.from("products").select("id,name,description,cost,unit,item_type").eq("id", f.id).maybeSingle();
			p = data ?? void 0;
			qc.invalidateQueries({ queryKey: ["products"] });
		}
		if (!p) return;
		const empty = lines.findIndex((l) => !l.product_id && !l.description);
		if (empty >= 0) return pickProduct(empty, p.id, p);
		const at = lines.length;
		setLines((ls) => [...ls, newLine(ls.length + 1)]);
		setTimeout(() => pickProduct(at, p.id, p), 0);
	}
	async function save(extra = {}) {
		if (!po.vendor_name?.trim()) {
			toast.error("Choose a vendor first.");
			return null;
		}
		setBusy(true);
		try {
			const row = {
				...po,
				...extra,
				subtotal: t.subtotal,
				tax: t.tax,
				total: t.total,
				balance: t.total - Number(po.amount_paid || 0)
			};
			delete row.id;
			let oid = po.id;
			if (!oid) {
				const number = await nextNumber("purchase_order");
				const { data: u } = await db.auth.getUser();
				const { data, error } = await db.from("purchase_orders").insert({
					...row,
					number,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				oid = data.id;
			} else {
				const { error } = await db.from("purchase_orders").update(row).eq("id", oid);
				if (error) throw error;
			}
			if (removed.length) {
				const { error } = await db.from("purchase_order_lines").delete().in("id", removed);
				if (error) throw error;
			}
			const rows = lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l, i) => {
				const { _new, ...r } = l;
				return {
					...r,
					purchase_order_id: oid,
					line_no: i + 1,
					line_total: poLineTotal(l)
				};
			});
			if (rows.length) {
				const { error } = await db.from("purchase_order_lines").upsert(rows, { onConflict: "id" });
				if (error) throw error;
			}
			qc.invalidateQueries({ queryKey: ["po", oid] });
			qc.invalidateQueries({ queryKey: ["pos"] });
			qc.invalidateQueries({ queryKey: ["side-list"] });
			setDirty(false);
			if (isNew) navigate({
				to: "/po/$id",
				params: { id: oid },
				search: {},
				replace: true
			});
			return oid;
		} catch (e) {
			toast.error(e.message);
			return null;
		} finally {
			setBusy(false);
		}
	}
	async function change(next, msg) {
		setPo((o) => ({
			...o,
			...next
		}));
		if (await save(next)) toast.success(msg);
	}
	async function copyAsNew() {
		setBusy(true);
		try {
			const number = await nextNumber("purchase_order");
			const { data: u } = await db.auth.getUser();
			const { id: _i, number: _n, ...rest } = po;
			const { data, error } = await db.from("purchase_orders").insert({
				...rest,
				number,
				status: "open",
				order_date: (/* @__PURE__ */ new Date()).toISOString(),
				due_date: null,
				amount_paid: 0,
				balance: t.total,
				subtotal: t.subtotal,
				tax: t.tax,
				total: t.total,
				stock_received_at: null,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const copies = lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l, i) => {
				const { _new, id: _lid, ...r } = l;
				return {
					...r,
					purchase_order_id: data.id,
					line_no: i + 1,
					line_total: poLineTotal(l),
					qty_received: 0
				};
			});
			if (copies.length) {
				const { error: e2 } = await db.from("purchase_order_lines").insert(copies);
				if (e2) throw e2;
			}
			toast.success(`Copied to new purchase order ${number}.`);
			navigate({
				to: "/po/$id",
				params: { id: data.id },
				search: {}
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (!isNew && (isLoading || !loaded)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
			kind: { type: "po" },
			currentId: id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" })] })
		})
	});
	const payments = loaded?.payments ?? [];
	const ps = poPayStatus({
		...po,
		...t,
		balance: t.total - Number(po.amount_paid || 0)
	});
	const is = poInvStatus(po);
	const hasStocked = lines.some((l) => products?.find((p) => p.id === l.product_id)?.item_type === "stocked");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
				kind: { type: "po" },
				currentId: id,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/purchase-orders",
						className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Purchase order list"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
									children: isNew ? "New purchase order" : `Purchase Order ${po.number}`
								}),
								typeof po.custom?.["sales_order_id"] === "string" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/sales/$id",
									params: { id: po.custom["sales_order_id"] },
									search: {},
									className: "rounded bg-muted px-2 py-0.5 text-xs font-medium underline",
									title: "This purchase order was made from that invoice",
									children: ["For ", String(po.custom["sales_order_number"] ?? "invoice")]
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded px-2 py-0.5 text-xs font-medium ${INV_STYLE[is]}`,
									children: is === "Fulfilled" ? "Received" : "Not received"
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded px-2 py-0.5 text-xs font-medium ${PAY_STYLE[ps]}`,
									children: ps
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => window.print(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print or save PDF"]
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void (async () => {
										if (dirty && !await save()) return;
										setDialog("email");
									})(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email vendor"]
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: copyAsNew,
									disabled: busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => void save().then((ok) => ok && toast.success("Saved.")),
									disabled: busy || locked,
									children: busy ? "Saving…" : dirty || isNew ? "Save" : "Saved"
								})
							]
						})]
					}),
					!isNew && !locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 rounded-2xl border bg-card p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "self-center px-1 text-sm font-medium text-muted-foreground",
								children: "Next step:"
							}),
							hasStocked && !po.stock_received_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => setDialog("receive"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackagePlus, { className: "h-4 w-4" }), " Receive items into stock"]
							}),
							ps !== "Paid" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setDialog("payment"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-4 w-4" }), " Pay vendor"]
							}),
							ps === "Paid" && is === "Fulfilled" && po.status !== "completed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => change({ status: "completed" }, "Marked as completed."),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), " Mark as completed"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => change({ status: "cancelled" }, "Cancelled."),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "h-4 w-4" }), " Cancel this order"]
							})
						]
					}),
					locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-2xl border bg-muted p-3 text-sm",
						children: ["This purchase order was cancelled.", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => change({ status: "open" }, "Reopened."),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Reopen"]
						})]
					}),
					po.stock_received_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Items were received into stock on ",
							fmtDate(po.stock_received_at),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 rounded-2xl border bg-card p-4 sm:p-6 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Vendor",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VendorPicker, {
											vendors: vendors ?? [],
											value: po.vendor_id,
											name: po.vendor_name,
											onPick: pickVendor,
											onAdd: async (name) => {
												const id = await addVendor(name);
												await qc.invalidateQueries({ queryKey: ["vendors"] });
												patch({
													vendor_id: id,
													vendor_name: name
												});
												toast.success(`${name} added. Fill in their details later on their page.`);
											},
											disabled: locked
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Contact",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: po.contact_name ?? "",
											onChange: (e) => patch({ contact_name: e.target.value || null })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Phone",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: po.phone ?? "",
											onChange: (e) => patch({ phone: e.target.value || null })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Vendor address",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 3,
											value: po.vendor_address ?? "",
											onChange: (e) => patch({ vendor_address: e.target.value || null })
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Location (where it will arrive)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
											value: po.location_id ?? "none",
											disabled: locked,
											options: [{
												value: "none",
												label: "Not set"
											}, ...(locations ?? []).filter((l) => l.is_active || l.id === po.location_id).map((l) => ({
												value: l.id,
												label: l.name
											}))],
											addLabel: "Add new location",
											onAdd: async (name) => {
												const id = await addLocation(name);
												await qc.invalidateQueries({ queryKey: ["locations"] });
												return id;
											},
											onChange: (v) => patch({ location_id: v === "none" ? null : v })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Vendor order #",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: po.vendor_order_number ?? "",
											onChange: (e) => patch({ vendor_order_number: e.target.value || null })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Terms",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
											value: po.payment_terms_id ?? "none",
											disabled: locked,
											options: [{
												value: "none",
												label: "Not set"
											}, ...(terms ?? []).filter((x) => x.is_active || x.id === po.payment_terms_id).map((x) => ({
												value: x.id,
												label: x.name
											}))],
											addLabel: "Add new terms",
											onAdd: async (name) => {
												const id = await addTerms(name);
												await qc.invalidateQueries({ queryKey: ["payment_terms"] });
												return id;
											},
											onChange: (v) => patch({ payment_terms_id: v === "none" ? null : v })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Carrier",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: po.carrier ?? "",
											onChange: (e) => patch({ carrier: e.target.value || null })
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3 rounded-xl bg-muted/40 p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Order #",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: po.number ?? "(given when saved)",
												disabled: true
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: po.order_date.slice(0, 10),
												onChange: (e) => patch({ order_date: (/* @__PURE__ */ new Date(e.target.value + "T12:00:00")).toISOString() })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Due date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: (po.due_date ?? "").slice(0, 10),
												onChange: (e) => patch({ due_date: e.target.value ? (/* @__PURE__ */ new Date(e.target.value + "T12:00:00")).toISOString() : null })
											})
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Ship to" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "text-xs underline",
											style: { color: "var(--section)" },
											onClick: () => patch({ ship_to_address: [company?.name, company?.address].filter(Boolean).join("\n") }),
											children: "Use our address"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										rows: 3,
										value: po.ship_to_address ?? "",
										onChange: (e) => patch({ ship_to_address: e.target.value || null })
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl border bg-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden grid-cols-[minmax(0,1fr)_150px_90px_120px_90px_110px_40px] gap-2 border-b bg-muted/40 px-4 py-2 text-xs font-semibold text-muted-foreground md:grid",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Item" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Vendor product code" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Qty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Unit price"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Disc. %"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Sub-total"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								]
							}),
							lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 border-b px-4 py-3 md:grid-cols-[minmax(0,1fr)_150px_90px_120px_90px_110px_40px] md:items-start",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2 space-y-1.5 md:col-span-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductPicker, {
											products: products ?? [],
											value: l.product_id,
											onPick: (pid, fresh) => pickProduct(i, pid, fresh),
											disabled: locked
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 1,
											className: "min-h-9 text-sm",
											placeholder: "Description",
											value: l.description ?? "",
											onChange: (e) => patchLine(i, { description: e.target.value })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-9",
										placeholder: "Code",
										value: l.vendor_code ?? "",
										onChange: (e) => patchLine(i, { vendor_code: e.target.value || null })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
										value: l.qty,
										onChange: (v) => patchLine(i, { qty: v }),
										label: "Qty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
										value: l.unit_cost,
										onChange: (v) => patchLine(i, { unit_cost: v }),
										label: "Unit price"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
										value: l.discount,
										onChange: (v) => patchLine(i, {
											discount: v,
											discount_is_percent: true
										}),
										label: "Disc. %"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "self-center text-right font-semibold md:pt-2",
										children: fmtMoney(poLineTotal(l))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": "Remove line",
										onClick: () => {
											if (!l._new) setRemoved((r) => [...r, l.id]);
											setLines((ls) => ls.filter((_, j) => j !== i));
											setDirty(true);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									})
								]
							}, l.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										size: "sm",
										disabled: locked,
										onClick: () => {
											setLines((ls) => [...ls, newLine(ls.length + 1)]);
											setDirty(true);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
									}),
									" ",
									!locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanAddButton, {
										onProduct: (p) => void scanned(p),
										hint: "Scan each item to order. Each scan adds one."
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border bg-card p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Remarks",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 4,
									value: po.remarks ?? "",
									onChange: (e) => patch({ remarks: e.target.value || null })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterPicker, {
									footers: footers ?? [],
									doc: po,
									onChange: patch
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Sub-total",
									value: fmtMoney(t.subtotal)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: taxes?.find((x) => x.name === po.tax_name && Number(x.rate) === Number(po.tax_rate))?.id ?? "none",
										onValueChange: (v) => {
											const x = taxes?.find((y) => y.id === v);
											patch(x ? {
												tax_name: x.name,
												tax_rate: Number(x.rate)
											} : {
												tax_name: null,
												tax_rate: 0
											});
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 w-auto max-w-[220px]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "none",
											children: "No tax"
										}), (taxes ?? []).filter((x) => x.is_active).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
											value: x.id,
											children: [
												x.name,
												" (",
												Number(x.rate),
												"%)"
											]
										}, x.id))] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fmtMoney(t.tax) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Freight / other costs" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-28 text-right",
										inputMode: "decimal",
										value: po.freight,
										onChange: (e) => patch({ freight: Number(e.target.value) || 0 })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border-t pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Total",
										value: fmtMoney(t.total),
										big: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Paid",
									value: fmtMoney(po.amount_paid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Balance",
									value: fmtMoney(t.total - Number(po.amount_paid || 0)),
									big: true
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							onClick: () => void save().then((ok) => ok && toast.success("Saved.")),
							disabled: busy || locked,
							children: busy ? "Saving…" : dirty || isNew ? "Save" : "Saved"
						})
					}),
					payments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl border bg-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-b px-4 py-2 text-sm font-semibold",
							children: "Payments to vendor"
						}), [...payments].sort((a, b) => a.paid_on.localeCompare(b.paid_on)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-28",
									children: fmtDate(p.paid_on)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 truncate text-muted-foreground",
									children: [
										p.method,
										p.reference,
										p.remarks
									].filter(Boolean).join(" · ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: fmtMoney(p.amount)
								}),
								isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Remove payment",
									onClick: async () => {
										const { error } = await db.from("payments").delete().eq("id", p.id);
										if (error) toast.error(error.message);
										else {
											toast.success("Payment removed.");
											qc.invalidateQueries({ queryKey: ["po", id] });
										}
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							]
						}, p.id))]
					})
				] })
			})
		}),
		!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrintFrame, {
			pageFooter: po.page_footer_text,
			attach: po.attach_text,
			logo,
			company: company?.name ?? "",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						logo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo,
							alt: company?.name ?? "",
							className: "mb-2 h-14 object-contain"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-bold uppercase tracking-wide text-gray-500",
							children: "Mailing address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-bold",
							children: company?.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-line",
							children: company?.address
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: [company?.phone, company?.email].filter(Boolean).join(" · ") })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl font-bold uppercase",
								children: "Purchase Order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "No." }),
								" ",
								po.number
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Date" }),
								" ",
								fmtDate(po.order_date)
							] }),
							po.due_date && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Due" }),
								" ",
								fmtDate(po.due_date)
							] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-2 gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 font-bold uppercase text-gray-500",
							children: "Vendor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: po.vendor_name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "whitespace-pre-line",
							children: po.vendor_address
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-bold uppercase text-gray-500",
						children: "Ship to"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-line",
						children: po.ship_to_address
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "mt-6 w-full border-collapse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b-2 border-black text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Vendor code" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Qty"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Unit price"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Total"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b align-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-pre-line py-1.5 pr-2",
								children: l.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: l.vendor_code }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: fmtQty(l.qty)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: fmtMoney(l.unit_cost)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: fmtMoney(poLineTotal(l))
							})
						]
					}, l.id)) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-between gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[55%] whitespace-pre-line",
						children: po.remarks
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-64 space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Sub-total",
								value: fmtMoney(t.subtotal)
							}),
							t.tax !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: po.tax_name ?? "Tax",
								value: fmtMoney(t.tax)
							}),
							Number(po.freight) !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Freight",
								value: fmtMoney(po.freight)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "border-t border-black pt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Total",
									value: fmtMoney(t.total),
									big: true
								})
							})
						]
					})]
				}),
				po.footer_text && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 whitespace-pre-line border-t pt-3 text-[11px] text-gray-600",
					children: po.footer_text
				})
			]
		}),
		dialog === "email" && po.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailDocDialog, {
			doc: () => ({
				title: "PURCHASE ORDER",
				logo: logo ? new URL(logo, window.location.href).href : "",
				company: {
					name: company?.name ?? "",
					address: company?.address ?? null,
					addressLabel: "MAILING ADDRESS",
					phone: company?.phone ?? null,
					email: company?.email ?? null,
					website: company?.website ?? null
				},
				facts: [
					["No.", po.number ?? ""],
					["Date", fmtDate(po.order_date)],
					...po.vendor_order_number ? [["Your order #", po.vendor_order_number]] : [],
					...po.due_date ? [["Needed by", fmtDate(po.due_date)]] : []
				],
				leftTitle: "VENDOR",
				left: [po.vendor_name, po.vendor_address].filter(Boolean).join("\n"),
				rightTitle: "SHIP TO",
				right: po.ship_to_address ?? "",
				lines: lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l) => ({
					desc: `${l.description ?? ""}${l.vendor_code ? `\nYour code: ${l.vendor_code}` : ""}`,
					qty: fmtQty(l.qty),
					price: fmtMoney(l.unit_cost),
					disc: Number(l.discount) ? `${Number(l.discount)}%` : "",
					total: fmtMoney(poLineTotal(l))
				})),
				remarks: po.remarks,
				totals: [
					{
						label: "Sub-total",
						value: fmtMoney(t.subtotal)
					},
					...t.tax !== 0 ? [{
						label: po.tax_name ?? "Tax",
						value: fmtMoney(t.tax)
					}] : [],
					...Number(po.freight) !== 0 ? [{
						label: "Freight",
						value: fmtMoney(po.freight)
					}] : [],
					{
						label: "Total",
						value: fmtMoney(t.total),
						big: true
					}
				],
				endFooter: po.footer_text,
				pageFooter: po.page_footer_text,
				attach: po.attach_text
			}),
			filename: `${po.number ?? "purchase-order"}.pdf`,
			to: vendors?.find((v) => v.id === po.vendor_id)?.email ?? "",
			myEmail: myEmail || void 0,
			subject: `Purchase Order ${po.number ?? ""} from ${company?.name ?? ""}`,
			message: `Hello ${po.contact_name || po.vendor_name || ""},\n\nPlease find attached our purchase order ${po.number ?? ""}. Please confirm the order and the ship date.\n\nThank you,\n${company?.name ?? ""}`,
			onClose: () => setDialog(null)
		}),
		dialog === "receive" && po.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiveDialog, {
			poId: po.id,
			defaultLocation: po.location_id,
			items: lines.filter((l) => l.product_id).map((l) => ({
				id: l.product_id,
				name: l.description ?? "",
				qty: Number(l.qty) || 0
			})),
			beforeReceive: async () => dirty ? !!await save() : true,
			onClose: () => setDialog(null),
			onDone: () => {
				qc.invalidateQueries({ queryKey: ["po", id] });
				qc.invalidateQueries({ queryKey: ["products"] });
				qc.invalidateQueries({ queryKey: ["pos"] });
			}
		}),
		dialog === "payment" && po.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayVendorDialog, {
			poId: po.id,
			balance: t.total - Number(po.amount_paid || 0),
			onClose: () => setDialog(null),
			onSaved: () => {
				qc.invalidateQueries({ queryKey: ["po", id] });
				qc.invalidateQueries({ queryKey: ["pos"] });
			}
		})
	] });
}
function Row({ label, value, big }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between ${big ? "font-display text-lg font-bold" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value })]
	});
}
function Num({ value, onChange, label }) {
	const [s, setS] = (0, import_react.useState)(String(value ?? ""));
	(0, import_react.useEffect)(() => {
		if (Number(s) !== Number(value)) setS(String(value ?? ""));
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground md:hidden",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "h-9 text-right",
			inputMode: "decimal",
			value: s,
			onChange: (e) => {
				setS(e.target.value);
				const n = Number(e.target.value);
				if (Number.isFinite(n)) onChange(n);
			}
		})]
	});
}
function VendorPicker({ vendors, value, name, onPick, onAdd, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [newName, setNewName] = (0, import_react.useState)("");
	const [adding, setAdding] = (0, import_react.useState)(false);
	async function add() {
		const n = (newName || typed).trim();
		if (!n || !onAdd) return;
		setAdding(true);
		try {
			await onAdd(n);
			setOpen(false);
			setTyped("");
			setNewName("");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setAdding(false);
		}
	}
	const list = vendors.filter((v) => v.is_active || v.id === value).sort((a, b) => a.name.localeCompare(b.name));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "w-full justify-between font-normal",
				disabled,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: name || "Choose a vendor"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[min(420px,90vw)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
					placeholder: "Type a vendor name",
					value: typed,
					onValueChange: (v) => {
						setTyped(v);
						setNewName(v);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No vendor found. Add it below." }), list.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: `${v.name} ${v.id}`,
					onSelect: () => {
						onPick(v.id);
						setOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: `h-4 w-4 ${v.id === value ? "opacity-100" : "opacity-0"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: v.name
					})]
				}, v.id))] }),
				onAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 border-t p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs font-semibold text-muted-foreground",
							children: "Add new vendor:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "h-8",
							placeholder: "Name",
							value: newName,
							onChange: (e) => setNewName(e.target.value),
							onKeyDown: (e) => {
								e.stopPropagation();
								if (e.key === "Enter") {
									e.preventDefault();
									add();
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							disabled: adding || !(newName || typed).trim(),
							onClick: () => void add(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
						})
					]
				})
			] })
		})]
	});
}
function ProductPicker({ products, value, onPick, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [adding, setAdding] = (0, import_react.useState)(null);
	const current = products.find((p) => p.id === value);
	const sorted = (0, import_react.useMemo)(() => [...products].sort((a, b) => a.name.localeCompare(b.name)), [products]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [adding != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewProductDialog, {
		name: adding,
		onClose: () => setAdding(null),
		onCreated: (p) => {
			setAdding(null);
			onPick(p.id, p);
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "w-full justify-between font-normal",
				disabled,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: current?.name ?? "Choose a product (or just type a description)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[min(520px,90vw)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				shouldFilter: false,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
						placeholder: "Type to search products",
						value: q,
						onValueChange: setQ
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No product found." }), smartSearch(sorted, q, (p) => p.name, (p) => p.description ?? "").slice(0, 200).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						value: `${p.name} ${p.description ?? ""} ${p.id}`,
						onSelect: () => {
							onPick(p.id);
							setOpen(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 truncate",
							children: p.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground",
							children: ["cost ", fmtMoney(p.cost)]
						})]
					}, p.id))] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "w-full justify-start",
							onClick: () => {
								setAdding(q.trim());
								setOpen(false);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }),
								" Add new product",
								q.trim() ? ` “${q.trim()}”` : ""
							]
						})
					})
				]
			})
		})]
	})] });
}
function ReceiveDialog({ poId, defaultLocation, items, beforeReceive, onClose, onDone }) {
	const { data: locations } = useLocations();
	const [loc, setLoc] = (0, import_react.useState)(defaultLocation ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [got, setGot] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const checking = got.size > 0;
	const short = items.filter((i) => (got.get(i.id) ?? 0) < i.qty);
	async function go() {
		if (!loc) {
			toast.error("Choose where the items go.");
			return;
		}
		if (checking && short.length && !window.confirm(`${short.length} item${short.length === 1 ? " wasn't" : "s weren't"} all scanned. Receive the whole order anyway?`)) return;
		setBusy(true);
		if (!await beforeReceive()) {
			setBusy(false);
			return;
		}
		const { error } = await db.rpc("receive_po_stock", {
			_po_id: poId,
			_location_id: loc
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Items received into stock.");
		onDone();
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Receive items into stock" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Every stocked item on this purchase order will be added to the place you choose. This happens once." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: loc,
				onValueChange: setLoc,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Put items in…" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (locations ?? []).filter((l) => l.is_active).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: l.id,
					children: l.name
				}, l.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanAddButton, {
					label: "Check the items with the scanner",
					hint: "Scan each item as you unpack it. Tallkeep checks it against the order.",
					onProduct: (p) => {
						if (!items.some((i) => i.id === p.id)) return void toast.error(`${p.name} isn't on this order.`);
						setGot((m) => new Map(m).set(p.id, (m.get(p.id) ?? 0) + 1));
					}
				}), checking && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y rounded-xl border text-sm",
					children: items.map((i) => {
						const n = got.get(i.id) ?? 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 px-3 py-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 truncate",
								children: i.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: n === i.qty ? "font-medium text-emerald-700" : n > i.qty ? "font-medium text-amber-700" : "text-muted-foreground",
								children: [
									n,
									" of ",
									i.qty
								]
							})]
						}, i.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: go,
				disabled: busy,
				children: busy ? "Working…" : "Receive into stock"
			})] })
		] })
	});
}
function PayVendorDialog({ poId, balance, onClose, onSaved }) {
	const [amount, setAmount] = (0, import_react.useState)(balance > 0 ? balance.toFixed(2) : "");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const [method, setMethod] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [accountId, setAccountId] = (0, import_react.useState)("");
	async function save() {
		const n = Number(amount);
		if (!n) {
			toast.error("Type the amount.");
			return;
		}
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const { error } = await db.from("payments").insert({
			purchase_order_id: poId,
			amount: n,
			paid_on: (/* @__PURE__ */ new Date(date + "T12:00:00")).toISOString(),
			method: method || null,
			reference: ref || null,
			...accountId ? { account_id: accountId } : {},
			created_by: u.user?.id
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Payment to vendor recorded.");
		onSaved();
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Pay vendor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"We still owe: ",
				fmtMoney(balance),
				"."
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How we paid" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								list: "po-pay-methods",
								value: method,
								onChange: (e) => setMethod(e.target.value),
								placeholder: "Wire, check, card…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "po-pay-methods",
								children: [
									"Wire transfer",
									"Check",
									"Credit card",
									"ACH",
									"PayPal"
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: m }, m))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Reference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyAccountPick, {
						label: "Paid from",
						value: accountId,
						onChange: setAccountId,
						cards: true
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				disabled: busy,
				children: busy ? "Saving…" : "Save payment"
			})] })
		] })
	});
}
//#endregion
export { POPage as component };
