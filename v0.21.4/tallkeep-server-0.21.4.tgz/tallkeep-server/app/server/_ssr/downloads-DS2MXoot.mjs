import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as listDownloads } from "./downloads.functions-B7MZ-YfH.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/downloads-DS2MXoot.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLATFORM = {
	windows: "Windows",
	linux: "Synology / Linux",
	mac: "Mac (wants to know)"
};
function DownloadsPage() {
	const q = useQuery({
		queryKey: ["admin-downloads"],
		queryFn: () => listDownloads()
	});
	const [find, setFind] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("all");
	const all = q.data?.rows ?? [];
	const f = find.trim().toLowerCase();
	const rows = all.filter((r) => kind === "all" || r.platform === kind).filter((r) => !f || `${r.name} ${r.email} ${r.business ?? ""}`.toLowerCase().includes(f));
	const since = (days) => all.filter((r) => r.platform !== "mac" && Date.parse(r.created_at) > Date.now() - days * 864e5).length;
	const i = q.data?.installs;
	const download = () => {
		const esc = (v) => `"${(v ?? "").replace(/"/g, "\"\"")}"`;
		const csv = ["Date,Name,Email,What for,Version,Bought", ...rows.map((r) => [
			r.created_at,
			r.name,
			r.email,
			r.business ?? "",
			PLATFORM[r.platform] ?? r.platform,
			r.bought ? "yes" : ""
		].map(esc).join(","))].join("\n");
		const a = document.createElement("a");
		a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
		a.download = "tallkeep-downloads.csv";
		a.click();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Downloads",
		text: "Who downloaded Tallkeep, and how many computers run it.",
		actions: rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: download,
			className: "text-sm font-semibold text-primary underline",
			children: "Download this list (Excel)"
		})
	}), q.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-32" }) : !q.data?.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6 text-muted-foreground",
		children: "Run database step 49 (docs/db/049_downloads.sql) and downloads show here."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-2 gap-3 lg:grid-cols-5",
			children: [
				["Downloads today", since(1)],
				["Last 7 days", since(7)],
				["Last 30 days", since(30)],
				["Computers running it (7 days)", i?.activeWeek ?? 0],
				["Of those, licensed", i?.licensedActive ?? 0]
			].map(([label, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-2xl font-semibold",
					children: n
				})]
			}, String(label)))
		}),
		i && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				"Running this week: ",
				i.windows,
				" on Windows, ",
				i.linux,
				" on Synology/Linux ·",
				" ",
				i.trialActive,
				" on the free trial · ",
				i.total,
				" computers ever."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 border-b p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1 rounded-lg bg-muted p-1 text-sm",
					children: [
						"all",
						"windows",
						"linux",
						"mac"
					].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setKind(k),
						className: cn("rounded-md px-3 py-1", kind === k && "bg-card font-semibold shadow-sm"),
						children: [
							k === "all" ? "All" : PLATFORM[k],
							" (",
							k === "all" ? all.length : all.filter((r) => r.platform === k).length,
							")"
						]
					}, k))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: find,
					onChange: (e) => setFind(e.target.value),
					placeholder: "Find a name or email",
					className: "w-64"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Email"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "What for"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Version"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Bought"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "whitespace-nowrap p-3",
								children: fmtDateTime(r.created_at)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: r.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${r.email}`,
									className: "text-primary underline",
									children: r.email
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: r.business ?? ""
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: PLATFORM[r.platform] ?? r.platform
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: r.bought && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-emerald-100 px-2 py-0.5 text-xs text-emerald-900",
									children: "Bought"
								})
							})
						]
					}, r.id)), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "p-6 text-center text-muted-foreground",
						children: "No downloads yet."
					}) })] })]
				})
			})]
		})
	] })] });
}
//#endregion
export { DownloadsPage as component };
