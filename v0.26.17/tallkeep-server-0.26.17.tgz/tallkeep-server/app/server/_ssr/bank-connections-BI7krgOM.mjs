import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as BankConnections } from "./BankConnections-Mrr9GKQ6.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bank-connections-BI7krgOM.js
var import_jsx_runtime = require_jsx_runtime();
function BankConnectionsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Bank Connections",
			text: "Connect your bank and credit cards once. New lines come in every morning, ready to check in Review & Reconcile."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BankConnections, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				"New lines wait in",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/banking",
					className: "font-medium text-primary underline",
					children: "Review & Reconcile → For review"
				}),
				", the same as lines from a statement file."
			]
		})
	] });
}
//#endregion
export { BankConnectionsPage as component };
