//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D9_8AhEQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-CTbC5mnd.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-kTezmV_t.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BmMhVeAV.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CTbC5mnd.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-CRqscw_c.js",
			"/assets/log-out-BMaBmvSP.js",
			"/assets/testers.functions-D-3NIPSK.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Cu4sefIR.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-tcxw4-h5.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-CkT_nZBJ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/dist-BlVMjXBA.js",
			"/assets/dialog-BGJXxfbK.js",
			"/assets/queries-B_LkDF_B.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/label-1ist3nmM.js",
			"/assets/textarea-DGBs_2hE.js",
			"/assets/shoebox-Dl4Hlq9u.js",
			"/assets/company-BXfYjhNm.js",
			"/assets/reports-CyA40PPR.js",
			"/assets/access-Dl1XIyA7.js",
			"/assets/LicenseCard-B7QVYQ5j.js",
			"/assets/Logo-DKgT15Pw.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-B7M6hHWj.js",
			"/assets/log-out-BMaBmvSP.js",
			"/assets/admin.functions-B9oFKFyB.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-DKgT15Pw.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-D5idI9CI.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/label-1ist3nmM.js",
			"/assets/Logo-DKgT15Pw.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-XDr0wwtO.js",
			"/assets/testers.functions-D-3NIPSK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/buy.functions-CO0dF0zx.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-BfXqlMlg.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/downloads.functions-BvdUA91W.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-Cr5m49iV.js",
			"/assets/testers.functions-D-3NIPSK.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/textarea-DGBs_2hE.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BJDYHapE.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/label-1ist3nmM.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-CDBB3NQB.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/label-1ist3nmM.js",
			"/assets/Logo-DKgT15Pw.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BWPsLwNn.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/upgrade.functions-B0NLUd3M.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-POQCHeZV.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/label-1ist3nmM.js",
			"/assets/Logo-DKgT15Pw.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CWjrqqHj.js",
			"/assets/select-C9YkhATD.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-njhNrgTA.js", "/assets/StockDocList-BEsYamj2.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-7Q_h1-e9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/ai-DzM7TRXp.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-BLHCKxlc.js",
			"/assets/BankConnections-D6xxx1On.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-DAQudg1o.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BYrHtyHs.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-D6xxx1On.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/ai-DzM7TRXp.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-bax2GEjN.js",
			"/assets/TxnEditor-BeYgQLCq.js",
			"/assets/feedWaiting-o6cEpth_.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-B7DA4x6x.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-C3tXHRXH.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/personal-MW7Jzxg7.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/WhoPicker-DMxnlCRF.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-bYxFlMt2.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BvbXaPdI.js", "/assets/AccountRegister-DeEQLdeM.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-91TZLhPP.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-BapjJhes.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/money-CtW8UOUY.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-txLMKqeg.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DzM7TRXp.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-Du3vgtUP.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Cz4PCyRV.js", "/assets/StockDocList-BEsYamj2.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DqicPd8A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-Cnxa5MLc.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-Bx8-v0fp.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-B_b27mT5.js", "/assets/PartyList-yuD9Vsin.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-BPDDW5WO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-Br89-BFL.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/storage.functions-BL5FGitJ.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BS60rRzr.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-Dx94tj0R.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-m8xkaJEm.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BgfxaB1W.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-5AQCzc0P.js", "/assets/ChangeHistory-CuP4HVxh.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-_ia6_S7K.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/members-JpXSdbCC.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-D6tI-zeO.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/personal-MW7Jzxg7.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/WhoPicker-DMxnlCRF.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-ALU8TStI.js", "/assets/SalesList-BAFxvlJo.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-BZvoGDm8.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BwytZwiV.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BXxnR11l.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CkYXsIrN.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/loans-bax2GEjN.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-BpF8uoaO.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-CFzEHWR6.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CFBhFB9l.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/personal-MW7Jzxg7.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/WhoPicker-DMxnlCRF.js",
			"/assets/reminders-CnSHEMdo.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BlokHwUm.js",
			"/assets/select-C9YkhATD.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DIrsbeR3.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/personal-MW7Jzxg7.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/WhoPicker-DMxnlCRF.js",
			"/assets/generateCategoricalChart-DmclHr45.js",
			"/assets/Area-CTVy4HLF.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-IxwvJ69h.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/generateCategoricalChart-DmclHr45.js",
			"/assets/PlCharts-m8xkaJEm.js",
			"/assets/BarChart-Bbh18nHR.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-v72Gh9Op.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BHCDAwm4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CtPFgAEv.js",
			"/assets/createServerFn-DQCYk2tW.js",
			"/assets/auth-middleware-Q4LEgqcu.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/storage.functions-BL5FGitJ.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-BGItiYca.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-s8FNdtUY.js",
			"/assets/select-C9YkhATD.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/checkbox-dj0oeW1S.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-K5dsIisy.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CtyGEqAw.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-C9YkhATD.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-BreeF9pI.js", "/assets/SalesList-BAFxvlJo.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-CMaFp7jK.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/ai-DzM7TRXp.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BL5FGitJ.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-dYZipp-q.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/money-CtW8UOUY.js",
			"/assets/badge-Br9XnQLU.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DSpLuPKf.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-g_94WbCm.js", "/assets/AccountRegister-DeEQLdeM.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-CKCTBR82.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/MoneyAccountPick-BiIgdULB.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DIByu1_4.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DYexmCUb.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/RepeatInvoice-DiDyx0oR.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CILDpM8f.js",
			"/assets/select-C9YkhATD.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DmclHr45.js",
			"/assets/BarChart-Bbh18nHR.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-Cvor42r2.js", "/assets/SalesList-BAFxvlJo.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-BvFDHVtR.js", "/assets/SalesList-BAFxvlJo.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-BfEguI2f.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials--rt7x0Pm.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/serials-Bnpp238D.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-Db01hK1b.js",
			"/assets/createServerFn-DQCYk2tW.js",
			"/assets/auth-middleware-Q4LEgqcu.js",
			"/assets/select-C9YkhATD.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-B5RcKUZI.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DnqqXbpj.js",
			"/assets/switch-CFzEHWR6.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-Bx8-v0fp.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-CGp9tNfx.js",
			"/assets/footers-nkJOnXTq.js",
			"/assets/PrintFrame-DrdaRK-0.js",
			"/assets/checkbox-dj0oeW1S.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-C8KyXITG.js",
			"/assets/FeaturePicker-Bl9Rq8pg.js",
			"/assets/support-CQNnJp0o.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-BchxfKB6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/FeaturePicker-Bl9Rq8pg.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-DOeN0KWp.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ZL8D3AkM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/photos-CGp9tNfx.js",
			"/assets/stockmove-CWFx0IA4.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-C_cqS3zy.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/loans-bax2GEjN.js",
			"/assets/feedWaiting-o6cEpth_.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-BL5FGitJ.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-MwHmXXzI.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/PrintFrame-DrdaRK-0.js",
			"/assets/DocPdf-DWrrCv3j.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-CPfVtmfR.js",
			"/assets/createServerFn-DQCYk2tW.js",
			"/assets/auth-middleware-Q4LEgqcu.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/MoneyAccountPick-BiIgdULB.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CQNnJp0o.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-CjCQWkoc.js",
			"/assets/select-C9YkhATD.js",
			"/assets/StockDialogs-ZL8D3AkM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/stockmove-CWFx0IA4.js",
			"/assets/checkbox-dj0oeW1S.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-MWrFuVFo.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/members-JpXSdbCC.js",
			"/assets/WhoPicker-DMxnlCRF.js",
			"/assets/reminders-CnSHEMdo.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-CnjdFn3b.js",
			"/assets/select-C9YkhATD.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/tickets.functions-C2Ub1X3l.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DMmJ6L8x.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CQNnJp0o.js",
			"/assets/support.functions-DqCmMOtH.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-l3Wrv5qE.js", "/assets/StockDocList-BEsYamj2.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CLOB7092.js", "/assets/PartyList-yuD9Vsin.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BGoJQQVS.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/tickets.functions-C2Ub1X3l.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DOAbXq_A.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/workorders-XjIl2FGV.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-BMQ5YPLM.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-CcumuJ8k.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/AdminAccount-CB9R2Z3p.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BP9dIGfP.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/downloads.functions-BvdUA91W.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-CNIViXk1.js",
			"/assets/createServerFn-DQCYk2tW.js",
			"/assets/auth-middleware-Q4LEgqcu.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DC8d-I28.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BUZ1dT4S.js",
			"/assets/testers.functions-D-3NIPSK.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-jjfdQDN5.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-CvCFNIUy.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CO0dF0zx.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-1jmD0J6-.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/textarea-DGBs_2hE.js",
			"/assets/support.functions-DqCmMOtH.js",
			"/assets/HelpParts-CYrL3txG.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BXR3B57A.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-C75WHmLg.js",
			"/assets/manual._slug-DyrUHr80.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-CAV2rdPm.js",
			"/assets/createServerFn-DQCYk2tW.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-BwsvmG3j.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-B0NLUd3M.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-DdyeR7bI.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DzM7TRXp.js",
			"/assets/personal-MW7Jzxg7.js",
			"/assets/reminders-CnSHEMdo.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CKfuLrX8.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/AdminAccount-CB9R2Z3p.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-CVw-ybuT.js", "/assets/ManualFrame-C75WHmLg.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D8TQsW4F.js", "/assets/AccountRegister-DeEQLdeM.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-Cq_YPTGr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/OriginalLink-BUhK6Fbe.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/realestate-DzJQAx03.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-3FFxvMEr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-kH0sRe8y.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/realestate-DzJQAx03.js",
			"/assets/money-CtW8UOUY.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-wgQR_xzu.js",
			"/assets/select-C9YkhATD.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/SideList-CqSJofO2.js",
			"/assets/PartyHistory-h1O-wEEB.js",
			"/assets/tabs-EsUComxU.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-C7QqTb21.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C9YkhATD.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-B5RcKUZI.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CuP4HVxh.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/SideList-CqSJofO2.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-U0Exc1rG.js",
			"/assets/MoneyAccountPick-BiIgdULB.js",
			"/assets/footers-nkJOnXTq.js",
			"/assets/PrintFrame-DrdaRK-0.js",
			"/assets/serials-Bnpp238D.js",
			"/assets/SerialsBox-DHYAXQO8.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-B7CR4uDS.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-C9YkhATD.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ZL8D3AkM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CuP4HVxh.js",
			"/assets/switch-CFzEHWR6.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/badge-Br9XnQLU.js",
			"/assets/SideList-CqSJofO2.js",
			"/assets/tabs-EsUComxU.js",
			"/assets/photos-CGp9tNfx.js",
			"/assets/stockmove-CWFx0IA4.js",
			"/assets/serials-Bnpp238D.js",
			"/assets/SerialsBox-DHYAXQO8.js",
			"/assets/workorders-XjIl2FGV.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-9t5D--VZ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-C9YkhATD.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-B5RcKUZI.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-CuP4HVxh.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/SideList-CqSJofO2.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-U0Exc1rG.js",
			"/assets/MoneyAccountPick-BiIgdULB.js",
			"/assets/footers-nkJOnXTq.js",
			"/assets/PrintFrame-DrdaRK-0.js",
			"/assets/checkbox-dj0oeW1S.js",
			"/assets/serials-Bnpp238D.js",
			"/assets/workorders-XjIl2FGV.js",
			"/assets/RepeatInvoice-DiDyx0oR.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-C2Ub1X3l.js",
			"/assets/users.functions-C8KyXITG.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DmGlqJZ9.js",
			"/assets/select-C9YkhATD.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/SideList-CqSJofO2.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-Wf__l8Hm.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/quickadd-CI5OPZjo.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-CQNnJp0o.js",
			"/assets/support.functions-DqCmMOtH.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-Cw0KYWK6.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-iHC19Fae.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/SideList-CqSJofO2.js",
			"/assets/PartyHistory-h1O-wEEB.js",
			"/assets/tabs-EsUComxU.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C8phIqha.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/sales-Du3vgtUP.js",
			"/assets/footers-nkJOnXTq.js",
			"/assets/tickets.functions-C2Ub1X3l.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DXOZs4Pn.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/input-C4k4HHnN.js",
			"/assets/skeleton-MudWINPY.js",
			"/assets/AdminAccount-CB9R2Z3p.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-NFKAKwfk.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-j-DG5RM5.js",
			"/assets/textarea-DGBs_2hE.js",
			"/assets/support-CQNnJp0o.js",
			"/assets/support.functions-DqCmMOtH.js",
			"/assets/HelpParts-CYrL3txG.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-BYo-Lk4U.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-MudWINPY.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
