import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { t as activeCompanyId } from "./company-Bw8OfDgk.mjs";
import { E as Send, Ft as FileText, G as Paperclip, Nn as ArrowLeft, lt as LoaderCircle, n as X, qt as Copy, u as UserPlus, y as StickyNote } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-Yp0ZfJ76.mjs";
import { o as useAddCustomer } from "./quickadd-CPmfd8Bg.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { o as staffReply, r as listSupportStaff, s as supportEmailReady } from "./support.functions-Byionxwq.mjs";
import { a as fileSize, c as publicOrigin, n as TICKET_STATUS, r as TICKET_STATUSES, t as PRIORITY } from "./support-Bri7jlNl.mjs";
import { t as Route } from "./tickets_._id-xBo0KlBR.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets_._id-DE3YalZ8.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var when = (iso) => new Date(iso).toLocaleString([], {
	dateStyle: "medium",
	timeStyle: "short"
});
function useCustomers() {
	return useQuery({
		queryKey: ["customers", "support"],
		queryFn: () => fetchAll("customers", "id,name,email,phone,contact_name")
	});
}
function TicketPage() {
	const { id } = Route.useParams();
	return id === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewTicket, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenTicket, { id });
}
function NewTicket() {
	const addCustomerNow = useAddCustomer();
	const navigate = useNavigate();
	const { data: customers } = useCustomers();
	const [f, setF] = (0, import_react.useState)({
		customer_id: "",
		name: "",
		email: "",
		phone: "",
		subject: "",
		message: "",
		source: "phone"
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const pick = (cid) => {
		const c = customers?.find((x) => x.id === cid);
		setF((x) => ({
			...x,
			customer_id: cid ?? "",
			name: c?.contact_name || c?.name || x.name,
			email: c?.email || x.email,
			phone: c?.phone || x.phone
		}));
	};
	async function save(e) {
		e.preventDefault();
		if (!f.subject.trim()) return void toast.error("Type what it's about.");
		setBusy(true);
		try {
			const c = customers?.find((x) => x.id === f.customer_id);
			const { data: u } = await db.auth.getUser();
			const { data, error } = await db.from("tickets").insert({
				subject: f.subject.trim(),
				customer_id: f.customer_id || null,
				name: f.name.trim() || null,
				company_name: c?.name ?? null,
				email: f.email.trim() || null,
				phone: f.phone.trim() || null,
				source: f.source,
				status: "open",
				created_by: u.user?.id,
				assigned_to: u.user?.id
			}).select("id").single();
			if (error) throw error;
			if (f.message.trim()) {
				const m = await db.from("ticket_messages").insert({
					ticket_id: data.id,
					kind: "customer",
					author_name: f.name.trim() || c?.name || "Customer",
					body: f.message.trim()
				});
				if (m.error) throw m.error;
			}
			toast.success("Ticket opened.");
			navigate({
				to: "/tickets/$id",
				params: { id: data.id },
				replace: true
			});
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/tickets",
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Tickets"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold",
			children: "New ticket"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: save,
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Customer"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: f.customer_id || null,
						options: (customers ?? []).map((c) => ({
							value: c.id,
							label: c.name,
							hint: c.email ?? ""
						})),
						onChange: pick,
						placeholder: "Choose a customer (or type the details below)",
						onAdd: addCustomerNow,
						addLabel: "Add new customer"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Contact name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.name,
						onChange: (e) => setF({
							...f,
							name: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Email (replies go here)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						value: f.email,
						onChange: (e) => setF({
							...f,
							email: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Phone"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.phone,
						onChange: (e) => setF({
							...f,
							phone: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "How they reached us"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: f.source,
						onChange: (e) => setF({
							...f,
							source: e.target.value
						}),
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "phone",
								children: "Phone call"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "email",
								children: "Email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "staff",
								children: "In person / other"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "Subject"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: f.subject,
						onChange: (e) => setF({
							...f,
							subject: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "What they told us"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 5,
						value: f.message,
						onChange: (e) => setF({
							...f,
							message: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Opening…" : "Open the ticket"]
					})
				})
			]
		})
	] });
}
function OpenTicket({ id }) {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: t, isLoading } = useQuery({
		queryKey: ["ticket", id],
		queryFn: async () => {
			const { data, error } = await db.from("tickets").select("*").eq("id", id).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	const { data: messages } = useQuery({
		queryKey: ["ticket-messages", id],
		queryFn: async () => {
			const { data, error } = await db.from("ticket_messages").select("*").eq("ticket_id", id).order("created_at");
			if (error) throw error;
			return data ?? [];
		},
		refetchInterval: 3e4
	});
	const { data: docs } = useQuery({
		queryKey: ["ticket-docs", id],
		queryFn: async () => {
			const { data } = await db.from("sales_orders").select("id,number,status,total,balance").eq("ticket_id", id).order("created_at");
			return (data ?? []).map((d) => ({
				...d,
				total: Number(d.total),
				balance: Number(d.balance)
			}));
		}
	});
	const { data: staff } = useQuery({
		queryKey: ["support-staff"],
		queryFn: () => listSupportStaff(),
		staleTime: 6e5
	});
	const { data: templates } = useQuery({
		queryKey: ["ticket-templates"],
		queryFn: async () => {
			const { data } = await db.from("ticket_templates").select("id,title,body").order("title");
			return data ?? [];
		}
	});
	const { data: emailReady } = useQuery({
		queryKey: ["support-email-ready"],
		queryFn: () => supportEmailReady(),
		staleTime: 36e5
	});
	const { data: origin } = useQuery({
		queryKey: ["public-origin"],
		queryFn: publicOrigin
	});
	const { data: customers } = useCustomers();
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["ticket", id] });
		qc.invalidateQueries({ queryKey: ["ticket-messages", id] });
		qc.invalidateQueries({ queryKey: ["tickets"] });
	};
	(0, import_react.useEffect)(() => {
		if (t) document.title = `${t.number} · ${t.subject} · Tallkeep`;
	}, [t]);
	async function change(patch, event) {
		const { error } = await db.from("tickets").update(patch).eq("id", id);
		if (error) return void toast.error(error.message);
		if (event) await db.from("ticket_messages").insert({
			ticket_id: id,
			kind: "event",
			body: event
		});
		refresh();
	}
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) });
	if (!t) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-2xl border bg-card p-6",
		children: "This ticket isn't here."
	}) });
	const link = origin ? `${origin}/help/t/${t.public_key}` : "";
	const customer = customers?.find((c) => c.id === t.customer_id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/tickets",
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Tickets"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					t.number,
					" · opened ",
					when(t.created_at),
					t.source === "page" ? " on your support page" : t.source === "phone" ? " from a call" : "",
					t.topic ? ` · ${t.topic}` : ""
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
				children: t.subject
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "Status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: t.status,
						onChange: (e) => {
							const st = e.target.value;
							change({ status: st }, `Status: ${TICKET_STATUS[st].customer}`);
						},
						className: "h-9 rounded-md border bg-background px-2",
						children: TICKET_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: TICKET_STATUS[s].label
						}, s))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "Priority"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: t.priority,
						onChange: (e) => void change({ priority: e.target.value }),
						className: "h-9 rounded-md border bg-background px-2",
						children: Object.keys(PRIORITY).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p,
							children: PRIORITY[p]
						}, p))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "Assigned to"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: t.assigned_to ?? "",
						onChange: (e) => void change({ assigned_to: e.target.value || null }),
						className: "h-9 rounded-md border bg-background px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Nobody yet"
						}), (staff ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.id,
							children: s.name
						}, s.id))]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_20rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [(messages ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageView, { m }, m.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
					ticket: t,
					templates: templates ?? [],
					emailReady: !!emailReady?.ready,
					onSent: refresh
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Customer"
							}),
							customer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/customers/$id",
								params: { id: customer.id },
								className: "font-medium underline",
								children: customer.name
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkCustomer, {
								ticket: t,
								customers: customers ?? [],
								onDone: refresh
							}),
							t.name && t.name !== customer?.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.name }),
							t.company_name && t.company_name !== customer?.name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.company_name }),
							t.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:${t.email}`,
								className: "block underline",
								children: t.email
							}),
							t.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `tel:${t.phone}`,
								className: "block underline",
								children: t.phone
							}),
							t.address && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-muted-foreground",
								children: ["On site: ", t.address]
							}),
							link && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									copyText(link);
									toast.success("Link copied. The customer sees the conversation and can reply there.");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy the customer's link"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "Quotes and invoices"
							}),
							(docs ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: "None yet. The customer sees them on their link."
							}),
							(docs ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/sales/$id",
								params: { id: d.id },
								search: {},
								className: "flex justify-between gap-2 hover:underline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "mr-1 inline h-4 w-4" }), d.number] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fmtMoney(d.total), d.status !== "quote" && d.balance > 0 ? ` · owes ${fmtMoney(d.balance)}` : ""] })]
							}, d.id)),
							t.customer_id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/sales/$id",
										params: { id: "new" },
										search: {
											kind: "quote",
											customer: t.customer_id,
											ticket: t.id
										},
										children: "Make a quote"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/sales/$id",
										params: { id: "new" },
										search: {
											kind: "order",
											customer: t.customer_id,
											ticket: t.id
										},
										children: "Make an invoice"
									})
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Add the customer first to make a quote or invoice."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteTicket, {
						ticket: t,
						onDone: () => void navigate({ to: "/tickets" })
					})
				]
			})]
		})
	] });
}
function MessageView({ m }) {
	if (m.kind === "event") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-center text-xs text-muted-foreground",
		children: [
			m.body,
			" · ",
			when(m.created_at)
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-2 rounded-2xl border p-4", m.kind === "customer" && "mr-8 bg-card", m.kind === "staff" && "ml-8 bg-sky-50 dark:bg-sky-950/40", m.kind === "note" && "ml-8 border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/40"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex flex-wrap gap-x-2 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: m.author_name ?? (m.kind === "customer" ? "Customer" : "Staff")
					}),
					m.kind === "note" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· internal note (the customer doesn't see it)" }),
					m.kind === "staff" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", m.emailed ? "emailed to the customer" : "on their link"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", when(m.created_at)] })
				]
			}),
			m.body && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap text-sm",
				children: m.body
			}),
			m.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileLink, { f }, f.path))
		]
	});
}
function FileLink({ f }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: async () => {
			const { data, error } = await db.storage.from("ticket-files").createSignedUrl(f.path, 600);
			if (error || !data) return void toast.error("Couldn't open the file.");
			window.open(data.signedUrl, "_blank", "noopener");
		},
		className: "flex items-center gap-2 text-left text-sm underline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
			" ",
			f.name,
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground no-underline",
				children: fileSize(f.size)
			})
		]
	});
}
function Composer({ ticket, templates, emailReady, onSent }) {
	const [kind, setKind] = (0, import_react.useState)("staff");
	const [body, setBody] = (0, import_react.useState)("");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [then, setThen] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const canEmail = emailReady && !!ticket.email;
	async function send(e) {
		e.preventDefault();
		if (!body.trim() && !files.length) return void toast.error("Type a message.");
		setBusy(true);
		try {
			const co = await activeCompanyId();
			const saved = [];
			for (const f of files) {
				const path = `${co}/${ticket.id}/${crypto.randomUUID().slice(0, 8)}-${f.name.replace(/[^\w.\- ]+/g, "_")}`;
				const { error } = await db.storage.from("ticket-files").upload(path, f, { contentType: f.type });
				if (error) throw error;
				saved.push({
					path,
					name: f.name,
					size: f.size,
					type: f.type
				});
			}
			const r = await staffReply({ data: {
				ticketId: ticket.id,
				kind,
				body,
				files: saved,
				origin: await publicOrigin(),
				...then ? { status: then } : {}
			} });
			toast.success(kind === "note" ? "Note added." : r.emailed ? "Reply emailed to the customer." : "Reply saved on the customer's link.");
			setBody("");
			setFiles([]);
			setThen("");
			onSent();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: send,
		className: cn("space-y-3 rounded-2xl border p-4", kind === "note" ? "border-amber-300 bg-amber-50/60 dark:border-amber-800 dark:bg-amber-950/30" : "bg-card"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "inline-flex rounded-lg border p-0.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setKind("staff"),
						className: cn("rounded-md px-3 py-1", kind === "staff" && "bg-[var(--section)] text-white"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "mr-1 inline h-3.5 w-3.5" }), " Reply to the customer"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setKind("note"),
						className: cn("rounded-md px-3 py-1", kind === "note" && "bg-amber-500 text-white"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "mr-1 inline h-3.5 w-3.5" }), " Internal note"]
					})]
				}), templates.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: "",
					onChange: (e) => {
						const tp = templates.find((x) => x.id === e.target.value);
						if (tp) setBody((b) => b ? `${b}\n\n${tp.body}` : tp.body);
					},
					className: "h-8 rounded-md border bg-background px-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Saved replies…"
					}), templates.map((tp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: tp.id,
						children: tp.title
					}, tp.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				rows: 5,
				value: body,
				onChange: (e) => setBody(e.target.value),
				placeholder: kind === "note" ? "Only your team sees this." : `Write to ${ticket.name ?? "the customer"}…`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-1",
				children: files.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate",
							children: f.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Remove ${f.name}`,
							onClick: () => setFiles(files.filter((_, k) => k !== i)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" })
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					files.length < 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-1.5 rounded-md border px-3 py-1.5 text-sm hover:bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "h-4 w-4" }),
							" Attach",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								multiple: true,
								className: "hidden",
								onChange: (e) => {
									const picked = [...e.target.files ?? []].filter((f) => {
										if (f.size > 8388608) toast.error(`${f.name} is over 8 MB.`);
										return f.size <= 8388608;
									});
									e.target.value = "";
									setFiles([...files, ...picked].slice(0, 4));
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-1.5 text-sm",
						children: ["then mark it", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: then,
							onChange: (e) => setThen(e.target.value),
							className: "h-8 rounded-md border bg-background px-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: kind === "staff" ? "Waiting on customer" : "as it is"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "open",
									children: "Open"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "done",
									children: "Done"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "closed",
									children: "Closed"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: busy,
						className: "ml-auto",
						children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), busy ? "Sending…" : kind === "note" ? "Add the note" : canEmail ? "Send the reply" : "Save the reply"]
					})
				]
			}),
			kind === "staff" && !canEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [ticket.email ? "Email isn't set up here, so" : "There's no email on this ticket, so", " the customer sees your reply only on their link. Copy the link on the right and send it to them."]
			})
		]
	});
}
function LinkCustomer({ ticket, customers, onDone }) {
	const qc = useQueryClient();
	const guess = (0, import_react.useMemo)(() => customers.find((c) => ticket.email && c.email?.toLowerCase() === ticket.email.toLowerCase() || ticket.company_name && c.name.toLowerCase() === ticket.company_name.toLowerCase()), [customers, ticket]);
	const link = async (cid) => {
		if (!cid) return;
		const { error } = await db.from("tickets").update({ customer_id: cid }).eq("id", ticket.id);
		if (error) return void toast.error(error.message);
		onDone();
	};
	async function add() {
		const name = ticket.company_name || ticket.name || ticket.email;
		if (!name) return void toast.error("This ticket has no name to use.");
		const { data, error } = await db.from("customers").insert({
			name,
			contact_name: ticket.company_name ? ticket.name : null,
			email: ticket.email,
			phone: ticket.phone
		}).select("id").single();
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["customers"] });
		await link(data.id);
		toast.success(`${name} added as a customer.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [guess ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			variant: "outline",
			onClick: () => void link(guess.id),
			children: ["This is ", guess.name]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			variant: "outline",
			onClick: () => void add(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4" }), " Add as a new customer"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
			value: null,
			options: customers.map((c) => ({
				value: c.id,
				label: c.name,
				hint: c.email ?? ""
			})),
			onChange: (v) => void link(v),
			placeholder: "…or pick a customer"
		})]
	});
}
function DeleteTicket({ ticket, onDone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "text-xs text-muted-foreground underline hover:text-destructive",
		onClick: async () => {
			if (!window.confirm(`Delete ticket ${ticket.number} and its whole conversation? This can't be undone.`)) return;
			const { error, count } = await db.from("tickets").delete({ count: "exact" }).eq("id", ticket.id);
			if (error) return void toast.error(error.message);
			if (!count) return void toast.error("Only an admin can delete tickets. Mark it Closed instead.");
			toast.success("Ticket deleted.");
			onDone();
		},
		children: "Delete this ticket"
	});
}
//#endregion
export { TicketPage as component };
