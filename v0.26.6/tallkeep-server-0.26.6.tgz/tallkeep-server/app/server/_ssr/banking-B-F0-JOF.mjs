import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as kindLabel, d as today, f as useAccounts, i as accountLabel, t as KINDS } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { t as aiRead } from "./ai.functions-BGeFSAw1.mjs";
import { a as ruleFor, i as payeeKey, n as parseBankCsv, r as parseOfx } from "./bankfile-DZuZ5KwQ.mjs";
import { a as recordLoanPayments } from "./loans-Dgof3KNS.mjs";
import { c as keepInShoebox, d as offWarning, f as openFromStatement, m as readStatement } from "./shoebox-DHaB7ffx.mjs";
import { Vt as EyeOff, d as Upload, f as Undo2, ft as Link2, g as Trash2, i as WandSparkles, sn as Check, wn as BookMarked, x as Sparkles } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as TxnEditor, t as EDITABLE } from "./TxnEditor-DunpuwAB.mjs";
import { u as SearchSelect } from "./SearchSelect-Yp0ZfJ76.mjs";
import { t as Route } from "./banking-lF_6gSJ-.mjs";
import { t as useFeedWaiting } from "./feedWaiting-CPOsDrkb.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/banking-B-F0-JOF.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Make a new account from a bank line: its name and what kind it is, in plain words.
* Opened with ask(name); resolves to the new account's id, or null when cancelled.
*/
var CHOICES = [
	{
		kind: "expense",
		label: "Spending",
		hint: "Something you paid for: food, repairs, fees"
	},
	{
		kind: "income",
		label: "Income",
		hint: "Money you earned: pay, sales, rent"
	},
	{
		kind: "other_asset",
		label: "Money someone owes me",
		hint: "A loan you gave, a deposit you'll get back"
	},
	{
		kind: "other_liability",
		label: "A loan or money I owe",
		hint: "A loan you got, money you'll pay back"
	},
	{
		kind: "bank",
		label: "Another bank account",
		hint: "Checking, savings, PayPal, cash"
	},
	{
		kind: "credit_card",
		label: "A credit card",
		hint: "A card you pay off"
	},
	{
		kind: "equity",
		label: "Owner money in or out",
		hint: "Money you put in or took out for yourself"
	},
	{
		kind: "fixed_asset",
		label: "Something I own",
		hint: "Equipment, a vehicle, property"
	}
];
function NewAccountDialog({ name: start, moneyIn, onDone }) {
	const qc = useQueryClient();
	const [name, setName] = (0, import_react.useState)(start);
	const [kind, setKind] = (0, import_react.useState)(moneyIn ? "income" : "expense");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function add() {
		const n = name.trim();
		if (!n) return void toast.error("Type a name for the account.");
		const type = KINDS.find((k) => k.kind === kind)?.type ?? "expense";
		setBusy(true);
		const { data, error } = await db.from("accounts").insert({
			name: n,
			kind,
			type,
			is_active: true
		}).select("id").single();
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(`Account "${n}" added.`);
		await qc.invalidateQueries({ queryKey: ["accounts"] });
		onDone(data.id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onDone(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New account" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Name it and choose what it is." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: name,
					onChange: (e) => setName(e.target.value),
					autoFocus: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: CHOICES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setKind(c.kind),
						className: `rounded-xl border p-2.5 text-left text-sm ${kind === c.kind ? "border-[var(--section)] bg-[var(--section)]/10" : "hover:bg-muted"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: c.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: c.hint
						})]
					}, c.kind))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => onDone(null),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void add(),
					disabled: busy,
					children: busy ? "Adding…" : "Add the account"
				})] })
			]
		})
	});
}
var TYPE_NAME = {
	invoice: "Invoice",
	payment: "Payment received",
	po: "Purchase order",
	po_payment: "PO payment",
	bill: "Bill",
	bill_payment: "Bill payment",
	manual: "Journal entry",
	opening: "Opening balance",
	bank: "Added from bank"
};
var daysApart = (a, b) => Math.abs(Date.parse(`${a}T12:00:00`) - Date.parse(`${b}T12:00:00`)) / 864e5;
/** For each new bank line, an uncleared book line with the same amount within 10 days. */
function suggest(txns, lines) {
	const used = new Set(txns.filter((t) => t.source_id).map((t) => t.source_id));
	const m = /* @__PURE__ */ new Map();
	for (const t of txns.filter((x) => x.status === "new")) {
		const hit = lines.filter((l) => !l.cleared && !used.has(l.item_key) && Math.abs(Number(l.amount) - Number(t.amount)) < .005 && daysApart(l.entry_date, t.txn_date) <= 10).sort((a, b) => daysApart(a.entry_date, t.txn_date) - daysApart(b.entry_date, t.txn_date))[0];
		if (hit) {
			m.set(t.id, hit);
			used.add(hit.item_key);
		}
	}
	return m;
}
var AUTO_KEY = "bank-auto-record";
function readAuto() {
	try {
		return localStorage.getItem(AUTO_KEY) !== "off";
	} catch {
		return true;
	}
}
function Banking() {
	const { data: accounts } = useAccounts();
	const { data: waiting } = useFeedWaiting();
	const banks = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card") || (waiting?.per.get(a.id) ?? 0) > 0);
	const search = Route.useSearch();
	const [accountId, setAccountId] = (0, import_react.useState)(search.account ?? keep.get("account") ?? null);
	(0, import_react.useEffect)(() => {
		if (accountId) keep.set("account", accountId);
	}, [accountId]);
	(0, import_react.useEffect)(() => {
		if (search.account) setAccountId(search.account);
	}, [search.account]);
	(0, import_react.useEffect)(() => {
		if (!accountId && banks[0]) setAccountId(banks[0].id);
	}, [banks, accountId]);
	const account = banks.find((a) => a.id === accountId);
	const [tab, setTab] = (0, import_react.useState)(search.tab ?? (keep.get("tab") || "review"));
	(0, import_react.useEffect)(() => keep.set("tab", tab), [tab]);
	(0, import_react.useEffect)(() => {
		if (search.tab) setTab(search.tab);
	}, [search.tab]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Banking",
			text: "Bring in your bank or credit card statement, check each line against the books, then reconcile so the books match the bank to the penny."
		}),
		accounts && banks.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-sm text-muted-foreground",
			children: "No bank or credit card accounts yet. Add one in the Chart of Accounts."
		}),
		banks.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-72",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
					value: accountId,
					options: banks.map((a) => {
						const n = waiting?.per.get(a.id) ?? 0;
						return {
							value: a.id,
							label: `${accountLabel(a)}${n ? ` · ${n} to review` : ""}`
						};
					}),
					onChange: setAccountId,
					placeholder: "Choose the account"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: [
					["review", "For review"],
					["done", "Done"],
					["reconcile", "Reconcile"]
				].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(k),
					className: `rounded-md px-3 py-1 ${tab === k ? "bg-[var(--section)] text-white" : ""}`,
					children: label
				}, k))
			})]
		}),
		account && tab !== "reconcile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feed, {
			account,
			accounts: accounts ?? [],
			done: tab === "done"
		}),
		account && tab === "reconcile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reconcile, { account }, account.id)
	] });
}
/** Small things remembered for this browser session (the account, tab and reconcile boxes). */
var keep = {
	get(k) {
		try {
			return sessionStorage.getItem(`tk-banking:${k}`);
		} catch {
			return null;
		}
	},
	set(k, v) {
		try {
			sessionStorage.setItem(`tk-banking:${k}`, v);
		} catch {}
	}
};
/** Lines waiting in other accounts: one click to each. */
function WaitingElsewhere({ here }) {
	const { data: waiting } = useFeedWaiting();
	const { data: accounts } = useAccounts();
	const navigate = useNavigate();
	const others = [...waiting?.per.entries() ?? []].filter(([id, n]) => id !== here && n > 0);
	if (!others.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-center gap-2 px-4 pb-6 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: "Lines wait in:"
		}), others.map(([id, n]) => {
			const a = accounts?.find((x) => x.id === id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => void navigate({
					to: "/banking",
					search: {
						account: id,
						tab: "review"
					}
				}),
				children: [
					a ? accountLabel(a) : "An account",
					" · ",
					n
				]
			}, id);
		})]
	});
}
function Feed({ account, accounts, done }) {
	const qc = useQueryClient();
	const [flip, setFlip] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const loadTxns = async () => {
		const { data, error } = await db.from("bank_transactions").select("id,txn_date,amount,description,ref,status,source_type,source_id").eq("account_id", account.id).order("txn_date", { ascending: false }).limit(5e3);
		if (error) throw error;
		return data ?? [];
	};
	const loadLines = async () => {
		const { data, error } = await db.rpc("account_lines", {
			_account: account.id,
			_to: null
		});
		if (error) throw error;
		return data ?? [];
	};
	const loadRules = () => fetchAll("bank_rules", "id,contains,account_id");
	const { data: txns, isLoading } = useQuery({
		queryKey: ["bank-txns", account.id],
		queryFn: loadTxns
	});
	const { data: lines } = useQuery({
		queryKey: ["account-lines", account.id],
		queryFn: loadLines
	});
	const { data: rules } = useQuery({
		queryKey: ["bank-rules"],
		queryFn: loadRules
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["bank-txns", account.id] });
		qc.invalidateQueries({ queryKey: ["account-lines", account.id] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	const suggestions = (0, import_react.useMemo)(() => suggest(txns ?? [], lines ?? []), [txns, lines]);
	const [auto, setAuto] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => setAuto(readAuto()), []);
	const [drag, setDrag] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)("");
	const [rulesOpen, setRulesOpen] = (0, import_react.useState)(false);
	const [aiPicks, setAiPicks] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const noteKey = `tk-ai-note:${account.id}`;
	const [note, setNote] = (0, import_react.useState)(() => {
		try {
			return localStorage.getItem(noteKey) ?? "";
		} catch {
			return "";
		}
	});
	const [suggesting, setSuggesting] = (0, import_react.useState)(false);
	/** Record every line we're sure about: matches with the books, then remembered payees. */
	async function recordSure(quiet = false) {
		const loans = account.kind === "bank" ? await recordLoanPayments(account.id) : 0;
		const [t2, l2, r2] = await Promise.all([
			qc.fetchQuery({
				queryKey: ["bank-txns", account.id],
				queryFn: loadTxns,
				staleTime: 0
			}),
			qc.fetchQuery({
				queryKey: ["account-lines", account.id],
				queryFn: loadLines,
				staleTime: 0
			}),
			qc.fetchQuery({
				queryKey: ["bank-rules"],
				queryFn: loadRules,
				staleTime: 0
			})
		]);
		const sugg = suggest(t2, l2);
		let matched = 0;
		let added = loans;
		setBusy(true);
		for (const t of t2.filter((x) => x.status === "new")) {
			const l = sugg.get(t.id);
			if (l) {
				if (await match(t, l, false)) matched++;
				continue;
			}
			const r = ruleFor(r2, t.description);
			if (r && await add(t, r.account_id, null, false)) added++;
		}
		setBusy(false);
		refresh();
		if (matched + added > 0) toast.success(`Recorded ${matched + added} automatically (${matched} matched, ${added - loans} from remembered payees${loans ? `, ${loans} loan payment${loans === 1 ? "" : "s"} split` : ""}). Check them under Done.`);
		else if (!quiet) toast.message("Nothing sure to record. The rest needs you.");
	}
	/** A PDF statement: the AI reads it, and the lines are checked against its balances. */
	async function readPdf(file) {
		try {
			setBusy(true);
			const r = await readStatement(file, account.kind === "credit_card", (t) => setStep(t.charAt(0).toUpperCase() + t.slice(1)));
			const warn = offWarning(r);
			if (warn) toast.warning(warn, { duration: 3e4 });
			const first = r.lines.map((l) => l.txn_date).sort()[0];
			if (r.begin != null && first) {
				const said = await openFromStatement(account, r.begin, first);
				if (said) toast.success(said);
			}
			return r.lines;
		} catch (e) {
			return e.message;
		} finally {
			setStep("");
			setBusy(false);
		}
	}
	async function importFile(file) {
		let parsed;
		if (/\.pdf$/i.test(file.name)) parsed = await readPdf(file);
		else {
			const text = await file.text();
			parsed = /<OFX>|<STMTTRN>/i.test(text) ? parseOfx(text) : parseBankCsv(text, flip);
		}
		if (typeof parsed === "string") return void toast.error(parsed);
		if (!parsed.length) return void toast.error("No lines found in this file.");
		setBusy(true);
		const before = txns?.length ?? 0;
		const { error } = await db.from("bank_transactions").upsert(parsed.map((p) => ({
			...p,
			account_id: account.id
		})), {
			onConflict: "account_id,fit_id",
			ignoreDuplicates: true
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		const { count } = await db.from("bank_transactions").select("id", {
			count: "exact",
			head: true
		}).eq("account_id", account.id);
		const added = (count ?? before) - before;
		const said = added > 0 ? `Brought in ${added} new lines${parsed.length > added ? ` (${parsed.length - added} were already here)` : ""}.` : "All these lines were already here.";
		toast.success(said);
		keepInShoebox(file, account.id, `${said.replace(/\.$/, "")} in ${account.name}`);
		refresh();
		if (auto && added > 0) await recordSure(true);
	}
	async function match(t, l, again = true) {
		const a = await db.from("bank_transactions").update({
			status: "matched",
			source_type: l.source_type,
			source_id: l.item_key
		}).eq("id", t.id);
		if (a.error) {
			toast.error(a.error.message);
			return false;
		}
		await db.from("cleared_items").upsert({
			account_id: account.id,
			item_key: l.item_key
		}, { onConflict: "account_id,item_key" });
		if (again) refresh();
		return true;
	}
	/**
	* A payment between two of your own accounts shows on both statements (checking: "Payment To
	* Chase Card", card: "Payment Thank You"). When the other account already has it from its own
	* statement, this finds it, so it's counted once, as one transfer.
	*/
	async function findTwin(t, other) {
		const acc = accounts.find((a) => a.id === other);
		if (!acc || !["bank", "credit_card"].includes(acc.kind)) return null;
		const { data } = await db.from("bank_transactions").select("id,txn_date,amount,source_id").eq("account_id", other).eq("status", "added").eq("amount", -Number(t.amount));
		const near = (data ?? []).find((x) => x.source_id && Math.abs(Date.parse(x.txn_date) - Date.parse(t.txn_date)) <= 864e6);
		if (!near?.source_id) return null;
		const { data: ls } = await db.from("journal_lines").select("id,account_id").eq("entry_id", near.source_id);
		const lines = ls ?? [];
		if (lines.length !== 2) return null;
		if (lines.some((l) => l.account_id === account.id)) return {
			entry: near.source_id,
			line: null,
			date: near.txn_date,
			name: acc.name
		};
		const side = lines.find((l) => l.account_id !== other);
		return side ? {
			entry: near.source_id,
			line: side.id,
			date: near.txn_date,
			name: acc.name
		} : null;
	}
	async function add(t, other, remember, again = true) {
		const twin = await findTwin(t, other);
		if (twin && window.confirm(`${twin.name} already has this ${fmtMoney(Math.abs(Number(t.amount)))} from its own statement (${fmtDate(twin.date)}). Count it once, as a transfer between the two accounts?`)) {
			if (twin.line) {
				const u = await db.from("journal_lines").update({ account_id: account.id }).eq("id", twin.line);
				if (u.error) {
					toast.error(u.error.message);
					return false;
				}
			}
			const ok = await match(t, {
				item_key: twin.entry,
				source_type: "bank"
			}, again);
			if (ok) toast.success("Counted once, as a transfer between the two accounts.");
			return ok;
		}
		const { error } = await db.rpc("add_bank_transaction", {
			_txn: t.id,
			_other: other,
			_memo: t.description ?? ""
		});
		if (error) {
			toast.error(error.message);
			return false;
		}
		const key = remember?.trim();
		if (key) {
			const old = (rules ?? []).find((r) => r.contains.toLowerCase() === key.toLowerCase());
			if (old) await db.from("bank_rules").update({ account_id: other }).eq("id", old.id);
			else await db.from("bank_rules").insert({
				contains: key,
				account_id: other
			});
			qc.invalidateQueries({ queryKey: ["bank-rules"] });
		}
		if (again) {
			refresh();
			const more = key ? list.filter((x) => x.id !== t.id && ruleFor([{ contains: key }], x.description)).length : 0;
			if (key && auto) {
				await recordSure(true);
				if (more) toast.success(`Also added ${more} more "${key}" line${more === 1 ? "" : "s"} to the same account.`);
			} else if (more) toast.info(`${more} more "${key}" line${more === 1 ? " has" : "s have"} the same account filled in. Press Add to the books on each, or Record the sure lines.`);
		}
		return true;
	}
	async function ignore(t) {
		await db.from("bank_transactions").update({ status: "ignored" }).eq("id", t.id);
		refresh();
	}
	async function undo(t) {
		const { error } = await db.rpc("undo_bank_transaction", { _txn: t.id });
		if (error) return void toast.error(error.message);
		refresh();
	}
	const list = (txns ?? []).filter((t) => done ? t.status !== "new" : t.status === "new");
	const investGuess = (desc) => {
		const d = (desc ?? "").toLowerCase();
		if (!d) return null;
		return accounts.find((a) => {
			if (!a.is_active || a.kind !== "other_asset") return false;
			const w = a.name.toLowerCase().split(/[^a-z0-9]+/).find((x) => x.length > 3 && !COMMON_WORDS.has(x));
			return !!w && d.includes(w);
		})?.id ?? null;
	};
	const ruleGuess = (desc) => ruleFor(rules ?? [], desc)?.account_id ?? null;
	/** Ask the AI which account fits each waiting line that has no match or remembered payee. */
	async function suggestAccounts() {
		const open = list.filter((t) => !suggestions.has(t.id) && !guessFor(t.description)).slice(0, 80);
		if (!open.length) return void toast.info("Every line already has a match or an account.");
		setSuggesting(true);
		try {
			try {
				localStorage.setItem(noteKey, note);
			} catch {}
			const usable = accounts.filter((a) => a.is_active && a.id !== account.id && !["ar", "ap"].includes(a.kind));
			const hint = [
				`These lines are from "${account.name}" (${account.kind === "credit_card" ? "a credit card" : "a bank account"}).`,
				note.trim() ? `Note from the owner: ${note.trim()}` : "",
				"Chart of accounts (name — type):",
				...usable.map((a) => `${a.name} — ${kindLabel(a.kind)}`),
				"Lines (id | date | description | amount; negative = money out):",
				...open.map((t) => `${t.id} | ${t.txn_date} | ${t.description ?? ""} | ${t.amount}`)
			].filter(Boolean).join("\n");
			const r = JSON.parse(await aiRead({ data: {
				feature: "categorize",
				images: [],
				hint
			} }));
			const byName = new Map(usable.map((a) => [a.name.toLowerCase(), a.id]));
			const next = new Map(aiPicks);
			for (const p of r.picks ?? []) {
				const id = p.account && byName.get(p.account.toLowerCase().trim());
				if (p.id && id) next.set(p.id, {
					acc: id,
					why: (p.why ?? "").slice(0, 80)
				});
			}
			setAiPicks(next);
			const n = open.filter((t) => next.has(t.id)).length;
			toast.success(n ? `Suggested an account for ${n} of ${open.length} lines. Check each one, then Add to the books.` : "The AI wasn't sure about any of these. Pick them yourself.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setSuggesting(false);
		}
	}
	const guessFor = (desc) => ruleGuess(desc) ?? investGuess(desc);
	const sure = list.filter((t) => suggestions.has(t.id) || ruleGuess(t.description)).length;
	const onFile = (f) => {
		if (!f) return;
		if (!/\.(csv|ofx|qfx|qbo|pdf)$/i.test(f.name)) return void toast.error("Use a PDF, CSV, QBO, QFX or OFX file from your bank's website.");
		importFile(f);
	};
	const options = accounts.filter((a) => a.is_active && a.id !== account.id && !["ar", "ap"].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		onDragOver: (e) => {
			if (done) return;
			e.preventDefault();
			setDrag(true);
		},
		onDragLeave: (e) => {
			if (!e.currentTarget.contains(e.relatedTarget)) setDrag(false);
		},
		onDrop: (e) => {
			if (done) return;
			e.preventDefault();
			setDrag(false);
			onFile(e.dataTransfer.files[0]);
		},
		children: [
			rulesOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RulesDialog, {
				rules: rules ?? [],
				options,
				onClose: () => setRulesOpen(false)
			}),
			!done && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex flex-wrap items-center gap-3 rounded-2xl border-2 border-dashed bg-card p-4 text-sm ${drag ? "border-[var(--section)] bg-[var(--section-soft)]" : "border-border"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 font-medium hover:bg-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
							" ",
							busy ? step || "Working…" : "Bring in a statement file",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: ".pdf,.csv,.ofx,.qfx,.qbo",
								className: "hidden",
								onChange: (e) => {
									const f = e.target.files?.[0];
									e.target.value = "";
									onFile(f);
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "or drop it here. A PDF statement works (AI reads it), or download CSV / QuickBooks / Quicken (QBO, QFX, OFX) from your bank's website."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: flip,
							onChange: (e) => setFlip(e.target.checked)
						}), "CSV shows charges as positive numbers (flip them)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full flex-wrap items-center gap-3 border-t pt-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: auto,
									onChange: (e) => {
										setAuto(e.target.checked);
										try {
											localStorage.setItem(AUTO_KEY, e.target.checked ? "on" : "off");
										} catch {}
									}
								}), "Record sure lines automatically (matches and remembered payees)"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								disabled: busy || sure === 0,
								onClick: () => void recordSure(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }),
									" Record the ",
									sure,
									" sure line",
									sure === 1 ? "" : "s"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setRulesOpen(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMarked, { className: "h-3.5 w-3.5" }),
									" Remembered payees (",
									rules?.length ?? 0,
									")"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-full flex-wrap items-center gap-2 border-t pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							disabled: suggesting || busy || list.length === 0,
							onClick: () => void suggestAccounts(),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "h-3.5 w-3.5" }),
								" ",
								suggesting ? "Asking the AI…" : "Suggest accounts"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: note,
							onChange: (e) => setNote(e.target.value),
							placeholder: "Note for the AI (optional), like: Capsule is for SunRise LED; food and pharmacy are personal",
							className: "h-8 min-w-0 flex-1 text-xs"
						})]
					})
				]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [
					list.map((t) => done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3 px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24",
								children: fmtDate(t.txn_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: t.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: t.status === "matched" ? `Matched · ${TYPE_NAME[t.source_type ?? ""] ?? ""}` : t.status === "added" ? "Added to the books" : "Ignored"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: t.amount }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => void undo(t),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-3.5 w-3.5" }), " Undo"]
							})
						]
					}, t.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewRow, {
						t,
						suggestion: suggestions.get(t.id),
						guess: guessFor(t.description) ?? aiPicks.get(t.id)?.acc ?? null,
						why: guessFor(t.description) ? void 0 : aiPicks.get(t.id)?.why,
						transfer: !ruleGuess(t.description) && !!investGuess(t.description),
						options,
						onMatch: (l) => void match(t, l),
						onAdd: (acc, remember) => void add(t, acc, remember),
						onIgnore: () => void ignore(t)
					}, t.id)),
					txns && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-8 text-center text-muted-foreground",
						children: done ? "Nothing handled yet." : "Nothing to review. Bring in a statement file to start."
					}),
					txns && list.length === 0 && !done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaitingElsewhere, { here: account.id })
				]
			})
		]
	});
}
function Amount({ v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `w-28 text-right font-medium tabular-nums ${v < 0 ? "" : "text-emerald-700"}`,
		children: v < 0 ? `− ${fmtMoney(-v)}` : `+ ${fmtMoney(v)}`
	});
}
/** Words in account names that don't tell one company from another. */
var COMMON_WORDS = new Set("account investments investment brokerage retirement roth rollover traditional joint individual tenants common savings checking trust".split(" "));
function ReviewRow({ t, suggestion, guess, transfer, why, options, onMatch, onAdd, onIgnore }) {
	const [acc, setAcc] = (0, import_react.useState)(guess);
	useQueryClient();
	const [adding, setAdding] = (0, import_react.useState)(null);
	const newAccount = (name) => new Promise((done) => setAdding({
		name,
		done
	}));
	(0, import_react.useEffect)(() => {
		if (guess) setAcc(guess);
	}, [guess]);
	const [remember, setRemember] = (0, import_react.useState)(!guess);
	const [word, setWord] = (0, import_react.useState)(() => payeeKey(t.description));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 px-4 py-3",
		children: [
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewAccountDialog, {
				name: adding.name,
				moneyIn: t.amount > 0,
				onDone: (id) => {
					adding.done(id);
					setAdding(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24",
						children: fmtDate(t.txn_date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate font-medium",
						children: t.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: t.amount })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 pl-0 sm:pl-[6.75rem]",
				children: [suggestion ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-3.5 w-3.5 text-[var(--section)]" }),
						"Matches ",
						TYPE_NAME[suggestion.source_type] ?? "entry",
						" ",
						suggestion.ref ?? "",
						" on",
						" ",
						fmtDate(suggestion.entry_date)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => onMatch(suggestion),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }), " Match"]
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: acc,
							options,
							onChange: setAcc,
							onAdd: newAccount,
							addLabel: "New account",
							placeholder: t.amount < 0 ? "What was it for? (account)" : "Where did it come from? (account)"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-1.5 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: remember,
							onChange: (e) => setRemember(e.target.checked)
						}), "Always use it for"]
					}),
					why && acc === guess && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-xs text-[var(--section)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "h-3 w-3" }),
							" Suggested",
							why ? `: ${why}` : ""
						]
					}),
					transfer && acc === guess && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-[var(--section)]",
						children: "A transfer between your bank and investment account (not spending or income)"
					}),
					remember && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: word,
						onChange: (e) => setWord(e.target.value),
						className: "h-8 w-44 text-xs",
						title: "Bank lines that contain this text get this account from now on"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						disabled: !acc,
						onClick: () => acc && onAdd(acc, remember && word.trim() ? word : null),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }), " Add to the books"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: onIgnore,
					title: "Already in the books some other way, or not ours",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-3.5 w-3.5" }), " Ignore"]
				})]
			})
		]
	});
}
function RulesDialog({ rules, options, onClose }) {
	const qc = useQueryClient();
	const [q, setQ] = (0, import_react.useState)("");
	const shown = [...rules].sort((a, b) => a.contains.localeCompare(b.contains)).filter((r) => r.contains.toLowerCase().includes(q.toLowerCase()));
	const save = async (id, patch) => {
		const { error } = await db.from("bank_rules").update(patch).eq("id", id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["bank-rules"] });
	};
	const remove = async (id) => {
		const { error } = await db.from("bank_rules").delete().eq("id", id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["bank-rules"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Remembered payees" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Bank lines that contain the text on the left get the account on the right, for every bank and card account. Fix or delete any of them here."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Find…",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[55vh] divide-y overflow-y-auto rounded-lg border",
					children: [shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-6 text-center text-sm text-muted-foreground",
						children: "None yet. They are saved when you add a bank line with \"Always use it for\"."
					}), shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								defaultValue: r.contains,
								className: "h-8 w-48 text-sm",
								onBlur: (e) => {
									const v = e.target.value.trim();
									if (v && v !== r.contains) save(r.id, { contains: v });
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "min-w-0 flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: r.account_id,
									options,
									onChange: (v) => v && void save(r.id, { account_id: v })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "Delete",
								onClick: () => void remove(r.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, r.id))]
				})
			]
		})
	});
}
function Reconcile({ account }) {
	const [editing, setEditing] = (0, import_react.useState)(null);
	const { data: accounts } = useAccounts();
	const qc = useQueryClient();
	const sign = account.type === "liability" ? -1 : 1;
	const [date, setDate] = (0, import_react.useState)(() => keep.get(`rec-date:${account.id}`) || today());
	const [ending, setEnding] = (0, import_react.useState)(() => keep.get(`rec-end:${account.id}`) ?? "");
	(0, import_react.useEffect)(() => keep.set(`rec-date:${account.id}`, date), [account.id, date]);
	(0, import_react.useEffect)(() => keep.set(`rec-end:${account.id}`, ending), [account.id, ending]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const { data: lines, isLoading } = useQuery({
		queryKey: ["account-lines", account.id],
		queryFn: async () => {
			const { data, error } = await db.rpc("account_lines", {
				_account: account.id,
				_to: null
			});
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: history } = useQuery({
		queryKey: ["reconciliations", account.id],
		queryFn: async () => {
			const { data } = await db.from("reconciliations").select("id,statement_date,ending_balance,completed_at").eq("account_id", account.id).not("completed_at", "is", null).order("statement_date", { ascending: false });
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["account-lines", account.id] });
		qc.invalidateQueries({ queryKey: ["reconciliations", account.id] });
	};
	const items = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const l of lines ?? []) {
			const x = m.get(l.item_key);
			if (x) x.total += Number(l.amount);
			else m.set(l.item_key, {
				...l,
				total: Number(l.amount)
			});
		}
		return [...m.values()].sort((a, b) => a.entry_date.localeCompare(b.entry_date));
	}, [lines]);
	const beginning = items.filter((i) => i.reconciliation_id).reduce((s, i) => s + i.total, 0) * sign;
	const open = items.filter((i) => !i.reconciliation_id && i.entry_date <= date);
	const [newestFirst, setNewestFirst] = (0, import_react.useState)(true);
	const shown = newestFirst ? [...open].reverse() : open;
	const ticked = open.filter((i) => i.cleared);
	const clearedBal = beginning + ticked.reduce((s, i) => s + i.total, 0) * sign;
	const target = Number(ending);
	const diff = ending === "" ? null : Math.round((target - clearedBal) * 100) / 100;
	async function toggle(i, on) {
		const { error } = on ? await db.from("cleared_items").upsert({
			account_id: account.id,
			item_key: i.item_key
		}, { onConflict: "account_id,item_key" }) : await db.from("cleared_items").delete().eq("account_id", account.id).eq("item_key", i.item_key);
		if (error) toast.error(error.message);
		refresh();
	}
	/** Tick or untick many lines at once. */
	async function tickMany(list, on) {
		const keys = list.filter((i) => i.cleared !== on).map((i) => i.item_key);
		if (!keys.length) return;
		setBusy(true);
		try {
			for (let k = 0; k < keys.length; k += 200) {
				const part = keys.slice(k, k + 200);
				const { error } = on ? await db.from("cleared_items").upsert(part.map((item_key) => ({
					account_id: account.id,
					item_key
				})), { onConflict: "account_id,item_key" }) : await db.from("cleared_items").delete().eq("account_id", account.id).in("item_key", part);
				if (error) throw error;
			}
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
			refresh();
		}
	}
	const firstBank = open.find((i) => i.source_type === "bank")?.entry_date ?? null;
	const oldHistory = (history ?? []).length === 0 ? open.filter((i) => i.source_type === "history" && !i.cleared && (!firstBank || i.entry_date < firstBank)) : [];
	const unticked = open.filter((i) => !i.cleared);
	const exact = diff && diff !== 0 ? new Set(open.filter((i) => Math.abs(Math.abs(i.total * sign) - Math.abs(diff)) < .005 && (i.cleared ? -1 : 1) * i.total * sign * Math.sign(diff) > 0).map((i) => i.item_key)) : /* @__PURE__ */ new Set();
	async function finish() {
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const { data: r, error } = await db.from("reconciliations").insert({
				account_id: account.id,
				statement_date: date,
				ending_balance: target,
				completed_at: (/* @__PURE__ */ new Date()).toISOString(),
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const keys = ticked.map((i) => i.item_key);
			for (let k = 0; k < keys.length; k += 200) {
				const { error: e2 } = await db.from("cleared_items").update({ reconciliation_id: r.id }).eq("account_id", account.id).in("item_key", keys.slice(k, k + 200));
				if (e2) throw e2;
			}
			toast.success(`Reconciled through ${fmtDate(date)}.`);
			setEnding("");
			refresh();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3 rounded-2xl border bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: "Statement end date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: account.type === "liability" ? "Statement balance owed" : "Statement ending balance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							className: "w-40",
							value: ending,
							onChange: (e) => setEnding(e.target.value),
							placeholder: "0.00"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto grid grid-cols-3 gap-4 text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Beginning",
								v: beginning
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Cleared balance",
								v: clearedBal
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Difference",
								v: diff ?? 0,
								bad: diff !== null && diff !== 0,
								good: diff === 0
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Tick every line that shows on the statement. Lines matched from a bank file are already ticked. When the difference is $0.00, press Finish."
			}),
			open.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 text-sm",
				children: [
					oldHistory.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						disabled: busy,
						onClick: () => void tickMany(oldHistory, true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }),
							" Tick the ",
							oldHistory.length,
							" QuickBooks lines",
							firstBank ? ` before ${fmtDate(firstBank)}` : "",
							" (reconciled there)"
						]
					}),
					unticked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "outline",
						disabled: busy,
						onClick: () => void tickMany(unticked, true),
						children: [
							"Tick all ",
							unticked.length,
							" up to ",
							fmtDate(date)
						]
					}),
					ticked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: busy,
						onClick: () => void tickMany(ticked, false),
						children: "Untick all"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "ml-auto flex items-center gap-1.5 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: newestFirst,
							onChange: (e) => setNewestFirst(e.target.checked)
						}), "Newest first"]
					}),
					unticked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							"Not ticked: ",
							unticked.length,
							" lines,",
							" ",
							fmtMoney(unticked.reduce((t, i) => t + i.total, 0) * sign)
						]
					})
				]
			}),
			exact.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
				children: "The difference is exactly one line's amount: it's marked below."
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
				children: [
					shown.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: `flex cursor-pointer items-center gap-3 px-4 py-2 hover:bg-muted/40 ${exact.has(i.item_key) ? "bg-amber-50 dark:bg-amber-950/40" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "h-4 w-4",
								checked: i.cleared,
								onChange: (e) => void toggle(i, e.target.checked)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24",
								children: fmtDate(i.entry_date)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-36 text-muted-foreground",
								children: TYPE_NAME[i.source_type] ?? i.source_type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-24",
								children: i.ref
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate text-muted-foreground",
								children: i.memo
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Amount, { v: i.total }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: "Change or delete this line",
								className: "rounded-md px-2 py-0.5 text-xs text-[var(--section)] hover:bg-muted",
								onClick: (e) => {
									e.preventDefault();
									if (EDITABLE.has(i.source_type)) setEditing(i.entry_id);
									else window.location.assign(`/go/entry/${i.entry_id}`);
								},
								children: "Open"
							})
						]
					}, i.item_key)),
					editing && accounts && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TxnEditor, {
						entryId: editing,
						accountId: account.id,
						accounts,
						onClose: () => {
							setEditing(null);
							qc.invalidateQueries();
						}
					}),
					lines && open.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-8 text-center text-muted-foreground",
						children: "Nothing left to reconcile up to this date."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void finish(),
					disabled: busy || diff !== 0 || ticked.length === 0,
					children: busy ? "Finishing…" : "Finish reconciling"
				})
			}),
			(history ?? []).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 font-semibold",
					children: "Reconciled before"
				}), (history ?? []).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Statement of ", fmtDate(h.statement_date)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: fmtMoney(h.ending_balance)
					})]
				}, h.id))]
			})
		]
	});
}
function Stat({ label, v, bad, good }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `font-semibold tabular-nums ${bad ? "text-destructive" : good ? "text-emerald-700" : ""}`,
		children: fmtMoney(v)
	})] });
}
//#endregion
export { Banking as component };
