import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay._token-DhDNLECZ.js
var $$splitComponentImporter = () => import("./pay._token-8jht1pDy.mjs");
/**
* The customer's page for an invoice or a quote: no sign-in. An invoice is paid through Stripe's
* secure checkout (card, Apple Pay, Google Pay or bank account). A quote is read, accepted by
* typing a name, and its deposit paid the same way.
*/
var Route = createFileRoute("/pay/$token")({
	ssr: false,
	validateSearch: (s) => typeof s["session"] === "string" ? { session: s["session"] } : {},
	head: () => ({ meta: [{ title: "Your invoice" }, {
		name: "robots",
		content: "noindex"
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
