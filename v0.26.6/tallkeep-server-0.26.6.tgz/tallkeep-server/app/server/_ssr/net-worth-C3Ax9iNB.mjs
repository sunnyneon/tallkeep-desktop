import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, p as useTotals } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { h as worth, m as useHoldings, n as OWE_GROUPS, o as isInvestment, t as HAVE_GROUPS, u as netWorthByMonth } from "./personal-C-Op5nYv.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as useWho, r as useAccountOwners } from "./members-BvdxHr68.mjs";
import { t as WhoPicker } from "./WhoPicker-DLJRzcvg.mjs";
import { a as YAxis, l as CartesianGrid, m as Tooltip, n as AreaChart, o as XAxis, p as ResponsiveContainer, s as Area } from "../_libs/recharts+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/net-worth-C3Ax9iNB.js
var import_jsx_runtime = require_jsx_runtime();
function NetWorth() {
	const { data: everyAccount } = useAccounts();
	const [who] = useWho();
	const { data: owners } = useAccountOwners();
	const accounts = everyAccount?.filter((a) => !who || a.type !== "asset" && a.type !== "liability" || owners?.get(a.id) === who);
	const { data: totals } = useTotals(null, today());
	const { data: holdings } = useHoldings();
	const list = accounts ?? [];
	const history = useQuery({
		queryKey: [
			"net-worth-history",
			list.length,
			who
		],
		enabled: list.length > 0,
		queryFn: () => netWorthByMonth(list)
	});
	if (!accounts || !totals) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) });
	const w = worth(accounts, totals, holdings);
	const chart = (history.data ?? []).map((r, i, l) => i === l.length - 1 ? {
		...r,
		net: Math.round(w.net)
	} : r);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Net Worth",
			text: "Everything you own minus everything you owe. Investments count at today's prices (from Investments); the rest comes from your books."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoPicker, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
					label: "You own",
					value: w.totalHave
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
					label: "You owe",
					value: w.totalOwe
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Big, {
					label: "Net worth",
					value: w.net,
					main: true
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-2xl border bg-card p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-2 font-semibold",
					children: "The last 12 months"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-56",
					children: history.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-full" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: chart,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									strokeDasharray: "3 3",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "month",
									tick: { fontSize: 11 }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: { fontSize: 11 },
									width: 56,
									tickFormatter: (n) => Math.abs(n) >= 1e3 ? `$${Math.round(n / 1e3)}k` : `$${n}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (n) => fmtMoney(n) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: "net",
									name: "Net worth",
									stroke: "#0E7C74",
									fill: "#0E7C74",
									fillOpacity: .15,
									strokeWidth: 2
								})
							]
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: "Earlier months use your books; this month uses today's investment prices."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
				title: "What you own",
				groups: HAVE_GROUPS,
				list: w.have,
				value: w.value,
				total: w.totalHave
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Side, {
				title: "What you owe",
				groups: OWE_GROUPS,
				list: w.owe,
				value: w.value,
				total: w.totalOwe
			})]
		})
	] });
}
function Big({ label, value, main }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-2xl border p-4", main ? "bg-[var(--section)] text-white" : "bg-card"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("text-xs", main ? "text-white/80" : "text-muted-foreground"),
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-3xl font-semibold tabular-nums",
			children: fmtMoney(value)
		})]
	});
}
function Side({ title, groups, list, value, total }) {
	const known = groups.flatMap((g) => g.kinds);
	const all = [...groups, {
		label: "Other",
		kinds: [...new Set(list.map((a) => a.kind))].filter((k) => !known.includes(k))
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex justify-between border-b bg-muted/40 px-4 py-2 font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: fmtMoney(total)
				})]
			}),
			all.map((g) => {
				const rows = list.filter((a) => g.kinds.includes(a.kind) && Math.abs(value(a)) > .004);
				if (!rows.length) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
						children: g.label
					}), rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: isInvestment(a) ? "/investments" : "/accounts/$id",
							params: { id: a.id },
							className: "hover:underline",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: fmtMoney(value(a))
						})]
					}, a.id))]
				}, g.label);
			}),
			list.every((a) => Math.abs(value(a)) <= .004) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-6 text-center text-sm text-muted-foreground",
				children: "Nothing yet. Add opening balances in Chart of Accounts, or bring in a statement in the Shoebox."
			})
		]
	});
}
//#endregion
export { NetWorth as component };
