import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as balFrom, f as useAccounts, i as accountLabel, u as loadTotals } from "./accounting-BZzWF9St.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { p as profitLoss } from "./reports-BrTLGjes.mjs";
import { a as YAxis, c as Line, d as Pie, f as Cell, h as Legend, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, r as PieChart, t as ComposedChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PlCharts-D-G9vwLq.js
var import_jsx_runtime = require_jsx_runtime();
var IN = "#178A5A";
var OUT = "#F28C38";
var NET = "#0F2A44";
var SLICES = [
	"#0E7C74",
	"#F28C38",
	"#3B6FD8",
	"#9B5DE5",
	"#E2B007",
	"#5B6B7F",
	"#C5CED8"
];
var short = (n) => {
	const a = Math.abs(n);
	const s = a >= 1e6 ? `${(a / 1e6).toFixed(1)}M` : a >= 1e3 ? `${(a / 1e3).toFixed(a >= 1e4 ? 0 : 1)}k` : a.toFixed(0);
	return `${n < 0 ? "-" : ""}$${s}`;
};
function months(from, to) {
	const out = [];
	const d = /* @__PURE__ */ new Date(`${from.slice(0, 7)}-01T12:00:00`);
	const end = to.slice(0, 7);
	while (d.toLocaleDateString("en-CA").slice(0, 7) <= end && out.length < 24) {
		const k = d.toLocaleDateString("en-CA").slice(0, 7);
		const last = new Date(d.getFullYear(), d.getMonth() + 1, 0, 12).toLocaleDateString("en-CA");
		out.push({
			from: k === from.slice(0, 7) ? from : `${k}-01`,
			to: k === end ? to : last,
			label: d.toLocaleDateString("en-US", { month: "short" })
		});
		d.setMonth(d.getMonth() + 1);
	}
	return out;
}
/** Charts over the Profit & Loss: money in and out by month, and where the money went. */
function PlCharts({ from, to, personal }) {
	const { data: accounts } = useAccounts();
	const cols = months(from, to);
	const { data, isLoading } = useQuery({
		queryKey: [
			"account-totals",
			"pl-charts",
			from,
			to
		],
		queryFn: async () => {
			const [whole, ...each] = await Promise.all([loadTotals(from, to), ...cols.map((c) => loadTotals(c.from, c.to))]);
			return {
				whole,
				each
			};
		}
	});
	if (isLoading || !data || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80 print:hidden" });
	const inLabel = personal ? "Money in" : "Income";
	const outLabel = personal ? "Spending" : "Expenses";
	const netLabel = personal ? "Left over" : "Profit";
	const byMonth = data.each.map((t, i) => {
		const r = profitLoss(accounts, balFrom(t));
		const income = r.sum(r.income) + r.sum(r.otherIncome);
		const spent = r.sum(r.cogs) + r.sum(r.expenses) + r.sum(r.otherExp);
		return {
			label: cols[i].label,
			[inLabel]: income,
			[outLabel]: spent,
			[netLabel]: income - spent
		};
	});
	const bal = balFrom(data.whole);
	const r = profitLoss(accounts, bal);
	const spentList = [
		...r.cogs,
		...r.expenses,
		...r.otherExp
	].map((a) => ({
		name: accountLabel(a),
		value: bal(a)
	})).filter((x) => x.value > .004).sort((a, b) => b.value - a.value);
	const top = spentList.slice(0, 6);
	const rest = spentList.slice(6).reduce((s, x) => s + x.value, 0);
	const slices = rest > 0 ? [...top, {
		name: "Everything else",
		value: rest
	}] : top;
	const totalSpent = slices.reduce((s, x) => s + x.value, 0);
	if (!byMonth.some((m) => m[inLabel] || m[outLabel])) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 print:hidden lg:grid-cols-[1.6fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-2 font-semibold",
				children: [
					inLabel,
					" and ",
					outLabel.toLowerCase(),
					" by month"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComposedChart, {
						data: byMonth,
						margin: {
							left: 4,
							right: 8,
							top: 4
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								strokeDasharray: "3 3",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								tickLine: false,
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tickFormatter: short,
								width: 56,
								fontSize: 12,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (v) => fmtMoney(v) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {
								iconType: "circle",
								wrapperStyle: { fontSize: 12 }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: inLabel,
								fill: IN,
								radius: [
									4,
									4,
									0,
									0
								],
								maxBarSize: 28
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: outLabel,
								fill: OUT,
								radius: [
									4,
									4,
									0,
									0
								],
								maxBarSize: 28
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								dataKey: netLabel,
								stroke: NET,
								strokeWidth: 2,
								dot: { r: 3 },
								type: "linear"
							})
						]
					})
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-semibold",
				children: "Where the money went"
			}), slices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Nothing spent in these dates."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-44 w-44 shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
							data: slices,
							dataKey: "value",
							nameKey: "name",
							innerRadius: "58%",
							outerRadius: "100%",
							paddingAngle: 1,
							stroke: "none",
							children: slices.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: SLICES[i % SLICES.length] }, i))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (v) => fmtMoney(v) })] })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "min-w-40 flex-1 space-y-1.5 text-sm",
					children: slices.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-2.5 w-2.5 shrink-0 rounded-full",
								style: { backgroundColor: SLICES[i % SLICES.length] },
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: s.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-muted-foreground",
								children: [Math.round(s.value / totalSpent * 100), "%"]
							})
						]
					}, s.name))
				})]
			})]
		})]
	});
}
//#endregion
export { PlCharts as t };
