import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as StockDocList } from "./StockDocList-CYMwNMAp.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/transfer-7hB67cjd.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockDocList, { kind: "transfer" });
//#endregion
export { SplitComponent as component };
