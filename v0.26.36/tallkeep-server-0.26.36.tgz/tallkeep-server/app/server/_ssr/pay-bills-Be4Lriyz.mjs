import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { i as fmtMoney, n as fmtDate } from "./format-CgElbAz-.mjs";
import { n as db, r as fetchAll } from "./db-vflE6hVn.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as today, i as accountLabel, p as useAccounts } from "./accounting-Bw29qbnY.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-lzWqdCJD.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-Yp0ZfJ76.mjs";
import { n as poOwed, t as fetchPos } from "./balances-D0KVpiPP.mjs";
import { i as payFromAccounts, r as nextCheckNumber, t as METHOD_LABEL } from "./money-BJBQLrrH.mjs";
import { t as DecimalInput } from "./DecimalInput-WTxAPvk_.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay-bills-Be4Lriyz.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function PayBills() {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const { data: accounts } = useAccounts();
	const { data, isLoading } = useQuery({
		queryKey: ["pay-bills"],
		queryFn: async () => {
			const [bills, pos, vendors] = await Promise.all([
				db.from("bills").select("id,vendor_id,vendor_name,ref,bill_date,due_date,balance,status").eq("status", "open").neq("balance", 0).limit(5e3),
				fetchPos("id,vendor_id,vendor_name,number,order_date,due_date,balance,status,stock_received_at"),
				fetchAll("vendors", "id,address")
			]);
			if (bills.error) throw bills.error;
			return {
				due: [...(bills.data ?? []).map((b) => ({
					key: `b${b.id}`,
					kind: "bill",
					id: b.id,
					vendor_id: b.vendor_id,
					vendor: b.vendor_name ?? "No vendor",
					ref: Number(b.balance) < 0 ? `Vendor credit${b.ref ? ` ${b.ref}` : ""}` : b.ref ? `Bill ${b.ref}` : "Bill",
					date: b.bill_date,
					due: b.due_date ?? b.bill_date,
					balance: Number(b.balance)
				})), ...pos.filter((p) => poOwed(p) > .005).map((p) => ({
					key: `p${p.id}`,
					kind: "po",
					id: p.id,
					vendor_id: p.vendor_id,
					vendor: p.vendor_name ?? "No vendor",
					ref: poOwed(p) < Number(p.balance) - .005 ? `${p.number} (part received)` : p.number,
					date: p.order_date.slice(0, 10),
					due: (p.due_date ?? p.order_date).slice(0, 10),
					balance: poOwed(p)
				}))].sort((a, b) => a.due.localeCompare(b.due)),
				address: new Map(vendors.map((v) => [v.id, v.address]))
			};
		}
	});
	const pay = payFromAccounts(accounts);
	const [pick, setPick] = (0, import_react.useState)({});
	const [date, setDate] = (0, import_react.useState)(today());
	const [from, setFrom] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("check");
	const [printLater, setPrintLater] = (0, import_react.useState)(true);
	const [firstNo, setFirstNo] = (0, import_react.useState)("");
	const [showAll, setShowAll] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!from && pay.length) setFrom((pay.find((a) => a.kind === "bank") ?? pay[0]).id);
	}, [pay, from]);
	(0, import_react.useEffect)(() => {
		if (from && method === "check" && !printLater) nextCheckNumber(from).then(setFirstNo);
	}, [
		from,
		method,
		printLater
	]);
	const list = (data?.due ?? []).filter((d) => showAll || d.due <= date);
	const chosen = (data?.due ?? []).filter((d) => pick[d.key] != null && pick[d.key] !== 0);
	const vendorsChosen = [...new Set(chosen.map((d) => d.vendor_id ?? d.vendor))];
	const total = chosen.reduce((s, d) => s + (pick[d.key] ?? 0), 0);
	async function run() {
		if (!from) return void toast.error("Choose which account pays.");
		if (!chosen.length) return void toast.error("Tick the bills to pay.");
		for (const v of vendorsChosen) if (chosen.filter((d) => (d.vendor_id ?? d.vendor) === v).reduce((s, d) => s + Math.round((pick[d.key] ?? 0) * 100), 0) < 0) {
			const who = chosen.find((d) => (d.vendor_id ?? d.vendor) === v)?.vendor;
			toast.error(`${who}: the credit used is more than the bills ticked. Tick more bills, or type a smaller amount next to the credit.`);
			return;
		}
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			let n = /^\d+$/.test(firstNo) ? Number(firstNo) : null;
			let made = 0;
			for (const v of vendorsChosen) {
				const items = chosen.filter((d) => (d.vendor_id ?? d.vendor) === v);
				const first = items[0];
				if (items.reduce((s, d) => s + Math.round((pick[d.key] ?? 0) * 100), 0) === 0) {
					const { error: e } = await db.from("bill_payments").insert(items.filter((d) => d.kind === "bill").map((d) => ({
						bill_id: d.id,
						paid_on: date,
						amount: Math.round(pick[d.key] * 100) / 100,
						account_id: from,
						method: "Credit applied",
						created_by: u.user?.id
					})));
					if (e) throw e;
					const pos0 = items.filter((d) => d.kind === "po");
					if (pos0.length) {
						const { error: e2 } = await db.from("payments").insert(pos0.map((d) => ({
							purchase_order_id: d.id,
							paid_on: date,
							amount: Math.round(pick[d.key] * 100) / 100,
							account_id: from,
							method: "Credit applied",
							created_by: u.user?.id
						})));
						if (e2) throw e2;
					}
					made++;
					continue;
				}
				const { data: c, error } = await db.from("checks").insert({
					account_id: from,
					method,
					number: method === "check" && !printLater && n != null ? String(n++) : null,
					check_date: date,
					vendor_id: first.vendor_id,
					payee: first.vendor,
					address: first.vendor_id ? data?.address.get(first.vendor_id) ?? null : null,
					memo: items.map((d) => d.ref).join(", ").slice(0, 120),
					to_print: method === "check" && printLater,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				const cid = c.id;
				const bills = items.filter((d) => d.kind === "bill");
				const pos = items.filter((d) => d.kind === "po");
				if (bills.length) {
					const { error: e } = await db.from("bill_payments").insert(bills.map((d) => ({
						bill_id: d.id,
						paid_on: date,
						amount: Math.round(pick[d.key] * 100) / 100,
						account_id: from,
						method: METHOD_LABEL[method],
						check_id: cid,
						created_by: u.user?.id
					})));
					if (e) throw e;
				}
				if (pos.length) {
					const { error: e } = await db.from("payments").insert(pos.map((d) => ({
						purchase_order_id: d.id,
						paid_on: date,
						amount: Math.round(pick[d.key] * 100) / 100,
						account_id: from,
						method: METHOD_LABEL[method],
						check_id: cid,
						created_by: u.user?.id
					})));
					if (e) throw e;
				}
				made++;
			}
			toast.success(`Paid ${chosen.length} item${chosen.length === 1 ? "" : "s"} with ${made} payment${made === 1 ? "" : "s"}.`);
			setPick({});
			qc.invalidateQueries();
			if (method === "check" && printLater) navigate({
				to: "/print-checks",
				search: {}
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Pay Bills",
			text: "Tick what to pay. One check (or payment) is made for each vendor, covering all of their bills you ticked. Vendor credits (green) come off that vendor's payment."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Pay from",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: from,
						options: pay.map((a) => ({
							value: a.id,
							label: accountLabel(a)
						})),
						onChange: (v) => {
							setFrom(v);
							if (pay.find((a) => a.id === v)?.kind === "credit_card") setMethod("card");
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "How",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: method,
						onChange: (e) => setMethod(e.target.value),
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						children: Object.entries(METHOD_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v
						}, k))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Payment date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})
				}),
				method === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: printLater,
							onChange: (e) => setPrintLater(e.target.checked)
						}), "Print the checks"]
					}), !printLater && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "First check number",
						value: firstNo,
						onChange: (e) => setFirstNo(e.target.value)
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: !showAll,
					onChange: (e) => setShowAll(!e.target.checked)
				}), "Only what's due by the payment date"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setPick(Object.fromEntries(list.map((d) => [d.key, d.balance]))),
					children: "Tick all"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setPick({}),
					children: "Clear"
				})]
			})]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [data && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "Nothing to pay."
			}), list.map((d) => {
				const on = pick[d.key] != null;
				const late = d.due < today();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: on,
							onChange: (e) => {
								const n = { ...pick };
								if (e.target.checked) if (d.balance >= 0) n[d.key] = d.balance;
								else {
									const v = d.vendor_id ?? d.vendor;
									const bills = (data?.due ?? []).filter((x) => (x.vendor_id ?? x.vendor) === v && x.key !== d.key).reduce((t, x) => t + (n[x.key] ?? 0), 0);
									const use = Math.min(-d.balance, Math.max(bills, 0));
									n[d.key] = -(use > .004 ? Math.round(use * 100) / 100 : -d.balance);
								}
								else delete n[d.key];
								setPick(n);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-24 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: late ? "font-medium text-destructive" : "",
								children: fmtDate(d.due)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: late ? "late" : "due"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [d.vendor, d.balance < 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 rounded bg-emerald-100 px-1.5 py-0.5 text-xs font-medium text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200",
									children: "Credit"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									d.kind === "bill" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/bills/$id",
										params: { id: d.id },
										search: {},
										className: "hover:underline",
										children: d.ref
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/po/$id",
										params: { id: d.id },
										search: {},
										className: "hover:underline",
										children: d.ref
									}),
									" ",
									"· ",
									fmtDate(d.date)
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-24 text-right",
							children: fmtMoney(d.balance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [d.balance < 0 && on && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "use"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DecimalInput, {
								money: true,
								"aria-label": d.balance < 0 ? `Credit to use from ${d.vendor}` : `Pay ${d.ref}`,
								className: "h-8 w-28 text-right",
								disabled: !on,
								value: on ? Math.abs(pick[d.key] ?? 0) : "",
								onValue: (v) => setPick({
									...pick,
									[d.key]: d.balance >= 0 ? Math.min(d.balance, Math.max(0, v)) : -Math.min(-d.balance, Math.max(0, v))
								})
							})]
						})
					]
				}, d.key);
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sticky bottom-2 flex flex-wrap items-center justify-end gap-3 rounded-2xl border bg-card p-3 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					chosen.length,
					" item",
					chosen.length === 1 ? "" : "s",
					", ",
					vendorsChosen.length,
					" vendor",
					vendorsChosen.length === 1 ? "" : "s",
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(total) })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void run(),
				disabled: busy || !chosen.length,
				children: busy ? "Paying…" : method === "check" && printLater ? "Pay and go print checks" : "Pay now"
			})]
		})
	] });
}
//#endregion
export { PayBills as component };
