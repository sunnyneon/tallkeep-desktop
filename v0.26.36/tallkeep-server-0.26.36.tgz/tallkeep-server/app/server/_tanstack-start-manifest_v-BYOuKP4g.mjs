//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BYOuKP4g.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-Bz9i8iWC.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-CV0pgiib.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-B_ij73Jr.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bz9i8iWC.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/options",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/po/",
			"/_authenticated/sales/",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-DhBHD0xJ.js",
			"/assets/log-out-Bmii-BAt.js",
			"/assets/testers.functions-CfdHjNuX.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-C7Ozpags.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DRTYVBld.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-BYIyXWJ5.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/dist-BFH27tfm.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/dist-BcAb6ivw.js",
			"/assets/dialog-C7UXXTtq.js",
			"/assets/queries-DNRh9lrp.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/label-CW4Pr_FF.js",
			"/assets/textarea-Cx3xWz4u.js",
			"/assets/shoebox-d_IAeNRc.js",
			"/assets/company-CVR9pnA_.js",
			"/assets/reports-BH-psWH4.js",
			"/assets/access-CHVKn_RG.js",
			"/assets/theme-CSeGuAhV.js",
			"/assets/Logo-CF6JKfQ-.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/coupons",
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-04rIODQo.js",
			"/assets/log-out-Bmii-BAt.js",
			"/assets/admin.functions-n0QEzWzl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/flask-conical-CoRklKsr.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-CF6JKfQ-.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DVPa5lQF.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/label-CW4Pr_FF.js",
			"/assets/Logo-CF6JKfQ-.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-SvAp6cVj.js",
			"/assets/testers.functions-CfdHjNuX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/coupons.functions-ComqhGa6.js",
			"/assets/buy.functions-iZ476neg.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-D9TOe3pi.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/downloads.functions-DFD5n_yF.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-BQGKOzKJ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/label-CW4Pr_FF.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-ChI-Jv3Y.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/label-CW4Pr_FF.js",
			"/assets/Logo-CF6JKfQ-.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-D2JW8--n.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/upgrade.functions-DyCEsVl7.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-BUnnDaOJ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/label-CW4Pr_FF.js",
			"/assets/Logo-CF6JKfQ-.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-D8k_Epu3.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Cwd2DmzY.js", "/assets/StockDocList-BSLnQdrJ.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-BMz05whF.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/ai-CMjnLVY7.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-ByvePL70.js",
			"/assets/BankConnections-D-D4WYb_.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-AbVbXq4u.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DAmpNdLJ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-D-D4WYb_.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/ai-CMjnLVY7.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-okQBG-Wy.js",
			"/assets/TxnEditor-6-LieT51.js",
			"/assets/feedWaiting-C6pmHF_9.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-CmcSvKBS.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/balances-B7NNbnZA.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-xqPAlOb6.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/personal-DaaeGYsg.js",
			"/assets/members-i_znXmA1.js",
			"/assets/WhoPicker-C0aHPgiH.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-E6e3Zdm2.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-CmoPe3kS.js", "/assets/AccountRegister-BDInQdvr.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-BbnrPnE6.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-DX-j9mBq.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/money-9BFLrVHk.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-D_3l5eE5.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CMjnLVY7.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-DRTm3NJH.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-D3tUhviC.js", "/assets/StockDocList-BSLnQdrJ.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-DHaG3lgr.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-CswJsPVQ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-i_znXmA1.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-B_ks8x-U.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-C2AnqWdk.js", "/assets/PartyList-1cj-n34Q.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DH7n5w6y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-CIw-q178.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/storage.functions-DjFcg-8j.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CaPfh7hS.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-BIzVK8yx.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-B2G5qytu.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-CD83NGmG.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BkEJU5-W.js", "/assets/ChangeHistory-BW22rSz4.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-NW45cg3g.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/members-i_znXmA1.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-D_beX8Fp.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/personal-DaaeGYsg.js",
			"/assets/members-i_znXmA1.js",
			"/assets/WhoPicker-C0aHPgiH.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-XiLHftPr.js", "/assets/SalesList-DegMC-_8.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-D-l1KUYX.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-BiveQciy.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BorLg6hG.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-SNSSRyEn.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/loans-okQBG-Wy.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CWNAX8Ca.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-Bo6rj6m5.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BXl_gY9c.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/personal-DaaeGYsg.js",
			"/assets/members-i_znXmA1.js",
			"/assets/WhoPicker-C0aHPgiH.js",
			"/assets/reminders-BkCjCgNN.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DHaIXx4Y.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-DKTWGqua.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/personal-DaaeGYsg.js",
			"/assets/members-i_znXmA1.js",
			"/assets/WhoPicker-C0aHPgiH.js",
			"/assets/generateCategoricalChart-Bys7DvcP.js",
			"/assets/Area-BKITs9ZN.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-Bkwshgpp.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/generateCategoricalChart-Bys7DvcP.js",
			"/assets/PlCharts-B2G5qytu.js",
			"/assets/BarChart-DL2BMKuv.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-DjcCOXW6.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/balances-B7NNbnZA.js",
			"/assets/money-9BFLrVHk.js",
			"/assets/DecimalInput-CVafzvDx.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-BbAj_KnZ.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CsIEQlLL.js",
			"/assets/createServerFn-D4GMkL2J.js",
			"/assets/auth-middleware-OoLtq_m_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/storage.functions-DjFcg-8j.js",
			"/assets/coupons.functions-ComqhGa6.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-uu2Z3xsM.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Ay-6t9Qc.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/DecimalInput-CVafzvDx.js",
			"/assets/StockDialogs-i8Ee7hQJ.js",
			"/assets/checkbox-sXajeKGz.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-D3byznLK.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-CX-z7G_N.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/purchasing-CMHfsQM0.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-R6dOUm13.js", "/assets/SalesList-DegMC-_8.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-d9DbbP-d.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/ai-CMjnLVY7.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DjFcg-8j.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BEKEz18L.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/money-9BFLrVHk.js",
			"/assets/badge-ZbV7tyke.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-DTQlWkoT.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BkvXEK9e.js", "/assets/AccountRegister-BDInQdvr.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BcnHWsl1.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/MoneyAccountPick-BshlaxQA.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-DowpL8DM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-DiUygxlj.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/RepeatInvoice-BiTvK0p-.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-F2hz3JLt.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/generateCategoricalChart-Bys7DvcP.js",
			"/assets/BarChart-DL2BMKuv.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-C_ZlXvIg.js", "/assets/SalesList-DegMC-_8.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-B63K3OO0.js", "/assets/SalesList-DegMC-_8.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-CDaEzrFZ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-Bze84RaW.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/serials-BOaV1ZOs.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-DS8D7n7o.js",
			"/assets/createServerFn-D4GMkL2J.js",
			"/assets/auth-middleware-OoLtq_m_.js",
			"/assets/AppsCatalog-CrlmWPYQ.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-DajLBDgx.js",
			"/assets/switch-Bo6rj6m5.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-B_ks8x-U.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-D6twEAug.js",
			"/assets/footers-B34sGe2E.js",
			"/assets/PrintFrame-CO2HIXgU.js",
			"/assets/checkbox-sXajeKGz.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BarhegP8.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CMXqN7Ca.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/AppsCatalog-CrlmWPYQ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/BankConnections-D-D4WYb_.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-D5kAto--.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/StockDialogs-i8Ee7hQJ.js",
			"/assets/photos-D6twEAug.js",
			"/assets/stockmove-wzpJ37AF.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DSrMF-f8.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/loans-okQBG-Wy.js",
			"/assets/feedWaiting-C6pmHF_9.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-DjFcg-8j.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CZFHYFAu.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/PrintFrame-CO2HIXgU.js",
			"/assets/DocPdf-B6kkWtR4.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-DqBy1hrr.js",
			"/assets/createServerFn-D4GMkL2J.js",
			"/assets/auth-middleware-OoLtq_m_.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/MoneyAccountPick-BshlaxQA.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BarhegP8.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-GsFzhe_m.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/StockDialogs-i8Ee7hQJ.js",
			"/assets/stockmove-wzpJ37AF.js",
			"/assets/checkbox-sXajeKGz.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-DbV5pbu3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/members-i_znXmA1.js",
			"/assets/WhoPicker-C0aHPgiH.js",
			"/assets/reminders-BkCjCgNN.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-iYdf_7YB.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/tickets.functions-g4ScwjyB.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-B2StXLv-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BarhegP8.js",
			"/assets/support.functions-Q2M9WwGY.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CPYVAflU.js", "/assets/StockDocList-BSLnQdrJ.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-kTTeriQ2.js", "/assets/PartyList-1cj-n34Q.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-n1drbsji.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/tickets.functions-g4ScwjyB.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-BY_Oaj0b.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/workorders-DfKIz55d.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-DlCjULpx.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/coupons": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/coupons.tsx",
		children: void 0,
		preloads: [
			"/assets/coupons-DvyGHiFp.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/coupons.functions-ComqhGa6.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-IsMQLdk2.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/AdminAccount-gVJk6d2q.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-Cj--tG1T.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/downloads.functions-DFD5n_yF.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-C0p8v0zQ.js",
			"/assets/createServerFn-D4GMkL2J.js",
			"/assets/auth-middleware-OoLtq_m_.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-Dg-Cp-ik.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-Btq8PYAN.js",
			"/assets/testers.functions-CfdHjNuX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-BwqpWWg9.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-BJxA6A4j.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-iZ476neg.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-SopmYEvB.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/textarea-Cx3xWz4u.js",
			"/assets/support.functions-Q2M9WwGY.js",
			"/assets/HelpParts-BtMjjQQr.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-DeUtSusl.js",
			"/assets/ManualFrame-Cd12EOJX.js",
			"/assets/manual._slug-GjlWNOzT.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-Dv0CrpkG.js",
			"/assets/createServerFn-D4GMkL2J.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Dj5U-Ord.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DyCEsVl7.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CP9qyyj0.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/smartphone-CxZHHcw0.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-CMjnLVY7.js",
			"/assets/personal-DaaeGYsg.js",
			"/assets/reminders-BkCjCgNN.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BNTjy2p2.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/AdminAccount-gVJk6d2q.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BaFoHWfU.js", "/assets/ManualFrame-Cd12EOJX.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-bG0KUtVx.js", "/assets/AccountRegister-BDInQdvr.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CReoDEAo.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/OriginalLink-gJjldfem.js",
			"/assets/bills-DVa9uNHT.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/realestate-DsNqLk90.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-C9EoWsbv.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/realestate-DsNqLk90.js",
			"/assets/money-9BFLrVHk.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-BRzaTU5i.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/booksStart-DLTNrqCA.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/SideList-D7Sa4BnT.js",
			"/assets/PartyHistory-ClPmTQes.js",
			"/assets/tabs-D2KlAxX8.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-XrK4QHjC.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/ChangeHistory-BW22rSz4.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/SideList-D7Sa4BnT.js",
			"/assets/purchasing-CMHfsQM0.js",
			"/assets/DecimalInput-CVafzvDx.js",
			"/assets/StockDialogs-i8Ee7hQJ.js",
			"/assets/NewProductDialog-D5IZ_WXG.js",
			"/assets/MoneyAccountPick-BshlaxQA.js",
			"/assets/footers-B34sGe2E.js",
			"/assets/PrintFrame-CO2HIXgU.js",
			"/assets/serials-BOaV1ZOs.js",
			"/assets/SerialsBox-D5Yi1fIK.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Bp7U69zP.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/move-right-BYvaeblp.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-BW22rSz4.js",
			"/assets/switch-Bo6rj6m5.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-ZbV7tyke.js",
			"/assets/SideList-D7Sa4BnT.js",
			"/assets/tabs-D2KlAxX8.js",
			"/assets/StockDialogs-i8Ee7hQJ.js",
			"/assets/photos-D6twEAug.js",
			"/assets/stockmove-wzpJ37AF.js",
			"/assets/serials-BOaV1ZOs.js",
			"/assets/SerialsBox-D5Yi1fIK.js",
			"/assets/workorders-DfKIz55d.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-IDyHmy1o.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-CtfV3uZg.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/ChangeHistory-BW22rSz4.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/booksStart-DLTNrqCA.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/SideList-D7Sa4BnT.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/DecimalInput-CVafzvDx.js",
			"/assets/NewProductDialog-D5IZ_WXG.js",
			"/assets/MoneyAccountPick-BshlaxQA.js",
			"/assets/footers-B34sGe2E.js",
			"/assets/PrintFrame-CO2HIXgU.js",
			"/assets/cardpay-BSU9lDQA.js",
			"/assets/checkbox-sXajeKGz.js",
			"/assets/serials-BOaV1ZOs.js",
			"/assets/workorders-DfKIz55d.js",
			"/assets/RepeatInvoice-BiTvK0p-.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-g4ScwjyB.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-8z8V-GxH.js",
			"/assets/select-DfKz8V-x.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/SideList-D7Sa4BnT.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-D_9vLkag.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/quickadd-CD7RmF4A.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-BarhegP8.js",
			"/assets/support.functions-Q2M9WwGY.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-DMtHiQjF.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-jCVIZxwY.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/SideList-D7Sa4BnT.js",
			"/assets/PartyHistory-ClPmTQes.js",
			"/assets/tabs-D2KlAxX8.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-CQL1EYI5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/accounting-BmHrCh-s.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/sales-DRTm3NJH.js",
			"/assets/footers-B34sGe2E.js",
			"/assets/tickets.functions-g4ScwjyB.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-ByBXrO4d.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/input-CJdRDjlv.js",
			"/assets/skeleton-ByHzGvHD.js",
			"/assets/AdminAccount-gVJk6d2q.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-B9AkT5hY.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ByFg8luQ.js",
			"/assets/button-vQIGhUwA.js",
			"/assets/textarea-Cx3xWz4u.js",
			"/assets/support-BarhegP8.js",
			"/assets/support.functions-Q2M9WwGY.js",
			"/assets/HelpParts-BtMjjQQr.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-D_CUPN1f.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-ByHzGvHD.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
