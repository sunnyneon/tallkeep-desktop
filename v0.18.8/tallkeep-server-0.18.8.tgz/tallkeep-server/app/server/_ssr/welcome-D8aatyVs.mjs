import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-C9I0PyVu.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { n as BUSINESS_TYPES, r as BUSINESS_TYPE_KEYS } from "./addons-8tQCpcOj.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Logo } from "./Logo-DIt5xzl6.mjs";
import { n as startTrial } from "./signup-BHUaC5c-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/welcome-D8aatyVs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** First stop for someone who signed up but has no company yet. */
function WelcomePage() {
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [company, setCompany] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("products");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data } = await supabase.auth.getUser();
			if (!data.user) return void navigate({
				to: "/auth",
				replace: true
			});
			const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id).limit(1);
			if (role?.length) return void navigate({
				to: "/",
				replace: true
			});
			const meta = data.user.user_metadata ?? {};
			if (typeof meta["company"] === "string") setCompany(meta["company"]);
			const t = meta["business_type"];
			if (typeof t === "string" && t in BUSINESS_TYPES) setType(t);
			setReady(true);
		})();
	}, [navigate]);
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			await startTrial(company.trim(), type);
			await qc.invalidateQueries();
			toast.success("Welcome to Tallkeep! Your 30 days start today.");
			navigate({
				to: "/",
				replace: true
			});
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-6 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { light: true }), ready && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-5 rounded-2xl border bg-card p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-bold",
						children: "Set up your company"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "One step left. Your free 30 days start when you press the button."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "company",
							children: "Company name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "company",
							required: true,
							value: company,
							onChange: (e) => setCompany(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "text-sm font-medium",
							children: "What does it do?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-2",
							children: BUSINESS_TYPE_KEYS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex cursor-pointer items-start gap-3 rounded-lg border p-3 text-sm ${type === k ? "border-primary bg-accent" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "radio",
									name: "type",
									checked: type === k,
									onChange: () => setType(k),
									className: "mt-1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: BUSINESS_TYPES[k].label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-muted-foreground",
									children: BUSINESS_TYPES[k].text
								})] })]
							}, k))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy || !company.trim(),
						className: "h-11 w-full text-base",
						children: busy ? "Setting up…" : "Open my company"
					})
				]
			})]
		})
	});
}
//#endregion
export { WelcomePage as component };
