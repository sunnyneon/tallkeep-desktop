import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, p as useTotals, u as loadTotals } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { c as monthName, d as table, f as thisMonth, i as amountIn, l as monthRange, p as useBudgets, r as addMonths, s as loadTotalsFor } from "./personal-BW24I9nu.mjs";
import { i as WandSparkles, lt as LoaderCircle, nn as ChevronRight, rn as ChevronLeft } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as useWho, i as useMembers, r as useAccountOwners } from "./members-CRgkIqM9.mjs";
import { t as WhoPicker } from "./WhoPicker-DJy3fIi-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/budget-lrw-BqVB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BudgetPage() {
	const qc = useQueryClient();
	const [ym, setYm] = (0, import_react.useState)(thisMonth());
	const [all, setAll] = (0, import_react.useState)(false);
	const [filling, setFilling] = (0, import_react.useState)(false);
	const { from, to } = monthRange(ym);
	const { data: accounts } = useAccounts();
	const { data: allTotals, isLoading } = useTotals(from, to);
	const [who] = useWho();
	const { data: owners } = useAccountOwners();
	const { data: members } = useMembers();
	const theirs = [...owners ?? []].filter(([, m]) => m === who).map(([a]) => a);
	const mine = useQuery({
		queryKey: [
			"totals-for",
			who,
			from,
			to,
			theirs.join()
		],
		enabled: !!who,
		queryFn: () => loadTotalsFor(from, to, theirs)
	});
	const totals = who ? mine.data : allTotals;
	const whoName = members?.find((m) => m.id === who)?.name;
	const { data: budgets } = useBudgets();
	const past = useQuery({
		queryKey: [
			"account-totals",
			monthRange(addMonths(ym, -3)).from,
			monthRange(addMonths(ym, -1)).to
		],
		queryFn: () => loadTotals(monthRange(addMonths(ym, -3)).from, monthRange(addMonths(ym, -1)).to)
	});
	const plan = (0, import_react.useMemo)(() => new Map((budgets ?? []).map((b) => [b.account_id, b])), [budgets]);
	const active = (accounts ?? []).filter((a) => a.is_active);
	const spendCats = active.filter((a) => a.type === "expense");
	const incomeCats = active.filter((a) => a.type === "income");
	async function save(a, amount) {
		const old = plan.get(a.id);
		if ((old?.amount ?? 0) === amount) return;
		const { error } = amount ? await table("budgets").upsert({
			account_id: a.id,
			amount
		}, { onConflict: "company_id,account_id" }) : await table("budgets").delete().eq("account_id", a.id);
		if (error) return void toast.error(error.message);
		qc.setQueryData(["budgets"], (l) => [...(l ?? []).filter((b) => b.account_id !== a.id), ...amount ? [{
			id: old?.id ?? a.id,
			account_id: a.id,
			amount
		}] : []]);
	}
	async function fill() {
		if (!past.data) return;
		setFilling(true);
		try {
			const rows = [...spendCats, ...incomeCats].filter((a) => !plan.get(a.id)).map((a) => ({
				account_id: a.id,
				amount: Math.round(amountIn(a, past.data) / 3 / 10) * 10
			})).filter((r) => r.amount > 0);
			if (!rows.length) return void toast("Nothing to fill: no spending in the last 3 months.");
			const { error } = await table("budgets").upsert(rows, { onConflict: "company_id,account_id" });
			if (error) throw new Error(error.message);
			await qc.invalidateQueries({ queryKey: ["budgets"] });
			toast.success(`Filled ${rows.length} categories from the last 3 months.`);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setFilling(false);
		}
	}
	const show = (l) => all ? l : l.filter((a) => plan.get(a.id) || Math.abs(amountIn(a, totals)) > .004);
	const sum = (l, f) => l.reduce((s, a) => s + f(a), 0);
	const planned = sum(spendCats, (a) => plan.get(a.id)?.amount ?? 0);
	const spent = sum(spendCats, (a) => amountIn(a, totals));
	const earned = sum(incomeCats, (a) => amountIn(a, totals));
	const plannedIn = sum(incomeCats, (a) => plan.get(a.id)?.amount ?? 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Budget",
			text: "Type how much you plan to spend in each category each month. Spending comes from your bank, card and check entries.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": "Month before",
						onClick: () => setYm(addMonths(ym, -1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-36 text-center font-medium",
						children: monthName(ym)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "icon",
						"aria-label": "Month after",
						onClick: () => setYm(addMonths(ym, 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
					}),
					ym !== thisMonth() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setYm(thisMonth()),
						children: "This month"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhoPicker, {}),
		whoName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "-mt-3 text-xs text-muted-foreground",
			children: [
				"Showing what was paid from ",
				whoName,
				"'s accounts. Budgets are for the whole household."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Came in",
					value: earned,
					note: plannedIn ? `of ${fmtMoney(plannedIn)} planned` : void 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Planned to spend",
					value: planned
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: "Spent",
					value: spent
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					label: planned - spent >= 0 ? "Left to spend" : "Over budget",
					value: Math.abs(planned - spent),
					bad: planned - spent < 0
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				onClick: () => void fill(),
				disabled: filling || !past.data,
				children: [filling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, { className: "h-4 w-4" }), "Fill empty budgets from the last 3 months"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: () => setAll(!all),
				children: all ? "Show only categories in use" : "Show all categories"
			})]
		}),
		isLoading || !accounts ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Spending",
				cats: show(spendCats),
				plan,
				got: (a) => amountIn(a, totals),
				onSave: save,
				spendWord: "Spent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Money coming in",
				cats: show(incomeCats),
				plan,
				got: (a) => amountIn(a, totals),
				onSave: save,
				spendWord: "Came in",
				income: true
			}),
			!show(spendCats).length && !show(incomeCats).length && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
				children: [
					"No spending this month yet. Press ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Show all categories" }),
					" to type budgets, or add entries in the Check Register or the Shoebox."
				]
			})
		] })
	] });
}
function Tile({ label, value, note, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-2xl font-semibold tabular-nums", bad && "text-destructive"),
				children: fmtMoney(value)
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: note
			})
		]
	});
}
function Section({ title, cats, plan, got, onSave, spendWord, income }) {
	if (!cats.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-2xl border bg-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "border-b bg-muted/40 px-4 py-2 font-semibold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden grid-cols-[minmax(0,2fr)_8rem_7rem_7rem_minmax(0,1.5fr)] gap-3 px-4 py-2 text-xs text-muted-foreground sm:grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Category" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Each month" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: spendWord
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: income ? "Still to come" : "Left"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
				]
			}),
			cats.map((a) => {
				const b = plan.get(a.id)?.amount ?? 0;
				const g = got(a);
				const left = b - g;
				const pct = b ? Math.min(100, Math.round(g / b * 100)) : g ? 100 : 0;
				const over = !income && b > 0 && g > b;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 items-center gap-x-3 gap-y-1 border-t px-4 py-2 text-sm sm:grid-cols-[minmax(0,2fr)_8rem_7rem_7rem_minmax(0,1.5fr)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/accounts/$id",
							params: { id: a.id },
							className: "col-span-2 truncate font-medium hover:underline sm:col-span-1",
							children: a.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": `${a.name} each month`,
							inputMode: "decimal",
							defaultValue: b ? String(b) : "",
							placeholder: "0",
							className: "h-8",
							onBlur: (e) => {
								const n = Number(e.target.value.replace(/[$,\s]/g, "") || 0);
								if (!Number.isFinite(n) || n < 0) return void toast.error("Type an amount, like 250.");
								onSave(a, Math.round(n * 100) / 100);
							},
							onKeyDown: (e) => e.key === "Enter" && e.target.blur()
						}, `${a.id}-${b}`),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right tabular-nums",
							children: fmtMoney(g)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-right tabular-nums", over && "font-semibold text-destructive"),
							children: b ? over ? `-${fmtMoney(-left)}` : fmtMoney(Math.max(0, left)) : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-span-2 h-2 overflow-hidden rounded-full bg-muted sm:col-span-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full", over ? "bg-destructive" : "bg-[var(--section)]"),
								style: { width: `${pct}%` }
							})
						})
					]
				}, a.id);
			})
		]
	});
}
//#endregion
export { BudgetPage as component };
