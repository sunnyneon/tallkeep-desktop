import { i as __toESM } from "../_runtime.mjs";
import { r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Kt as CreditCard, L as Printer, R as Plus } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as METHOD_LABEL } from "./money-uSYuy5S6.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/checks-BhJSU-TZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Checks() {
	const { data: accounts } = useAccounts();
	const [q, setQ] = (0, import_react.useState)("");
	const [acct, setAcct] = (0, import_react.useState)("");
	const { data, isLoading } = useQuery({
		queryKey: ["checks"],
		queryFn: async () => (await fetchAll("checks")).map((c) => ({
			...c,
			total: Number(c.total)
		}))
	});
	const name = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
	const rows = (0, import_react.useMemo)(() => {
		const list = (data ?? []).filter((c) => !acct || c.account_id === acct).sort((a, b) => b.check_date.localeCompare(a.check_date) || (b.number ?? "").localeCompare(a.number ?? ""));
		return smartSearch(list, q, (c) => c.payee ?? "", (c) => `${c.number ?? ""} ${c.memo ?? ""}`);
	}, [
		data,
		q,
		acct
	]);
	const toPrint = (data ?? []).filter((c) => c.to_print && c.status === "ok").length;
	const used = [...new Set((data ?? []).map((c) => c.account_id))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Checks & Payments",
			text: "Money paid out: checks, card charges, online payments and cash. Paying bills? Use Pay Bills to pay several at once.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/print-checks",
							search: {},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }),
								" Print checks",
								toPrint ? ` (${toPrint})` : ""
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/checks/$id",
							params: { id: "new" },
							search: { card: 1 },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-4 w-4" }), " Card charge"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/checks/$id",
							params: { id: "new" },
							search: {},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Write a check"]
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "max-w-xs",
				placeholder: "Search payee, number, memo",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: acct,
				onChange: (e) => setAcct(e.target.value),
				className: "h-9 rounded-md border bg-background px-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "All accounts"
				}), used.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: id,
					children: name.get(id)
				}, id))]
			})]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "Nothing paid out yet."
			}), rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/checks/$id",
				params: { id: c.id },
				search: {},
				className: "flex flex-wrap items-center gap-3 px-4 py-3 hover:bg-muted/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-24 text-xs",
						children: fmtDate(c.check_date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "w-28 text-xs",
						children: [METHOD_LABEL[c.method], c.number ? ` ${c.number}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: c.payee
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: [name.get(c.account_id), c.memo ? ` · ${c.memo}` : ""]
						})]
					}),
					c.status === "void" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						children: "Void"
					}),
					c.to_print && c.status === "ok" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "To print" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "w-28 text-right font-semibold",
						children: fmtMoney(c.total)
					})
				]
			}, c.id))]
		})
	] });
}
//#endregion
export { Checks as component };
