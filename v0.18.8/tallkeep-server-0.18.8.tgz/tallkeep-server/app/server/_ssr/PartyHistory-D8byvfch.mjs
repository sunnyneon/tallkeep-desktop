import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { D as Search } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { c as isRmaDoc, d as payStatus, n as PAY_STYLE, o as invStatus, t as INV_STYLE } from "./sales-CAB3s83f.mjs";
import { r as poPayStatus, t as poInvStatus } from "./purchasing-CjrJJbX-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PartyHistory-D8byvfch.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* A customer's quotes, invoices and RMAs, or a vendor's purchase orders, with quick filters and a
* search, on the customer or vendor page. The filters stay while you open a record and come back.
*/
/** For filters on a customer's or vendor's records (by name, including older imported ones). */
var nameMatch = (col, name) => `${col}.eq."${name.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
function Chips({ value, set, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: items.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => set(x.key),
			className: `rounded-full border px-3 py-1 text-sm font-medium ${value === x.key ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
			children: [
				x.label,
				" (",
				x.n,
				")"
			]
		}, x.key))
	});
}
function CustomerHistory({ docs, customerId }) {
	const [st, setSt] = useSticky(`customer-history:${customerId}`, {
		show: "all",
		q: ""
	});
	const kindOf = (d) => isRmaDoc(d) ? "rma" : d.status === "quote" ? "quotes" : "invoices";
	const owed = (d) => ["Unpaid", "Partial"].includes(payStatus(d));
	const count = (k) => k === "all" ? docs.length : k === "owed" ? docs.filter(owed).length : docs.filter((d) => kindOf(d) === k).length;
	const rows = (0, import_react.useMemo)(() => {
		const words = st.q.toLowerCase().split(/\s+/).filter(Boolean);
		return docs.filter((d) => (st.show === "all" || (st.show === "owed" ? owed(d) : kindOf(d) === st.show)) && words.every((w) => `${d.number} ${d.po_number ?? ""}`.toLowerCase().includes(w)));
	}, [docs, st]);
	const total = rows.filter((d) => d.status !== "quote" && d.status !== "cancelled").reduce((s, d) => s + Number(d.total), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
					value: st.show,
					set: (show) => setSt((x) => ({
						...x,
						show
					})),
					items: [
						{
							key: "all",
							label: "All",
							n: count("all")
						},
						{
							key: "quotes",
							label: "Quotes",
							n: count("quotes")
						},
						{
							key: "invoices",
							label: "Invoices",
							n: count("invoices")
						},
						{
							key: "rma",
							label: "RMAs",
							n: count("rma")
						},
						{
							key: "owed",
							label: "Still owed",
							n: count("owed")
						}
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:w-64",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-9",
						placeholder: "Search order # or PO #",
						value: st.q,
						onChange: (e) => setSt((x) => ({
							...x,
							q: e.target.value
						}))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Order #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "P.O. #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Inventory"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Balance"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 7,
							className: "p-6 text-center text-muted-foreground",
							children: "Nothing here."
						}) }), rows.map((d) => {
							const ps = payStatus(d);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-muted/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/sales/$id",
											params: { id: d.id },
											search: {},
											className: "font-medium text-primary",
											children: d.number
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: fmtDate(d.order_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[140px] truncate px-3 py-2",
										children: d.po_number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${INV_STYLE[invStatus(d)]}`,
											children: invStatus(d)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${PAY_STYLE[ps]}`,
											children: ps
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(d.total)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right font-semibold",
										children: ps === "Quote" ? "" : fmtMoney(d.balance)
									})
								]
							}, d.id);
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					rows.length,
					" shown",
					total ? ` · sales ${fmtMoney(total)}` : ""
				]
			})
		]
	});
}
function VendorHistory({ pos, vendorId }) {
	const [st, setSt] = useSticky(`vendor-history:${vendorId}`, {
		show: "all",
		q: ""
	});
	const isOpen = (p) => p.status !== "cancelled" && poInvStatus(p) === "Unfulfilled";
	const owed = (p) => ["Unpaid", "Partial"].includes(poPayStatus(p));
	const rows = (0, import_react.useMemo)(() => {
		const words = st.q.toLowerCase().split(/\s+/).filter(Boolean);
		return pos.filter((p) => (st.show === "all" || (st.show === "open" ? isOpen(p) : owed(p))) && words.every((w) => `${p.number} ${p.vendor_order_number ?? ""}`.toLowerCase().includes(w)));
	}, [pos, st]);
	const total = rows.filter((p) => p.status !== "cancelled").reduce((s, p) => s + Number(p.total), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chips, {
					value: st.show,
					set: (show) => setSt((x) => ({
						...x,
						show
					})),
					items: [
						{
							key: "all",
							label: "All",
							n: pos.length
						},
						{
							key: "open",
							label: "Not received yet",
							n: pos.filter(isOpen).length
						},
						{
							key: "owed",
							label: "Still owed",
							n: pos.filter(owed).length
						}
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative w-full sm:w-64",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-9",
						placeholder: "Search PO # or vendor order #",
						value: st.q,
						onChange: (e) => setSt((x) => ({
							...x,
							q: e.target.value
						}))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "PO #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Vendor order #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Inventory"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Balance"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 7,
							className: "p-6 text-center text-muted-foreground",
							children: "Nothing here."
						}) }), rows.map((p) => {
							const ps = poPayStatus(p);
							const inv = p.status === "cancelled" ? null : poInvStatus(p);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-muted/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/po/$id",
											params: { id: p.id },
											search: {},
											className: "font-medium text-primary",
											children: p.number
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: fmtDate(p.order_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[140px] truncate px-3 py-2",
										children: p.vendor_order_number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: inv && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${INV_STYLE[inv]}`,
											children: inv === "Fulfilled" ? "Received" : "Not received"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${PAY_STYLE[ps]}`,
											children: ps
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(p.total)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right font-semibold",
										children: fmtMoney(p.balance)
									})
								]
							}, p.id);
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					rows.length,
					" shown",
					total ? ` · ${fmtMoney(total)}` : ""
				]
			})
		]
	});
}
//#endregion
export { VendorHistory as n, nameMatch as r, CustomerHistory as t };
