import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/recurring-CtNHlYOs.js
var $$splitComponentImporter = () => import("./recurring-ChpDS_E2.mjs");
var Route = createFileRoute("/_authenticated/recurring")({
	validateSearch: (s) => typeof s["from"] === "string" ? { from: s["from"] } : {},
	head: () => ({ meta: [{ title: "Recurring · Tallkeep" }, {
		name: "description",
		content: "Payments and bills that repeat, like autopay."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
