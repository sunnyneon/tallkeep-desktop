import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { D as Search, Mn as ArrowDownUp, R as Plus } from "../_libs/lucide-react.mjs";
import { o as useLocations, t as byId } from "./queries-CUGyjerL.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { n as PAY_STYLE, t as INV_STYLE } from "./sales-CAB3s83f.mjs";
import { r as poPayStatus, t as poInvStatus } from "./purchasing-CjrJJbX-.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/purchase-orders-89zJZHnb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var QUICK = [
	{
		label: "All orders",
		f: {
			inv: "all",
			pay: "all",
			days: "all"
		}
	},
	{
		label: "Unreceived",
		f: {
			inv: "Unfulfilled",
			pay: "all",
			days: "all"
		}
	},
	{
		label: "Unpaid",
		f: {
			inv: "all",
			pay: "owed",
			days: "all"
		}
	},
	{
		label: "Recent (30 days)",
		f: {
			inv: "all",
			pay: "all",
			days: "30"
		}
	}
];
function POList() {
	const navigate = useNavigate();
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const [f, setF] = useSticky("po-list", {
		inv: "all",
		pay: "all",
		days: "all",
		cancelled: false
	});
	const [search, setSearch] = useSticky("po-search", {
		q: "",
		customer: "",
		vendor: ""
	});
	const q = search.q;
	const setQ = (v) => setSearch((x) => ({
		...x,
		q: v
	}));
	const [sort, setSort] = useSticky("po-sort", {
		k: "order_date",
		desc: true
	});
	const { data, isLoading } = useQuery({
		queryKey: ["pos", "all"],
		queryFn: async () => {
			const { data, error } = await db.from("purchase_orders").select("id,number,status,order_date,vendor_name,vendor_order_number,location_id,due_date,total,amount_paid,balance,stock_received_at").order("order_date", { ascending: false }).limit(5e3);
			if (error) throw error;
			return data ?? [];
		}
	});
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		const since = f.days === "all" ? 0 : Date.now() - Number(f.days) * 864e5;
		const ven = search.vendor.trim().toLowerCase();
		const list = (data ?? []).filter((r) => {
			if (r.status === "cancelled" && !f.cancelled) return false;
			if (f.inv !== "all" && poInvStatus(r) !== f.inv) return false;
			const ps = poPayStatus(r);
			if (f.pay === "owed" && !(ps === "Unpaid" || ps === "Partial")) return false;
			if (f.pay !== "all" && f.pay !== "owed" && ps !== f.pay) return false;
			if (since && new Date(r.order_date).getTime() < since) return false;
			if (ven && !(r.vendor_name ?? "").toLowerCase().includes(ven)) return false;
			const hay = `${r.number} ${r.vendor_name ?? ""} ${r.vendor_order_number ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
		const dir = sort.desc ? -1 : 1;
		return list.sort((a, b) => {
			const x = a[sort.k], y = b[sort.k];
			if (typeof x === "number" || typeof y === "number") return (Number(x) - Number(y)) * dir;
			return String(x ?? "").localeCompare(String(y ?? ""), void 0, { numeric: true }) * dir;
		});
	}, [
		data,
		q,
		search.vendor,
		f,
		sort
	]);
	const vendors = (0, import_react.useMemo)(() => [...new Set((data ?? []).map((r) => r.vendor_name).filter(Boolean))].sort((a, b) => a.localeCompare(b)), [data]);
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	const owed = rows.filter((r) => r.status !== "cancelled").reduce((s, r) => s + Number(r.balance), 0);
	const th = (k, label, right) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		className: `px-3 py-2 font-semibold ${right ? "text-right" : "text-left"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			className: "inline-flex items-center gap-1 hover:text-foreground",
			onClick: () => setSort((s) => ({
				k,
				desc: s.k === k ? !s.desc : true
			})),
			children: [label, sort.k === k && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownUp, { className: "h-3 w-3" })]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Purchase Order List",
				text: "What you ordered from vendors, what arrived and what you still owe.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/po/$id",
						params: { id: "new" },
						search: {},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New purchase order"]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: QUICK.map((x) => {
					const on = Object.entries(x.f).every(([k, v]) => f[k] === v);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => set(x.f),
						className: `rounded-full border px-3 py-1.5 text-sm font-medium ${on ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
						children: x.label
					}, x.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-[minmax(0,1fr)_220px_160px_160px_160px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search order #, vendor or vendor order #",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground",
							children: "Vendor:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							"aria-label": "Vendor",
							className: "pl-[4.5rem]",
							placeholder: "all",
							list: "po-list-vendors",
							value: search.vendor,
							onChange: (e) => setSearch((x) => ({
								...x,
								vendor: e.target.value
							}))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
						id: "po-list-vendors",
						children: vendors.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: v }, v))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.inv,
						onValueChange: (v) => set({ inv: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Inventory: all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Unfulfilled",
								children: "Not received"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Fulfilled",
								children: "Received"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.pay,
						onValueChange: (v) => set({ pay: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Payment: all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "owed",
								children: "Unpaid or partial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Unpaid",
								children: "Unpaid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Partial",
								children: "Partial"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "Paid",
								children: "Paid"
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.days,
						onValueChange: (v) => set({ days: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "all",
								children: "Any date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "30",
								children: "Last 30 days"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "90",
								children: "Last 90 days"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "365",
								children: "Last 12 months"
							})
						] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					rows.length,
					" shown",
					owed > 0 ? ` · we still owe ${fmtMoney(owed)}` : ""
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: f.cancelled,
							onChange: (e) => set({ cancelled: e.target.checked })
						}),
						" ",
						"Show cancelled"
					]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card md:hidden",
				children: rows.slice(0, 300).map((r) => {
					const ps = poPayStatus(r), is = poInvStatus(r);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/po/$id",
						params: { id: r.id },
						search: {},
						className: "flex items-center gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: r.vendor_name || "No vendor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										r.number,
										" · ",
										fmtDate(r.order_date)
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 flex gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded px-1.5 py-0.5 text-[10px] ${INV_STYLE[is]}`,
										children: is
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded px-1.5 py-0.5 text-[10px] ${PAY_STYLE[ps]}`,
										children: ps
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: fmtMoney(r.total)
						})]
					}, r.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-2xl border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							th("number", "Order #"),
							th("order_date", "Order date"),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Inventory"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Payment"
							}),
							th("vendor_name", "Vendor"),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Vendor order #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-left font-semibold",
								children: "Location"
							}),
							th("due_date", "Due date"),
							th("total", "Total", true),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right font-semibold",
								children: "Paid"
							}),
							th("balance", "Balance", true)
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
						className: "divide-y",
						children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 11,
							className: "p-8 text-center text-muted-foreground",
							children: "Nothing here."
						}) }), rows.slice(0, 500).map((r) => {
							const ps = poPayStatus(r), is = poInvStatus(r);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "cursor-pointer hover:bg-muted/50",
								onClick: () => navigate({
									to: "/po/$id",
									params: { id: r.id },
									search: {}
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 font-medium",
										style: { color: "var(--section)" },
										children: r.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: fmtDate(r.order_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${INV_STYLE[is]}`,
											children: is
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded px-1.5 py-0.5 text-xs ${PAY_STYLE[ps]}`,
											children: ps
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[260px] truncate px-3 py-2",
										children: r.vendor_name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "max-w-[140px] truncate px-3 py-2",
										children: r.vendor_order_number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2",
										children: r.location_id ? locName.get(r.location_id) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2",
										children: fmtDate(r.due_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(r.total)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right",
										children: fmtMoney(r.amount_paid)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "whitespace-nowrap px-3 py-2 text-right font-semibold",
										children: fmtMoney(r.balance)
									})
								]
							}, r.id);
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { POList as component };
