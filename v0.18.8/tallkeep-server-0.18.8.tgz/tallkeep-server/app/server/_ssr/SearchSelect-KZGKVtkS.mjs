import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { an as Check, en as ChevronsUpDown } from "../_libs/lucide-react.mjs";
import { n as PopoverContent, r as PopoverTrigger, t as Popover } from "./popover-Cmlz_mk1.mjs";
import { a as CommandItem, i as CommandInput, n as CommandEmpty, o as CommandList, t as Command$1 } from "./command--2jI_dfJ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/SearchSelect-KZGKVtkS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* A drop-down you can type in. Every word you type must match; names that start
* with what you typed come first. Use instead of a plain Select for long lists.
*/
function SearchSelect({ value, onChange, options, placeholder = "Choose", searchText = "Type to search", className, invalid, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const current = options.find((o) => o.value === value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				disabled,
				className: cn("w-full justify-between px-3 font-normal", !current && "text-muted-foreground", invalid && "border-destructive", className),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: current?.label ?? placeholder
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 shrink-0 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[max(var(--radix-popover-trigger-width),18rem)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, { placeholder: searchText }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "Nothing found." }), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
				value: `${o.label} ${o.value}`,
				onSelect: () => {
					onChange(o.value);
					setOpen(false);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: cn("h-4 w-4", o.value === value ? "opacity-100" : "opacity-0") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex-1 truncate",
						children: o.label
					}),
					o.hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: o.hint
					})
				]
			}, o.value))] })] })
		})]
	});
}
//#endregion
export { SearchSelect as t };
