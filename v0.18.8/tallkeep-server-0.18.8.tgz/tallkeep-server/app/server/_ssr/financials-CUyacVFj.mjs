import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-8tQCpcOj.mjs";
import { C as useRouter, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, d as today, f as useAccounts, i as accountLabel, m as yearStart, p as useTotals, u as loadTotals } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, Ut as Download } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as downloadCsv } from "./csv-D0ewwTlm.mjs";
import { n as TABS, t as Route } from "./financials-CideDR94.mjs";
import { _ as v1099Csv, c as load1099, d as loadSplit, f as loadTaxRows, g as trialBalance, h as threshold1099, i as balanceSheet, l as loadLedger, m as salesTax, n as SOURCE_NAME, o as ledger, p as profitLoss, r as aging, s as ledgerOpenRange, t as BUCKETS, u as loadOpen } from "./reports-Ba6xoNML.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/financials-CUyacVFj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Personal books: the reports that make sense at home, in household words. */
var PERSONAL_TABS = [
	{
		k: "pl",
		label: "Income & Spending"
	},
	{
		k: "pm",
		label: "By month / vs last year"
	},
	{
		k: "bs",
		label: "What you own & owe"
	},
	{
		k: "ebv",
		label: "Spending by payee"
	},
	{
		k: "gl",
		label: "All transactions"
	}
];
var RANGE = [
	"pl",
	"pm",
	"gl",
	"tax",
	"v1099",
	"sbc",
	"ebv"
];
function Financials() {
	const search = Route.useSearch();
	const [tab, setTab] = (0, import_react.useState)(search.tab ?? "pl");
	const [from, setFrom] = (0, import_react.useState)(search.from ?? yearStart());
	const [to, setTo] = (0, import_react.useState)(search.to ?? today());
	const range = RANGE.includes(tab);
	const { data: features } = useFeatures();
	const personal = !!features?.includes("personal");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: personal ? "Money Reports" : "Financial Reports",
				text: personal ? "Where your money came from and where it went, and what you own and owe. Print or download for your tax preparer." : "Made from the books automatically. Print or download for your accountant."
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-3 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex flex-wrap rounded-lg border p-0.5 text-sm",
					children: (personal ? PERSONAL_TABS : TABS).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t.k),
						className: `rounded-md px-3 py-1 ${tab === t.k ? "bg-[var(--section)] text-white" : ""}`,
						children: t.label
					}, t.k))
				}),
				range && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: from,
						onChange: (e) => setFrom(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "space-y-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted-foreground",
						children: range ? "To" : "As of"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: to,
						onChange: (e) => setTo(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: () => window.print(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print or save PDF"]
				})
			]
		}),
		tab === "pl" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfitLoss, {
			from,
			to,
			personal
		}),
		tab === "bs" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalanceSheet, {
			asOf: to,
			personal
		}),
		tab === "tb" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrialBalance, { asOf: to }),
		tab === "gl" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GeneralLedger, {
			from,
			to
		}),
		tab === "ar" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aging, {
			kind: "ar",
			asOf: to
		}),
		tab === "ap" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aging, {
			kind: "ap",
			asOf: to
		}),
		tab === "tax" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesTax, {
			from,
			to
		}),
		tab === "v1099" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vendors1099, {
			from,
			to
		}),
		tab === "pm" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlColumns, {
			from,
			to
		}),
		tab === "sbc" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalesByCustomer, {
			from,
			to
		}),
		tab === "ebv" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpensesByVendor, {
			from,
			to
		})
	] });
}
function Sheet({ title, sub, onCsv, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl rounded-2xl border bg-card p-6 print:border-0 print:p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: sub
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				className: "print:hidden",
				onClick: onCsv,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download CSV"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm",
			children
		})]
	});
}
function Row({ label, value, bold, indent, line, account, from, to }) {
	const cls = `flex justify-between py-1 ${bold ? "font-semibold" : ""} ${line ? "mt-1 border-t pt-2" : ""} ${indent ? "pl-4" : ""}`;
	if (account) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/accounts/$id",
		params: { id: account },
		search: {
			...from ? { from } : {},
			...to ? { to } : {}
		},
		className: `${cls} -mx-2 rounded px-2 hover:bg-muted hover:text-[var(--section)] ${indent ? "pl-6" : ""}`,
		title: "See the transactions",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums underline-offset-2 hover:underline",
			children: fmtMoney(value)
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cls,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: fmtMoney(value)
		})]
	});
}
function useBalances(from, to) {
	const { data: accounts, isLoading: a } = useAccounts();
	const { data: totals, isLoading: b } = useTotals(from, to);
	return {
		accounts: accounts ?? [],
		bal: balFrom(totals),
		loading: a || b
	};
}
var Failed = ({ error }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
	className: "rounded-2xl border bg-card p-6 text-sm text-destructive",
	children: error.message
});
function ProfitLoss({ from, to, personal }) {
	const { accounts, bal, loading } = useBalances(from, to);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const r = profitLoss(accounts, bal);
	const section = (title, list, total) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: title
			}),
			list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				from,
				to
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: total,
				value: r.sum(list),
				bold: true,
				line: true
			})
		]
	});
	return personal ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Income & Spending",
		sub: `${fmtDate(from)} to ${fmtDate(to)}`,
		onCsv: () => downloadCsv(`income-and-spending-${from}-to-${to}`, r.csv()),
		children: [
			section("Money in", [...r.income, ...r.otherIncome], "Total money in"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: section("Spending", [
					...r.cogs,
					...r.expenses,
					...r.otherExp
				], "Total spending")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-lg bg-muted/50 px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: r.net >= 0 ? "Left over (saved)" : "Spent more than came in",
					value: r.net,
					bold: true
				})
			})
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Profit & Loss",
		sub: `${fmtDate(from)} to ${fmtDate(to)}`,
		onCsv: () => downloadCsv(`profit-and-loss-${from}-to-${to}`, r.csv()),
		children: [
			section("Income", r.income, "Total income"),
			section("Cost of goods sold", r.cogs, "Total cost of goods"),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Gross profit",
				value: r.gross,
				bold: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: section("Expenses", r.expenses, "Total expenses")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Operating profit",
				value: r.operating,
				bold: true
			}),
			(r.otherIncome.length > 0 || r.otherExp.length > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [r.otherIncome.length > 0 && section("Other income", r.otherIncome, "Total other income"), r.otherExp.length > 0 && section("Other expenses", r.otherExp, "Total other expenses")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-lg bg-muted/50 px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Net profit",
					value: r.net,
					bold: true
				})
			})
		]
	});
}
function BalanceSheet({ asOf, personal }) {
	const all = useBalances(null, asOf);
	const year = useBalances(`${asOf.slice(0, 4)}-01-01`, asOf);
	if (all.loading || year.loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const { bal } = all;
	const r = balanceSheet(all.accounts, bal, year.bal);
	if (personal) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "What you own & owe",
		sub: `As of ${fmtDate(asOf)}`,
		onCsv: () => downloadCsv(`own-and-owe-${asOf}`, r.csv()),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "What you own"
			}),
			r.assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				to: asOf
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Total you own",
				value: r.totalAssets,
				bold: true,
				line: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-semibold",
				children: "What you owe"
			}),
			r.liabilities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				to: asOf
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Total you owe",
				value: r.sum(r.liabilities),
				bold: true,
				line: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-lg bg-muted/50 px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Net worth",
					value: r.totalAssets - r.sum(r.liabilities),
					bold: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted-foreground",
				children: "From your books. Net Worth (under My Money) also counts investments at today's prices."
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Balance Sheet",
		sub: `As of ${fmtDate(asOf)}`,
		onCsv: () => downloadCsv(`balance-sheet-${asOf}`, r.csv()),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				children: "Assets"
			}),
			r.assets.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				to: asOf
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Total assets",
				value: r.totalAssets,
				bold: true,
				line: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-semibold",
				children: "Liabilities"
			}),
			r.liabilities.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				to: asOf
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Total liabilities",
				value: r.sum(r.liabilities),
				bold: true,
				line: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-semibold",
				children: "Equity"
			}),
			r.equity.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: accountLabel(a),
				value: bal(a),
				indent: true,
				account: a.id,
				to: asOf
			}, a.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Retained earnings (earlier years)",
				value: r.prior,
				indent: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Net profit (this year)",
				value: r.netYear,
				indent: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Total equity",
				value: r.totalEquity,
				bold: true,
				line: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 rounded-lg bg-muted/50 px-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Total liabilities and equity",
					value: r.totalLE,
					bold: true
				})
			}),
			r.off !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-destructive",
				children: [
					"Assets and liabilities + equity differ by ",
					fmtMoney(r.off),
					". Press \"Rebuild the books\" in Settings → Accounting."
				]
			})
		]
	});
}
function TrialBalance({ asOf }) {
	const { data: accounts, isLoading } = useAccounts();
	const { data: split, isLoading: l2 } = useQuery({
		queryKey: [
			"account-totals",
			"split",
			asOf
		],
		queryFn: () => loadSplit(null, asOf)
	});
	if (isLoading || l2 || !split) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const r = trialBalance(accounts ?? [], split);
	const m = (n) => n ? fmtMoney(n) : "";
	const th = "py-1 text-right font-medium";
	const td = "py-1 text-right tabular-nums";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: r.hasAdj ? "Adjusted Trial Balance" : "Trial Balance",
		sub: `As of ${fmtDate(asOf)}${r.hasAdj ? " · with your accountant's adjustments" : ""}`,
		onCsv: () => downloadCsv(`trial-balance-${asOf}`, r.csv()),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("thead", {
					className: "text-xs text-muted-foreground",
					children: [r.hasAdj && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							colSpan: 2,
							className: "text-center font-medium",
							children: "Before adjustments"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							colSpan: 2,
							className: "text-center font-medium",
							children: "Adjustments"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							colSpan: 2,
							className: "text-center font-medium",
							children: "Adjusted"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-left font-medium",
							children: "Account"
						}),
						r.hasAdj && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: th,
								children: "Debit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: th,
								children: "Credit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: th,
								children: "Debit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: th,
								children: "Credit"
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: th,
							children: "Debit"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: th,
							children: "Credit"
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [r.rows.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 pr-2",
							children: accountLabel(x.a)
						}),
						r.hasAdj && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: m(x.before.dr)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: m(x.before.cr)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: m(x.adj.dr)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: m(x.adj.cr)
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: m(x.after.dr)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: m(x.after.cr)
						})
					]
				}, x.a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t-2 font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1",
							children: "Total"
						}),
						r.hasAdj && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: fmtMoney(r.total("before", "dr"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: fmtMoney(r.total("before", "cr"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: fmtMoney(r.total("adj", "dr"))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: td,
								children: fmtMoney(r.total("adj", "cr"))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: fmtMoney(r.total("after", "dr"))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: fmtMoney(r.total("after", "cr"))
						})
					]
				})] })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-xs text-muted-foreground print:hidden",
			children: [
				"Adjustments from your accountant go in",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/journal",
					search: { adjust: 1 },
					className: "underline",
					children: "Journal Entries → Accountant adjustment"
				}),
				"."
			]
		})]
	});
}
function GeneralLedger({ from, to }) {
	const router = useRouter();
	const { data: accounts, isLoading } = useAccounts();
	const [only, setOnly] = (0, import_react.useState)("");
	const { data, isLoading: l2, error } = useQuery({
		queryKey: [
			"account-totals",
			"ledger",
			from,
			to
		],
		queryFn: async () => {
			const r = ledgerOpenRange(from);
			const [lines, openAll, openYear] = await Promise.all([
				loadLedger(from, to),
				loadTotals(null, r.before),
				loadTotals(r.yearStart, r.before)
			]);
			return {
				lines,
				openAll,
				openYear
			};
		}
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	if (isLoading || l2 || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const r = ledger(accounts ?? [], data.lines, data.openAll, data.openYear);
	const shown = only ? r.groups.filter((g) => g.a.id === only) : r.groups;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl rounded-2xl border bg-card p-6 print:border-0 print:p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-semibold",
					children: "General Ledger"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						fmtDate(from),
						" to ",
						fmtDate(to),
						" · every line in the books, by account"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 print:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: only,
						onChange: (e) => setOnly(e.target.value),
						className: "h-9 rounded-md border bg-background px-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All accounts"
						}), r.groups.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: g.a.id,
							children: accountLabel(g.a)
						}, g.a.id))]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => downloadCsv(`general-ledger-${from}-to-${to}`, r.csv()),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download CSV"]
					})]
				})]
			}),
			shown.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-4 text-center text-sm text-muted-foreground",
				children: "Nothing in these dates."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5 text-sm",
				children: shown.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-x-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: accountLabel(g.a)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs sm:text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Date"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Number"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Name / memo"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Debit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Credit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Balance"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1",
									colSpan: 6,
									children: "Starting balance"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(g.opening)
								})]
							}),
							g.rows.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "cursor-pointer border-t hover:bg-muted",
								title: "Open this transaction",
								onClick: () => router.history.push(`/go/entry/${l.entry_id}`),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-2 whitespace-nowrap",
										children: fmtDate(l.entry_date)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-2",
										children: SOURCE_NAME[l.source_type] ?? l.source_type
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-2",
										children: l.ref
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 pr-2",
										children: [l.name, l.memo].filter(Boolean).join(" · ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right tabular-nums",
										children: l.debit ? fmtMoney(l.debit) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right tabular-nums",
										children: l.credit ? fmtMoney(l.credit) : ""
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1 text-right tabular-nums",
										children: fmtMoney(l.balance)
									})
								]
							}, l.line_id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1",
									colSpan: 6,
									children: "Ending balance"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(g.closing)
								})]
							})
						] })]
					})]
				}, g.a.id))
			})
		]
	});
}
function Aging({ kind, asOf }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["aging", kind],
		queryFn: () => loadOpen(kind)
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	const r = aging(kind, data ?? [], asOf);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: kind === "ar" ? "Who owes us (A/R aging)" : "What we owe (A/P aging)",
		sub: `As of ${fmtDate(asOf)} · ${fmtMoney(r.grand)} in total`,
		onCsv: () => downloadCsv(`${kind}-aging-${asOf}`, r.csv()),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-xs sm:text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-left font-medium",
							children: kind === "ar" ? "Customer" : "Vendor"
						}),
						BUCKETS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-right font-medium",
							children: b
						}, b)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-right font-medium",
							children: "Total"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [r.list.map(([w, b]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 pr-2",
							children: w
						}),
						b.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: `py-1 text-right tabular-nums ${i >= 3 && x > 0 ? "text-destructive" : ""}`,
							children: x ? fmtMoney(x) : ""
						}, i)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 text-right font-medium tabular-nums",
							children: fmtMoney(r.sum(b))
						})
					]
				}, w)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t-2 font-semibold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1",
							children: "Total"
						}),
						r.totals.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 text-right tabular-nums",
							children: fmtMoney(x)
						}, i)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 text-right tabular-nums",
							children: fmtMoney(r.grand)
						})
					]
				})] })]
			})
		}), r.list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-4 text-center text-muted-foreground",
			children: "Nothing owed."
		})]
	});
}
function SalesTax({ from, to }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["sales-tax"],
		queryFn: loadTaxRows
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	const r = salesTax(data ?? [], from, to);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		title: "Sales tax",
		sub: `${fmtDate(from)} to ${fmtDate(to)} · invoices by invoice date`,
		onCsv: () => downloadCsv(`sales-tax-${from}-to-${to}`, r.csv()),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-left font-medium",
						children: "Tax"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Invoices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Sales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Taxable sales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Tax collected"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [r.list.map(([k, g]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1",
						children: k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: g.count
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(g.sales)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(g.taxable)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(g.tax)
					})
				]
			}, k)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t-2 font-semibold",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1",
						children: "Total"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: r.count
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(r.t.sales)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(r.t.taxable)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(r.t.tax)
					})
				]
			})] })]
		})
	});
}
function Vendors1099({ from, to }) {
	const { data, isLoading, error } = useQuery({
		queryKey: [
			"vendors-1099",
			from,
			to
		],
		queryFn: () => load1099(from, to)
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	const limit = threshold1099(Number(to.slice(0, 4)));
	const rows = data ?? [];
	const need = rows.filter((v) => v.is_1099 && v.counted >= limit);
	const check = rows.filter((v) => !v.is_1099 && v.counted >= limit);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "1099 vendors",
		sub: `${fmtDate(from)} to ${fmtDate(to)} · ${need.length} need a 1099`,
		onCsv: () => downloadCsv(`1099-vendors-${from}-to-${to}`, v1099Csv(rows, limit)),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 text-muted-foreground",
				children: [
					"A vendor you marked \"gets a 1099\" and paid ",
					fmtMoney(limit),
					" or more (not counting credit card payments) needs a Form 1099-NEC. Mark vendors on their page → Details. Your accountant has the final say on who needs one."
				]
			}),
			check.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 rounded-lg bg-amber-50 p-2 text-amber-900 dark:bg-amber-950 dark:text-amber-200",
				children: [
					check.length,
					" vendor",
					check.length > 1 ? "s" : "",
					" you paid ",
					fmtMoney(limit),
					" or more",
					" ",
					check.length > 1 ? "aren't" : "isn't",
					" marked. If they are a person or a company that does services for you (not a corporation selling goods), ask your accountant."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-xs sm:text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "Vendor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "Tax ID"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-left font-medium",
								children: "1099?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "Paid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "By card"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-1 text-right font-medium",
								children: "Counts"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((v) => {
						const needs = v.is_1099 && v.counted >= limit;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: `border-t ${needs ? "font-semibold" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 pr-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/vendors/$id",
										params: { id: v.id },
										className: "hover:underline",
										children: v.name
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: `py-1 pr-2 ${needs && !v.tax_id ? "text-destructive" : ""}`,
									children: v.tax_id ?? (needs ? "Missing" : "")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 pr-2",
									children: v.is_1099 ? needs ? "Needs one" : "Yes" : "No"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(v.paid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: v.by_card ? fmtMoney(v.by_card) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(v.counted)
								})
							]
						}, v.id);
					}) })]
				})
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-4 text-center text-muted-foreground",
				children: "No vendor payments in these dates."
			})
		]
	});
}
var monthsBetween = (from, to) => {
	const out = [];
	const d = /* @__PURE__ */ new Date(`${from.slice(0, 7)}-01T12:00:00`);
	const end = to.slice(0, 7);
	while (d.toLocaleDateString("en-CA").slice(0, 7) <= end && out.length < 24) {
		const k = d.toLocaleDateString("en-CA").slice(0, 7);
		const last = new Date(d.getFullYear(), d.getMonth() + 1, 0, 12).toLocaleDateString("en-CA");
		out.push({
			key: k,
			from: k === from.slice(0, 7) ? from : `${k}-01`,
			to: k === end ? to : last,
			label: d.toLocaleDateString("en-US", {
				month: "short",
				year: "2-digit"
			})
		});
		d.setMonth(d.getMonth() + 1);
	}
	return out;
};
var lastYear = (iso) => `${Number(iso.slice(0, 4)) - 1}${iso.slice(4)}`;
function PlColumns({ from, to }) {
	const [mode, setMode] = (0, import_react.useState)("month");
	const { data: accounts } = useAccounts();
	const cols = mode === "month" ? monthsBetween(from, to) : [{
		key: "now",
		from,
		to,
		label: `${fmtDate(from)} – ${fmtDate(to)}`
	}, {
		key: "last",
		from: lastYear(from),
		to: lastYear(to),
		label: "Same dates last year"
	}];
	const { data, isLoading } = useQuery({
		queryKey: [
			"account-totals",
			"pl-cols",
			mode,
			from,
			to
		],
		queryFn: () => Promise.all(cols.map((c) => loadTotals(c.from, c.to)))
	});
	if (isLoading || !data || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const bals = data.map((t) => balFrom(t));
	const plOf = (b) => profitLoss(accounts, b);
	const pls = bals.map(plOf);
	const sections = [
		{
			title: "Income",
			kinds: ["income"],
			sign: 1
		},
		{
			title: "Cost of goods sold",
			kinds: ["cogs"],
			sign: -1
		},
		{
			title: "Expenses",
			kinds: ["expense"],
			sign: -1
		},
		{
			title: "Other income",
			kinds: ["other_income"],
			sign: 1
		},
		{
			title: "Other expenses",
			kinds: ["other_expense"],
			sign: -1
		}
	].map((k) => ({
		...k,
		rows: accounts.filter((a) => k.kinds.includes(a.kind) && bals.some((b) => Math.abs(b(a)) > .004))
	})).filter((k) => k.rows.length);
	const showChange = mode === "year";
	const change = (a, b) => Math.abs(b) < .005 ? "" : `${((a - b) / Math.abs(b) * 100).toFixed(0)}%`;
	const csv = () => {
		const rows = [[
			"Account",
			...cols.map((c) => c.label),
			...showChange ? ["Change"] : []
		]];
		for (const sec of sections) {
			for (const a of sec.rows) rows.push([accountLabel(a), ...bals.map((b) => b(a))]);
			rows.push([`Total ${sec.title.toLowerCase()}`, ...bals.map((b) => sec.rows.reduce((s, a) => s + b(a), 0))]);
		}
		rows.push(["Net profit", ...pls.map((p) => p.net)]);
		downloadCsv(`profit-and-loss-${mode === "month" ? "by-month" : "vs-last-year"}-${from}-to-${to}`, rows);
	};
	const th = "px-2 py-1 text-right font-medium whitespace-nowrap";
	const td = "px-2 py-1 text-right tabular-nums whitespace-nowrap";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border bg-card p-4 sm:p-6 print:border-0 print:p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-xl font-semibold",
				children: ["Profit & Loss ", mode === "month" ? "by month" : "compared with last year"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					fmtDate(from),
					" to ",
					fmtDate(to),
					mode === "month" && cols.length >= 24 ? " (first 24 months)" : ""
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex rounded-lg border p-0.5 text-sm",
					children: [["month", "By month"], ["year", "This vs last year"]].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setMode(k),
						className: `rounded-md px-3 py-1 ${mode === k ? "bg-[var(--section)] text-white" : ""}`,
						children: l
					}, k))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: csv,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }), " Download CSV"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-xs sm:text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 pr-2 text-left font-medium",
							children: "Account"
						}),
						cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: th,
							children: c.label
						}, c.key)),
						showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: th,
							children: "Change"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [sections.map((sec) => {
					const tot = bals.map((b) => sec.rows.reduce((s, a) => s + b(a), 0));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: cols.length + 2,
							className: "pt-3 font-semibold",
							children: sec.title
						}) }),
						sec.rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 pr-2 pl-3",
									children: accountLabel(a)
								}),
								bals.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: td,
									children: fmtMoney(b(a))
								}, i)),
								showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: td,
									children: change(bals[0](a), bals[1](a))
								})
							]
						}, a.id)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-1 pr-2",
									children: ["Total ", sec.title.toLowerCase()]
								}),
								tot.map((x, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: td,
									children: fmtMoney(x)
								}, i)),
								showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: td,
									children: change(tot[0], tot[1])
								})
							]
						})
					] }, sec.title);
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t-2 bg-muted/50 font-bold",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 pr-2",
							children: "Net profit"
						}),
						pls.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: fmtMoney(p.net)
						}, i)),
						showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: change(pls[0].net, pls[1].net)
						})
					]
				})] })]
			})
		})]
	});
}
function SalesByCustomer({ from, to }) {
	const { data, isLoading, error } = useQuery({
		queryKey: ["sales-by-customer"],
		queryFn: async () => {
			const out = [];
			for (let i = 0;; i += 1e3) {
				const { data, error } = await db.from("sales_orders").select("customer_name,number,invoice_date,order_date,total,tax,balance,status").in("status", [
					"invoiced",
					"paid",
					"completed"
				]).range(i, i + 999);
				if (error) throw error;
				out.push(...data ?? []);
				if (!data || data.length < 1e3) break;
			}
			return out;
		}
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	const by = /* @__PURE__ */ new Map();
	for (const o of data ?? []) {
		const d = (o.invoice_date ?? o.order_date).slice(0, 10);
		if (d < from || d > to || o.number.startsWith("RMA-")) continue;
		const k = o.customer_name || "No customer";
		const g = by.get(k) ?? {
			count: 0,
			sales: 0,
			owed: 0
		};
		g.count += 1;
		g.sales += Number(o.total) - Number(o.tax);
		g.owed += Number(o.balance);
		by.set(k, g);
	}
	const list = [...by.entries()].sort((a, b) => b[1].sales - a[1].sales);
	const total = list.reduce((s, [, g]) => s + g.sales, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Sales by customer",
		sub: `${fmtDate(from)} to ${fmtDate(to)} · before sales tax · ${fmtMoney(total)}`,
		onCsv: () => downloadCsv(`sales-by-customer-${from}-to-${to}`, [
			[
				"Customer",
				"Invoices",
				"Sales",
				"Share",
				"Still owed"
			],
			...list.map(([k, g]) => [
				k,
				g.count,
				g.sales,
				total ? `${(g.sales / total * 100).toFixed(1)}%` : "",
				g.owed
			]),
			[
				"Total",
				list.reduce((s, [, g]) => s + g.count, 0),
				total,
				"",
				list.reduce((s, [, g]) => s + g.owed, 0)
			]
		]),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-left font-medium",
						children: "Customer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Invoices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Sales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Share"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-1 text-right font-medium",
						children: "Still owed"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.map(([k, g]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 pr-2",
						children: k
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: g.count
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: fmtMoney(g.sales)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: total ? `${(g.sales / total * 100).toFixed(1)}%` : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-1 text-right tabular-nums",
						children: g.owed ? fmtMoney(g.owed) : ""
					})
				]
			}, k)) })]
		}), list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-4 text-center text-muted-foreground",
			children: "No sales in these dates."
		})]
	});
}
function ExpensesByVendor({ from, to }) {
	const { data: accounts } = useAccounts();
	const { data, isLoading, error } = useQuery({
		queryKey: [
			"account-totals",
			"ledger-ebv",
			from,
			to
		],
		queryFn: () => loadLedger(from, to)
	});
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Failed, { error });
	if (isLoading || !data || !accounts) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	const exp = new Set(accounts.filter((a) => a.type === "expense").map((a) => a.id));
	const by = /* @__PURE__ */ new Map();
	for (const l of data) {
		if (!exp.has(l.account_id)) continue;
		const k = l.name || "No vendor named";
		by.set(k, (by.get(k) ?? 0) + l.debit - l.credit);
	}
	const list = [...by.entries()].filter(([, v]) => Math.abs(v) > .004).sort((a, b) => b[1] - a[1]);
	const total = list.reduce((s, [, v]) => s + v, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Expenses by vendor",
		sub: `${fmtDate(from)} to ${fmtDate(to)} · costs and expenses · ${fmtMoney(total)}`,
		onCsv: () => downloadCsv(`expenses-by-vendor-${from}-to-${to}`, [
			[
				"Vendor",
				"Amount",
				"Share"
			],
			...list.map(([k, v]) => [
				k,
				v,
				total ? `${(v / total * 100).toFixed(1)}%` : ""
			]),
			[
				"Total",
				total,
				""
			]
		]),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-left font-medium",
							children: "Vendor"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-right font-medium",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1 text-right font-medium",
							children: "Share"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 pr-2",
							children: k
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 text-right tabular-nums",
							children: fmtMoney(v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-1 text-right tabular-nums",
							children: total ? `${(v / total * 100).toFixed(1)}%` : ""
						})
					]
				}, k)) })]
			}),
			list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-4 text-center text-muted-foreground",
				children: "No expenses in these dates."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted-foreground print:hidden",
				children: "Expenses with no vendor (hand-typed entries, bank fees added from Banking) show as \"No vendor named\"."
			})
		]
	});
}
//#endregion
export { Financials as component };
