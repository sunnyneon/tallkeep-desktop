import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/checks_._id-mL6-k3i0.js
var $$splitComponentImporter = () => import("./checks_._id-gNRbcw7E.mjs");
var Route = createFileRoute("/_authenticated/checks_/$id")({
	validateSearch: (s) => ({
		...s["card"] ? { card: 1 } : {},
		...typeof s["account"] === "string" ? { account: s["account"] } : {}
	}),
	head: () => ({ meta: [{ title: "Check · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
