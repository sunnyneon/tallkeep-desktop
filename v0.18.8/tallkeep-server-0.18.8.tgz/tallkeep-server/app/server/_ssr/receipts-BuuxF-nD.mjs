import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { n as fileToPages, r as shrinkForStorage } from "./ai-DoFpV1D-.mjs";
import { t as aiRead } from "./ai.functions-CtjfBE_r.mjs";
import { a as ruleFor, i as payeeKey } from "./bankfile-C7N990Vr.mjs";
import { P as RefreshCw, Vt as EyeOff, an as Check, d as Upload, ft as Link2, g as Trash2, ln as Camera, x as Sparkles } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-wDrazOwE.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as SearchSelect } from "./SearchSelect-KZGKVtkS.mjs";
import { n as takeScans } from "./scanQueue-C9-xAAQ0.mjs";
import { n as getStorage } from "./storage.functions-CIS5m0Oi.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/receipts-BuuxF-nD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var T = (name) => db.from(name);
var BUCKET = "receipts";
var daysApart = (a, b) => Math.abs(Date.parse(`${a}T12:00:00`) - Date.parse(`${b}T12:00:00`)) / 864e5;
function ReceiptsPage() {
	const qc = useQueryClient();
	const [tab, setTab] = (0, import_react.useState)("todo");
	const [busy, setBusy] = (0, import_react.useState)("");
	const [drag, setDrag] = (0, import_react.useState)(false);
	const { data: accounts } = useAccounts();
	const { data: receipts, isLoading } = useQuery({
		queryKey: ["receipts"],
		queryFn: async () => {
			const { data, error } = await T("receipts").select("*").order("created_at", { ascending: false }).limit(1e3);
			if (error) throw error;
			return data ?? [];
		}
	});
	const { data: rules } = useQuery({
		queryKey: ["bank-rules"],
		queryFn: () => fetchAll("bank_rules", "id,contains,account_id")
	});
	const { data: vendors } = useQuery({
		queryKey: ["vendor-names"],
		queryFn: () => fetchAll("vendors", "id,name")
	});
	const { data: txns } = useQuery({
		queryKey: ["bank-txns", "receipts"],
		queryFn: async () => {
			const since = (/* @__PURE__ */ new Date(Date.now() - 158112e5)).toLocaleDateString("en-CA");
			const { data, error } = await db.from("bank_transactions").select("id,account_id,txn_date,amount,description,status").gte("txn_date", since).lt("amount", 0).limit(1e4);
			if (error) throw error;
			return data ?? [];
		}
	});
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["receipts"] });
		qc.invalidateQueries({ queryKey: ["bank-txns"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	const expenseOpts = (accounts ?? []).filter((a) => a.is_active && (a.type === "expense" || a.kind === "fixed_asset" || a.kind === "other_asset")).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	const payOpts = (accounts ?? []).filter((a) => a.is_active && (a.kind === "bank" || a.kind === "credit_card")).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	/** Upload, then let the AI read it. */
	async function addFiles(files) {
		const room = await getStorage().catch(() => null);
		if (room?.limit && room.used >= room.limit) {
			toast.error("Your files take all the space your plan includes. Delete files you don't need (Documents), or pick a bigger plan in Plan & billing.");
			return;
		}
		if (!files.length) return;
		const { data: co } = await db.rpc("active_company");
		const { data: u } = await db.auth.getUser();
		let ok = 0;
		for (const [i, f] of files.entries()) {
			if (!/^image\//.test(f.type) && !/\.pdf$/i.test(f.name)) {
				toast.error(`${f.name}: use a photo or a PDF.`);
				continue;
			}
			setBusy(`Receipt ${i + 1} of ${files.length}: saving…`);
			const isPdf = /\.pdf$/i.test(f.name);
			const blob = await shrinkForStorage(f);
			const path = `${String(co)}/${crypto.randomUUID()}.${isPdf ? "pdf" : "jpg"}`;
			const up = await db.storage.from(BUCKET).upload(path, blob, { contentType: isPdf ? "application/pdf" : "image/jpeg" });
			if (up.error) {
				toast.error(`${f.name}: ${up.error.message}`);
				continue;
			}
			const { data: row, error } = await T("receipts").insert({
				file_path: path,
				file_name: f.name,
				mime: isPdf ? "application/pdf" : "image/jpeg",
				created_by: u.user?.id
			}).select("id").single();
			if (error) {
				toast.error(error.message);
				continue;
			}
			setBusy(`Receipt ${i + 1} of ${files.length}: AI is reading it…`);
			await readOne(row.id, f);
			ok++;
		}
		setBusy("");
		if (ok) toast.success(`${ok} receipt${ok === 1 ? "" : "s"} added.`);
		refresh();
	}
	async function readOne(id, file) {
		try {
			const f = file instanceof File ? file : new File([file], "receipt", { type: file.type });
			const pages = await fileToPages(f, 3);
			const r = JSON.parse(await aiRead({ data: {
				feature: "receipt",
				images: pages
			} }));
			const vendor = r["vendor"] ? String(r["vendor"]) : null;
			const total = r["total"] == null ? null : Math.abs(Number(r["total"]));
			const v = vendor ? (vendors ?? []).find((x) => x.name.toLowerCase().includes(vendor.toLowerCase()) || vendor.toLowerCase().includes(x.name.toLowerCase())) : void 0;
			const rule = vendor ? ruleFor(rules ?? [], vendor) : null;
			await T("receipts").update({
				status: "read",
				vendor_name: v?.name ?? vendor,
				vendor_id: v?.id ?? null,
				receipt_date: /^\d{4}-\d{2}-\d{2}$/.test(String(r["date"] ?? "")) ? String(r["date"]) : null,
				total,
				tax: r["tax"] == null ? null : Number(r["tax"]),
				account_id: rule?.account_id ?? null,
				ai: r,
				error: null
			}).eq("id", id);
		} catch (e) {
			await T("receipts").update({
				status: "failed",
				error: e.message
			}).eq("id", id);
			toast.error(e.message);
		}
	}
	async function readAgain(r) {
		setBusy("AI is reading it…");
		const { data, error } = await db.storage.from(BUCKET).download(r.file_path);
		if (error || !data) {
			setBusy("");
			toast.error(error?.message ?? "File not found.");
			return;
		}
		await readOne(r.id, new File([data], r.file_name ?? "receipt", { type: r.mime ?? data.type }));
		setBusy("");
		refresh();
	}
	const tookScans = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (tookScans.current || !vendors || !rules) return;
		tookScans.current = true;
		const files = takeScans();
		if (files.length) addFiles(files);
	}, [vendors, rules]);
	const list = (receipts ?? []).filter((r) => tab === "done" ? r.status === "done" || r.status === "ignored" : !["done", "ignored"].includes(r.status));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Receipts",
			text: "Snap a photo or drop receipts and PDF bills here. AI reads the store, date and total, finds the matching bank or card line, and you record it with one click. The receipt stays attached for your accountant."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `flex flex-wrap items-center gap-3 rounded-2xl border-2 border-dashed bg-card p-4 text-sm ${drag ? "border-[var(--section)] bg-[var(--section-soft)]" : "border-border"}`,
			onDragOver: (e) => {
				e.preventDefault();
				setDrag(true);
			},
			onDragLeave: (e) => {
				if (!e.currentTarget.contains(e.relatedTarget)) setDrag(false);
			},
			onDrop: (e) => {
				e.preventDefault();
				setDrag(false);
				addFiles([...e.dataTransfer.files]);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex cursor-pointer items-center gap-2 rounded-md bg-[var(--section)] px-3 py-1.5 font-medium text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-4 w-4" }),
						" Take a photo",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							capture: "environment",
							className: "hidden",
							onChange: (e) => {
								const f = [...e.target.files ?? []];
								e.target.value = "";
								addFiles(f);
							}
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "inline-flex cursor-pointer items-center gap-2 rounded-md border px-3 py-1.5 font-medium hover:bg-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-4 w-4" }),
						" Add receipt files",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*,.pdf,application/pdf",
							multiple: true,
							className: "hidden",
							onChange: (e) => {
								const f = [...e.target.files ?? []];
								e.target.value = "";
								addFiles(f);
							}
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: busy || "or drop photos and PDFs here."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "inline-flex rounded-lg border p-0.5 text-sm",
			children: [["todo", "To record"], ["done", "Done"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setTab(k),
				className: `rounded-md px-3 py-1 ${tab === k ? "bg-[var(--section)] text-white" : ""}`,
				children: label
			}, k))
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [receipts && list.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-8 text-center text-sm text-muted-foreground",
				children: tab === "done" ? "Nothing recorded yet." : "No receipts waiting. Add some above."
			}), list.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptCard, {
				r,
				txns: txns ?? [],
				receipts: receipts ?? [],
				expenseOpts,
				payOpts,
				accountName: (id) => {
					const a = accounts?.find((x) => x.id === id);
					return a ? accountLabel(a) : "";
				},
				kindOf: (id) => accounts?.find((x) => x.id === id)?.kind ?? "",
				onChanged: refresh,
				onReadAgain: () => void readAgain(r)
			}, r.id))]
		})
	] });
}
function Thumb({ r }) {
	const { data: url } = useQuery({
		queryKey: ["receipt-url", r.file_path],
		staleTime: 3e6,
		queryFn: async () => {
			const { data } = await db.storage.from(BUCKET).createSignedUrl(r.file_path, 3600);
			return data?.signedUrl ?? "";
		}
	});
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-20 shrink-0 rounded-md bg-muted" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: url,
		target: "_blank",
		rel: "noreferrer",
		className: "shrink-0",
		title: "Open the receipt",
		children: r.mime === "application/pdf" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-24 w-20 items-center justify-center rounded-md border bg-muted text-xs font-semibold",
			children: "PDF"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: "Receipt",
			className: "h-24 w-20 rounded-md border object-cover"
		})
	});
}
function ReceiptCard({ r, txns, receipts, expenseOpts, payOpts, accountName, kindOf, onChanged, onReadAgain }) {
	const [vendor, setVendor] = (0, import_react.useState)(r.vendor_name ?? "");
	const [date, setDate] = (0, import_react.useState)(r.receipt_date ?? "");
	const [total, setTotal] = (0, import_react.useState)(r.total != null ? String(r.total) : "");
	const [acc, setAcc] = (0, import_react.useState)(r.account_id);
	const [paidFrom, setPaidFrom] = (0, import_react.useState)(r.paid_from);
	const [remember, setRemember] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setVendor(r.vendor_name ?? "");
		setDate(r.receipt_date ?? "");
		setTotal(r.total != null ? String(r.total) : "");
		setAcc(r.account_id);
	}, [
		r.vendor_name,
		r.receipt_date,
		r.total,
		r.account_id
	]);
	const amt = Math.round(Number(total) * 100) / 100;
	const match = (0, import_react.useMemo)(() => {
		if (!(amt > 0) || !date) return void 0;
		const used = new Set(receipts.filter((x) => x.id !== r.id && x.bank_txn_id).map((x) => x.bank_txn_id));
		return txns.filter((t) => !used.has(t.id) && Math.abs(-Number(t.amount) - amt) < .005 && daysApart(t.txn_date, date) <= 5).sort((a, b) => daysApart(a.txn_date, date) - daysApart(b.txn_date, date))[0];
	}, [
		txns,
		receipts,
		r.id,
		amt,
		date
	]);
	const done = r.status === "done" || r.status === "ignored";
	async function save(patch) {
		const { error } = await T("receipts").update(patch).eq("id", r.id);
		if (error) throw error;
	}
	async function learn() {
		const key = payeeKey(vendor);
		if (!remember || !acc || !key) return;
		const { data } = await db.from("bank_rules").select("id").ilike("contains", key).limit(1);
		if (data?.[0]) await db.from("bank_rules").update({ account_id: acc }).eq("id", data[0].id);
		else await db.from("bank_rules").insert({
			contains: key,
			account_id: acc
		});
	}
	async function recordWithLine(t) {
		if (!acc) return void toast.error("Choose what it was for (account).");
		setBusy(true);
		try {
			if (t.status === "new") {
				const { error } = await db.rpc("add_bank_transaction", {
					_txn: t.id,
					_other: acc,
					_memo: [vendor, r.ai?.items].filter(Boolean).join(" · ") || (t.description ?? "")
				});
				if (error) throw error;
			}
			await save({
				status: "done",
				vendor_name: vendor || null,
				receipt_date: date || null,
				total: amt,
				account_id: acc,
				paid_from: t.account_id,
				bank_txn_id: t.id
			});
			await learn();
			toast.success(t.status === "new" ? "Recorded and matched to the bank line." : "Attached to the bank line.");
			onChanged();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function recordAsPayment() {
		if (!acc) return void toast.error("Choose what it was for (account).");
		if (!paidFrom) return void toast.error("Choose how it was paid (bank or card).");
		if (!(amt > 0)) return void toast.error("Type the total.");
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const method = kindOf(paidFrom) === "credit_card" ? "card" : r.ai?.payment === "cash" ? "cash" : "other";
			const { data: c, error } = await db.from("checks").insert({
				account_id: paidFrom,
				method,
				number: null,
				check_date: date || today(),
				payee: vendor || "Receipt",
				vendor_id: r.vendor_id,
				memo: r.ai?.items ?? "From a receipt",
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("check_lines").insert({
				check_id: c.id,
				line_no: 1,
				account_id: acc,
				description: r.ai?.items ?? vendor ?? "Receipt",
				amount: amt
			});
			if (le) throw le;
			await save({
				status: "done",
				vendor_name: vendor || null,
				receipt_date: date || null,
				total: amt,
				account_id: acc,
				paid_from: paidFrom,
				check_id: c.id
			});
			await learn();
			toast.success("Recorded. When the bank or card statement comes in, it will match.");
			onChanged();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function ignore() {
		await save({ status: r.status === "ignored" ? "read" : "ignored" });
		onChanged();
	}
	async function remove() {
		if (!confirm("Delete this receipt and its photo? What it recorded in the books stays.")) return;
		await db.storage.from(BUCKET).remove([r.file_path]);
		const { error } = await T("receipts").delete().eq("id", r.id);
		if (error) return void toast.error(error.message);
		onChanged();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-3 rounded-2xl border bg-card p-3 text-sm sm:p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thumb, { r }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1 space-y-2",
			children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: r.vendor_name ?? "Receipt"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted-foreground",
							children: [
								r.receipt_date ? fmtDate(r.receipt_date) : "",
								r.account_id ? ` · ${accountName(r.account_id)}` : "",
								r.status === "ignored" ? " · Ignored" : r.bank_txn_id ? " · Matched to a bank line" : r.check_id ? " · Recorded as a payment" : ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: r.total != null ? fmtMoney(r.total) : ""
					}),
					r.check_id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/checks/$id",
						params: { id: r.check_id },
						className: "text-xs underline",
						children: "Open the payment"
					}),
					r.status === "ignored" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => void ignore(),
						children: "Put back"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				r.status === "failed" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-destructive",
					children: ["AI couldn't read it: ", r.error]
				}),
				r.status === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Waiting for the AI to read it…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_9rem_7rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Store / vendor",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: vendor,
								onChange: (e) => setVendor(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: date,
								onChange: (e) => setDate(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Total",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								value: total,
								onChange: (e) => setTotal(e.target.value)
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "What was it for?",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: acc,
							options: expenseOpts,
							onChange: setAcc,
							placeholder: r.ai?.category ? `AI guess: ${r.ai.category}` : "Choose the account"
						})
					}), !match && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Paid with",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: paidFrom,
							options: payOpts,
							onChange: setPaidFrom,
							placeholder: r.ai?.card_last4 ? `Card ending ${r.ai.card_last4}` : "Bank or card"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-1.5 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: remember,
							onChange: (e) => setRemember(e.target.checked)
						}),
						"Always use this account for \"",
						payeeKey(vendor) || "this store",
						"\" (receipts and bank lines)"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						match ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-3.5 w-3.5 text-[var(--section)]" }),
								"Matches ",
								accountName(match.account_id),
								" line on ",
								fmtDate(match.txn_date),
								":",
								" ",
								match.description
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: busy,
							onClick: () => void recordWithLine(match),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" }),
								" ",
								match.status === "new" ? "Record with this bank line" : "Attach to this bank line"
							]
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							disabled: busy,
							onClick: () => void recordAsPayment(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), " Record as a payment"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: onReadAgain,
							title: "Let the AI read it again",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "h-3.5 w-3.5" }), " Read again"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => void ignore(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-3.5 w-3.5" }), " Ignore"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "ghost",
							"aria-label": "Delete",
							onClick: () => void remove(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				})
			] })
		})]
	});
}
//#endregion
export { ReceiptsPage as component };
