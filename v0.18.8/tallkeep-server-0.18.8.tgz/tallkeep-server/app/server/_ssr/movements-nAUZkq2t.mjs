import { i as __toESM } from "../_runtime.mjs";
import { n as db, t as REASON_LABEL } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { D as Search } from "../_libs/lucide-react.mjs";
import { o as useLocations, t as byId } from "./queries-CUGyjerL.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/movements-nAUZkq2t.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	{
		v: "all",
		label: "All types",
		reasons: []
	},
	{
		v: "sold",
		label: "Sales order picking",
		reasons: ["sold"]
	},
	{
		v: "received",
		label: "Purchase order receive",
		reasons: ["received"]
	},
	{
		v: "returned",
		label: "Returns / restock",
		reasons: ["returned"]
	},
	{
		v: "adjust",
		label: "Stock adjustment",
		reasons: ["adjust"]
	},
	{
		v: "count",
		label: "Count sheet",
		reasons: ["count"]
	},
	{
		v: "move",
		label: "Stock transfer",
		reasons: ["move_in", "move_out"]
	},
	{
		v: "import",
		label: "Brought over from inFlow",
		reasons: ["import"]
	}
];
function Movements() {
	const { data: locations } = useLocations();
	const locName = byId(locations);
	const [q, setQ] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("all");
	const [loc, setLoc] = (0, import_react.useState)("all");
	const { data, isLoading } = useQuery({
		queryKey: ["movements"],
		queryFn: async () => {
			const out = [];
			for (let from = 0; from < 2e4; from += 1e3) {
				const { data, error } = await db.from("stock_moves").select("id,qty_change,reason,note,shelf,location_id,ref_type,ref_id,created_at, products(id,name,description)").order("created_at", { ascending: false }).range(from, from + 999);
				if (error) throw error;
				out.push(...data ?? []);
				if (!data || data.length < 1e3) break;
			}
			return out;
		}
	});
	const rows = (0, import_react.useMemo)(() => {
		const w = q.toLowerCase().split(/\s+/).filter(Boolean);
		const reasons = TYPES.find((t) => t.v === type)?.reasons ?? [];
		return (data ?? []).filter((r) => reasons.length ? reasons.includes(r.reason) : true).filter((r) => loc === "all" || r.location_id === loc).filter((r) => w.every((x) => `${r.products?.name ?? ""} ${r.products?.description ?? ""} ${r.note ?? ""} ${r.shelf}`.toLowerCase().includes(x)));
	}, [
		data,
		q,
		type,
		loc
	]);
	function refLink(r) {
		if (!r.note) return null;
		if (r.ref_type === "sales_order" && r.ref_id) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/sales/$id",
			params: { id: r.ref_id },
			search: {},
			className: "text-primary",
			children: r.note
		});
		if (r.ref_type === "purchase_order" && r.ref_id) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/po/$id",
			params: { id: r.ref_id },
			search: {},
			className: "text-primary",
			children: r.note
		});
		if (r.ref_type === "stock_doc" && r.ref_id) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/stock-doc/$id",
			params: { id: r.ref_id },
			search: {},
			className: "text-primary",
			children: r.note
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: r.note
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Movement History",
				text: "Every time stock went in, out or moved — newest first."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-[minmax(0,1fr)_220px_200px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-9",
							placeholder: "Search item, order number or shelf",
							value: q,
							onChange: (e) => setQ(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: type,
						onValueChange: setType,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: t.v,
							children: t.label
						}, t.v)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: loc,
						onValueChange: setLoc,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All locations"
						}), (locations ?? []).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: l.id,
							children: l.name
						}, l.id))] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [rows.length.toLocaleString(), " movements"]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Location"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Shelf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Order / doc #"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Quantity"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: rows.slice(0, 500).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "hover:bg-muted/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[280px] truncate px-3 py-2",
									children: r.products ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/products/$id",
										params: { id: r.products.id },
										className: "font-medium hover:underline",
										children: r.products.name
									}) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "whitespace-nowrap px-3 py-2",
									children: REASON_LABEL[r.reason] ?? r.reason
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "whitespace-nowrap px-3 py-2",
									children: fmtDate(r.created_at)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: locName.get(r.location_id)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.shelf
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "whitespace-nowrap px-3 py-2",
									children: refLink(r)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: `whitespace-nowrap px-3 py-2 text-right font-semibold ${Number(r.qty_change) < 0 ? "text-destructive" : "text-emerald-600"}`,
									children: [Number(r.qty_change) > 0 ? "+" : "", fmtQty(r.qty_change)]
								})
							]
						}, r.id))
					})]
				})
			}),
			rows.length > 500 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Showing the newest 500. Search or filter to narrow it down."
			})
		]
	});
}
//#endregion
export { Movements as component };
