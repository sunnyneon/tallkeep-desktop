import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-zltnVrwr.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-8tQCpcOj.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today } from "./accounting-QuDdqtoA.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { nn as ChevronRight, rn as ChevronLeft } from "../_libs/lucide-react.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/calendar-OqrO_5x2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KIND = {
	invoice: {
		name: "Customer owes",
		cls: "bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200"
	},
	bill: {
		name: "Bill due",
		cls: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200"
	},
	po: {
		name: "PO due",
		cls: "bg-orange-100 text-orange-900 dark:bg-orange-950 dark:text-orange-200"
	},
	rent: {
		name: "Rent due",
		cls: "bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-200"
	},
	recurring: {
		name: "Repeats",
		cls: "bg-violet-100 text-violet-900 dark:bg-violet-950 dark:text-violet-200"
	},
	lease: {
		name: "Lease ends",
		cls: "bg-rose-100 text-rose-900 dark:bg-rose-950 dark:text-rose-200"
	}
};
var d10 = (s) => (s ?? "").slice(0, 10);
function CalendarPage() {
	const { data: features } = useFeatures();
	const [month, setMonth] = (0, import_react.useState)(today().slice(0, 7));
	const [pick, setPick] = (0, import_react.useState)(today());
	const first = `${month}-01`;
	const lastDay = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)), 0).getDate();
	const last = `${month}-${String(lastDay).padStart(2, "0")}`;
	const { data, isLoading } = useQuery({
		queryKey: [
			"calendar",
			month,
			(features ?? []).join(",")
		],
		queryFn: async () => {
			const on = (f) => !features || features.includes(f);
			const out = [];
			const safe = async (p) => {
				const r = await p;
				return r.error ? [] : r.data ?? [];
			};
			const [inv, bills, pos, rent, rec, leases] = await Promise.all([
				on("sales") ? safe(db.from("sales_orders").select("id,number,customer_name,due_date,invoice_date,balance").in("status", [
					"invoiced",
					"paid",
					"completed"
				]).gt("balance", 0).limit(5e3)) : [],
				on("accounting") ? safe(db.from("bills").select("id,vendor_name,ref,due_date,bill_date,balance").eq("status", "open").gt("balance", 0).limit(5e3)) : [],
				on("purchasing") ? safe(db.from("purchase_orders").select("id,number,vendor_name,due_date,balance,status,stock_received_at").gt("balance", 0).neq("status", "cancelled").not("due_date", "is", null).limit(5e3)) : [],
				on("real_estate") ? safe(db.from("rent_charges").select("id,due_date,balance,description").eq("status", "open").gte("due_date", first).lte("due_date", last).limit(5e3)) : [],
				on("accounting") ? safe(db.from("recurring").select("id,name,next_date,lines,kind,every").eq("active", true).limit(1e3)) : [],
				on("real_estate") ? safe(db.from("leases").select("id,end_date").eq("status", "active").gte("end_date", first).lte("end_date", last).limit(1e3)) : []
			]);
			for (const o of inv) {
				const day = d10(o.due_date ?? o.invoice_date);
				if (day >= first && day <= last) out.push({
					day,
					kind: "invoice",
					label: `${o.number} · ${o.customer_name ?? ""}`,
					amount: Number(o.balance),
					to: "/sales/$id",
					params: { id: o.id },
					search: {}
				});
			}
			for (const b of bills) {
				const day = d10(b.due_date ?? b.bill_date);
				if (day >= first && day <= last) out.push({
					day,
					kind: "bill",
					label: `${b.vendor_name ?? "Bill"}${b.ref ? ` · ${b.ref}` : ""}`,
					amount: Number(b.balance),
					to: "/bills/$id",
					params: { id: b.id },
					search: {}
				});
			}
			for (const p of pos) {
				const day = d10(p.due_date);
				if (day >= first && day <= last && (p.stock_received_at || [
					"received",
					"paid",
					"completed"
				].includes(p.status))) out.push({
					day,
					kind: "po",
					label: `${p.number} · ${p.vendor_name ?? ""}`,
					amount: Number(p.balance),
					to: "/po/$id",
					params: { id: p.id },
					search: {}
				});
			}
			const rentByDay = /* @__PURE__ */ new Map();
			for (const r of rent) {
				const g = rentByDay.get(d10(r.due_date)) ?? {
					n: 0,
					amt: 0
				};
				g.n += 1;
				g.amt += Number(r.balance);
				rentByDay.set(d10(r.due_date), g);
			}
			for (const [day, g] of rentByDay) out.push({
				day,
				kind: "rent",
				label: `${g.n} rent charge${g.n === 1 ? "" : "s"} unpaid`,
				amount: g.amt,
				to: "/rent"
			});
			for (const r of rec) {
				let d = d10(r.next_date);
				const amt = (r.lines ?? []).reduce((s, l) => s + Number(l.amount || 0), 0);
				for (let i = 0; i < 6 && d <= last; i++) {
					if (d >= first) out.push({
						day: d,
						kind: "recurring",
						label: r.name,
						amount: amt,
						to: "/recurring",
						search: {}
					});
					const x = /* @__PURE__ */ new Date(`${d}T12:00:00`);
					if (r.every === "week") x.setDate(x.getDate() + 7);
					else x.setMonth(x.getMonth() + (r.every === "quarter" ? 3 : r.every === "year" ? 12 : 1));
					d = x.toLocaleDateString("en-CA");
				}
			}
			for (const l of leases) if (l.end_date) out.push({
				day: d10(l.end_date),
				kind: "lease",
				label: "A lease ends",
				to: "/leases",
				search: { lease: l.id }
			});
			return out;
		}
	});
	const byDay = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const e of data ?? []) m.set(e.day, [...m.get(e.day) ?? [], e]);
		return m;
	}, [data]);
	const startDow = (/* @__PURE__ */ new Date(`${first}T12:00:00`)).getDay();
	const cells = [...Array.from({ length: startDow }, () => null), ...Array.from({ length: lastDay }, (_, i) => `${month}-${String(i + 1).padStart(2, "0")}`)];
	while (cells.length % 7) cells.push(null);
	const move = (n) => {
		const d = /* @__PURE__ */ new Date(`${first}T12:00:00`);
		d.setMonth(d.getMonth() + n);
		setMonth(d.toLocaleDateString("en-CA").slice(0, 7));
		setPick(null);
	};
	const title = (/* @__PURE__ */ new Date(`${first}T12:00:00`)).toLocaleDateString("en-US", {
		month: "long",
		year: "numeric"
	});
	const chosen = pick ? byDay.get(pick) ?? [] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Calendar",
			text: "What's due each day: customers who owe, bills to pay, rent, repeating payments and leases ending."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "icon",
					"aria-label": "Last month",
					onClick: () => move(-1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "min-w-44 text-center font-display text-lg font-semibold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "icon",
					"aria-label": "Next month",
					onClick: () => move(1),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => {
						setMonth(today().slice(0, 7));
						setPick(today());
					},
					children: "Today"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ml-auto flex flex-wrap gap-1 text-xs",
					children: Object.keys(KIND).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `rounded px-1.5 py-0.5 ${KIND[k].cls}`,
						children: KIND[k].name
					}, k))
				})
			]
		}),
		isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[minmax(0,3fr)_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7 border-b text-center text-xs text-muted-foreground",
					children: [
						"Sun",
						"Mon",
						"Tue",
						"Wed",
						"Thu",
						"Fri",
						"Sat"
					].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-1",
						children: d
					}, d))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-7",
					children: cells.map((day, i) => {
						const evs = day ? byDay.get(day) ?? [] : [];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !day,
							onClick: () => day && setPick(day),
							className: `min-h-24 border-b border-r p-1 text-left align-top text-xs ${!day ? "bg-muted/30" : "hover:bg-muted/40"} ${day === pick ? "ring-2 ring-inset ring-[var(--section)]" : ""}`,
							children: day && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-block rounded px-1 ${day === today() ? "bg-[var(--section)] font-bold text-white" : "text-muted-foreground"}`,
								children: Number(day.slice(8))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 space-y-0.5",
								children: [evs.slice(0, 3).map((e, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `truncate rounded px-1 ${KIND[e.kind].cls}`,
									children: e.label
								}, j)), evs.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-muted-foreground",
									children: [
										"+",
										evs.length - 3,
										" more"
									]
								})]
							})] })
						}, i);
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 font-semibold",
						children: pick ? fmtDate(pick) : "Pick a day"
					}),
					pick && chosen.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted-foreground",
						children: "Nothing due."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: chosen.map((e, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: e.to,
							params: e.params,
							search: e.search,
							className: "block rounded-lg border p-2 hover:bg-muted/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded px-1.5 py-0.5 text-xs ${KIND[e.kind].cls}`,
									children: KIND[e.kind].name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block",
									children: e.label
								}),
								e.amount != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-semibold",
									children: fmtMoney(e.amount)
								})
							]
						}, j))
					})
				]
			})]
		})
	] });
}
//#endregion
export { CalendarPage as component };
