import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/customers_._id-CdhPSZq3.js
var $$splitComponentImporter = () => import("./customers_._id-By2-OFMv.mjs");
var Route = createFileRoute("/admin/customers_/$id")({
	head: () => ({ meta: [{ title: "Customer · Tallkeep Admin" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
