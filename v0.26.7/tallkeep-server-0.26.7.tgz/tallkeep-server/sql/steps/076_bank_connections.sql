-- 076: Bank connections (SimpleFIN Bridge). A company pastes the setup code from its SimpleFIN
-- account; Tallkeep swaps it for a private read-only address and pulls new bank and card lines
-- every day into Banking → For review (the same place statement files go).
-- The private address can only read; it can never move money. It is kept where only the server
-- can see it (no one signed in can read these tables directly), and it is left out of backups:
-- after putting a backup back, connect the bank again.

create table if not exists public.bank_links (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  provider text not null default 'simplefin',
  access_url text not null,              -- private: read-only address with its own password
  name text,                             -- what the person sees ("SimpleFIN")
  created_by uuid,
  created_at timestamptz not null default now(),
  last_pulled_at timestamptz,
  last_error text
);
create index if not exists bank_links_company_idx on public.bank_links (company_id);

-- Each account the bank shares, and which Tallkeep account its lines go to (none = skipped).
create table if not exists public.bank_link_accounts (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  link_id uuid not null references public.bank_links(id) on delete cascade,
  remote_id text not null,
  name text not null,
  bank_name text,
  currency text,
  balance numeric(14,2),
  balance_date timestamptz,
  account_id uuid references public.accounts(id) on delete set null,
  -- Lines on or after this day come in (set when the account is first linked).
  start_date date,
  unique (link_id, remote_id)
);
create index if not exists bank_link_accounts_company_idx on public.bank_link_accounts (company_id);

-- Only the server reads and writes these (it checks who is asking first).
alter table public.bank_links enable row level security;
alter table public.bank_link_accounts enable row level security;
revoke all on public.bank_links from anon, authenticated;
revoke all on public.bank_link_accounts from anon, authenticated;
grant all on public.bank_links to service_role;
grant all on public.bank_link_accounts to service_role;

notify pgrst, 'reload schema';
