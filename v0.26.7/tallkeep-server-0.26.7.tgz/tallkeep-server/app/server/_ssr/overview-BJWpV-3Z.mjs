import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-tdRottJR.mjs";
import { b as Link, x as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, f as useAccounts, m as yearStart, p as useTotals } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { $t as ClipboardList, Jt as CreditCard, Lt as FileText, Nn as ArrowRight, R as Receipt, Sn as Boxes, X as Package, _n as CalendarDays, a as Wallet, bn as Building2, c as Users, fn as ChartColumn, g as TrendingUp, h as TriangleAlert, m as Truck, st as Mail, vt as Landmark, w as ShoppingCart, yt as KeyRound } from "../_libs/lucide-react.mjs";
import { t as GROUP_COLOR } from "./nav-KzVPv_d3.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as loadCharges, s as useRealEstate } from "./realestate-B7MhUll3.mjs";
import { n as useProductList } from "./products-CqM8plvT.mjs";
import { a as YAxis, i as BarChart, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, u as Bar } from "../_libs/recharts+[...].mjs";
import { t as PlCharts } from "./PlCharts-D-G9vwLq.mjs";
import { n as ageDays, o as stageOf, t as DEFAULT_RULES } from "./followups-CAmQFMgv.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/overview-BJWpV-3Z.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Personal books have their numbers on Home; this page is the business one. */
function OverviewPage() {
	const { data: features } = useFeatures();
	if (!features) return null;
	if (features.includes("personal")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, {
		to: "/",
		replace: true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, { realEstate: features.includes("real_estate") });
}
var SOLD = [
	"invoiced",
	"paid",
	"completed"
];
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function Home$1({ realEstate }) {
	const qc = useQueryClient();
	const { data: products } = useProductList();
	const { data: accounts } = useAccounts();
	const { data: allTime } = useTotals(null, null);
	const { data: thisYear } = useTotals(yearStart(), null);
	const { data: re } = useRealEstate(realEstate);
	const { data: openRent } = useQuery({
		queryKey: ["rent-open-overview"],
		enabled: realEstate,
		queryFn: () => loadCharges(true)
	});
	const { data: sos } = useQuery({
		queryKey: ["home", "sales"],
		queryFn: () => fetchAll("sales_orders", "*")
	});
	const monthStart = new Date((/* @__PURE__ */ new Date()).getFullYear(), (/* @__PURE__ */ new Date()).getMonth(), 1);
	const { data: paidThisMonth } = useQuery({
		queryKey: [
			"home",
			"payments",
			monthStart.toISOString()
		],
		queryFn: async () => {
			const { data } = await db.from("payments").select("amount, method").not("sales_order_id", "is", null).gte("paid_on", monthStart.toISOString()).limit(5e3);
			return (data ?? []).filter((p) => p.method !== "Paid before switch-over").reduce((s, p) => s + Number(p.amount), 0);
		}
	});
	const { data: stockValue } = useQuery({
		queryKey: ["home", "stock-value"],
		queryFn: async () => {
			return (await fetchAll("stock", "qty,products(cost)")).reduce((s, r) => s + Math.max(0, Number(r.qty)) * Number(r.products?.cost ?? 0), 0);
		}
	});
	const { data: rules } = useQuery({
		queryKey: ["followup-rules"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			const r = { ...DEFAULT_RULES };
			if (data) Object.keys(r).forEach((k) => {
				const v = data[k];
				if (v != null) r[k] = v;
			});
			return r;
		}
	});
	const now = /* @__PURE__ */ new Date();
	const y = now.getFullYear();
	const dayOfYear = (d) => Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 1).getTime()) / 864e5);
	const stats = (0, import_react.useMemo)(() => {
		const sold = (sos ?? []).filter((o) => SOLD.includes(o.status) && !o.number.startsWith("RMA-"));
		const when = (o) => new Date(o.invoice_date ?? o.order_date);
		const ytd = sold.filter((o) => when(o).getFullYear() === y);
		const lastYtd = sold.filter((o) => when(o).getFullYear() === y - 1 && dayOfYear(when(o)) <= dayOfYear(now));
		const month = ytd.filter((o) => when(o).getMonth() === now.getMonth());
		const sum = (l) => l.reduce((s, o) => s + Number(o.total), 0);
		const byMonth = MONTHS.map((m, i) => ({
			month: m,
			[String(y)]: sum(ytd.filter((o) => when(o).getMonth() === i)),
			[String(y - 1)]: sum(sold.filter((o) => when(o).getFullYear() === y - 1 && when(o).getMonth() === i))
		}));
		const top = /* @__PURE__ */ new Map();
		ytd.forEach((o) => top.set(o.customer_name ?? "—", (top.get(o.customer_name ?? "—") ?? 0) + Number(o.total)));
		const quotes = (sos ?? []).filter((o) => o.status === "quote" && !o.number.startsWith("RMA-"));
		const toFollow = quotes.filter((o) => !o.accepted_at);
		const owed = (sos ?? []).filter((o) => [
			"open",
			"invoiced",
			"paid",
			"completed"
		].includes(o.status) && !o.number.startsWith("RMA-") && Number(o.balance) > .005);
		return {
			ytd: sum(ytd),
			lastYtd: sum(lastYtd),
			month: sum(month),
			count: ytd.length,
			avg: ytd.length ? sum(ytd) / ytd.length : 0,
			byMonth,
			top: [...top.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5),
			quotes: quotes.length,
			quotesValue: sum(quotes),
			owed: owed.reduce((s, o) => s + Number(o.balance), 0),
			owedCount: owed.length,
			quoteList: toFollow
		};
	}, [sos, y]);
	const r = rules ?? DEFAULT_RULES;
	const due = stats.quoteList.map((q) => ({
		q,
		st: stageOf(q, r)
	})).filter((x) => x.st === "first" || x.st === "second").sort((a, b) => a.q.order_date.localeCompare(b.q.order_date));
	const stale = stats.quoteList.filter((q) => stageOf(q, r) === "close").length;
	const change = stats.lastYtd ? (stats.ytd - stats.lastYtd) / stats.lastYtd * 100 : null;
	async function closeQuote(id) {
		const { error } = await db.from("sales_orders").update({
			status: "cancelled",
			closed_reason: "Closed: customer didn't go ahead"
		}).eq("id", id);
		if (error) toast.error(error.message);
		else {
			toast.success("Quote closed. You can reopen it from the quote page.");
			qc.invalidateQueries({ queryKey: ["home"] });
		}
	}
	const active = (products ?? []).filter((p) => p.is_active);
	const low = active.filter((p) => {
		const on = p.stock.reduce((s, x) => s + Number(x.qty), 0);
		return p.item_type === "stocked" && Number(p.reorder_point) > 0 && on <= Number(p.reorder_point);
	});
	const negative = active.filter((p) => p.item_type === "stocked" && p.stock.reduce((s, x) => s + Number(x.qty), 0) < 0).length;
	const v = (x, f = fmtMoney) => x == null || !sos ? "…" : f(x);
	const money = (0, import_react.useMemo)(() => {
		if (!accounts || !allTime || !thisYear) return null;
		const all = balFrom(allTime);
		const yr = balFrom(thisYear);
		const sum = (f, b) => accounts.filter(f).reduce((t, a) => t + b(a), 0);
		const income = sum((a) => a.type === "income", yr);
		return {
			cash: sum((a) => a.kind === "bank", all),
			owed: sum((a) => ["credit_card", "long_term_liability"].includes(a.kind) || /loan|mortgage/i.test(a.name) && a.type === "liability", all),
			income,
			profit: income - sum((a) => a.type === "expense", yr)
		};
	}, [
		accounts,
		allTime,
		thisYear
	]);
	const showSales = !sos || sos.length > 0 || (products ?? []).some((p) => p.is_active);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Overview",
				text: "Your day at a glance: numbers, what needs attention, and recent work."
			}),
			money && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/banking",
						icon: Landmark,
						label: "Cash in the bank",
						value: fmtMoney(money.cash)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/accounts",
						icon: CreditCard,
						label: "Owed on cards and loans",
						value: fmtMoney(money.owed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/financials",
						icon: TrendingUp,
						label: `Income this year (${y})`,
						value: fmtMoney(money.income)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/financials",
						icon: ChartColumn,
						label: `Profit this year (${y})`,
						value: fmtMoney(money.profit),
						good: money.profit > 0,
						bad: money.profit < 0
					})
				]
			}),
			re && re.properties.some((p) => p.is_active) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: (() => {
					const props = re.properties.filter((p) => p.is_active);
					const land = props.filter((p) => p.kind === "land").length;
					const units = re.units.filter((u) => u.is_active && u.rental_type !== "short");
					const rented = units.filter((u) => re.current(u.id)).length;
					const soon = new Date(Date.now() + 5184e6).toISOString().slice(0, 10);
					const ending = re.leases.filter((l) => l.status === "active" && l.end_date && l.end_date <= soon).length;
					const owed = (openRent ?? []).reduce((t, c) => t + c.balance, 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/properties",
							icon: Building2,
							label: "Properties",
							value: String(props.length),
							sub: land ? `${land} land` : void 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/properties",
							icon: KeyRound,
							label: "Units rented",
							value: units.length ? `${rented} of ${units.length}` : "—",
							sub: units.length > rented ? `${units.length - rented} empty` : void 0,
							bad: units.length > rented
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/rent",
							icon: Wallet,
							label: "Rent owed to you",
							value: openRent ? fmtMoney(owed) : "…",
							bad: owed > 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
							to: "/leases",
							icon: CalendarDays,
							label: "Leases ending in 60 days",
							value: String(ending),
							bad: ending > 0
						})
					] });
				})()
			}),
			showSales && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: TrendingUp,
						label: `Sales this year (${y})`,
						value: v(stats.ytd),
						sub: change == null ? `${stats.count} invoices` : `${change >= 0 ? "▲" : "▼"} ${Math.abs(change).toFixed(0)}% vs same time ${y - 1}`,
						good: change != null && change >= 0,
						bad: change != null && change < 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: CalendarDays,
						label: `Sales in ${MONTHS[now.getMonth()]}`,
						value: v(stats.month)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						icon: Wallet,
						label: `Payments received in ${MONTHS[now.getMonth()]}`,
						value: paidThisMonth == null ? "…" : fmtMoney(paidThisMonth)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						icon: Receipt,
						label: "Customers owe",
						value: v(stats.owed),
						sub: sos ? `${stats.owedCount} unpaid invoices and orders` : void 0,
						bad: stats.owed > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/sales-list",
						icon: FileText,
						label: "Open quotes",
						value: sos ? String(stats.quotes) : "…",
						sub: sos ? `worth ${fmtMoney(stats.quotesValue)}` : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/reports",
						icon: ChartColumn,
						label: "Average invoice this year",
						value: v(stats.avg)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/stock",
						icon: Boxes,
						label: "Stock value (at cost)",
						value: stockValue == null ? "…" : fmtMoney(stockValue),
						sub: products ? `${active.length.toLocaleString()} active products` : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
						to: "/products",
						icon: TriangleAlert,
						label: "Running low",
						value: products ? String(low.length) : "…",
						sub: products && negative > 0 ? `${negative} below zero — check the count` : void 0,
						bad: low.length > 0
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlCharts, {
				from: yearStart(),
				to: (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"),
				personal: false
			}),
			showSales && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-sm font-semibold text-muted-foreground",
						children: "How things flow"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-5 items-start gap-1 text-center text-xs sm:text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/vendors",
								icon: Truck,
								label: "Vendor",
								color: GROUP_COLOR.Purchasing.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/purchase-orders",
								icon: ClipboardList,
								label: "Purchase order",
								arrow: true,
								color: GROUP_COLOR.Purchasing.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/stock",
								icon: Boxes,
								label: "Inventory",
								arrow: true,
								strong: true,
								color: GROUP_COLOR.Inventory.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/sales-list",
								icon: Receipt,
								label: "Invoice",
								arrow: true,
								color: GROUP_COLOR.Sales.main
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowStep, {
								to: "/customers",
								icon: Users,
								label: "Customer",
								arrow: true,
								color: GROUP_COLOR.Sales.main
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border bg-card p-4 lg:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-2 text-sm font-semibold text-muted-foreground",
							children: [
								"Sales by month — ",
								y,
								" and ",
								y - 1
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-56",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
									data: stats.byMonth,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											strokeDasharray: "3 3",
											vertical: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "month",
											tick: { fontSize: 11 }
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: { fontSize: 11 },
											tickFormatter: (n) => `$${Math.round(n / 1e3)}k`,
											width: 48
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (n) => fmtMoney(n) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: String(y - 1),
											fill: "#cbd5e1",
											radius: [
												3,
												3,
												0,
												0
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
											dataKey: String(y),
											fill: GROUP_COLOR.Sales.main,
											radius: [
												3,
												3,
												0,
												0
											]
										})
									]
								})
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-sm font-semibold text-muted-foreground",
								children: "Top customers this year"
							}),
							stats.top.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "No sales yet this year."
							}),
							stats.top.map(([name, total], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 border-b py-2 text-sm last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "truncate",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mr-2 text-muted-foreground",
										children: [i + 1, "."]
									}), name]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: fmtMoney(total)
								})]
							}, name))
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold text-muted-foreground",
							children: [
								"Quotes to follow up (",
								due.length,
								")",
								stale > 0 && ` · ${stale} older than ${r.quote_close_days} days`
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/settings",
							className: "text-xs text-primary underline",
							children: r.followup_enabled ? "Follow-up rules" : "Turn on daily follow-ups"
						})]
					}), due.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Nothing to follow up today."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y",
						children: due.slice(0, 12).map(({ q, st }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/sales/$id",
									params: { id: q.id },
									className: "w-28 font-medium underline",
									children: q.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate",
									children: q.customer_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [ageDays(q.order_date), " days"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-20 text-right font-semibold",
									children: fmtMoney(q.total)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-0.5 text-xs ${st === "second" ? "bg-orange-100 text-orange-800" : "bg-sky-100 text-sky-800"}`,
									children: st === "second" ? "2nd follow-up" : "1st follow-up"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/sales/$id",
										params: { id: q.id },
										search: { followup: "1" },
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email follow-up"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void closeQuote(q.id),
									children: "Close quote"
								})
							]
						}, q.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/sales/$id",
							icon: FileText,
							label: "New quote",
							search: { kind: "quote" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/sales/$id",
							icon: ShoppingCart,
							label: "New invoice",
							search: { kind: "order" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/products",
							icon: Package,
							label: "Find a product"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
							to: "/stock",
							icon: Boxes,
							label: "Check stock"
						})
					]
				})
			] })
		]
	});
}
function Tile({ to, icon: Icon, label, value, sub, good, bad }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "rounded-2xl border bg-card p-4 transition-colors hover:bg-muted/50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: bad ? "h-5 w-5 text-primary" : "h-5 w-5 text-muted-foreground" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl font-bold",
				children: value
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-xs ${good ? "text-emerald-700" : bad ? "text-primary" : "text-muted-foreground"}`,
				children: sub
			})
		]
	});
}
function FlowStep({ to, icon: Icon, label, arrow, strong, color }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group relative flex flex-col items-center gap-2 rounded-xl p-2 hover:bg-muted/60",
		children: [
			arrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "absolute -left-2 top-5 h-4 w-4 text-muted-foreground/50 sm:top-6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `grid place-items-center rounded-2xl text-white shadow-sm ${strong ? "h-14 w-14 sm:h-16 sm:w-16" : "h-11 w-11 sm:h-14 sm:w-14"}`,
				style: { backgroundColor: color },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 sm:h-7 sm:w-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: strong ? "font-semibold uppercase" : "uppercase",
				children: label
			})
		]
	});
}
function Quick({ to, icon: Icon, label, search }) {
	const cls = "flex items-center gap-2 rounded-xl border bg-card px-3 py-3 text-sm font-medium hover:bg-muted/50";
	if (to === "/sales/$id") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/sales/$id",
		params: { id: "new" },
		search: search ?? {},
		className: cls,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-primary" }), label]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cls,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4 text-primary" }), label]
	});
}
//#endregion
export { OverviewPage as component };
