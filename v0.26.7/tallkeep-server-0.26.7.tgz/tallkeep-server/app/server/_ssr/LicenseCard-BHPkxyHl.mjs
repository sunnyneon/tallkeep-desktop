import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as supabase } from "./client-sss9hg5u.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { I as RefreshCw, dt as LoaderCircle, yt as KeyRound } from "../_libs/lucide-react.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as EDITIONS, t as ADDONS_FOR_SALE } from "./editions-CIhnK_Ff.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/LicenseCard-BHPkxyHl.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function useMyAccount() {
	return useQuery({
		queryKey: ["my-account"],
		staleTime: 6e5,
		queryFn: async () => {
			const { data, error } = await db.from("orgs").select("*").maybeSingle();
			if (error) return null;
			return data ?? null;
		}
	});
}
/** Whole days left in the free trial (0 when it has ended). */
var trialDaysLeft = (a) => a?.status === "trial" && a.trial_ends_at ? Math.max(0, Math.ceil((Date.parse(a.trial_ends_at) - Date.now()) / 864e5)) : null;
/** Can this account still add and change things? (Same rule as the database.) */
var canWrite = (a) => !a || a.is_platform && a.edition !== "desktop" || a.status === "active" || a.status === "past_due" || a.status === "trial" && (!a.trial_ends_at || Date.parse(a.trial_ends_at) > Date.now());
/** Where people choose or change their plan. */
var PLANS_URL = "https://tallkeep.com/pricing";
var bridge = () => (typeof window !== "undefined" ? window.tallkeep : void 0) ?? {};
function useUpdateStatus() {
	const [st, setSt] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const b = bridge();
		if (!b.updateStatus) return;
		const read = () => void b.updateStatus().then(setSt).catch(() => {});
		read();
		const t = setInterval(read, 6e4);
		window.addEventListener("focus", read);
		return () => {
			clearInterval(t);
			window.removeEventListener("focus", read);
		};
	}, []);
	return [st, setSt];
}
async function installUpdate() {
	const r = await bridge().installUpdate?.();
	if (r && !r.ok && !r.canceled) toast.error(r.error ?? "The update didn't start.");
}
/** Settings → Plan & computer: the version here, and checking for a new one. */
function UpdatesCard() {
	const [st, setSt] = useUpdateStatus();
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!st) return null;
	const dl = st.downloading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: st.officeComputer ? "Update Tallkeep" : "Update the Tallkeep app on this computer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"This computer has Tallkeep ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.current }),
					".",
					" ",
					st.officeComputer ? "It looks for a new version every few hours and downloads it by itself; you choose when to install it." : "It follows the office computer: when that one is updated, this one offers the same update."
				]
			}),
			dl && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }),
					" Downloading ",
					dl.version,
					dl.size ? ` (${Math.round(dl.got / dl.size * 100)}%)` : "…"
				]
			}),
			st.renew && !st.ready && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: [
					"Tallkeep ",
					st.renew.version,
					" is out. Your license includes updates until",
					" ",
					(/* @__PURE__ */ new Date(`${st.renew.until}T12:00:00`)).toLocaleDateString(),
					", so this computer keeps the version it has.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://app.tallkeep.com/upgrade",
						target: "_blank",
						rel: "noreferrer",
						className: "underline",
						children: "Renew updates"
					}),
					" ",
					"to get it."
				]
			}),
			st.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [
						"Tallkeep ",
						st.ready.version,
						" is ready.",
						st.ready.notes ? ` ${sentence(st.ready.notes)}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void installUpdate(),
					children: "Update now"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				disabled: busy || st.checking || !!dl,
				onClick: async () => {
					setBusy(true);
					try {
						const r = await bridge().checkUpdate();
						setSt(r);
						if (r.error) toast.error(`Couldn't check: ${r.error}`);
						else if (!r.ready) toast.success("You have the newest Tallkeep.");
					} finally {
						setBusy(false);
					}
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: busy ? "h-4 w-4 animate-spin" : "h-4 w-4" }), busy ? "Checking…" : "Check for updates"]
			}),
			st.error && !busy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["Last check didn't work: ", st.error]
			})
		]
	});
}
/** Release notes as a sentence (ends with a period). */
var sentence = (t) => /[.!?]$/.test(t.trim()) ? t.trim() : `${t.trim()}.`;
/** Updates for Tallkeep in Docker (no Tallkeep window): what's new, and Update now. */
async function post(body) {
	const { data } = await supabase.auth.getSession();
	const r = await fetch("/tallkeep/self-update", {
		method: "POST",
		headers: {
			authorization: `Bearer ${data.session?.access_token ?? ""}`,
			"content-type": "application/json"
		},
		body: JSON.stringify(body)
	});
	const out = await r.json().catch(() => ({}));
	if (!r.ok) throw new Error(out.message ?? "That didn't work.");
	return out;
}
/** Waits for Tallkeep to come back after an update, then reloads the page. */
function waitAndReload() {
	const started = Date.now();
	const tick = async () => {
		try {
			if ((await fetch("/tallkeep/health", { cache: "no-store" })).ok && Date.now() - started > 8e3) return window.location.reload();
		} catch {}
		if (Date.now() - started < 6e5) setTimeout(() => void tick(), 3e3);
	};
	setTimeout(() => void tick(), 5e3);
}
function DockerUpdatesCard() {
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [updating, setUpdating] = (0, import_react.useState)(false);
	const { data: st } = useQuery({
		queryKey: ["docker-updates"],
		queryFn: async () => {
			const r = await fetch("/tallkeep/self-update");
			return r.ok ? await r.json() : null;
		}
	});
	if (!st) return null;
	const check = async () => {
		setBusy(true);
		try {
			const r = await post({ check: true });
			qc.setQueryData(["docker-updates"], r);
			if (r.error) toast.error(`Couldn't check: ${r.error}`);
			else if (!r.latest) toast.success("You have the newest Tallkeep.");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	};
	const update = async () => {
		setUpdating(true);
		try {
			await post({});
			waitAndReload();
		} catch (e) {
			toast.error(e.message);
			setUpdating(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-semibold",
				children: "Update the server (where the books are)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"The server that keeps everyone's books has Tallkeep ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: st.current ?? "?" }),
					". It looks for a new version every few hours; you choose when to install it. Update the server first, then each computer's app."
				]
			}),
			updating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: "Updating… Tallkeep saves a backup of the books, closes for a minute or two and opens again. This page reloads by itself."
			}) : st.renew ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border bg-muted/40 p-3 text-sm",
				children: [
					"Tallkeep ",
					st.renew.version,
					" is out. Your license includes updates until",
					" ",
					(/* @__PURE__ */ new Date(`${st.renew.until}T12:00:00`)).toLocaleDateString(),
					", so this server keeps the version it has.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://app.tallkeep.com/upgrade",
						target: "_blank",
						rel: "noreferrer",
						className: "underline",
						children: "Renew updates"
					}),
					" ",
					"to get it."
				]
			}) : st.latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-sm text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex-1",
					children: [
						"Tallkeep ",
						st.latest,
						" is ready.",
						st.notes ? ` ${sentence(st.notes)}` : "",
						" Everyone is disconnected for a minute or two while it updates."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => void update(),
					children: "Update now"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				disabled: busy,
				onClick: () => void check(),
				children: busy ? "Checking…" : "Check for updates"
			})
		]
	});
}
/** Renew updates or add companies/people (Tallkeep's server). */
var UPGRADE_URL = "https://app.tallkeep.com/upgrade";
function useDesktopLicense() {
	return useQuery({
		queryKey: ["desktop-license"],
		queryFn: async () => {
			const r = await fetch("/tallkeep/license");
			if (!r.ok) throw new Error("Couldn't read the license.");
			return await r.json();
		}
	});
}
var many = (n, one, more) => n == null ? `any number of ${more}` : `${n} ${n === 1 ? one : more}`;
/** Settings → Plan & computer on an office computer: the trial or the license, and the key box. */
function LicenseCard() {
	const qc = useQueryClient();
	const { data: lic } = useDesktopLicense();
	const [key, setKey] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [changing, setChanging] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		try {
			const { data } = await supabase.auth.getSession();
			const r = await fetch("/tallkeep/license", {
				method: "POST",
				headers: {
					authorization: `Bearer ${data.session?.access_token ?? ""}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({ key })
			});
			const out = await r.json().catch(() => ({}));
			if (!r.ok) throw new Error(out.message ?? "That didn't work.");
			toast.success(out.checked ? "License checked with Tallkeep and saved. Thank you!" : "License saved. Tallkeep will check it when this computer is online.");
			setKey("");
			setChanging(false);
			await qc.invalidateQueries({ queryKey: ["desktop-license"] });
			await qc.invalidateQueries({ queryKey: ["my-account"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function checkNow() {
		setBusy(true);
		try {
			const { data } = await supabase.auth.getSession();
			const before = lic?.updatesUntil;
			const r = await fetch("/tallkeep/license", {
				method: "POST",
				headers: {
					authorization: `Bearer ${data.session?.access_token ?? ""}`,
					"content-type": "application/json"
				},
				body: JSON.stringify({ check: true })
			});
			const out = await r.json().catch(() => ({}));
			if (!r.ok) throw new Error(out.message ?? "That didn't work.");
			if (!out.checked) toast.error("Couldn't reach Tallkeep. Check the internet connection and try again.");
			else if (out.updatesUntil !== before || out.companies !== lic?.companies || out.users !== lic?.users) toast.success("Your updated license is in. Thank you!");
			else toast.success("Checked with Tallkeep: your license is up to date.");
			await qc.invalidateQueries({ queryKey: ["desktop-license"] });
			await qc.invalidateQueries({ queryKey: ["my-account"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	if (!lic) return null;
	const upgradeUrl = lic.mode === "licensed" || lic.mode === "invalid" ? `${UPGRADE_URL}?${new URLSearchParams({
		license: lic.id ?? "",
		email: lic.email ?? ""
	})}` : UPGRADE_URL;
	const licensed = lic.mode === "licensed";
	const invalid = lic.mode === "invalid";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "flex items-center gap-2 font-display text-xl font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-5 w-5" }), " Your license"]
			}),
			invalid ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-900 dark:border-red-800 dark:bg-red-950/40 dark:text-red-100",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: "License not valid."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [lic.message, lic.reason === "elsewhere" && lic.computers?.length ? ` (${lic.computers.join(", ")})` : ""] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Your books are read-only: you can still open, print and download everything. Enter a valid license key, or contact Tallkeep." })
				]
			}) : licensed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Licensed to ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: lic.to }),
						lic.email ? ` (${lic.email})` : "",
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Plan:",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [lic.edition && EDITIONS[lic.edition] ? EDITIONS[lic.edition].label : "Full Business + Real Estate + Crypto Tax (everything)", (lic.edition ? lic.addons ?? [] : []).map((a) => ` + ${ADDONS_FOR_SALE[a]?.label ?? a}`).join("")] }),
						".",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://app.tallkeep.com/buy?upgrade=1",
							target: "_blank",
							rel: "noreferrer",
							className: "text-[#C2410C] underline",
							children: "Add to my license"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Includes ",
						many(lic.companies, "company", "companies"),
						" and",
						" ",
						many(lic.users, "person", "people"),
						"."
					] }),
					lic.expires && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-lg bg-sky-50 p-2 text-sky-900 dark:bg-sky-950/40 dark:text-sky-100",
						children: [
							"Early access license: works until ",
							fmtDate(lic.expires),
							". Thank you for testing! Use",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Report a problem" }),
							" in Help (F1) for anything that doesn't work right."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lic.updatesUntil ? /* @__PURE__ */ new Date(`${lic.updatesUntil}T12:00:00`) >= /* @__PURE__ */ new Date() ? `Updates included until ${fmtDate(lic.updatesUntil)}.` : `Updates ended on ${fmtDate(lic.updatesUntil)}. Tallkeep keeps working; renew to get new versions.` : "Updates included." }),
					lic.offline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-amber-700 dark:text-amber-300",
						children: [
							"Not checked with Tallkeep yet (no internet?). It keeps working ",
							lic.offlineDaysLeft,
							" ",
							"more day",
							lic.offlineDaysLeft === 1 ? "" : "s",
							" without a check."
						]
					}) : lic.checkedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Checked with Tallkeep ",
							fmtDate(lic.checkedAt),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: ["License ", lic.id]
					})
				]
			}) : lic.mode === "trial" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Free trial:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [
						lic.daysLeft,
						" day",
						lic.daysLeft === 1 ? "" : "s",
						" left"
					] }),
					" ",
					"(until ",
					fmtDate(lic.trialEnds),
					"). The trial includes ",
					lic.companies,
					" companies and",
					" ",
					lic.users,
					" people. Then the books become read-only until you enter a license key."
				]
			}) : lic.mode === "ended" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rounded-xl border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-100",
				children: [
					"The free trial ended on ",
					fmtDate(lic.trialEnds),
					". Your books are read-only: you can still open, print and download everything. Enter a license key to keep working."
				]
			}) : null,
			(!licensed || invalid || changing) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-sm font-medium",
						htmlFor: "license-key",
						children: "License key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "license-key",
						rows: 3,
						value: key,
						onChange: (e) => setKey(e.target.value),
						placeholder: "Paste the key from your email (it starts with TK1.)",
						className: "font-mono text-xs"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => void save(),
								disabled: busy || !key.trim(),
								children: busy ? "Checking…" : "Save the license key"
							}),
							!licensed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "https://tallkeep.com/pricing",
									target: "_blank",
									rel: "noreferrer",
									children: "Buy Tallkeep"
								})
							}),
							changing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setChanging(false),
								children: "Cancel"
							})
						]
					})
				]
			}),
			licensed && !changing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: upgradeUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "Renew updates"
						})
					}),
					(lic.companies != null || lic.users != null) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: upgradeUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "Add companies or people"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => void checkNow(),
						disabled: busy,
						children: busy ? "Checking…" : "Check for my updated key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setChanging(true),
						children: "Enter a new license key"
					})
				]
			})
		]
	});
}
//#endregion
export { canWrite as a, sentence as c, useMyAccount as d, useUpdateStatus as f, UpdatesCard as i, trialDaysLeft as l, LicenseCard as n, installUpdate as o, waitAndReload as p, PLANS_URL as r, post as s, DockerUpdatesCard as t, useDesktopLicense as u };
