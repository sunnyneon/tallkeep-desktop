import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { k as Search, kn as Barcode, z as Printer } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/labels-CYxL1rHT.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/**
* Code 128 barcodes (set B: letters, digits and signs), drawn as SVG: works with every barcode
* scanner and phone. Also makes a new code for items that don't have one: 12 digits starting
* with 2 (the range stores use for their own items) with a UPC check digit.
*/
var P = [
	"212222",
	"222122",
	"222221",
	"121223",
	"121322",
	"131222",
	"122213",
	"122312",
	"132212",
	"221213",
	"221312",
	"231212",
	"112232",
	"122132",
	"122231",
	"113222",
	"123122",
	"123221",
	"223211",
	"221132",
	"221231",
	"213212",
	"223112",
	"312131",
	"311222",
	"321122",
	"321221",
	"312212",
	"322112",
	"322211",
	"212123",
	"212321",
	"232121",
	"111323",
	"131123",
	"131321",
	"112313",
	"132113",
	"132311",
	"211313",
	"231113",
	"231311",
	"112133",
	"112331",
	"132131",
	"113123",
	"113321",
	"133121",
	"313121",
	"211331",
	"231131",
	"213113",
	"213311",
	"213131",
	"311123",
	"311321",
	"331121",
	"312113",
	"312311",
	"332111",
	"314111",
	"221411",
	"431111",
	"111224",
	"111422",
	"121124",
	"121421",
	"141122",
	"141221",
	"112214",
	"112412",
	"122114",
	"122411",
	"142112",
	"142211",
	"241211",
	"221114",
	"413111",
	"241112",
	"134111",
	"111242",
	"121142",
	"121241",
	"114212",
	"124112",
	"124211",
	"411212",
	"421112",
	"421211",
	"212141",
	"214121",
	"412121",
	"111143",
	"111341",
	"131141",
	"114113",
	"114311",
	"411113",
	"411311",
	"113141",
	"114131",
	"311141",
	"411131",
	"211412",
	"211214",
	"211232",
	"2331112"
];
var START_B = 104;
var STOP = 106;
/** Bar and space widths, left to right (starting with a bar). */
function code128Widths(text) {
	const codes = [START_B];
	for (const ch of text) {
		const c = ch.charCodeAt(0);
		if (c < 32 || c > 126) throw new Error("A barcode can only have letters, digits and signs.");
		codes.push(c - 32);
	}
	const sum = codes.reduce((t, c, i) => t + c * (i === 0 ? 1 : i), 0);
	codes.push(sum % 103, STOP);
	return codes.flatMap((c) => [...P[c]].map(Number));
}
/** An SVG of the barcode (quiet zone included), heightPx tall, each narrow bar `x` wide. */
function code128Svg(text, x = 2, heightPx = 60) {
	const w = code128Widths(text);
	const quiet = 10;
	let pos = quiet;
	const rects = [];
	w.forEach((n, i) => {
		if (i % 2 === 0) rects.push(`<rect x="${pos * x}" y="0" width="${n * x}" height="${heightPx}"/>`);
		pos += n;
	});
	return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${(pos + quiet) * x} ${heightPx}" preserveAspectRatio="none" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="#fff"/><g fill="#000">${rects.join("")}</g></svg>`;
}
/** A new item code: 2 + 10 random digits + UPC check digit. */
function newItemCode() {
	const d = [2, ...Array.from({ length: 10 }, () => Math.floor(Math.random() * 10))];
	const odd = d.filter((_, i) => i % 2 === 0).reduce((a, b) => a + b, 0);
	const even = d.filter((_, i) => i % 2 === 1).reduce((a, b) => a + b, 0);
	const check = (10 - (odd * 3 + even) % 10) % 10;
	return [...d, check].join("");
}
/**
* Print barcode labels: pick items, give a barcode to the ones without one, pick the label size
* (Avery sheets or a label printer), print. Each label: the name, the barcode and its number
* (and the price, if wanted). Scanning a label opens the item, counts it, or adds it to an order.
*/
/** Label sizes, in inches. Sheets: columns, rows, margins and gaps of the Avery sheet. */
var SIZES = {
	avery5160: {
		label: "Avery 5160 sheet: 30 labels, 1\" × 2⅝\"",
		w: 2.625,
		h: 1,
		cols: 3,
		rows: 10,
		top: .5,
		left: .1875,
		gapX: .125,
		gapY: 0,
		sheet: true
	},
	avery5167: {
		label: "Avery 5167 sheet: 80 small labels, ½\" × 1¾\"",
		w: 1.75,
		h: .5,
		cols: 4,
		rows: 20,
		top: .5,
		left: .28,
		gapX: .3,
		gapY: 0,
		sheet: true
	},
	roll2x1: {
		label: "Label printer: 2\" × 1\"",
		w: 2,
		h: 1,
		cols: 1,
		rows: 1,
		top: 0,
		left: 0,
		gapX: 0,
		gapY: 0,
		sheet: false
	},
	roll225: {
		label: "Label printer: 2¼\" × 1¼\"",
		w: 2.25,
		h: 1.25,
		cols: 1,
		rows: 1,
		top: 0,
		left: 0,
		gapX: 0,
		gapY: 0,
		sheet: false
	}
};
function LabelsPage() {
	const qc = useQueryClient();
	const { data: products, isLoading } = useQuery({
		queryKey: ["products-labels"],
		queryFn: () => fetchAll("products", "id,name,barcode,price,is_active")
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [counts, setCounts] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const [size, setSize] = (0, import_react.useState)("avery5160");
	const [withPrice, setWithPrice] = (0, import_react.useState)(false);
	const [skip, setSkip] = (0, import_react.useState)(0);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const list = (0, import_react.useMemo)(() => {
		const w = q.trim().toLowerCase();
		return (products ?? []).filter((p) => p.is_active).filter((p) => !w || `${p.name} ${p.barcode ?? ""}`.toLowerCase().includes(w)).sort((a, b) => a.name.localeCompare(b.name)).slice(0, 300);
	}, [products, q]);
	const picked = (products ?? []).filter((p) => (counts.get(p.id) ?? 0) > 0);
	const noCode = picked.filter((p) => !p.barcode);
	const setCount = (id, n) => setCounts((m) => {
		const x = new Map(m);
		if (n > 0) x.set(id, n);
		else x.delete(id);
		return x;
	});
	async function giveCodes() {
		setBusy(true);
		try {
			const taken = new Set((products ?? []).map((p) => p.barcode).filter(Boolean));
			for (const p of noCode) {
				let code = newItemCode();
				while (taken.has(code)) code = newItemCode();
				taken.add(code);
				const { error } = await db.from("products").update({ barcode: code }).eq("id", p.id);
				if (error) throw new Error(error.message);
			}
			toast.success(`${noCode.length} item${noCode.length === 1 ? "" : "s"} got a barcode.`);
			await qc.invalidateQueries({ queryKey: ["products-labels"] });
			qc.invalidateQueries({ queryKey: ["products"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	const S = SIZES[size];
	const labels = picked.filter((p) => p.barcode).flatMap((p) => Array.from({ length: counts.get(p.id) ?? 0 }, () => p));
	const cells = [...Array.from({ length: S.sheet ? skip : 0 }, () => null), ...labels];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: `
        @media print {
          @page { size: ${S.sheet ? "8.5in 11in" : `${S.w}in ${S.h}in`}; margin: 0; }
          body * { visibility: hidden; }
          #labels, #labels * { visibility: visible; }
          #labels { position: absolute; left: 0; top: 0; }
        }
      ` }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 print:hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
					title: "Barcode Labels",
					text: "Pick the items, then print labels for the shelf, the bin or the item. Items without a barcode can get one here; scanning the label then finds the item everywhere in Tallkeep."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 lg:grid-cols-[1fr_320px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-2xl border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "pl-8",
								placeholder: "Find items",
								value: q,
								onChange: (e) => setQ(e.target.value)
							})]
						}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-h-[60vh] divide-y overflow-y-auto",
							children: list.map((p) => {
								const n = counts.get(p.id) ?? 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-3 py-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: n > 0,
											onChange: (e) => setCount(p.id, e.target.checked ? 1 : 0)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate",
												children: p.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-xs text-muted-foreground",
												children: p.barcode ? `Barcode ${p.barcode}` : "No barcode yet"
											})]
										}),
										n > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											min: 1,
											className: "h-8 w-20",
											value: n,
											title: "How many labels",
											onChange: (e) => setCount(p.id, Math.max(1, Number(e.target.value) || 1))
										})
									]
								}, p.id);
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 rounded-2xl border bg-card p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold",
								children: [
									labels.length,
									" label",
									labels.length === 1 ? "" : "s"
								]
							}),
							noCode.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-amber-50 p-3 text-amber-900 dark:bg-amber-950 dark:text-amber-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									noCode.length,
									" picked item",
									noCode.length === 1 ? " has" : "s have",
									" no barcode."
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									className: "mt-2",
									disabled: busy,
									onClick: () => void giveCodes(),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Barcode, { className: "h-4 w-4" }),
										" Give ",
										noCode.length === 1 ? "it" : "them",
										" a barcode"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Labels"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "h-9 w-full rounded-md border bg-background px-2",
									value: size,
									onChange: (e) => setSize(e.target.value),
									children: Object.keys(SIZES).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: k,
										children: SIZES[k].label
									}, k))
								})]
							}),
							S.sheet && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Skip labels already used on the sheet"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: skip,
									onChange: (e) => setSkip(Math.max(0, Number(e.target.value) || 0))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: withPrice,
									onChange: (e) => setWithPrice(e.target.checked)
								}), "Show the price"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "w-full",
								disabled: !labels.length,
								onClick: () => window.print(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print the labels"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "In the print window, set the scale to 100% (Actual size) and margins to None."
							})
						]
					})]
				}),
				labels.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Preview"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "labels",
			style: {
				width: S.sheet ? "8.5in" : `${S.w}in`,
				paddingTop: `${S.top}in`,
				paddingLeft: `${S.left}in`,
				display: "grid",
				gridTemplateColumns: `repeat(${S.cols}, ${S.w}in)`,
				gridAutoRows: `${S.h}in`,
				columnGap: `${S.gapX}in`,
				rowGap: `${S.gapY}in`,
				background: "white",
				color: "black"
			},
			children: cells.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					width: `${S.w}in`,
					height: `${S.h}in`,
					padding: "0.06in 0.08in",
					overflow: "hidden",
					display: "flex",
					flexDirection: "column",
					justifyContent: "center",
					breakInside: "avoid",
					pageBreakAfter: !S.sheet ? "always" : void 0
				},
				className: "outline-dashed outline-1 -outline-offset-1 outline-gray-300 print:outline-none",
				children: p && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							fontSize: S.h < .75 ? "6pt" : "8pt",
							lineHeight: 1.1,
							fontWeight: 600,
							maxHeight: S.h < .75 ? "7pt" : "18pt",
							overflow: "hidden"
						},
						children: [p.name, withPrice && p.price ? ` · ${fmtMoney(Number(p.price))}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							height: S.h < .75 ? "0.22in" : `${S.h * .45}in`,
							marginTop: "0.02in"
						},
						dangerouslySetInnerHTML: { __html: code128Svg(p.barcode).replace("<svg ", "<svg width=\"100%\" height=\"100%\" ") }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							fontSize: "6pt",
							textAlign: "center",
							letterSpacing: "0.05em"
						},
						children: p.barcode
					})
				] })
			}, i))
		})
	] });
}
//#endregion
export { LabelsPage as component };
