import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/pay.functions-B8cDFG76.js
/** The customer's "Pay now" page (no sign-in). See pay.server.ts. */
var tokenOk = (t) => typeof t === "string" && /^[A-Za-z0-9_-]{10,40}$/.test(t);
async function load(token) {
	const p = await import("./pay.server-DmrbyPTQ.mjs");
	const db = await p.admin();
	const { data: r } = await db.from("pay_requests").select("*").eq("token", token).maybeSingle();
	if (!r) return null;
	const { data: m } = await db.from("pay_merchants").select("*").eq("id", r.merchant_id).maybeSingle();
	return {
		p,
		req: r,
		m
	};
}
var page = (x) => ({
	business: x.m.business_name,
	number: x.req.number,
	customer: x.req.customer_name,
	amountCents: x.req.amount_cents,
	paidCents: x.req.paid_cents,
	currency: x.req.currency,
	status: x.req.status,
	kind: x.req.kind ?? "invoice",
	doc: x.req.doc ?? null,
	acceptedAt: x.req.accepted_at ?? null,
	acceptedName: x.req.accepted_name ?? null,
	pending: !!x.req.pending_at
});
var getPayPage_createServerFn_handler = createServerRpc({
	id: "65167bf74740ab17c0fbab7a39a651e64108b27c734b7bc92f51ab7af27647c0",
	name: "getPayPage",
	filename: "src/lib/pay.functions.ts"
}, (opts) => getPayPage.__executeServer(opts));
var getPayPage = createServerFn({ method: "GET" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	return {
		token: d.token,
		session: /^cs_[A-Za-z0-9_]+$/.test(d.session ?? "") ? d.session : void 0
	};
}).handler(getPayPage_createServerFn_handler, async ({ data }) => {
	const x = await load(data.token);
	if (!x) return null;
	if (data.session && x.req.status === "open") {
		const done = await x.p.fulfillPay(x.req.id, data.session).catch(() => null);
		if (done) x.req = done;
	}
	return page(x);
});
var startPayCheckout_createServerFn_handler = createServerRpc({
	id: "1451e52a03e1d052f3d1a13763407804acbc263dab8122da9b78e14acc3f6c68",
	name: "startPayCheckout",
	filename: "src/lib/pay.functions.ts"
}, (opts) => startPayCheckout.__executeServer(opts));
var startPayCheckout = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This payment link isn't right.");
	if (!/^https?:\/\/[^/\s]+$/.test(d.origin)) throw new Error("Bad address.");
	return d;
}).handler(startPayCheckout_createServerFn_handler, async ({ data }) => {
	const x = await load(data.token);
	if (!x || x.req.status !== "open") throw new Error("This invoice can't be paid here anymore.");
	if (!x.m.stripe_account) throw new Error("This business can't take card payments yet.");
	if (x.req.pending_at) throw new Error("A bank payment for this is already on its way.");
	const quote = x.req.kind === "quote";
	if (quote && !x.req.accepted_at) throw new Error("Accept the quote first.");
	if (!(x.req.amount_cents > 0)) throw new Error("Nothing to pay here.");
	const pct = await x.p.appFeePct();
	const fee = Math.round(x.req.amount_cents * pct / 100);
	const back = `${data.origin}/pay/${data.token}`;
	const what = quote ? `Deposit for quote ${x.req.number ?? ""}`.trim() : `Invoice ${x.req.number ?? ""}`.trim();
	const form = {
		mode: "payment",
		"line_items[0][price_data][currency]": x.req.currency,
		"line_items[0][price_data][product_data][name]": what,
		"line_items[0][price_data][unit_amount]": x.req.amount_cents,
		"line_items[0][quantity]": 1,
		customer_email: x.req.customer_email || void 0,
		"payment_intent_data[description]": `${x.m.business_name}: ${what}`,
		...fee > 0 ? { "payment_intent_data[application_fee_amount]": fee } : {},
		"metadata[pay_request]": x.req.id,
		"payment_intent_data[metadata][pay_request]": x.req.id,
		success_url: `${back}?session={CHECKOUT_SESSION_ID}`,
		cancel_url: back
	};
	let s;
	try {
		s = await x.p.stripe("checkout/sessions", x.req.currency === "usd" ? {
			...form,
			"payment_method_types[0]": "card",
			"payment_method_types[1]": "us_bank_account"
		} : form, x.m.stripe_account);
	} catch (e) {
		if (x.req.currency !== "usd" || !/us_bank_account|payment method/i.test(e.message)) throw e;
		s = await x.p.stripe("checkout/sessions", form, x.m.stripe_account);
	}
	await (await x.p.admin()).from("pay_requests").update({
		stripe_session: s.id,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", x.req.id);
	return { url: s.url };
});
var acceptQuote_createServerFn_handler = createServerRpc({
	id: "5dc7d881149d1054bafa0caa5fa9c389eb01afc534cc586a6ed5aef7f445bd6d",
	name: "acceptQuote",
	filename: "src/lib/pay.functions.ts"
}, (opts) => acceptQuote.__executeServer(opts));
var acceptQuote = createServerFn({ method: "POST" }).inputValidator((d) => {
	if (!tokenOk(d.token)) throw new Error("This link isn't right.");
	const name = String(d.name ?? "").trim().slice(0, 120);
	if (name.length < 2) throw new Error("Type your name to accept.");
	return {
		token: d.token,
		name
	};
}).handler(acceptQuote_createServerFn_handler, async ({ data }) => {
	const x = await load(data.token);
	if (!x || x.req.kind !== "quote" || x.req.status !== "open") throw new Error("This quote can't be accepted here anymore. Please contact the business.");
	if (!x.req.accepted_at) {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const up = {
			accepted_at: now,
			accepted_name: data.name,
			...x.req.amount_cents > 0 ? {} : { status: "accepted" },
			updated_at: now
		};
		await (await x.p.admin()).from("pay_requests").update(up).eq("id", x.req.id).eq("status", "open");
		x.req = {
			...x.req,
			...up
		};
	}
	return page(x);
});
//#endregion
export { acceptQuote_createServerFn_handler, getPayPage_createServerFn_handler, startPayCheckout_createServerFn_handler };
