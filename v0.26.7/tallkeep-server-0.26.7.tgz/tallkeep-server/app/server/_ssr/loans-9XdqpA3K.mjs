import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, d as today, f as useAccounts, p as useTotals } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { i as matchWord, n as loanKind, o as saveLoan } from "./loans-Dgof3KNS.mjs";
import { B as Plus, Tt as HousePlus, W as Pencil, xt as Inbox } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/loans-9XdqpA3K.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var T = (t) => db.from(t);
var KINDS = [
	["mortgage", "Mortgage"],
	["car", "Car loan"],
	["student", "Student loan"],
	["personal", "Personal loan"],
	["heloc", "Home equity line"],
	["other", "Other loan"]
];
var kindName = (k) => KINDS.find((x) => x[0] === k)?.[1] ?? "Loan";
function LoansPage() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: totals } = useTotals(null, today());
	const loans = useQuery({
		queryKey: ["loans"],
		queryFn: async () => {
			const { data, error } = await T("loans").select("*").order("updated_at");
			if (error) throw new Error(error.message);
			return data ?? [];
		}
	});
	const [edit, setEdit] = (0, import_react.useState)(null);
	if (!accounts || !totals || loans.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) });
	const bal = balFrom(totals);
	const list = loans.data ?? [];
	const bare = accounts.filter((a) => a.is_active && (a.kind === "long_term_liability" || a.kind === "other_liability" && /loan|mortgage|note|financ|auto|truck|car\b/i.test(a.name)) && Math.abs(bal(a)) > .004 && !list.some((l) => l.account_id === a.id));
	const owed = list.reduce((t, l) => {
		const a = accounts.find((x) => x.id === l.account_id);
		return t + (a ? bal(a) : 0);
	}, 0) + bare.reduce((t, a) => t + bal(a), 0);
	const refresh = () => {
		qc.invalidateQueries({ queryKey: ["loans"] });
		qc.invalidateQueries({ queryKey: ["accounts"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Mortgage & Loans",
			text: "What you still owe, and where each payment goes. Drop each month's statement in the Shoebox and Tallkeep keeps it up to date: interest, escrow (taxes and insurance) and what pays down the loan.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/shoebox",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-4 w-4" }), " Drop a statement"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setEdit({}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add a loan"]
				})]
			})
		}),
		list.length + bare.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HousePlus, { className: "mx-auto h-8 w-8 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-semibold",
					children: "No loans yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-1 max-w-md text-sm text-muted-foreground",
					children: "The easiest way: drop your latest mortgage or loan statement in the Shoebox. Or click Add a loan and type what you owe. Paying rent instead? Add it in Bills, Rent & Subscriptions."
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground",
				children: "You still owe, all loans"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-2xl font-semibold",
				children: fmtMoney(owed)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-2",
			children: [list.map((l) => {
				const a = accounts.find((x) => x.id === l.account_id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 rounded-2xl border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: a?.name ?? kindName(l.loan_kind)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									kindName(l.loan_kind),
									l.lender,
									l.last4 ? `ending ${l.last4}` : null,
									l.rate ? `${l.rate}%` : null
								].filter(Boolean).join(" · ")
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => setEdit({
									loan: l,
									acct: a
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-4 w-4" }), " Change"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Owed now",
									value: fmtMoney(a ? bal(a) : 0),
									big: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Monthly payment",
									value: l.payment ? fmtMoney(Number(l.payment)) : "—",
									big: true
								}),
								l.interest != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Interest",
									value: fmtMoney(Number(l.interest))
								}),
								l.escrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Escrow (taxes, insurance)",
									value: fmtMoney(Number(l.escrow))
								}) : null,
								l.principal != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Pays down the loan",
									value: fmtMoney(Number(l.principal))
								}),
								l.due_date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									label: "Next payment due",
									value: fmtDate(l.due_date)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [l.match ? `Bank lines with "${l.match}" are split by themselves in Bank Feeds.` : "Payments wait in Bank Feeds for you. Click Change and fill in the word on the bank line to split them by themselves.", l.statement_date && ` Last statement: ${fmtDate(l.statement_date)}.`]
						})
					]
				}, l.id);
			}), bare.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border bg-card p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: a.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "No loan details yet: drop a statement, or add them."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setEdit({ acct: a }),
						children: "Add the details"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
					label: "Owed now",
					value: fmtMoney(bal(a)),
					big: true
				})]
			}, a.id))]
		})] }),
		edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoanForm, {
			loan: edit.loan,
			acct: edit.acct,
			owedNow: edit.acct ? bal(edit.acct) : null,
			accounts,
			onClose: () => setEdit(null),
			onSaved: refresh
		})
	] });
}
function Fact({ label, value, big }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-muted/40 p-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: big ? "text-lg font-semibold" : "font-medium",
			children: value
		})]
	});
}
var numOrNull = (v) => {
	const n = Number(v.replace(/[$,%\s]/g, ""));
	return v.trim() === "" || !Number.isFinite(n) ? null : Math.round(n * 1e3) / 1e3;
};
function LoanForm({ loan, acct, owedNow, accounts, onClose, onSaved }) {
	const s = (v) => v == null ? "" : String(v);
	const [start] = (0, import_react.useState)(() => ({ balance: s(owedNow != null && Math.abs(owedNow) > .004 ? owedNow : loan?.balance) }));
	const [f, setF] = (0, import_react.useState)({
		kind: loan?.loan_kind ?? "mortgage",
		name: acct?.name ?? "",
		lender: loan?.lender ?? "",
		last4: loan?.last4 ?? "",
		balance: start.balance,
		rate: s(loan?.rate),
		payment: s(loan?.payment),
		escrow: s(loan?.escrow),
		due: loan?.due_date ?? "",
		match: loan?.match ?? ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setF((x) => ({
		...x,
		...p
	}));
	async function save() {
		const balance = numOrNull(f.balance);
		if (balance == null) return void toast.error("Type what you still owe today.");
		if (!acct && !f.name.trim() && !f.lender.trim()) return void toast.error("Type a name for the loan, like Home mortgage.");
		setBusy(true);
		try {
			const kind = loanKind(f.kind);
			const payment = numOrNull(f.payment);
			const sameBalance = !!loan && f.balance === start.balance;
			const samePay = !!loan && payment === (loan.payment == null ? null : Number(loan.payment));
			const L = {
				kind,
				lender: f.lender.trim() || null,
				last4: /^\d{4}$/.test(f.last4.trim()) ? f.last4.trim() : null,
				statementDate: sameBalance ? loan?.statement_date ?? today() : today(),
				dueDate: f.due || null,
				payment,
				principal: samePay ? loan?.principal ?? null : null,
				interest: samePay ? loan?.interest ?? null : null,
				escrow: numOrNull(f.escrow),
				fees: null,
				balance: sameBalance && loan?.balance != null ? Number(loan.balance) : balance,
				rate: numOrNull(f.rate)
			};
			const r = await saveLoan(L, {
				accounts,
				step: () => void 0
			}, {
				...acct ? { accountId: acct.id } : f.name.trim() ? { name: f.name.trim() } : {},
				match: f.match.trim() || matchWord(L.lender)
			});
			if (acct && f.name.trim() && f.name.trim() !== acct.name) await T("accounts").update({ name: f.name.trim() }).eq("id", acct.id);
			if (r.state.startsWith("differs:")) toast.message("Saved. The books had a different balance, so it wasn't changed. Drop a statement in the Shoebox to match it.");
			else toast.success(r.split ? `Saved. ${r.split} payment${r.split === 1 ? "" : "s"} in Bank Feeds split.` : "Saved.");
			onSaved();
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: loan ? `Change ${acct?.name ?? "the loan"}` : "Add a loan" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Kind",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								value: f.kind,
								onChange: (e) => set({ kind: e.target.value }),
								children: KINDS.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.name,
								onChange: (e) => set({ name: e.target.value }),
								placeholder: "Home mortgage"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Lender",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.lender,
								onChange: (e) => set({ lender: e.target.value }),
								placeholder: "Lakeview Loan Servicing"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Last 4 digits of the loan number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								maxLength: 4,
								value: f.last4,
								onChange: (e) => set({ last4: e.target.value.replace(/\D/g, "") })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "You still owe today",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.balance,
								onChange: (e) => set({ balance: e.target.value }),
								placeholder: "287,904.12"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Interest rate (%)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.rate,
								onChange: (e) => set({ rate: e.target.value }),
								placeholder: "4.625"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Monthly payment",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.payment,
								onChange: (e) => set({ payment: e.target.value }),
								placeholder: "2,145.67"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Escrow in the payment (taxes, insurance)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f.escrow,
								onChange: (e) => set({ escrow: e.target.value }),
								placeholder: "0"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Next payment due",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: f.due,
								onChange: (e) => set({ due: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(L, {
							label: "Word on the bank line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.match,
								onChange: (e) => set({ match: e.target.value }),
								placeholder: matchWord(f.lender) ?? "lakeview"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Bank lines with that word are split by themselves: interest from the rate, the escrow, and the rest pays down the loan."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: busy,
						onClick: () => void save(),
						children: busy ? "Saving…" : "Save the loan"
					})]
				})
			]
		})
	});
}
function L({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { LoansPage as component };
