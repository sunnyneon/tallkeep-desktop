import { supabaseAdmin } from "./client.server-KzwUIAkW.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bankfeed.server-Blw8UdqC.js
var db = supabaseAdmin;
var plainUrl = (u) => /^https:\/\//i.test(u) || !!process.env["TALLKEEP_SIMPLEFIN_TEST"];
/** Turn the pasted setup code into the private access address. */
async function claimSetupCode(code) {
	const clean = code.replace(/\s+/g, "");
	let claim = "";
	try {
		claim = Buffer.from(clean, "base64").toString("utf8").trim();
	} catch {}
	if (!/^https?:\/\/\S+$/i.test(claim) || !plainUrl(claim)) throw new Error("That doesn't look like a SimpleFIN setup code. Copy the whole code from SimpleFIN and paste it again.");
	const res = await fetch(claim, {
		method: "POST",
		headers: { "content-length": "0" }
	});
	if (res.status === 403) throw new Error("SimpleFIN says this setup code was already used. Make a new setup code in SimpleFIN and paste that one.");
	if (!res.ok) throw new Error(`SimpleFIN didn't answer (${res.status}). Try again in a minute.`);
	const access = (await res.text()).trim();
	if (!/^https?:\/\/[^\s/]+:[^\s/]+@\S+$/i.test(access) || !plainUrl(access)) throw new Error("SimpleFIN sent back something unexpected. Try a new setup code.");
	return access;
}
/** Ask SimpleFIN for accounts (and their lines from `from`, when given). */
async function fetchAccounts(access, from, balancesOnly = false) {
	const u = new URL(access);
	const auth = Buffer.from(`${decodeURIComponent(u.username)}:${decodeURIComponent(u.password)}`).toString("base64");
	u.username = "";
	u.password = "";
	const base = u.toString().replace(/\/$/, "");
	const q = new URLSearchParams();
	if (balancesOnly) q.set("balances-only", "1");
	if (from) q.set("start-date", String(Math.floor(from.getTime() / 1e3)));
	const res = await fetch(`${base}/accounts?${q}`, { headers: { authorization: `Basic ${auth}` } });
	if (res.status === 402) throw new Error("Your SimpleFIN subscription needs paying. Renew it at SimpleFIN.");
	if (res.status === 403) throw new Error("SimpleFIN turned this connection off. Remove it here, then connect again with a new setup code.");
	if (!res.ok) throw new Error(`SimpleFIN didn't answer (${res.status}).`);
	return await res.json();
}
function problems(set) {
	const list = [...(set.errlist ?? []).map((e) => e.msg ?? e.code ?? ""), ...set.errors ?? []].filter(Boolean);
	return list.length ? [...new Set(list)].join(" ") : null;
}
var bankName = (set, a) => set.connections?.find((c) => c.conn_id === a.conn_id)?.name ?? a.org?.name ?? a.org?.domain ?? null;
/** Save the accounts SimpleFIN shares (new ones are added; names and balances are refreshed). */
async function saveAccounts(companyId, linkId, set) {
	const rows = (set.accounts ?? []).map((a) => ({
		company_id: companyId,
		link_id: linkId,
		remote_id: a.id,
		name: a.name,
		bank_name: bankName(set, a),
		currency: a.currency ?? null,
		balance: Number(a.balance) || 0,
		balance_date: a["balance-date"] ? (/* @__PURE__ */ new Date(a["balance-date"] * 1e3)).toISOString() : null
	}));
	if (!rows.length) return 0;
	const { error } = await db.from("bank_link_accounts").upsert(rows, { onConflict: "link_id,remote_id" });
	if (error) throw new Error(error.message);
	return rows.length;
}
/** Connect: claim the code, keep the address, and list the accounts it shares. */
async function connectSimplefin(companyId, userId, code) {
	const access = await claimSetupCode(code);
	const set = await fetchAccounts(access, void 0, true);
	const { data: link, error } = await db.from("bank_links").insert({
		company_id: companyId,
		access_url: access,
		name: "SimpleFIN",
		created_by: userId
	}).select("id").single();
	if (error) throw new Error(error.message);
	const n = await saveAccounts(companyId, link.id, set);
	await db.from("bank_links").update({ last_error: problems(set) }).eq("id", link.id);
	return {
		id: link.id,
		accounts: n
	};
}
var day = (d) => d.toISOString().slice(0, 10);
/**
* Bring in new lines for one company's connections. Lines go to Banking → For review; the
* bank's own line id stops doubles, so pulling again is harmless.
*/
async function pullCompany(companyId, onlyLink) {
	let q = db.from("bank_links").select("id,access_url").eq("company_id", companyId);
	if (onlyLink) q = q.eq("id", onlyLink);
	const { data: links } = await q;
	let added = 0;
	const errors = [];
	for (const link of links ?? []) try {
		added += await pullLink(companyId, link);
	} catch (e) {
		const msg = e.message;
		errors.push(msg);
		await db.from("bank_links").update({ last_error: msg }).eq("id", link.id);
	}
	return {
		added,
		errors
	};
}
async function pullLink(companyId, link) {
	const { data: accs } = await db.from("bank_link_accounts").select("id,remote_id,account_id,start_date").eq("link_id", link.id);
	const mapped = (accs ?? []).filter((a) => a.account_id);
	const now = Date.now();
	const floor = /* @__PURE__ */ new Date(now - 76896e5);
	const earliest = mapped.map((a) => a.start_date ? /* @__PURE__ */ new Date(`${a.start_date}T00:00:00Z`) : floor).reduce((m, d) => d < m ? d : m, new Date(now));
	const from = earliest < floor ? floor : earliest;
	const set = await fetchAccounts(link.access_url, mapped.length ? from : void 0, !mapped.length);
	await saveAccounts(companyId, link.id, set);
	let added = 0;
	for (const a of mapped) {
		const remote = (set.accounts ?? []).find((x) => x.id === a.remote_id);
		if (!remote) continue;
		const start = a.start_date ?? day(from);
		const rows = (remote.transactions ?? []).filter((t) => !t.pending && t.posted > 0).map((t) => {
			const desc = [t.payee, t.description].filter(Boolean);
			return {
				company_id: companyId,
				account_id: a.account_id,
				txn_date: day(/* @__PURE__ */ new Date(t.posted * 1e3)),
				amount: Math.round(Number(t.amount) * 100) / 100,
				description: (desc[0] === desc[1] ? desc[0] : desc.join(" · ")) || "Bank line",
				ref: t.memo || null,
				fit_id: `sf:${t.id}`,
				status: "new"
			};
		}).filter((r) => r.txn_date >= start && Number.isFinite(r.amount));
		if (!rows.length) continue;
		const { data, error } = await db.from("bank_transactions").upsert(rows, {
			onConflict: "account_id,fit_id",
			ignoreDuplicates: true
		}).select("id");
		if (error) throw new Error(error.message);
		added += (data ?? []).length;
	}
	await db.from("bank_links").update({
		last_pulled_at: (/* @__PURE__ */ new Date()).toISOString(),
		last_error: problems(set)
	}).eq("id", link.id);
	return added;
}
/** The daily job: every company with a connection. */
async function pullAll() {
	const { data } = await db.from("bank_links").select("company_id");
	const companies = [...new Set((data ?? []).map((r) => r.company_id))];
	let added = 0;
	let failed = 0;
	for (const c of companies) {
		const r = await pullCompany(c).catch(() => ({
			added: 0,
			errors: ["failed"]
		}));
		added += r.added;
		failed += r.errors.length;
	}
	return {
		companies: companies.length,
		added,
		failed
	};
}
/** What the Banking page shows (never the private address). */
async function listLinks(companyId) {
	const [{ data: links }, { data: accs }] = await Promise.all([db.from("bank_links").select("id,name,created_at,last_pulled_at,last_error").eq("company_id", companyId).order("created_at"), db.from("bank_link_accounts").select("id,link_id,name,bank_name,balance,balance_date,account_id,start_date").eq("company_id", companyId).order("bank_name").order("name")]);
	return (links ?? []).map((l) => ({
		...l,
		accounts: (accs ?? []).filter((a) => a.link_id === l.id).map(({ link_id: _, ...a }) => ({
			...a,
			balance: a.balance == null ? null : Number(a.balance)
		}))
	}));
}
/** Send one shared account's lines to a Tallkeep account (or nowhere). */
async function setLinkAccount(companyId, id, accountId, startDate) {
	if (accountId) {
		const { data: acc } = await db.from("accounts").select("id").eq("id", accountId).eq("company_id", companyId).maybeSingle();
		if (!acc) throw new Error("That account isn't in this company.");
	}
	const { error } = await db.from("bank_link_accounts").update({
		account_id: accountId,
		start_date: accountId ? startDate : null
	}).eq("id", id).eq("company_id", companyId);
	if (error) throw new Error(error.message);
}
async function removeLink(companyId, id) {
	const { error } = await db.from("bank_links").delete().eq("id", id).eq("company_id", companyId);
	if (error) throw new Error(error.message);
}
//#endregion
export { connectSimplefin, listLinks, pullAll, pullCompany, removeLink, setLinkAccount };
