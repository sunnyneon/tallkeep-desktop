import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as kindLabel, f as useAccounts, n as TYPE_LABEL, o as balanceOf, p as useTotals, r as TYPE_ORDER, t as KINDS } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { B as Plus, W as Pencil } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-CojDUW5Y.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/accounts-NdQKeXkS.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function ChartOfAccounts() {
	const { data: accounts, isLoading } = useAccounts();
	const { data: totals } = useTotals(null, null);
	const [q, setQ] = (0, import_react.useState)("");
	const [showInactive, setShowInactive] = (0, import_react.useState)(false);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => smartSearch((accounts ?? []).filter((a) => showInactive || a.is_active), q, (a) => `${a.number ?? ""} ${a.name}`, (a) => kindLabel(a.kind)), [
		accounts,
		q,
		showInactive
	]);
	const qc = useQueryClient();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const hiddenUnused = (accounts ?? []).filter((a) => !a.is_active && !totals?.get(a.id));
	const unhideAll = async () => {
		setBusy(true);
		const { error } = await db.from("accounts").update({ is_active: true }).in("id", hiddenUnused.map((a) => a.id));
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success(`${hiddenUnused.length} accounts are active again.`);
		qc.invalidateQueries();
	};
	const bal = (a) => {
		const t = totals?.get(a.id);
		return t ? balanceOf(a.type, t.debit, t.credit) : 0;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Chart of Accounts",
			text: "Every account your money moves through, with today's balance. Click an account to see its transactions.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setEdit({
					name: "",
					kind: "expense",
					is_active: true
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New account"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-sm",
					placeholder: "Search accounts",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: showInactive,
						onChange: (e) => setShowInactive(e.target.checked)
					}), "Show inactive"]
				}),
				showInactive && hiddenUnused.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					disabled: busy,
					onClick: () => void unhideAll(),
					children: [
						"Make the ",
						hiddenUnused.length,
						" unused inactive accounts active again"
					]
				})
			]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		accounts && accounts.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-2xl border bg-card p-6 text-sm text-muted-foreground",
			children: "No accounts yet. Set the books start date in Settings → Accounting to add a ready-made chart of accounts."
		}),
		TYPE_ORDER.map((t) => {
			const list = rows.filter((a) => a.type === t);
			if (!list.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-hidden rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b bg-muted/40 px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: TYPE_LABEL[t]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: fmtMoney(list.reduce((s, a) => s + bal(a), 0))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y",
					children: list.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-14 shrink-0 text-muted-foreground",
								children: a.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/accounts/$id",
								params: { id: a.id },
								className: `min-w-0 flex-1 truncate font-medium hover:underline ${a.is_active ? "" : "text-muted-foreground line-through"}`,
								children: a.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden w-48 truncate text-xs text-muted-foreground sm:block",
								children: kindLabel(a.kind)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-28 text-right tabular-nums",
								children: fmtMoney(bal(a))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								className: "h-7 w-7",
								"aria-label": `Edit ${a.name}`,
								onClick: () => setEdit(a),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3.5 w-3.5" })
							})
						]
					}, a.id))
				})]
			}, t);
		}),
		edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountDialog, {
			draft: edit,
			onClose: () => setEdit(null)
		})
	] });
}
/** Two accounts for the same thing: move everything from this one into the other. */
function MergeInto({ from, onDone }) {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [into, setInto] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const type = KINDS.find((k) => k.kind === from.kind)?.type;
	const choices = (accounts ?? []).filter((a) => a.id !== from.id && a.is_active && KINDS.find((k) => k.kind === a.kind)?.type === type);
	async function merge() {
		const to = choices.find((a) => a.id === into);
		if (!to) return void toast.error("Choose the account to keep.");
		if (!window.confirm(`Move everything in ${from.name} into ${to.name}, then remove ${from.name}? This can't be undone (make a backup first if you're unsure).`)) return;
		setBusy(true);
		const { data, error } = await db.rpc("merge_accounts", {
			_from: from.id,
			_into: to.id
		});
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(String(data ?? "Merged."));
		qc.invalidateQueries();
		onDone();
	}
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "text-sm text-[var(--section)] underline-offset-2 hover:underline",
		onClick: () => setOpen(true),
		children: "Two accounts for the same thing? Merge this one into another"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 rounded-xl border p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					"Everything in ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: from.name }),
					" (its entries, bank lines, reconciliations, loan details) moves into the account you keep. Then ",
					from.name,
					" is removed."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: into,
				onValueChange: setInto,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Keep this account…" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: choices.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: a.id,
					children: [a.number ? `${a.number} · ` : "", a.name]
				}, a.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				disabled: busy || !into,
				onClick: () => void merge(),
				children: busy ? "Merging…" : `Merge ${from.name} into it`
			})
		]
	});
}
function AccountDialog({ draft, onClose }) {
	const qc = useQueryClient();
	const [f, setF] = (0, import_react.useState)(draft);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const isNew = !draft.id;
	const used = !!draft.key;
	async function save(e) {
		e.preventDefault();
		if (!f.name.trim()) return void toast.error("Type the account name.");
		const type = KINDS.find((k) => k.kind === f.kind).type;
		setBusy(true);
		const row = {
			number: f.number?.trim() || null,
			name: f.name.trim(),
			kind: f.kind,
			type,
			description: f.description?.trim() || null,
			is_active: f.is_active ?? true
		};
		const { error } = isNew ? await db.from("accounts").insert(row) : await db.from("accounts").update(row).eq("id", draft.id);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success(isNew ? "Account added." : "Account saved.");
		qc.invalidateQueries({ queryKey: ["accounts"] });
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: save,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: isNew ? "New account" : `Edit ${draft.name}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: used ? "The app posts to this account automatically, so its kind stays as it is." : "Pick what kind of account it is; that decides where it shows in your reports." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-[6rem_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.number ?? "",
							onChange: (e) => setF({
								...f,
								number: e.target.value
							})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.name,
							onChange: (e) => setF({
								...f,
								name: e.target.value
							})
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Kind",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: f.kind,
						onValueChange: (v) => setF({
							...f,
							kind: v
						}),
						disabled: used,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: KINDS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: k.kind,
							children: [
								TYPE_LABEL[k.type],
								" · ",
								k.label
							]
						}, k.kind)) })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: f.description ?? "",
						onChange: (e) => setF({
							...f,
							description: e.target.value
						})
					})
				}),
				!isNew && !used && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: f.is_active ?? true,
						onChange: (e) => setF({
							...f,
							is_active: e.target.checked
						})
					}), "Active (untick to hide it from lists; its history stays)"]
				}),
				!isNew && !used && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MergeInto, {
					from: draft,
					onDone: onClose
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					children: busy ? "Saving…" : isNew ? "Add account" : "Save account"
				})] })
			]
		}) })
	});
}
//#endregion
export { ChartOfAccounts as component };
