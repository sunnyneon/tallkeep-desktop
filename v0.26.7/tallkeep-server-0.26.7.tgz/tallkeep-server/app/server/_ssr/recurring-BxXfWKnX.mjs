import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-tdRottJR.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { B as Plus, F as Repeat, K as Pause, V as Play, _ as Trash2 } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-CojDUW5Y.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-Yp0ZfJ76.mjs";
import { s as useAddVendor } from "./quickadd-CPmfd8Bg.mjs";
import { s as useRealEstate } from "./realestate-B7MhUll3.mjs";
import { i as payFromAccounts, t as METHOD_LABEL } from "./money-BnCYGdUa.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
import { t as Route } from "./recurring-Dcpsvm9W.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/recurring-BxXfWKnX.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
var EVERY = {
	week: "Every week",
	month: "Every month",
	quarter: "Every 3 months",
	year: "Every year"
};
var sum = (l) => l.reduce((s, x) => s + (Number(x.amount) || 0), 0);
function RecurringPage() {
	const search = Route.useSearch();
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data, isLoading } = useQuery({
		queryKey: ["recurring"],
		queryFn: async () => {
			return (await fetchAll("recurring")).filter((r) => r.kind !== "invoice").sort((a, b) => Number(b.active) - Number(a.active) || a.next_date.localeCompare(b.next_date));
		}
	});
	const [edit, setEdit] = (0, import_react.useState)(null);
	const name = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
	(0, import_react.useEffect)(() => {
		if (!search.from) return;
		(async () => {
			const [c, l] = await Promise.all([db.from("checks").select("*").eq("id", search.from).single(), db.from("check_lines").select("account_id,description,amount,property_id").eq("check_id", search.from)]);
			if (c.error) return;
			const ck = c.data;
			setEdit({
				name: ck.payee ?? "",
				kind: "check",
				account_id: ck.account_id,
				method: ck.method === "check" ? "ach" : ck.method,
				vendor_id: ck.vendor_id,
				payee: ck.payee,
				memo: ck.memo,
				lines: (l.data ?? []).map((x) => ({
					...x,
					amount: Number(x.amount)
				})),
				every: "month",
				next_date: today(),
				auto: true,
				active: true
			});
		})();
	}, [search.from]);
	async function makeNow(r) {
		if (!window.confirm(`Make "${r.name}" for ${fmtDate(r.next_date)} now?`)) return;
		const { error } = await db.rpc("make_recurring_now", { _id: r.id });
		if (error) return void toast.error(error.message);
		toast.success(r.kind === "check" ? "Payment made." : "Bill made.");
		qc.invalidateQueries();
	}
	async function setActive(r, active) {
		const { error } = await db.from("recurring").update({ active }).eq("id", r.id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["recurring"] });
	}
	async function remove(r) {
		if (!window.confirm(`Delete "${r.name}"? Payments already made stay.`)) return;
		const { error } = await db.from("recurring").delete().eq("id", r.id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["recurring"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Recurring",
			text: "Payments and bills that repeat, like rent, loans, insurance or autopay. Automatic ones are made by themselves early in the morning on their day.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setEdit({
					kind: "check",
					method: "ach",
					every: "month",
					next_date: today(),
					auto: true,
					active: true,
					lines: []
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New recurring"]
			})
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [data && data.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "Nothing repeats yet. Press \"New recurring\", or open a payment in Write Checks and press \"Repeat this\"."
			}), (data ?? []).map((r) => {
				const due = r.active && r.next_date <= today();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: `h-4 w-4 ${r.active ? "text-[var(--section)]" : "text-muted-foreground"}` }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "min-w-0 flex-1 text-left",
							onClick: () => setEdit(r),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium hover:underline",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									r.kind === "check" ? `${METHOD_LABEL[r.method]} from ${name.get(r.account_id ?? "") ?? "?"}` : "Bill to pay later",
									" ",
									"· ",
									EVERY[r.every],
									" · ",
									r.auto ? "automatic" : "I make it myself"
								]
							})]
						}),
						!r.active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: "Paused"
						}),
						due && !r.auto && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Due" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "w-28 text-right text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted-foreground",
								children: "Next"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: due ? "font-semibold text-destructive" : "",
								children: fmtDate(r.next_date)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "w-24 text-right font-semibold",
							children: fmtMoney(sum(r.lines))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => void makeNow(r),
									disabled: !r.active,
									children: "Make it now"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									"aria-label": r.active ? "Pause" : "Start again",
									title: r.active ? "Pause" : "Start again",
									onClick: () => void setActive(r, !r.active),
									children: r.active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									"aria-label": "Delete",
									onClick: () => void remove(r),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							]
						})
					]
				}, r.id);
			})]
		}),
		edit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecDialog, {
			draft: edit,
			onClose: () => setEdit(null)
		})
	] });
}
function RecDialog({ draft, onClose }) {
	const addVendorNow = useAddVendor();
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: features } = useFeatures();
	const realEstate = !!features?.includes("real_estate");
	const { data: re } = useRealEstate(realEstate);
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "names"],
		queryFn: () => fetchAll("vendors", "id,name,is_active")
	});
	const [d, setD] = (0, import_react.useState)(draft);
	const [lines, setLines] = (0, import_react.useState)(draft.lines?.length ? draft.lines : [{
		account_id: "",
		description: "",
		amount: 0,
		property_id: null
	}]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	const pay = payFromAccounts(accounts);
	(0, import_react.useEffect)(() => {
		if (d.kind === "check" && !d.account_id && pay[0]) set({ account_id: (pay.find((a) => a.kind === "bank") ?? pay[0]).id });
	}, [
		d.kind,
		d.account_id,
		pay
	]);
	const lineAccounts = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && !["ar", "ap"].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	})), [accounts]);
	const props = (re?.properties ?? []).filter((p) => p.is_active).map((p) => ({
		value: p.id,
		label: p.name
	}));
	async function save() {
		const used = lines.filter((l) => Number(l.amount));
		if (!d.name?.trim()) return void toast.error("Give it a name, like 'Insurance'.");
		if (!d.payee?.trim() && !d.vendor_id) return void toast.error("Who is it paid to?");
		if (d.kind === "check" && !d.account_id) return void toast.error("Choose which account pays it.");
		if (!used.length) return void toast.error("Add at least one line with an amount.");
		if (used.some((l) => !l.account_id)) return void toast.error("Choose an account for every line.");
		if (!d.next_date) return void toast.error("When is the next one?");
		setBusy(true);
		const row = {
			name: d.name.trim(),
			kind: d.kind ?? "check",
			account_id: d.kind === "check" ? d.account_id : null,
			method: d.method ?? "ach",
			vendor_id: d.vendor_id ?? null,
			payee: d.payee?.trim() || null,
			memo: d.memo?.trim() || null,
			lines: used.map((l) => ({
				...l,
				amount: Math.round(Number(l.amount) * 100) / 100,
				property_id: l.property_id || null
			})),
			every: d.every ?? "month",
			next_date: d.next_date,
			end_date: d.end_date || null,
			auto: d.auto ?? true,
			active: d.active ?? true
		};
		const { error } = d.id ? await db.from("recurring").update(row).eq("id", d.id) : await db.from("recurring").insert(row);
		setBusy(false);
		if (error) return void toast.error(error.message);
		toast.success("Saved.");
		qc.invalidateQueries({ queryKey: ["recurring"] });
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: d.id ? "Recurring" : "New recurring" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "A payment that leaves the bank by itself (autopay), or a bill to pay later, made on the same day every week, month, 3 months or year." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.name ?? "",
								onChange: (e) => set({ name: e.target.value }),
								placeholder: "Insurance"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "What it makes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: d.kind,
								onChange: (e) => set({ kind: e.target.value }),
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "check",
									children: "A payment (autopay, online, card, check)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bill",
									children: "A bill to pay later"
								})]
							})
						}),
						d.kind === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Paid from",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: d.account_id ?? "",
								options: pay.map((a) => ({
									value: a.id,
									label: accountLabel(a)
								})),
								onChange: (v) => set({ account_id: v })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "How",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: d.method,
								onChange: (e) => set({ method: e.target.value }),
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								children: Object.entries(METHOD_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pay to (vendor)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: d.vendor_id ?? "",
								options: (vendors ?? []).filter((v) => v.is_active).map((v) => ({
									value: v.id,
									label: v.name
								})),
								placeholder: d.payee || "Choose a vendor",
								onAdd: addVendorNow,
								addLabel: "Add new vendor",
								onChange: (v) => set({
									vendor_id: v,
									payee: vendors?.find((x) => x.id === v)?.name ?? d.payee ?? null
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "…or type a name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.vendor_id ? "" : d.payee ?? "",
								onChange: (e) => set({
									vendor_id: null,
									payee: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "How often",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: d.every,
								onChange: (e) => set({ every: e.target.value }),
								className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
								children: Object.entries(EVERY).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: k,
									children: v
								}, k))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Next one on",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.next_date ?? "",
								onChange: (e) => set({ next_date: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Last one on (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.end_date ?? "",
								onChange: (e) => set({ end_date: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Memo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: d.memo ?? "",
								onChange: (e) => set({ memo: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-2 text-sm sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1",
								checked: d.auto ?? true,
								onChange: (e) => set({ auto: e.target.checked })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Make it automatically on its day", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: "Untick to make it yourself with \"Make it now\" (for amounts that change)."
							})] })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "What it pays for"
						}),
						lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-[minmax(0,2fr)_minmax(0,2fr)_7rem_2rem]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: l.account_id,
									options: lineAccounts,
									placeholder: "Account",
									onChange: (v) => setLines(lines.map((x, j) => j === i ? {
										...x,
										account_id: v
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Description",
									value: l.description,
									onChange: (e) => setLines(lines.map((x, j) => j === i ? {
										...x,
										description: e.target.value
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									className: "text-right",
									value: l.amount || "",
									onChange: (e) => setLines(lines.map((x, j) => j === i ? {
										...x,
										amount: Number(e.target.value)
									} : x))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Remove line",
									onClick: () => setLines(lines.filter((_, j) => j !== i)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								}),
								realEstate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
										value: l.property_id ?? "",
										options: props,
										placeholder: "For which property? (optional)",
										onChange: (v) => setLines(lines.map((x, j) => j === i ? {
											...x,
											property_id: v
										} : x))
									})
								})
							]
						}, i)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setLines([...lines, {
									account_id: "",
									description: "",
									amount: 0,
									property_id: null
								}]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: fmtMoney(sum(lines))
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Saving…" : "Save"
				})] })
			]
		})
	});
}
//#endregion
export { RecurringPage as component };
