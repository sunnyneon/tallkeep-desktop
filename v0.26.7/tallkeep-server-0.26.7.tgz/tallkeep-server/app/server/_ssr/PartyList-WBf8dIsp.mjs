import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { B as Plus, k as Search } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { t as Switch } from "./switch-Dkd0-FGF.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as useSticky } from "./sticky-B3ohlEWn.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PartyList-WBf8dIsp.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
function PartyList({ kind }) {
	const isCust = kind === "customers";
	const word = isCust ? "customer" : "vendor";
	const { data, isLoading } = useQuery({
		queryKey: [kind],
		queryFn: () => fetchAll(kind, "id,name,contact_name,phone,email,website,address,is_active")
	});
	const [q, setQ] = useSticky(`party-search:${kind}`, "");
	const [inactive, setInactive] = (0, import_react.useState)(false);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const navigate = useNavigate();
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		return (data ?? []).filter((r) => inactive || r.is_active).filter((r) => {
			const hay = `${r.name} ${r.contact_name ?? ""} ${r.phone ?? ""} ${r.email ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		}).sort((a, b) => a.name.localeCompare(b.name));
	}, [
		data,
		q,
		inactive
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: isCust ? "Customers" : "Vendors",
				text: data ? `${rows.length} of ${data.length}` : isCust ? "People and companies you sell to." : "Companies you buy from.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setAdding(true),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }),
						" Add ",
						word
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-9",
						placeholder: "Search name, contact, phone or email",
						value: q,
						onChange: (e) => setQ(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: inactive,
						onCheckedChange: setInactive
					}), " Show inactive"]
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y overflow-hidden rounded-2xl border bg-card md:hidden",
				children: rows.slice(0, 300).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: isCust ? "/customers/$id" : "/vendors/$id",
					params: { id: r.id },
					className: "flex items-center gap-3 px-4 py-3 hover:bg-muted/50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium",
							children: r.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: [
								r.contact_name,
								r.phone,
								r.email
							].filter(Boolean).join(" · ") || "\xA0"
						})]
					}), !r.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: "Inactive"
					})]
				}, r.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden overflow-x-auto rounded-2xl border bg-card md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Contact"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Phone"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Address"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-semibold",
								children: "Website"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: rows.slice(0, 500).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "cursor-pointer hover:bg-muted/50",
							onClick: () => navigate({
								to: isCust ? "/customers/$id" : "/vendors/$id",
								params: { id: r.id }
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "max-w-[260px] truncate px-3 py-2 font-medium text-primary",
									children: [
										r.name,
										" ",
										!r.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											variant: "outline",
											children: "Inactive"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[180px] truncate px-3 py-2",
									children: r.contact_name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "whitespace-nowrap px-3 py-2",
									children: r.phone
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[220px] truncate px-3 py-2",
									children: r.email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[320px] truncate px-3 py-2",
									children: (r.address ?? "").replace(/\n/g, ", ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[180px] truncate px-3 py-2",
									children: r.website
								})
							]
						}, r.id))
					})]
				})
			}),
			rows.length > 500 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: "Showing the first 500. Search to narrow it down."
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddParty, {
				kind,
				onClose: () => setAdding(false)
			})
		]
	});
}
function AddParty({ kind, onClose }) {
	const qc = useQueryClient();
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const word = kind === "customers" ? "customer" : "vendor";
	async function save(e) {
		e.preventDefault();
		if (!name.trim()) return;
		setBusy(true);
		const { data, error } = await db.from(kind).insert({ name: name.trim() }).select("id").single();
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		qc.invalidateQueries({ queryKey: [kind] });
		onClose();
		navigate({
			to: kind === "customers" ? "/customers/$id" : "/vendors/$id",
			params: { id: data.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: save,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Add ", word] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						autoFocus: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					disabled: busy || !name.trim(),
					children: ["Add ", word]
				})] })
			]
		}) })
	});
}
//#endregion
export { PartyList as t };
