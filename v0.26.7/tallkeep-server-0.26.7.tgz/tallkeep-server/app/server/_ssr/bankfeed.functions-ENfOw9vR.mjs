import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bankfeed.functions-ENfOw9vR.js
async function company(userId, sb, write) {
	const { requireZone, activeCompany } = await import("./zone.server-JWxH1ixr.mjs");
	await requireZone(userId, ["Accounting"], "bank connections", sb);
	return activeCompany(sb, write);
}
var listBankLinks_createServerFn_handler = createServerRpc({
	id: "52743db9114c316defd0de80423075d8f3ce16d64637a0cab7bda678b037e7ee",
	name: "listBankLinks",
	filename: "src/lib/bankfeed.functions.ts"
}, (opts) => listBankLinks.__executeServer(opts));
var listBankLinks = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listBankLinks_createServerFn_handler, async ({ context }) => {
	const c = await company(context.userId, context.supabase, false);
	const { listLinks } = await import("./bankfeed.server-Blw8UdqC.mjs");
	return listLinks(c);
});
var connectBank_createServerFn_handler = createServerRpc({
	id: "d4666967c9fdc9d7c8c16b3f6ce6b24652dd0a13c9bb7f80369329f45e85ac53",
	name: "connectBank",
	filename: "src/lib/bankfeed.functions.ts"
}, (opts) => connectBank.__executeServer(opts));
var connectBank = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const code = String(d?.code ?? "").trim();
	if (!code) throw new Error("Paste the setup code from SimpleFIN.");
	if (code.length > 2e3) throw new Error("That code is too long. Copy just the setup code.");
	return { code };
}).handler(connectBank_createServerFn_handler, async ({ data, context }) => {
	const c = await company(context.userId, context.supabase, true);
	const { connectSimplefin } = await import("./bankfeed.server-Blw8UdqC.mjs");
	return connectSimplefin(c, context.userId, data.code);
});
var setBankLinkAccount_createServerFn_handler = createServerRpc({
	id: "d45861089fecb1b6200c8e8e07147efcd9537a6f08a01f71fd821a171136d514",
	name: "setBankLinkAccount",
	filename: "src/lib/bankfeed.functions.ts"
}, (opts) => setBankLinkAccount.__executeServer(opts));
var setBankLinkAccount = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which account?");
	if (d.startDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.startDate)) throw new Error("Pick a start date.");
	return {
		id: d.id,
		accountId: d.accountId || null,
		startDate: d.startDate || null
	};
}).handler(setBankLinkAccount_createServerFn_handler, async ({ data, context }) => {
	const c = await company(context.userId, context.supabase, true);
	const { setLinkAccount } = await import("./bankfeed.server-Blw8UdqC.mjs");
	await setLinkAccount(c, data.id, data.accountId, data.startDate);
	return { ok: true };
});
var pullBankNow_createServerFn_handler = createServerRpc({
	id: "1ddc9bf46ce82113f0b8564806dc316e90df9282ae9ed81c6724e024d1d0757a",
	name: "pullBankNow",
	filename: "src/lib/bankfeed.functions.ts"
}, (opts) => pullBankNow.__executeServer(opts));
var pullBankNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(pullBankNow_createServerFn_handler, async ({ context }) => {
	const c = await company(context.userId, context.supabase, true);
	const { pullCompany } = await import("./bankfeed.server-Blw8UdqC.mjs");
	return pullCompany(c);
});
var removeBankLink_createServerFn_handler = createServerRpc({
	id: "d9c39b8ea424292e98f3177e30e500e9266a64f5d23e5d8ca85b07aafc9b746d",
	name: "removeBankLink",
	filename: "src/lib/bankfeed.functions.ts"
}, (opts) => removeBankLink.__executeServer(opts));
var removeBankLink = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!d?.id) throw new Error("Which connection?");
	return { id: d.id };
}).handler(removeBankLink_createServerFn_handler, async ({ data, context }) => {
	const c = await company(context.userId, context.supabase, true);
	const { removeLink } = await import("./bankfeed.server-Blw8UdqC.mjs");
	await removeLink(c, data.id);
	return { ok: true };
});
//#endregion
export { connectBank_createServerFn_handler, listBankLinks_createServerFn_handler, pullBankNow_createServerFn_handler, removeBankLink_createServerFn_handler, setBankLinkAccount_createServerFn_handler };
