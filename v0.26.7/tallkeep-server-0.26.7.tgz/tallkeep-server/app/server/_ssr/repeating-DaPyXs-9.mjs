import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { F as Repeat } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { t as Badge } from "./badge-BBXU3UFX.mjs";
import { a as RepeatDialog, t as EVERY_LABEL } from "./RepeatInvoice-DsbstCNc.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/repeating-DaPyXs-9.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Every invoice that repeats (monthly billing and the like). */
function RepeatingPage() {
	const { data, isLoading } = useQuery({
		queryKey: ["repeating"],
		queryFn: async () => {
			const { data, error } = await db.from("recurring").select("*").eq("kind", "invoice").order("next_date");
			if (error) return {
				rows: [],
				src: /* @__PURE__ */ new Map(),
				counts: {}
			};
			const rows = data ?? [];
			const ids = rows.map((r) => r.sales_order_id).filter(Boolean);
			const { data: s } = ids.length ? await db.from("sales_orders").select("id,number,customer_name,total,invoice_date,order_date").in("id", ids) : { data: [] };
			const { data: made } = rows.length ? await db.from("sales_orders").select("recurring_id").in("recurring_id", rows.map((r) => r.id)) : { data: [] };
			const counts = {};
			for (const m of made ?? []) counts[m.recurring_id] = (counts[m.recurring_id] ?? 0) + 1;
			return {
				rows: rows.sort((a, b) => Number(b.active) - Number(a.active) || a.next_date.localeCompare(b.next_date)),
				src: new Map((s ?? []).map((x) => [x.id, x])),
				counts
			};
		}
	});
	const [open, setOpen] = (0, import_react.useState)(null);
	const qc = useQueryClient();
	async function remove(r) {
		if (!window.confirm("Remove this repeating invoice? The invoices it already made stay.")) return;
		const { error } = await db.from("recurring").delete().eq("id", r.id);
		if (error) return void toast.error(error.message);
		qc.invalidateQueries({ queryKey: ["repeating"] });
	}
	const rows = data?.rows ?? [];
	const monthly = rows.filter((r) => r.active).reduce((sum, r) => {
		return sum + Number(data?.src.get(r.sales_order_id ?? "")?.total ?? 0) * (r.every === "week" ? 52 / 12 : r.every === "quarter" ? 1 / 3 : r.every === "year" ? 1 / 12 : 1);
	}, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Repeating invoices",
			text: "Invoices made by themselves on their day: monthly billing, retainers, service plans. To start one, open an invoice and press Repeat this invoice."
		}),
		isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" }) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border bg-card p-8 text-center text-sm text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "mx-auto mb-2 h-6 w-6" }),
				"Nothing repeats yet. Open an invoice and press ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Repeat this invoice" }),
				".",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/sales-list",
							children: "Open the Sales List"
						})
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				rows.filter((r) => r.active).length,
				" repeating · about",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					className: "text-foreground",
					children: fmtMoney(monthly)
				}),
				" a month"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-xl border bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Customer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Copies"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "How often"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Next"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2",
							children: "Last one ends"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-right",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-right",
							children: "Made"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y",
					children: rows.map((r) => {
						const s = data?.src.get(r.sales_order_id ?? "");
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: r.active ? "" : "text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-medium",
									children: s?.customer_name ?? r.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/sales/$id",
										params: { id: s.id },
										search: {},
										className: "text-primary underline-offset-2 hover:underline",
										children: s.number
									}) : "deleted"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-2",
									children: [EVERY_LABEL[r.every], r.as_draft && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1 text-xs text-muted-foreground",
										children: "(as drafts)"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.active ? fmtDate(r.next_date) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										title: r.last_error ?? void 0,
										children: r.last_error ? "Stopped: see why" : "Paused"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: r.end_date ? fmtDate(r.end_date) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: s ? fmtMoney(s.total) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: data?.counts[r.id] ?? 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setOpen(r),
										children: "Change"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => void remove(r),
										children: "Remove"
									})
								})
							]
						}, r.id);
					})
				})]
			})
		})] }),
		open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RepeatDialog, {
			orderId: open.sales_order_id,
			number: data?.src.get(open.sales_order_id ?? "")?.number ?? "",
			customer: data?.src.get(open.sales_order_id ?? "")?.customer_name ?? "",
			invoiceDate: null,
			rep: open,
			onClose: () => setOpen(null)
		})
	] });
}
//#endregion
export { RepeatingPage as component };
