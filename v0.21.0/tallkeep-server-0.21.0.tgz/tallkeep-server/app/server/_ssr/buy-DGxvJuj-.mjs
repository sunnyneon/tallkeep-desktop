import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { lt as LoaderCircle, sn as Check, st as Lock } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as addonFits, i as EDITION_KEYS, n as ADDON_KEYS } from "./editions-CIhnK_Ff.mjs";
import { getBuyInfo, lookUpLicense, quoteUpgrade, startCheckout, startUpgrade } from "./buy.functions-C86KSL9F.mjs";
import { n as checkTesterCode } from "./testers.functions-57kpkj-S.mjs";
import { n as Route } from "./buy-Cb_5NYbY.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/buy-DGxvJuj-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Buy Tallkeep: pick a plan and add-ons, or upgrade a license. Pay with Stripe; the key comes by email. */
var usd = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD",
	maximumFractionDigits: 0
});
function BuyFrame({ children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-muted/30 px-4 py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("mx-auto space-y-6", wide ? "max-w-3xl" : "max-w-xl"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "https://tallkeep.com",
				className: "inline-block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-light.svg",
					alt: "Tallkeep",
					className: "h-9 dark:hidden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/tallkeep-menu-dark.svg",
					alt: "Tallkeep",
					className: "hidden h-9 dark:block"
				})]
			}), children]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: label
		}), children]
	});
}
function BuyPage() {
	const search = Route.useSearch();
	const [tab, setTab] = (0, import_react.useState)(search.upgrade ? "upgrade" : "new");
	const { data: info, isLoading } = useQuery({
		queryKey: ["buy-info"],
		queryFn: () => getBuyInfo()
	});
	if (isLoading || !info) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, {
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96 rounded-2xl" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuyFrame, {
		wide: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5 rounded-2xl border bg-card p-6 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-semibold",
					children: "Buy Tallkeep"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Pay once and own it. Runs on your computer or server, with phone access. Your license key arrives by email right after you pay."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: [["new", "Buy a new license"], ["upgrade", "Upgrade my license"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(k),
						className: cn("rounded-full border px-4 py-1.5 text-sm font-medium", tab === k ? "border-primary bg-primary text-primary-foreground" : "bg-card"),
						children: label
					}, k))
				}),
				!info.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-xl border bg-muted/40 p-3 text-sm",
					children: [
						"Buying online opens soon. Email",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "underline",
							href: "mailto:hello@tallkeep.com",
							children: "hello@tallkeep.com"
						}),
						" ",
						"and we'll set you up."
					]
				}) : tab === "new" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewLicense, {
					info,
					search
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upgrade, { info })
			]
		})
	});
}
function PlanPicker({ info, plan, setPlan, priceOf, min }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
		children: EDITION_KEYS.map((k) => {
			const e = info.catalog.editions[k];
			const below = !!min && EDITION_KEYS.indexOf(k) < EDITION_KEYS.indexOf(min);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: below,
				onClick: () => setPlan(k),
				className: cn("rounded-xl border p-3 text-left text-sm transition-colors disabled:opacity-40", plan === k ? "border-[#F28C38] bg-[#F28C38]/10 ring-1 ring-[#F28C38]" : "hover:bg-muted"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-semibold",
						children: e.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-xl font-bold text-[#C2410C]",
						children: [priceOf(e) < e.price && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("s", {
							className: "mr-1.5 text-sm font-normal text-muted-foreground",
							children: usd(e.price)
						}), usd(priceOf(e))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-xs text-muted-foreground",
						children: e.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs",
						children: [
							e.companies === 1 ? "1 company" : `${e.companies} companies`,
							" · ",
							e.users,
							" people"
						]
					})
				]
			}, k);
		})
	});
}
function AddonPicker({ info, plan, picked, setPicked, priceOf, owned = [] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: "Add-ons"
		}), ADDON_KEYS.filter((k) => owned.includes(k) || addonFits(k, plan)).map((k) => {
			const a = info.catalog.addons[k];
			const has = owned.includes(k);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: cn("flex items-start gap-3 rounded-xl border p-3 text-sm", has && "opacity-60"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						className: "mt-0.5 h-4 w-4",
						disabled: has,
						checked: has || picked.includes(k),
						onChange: (e) => setPicked(e.target.checked ? [...picked, k] : picked.filter((x) => x !== k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium",
								children: a.label
							}),
							has && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-xs text-emerald-700",
								children: "You have this"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: a.text
							})
						]
					}),
					!has && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "whitespace-nowrap font-semibold",
						children: [priceOf(a) < a.price && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("s", {
							className: "mr-1 font-normal text-muted-foreground",
							children: usd(a.price)
						}), usd(priceOf(a))]
					})
				]
			}, k);
		})]
	});
}
function NewLicense({ info, search }) {
	const reLink = search.addon === "real_estate" && !search.plan;
	const [plan, setPlan] = (0, import_react.useState)(reLink ? "real_estate" : search.plan ?? "full");
	const [picked, setAddons] = (0, import_react.useState)(search.addon && !reLink ? [search.addon] : []);
	const addons = picked.filter((a) => addonFits(a, plan));
	const [f, setF] = (0, import_react.useState)({
		to: "",
		email: "",
		extraCompanies: "",
		extraUsers: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)((search.code ?? "").toUpperCase());
	const codeNow = code.trim().toUpperCase();
	const { data: tester } = useQuery({
		queryKey: ["tester-code", codeNow],
		enabled: /^TEST-[A-Z0-9]{6}$/.test(codeNow),
		queryFn: () => checkTesterCode({ data: { code: codeNow } })
	});
	const off = tester?.ok ? 1 - tester.pct / 100 : 1;
	const priceOf = (x) => tester?.ok ? Math.floor(x.price * off) : info.founders ? x.founders : x.price;
	const e = info.catalog.editions[plan];
	const xc = Math.max(0, Math.floor(Number(f.extraCompanies) || 0));
	const xu = Math.max(0, Math.floor(Number(f.extraUsers) || 0));
	const extraCompany = Math.floor(info.extraCompany * off);
	const extraUser = Math.floor(info.extraUser * off);
	const total = priceOf(e) + addons.reduce((s, a) => s + priceOf(info.catalog.addons[a]), 0) + xc * extraCompany + xu * extraUser;
	async function submit(ev) {
		ev.preventDefault();
		setBusy(true);
		try {
			const r = await startCheckout({ data: {
				to: f.to,
				email: f.email,
				edition: plan,
				addons,
				extraCompanies: xc,
				extraUsers: xu,
				origin: window.location.origin,
				...tester?.ok ? { code: codeNow } : {}
			} });
			window.location.href = r.url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanPicker, {
				info,
				plan,
				setPlan,
				priceOf
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddonPicker, {
				info,
				plan,
				picked: addons,
				setPicked: setAddons,
				priceOf
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: plan === "personal" ? "Your name (shows on the license)" : "Business name (shows on the license)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: f.to,
							onChange: (x) => setF({
								...f,
								to: x.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Your email (the key is sent here)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							value: f.email,
							onChange: (x) => setF({
								...f,
								email: x.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Extra companies (${usd(extraCompany)} each)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							placeholder: "0",
							value: f.extraCompanies,
							onChange: (x) => setF({
								...f,
								extraCompanies: x.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Extra people (${usd(extraUser)} each)`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							placeholder: "0",
							value: f.extraUsers,
							onChange: (x) => setF({
								...f,
								extraUsers: x.target.value
							})
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "Early access code (optional)",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: code,
					onChange: (x) => setCode(x.target.value.toUpperCase()),
					placeholder: "TEST-XXXXXX"
				}), codeNow && /^TEST-[A-Z0-9]{6}$/.test(codeNow) && tester && !tester.ok && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-destructive",
					children: "That code isn't right, or it was already used."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 rounded-xl bg-muted/40 p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: `Tallkeep ${e.label}`,
						value: priceOf(e)
					}),
					addons.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: `${info.catalog.addons[a].label} add-on`,
						value: priceOf(info.catalog.addons[a])
					}, a)),
					xc > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: `${xc} extra ${xc === 1 ? "company" : "companies"}`,
						value: xc * extraCompany
					}),
					xu > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						label: `${xu} extra ${xu === 1 ? "person" : "people"}`,
						value: xu * extraUser
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t pt-2 text-base font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total, one time" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(total) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "pt-1 text-xs text-muted-foreground",
						children: [
							tester?.ok ? `Early access price: ${tester.pct}% off. ` : info.founders ? `Founders price until ${(/* @__PURE__ */ new Date(`${info.foundersUntil}T12:00:00`)).toLocaleDateString("en-US", {
								month: "short",
								day: "numeric",
								year: "numeric"
							})}. ` : "",
							"1 year of updates included",
							info.updatesYearly > 0 ? `; after that ${usd(info.updatesYearly)} a year, optional.` : ".",
							" ",
							"Add more later and pay only the difference."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				size: "lg",
				className: "w-full",
				disabled: busy,
				children: [
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
					"Pay ",
					usd(total),
					" with card"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: [
					"Secure payment by Stripe. By paying you agree to the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline",
						href: "https://tallkeep.com/terms",
						target: "_blank",
						rel: "noreferrer",
						children: "Terms"
					}),
					" ",
					"and",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline",
						href: "https://tallkeep.com/privacy",
						target: "_blank",
						rel: "noreferrer",
						children: "Privacy policy"
					}),
					". 30-day money-back. Questions? hello@tallkeep.com"
				]
			})
		]
	});
}
function Line({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(value) })]
	});
}
function Upgrade({ info }) {
	const [key, setKey] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [owned, setOwned] = (0, import_react.useState)(null);
	const [plan, setPlan] = (0, import_react.useState)("full");
	const [picked, setAddons] = (0, import_react.useState)([]);
	const addons = picked.filter((a) => addonFits(a, plan));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const quote = useQuery({
		queryKey: [
			"upgrade-quote",
			owned?.id,
			plan,
			addons.join()
		],
		enabled: !!owned,
		queryFn: () => quoteUpgrade({ data: {
			key,
			edition: plan,
			addons
		} })
	});
	const priceOf = (x) => info.founders ? x.founders : x.price;
	async function look() {
		setBusy(true);
		try {
			const o = await lookUpLicense({ data: { key } });
			setOwned(o);
			setPlan(o.edition ?? "full");
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function pay(ev) {
		ev.preventDefault();
		setBusy(true);
		try {
			const r = await startUpgrade({ data: {
				key,
				email,
				edition: plan,
				addons,
				origin: window.location.origin
			} });
			window.location.href = r.url;
		} catch (err) {
			toast.error(err.message);
			setBusy(false);
		}
	}
	if (!owned) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Paste your license key. It's in your license email, and in Tallkeep under Settings → Plan & computer. You keep the same license; you only pay the difference."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				"aria-label": "License key",
				rows: 3,
				className: "w-full rounded-md border bg-background p-2 font-mono text-xs",
				placeholder: "TK1.…",
				value: key,
				onChange: (e) => setKey(e.target.value.trim())
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => void look(),
				disabled: busy || !key.startsWith("TK1."),
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), " Look up my license"]
			})
		]
	});
	const now = owned.edition ? info.catalog.editions[owned.edition].label : "Everything (early license)";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: pay,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-muted/40 p-3 text-sm",
				children: [
					"License ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: owned.id }),
					" for ",
					owned.to,
					": ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: now }),
					owned.addons.length > 0 && ` + ${owned.addons.map((a) => info.catalog.addons[a].label).join(" + ")}`,
					owned.companies != null && ` · ${owned.companies} companies, ${owned.users} people`
				]
			}),
			owned.edition && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanPicker, {
				info,
				plan,
				setPlan,
				priceOf,
				min: owned.edition
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddonPicker, {
				info,
				plan,
				picked: addons,
				setPicked: setAddons,
				priceOf,
				owned: owned.edition ? owned.addons : ADDON_KEYS
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Your email (the new key is sent here)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "email",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					required: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between rounded-xl bg-muted/40 p-4 text-base font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "You pay the difference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: quote.isLoading ? "…" : usd(quote.data?.total ?? 0) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mr-1 inline h-3.5 w-3.5 text-emerald-600" }), "Tallkeep on your computer picks up the upgrade by itself within a day, or right away when you paste the new key."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				size: "lg",
				className: "w-full",
				disabled: busy || !quote.data?.total,
				children: [
					busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4" }),
					"Pay ",
					usd(quote.data?.total ?? 0),
					" with card"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: [
					"By paying you agree to the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline",
						href: "https://tallkeep.com/terms",
						target: "_blank",
						rel: "noreferrer",
						children: "Terms"
					}),
					"."
				]
			})
		]
	});
}
//#endregion
export { BuyFrame, BuyPage as component };
