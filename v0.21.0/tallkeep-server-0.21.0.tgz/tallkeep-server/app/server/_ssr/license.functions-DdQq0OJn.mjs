import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/license.functions-DdQq0OJn.js
/**
* Tallkeep Desktop license keys (owner panel only).
*
* A key is "TK1.<payload>.<signature>": the payload says who it's for and what it covers, signed
* with our private key (the LICENSE_PRIVATE_KEY secret). Tallkeep Desktop checks it with the
* matching public key (desktop/server/lib/license.mjs), with no internet needed.
*/
var makeLicenseKey_createServerFn_handler = createServerRpc({
	id: "5e3f2155d8f79d4f9c40c121fe96e1948d07bb54af205475ce054a65585c1bfd",
	name: "makeLicenseKey",
	filename: "src/lib/license.functions.ts"
}, (opts) => makeLicenseKey.__executeServer(opts));
var makeLicenseKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!String(d.to ?? "").trim()) throw new Error("Type the business name.");
	const n = (v) => v == null || v === "" ? null : Number(v);
	const companies = n(d.companies);
	const users = n(d.users);
	if (companies != null && !(Number.isInteger(companies) && companies > 0)) throw new Error("Companies: a whole number, or empty for any number.");
	if (users != null && !(Number.isInteger(users) && users > 0)) throw new Error("People: a whole number, or empty for any number.");
	if (d.updatesUntil && !/^\d{4}-\d{2}-\d{2}$/.test(d.updatesUntil)) throw new Error("Pick the date updates end.");
	const computers = n(d.computers) ?? 1;
	if (!(Number.isInteger(computers) && computers > 0)) throw new Error("Computers: at least 1.");
	return {
		...d,
		to: d.to.trim(),
		companies,
		users,
		computers
	};
}).handler(makeLicenseKey_createServerFn_handler, async ({ data, context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const admin = await requireOwner(context.userId);
	const { createLicense } = await import("./license.server-Bu3IQdFy.mjs");
	return createLicense(admin, {
		to: data.to,
		email: data.email ?? null,
		companies: data.companies,
		users: data.users,
		updatesUntil: data.updatesUntil || null,
		computers: data.computers,
		notes: data.notes ?? null,
		createdBy: context.userId,
		edition: [
			"personal",
			"real_estate",
			"service",
			"full"
		].includes(data.edition ?? "") ? data.edition : null,
		addons: (data.addons ?? []).filter((a) => ["real_estate", "crypto_tax"].includes(a))
	});
});
var listLicenseKeys_createServerFn_handler = createServerRpc({
	id: "85f1fef7a0411d309d5893fece878801f90949dbde3de658a2916053fd00a251",
	name: "listLicenseKeys",
	filename: "src/lib/license.functions.ts"
}, (opts) => listLicenseKeys.__executeServer(opts));
var listLicenseKeys = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(listLicenseKeys_createServerFn_handler, async ({ context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const { data, error } = await (await requireOwner(context.userId)).from("desktop_licenses").select("*,desktop_activations(id,machine_name,app_version,first_seen,last_seen,released_at)").order("created_at", { ascending: false }).limit(500);
	if (error) throw new Error(error.message);
	return (data ?? []).map((r) => ({
		...r,
		activations: (r.desktop_activations ?? []).sort((a, b) => b.last_seen.localeCompare(a.last_seen))
	}));
});
var setLicenseOn_createServerFn_handler = createServerRpc({
	id: "43ed8732e31f6b7059578c4384ff3dc669315e2dcbc0ceef914318206731cc1b",
	name: "setLicenseOn",
	filename: "src/lib/license.functions.ts"
}, (opts) => setLicenseOn.__executeServer(opts));
var setLicenseOn = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(setLicenseOn_createServerFn_handler, async ({ data, context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const { error } = await (await requireOwner(context.userId)).from("desktop_licenses").update({ revoked: !data.on }).eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var releaseComputer_createServerFn_handler = createServerRpc({
	id: "487a6c1ba9a7b71ab5ed23fb488dba33912c2df9640f2ac290d7ad153199a3a7",
	name: "releaseComputer",
	filename: "src/lib/license.functions.ts"
}, (opts) => releaseComputer.__executeServer(opts));
var releaseComputer = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(releaseComputer_createServerFn_handler, async ({ data, context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const { error } = await (await requireOwner(context.userId)).from("desktop_activations").update({ released_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", data.id);
	if (error) throw new Error(error.message);
	return { ok: true };
});
var addExistingKey_createServerFn_handler = createServerRpc({
	id: "c3cb615a6833d9c11d076131e61d553f76bf27f094f99d46dcd824156aa301fa",
	name: "addExistingKey",
	filename: "src/lib/license.functions.ts"
}, (opts) => addExistingKey.__executeServer(opts));
var addExistingKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(addExistingKey_createServerFn_handler, async ({ data, context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const admin = await requireOwner(context.userId);
	const pem = (await import("./license-pem-Bul1iZky.mjs")).licensePem();
	if (!pem.includes("PRIVATE KEY")) throw new Error("Add the LICENSE_PRIVATE_KEY secret first.");
	const nodeCrypto = await import("node:crypto");
	const key = data.key.replace(/\s+/g, "");
	const m = /^(TK1\.([A-Za-z0-9_-]+))\.([A-Za-z0-9_-]+)$/.exec(key);
	const pub = nodeCrypto.createPublicKey(pem);
	if (!m || !nodeCrypto.verify(null, Buffer.from(m[1]), pub, Buffer.from(m[3], "base64url"))) throw new Error("That isn't a key Tallkeep made (the signature doesn't match).");
	const p = JSON.parse(Buffer.from(m[2], "base64url").toString("utf8"));
	const { error } = await admin.from("desktop_licenses").upsert({
		id: p.id,
		license_key: key,
		to_name: p.to,
		email: p.email ?? null,
		companies: p.companies,
		users: p.users,
		updates_until: p.updates,
		notes: data.notes?.trim() || null,
		created_by: context.userId
	});
	if (error) throw new Error(error.message);
	return { id: p.id };
});
var emailLicenseKey_createServerFn_handler = createServerRpc({
	id: "a3cdd7c9324ad5eab526048b501809bed2b6d4ed00f1862b877dbd2ec9fe2fba",
	name: "emailLicenseKey",
	filename: "src/lib/license.functions.ts"
}, (opts) => emailLicenseKey.__executeServer(opts));
var emailLicenseKey = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(emailLicenseKey_createServerFn_handler, async ({ data, context }) => {
	const { requireOwner } = await import("./admin.functions-MBmJ8uCy.mjs");
	const admin = await requireOwner(context.userId);
	const { data: l, error } = await admin.from("desktop_licenses").select("*").eq("id", data.id).maybeSingle();
	if (error || !l) throw new Error("That license isn't here.");
	const to = (data.to ?? l.email ?? "").trim();
	if (!/^\S+@\S+\.\S+$/.test(to)) throw new Error("This license has no email address.");
	const { mailLicense, mailNote } = await import("./license.server-Bu3IQdFy.mjs");
	const r = await mailLicense({
		to,
		name: l.to_name,
		id: l.id,
		key: l.license_key,
		companies: l.companies,
		users: l.users,
		updatesUntil: l.updates_until,
		origin: "https://app.tallkeep.com"
	});
	const notes = String(l.notes ?? "").replace(/ ?·? ?key email(ed [0-9-]+| didn't go \([^)]*\))/g, "").trim();
	await admin.from("desktop_licenses").update({ notes: [notes, mailNote(r)].filter(Boolean).join(" · ") }).eq("id", l.id);
	if (!r.ok) throw new Error(`The email didn't go: ${r.why}.`);
	return { to };
});
//#endregion
export { addExistingKey_createServerFn_handler, emailLicenseKey_createServerFn_handler, listLicenseKeys_createServerFn_handler, makeLicenseKey_createServerFn_handler, releaseComputer_createServerFn_handler, setLicenseOn_createServerFn_handler };
