import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/bank-transfers-B_2SaZ4L.js
var $$splitComponentImporter = () => import("./bank-transfers-BGC1BOdy.mjs");
var Route = createFileRoute("/_authenticated/bank-transfers")({
	validateSearch: (s) => typeof s["to"] === "string" ? { to: s["to"] } : {},
	head: () => ({ meta: [{ title: "Transfers · Tallkeep" }, {
		name: "description",
		content: "Move money between accounts, or pay the credit card."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
