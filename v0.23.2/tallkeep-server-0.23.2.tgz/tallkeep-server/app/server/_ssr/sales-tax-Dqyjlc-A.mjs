import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as balFrom, d as today, f as useAccounts, i as accountLabel, u as loadTotals } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-DUcTVge2.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as payFromAccounts, r as nextCheckNumber, t as METHOD_LABEL } from "./money-BnCYGdUa.mjs";
import { f as loadTaxRows } from "./reports-BrTLGjes.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales-tax-Dqyjlc-A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AGENCY_KEY = "sales-tax-agency";
var monthKey = (d) => d.slice(0, 7);
var monthName = (k) => (/* @__PURE__ */ new Date(`${k}-15T12:00:00`)).toLocaleDateString("en-US", {
	month: "short",
	year: "numeric"
});
function SalesTaxPage() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const taxAcct = accounts?.find((a) => a.key === "sales_tax");
	const { data, isLoading } = useQuery({
		queryKey: [
			"account-totals",
			"sales-tax",
			taxAcct?.id ?? ""
		],
		enabled: !!taxAcct,
		queryFn: async () => {
			const [totals, rows, paid, cs] = await Promise.all([
				loadTotals(null, null),
				loadTaxRows(),
				db.from("check_lines").select("amount,checks!inner(id,check_date,payee,method,number,status)").eq("account_id", taxAcct.id).limit(500),
				db.from("company_settings").select("books_start_date").maybeSingle()
			]);
			return {
				owed: balFrom(totals)(taxAcct),
				start: cs.data?.books_start_date ?? null,
				rows,
				paid: (paid.data ?? []).filter((p) => p.checks.status === "ok").sort((a, b) => b.checks.check_date.localeCompare(a.checks.check_date))
			};
		}
	});
	const months = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		const since = /* @__PURE__ */ new Date();
		since.setMonth(since.getMonth() - 11, 1);
		const from = since.toLocaleDateString("en-CA").slice(0, 7);
		for (const o of data?.rows ?? []) {
			if (o.number.startsWith("RMA-")) continue;
			const k = monthKey((o.invoice_date ?? o.order_date).slice(0, 10));
			if (k < from) continue;
			const g = m.get(k) ?? {
				sales: 0,
				tax: 0
			};
			g.sales += Number(o.total) - Number(o.tax);
			g.tax += Number(o.tax);
			m.set(k, g);
		}
		return [...m.entries()].sort((a, b) => b[0].localeCompare(a[0]));
	}, [data]);
	const pay = payFromAccounts(accounts);
	const [from, setFrom] = (0, import_react.useState)("");
	const [amt, setAmt] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today());
	const [agency, setAgency] = (0, import_react.useState)("");
	const [how, setHow] = (0, import_react.useState)("ach");
	const [period, setPeriod] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!from && pay.length) setFrom((pay.find((a) => a.kind === "bank") ?? pay[0]).id);
	}, [pay, from]);
	(0, import_react.useEffect)(() => {
		try {
			setAgency(localStorage.getItem(AGENCY_KEY) ?? "");
		} catch {}
	}, []);
	(0, import_react.useEffect)(() => {
		if (data && !amt && data.owed > 0) setAmt(data.owed.toFixed(2));
	}, [data, amt]);
	async function save() {
		const n = Math.round(Number(amt) * 100) / 100;
		if (!taxAcct) return;
		if (!agency.trim()) return void toast.error("Who do you pay? (for example: Illinois Department of Revenue)");
		if (!(n > 0)) return void toast.error("Type the amount.");
		if (!from) return void toast.error("Choose which account pays it.");
		setBusy(true);
		try {
			try {
				localStorage.setItem(AGENCY_KEY, agency.trim());
			} catch {}
			const { data: u } = await db.auth.getUser();
			const { data: c, error } = await db.from("checks").insert({
				account_id: from,
				method: how,
				number: how === "check" ? await nextCheckNumber(from) : null,
				check_date: date,
				payee: agency.trim(),
				memo: `Sales tax${period.trim() ? ` · ${period.trim()}` : ""}`,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const { error: le } = await db.from("check_lines").insert({
				check_id: c.id,
				line_no: 1,
				account_id: taxAcct.id,
				description: period.trim() || "Sales tax",
				amount: n
			});
			if (le) throw le;
			toast.success(`Sales tax payment of ${fmtMoney(n)} saved.`);
			setAmt("");
			setPeriod("");
			qc.invalidateQueries();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "Pay Sales Tax",
		text: "Sales tax you collected on invoices waits in Sales Tax Payable until you send it to the state. File your return on the state's website, then record the payment here."
	}), isLoading || !taxAcct ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "You owe the state now"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/accounts/$id",
						params: { id: taxAcct.id },
						className: "block text-3xl font-bold hover:text-[var(--section)] hover:underline",
						title: "See the transactions",
						children: fmtMoney(data?.owed ?? 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Balance of ",
							accountLabel(taxAcct),
							". Taxes collected minus payments made.",
							data?.start && ` Counts invoices from ${fmtDate(data.start)} on.`
						]
					}),
					data && !data.start && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-lg bg-amber-50 p-3 text-sm text-amber-900 dark:bg-amber-950 dark:text-amber-200",
						children: [
							"The books haven't started yet, so invoices don't reach the books and this shows $0. Set the books start date in",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/settings",
								className: "underline",
								children: "Settings → Accounting"
							}),
							". The months below come straight from your invoices."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "mt-3 w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-xs text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-left font-medium",
									children: "Month"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Sales"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-1 text-right font-medium",
									children: "Tax collected"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [months.map(([k, g]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1",
									children: monthName(k)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(g.sales)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-1 text-right tabular-nums",
									children: fmtMoney(g.tax)
								})
							]
						}, k)), months.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 3,
							className: "py-3 text-center text-muted-foreground",
							children: "No taxed sales in the last 12 months."
						}) })] })]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3 rounded-2xl border bg-card p-4 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-semibold",
						children: "Record a sales tax payment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Paid to",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: agency,
							onChange: (e) => setAgency(e.target.value),
							placeholder: "Illinois Department of Revenue"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Amount",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									step: "0.01",
									value: amt,
									onChange: (e) => setAmt(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Date paid",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: date,
									onChange: (e) => setDate(e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Paid from",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: from,
									options: pay.map((a) => ({
										value: a.id,
										label: accountLabel(a)
									})),
									onChange: setFrom
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "How",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: how,
									onChange: (e) => setHow(e.target.value),
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									children: Object.entries(METHOD_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: k,
										children: v
									}, k))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "For which period",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: period,
							onChange: (e) => setPeriod(e.target.value),
							placeholder: "October 2026"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy,
						children: busy ? "Saving…" : "Save the payment"
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "pt-2 font-semibold",
			children: "Payments made"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [(data?.paid ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-6 text-center text-muted-foreground",
				children: "None yet."
			}), (data?.paid ?? []).map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 text-xs",
						children: fmtDate(p.checks.check_date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [p.checks.payee, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs text-muted-foreground",
							children: [
								METHOD_LABEL[p.checks.method],
								" ",
								p.checks.number ?? ""
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: fmtMoney(Number(p.amount))
					})
				]
			}, i))]
		})
	] })] });
}
//#endregion
export { SalesTaxPage as component };
