import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-tdRottJR.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { L as Printer, N as Repeat, Nn as ArrowLeft, R as Plus, g as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-DUcTVge2.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { s as useRealEstate } from "./realestate-B7MhUll3.mjs";
import { i as payFromAccounts, n as amountInWords, r as nextCheckNumber, t as METHOD_LABEL } from "./money-BnCYGdUa.mjs";
import { t as Route } from "./checks_._id-D_srRPCL.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/checks_._id-Dh6R8puK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var blank = () => ({
	id: crypto.randomUUID(),
	account_id: "",
	description: "",
	amount: 0,
	property_id: null
});
function CheckPage() {
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const isNew = id === "new";
	const navigate = useNavigate();
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: features } = useFeatures();
	const realEstate = !!features?.includes("real_estate");
	const { data: re } = useRealEstate(realEstate);
	const { data: vendors } = useQuery({
		queryKey: ["vendors", "names-address"],
		queryFn: () => fetchAll("vendors", "id,name,address,is_active")
	});
	const { data: loaded, isLoading } = useQuery({
		queryKey: ["check", id],
		enabled: !isNew,
		queryFn: async () => {
			const [c, l, bp, pp] = await Promise.all([
				db.from("checks").select("*").eq("id", id).single(),
				db.from("check_lines").select("*").eq("check_id", id).order("line_no"),
				db.from("bill_payments").select("id,amount,bills(vendor_name,ref)").eq("check_id", id),
				db.from("payments").select("id,amount,purchase_orders(number)").eq("check_id", id)
			]);
			if (c.error) throw c.error;
			const paid = [...(bp.data ?? []).map((x) => ({
				id: x.id,
				kind: "bill",
				label: `Bill ${x.bills?.ref ?? ""}`.trim(),
				amount: Number(x.amount)
			})), ...(pp.data ?? []).map((x) => ({
				id: x.id,
				kind: "po",
				label: x.purchase_orders?.number ?? "PO",
				amount: Number(x.amount)
			}))];
			return {
				check: {
					...c.data,
					total: Number(c.data.total)
				},
				lines: (l.data ?? []).map((x) => ({
					...x,
					amount: Number(x.amount)
				})),
				paid
			};
		}
	});
	const payFrom = payFromAccounts(accounts);
	const [c, setC] = (0, import_react.useState)({
		method: search.card ? "card" : "check",
		check_date: today(),
		to_print: false
	});
	const [lines, setLines] = (0, import_react.useState)([blank()]);
	const [removed, setRemoved] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (loaded) {
			setC(loaded.check);
			setLines(loaded.lines.length ? loaded.lines : loaded.paid.length ? [] : [blank()]);
		}
	}, [loaded]);
	(0, import_react.useEffect)(() => {
		if (!isNew || c.account_id || !payFrom.length) return;
		const want = search.card ? "credit_card" : "bank";
		const a = payFrom.find((x) => x.id === search.account) ?? payFrom.find((x) => x.kind === want) ?? payFrom[0];
		setC((x) => ({
			...x,
			account_id: a.id
		}));
	}, [
		isNew,
		c.account_id,
		payFrom,
		search.card,
		search.account
	]);
	(0, import_react.useEffect)(() => {
		if (!isNew || !c.account_id || c.method !== "check" || c.number) return;
		nextCheckNumber(c.account_id).then((n) => setC((x) => x.number ? x : {
			...x,
			number: n
		}));
	}, [
		isNew,
		c.account_id,
		c.method,
		c.number
	]);
	const lineAccounts = (0, import_react.useMemo)(() => (accounts ?? []).filter((a) => a.is_active && !["ar", "ap"].includes(a.kind)).map((a) => ({
		value: a.id,
		label: accountLabel(a)
	})), [accounts]);
	const props = (re?.properties ?? []).filter((p) => p.is_active).map((p) => ({
		value: p.id,
		label: p.name
	}));
	const paid = loaded?.paid ?? [];
	const total = lines.reduce((s, l) => s + (Number(l.amount) || 0), 0) + paid.reduce((s, p) => s + p.amount, 0);
	const voided = c.status === "void";
	const patch = (i, p) => setLines((ls) => ls.map((l, j) => j === i ? {
		...l,
		...p
	} : l));
	const vendorOptions = (vendors ?? []).filter((v) => v.is_active || v.id === c.vendor_id).map((v) => ({
		value: v.id,
		label: v.name
	}));
	async function save(thenPrint = false) {
		const used = lines.filter((l) => Number(l.amount) || l.description?.trim());
		if (!c.account_id) return void toast.error("Choose which account it's paid from.");
		if (!c.payee?.trim()) return void toast.error("Who is it paid to?");
		if (!used.length && !paid.length) return void toast.error("Add at least one line with an amount.");
		if (used.some((l) => !l.account_id)) return void toast.error("Choose an account for every line.");
		setBusy(true);
		try {
			const head = {
				account_id: c.account_id,
				method: c.method ?? "check",
				number: c.method === "check" ? c.number?.trim() || null : c.number?.trim() || null,
				check_date: c.check_date,
				vendor_id: c.vendor_id ?? null,
				payee: c.payee.trim(),
				address: c.address?.trim() || null,
				memo: c.memo?.trim() || null,
				to_print: c.method === "check" ? !!c.to_print || thenPrint : false
			};
			let cid = c.id;
			if (!cid) {
				const { data: u } = await db.auth.getUser();
				const { data, error } = await db.from("checks").insert({
					...head,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				cid = data.id;
			} else {
				const { error } = await db.from("checks").update(head).eq("id", cid);
				if (error) throw error;
			}
			if (removed.length) {
				const { error } = await db.from("check_lines").delete().in("id", removed);
				if (error) throw error;
			}
			if (used.length) {
				const { error } = await db.from("check_lines").upsert(used.map((l, i) => ({
					id: l.id,
					check_id: cid,
					line_no: i + 1,
					account_id: l.account_id,
					description: l.description?.trim() || null,
					amount: Math.round((Number(l.amount) || 0) * 100) / 100,
					property_id: l.property_id || null
				})), { onConflict: "id" });
				if (error) throw error;
			}
			toast.success("Saved.");
			qc.invalidateQueries({ queryKey: ["checks"] });
			qc.invalidateQueries({ queryKey: ["account-totals"] });
			if (thenPrint) navigate({
				to: "/print-checks",
				search: { only: cid }
			});
			else if (isNew) navigate({
				to: "/checks/$id",
				params: { id: cid },
				search: c.method === "card" ? { card: 1 } : {}
			});
			else qc.invalidateQueries({ queryKey: ["check", id] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function voidIt() {
		if (!window.confirm(`Void this ${METHOD_LABEL[c.method ?? "check"].toLowerCase()}? It stays with its number but pays nothing.${paid.length ? " The bills it paid become unpaid again." : ""}`)) return;
		const { error } = await db.rpc("void_check", { _id: c.id });
		if (error) return void toast.error(error.message);
		toast.success("Voided.");
		qc.invalidateQueries();
	}
	async function remove() {
		if (!window.confirm("Delete this completely? (To keep the check number on record, use Void instead.)")) return;
		const { error } = await db.from("checks").delete().eq("id", c.id);
		if (error) return void toast.error(error.message);
		toast.success("Deleted.");
		qc.invalidateQueries();
		navigate({ to: c.method === "card" ? "/credit-cards" : "/checks" });
	}
	if (!isNew && (isLoading || !loaded)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }) });
	const kind = c.method === "card" ? "Card charge" : c.method === "check" ? "Check" : "Payment";
	if (typeof document !== "undefined") document.title = `${kind} · Tallkeep`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: search.card || c.method === "card" ? "/credit-cards" : "/checks",
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }),
				" ",
				search.card || c.method === "card" ? "Credit cards" : "Checks & payments"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "border-l-4 border-[var(--section)] pl-3 font-display text-2xl font-bold sm:text-3xl",
				children: isNew ? search.card ? "New card charge" : "Write a check" : `${kind}${c.number ? ` ${c.number}` : ""}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					!isNew && !voided && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void voidIt(),
						children: "Void"
					}),
					!isNew && !voided && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void navigate({
							to: "/recurring",
							search: { from: c.id }
						}),
						title: "Make this payment repeat every month (or week, quarter, year)",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, { className: "h-4 w-4" }), " Repeat this"]
					}),
					!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: () => void remove(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
					}),
					c.method === "check" && !voided && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void save(true),
						disabled: busy,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Save and print"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => void save(),
						disabled: busy || voided,
						children: busy ? "Saving…" : "Save"
					})
				]
			})]
		}),
		voided && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl bg-muted p-3 text-sm",
			children: "This is void and not in the books."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-2 sm:p-6 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Paid from",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: c.account_id ?? "",
						options: payFrom.map((a) => ({
							value: a.id,
							label: accountLabel(a)
						})),
						placeholder: "Bank or credit card",
						onChange: (v) => {
							const a = payFrom.find((x) => x.id === v);
							setC({
								...c,
								account_id: v,
								...a?.kind === "credit_card" ? { method: "card" } : {}
							});
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "How",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: c.method,
						onChange: (e) => setC({
							...c,
							method: e.target.value
						}),
						className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
						children: Object.entries(METHOD_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: k,
							children: v
						}, k))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: c.method === "check" ? "Check number" : "Reference (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: c.number ?? "",
						onChange: (e) => setC({
							...c,
							number: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: c.check_date ?? "",
						onChange: (e) => setC({
							...c,
							check_date: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					label: "Pay to (vendor)",
					wide: true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: c.vendor_id ?? "",
						options: vendorOptions,
						placeholder: c.payee || "Choose a vendor",
						onChange: (v) => {
							const ven = vendors?.find((x) => x.id === v);
							setC({
								...c,
								vendor_id: v,
								payee: ven?.name ?? "",
								address: c.address || ven?.address || ""
							});
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "mt-1.5",
						placeholder: "…or type a name",
						value: c.vendor_id ? "" : c.payee ?? "",
						onChange: (e) => setC({
							...c,
							vendor_id: null,
							payee: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Address (printed on the check)",
					wide: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						rows: 3,
						value: c.address ?? "",
						onChange: (e) => setC({
							...c,
							address: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Memo",
					wide: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: c.memo ?? "",
						onChange: (e) => setC({
							...c,
							memo: e.target.value
						})
					})
				}),
				c.method === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 self-end text-sm sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: !!c.to_print,
						onChange: (e) => setC({
							...c,
							to_print: e.target.checked
						})
					}), "Print later (it waits in Print Checks)"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-2xl border bg-card p-4 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "What it pays for"
				}),
				paid.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-medium",
						children: "Bills and purchase orders paid"
					}), paid.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: fmtMoney(p.amount)
						})]
					}, p.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y rounded-xl border",
					children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 p-2 sm:grid-cols-[minmax(0,2fr)_minmax(0,3fr)_8rem_2rem]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: l.account_id,
								options: lineAccounts,
								placeholder: "Account (e.g. Utilities)",
								onChange: (v) => patch(i, { account_id: v }),
								disabled: voided
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Description",
								value: l.description ?? "",
								onChange: (e) => patch(i, { description: e.target.value }),
								disabled: voided
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								className: "text-right",
								placeholder: "0.00",
								value: l.amount || "",
								onChange: (e) => patch(i, { amount: Number(e.target.value) }),
								disabled: voided
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": "Remove line",
								disabled: voided,
								onClick: () => {
									setRemoved((r) => [...r, l.id]);
									setLines((ls) => ls.filter((_, j) => j !== i));
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							}),
							realEstate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: l.property_id ?? "",
									options: props,
									placeholder: "For which property? (optional)",
									onChange: (v) => patch(i, { property_id: v }),
									disabled: voided
								})
							})
						]
					}, l.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setLines((ls) => [...ls, blank()]),
						disabled: voided,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-semibold",
							children: fmtMoney(total)
						}), c.method === "check" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [amountInWords(total), " dollars"]
						})]
					})]
				}),
				c.printed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Printed ",
						fmtDate(c.printed_at.slice(0, 10)),
						"."
					]
				})
			]
		})
	] });
}
//#endregion
export { CheckPage as component };
