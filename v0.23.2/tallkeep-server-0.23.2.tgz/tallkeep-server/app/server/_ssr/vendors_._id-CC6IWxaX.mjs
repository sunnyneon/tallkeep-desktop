import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/vendors_._id-CC6IWxaX.js
var $$splitComponentImporter = () => import("./vendors_._id-CqmsR6Gw.mjs");
var Route = createFileRoute("/_authenticated/vendors_/$id")({
	head: () => ({ meta: [{ title: "Vendor · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
