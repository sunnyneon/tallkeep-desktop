import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today, f as useAccounts, i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { R as Plus, g as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-DUcTVge2.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/deposits-B0WX7kAN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Deposits() {
	const qc = useQueryClient();
	const { data: accounts } = useAccounts();
	const { data: items, isLoading } = useQuery({
		queryKey: ["deposits", "waiting"],
		queryFn: async () => {
			const { data, error } = await db.rpc("undeposited_items");
			if (error) throw error;
			return (data ?? []).map((i) => ({
				...i,
				amount: Number(i.amount)
			})).sort((a, b) => a.paid_on.localeCompare(b.paid_on));
		}
	});
	const { data: past } = useQuery({
		queryKey: ["deposits", "past"],
		queryFn: async () => {
			const { data, error } = await db.from("deposits").select("id,account_id,deposit_date,memo,total,deposit_lines(amount,name,description,payment_id,rent_payment_id)").order("deposit_date", { ascending: false }).limit(200);
			if (error) throw error;
			return data ?? [];
		}
	});
	const banks = (accounts ?? []).filter((a) => a.is_active && a.kind === "bank");
	const incomeish = (accounts ?? []).filter((a) => a.is_active && a.key !== "undeposited").map((a) => ({
		value: a.id,
		label: accountLabel(a)
	}));
	const [pick, setPick] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [bank, setBank] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)(today());
	const [memo, setMemo] = (0, import_react.useState)("");
	const [others, setOthers] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!bank && banks[0]) setBank(banks[0].id);
	}, [banks, bank]);
	const chosen = (0, import_react.useMemo)(() => (items ?? []).filter((i) => pick.has(i.id)), [items, pick]);
	const otherTotal = others.reduce((s, o) => s + (Number(o.amount) || 0), 0);
	const total = chosen.reduce((s, i) => s + i.amount, 0) + otherTotal;
	const name = new Map((accounts ?? []).map((a) => [a.id, accountLabel(a)]));
	async function save() {
		if (!bank) return void toast.error("Choose the bank account.");
		const extra = others.filter((o) => Number(o.amount));
		if (!chosen.length && !extra.length) return void toast.error("Tick payments or add other money.");
		if (extra.some((o) => !o.account_id)) return void toast.error("Choose where the other money comes from.");
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const { data: d, error } = await db.from("deposits").insert({
				account_id: bank,
				deposit_date: date,
				memo: memo.trim() || null,
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const id = d.id;
			const { error: le } = await db.from("deposit_lines").insert([...chosen.map((i) => ({
				deposit_id: id,
				payment_id: i.kind === "payment" ? i.id : null,
				rent_payment_id: i.kind === "rent" ? i.id : null,
				name: i.name,
				description: [i.ref, i.method].filter(Boolean).join(" · ") || null,
				amount: i.amount
			})), ...extra.map((o) => ({
				deposit_id: id,
				account_id: o.account_id,
				name: o.name.trim() || null,
				description: o.description.trim() || null,
				amount: Math.round(Number(o.amount) * 100) / 100
			}))]);
			if (le) {
				await db.from("deposits").delete().eq("id", id);
				throw le;
			}
			toast.success(`Deposit of ${fmtMoney(total)} saved.`);
			setPick(/* @__PURE__ */ new Set());
			setOthers([]);
			setMemo("");
			qc.invalidateQueries({ queryKey: ["deposits"] });
			qc.invalidateQueries({ queryKey: ["account-totals"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function remove(d) {
		if (!window.confirm(`Delete the deposit of ${fmtMoney(Number(d.total))}? Its payments go back to waiting.`)) return;
		const { error } = await db.from("deposits").delete().eq("id", d.id);
		if (error) return void toast.error(error.message);
		toast.success("Deposit deleted.");
		qc.invalidateQueries({ queryKey: ["deposits"] });
		qc.invalidateQueries({ queryKey: ["account-totals"] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Record Deposits",
			text: "Payments received into Undeposited Funds wait here. Tick the ones you took to the bank together, so the books show one deposit, just like your bank statement."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-2xl border bg-card p-4 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Deposit to",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
						value: bank,
						options: banks.map((a) => ({
							value: a.id,
							label: accountLabel(a)
						})),
						onChange: setBank
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Memo",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: memo,
						onChange: (e) => setMemo(e.target.value)
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "Waiting to be deposited"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setPick(new Set((items ?? []).map((i) => i.id))),
					children: "Tick all"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setPick(/* @__PURE__ */ new Set()),
					children: "Clear"
				})]
			})]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [items && items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-6 text-center text-muted-foreground",
				children: "Nothing waiting. Payments land here when \"Deposit to\" is Undeposited Funds (set it as the usual choice in Settings → Accounting)."
			}), (items ?? []).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex cursor-pointer items-center gap-3 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: pick.has(i.id),
						onChange: (e) => {
							const n = new Set(pick);
							if (e.target.checked) n.add(i.id);
							else n.delete(i.id);
							setPick(n);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 text-xs",
						children: fmtDate(i.paid_on)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [i.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-muted-foreground",
							children: [i.kind === "rent" ? `Rent · ${i.ref}` : i.ref, i.method].filter(Boolean).join(" · ")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: fmtMoney(i.amount)
					})
				]
			}, i.id))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "Other money in this deposit (optional)"
				}),
				others.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-[minmax(0,2fr)_minmax(0,1.5fr)_minmax(0,2fr)_7rem_2rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
							value: o.account_id,
							options: incomeish,
							placeholder: "From account (e.g. Other Income)",
							onChange: (v) => setOthers(others.map((x, j) => j === i ? {
								...x,
								account_id: v
							} : x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Received from",
							value: o.name,
							onChange: (e) => setOthers(others.map((x, j) => j === i ? {
								...x,
								name: e.target.value
							} : x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "What for",
							value: o.description,
							onChange: (e) => setOthers(others.map((x, j) => j === i ? {
								...x,
								description: e.target.value
							} : x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							step: "0.01",
							className: "text-right",
							value: o.amount,
							onChange: (e) => setOthers(others.map((x, j) => j === i ? {
								...x,
								amount: e.target.value
							} : x))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							"aria-label": "Remove line",
							onClick: () => setOthers(others.filter((_, j) => j !== i)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
						})
					]
				}, o.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => setOthers([...others, {
						id: crypto.randomUUID(),
						account_id: "",
						name: "",
						description: "",
						amount: ""
					}]),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add other money"]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-end gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: ["Deposit total: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtMoney(total) })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => void save(),
				disabled: busy,
				children: busy ? "Saving…" : "Save deposit"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "pt-4 font-semibold",
			children: "Past deposits"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [(past ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-6 text-center text-muted-foreground",
				children: "No deposits yet."
			}), (past ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3 px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-24 text-xs",
						children: fmtDate(d.deposit_date)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [name.get(d.account_id), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block truncate text-xs text-muted-foreground",
							children: [
								d.deposit_lines.length,
								" item",
								d.deposit_lines.length === 1 ? "" : "s",
								d.memo ? ` · ${d.memo}` : "",
								" ·",
								" ",
								d.deposit_lines.map((l) => l.name).filter(Boolean).join(", ")
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold",
						children: fmtMoney(Number(d.total))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "ghost",
						"aria-label": "Delete deposit",
						onClick: () => void remove(d),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
					})
				]
			}, d.id))]
		})
	] });
}
//#endregion
export { Deposits as component };
