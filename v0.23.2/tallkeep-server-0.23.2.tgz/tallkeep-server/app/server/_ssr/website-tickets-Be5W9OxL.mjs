import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { D as Search } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { n as BILLING_STYLE, t as BILLING_LABEL } from "./website-tickets-DWH8z9fN.mjs";
import { r as listTickets } from "./tickets.functions-BSY7Jqc9.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/website-tickets-Be5W9OxL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SHOW = [
	{
		key: "done",
		label: "Job done, not paid"
	},
	{
		key: "open",
		label: "Open"
	},
	{
		key: "all",
		label: "All (not archived)"
	},
	{
		key: "archived",
		label: "Archived"
	}
];
function TicketsPage() {
	const navigate = useNavigate();
	const { data, isLoading, error } = useQuery({
		queryKey: ["tickets"],
		queryFn: () => listTickets()
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)("done");
	const rows = (0, import_react.useMemo)(() => {
		const words = q.toLowerCase().split(/\s+/).filter(Boolean);
		return (data ?? []).filter((t) => {
			if (show === "archived") return !!t.archived_at;
			if (t.archived_at) return false;
			if (show === "done") return !!t.completed_at && t.billing_status !== "paid" && t.billing_status !== "free";
			if (show === "open") return !t.completed_at;
			return true;
		}).filter((t) => {
			const hay = `${t.number} ${t.name ?? ""} ${t.company ?? ""} ${t.email ?? ""} ${t.subject ?? ""}`.toLowerCase();
			return words.every((w) => hay.includes(w));
		});
	}, [
		data,
		q,
		show
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Tickets",
				text: "Service tickets from sunriseled.com. Open one to make the final invoice."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: SHOW.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setShow(x.key),
					className: `rounded-full border px-3 py-1.5 text-sm font-medium ${show === x.key ? "border-[var(--section)] bg-[var(--section)] text-white" : "bg-card hover:bg-muted"}`,
					children: x.label
				}, x.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-9",
					placeholder: "Search ticket #, customer or subject",
					value: q,
					onChange: (e) => setQ(e.target.value)
				})]
			}),
			isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-destructive/40 p-4 text-sm text-destructive",
				children: error.message
			}),
			data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto rounded-2xl border bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-muted/40 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Ticket"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Customer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Subject"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Billing"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 text-right",
								children: "Quoted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Job done"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2",
								children: "Opened"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y",
						children: rows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "cursor-pointer hover:bg-muted/50",
							onClick: () => navigate({
								to: "/website-tickets/$id",
								params: { id: String(t.id) }
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 font-medium",
									style: { color: "var(--section)" },
									children: t.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[220px] truncate px-3 py-2",
									children: t.company || t.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-[320px] truncate px-3 py-2 text-muted-foreground",
									children: t.subject
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-0.5 text-xs font-medium ${BILLING_STYLE[t.billing_status ?? ""] ?? "bg-muted"}`,
										children: BILLING_LABEL[t.billing_status ?? ""] ?? t.billing_status
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-right",
									children: t.quoted_amount_cents ? fmtMoney(t.quoted_amount_cents / 100) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: t.completed_at ? fmtDate(t.completed_at) : ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2 text-muted-foreground",
									children: fmtDate(t.created_at)
								})
							]
						}, t.id))
					})]
				}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-center text-sm text-muted-foreground",
					children: "No tickets here."
				})]
			})
		]
	});
}
//#endregion
export { TicketsPage as component };
