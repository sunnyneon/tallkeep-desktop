import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { d as today } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { R as Plus } from "../_libs/lucide-react.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-DUcTVge2.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { i as loadCharges, o as refreshRealEstate, s as useRealEstate } from "./realestate-B7MhUll3.mjs";
import { t as Badge } from "./badge-D1Dupn2y.mjs";
import { t as Route } from "./leases-CsfF0qYs.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/leases-B1O6tCJW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var monthStart = () => `${today().slice(0, 7)}-01`;
function Leases() {
	const search = Route.useSearch();
	const { data, isLoading } = useRealEstate();
	const { data: open } = useQuery({
		queryKey: ["rent-charges", "open"],
		queryFn: () => loadCharges(true)
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)("active");
	const [edit, setEdit] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!data) return;
		if (search.lease) {
			const l = data.lease.get(search.lease);
			if (l) setEdit(l);
		} else if (search.unit) setEdit({ unit_id: search.unit });
	}, [
		data,
		search.lease,
		search.unit
	]);
	const owed = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const c of open ?? []) m.set(c.lease_id, (m.get(c.lease_id) ?? 0) + c.balance);
		return m;
	}, [open]);
	const rows = (0, import_react.useMemo)(() => {
		if (!data) return [];
		const list = data.leases.filter((l) => show === "all" || l.status === "active").map((l) => ({
			l,
			tenant: data.tenant.get(l.tenant_id),
			unit: data.unitLabel(l.unit_id)
		}));
		return smartSearch(list, q, (r) => r.tenant?.name ?? "", (r) => `${r.unit} ${r.tenant?.phone ?? ""}`).sort((a, b) => (a.l.status === "active" ? 0 : 1) - (b.l.status === "active" ? 0 : 1) || a.unit.localeCompare(b.unit, void 0, { numeric: true }));
	}, [
		data,
		q,
		show
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Leases & Tenants",
			text: "Each lease is a tenant renting a unit. Rent is charged on the due day each month from the Rent page.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setEdit({}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " New lease"]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				className: "max-w-xs",
				placeholder: "Search tenant or unit",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "inline-flex rounded-lg border p-0.5 text-sm",
				children: ["active", "all"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setShow(v),
					className: `rounded-md px-3 py-1 ${show === v ? "bg-[var(--section)] text-white" : ""}`,
					children: v === "active" ? "Active leases" : "All, with ended"
				}, v))
			})]
		}),
		isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "divide-y overflow-hidden rounded-2xl border bg-card text-sm",
			children: [data && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "p-8 text-center text-muted-foreground",
				children: "No leases yet. Add properties and units first, then press \"New lease\"."
			}), rows.map(({ l, tenant, unit }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => setEdit(l),
				className: "flex w-full flex-wrap items-center gap-3 px-4 py-3 text-left hover:bg-muted/50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: tenant?.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								unit,
								" · ",
								fmtDate(l.start_date),
								" –",
								" ",
								l.end_date ? fmtDate(l.end_date) : "month to month"
							]
						})]
					}),
					l.status === "ended" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						children: "Ended"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-28 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: fmtMoney(l.rent)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "a month"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-28 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: (owed.get(l.id) ?? 0) > 0 ? "font-semibold text-destructive" : "",
							children: fmtMoney(owed.get(l.id) ?? 0)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "owed"
						})]
					})
				]
			}, l.id))]
		}),
		edit && data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LeaseDialog, {
			draft: edit,
			onClose: () => setEdit(null)
		})
	] });
}
function LeaseDialog({ draft, onClose }) {
	const qc = useQueryClient();
	const { data } = useRealEstate();
	const isNew = !draft.id;
	const unit = draft.unit_id ? data?.unit.get(draft.unit_id) : void 0;
	const [d, setD] = (0, import_react.useState)({
		unit_id: draft.unit_id ?? "",
		tenant_id: draft.tenant_id ?? "",
		start_date: draft.start_date ?? today(),
		end_date: draft.end_date ?? "",
		rent: String(draft.rent ?? unit?.market_rent ?? ""),
		due_day: String(draft.due_day ?? 1),
		deposit: String(draft.deposit ?? ""),
		late_fee: String(draft.late_fee ?? ""),
		grace_days: String(draft.grace_days ?? 5),
		charge_from: draft.charge_from ?? monthStart(),
		notes: draft.notes ?? ""
	});
	const old = draft.tenant_id ? data?.tenant.get(draft.tenant_id) : void 0;
	const [t, setT] = (0, import_react.useState)({
		name: old?.name ?? "",
		phone: old?.phone ?? "",
		email: old?.email ?? ""
	});
	const [newTenant, setNewTenant] = (0, import_react.useState)(isNew);
	const [chargeDeposit, setChargeDeposit] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (p) => setD((x) => ({
		...x,
		...p
	}));
	const unitOptions = (data?.units ?? []).filter((u) => u.is_active && (u.id === d.unit_id || !data?.current(u.id))).map((u) => ({
		value: u.id,
		label: data.unitLabel(u.id)
	}));
	const tenantOptions = (data?.tenants ?? []).map((x) => ({
		value: x.id,
		label: x.name,
		...x.phone ? { hint: x.phone } : {}
	}));
	async function save() {
		if (!d.unit_id) return void toast.error("Pick the unit.");
		if (newTenant ? !t.name.trim() : !d.tenant_id) return void toast.error("Who is the tenant?");
		if (!(Number(d.rent) > 0)) return void toast.error("Type the monthly rent.");
		setBusy(true);
		try {
			let tenantId = d.tenant_id;
			const tRow = {
				name: t.name.trim(),
				phone: t.phone.trim() || null,
				email: t.email.trim() || null
			};
			if (newTenant) {
				const { data: row, error } = await db.from("tenants").insert(tRow).select("id").single();
				if (error) throw error;
				tenantId = row.id;
			} else if (old && (tRow.name !== old.name || tRow.phone !== old.phone || tRow.email !== old.email)) {
				if (tRow.name) {
					const { error } = await db.from("tenants").update(tRow).eq("id", old.id);
					if (error) throw error;
				}
			}
			const row = {
				unit_id: d.unit_id,
				tenant_id: tenantId,
				start_date: d.start_date,
				end_date: d.end_date || null,
				rent: Number(d.rent),
				due_day: Math.min(28, Math.max(1, Math.floor(Number(d.due_day) || 1))),
				deposit: Number(d.deposit) || 0,
				late_fee: Number(d.late_fee) || 0,
				grace_days: Math.max(0, Math.floor(Number(d.grace_days) || 0)),
				charge_from: d.charge_from || null,
				notes: d.notes.trim() || null
			};
			if (isNew) {
				const { data: l, error } = await db.from("leases").insert(row).select("id").single();
				if (error) throw error;
				if (chargeDeposit && row.deposit > 0) {
					const when = row.start_date > today() ? row.start_date : today();
					const { error: e2 } = await db.from("rent_charges").insert({
						lease_id: l.id,
						kind: "deposit",
						charge_date: when,
						due_date: when,
						description: "Security deposit",
						amount: row.deposit
					});
					if (e2) throw e2;
				}
			} else {
				const { error } = await db.from("leases").update(row).eq("id", draft.id);
				if (error) throw error;
			}
			toast.success("Lease saved.");
			refreshRealEstate(qc);
			onClose();
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function end() {
		const on = window.prompt("Last day of the lease (YYYY-MM-DD):", today());
		if (!on) return;
		if (!/^\d{4}-\d{2}-\d{2}$/.test(on)) return void toast.error("Use a date like 2027-03-31.");
		const { error } = await db.from("leases").update({
			status: "ended",
			ended_on: on,
			end_date: d.end_date || on
		}).eq("id", draft.id);
		if (error) return void toast.error(error.message);
		toast.success("Lease ended. If you give the deposit back, enter it in Bills & Expenses using the Security Deposits Held account.");
		refreshRealEstate(qc);
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: isNew ? "New lease" : "Lease" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Rent is charged on the due day each month, starting with the \"first month to charge here\". Earlier months stay in your old system." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Unit",
							wide: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: d.unit_id,
								onChange: (v) => set({ unit_id: v }),
								options: unitOptions,
								placeholder: "Pick a vacant unit"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 rounded-xl border p-3 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: "Tenant"
								}), isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-xs underline",
									onClick: () => setNewTenant((x) => !x),
									children: newTenant ? "Pick a tenant we already have" : "Add a new tenant"
								})]
							}), !newTenant && isNew ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
								value: d.tenant_id,
								onChange: (v) => set({ tenant_id: v }),
								options: tenantOptions,
								placeholder: "Pick the tenant"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Name",
										value: t.name,
										onChange: (e) => setT({
											...t,
											name: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Phone",
										value: t.phone,
										onChange: (e) => setT({
											...t,
											phone: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										placeholder: "Email",
										value: t.email,
										onChange: (e) => setT({
											...t,
											email: e.target.value
										})
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Starts",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.start_date,
								onChange: (e) => set({ start_date: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Ends (empty = month to month)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.end_date,
								onChange: (e) => set({ end_date: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Monthly rent",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								value: d.rent,
								onChange: (e) => set({ rent: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Due on day (1–28)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								max: 28,
								value: d.due_day,
								onChange: (e) => set({ due_day: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Security deposit",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								value: d.deposit,
								onChange: (e) => set({ deposit: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "First month to charge here",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: d.charge_from,
								onChange: (e) => set({ charge_from: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Late fee",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								step: "0.01",
								value: d.late_fee,
								onChange: (e) => set({ late_fee: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Late after how many days",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 0,
								value: d.grace_days,
								onChange: (e) => set({ grace_days: e.target.value })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notes",
							wide: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: d.notes,
								onChange: (e) => set({ notes: e.target.value })
							})
						}),
						isNew && Number(d.deposit) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm sm:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: chargeDeposit,
									onChange: (e) => setChargeDeposit(e.target.checked)
								}),
								"Charge the ",
								fmtMoney(Number(d.deposit)),
								" deposit now (uncheck if they paid it in your old system)"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [!isNew && draft.status === "active" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => void end(),
						children: "End this lease"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void save(),
							disabled: busy,
							children: busy ? "Saving…" : "Save lease"
						})]
					})]
				})
			]
		})
	});
}
//#endregion
export { Leases as component };
