import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as blobToBase64, r as makePdf } from "./DocPdf-D9IQazty.mjs";
import { i as fmtQty, t as fmtDate } from "./format-CORJO1ov.mjs";
import { n as db } from "./db-DDA6cTbR.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { Gt as Download, P as RotateCcw, st as Mail } from "../_libs/lucide-react.mjs";
import { r as useCategories } from "./queries-C-beXuGX.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C2ane53G.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { u as SearchSelect } from "./SearchSelect-Yp0ZfJ76.mjs";
import { a as useAddCategory } from "./quickadd-CI1bn9fK.mjs";
import { i as SLOT, r as PLACEMENTS } from "./footers-9QMKuKZn.mjs";
import { t as sendDocEmail } from "./email.functions-DswAxhkP.mjs";
import { i as quoteLink, o as useCardPay, r as payLink } from "./cardpay-DXL_ECil.mjs";
import { t as Checkbox } from "./checkbox-DO7eC_vL.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/NewProductDialog-Du0ppW1l.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** Each time items went out (an invoice) or came in (a purchase order), with Undo on the latest. */
var shortName = (l) => {
	const d = (l.description ?? "").split("\n")[0] ?? "";
	return (d.split(" — ")[0] ?? d).slice(0, 60) || "Item";
};
function Fulfilments({ docId, lines, onUndo, word = "went out" }) {
	const { data: batches } = useQuery({
		queryKey: ["stock-batches", docId],
		queryFn: async () => {
			const { data, error } = await db.from("stock_batches").select("id,created_at,lines").eq("doc_id", docId).is("undone_at", null).order("created_at");
			if (error) return [];
			return data ?? [];
		}
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!batches?.length) return null;
	const name = (id) => {
		const l = lines.find((x) => x.id === id);
		return l ? shortName(l) : "Item";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border bg-card p-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 font-medium",
			children: "History"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1",
			children: batches.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [fmtDate(b.created_at), ":"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							b.lines.map((x) => `${fmtQty(Number(x.qty))} × ${name(x.line)}`).join(", "),
							" ",
							word
						]
					}),
					i === batches.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						disabled: busy,
						onClick: async () => {
							if (!window.confirm("Undo this one? The stock goes back as it was.")) return;
							setBusy(true);
							await onUndo(b.id);
							setBusy(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-3.5 w-3.5" }), " Undo this one"]
					})
				]
			}, b.id))
		})]
	});
}
/** Pick the saved footers for this document; the text can still be changed here. */
function FooterPicker({ footers, doc, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: "Footers and attached pages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/settings",
					className: "text-xs text-primary underline",
					children: "Edit saved footers"
				})]
			}),
			PLACEMENTS.map((pl) => {
				const { id, text } = SLOT[pl.key];
				const choices = footers.filter((f) => f.placement === pl.key);
				const val = doc[id];
				const body = doc[text];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							className: "text-xs text-muted-foreground",
							children: pl.pick
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: val ?? "none",
							disabled: disabled ?? false,
							onValueChange: (v) => {
								const f = footers.find((x) => x.id === v);
								onChange({
									[id]: f?.id ?? null,
									[text]: f?.body ?? null
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "None" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "none",
								children: "None"
							}), choices.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: f.id,
								children: f.name
							}, f.id))] })]
						}),
						(val || body) && pl.key !== "attach" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							className: "text-xs",
							disabled: disabled ?? false,
							value: body ?? "",
							onChange: (e) => onChange({ [text]: e.target.value || null })
						})
					]
				}, pl.key);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Changes here are for this document only."
			})
		]
	});
}
var split = (v) => v.split(/[,;\s]+/).map((x) => x.trim()).filter(Boolean);
/** Send the document as a PDF (with any attached page) from the company email. */
function EmailDocDialog({ doc, filename, to, subject, message, myEmail, onClose, onSent, deposit, payNow, acceptOnline }) {
	const { data: card } = useCardPay();
	const canPay = (!!payNow || !!acceptOnline) && !!card?.connected;
	const [addPay, setAddPay] = (0, import_react.useState)(true);
	const [f, setF] = (0, import_react.useState)({
		to,
		cc: "",
		subject,
		message,
		copyMe: true
	});
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)("");
	const [askDep, setAskDep] = (0, import_react.useState)(false);
	const [pct, setPct] = (0, import_react.useState)(String(deposit?.percent ?? 50));
	const depAmount = deposit ? Math.round(deposit.of * (Number(pct) || 0)) / 100 : 0;
	const full = (Number(pct) || 0) >= 100;
	const word = full ? "payment" : "deposit";
	const opts = () => askDep && depAmount > 0 ? {
		deposit: depAmount,
		depositLabel: full ? "Payment due now" : "Deposit due now"
	} : {};
	const cents = askDep && depAmount > 0 ? Math.round(depAmount * 100) : void 0;
	async function getPayUrl() {
		if (!(canPay && addPay)) return void 0;
		const { url } = acceptOnline ? await quoteLink(acceptOnline.quoteId, cents) : await payLink(payNow.invoiceId, cents);
		return url;
	}
	const payLabel = acceptOnline ? cents ? `Accept and pay the ${word} online` : "Review and accept online" : "Pay now online";
	const linkLine = (url) => acceptOnline ? `Review and accept this quote online${cents ? ` (and pay the ${word})` : ""}: ${url}` : `Pay online (card, Apple Pay or bank account): ${url}`;
	async function send() {
		setBusy("send");
		setFailed("");
		try {
			const cc = [...split(f.cc), ...f.copyMe && myEmail ? [myEmail] : []];
			let message = f.message;
			const payUrl = await getPayUrl();
			if (payUrl) message = `${message.trimEnd()}\n\n${linkLine(payUrl)}`;
			const blob = await makePdf(doc({
				...opts(),
				...payUrl ? {
					payUrl,
					payLabel
				} : {}
			}));
			await sendDocEmail({ data: {
				to: split(f.to),
				cc,
				subject: f.subject,
				message,
				filename,
				pdfBase64: await blobToBase64(blob)
			} });
			toast.success(`Sent to ${f.to}.`);
			onSent?.(f.to.trim());
			onClose();
		} catch (e) {
			setFailed(e.message);
		} finally {
			setBusy(null);
		}
	}
	async function download() {
		setBusy("pdf");
		try {
			const payUrl = await getPayUrl();
			const blob = await makePdf(doc({
				...opts(),
				...payUrl ? {
					payUrl,
					payLabel
				} : {}
			}));
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = filename;
			a.click();
			setTimeout(() => URL.revokeObjectURL(url), 5e3);
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Email ", filename.replace(/\.pdf$/, "")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Sent from the company email with the PDF attached. Replies come back to you." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "To" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.to,
								onChange: (e) => setF({
									...f,
									to: e.target.value
								}),
								placeholder: "customer@example.com"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Copy to (optional)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.cc,
								onChange: (e) => setF({
									...f,
									cc: e.target.value
								}),
								placeholder: "other emails, separated by commas"
							})]
						}),
						myEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: f.copyMe,
									onCheckedChange: (v) => setF({
										...f,
										copyMe: v === true
									})
								}),
								"Send me a copy (",
								myEmail,
								")"
							]
						}),
						canPay && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: addPay,
								onCheckedChange: (v) => setAddPay(v === true)
							}), acceptOnline ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Let them accept it online",
								askDep && depAmount > 0 ? ` and pay the ${word}` : "",
								" (a button in the email and on the PDF)"
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Add \"Pay now online\" to the email and the invoice",
								askDep && depAmount > 0 ? ` (for the ${word})` : "",
								": card, Apple Pay or bank account"
							] })]
						}),
						deposit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 rounded-xl border p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: askDep,
										onCheckedChange: (v) => setAskDep(v === true)
									}), "Ask for a deposit or full payment now"]
								}),
								askDep && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2 text-sm",
									children: [
										["50", "100"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: pct === v ? "default" : "outline",
											className: "h-8",
											onClick: () => setPct(v),
											children: v === "100" ? "Full amount" : "Half"
										}, v)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "h-8 w-20 text-right",
											inputMode: "decimal",
											value: pct,
											onChange: (e) => setPct(e.target.value)
										}),
										"% of ",
										deposit.label,
										" =",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: depAmount.toLocaleString("en-US", {
											style: "currency",
											currency: "USD"
										}) })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Adds a \"",
										full ? "Payment" : "Deposit",
										" due now\" line to the PDF.",
										" ",
										canPay && addPay ? "Paid online, it goes in the books by itself." : "Record the money with Record payment when it arrives."
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Subject" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.subject,
								onChange: (e) => setF({
									...f,
									subject: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Message" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 6,
								value: f.message,
								onChange: (e) => setF({
									...f,
									message: e.target.value
								})
							})]
						})
					]
				}),
				failed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-900 dark:border-red-900 dark:bg-red-950/40 dark:text-red-100",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Not sent." }),
						" ",
						failed
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => void download(),
						disabled: !!busy,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" }),
							" ",
							busy === "pdf" ? "Making PDF…" : "Download PDF"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void send(),
						disabled: !!busy || !f.to.trim(),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
							" ",
							busy === "send" ? "Sending…" : "Send email"
						]
					})]
				})
			]
		})
	});
}
/** Add a product without leaving the quote / invoice / purchase order (like inFlow's "Add new"). */
function NewProductDialog({ name, onClose, onCreated }) {
	const addCategoryNow = useAddCategory();
	const qc = useQueryClient();
	const { data: cats } = useCategories();
	const [f, setF] = (0, import_react.useState)({
		name,
		description: "",
		item_type: "stocked",
		price: "",
		cost: "",
		category: ""
	});
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		if (!f.name.trim()) {
			toast.error("Type the product name.");
			return;
		}
		setBusy(true);
		const { data, error } = await db.from("products").insert({
			name: f.name.trim(),
			description: f.description.trim() || null,
			item_type: f.item_type,
			price: Number(f.price) || 0,
			cost: Number(f.cost) || 0,
			category_id: f.category || null
		}).select("id,name,description,price,cost,unit,item_type").single();
		setBusy(false);
		if (error) {
			toast.error(error.message.includes("duplicate") ? "A product with that name already exists." : error.message);
			return;
		}
		toast.success(`${f.name.trim()} added to the product list.`);
		qc.invalidateQueries({ queryKey: ["products"] });
		onCreated(data);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Add a new product" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "It's added to your Product List and put on this line." })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Item name / code" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								autoFocus: true,
								value: f.name,
								onChange: (e) => setF({
									...f,
									name: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: f.description,
								onChange: (e) => setF({
									...f,
									description: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: f.item_type,
										onValueChange: (v) => setF({
											...f,
											item_type: v
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "stocked",
												children: "Stocked product"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "non_stocked",
												children: "Non-stocked product"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "service",
												children: "Service / labor"
											})
										] })]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
										value: f.category,
										onChange: (v) => setF({
											...f,
											category: v
										}),
										options: [...(cats ?? []).map((c) => ({
											value: c.id,
											label: c.name
										}))],
										onAdd: addCategoryNow,
										addLabel: "Add new category",
										placeholder: "Choose",
										searchText: "Type a category"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Selling price ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: f.price,
										onChange: (e) => setF({
											...f,
											price: e.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Cost ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: f.cost,
										onChange: (e) => setF({
											...f,
											cost: e.target.value
										})
									})]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void save(),
					disabled: busy,
					children: busy ? "Adding…" : "Add product"
				})] })
			]
		})
	});
}
//#endregion
export { NewProductDialog as i, FooterPicker as n, Fulfilments as r, EmailDocDialog as t };
