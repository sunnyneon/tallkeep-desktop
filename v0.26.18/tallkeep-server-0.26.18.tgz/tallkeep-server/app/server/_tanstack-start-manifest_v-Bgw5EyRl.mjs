//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bgw5EyRl.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/bank-feeds",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-D0u3H3tS.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-B-OC1eMW.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-BskEv8Am.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D0u3H3tS.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-connections",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/serials",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-b773BydI.js",
			"/assets/log-out-D9q52Kcq.js",
			"/assets/testers.functions-DY9IQkcl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-DSjM2BnK.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-BcD7sPz0.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-9sYHO3zj.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/dist-RvtX-zf3.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/dist-C9_sT-Ox.js",
			"/assets/dialog-Boj9Ego9.js",
			"/assets/queries-Dk2GHkbD.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/label-DoaLrx6I.js",
			"/assets/textarea-CAMO60kj.js",
			"/assets/shoebox-B1tBR1Vk.js",
			"/assets/company-DIhND2xn.js",
			"/assets/reports-BzYfLwy4.js",
			"/assets/access-BWp1DMKl.js",
			"/assets/LicenseCard-BDDGy9Jg.js",
			"/assets/Logo-F6Bn0VDI.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CubC3xQN.js",
			"/assets/log-out-D9q52Kcq.js",
			"/assets/admin.functions-BjUBWtSJ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-F6Bn0VDI.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-KFj0KX8v.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/label-DoaLrx6I.js",
			"/assets/Logo-F6Bn0VDI.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-MZvLnjEv.js",
			"/assets/testers.functions-DY9IQkcl.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/buy.functions-BXsbPX7W.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DmXDfutI.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/downloads.functions-AuPMIRap.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-P7ab2qtf.js",
			"/assets/testers.functions-DY9IQkcl.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/textarea-CAMO60kj.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-C7smKt9J.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/label-DoaLrx6I.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BWpeS9pw.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/label-DoaLrx6I.js",
			"/assets/Logo-F6Bn0VDI.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BESPjckb.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/upgrade.functions-uobd-xaY.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-rhzqtBZ7.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/label-DoaLrx6I.js",
			"/assets/Logo-F6Bn0VDI.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-CaGtUr5S.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Cqo7juDr.js", "/assets/StockDocList-u2rQ7tlT.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-CylYimjM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/ai-uxPaYngc.js"
		]
	},
	"/_authenticated/bank-connections": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-connections.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-connections-CUAX0a-n.js",
			"/assets/BankConnections-PzE_F7Bg.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-rrLs7Nuv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-Bt5bn95a.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/BankConnections-PzE_F7Bg.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/ai-uxPaYngc.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-Dh1Cq_xk.js",
			"/assets/TxnEditor-DN7t57sO.js",
			"/assets/feedWaiting-Dgnfn41y.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-BiiWTrk5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-B-lL-CIO.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/personal-C893oxs4.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/WhoPicker-Cf2JUlp2.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-D-UsSWk8.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-BH2DUeoY.js", "/assets/AccountRegister-CZo60mdH.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-Y4QfdACI.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/categories-dEhQb4d5.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-C7bteYhP.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/money-DnY98We6.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-DdcOLLR2.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-uxPaYngc.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-B9KOXADv.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CiVbFSeT.js", "/assets/StockDocList-u2rQ7tlT.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-q5clAPy2.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-BrxM_1s8.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-zRbm1adH.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-DXM_G9Yo.js", "/assets/PartyList-DNy4PEjM.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-pBEhJWUE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-DmjtYI2h.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/storage.functions-CD36Cmat.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-CQTrp-Qd.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-d48021E7.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/PlCharts-ADro4_1F.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-Bs7SlsjB.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BMBIYrDE.js", "/assets/ChangeHistory-Q5XPKXo_.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-QEJwZr1a.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/members-ocdfRZ9L.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-hqu3Toim.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/personal-C893oxs4.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/WhoPicker-Cf2JUlp2.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-HRA2FNtV.js", "/assets/SalesList-C0t06dm4.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-2yN_w7p9.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-6wQoZaNX.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-CGKU29w_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-B4bvXjDT.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/loans-Dh1Cq_xk.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-fjfUStOV.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-CKy7B55L.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-BC1j7Rtv.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/personal-C893oxs4.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/WhoPicker-Cf2JUlp2.js",
			"/assets/reminders-CiMjccjV.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-BbIMmIQe.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-B7iE1rDO.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/personal-C893oxs4.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/WhoPicker-Cf2JUlp2.js",
			"/assets/generateCategoricalChart-DfvdV2mI.js",
			"/assets/Area-BPVG-kuH.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-DMsVJ-wj.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/generateCategoricalChart-DfvdV2mI.js",
			"/assets/PlCharts-ADro4_1F.js",
			"/assets/BarChart-47UAaL5f.js",
			"/assets/followups-ebMj4LTS.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-CwIck8WJ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DWimfh85.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-B9aNV4Sc.js",
			"/assets/createServerFn-DdCWP4bx.js",
			"/assets/auth-middleware-ChFZK_Dc.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/storage.functions-CD36Cmat.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-Bub7_4mt.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DvUg5xb0.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/eye-Cbs9C6DS.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/checkbox-DeKfoTFi.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-DjQEdxjp.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-9BDcJk0h.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-MXzjPrkj.js", "/assets/SalesList-C0t06dm4.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-BxuXR0vj.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/ai-uxPaYngc.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CD36Cmat.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-BbmTYzhB.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/money-DnY98We6.js",
			"/assets/badge-CJBrNH2g.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-BD5MBWq-.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-B-s8Zfjc.js", "/assets/AccountRegister-CZo60mdH.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BRuXPQWE.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/MoneyAccountPick-BTA3xa7b.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-BN0RDINt.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-hoEKsM6c.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/RepeatInvoice-By1sJfg1.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-Bsuhnkm4.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DfvdV2mI.js",
			"/assets/BarChart-47UAaL5f.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-B8kVv1RX.js", "/assets/SalesList-C0t06dm4.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-rt6TXngN.js", "/assets/SalesList-C0t06dm4.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-v1SI3kEl.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/serials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/serials.tsx",
		children: void 0,
		preloads: [
			"/assets/serials-CxeduxDF.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/serials-Pm06pmtH.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BxUSTGg2.js",
			"/assets/createServerFn-DdCWP4bx.js",
			"/assets/auth-middleware-ChFZK_Dc.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/emailWording-DyqXqwrF.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CXPiwOt9.js",
			"/assets/switch-CKy7B55L.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/QuickBooksImport-zRbm1adH.js",
			"/assets/csv-DThz9D5k.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-CNxHG9l2.js",
			"/assets/footers-BYpuHKqi.js",
			"/assets/PrintFrame-Ck0SlZQe.js",
			"/assets/checkbox-DeKfoTFi.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-D7m97kYu.js",
			"/assets/FeaturePicker-CjuimETR.js",
			"/assets/support-C1g84UrU.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-D4FQRwuq.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/FeaturePicker-CjuimETR.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-CdKxnJsZ.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-C6XPYRF3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/photos-CNxHG9l2.js",
			"/assets/stockmove-CUzswMpj.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-BtiiRYRl.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/loans-Dh1Cq_xk.js",
			"/assets/feedWaiting-Dgnfn41y.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CD36Cmat.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-BXa_Rw9t.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/PrintFrame-Ck0SlZQe.js",
			"/assets/DocPdf-BCd4f0G5.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-2HqAOqPj.js",
			"/assets/createServerFn-DdCWP4bx.js",
			"/assets/auth-middleware-ChFZK_Dc.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/MoneyAccountPick-BTA3xa7b.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C1g84UrU.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-7TBsSoM8.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/StockDialogs-C6XPYRF3.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/stockmove-CUzswMpj.js",
			"/assets/checkbox-DeKfoTFi.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BJiP_shW.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/members-ocdfRZ9L.js",
			"/assets/WhoPicker-Cf2JUlp2.js",
			"/assets/reminders-CiMjccjV.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DzrcY364.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/tickets.functions-DCnDuUVS.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-CD5Yikzf.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C1g84UrU.js",
			"/assets/support.functions-BSwnomH4.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-C0KnYpNl.js", "/assets/StockDocList-u2rQ7tlT.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CN5HYSZ3.js", "/assets/PartyList-DNy4PEjM.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-B64vELeb.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/tickets.functions-DCnDuUVS.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-DnhJeHng.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/workorders-CsL7WeGZ.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-Msnu0LQC.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-D7q6DTiA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/AdminAccount-CHSjC6Ov.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-DLXhE1hc.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/downloads.functions-AuPMIRap.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BRV0aIYL.js",
			"/assets/createServerFn-DdCWP4bx.js",
			"/assets/auth-middleware-ChFZK_Dc.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-CzXbbEIY.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-B8NPyto7.js",
			"/assets/testers.functions-DY9IQkcl.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-DiyWGof6.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-C-Q2F3Le.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-BXsbPX7W.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-i9illXPE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/textarea-CAMO60kj.js",
			"/assets/support.functions-BSwnomH4.js",
			"/assets/HelpParts-DqGuUfqd.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug--MW9g4AF.js",
			"/assets/ManualFrame-CTe33S-U.js",
			"/assets/manual._slug-Ynm5doPv.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-OLnyTbYa.js",
			"/assets/createServerFn-DdCWP4bx.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-sh2XIKLA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-uobd-xaY.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-CeY8kjGu.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/chart-line-ZnXNrHml.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/landmark-CUnqBx3K.js",
			"/assets/list-checks-DMQzEgC7.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-uxPaYngc.js",
			"/assets/personal-C893oxs4.js",
			"/assets/reminders-CiMjccjV.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin--8UgDoR_.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/AdminAccount-CHSjC6Ov.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-3UJth_gB.js", "/assets/ManualFrame-CTe33S-U.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D8GVGKuD.js", "/assets/AccountRegister-CZo60mdH.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CBwwBgkM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/OriginalLink-CpS1ZLQH.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/realestate-DzbXURHT.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-lOsleQ9Y.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-CMOFn_j5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/realestate-DzbXURHT.js",
			"/assets/money-DnY98We6.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-_1nRStKU.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/SideList-DAxi3ukH.js",
			"/assets/PartyHistory-MJxPEdrk.js",
			"/assets/tabs-CKgqjcjC.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-DDAWSXUu.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/emailWording-DyqXqwrF.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Q5XPKXo_.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/SideList-DAxi3ukH.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-CwHEjiYK.js",
			"/assets/MoneyAccountPick-BTA3xa7b.js",
			"/assets/footers-BYpuHKqi.js",
			"/assets/PrintFrame-Ck0SlZQe.js",
			"/assets/serials-Pm06pmtH.js",
			"/assets/SerialsBox-D1Ve4fV6.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-BxPKXz3E.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-C6XPYRF3.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Q5XPKXo_.js",
			"/assets/switch-CKy7B55L.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/categories-dEhQb4d5.js",
			"/assets/badge-CJBrNH2g.js",
			"/assets/SideList-DAxi3ukH.js",
			"/assets/tabs-CKgqjcjC.js",
			"/assets/photos-CNxHG9l2.js",
			"/assets/stockmove-CUzswMpj.js",
			"/assets/serials-Pm06pmtH.js",
			"/assets/SerialsBox-D1Ve4fV6.js",
			"/assets/workorders-CsL7WeGZ.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-CYm6hPvq.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/emailWording-DyqXqwrF.js",
			"/assets/scan-line-SUtkzhu9.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-Q5XPKXo_.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/SideList-DAxi3ukH.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-CwHEjiYK.js",
			"/assets/MoneyAccountPick-BTA3xa7b.js",
			"/assets/footers-BYpuHKqi.js",
			"/assets/PrintFrame-Ck0SlZQe.js",
			"/assets/checkbox-DeKfoTFi.js",
			"/assets/serials-Pm06pmtH.js",
			"/assets/workorders-CsL7WeGZ.js",
			"/assets/RepeatInvoice-By1sJfg1.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-DCnDuUVS.js",
			"/assets/users.functions-D7m97kYu.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-CikBGoZL.js",
			"/assets/select-DvDrTi4f.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/SideList-DAxi3ukH.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BUE4B1je.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/quickadd-3HqVqrT7.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-C1g84UrU.js",
			"/assets/support.functions-BSwnomH4.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-pnxW2qSq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-DRsA6MtL.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/SideList-DAxi3ukH.js",
			"/assets/PartyHistory-MJxPEdrk.js",
			"/assets/tabs-CKgqjcjC.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C3WMPH0k.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/sales-B9KOXADv.js",
			"/assets/footers-BYpuHKqi.js",
			"/assets/tickets.functions-DCnDuUVS.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-CNrP7wpa.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/input-kBrA2KXy.js",
			"/assets/skeleton-vx3Kxcad.js",
			"/assets/AdminAccount-CHSjC6Ov.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-SJCXhpOX.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-C8p9KpTH.js",
			"/assets/textarea-CAMO60kj.js",
			"/assets/support-C1g84UrU.js",
			"/assets/support.functions-BSwnomH4.js",
			"/assets/HelpParts-DqGuUfqd.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-k6L2olVc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-vx3Kxcad.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
