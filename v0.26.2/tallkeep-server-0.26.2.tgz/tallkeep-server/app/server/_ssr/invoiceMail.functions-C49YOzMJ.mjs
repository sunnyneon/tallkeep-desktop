import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { t as createServerRpc } from "./createServerRpc-BtWO3ciZ.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/invoiceMail.functions-C49YOzMJ.js
/** Send today's invoice emails and reminders now, for the company this person works in. */
var runInvoiceMailNow_createServerFn_handler = createServerRpc({
	id: "3fa78c0d4deecf4aa7060dfbd35fd6db8574d21f01040d6d7950d2bc21ca50f3",
	name: "runInvoiceMailNow",
	filename: "src/lib/invoiceMail.functions.ts"
}, (opts) => runInvoiceMailNow.__executeServer(opts));
var runInvoiceMailNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(runInvoiceMailNow_createServerFn_handler, async ({ context }) => {
	const { requireZone, activeCompany } = await import("./zone.server-JWxH1ixr.mjs");
	await requireZone(context.userId, ["Sales"], "sending invoice emails", context.supabase);
	const companyId = await activeCompany(context.supabase, true);
	const { runInvoiceMail } = await import("./invoiceMail.server-BebZNbAo.mjs");
	return runInvoiceMail({ companyId });
});
//#endregion
export { runInvoiceMailNow_createServerFn_handler };
