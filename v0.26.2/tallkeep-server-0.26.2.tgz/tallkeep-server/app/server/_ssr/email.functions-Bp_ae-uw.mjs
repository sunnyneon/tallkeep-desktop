import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B3nHhQ1h.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/email.functions-Bp_ae-uw.js
/** Emails a day for one company: free trial, and paid plans. Tallkeep's own account: no limit. */
/** Stop when the company has sent its emails for today; else count this one. */
/** Send a quote / invoice / PO as a PDF from the company (see mailer.server.ts). */
var sendDocEmail = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	const ok = (e) => /^\S+@\S+\.\S+$/.test(e);
	if (!d.to.length || !d.to.every(ok)) throw new Error("Type a valid email for the customer.");
	if (!d.cc.every(ok)) throw new Error("One of the copy addresses isn't a valid email.");
	if (d.to.length + d.cc.length > 10) throw new Error("Send to 10 addresses at most.");
	if (!d.pdfBase64) throw new Error("The PDF is missing.");
	if (d.pdfBase64.length > 14e6) throw new Error("The PDF is too big to email.");
	return d;
}).handler(createSsrRpc("a7f32f276406e2d7206bbca2e8c5fc871d65fb4425fcac828b84b5aae9eb123f"));
//#endregion
export { sendDocEmail as t };
