import { i as __toESM } from "../_runtime.mjs";
import { r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { supabaseAdmin } from "./client.server-KzwUIAkW.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/invoiceMail.server-BebZNbAo.js
var db = supabaseAdmin;
var today = () => process.env["TALLKEEP_DESKTOP"] === "1" ? (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA") : (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "America/Chicago" });
var daysBetween = (a, b) => Math.round((Date.parse(`${b}T12:00:00Z`) - Date.parse(`${a}T12:00:00Z`)) / 864e5);
/** The invoice as a PDF, the same as the one the app prints. */
async function invoicePdf(o, co) {
	const [{ data: lines }, { data: pays }, { data: term }] = await Promise.all([
		db.from("sales_order_lines").select("*").eq("sales_order_id", o.id).order("line_no"),
		db.from("payments").select("*").eq("sales_order_id", o.id).order("paid_on"),
		o.payment_terms_id ? db.from("payment_terms").select("name").eq("id", o.payment_terms_id).maybeSingle() : Promise.resolve({ data: null })
	]);
	let logo = "";
	if (co.logo_path && !co.logo_path.startsWith("/")) {
		const { data: s } = await db.storage.from("product-photos").createSignedUrl(co.logo_path, 600);
		logo = s?.signedUrl ?? "";
	}
	const { salesPdf } = await import("./salesPdf-DRzu8nfF.mjs");
	const { DocPdf } = await import("./DocPdf-D9IQazty.mjs").then((n) => n.t).then((n) => n.t);
	const { renderToBuffer } = await import("../_libs/react-pdf__renderer.mjs").then((n) => n.n);
	const { createElement } = await import("../_libs/@floating-ui/react-dom+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.u()));
	const d = salesPdf(o, lines ?? [], {
		name: co.name ?? "",
		address: co.address ?? null,
		mailing_address: co.mailing_address ?? null,
		phone: co.phone ?? null,
		email: co.email ?? null,
		website: co.website ?? null,
		quote_footer: co.quote_footer ?? null,
		invoice_footer: co.invoice_footer ?? null
	}, logo, term?.name, pays ?? [], o.pay_url ? { payUrl: o.pay_url } : {});
	let buf;
	try {
		buf = await renderToBuffer(createElement(DocPdf, { d }));
	} catch {
		buf = await renderToBuffer(createElement(DocPdf, { d: {
			...d,
			logo: ""
		} }));
	}
	return buf.toString("base64");
}
/** The invoice written out, for an email without the PDF. */
async function invoiceText(o) {
	const { data } = await db.from("sales_order_lines").select("description,qty,unit_price,discount,discount_is_percent").eq("sales_order_id", o.id).order("line_no");
	const { lineTotal } = await import("./sales-DLuHnKkT.mjs").then((n) => n.f).then((n) => n.f);
	const rows = (data ?? []).map((l) => `${Number(l.qty)} × ${l.description ?? ""}: ${fmtMoney(lineTotal(l))}`);
	return [
		`Invoice ${o.number}`,
		...rows,
		`Total: ${fmtMoney(o.total)}`,
		...Number(o.balance ?? o.total) !== Number(o.total) ? [`Still owed: ${fmtMoney(o.balance)}`] : [],
		...o.due_date ? [`Due: ${fmtDate(o.due_date)}`] : []
	].join("\n");
}
async function customerEmail(o) {
	if (o.email && /\S+@\S+\.\S+/.test(o.email)) return o.email.split(/[,;\s]+/).filter(Boolean);
	if (!o.customer_id) return [];
	const { data } = await db.from("customers").select("email").eq("id", o.customer_id).maybeSingle();
	const e = data?.email ?? "";
	return e ? e.split(/[,;\s]+/).filter(Boolean) : [];
}
/** Send one invoice email and write it down. False if it didn't go. */
async function sendOne(o, co, kind, step, subject, text) {
	const to = await customerEmail(o);
	const log = async (ok, why) => db.from("invoice_emails").insert({
		company_id: o.company_id,
		sales_order_id: o.id,
		kind,
		step,
		to_email: to.join(", ") || null,
		ok,
		why: why || null
	});
	if (!to.length) {
		await log(false, "There's no email address for this customer.");
		return {
			ok: false,
			why: "no email address",
			to: ""
		};
	}
	try {
		let pdf = "";
		try {
			pdf = await invoicePdf(o, co);
		} catch (e) {
			console.error("[invoice-mail] pdf", e.message);
		}
		const body = pdf ? text : `${text}\n\n${await invoiceText(o)}`;
		const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
		const r = await deliver({
			fromName: (co.email_from_name || co.name || "").trim(),
			to,
			replyTo: co.email_reply_to || co.email || null,
			subject,
			text: body.replace(/A copy is attached\./, pdf ? "A copy is attached." : "The invoice is below."),
			...pdf ? { attachments: [{
				filename: `Invoice ${o.number}.pdf`,
				content: pdf
			}] } : {}
		});
		const { error } = await log(r.ok, r.ok ? "" : r.why);
		if (error && r.ok) console.error("[invoice-mail] log", error.message);
		return {
			ok: r.ok,
			why: r.why,
			to: to.join(", ")
		};
	} catch (e) {
		await log(false, e.message);
		return {
			ok: false,
			why: e.message,
			to: to.join(", ")
		};
	}
}
var hello = (o) => {
	const n = (o.contact_name ?? "").trim();
	if (!n) return "Hello,";
	const first = n.split(/\s+/)[0];
	return `Hello ${/\.$|^(mr|mrs|ms|miss|dr)$/i.test(first) ? n : first},`;
};
function newMessage(o, co) {
	const lines = [
		hello(o),
		"",
		`Please find attached invoice ${o.number} for ${fmtMoney(o.total)}${o.due_date ? `, due ${fmtDate(o.due_date)}` : ""}.`
	];
	if (o.pay_url) lines.push("", `Pay online (card, Apple Pay or bank account): ${o.pay_url}`);
	lines.push("", "Thank you for your business!", "", co.name ?? "");
	return lines.join("\n");
}
function reminderMessage(o, co, late) {
	const lines = [
		hello(o),
		"",
		`A friendly reminder: invoice ${o.number} for ${fmtMoney(o.balance ?? o.total)} was due on ${fmtDate(o.due_date)} (${late} day${late === 1 ? "" : "s"} ago). A copy is attached.`
	];
	if (o.pay_url) lines.push("", `Pay online (card, Apple Pay or bank account): ${o.pay_url}`);
	if (co.reminder_note?.trim()) lines.push("", co.reminder_note.trim());
	lines.push("", "If you've already paid, thank you, and please ignore this email.", "", co.name ?? "");
	return lines.join("\n");
}
/** Which reminder an invoice is up to: the last step whose day has come (1-based), or 0. */
function reminderStep(days, late) {
	const sorted = [...new Set(days.filter((d) => d > 0))].sort((a, b) => a - b);
	let step = 0;
	sorted.forEach((d, i) => {
		if (late >= d) step = i + 1;
	});
	return step;
}
async function runForCompany(co, day) {
	const out = {
		invoices: 0,
		reminders: 0,
		failed: 0,
		skipped: false
	};
	const failures = [];
	const { data: reps } = await db.from("recurring").select("id").eq("company_id", co.company_id).eq("kind", "invoice").eq("email_customer", true);
	const repIds = (reps ?? []).map((r) => r.id);
	if (repIds.length) {
		const { data: made } = await db.from("sales_orders").select("*").in("recurring_id", repIds).in("status", ["invoiced", "paid"]).gte("recurring_date", daysAgo(day, 7)).lte("recurring_date", day);
		for (const o of made ?? []) {
			if (await already(o.id, "new", 0, day)) continue;
			const r = await sendOne(o, co, "new", 0, `Invoice ${o.number} from ${co.name ?? ""}`, newMessage(o, co));
			if (r.ok) out.invoices++;
			else {
				out.failed++;
				failures.push(`- ${o.number} · ${o.customer_name ?? ""}: ${r.why}`);
			}
		}
	}
	if (co.reminders_on) {
		const days = co.reminder_days?.length ? co.reminder_days : [
			3,
			10,
			30
		];
		let q = db.from("sales_orders").select("*").eq("company_id", co.company_id).eq("status", "invoiced").gt("balance", .009).not("due_date", "is", null).lt("due_date", `${day}T23:59:59`);
		if (co.reminders_from) q = q.gte("due_date", co.reminders_from);
		const { data: due } = await q.limit(2e3);
		const orders = due ?? [];
		const custIds = [...new Set(orders.map((o) => o.customer_id).filter(Boolean))];
		const { data: noRem } = custIds.length ? await db.from("customers").select("id").in("id", custIds).eq("no_reminders", true) : { data: [] };
		const skip = new Set((noRem ?? []).map((c) => c.id));
		for (const o of orders) {
			if (o.customer_id && skip.has(o.customer_id)) continue;
			const late = daysBetween(String(o.due_date).slice(0, 10), day);
			const step = reminderStep(days, late);
			if (!step) continue;
			const { data: sent } = await db.from("invoice_emails").select("step").eq("sales_order_id", o.id).eq("kind", "reminder").eq("ok", true).gte("step", step).limit(1);
			if ((sent ?? []).length) continue;
			if (await already(o.id, "reminder", step, day)) continue;
			const r = await sendOne(o, co, "reminder", step, `Reminder: invoice ${o.number} is past due`, reminderMessage(o, co, late));
			if (r.ok) out.reminders++;
			else {
				out.failed++;
				failures.push(`- ${o.number} · ${o.customer_name ?? ""}: ${r.why}`);
			}
		}
	}
	if ((out.invoices || out.reminders || out.failed) && co.email) {
		const lines = [`Invoice emails from ${co.name ?? "Tallkeep"} today:`, ""];
		if (out.invoices) lines.push(`${out.invoices} new invoice(s) emailed to customers.`);
		if (out.reminders) lines.push(`${out.reminders} overdue reminder(s) sent.`);
		if (failures.length) lines.push("", `These didn't go (Tallkeep tries again tomorrow):`, ...failures);
		const { deliver } = await import("./mailer.server-DR8PG4aY.mjs");
		await deliver({
			fromName: "Tallkeep",
			to: [co.email],
			subject: `Invoice emails today: ${out.invoices + out.reminders} sent${out.failed ? `, ${out.failed} didn't go` : ""}`,
			text: lines.join("\n")
		}).catch(() => null);
	}
	return out;
}
var daysAgo = (day, n) => (/* @__PURE__ */ new Date(Date.parse(`${day}T12:00:00Z`) - n * 864e5)).toISOString().slice(0, 10);
/** Sent already, or already tried (and failed) today: then wait for tomorrow. */
async function already(orderId, kind, step, day) {
	const { data } = await db.from("invoice_emails").select("ok, at").eq("sales_order_id", orderId).eq("kind", kind).eq("step", step);
	return (data ?? []).some((r) => r.ok || String(r.at).slice(0, 10) >= daysAgo(day, 0));
}
/** The daily job: for every company, or just one (Send now in Settings). */
async function runInvoiceMail(opts = {}) {
	let q = db.from("company_settings").select("*");
	if (opts.companyId) q = q.eq("company_id", opts.companyId);
	const { data, error } = await q;
	if (error) throw new Error(error.message);
	const day = opts.day ?? today();
	const total = {
		invoices: 0,
		reminders: 0,
		failed: 0,
		skipped: true
	};
	for (const co of data ?? []) try {
		const r = await runForCompany(co, day);
		total.invoices += r.invoices;
		total.reminders += r.reminders;
		total.failed += r.failed;
		total.skipped = false;
	} catch (e) {
		console.error("[invoice-mail]", co.company_id, e);
	}
	return total;
}
//#endregion
export { runInvoiceMail };
