import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/tickets_._id-C97b-AyD.js
var $$splitComponentImporter = () => import("./tickets_._id-lRO5juL_.mjs");
var Route = createFileRoute("/_authenticated/tickets_/$id")({
	head: () => ({ meta: [{ title: "Ticket · Tallkeep" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
