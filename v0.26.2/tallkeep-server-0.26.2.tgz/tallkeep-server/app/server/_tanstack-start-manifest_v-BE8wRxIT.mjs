//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BE8wRxIT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/invoice-emails",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-RzguTDrx.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bw20J02D.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuWl1-_-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-RzguTDrx.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/history",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/repeating",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-BTgNVNlV.js",
			"/assets/log-out-D3a4l1GN.js",
			"/assets/testers.functions-C53em2yM.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-BOCHCs9D.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-Csmevcuz.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-uLZGrQJz.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/dist-ClkebfEi.js",
			"/assets/dialog-DYE3ApXp.js",
			"/assets/queries-CoTwIZGh.js",
			"/assets/input-CpypSEol.js",
			"/assets/label-2h5jHB29.js",
			"/assets/textarea-CjwXRLp1.js",
			"/assets/shoebox-GgrxLIq9.js",
			"/assets/company-Cd9rtgpE.js",
			"/assets/reports-DU1m_pTa.js",
			"/assets/access-n-RMpd0n.js",
			"/assets/LicenseCard-eT7C9tbG.js",
			"/assets/Logo-I5ASnnY_.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-CO79_Lv1.js",
			"/assets/log-out-D3a4l1GN.js",
			"/assets/admin.functions-7DaXQXi4.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-I5ASnnY_.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-DPYFCP3_.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/label-2h5jHB29.js",
			"/assets/Logo-I5ASnnY_.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-Cks0BHlT.js",
			"/assets/testers.functions-C53em2yM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/buy.functions-B0v9C7Gm.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-DhKXx-wQ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/downloads.functions-CvLkxE3z.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-DI3j9PaN.js",
			"/assets/testers.functions-C53em2yM.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/textarea-CjwXRLp1.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-CQ6CwP7m.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/label-2h5jHB29.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-DwPr8hBi.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/label-2h5jHB29.js",
			"/assets/Logo-I5ASnnY_.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-SdRJnwKE.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/upgrade.functions-D_HF8UiR.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-CKmdaNtG.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/label-2h5jHB29.js",
			"/assets/Logo-I5ASnnY_.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-C6-_ZbYh.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-DsyBLzIt.js", "/assets/StockDocList-BWH2Ym0G.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-Ch5h7ECJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/ai-DWC6xD_x.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CwV2VHmF.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DABkrDaJ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/ai-DWC6xD_x.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/TxnEditor-z-n12Pcn.js",
			"/assets/feedWaiting-DLL1S0nn.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-C1FFxktX.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-ns5RhCD2.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-qXbhhDFW.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-C1_nHDay.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-C1YJa_JG.js", "/assets/AccountRegister-Gefd9BtY.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-CGq6G0Pc.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CyUNvoXy.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-fKOSlDD_.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DWC6xD_x.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-D0gD1-Vz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-Dn1jFoV7.js", "/assets/StockDocList-BWH2Ym0G.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-D0n9KnkY.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-Bj230dKE.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-B_RXn7CN.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-SNJM7GL4.js", "/assets/PartyList-PsKAEaKh.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-DDQ_IH18.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-By-3gBb6.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/storage.functions-CdV6HP9H.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-DlIRlDYv.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-DqeEPxty.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-0xZiRCt6.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/history": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/history.tsx",
		children: void 0,
		preloads: ["/assets/history-BzpjBKaB.js", "/assets/ChangeHistory-DitVgoQS.js"]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-BFHQ1Iug.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/members-B1ktLCoR.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-Ze7VQ2Un.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-qXbhhDFW.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-BXTLPt46.js", "/assets/SalesList-Bt9mha6p.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-C_hAX9mU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-Bz7-aMv1.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-7KKlpit8.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-CW6I16_d.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/loans-DlX_C_YK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-D07E_yCn.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-hsu8okQo.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-CQMjnYsJ.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-qXbhhDFW.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-DtTbEE_Q.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-CXdArFh4.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-qXbhhDFW.js",
			"/assets/generateCategoricalChart-CvoiZiWH.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-vCOrl26r.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-CvoiZiWH.js",
			"/assets/BarChart-4XCEtygY.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-mjDGl-FV.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-DFopjBwk.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-6lI0O9XF.js",
			"/assets/createServerFn-CggAK9Vt.js",
			"/assets/auth-middleware-B9ojWVz3.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/storage.functions-CdV6HP9H.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-RCFcLAKj.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-BjdXbfEg.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/checkbox-DGx08RLH.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-D3qMSXj_.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-Bfn94p3A.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-OMenBXBz.js", "/assets/SalesList-Bt9mha6p.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-D7A7XVmJ.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/ai-DWC6xD_x.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CdV6HP9H.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-CXltdjzz.js",
			"/assets/play-B3lrLyfe.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-HLF_1Nh9.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-CypO8ztL.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BvZ3C-tD.js", "/assets/AccountRegister-Gefd9BtY.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-XWmkjSD_.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/MoneyAccountPick-CxUZykk8.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-iCjbvYUk.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/repeating": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/repeating.tsx",
		children: void 0,
		preloads: [
			"/assets/repeating-BGOsRhzQ.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/RepeatInvoice-BxpNlGYa.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DKeVzYK2.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-CvoiZiWH.js",
			"/assets/BarChart-4XCEtygY.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-DhpUPtV7.js", "/assets/SalesList-Bt9mha6p.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-jybhOxUf.js", "/assets/SalesList-Bt9mha6p.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Df3xqBjO.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BDc4K47P.js",
			"/assets/createServerFn-CggAK9Vt.js",
			"/assets/auth-middleware-B9ojWVz3.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-DulbGtw5.js",
			"/assets/send-BwSadvej.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/dist-CykcFPlE.js",
			"/assets/switch-hsu8okQo.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/QuickBooksImport-B_RXn7CN.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-DGx08RLH.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-DBxFyXW-.js",
			"/assets/FeaturePicker-DikXuvih.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-B-ZEsCER.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/FeaturePicker-DikXuvih.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BlYqHkaC.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-B5zITPiu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-DCmJWp0c.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/feedWaiting-DLL1S0nn.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CdV6HP9H.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-CVWWfegV.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/DocPdf-D1JlXFub.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-7cgz58Id.js",
			"/assets/createServerFn-CggAK9Vt.js",
			"/assets/auth-middleware-B9ojWVz3.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/MoneyAccountPick-CxUZykk8.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-DObe9QLB.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/StockDialogs-B5zITPiu.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/checkbox-DGx08RLH.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-XfOwkKSt.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-qXbhhDFW.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DpQFwBmP.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/tickets.functions-C-gp9rWX.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DTmCXaD3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CgWLeBdg.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-CdbCCnO9.js", "/assets/StockDocList-BWH2Ym0G.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-CD2MkLoa.js", "/assets/PartyList-PsKAEaKh.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-BHP_WZyE.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/tickets.functions-C-gp9rWX.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-QVJlGTYs.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-B96uTKeA.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-Y_S8n0eE.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/AdminAccount-D1VUS8oy.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-BA418TSF.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/downloads.functions-CvLkxE3z.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-BYOWPERj.js",
			"/assets/createServerFn-CggAK9Vt.js",
			"/assets/auth-middleware-B9ojWVz3.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-DUpRidon.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-fbxmDrOZ.js",
			"/assets/testers.functions-C53em2yM.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-CHh9Sm7H.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-TWG20q8i.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-B0v9C7Gm.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DNSkU1sC.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/textarea-CjwXRLp1.js",
			"/assets/support.functions-CgWLeBdg.js",
			"/assets/HelpParts-CM-FnM9_.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BIM22lpD.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-BiF3KB48.js",
			"/assets/manual._slug-YSUPVIV1.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-49GmeyVs.js",
			"/assets/createServerFn-CggAK9Vt.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/clock-BlNsxegI.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-Nka_-2ZT.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-D_HF8UiR.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BTdN9f-t.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-DWC6xD_x.js",
			"/assets/personal-DMq024VV.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BnJlBsUG.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/AdminAccount-D1VUS8oy.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-BRhssYmO.js", "/assets/ManualFrame-BiF3KB48.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-B2J3Qv9F.js", "/assets/AccountRegister-Gefd9BtY.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-B1CZJWCV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/OriginalLink-IZXufAAl.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-CcFxAM-U.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-XuRTct_W.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-nclAgnM5.js",
			"/assets/PartyHistory-BgtC2lx-.js",
			"/assets/tabs-C46UqsQ9.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-C1xWL1lZ.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-DulbGtw5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DitVgoQS.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-nclAgnM5.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-JV2WNYwv.js",
			"/assets/MoneyAccountPick-CxUZykk8.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-DhOiavOv.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-B5zITPiu.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DitVgoQS.js",
			"/assets/switch-hsu8okQo.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/badge-HLF_1Nh9.js",
			"/assets/SideList-nclAgnM5.js",
			"/assets/tabs-C46UqsQ9.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-C0sQDh5q.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/file-check-corner-BF6TQ85Y.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-DulbGtw5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/truck-BkaNZLh2.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ChangeHistory-DitVgoQS.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-nclAgnM5.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-JV2WNYwv.js",
			"/assets/MoneyAccountPick-CxUZykk8.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-DGx08RLH.js",
			"/assets/workorders-CiTNPjMt.js",
			"/assets/RepeatInvoice-BxpNlGYa.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-C-gp9rWX.js",
			"/assets/users.functions-DBxFyXW-.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-lt-5Rmj9.js",
			"/assets/select-Bi6hxa50.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-nclAgnM5.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-ChQhNldr.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/send-BwSadvej.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CgWLeBdg.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-B42lzglw.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-BS4gThlp.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/SideList-nclAgnM5.js",
			"/assets/PartyHistory-BgtC2lx-.js",
			"/assets/tabs-C46UqsQ9.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-BCeKyWcF.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/footers-C066M_rV.js",
			"/assets/tickets.functions-C-gp9rWX.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-DOw8-TTC.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/input-CpypSEol.js",
			"/assets/skeleton-DHdUIGMY.js",
			"/assets/AdminAccount-D1VUS8oy.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-BG42HfS-.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-C2wKmCYZ.js",
			"/assets/textarea-CjwXRLp1.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-CgWLeBdg.js",
			"/assets/HelpParts-CM-FnM9_.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-C-ciYjxk.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-DHdUIGMY.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
