import { t as AI_PROVIDERS } from "./ai-BI7o6dZQ.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-VDuM5I42.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/ai.functions-CUv1c4hl.js
/** What this company's AI looks like right now (never the key itself). */
var aiStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("eb2ee64070a95f5ca231302b02ebc4033bc4338affec0d905e7b745c92a76c32"));
/** Choose the AI for this company. Admins or staff with the Accounting section. */
var aiSave = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!(d.provider in AI_PROVIDERS)) throw new Error("Unknown AI.");
	if (d.cap != null && !(d.cap >= 0)) throw new Error("The monthly limit must be 0 or more.");
	if (d.key && d.key.length > 400) throw new Error("That key is too long.");
	return d;
}).handler(createSsrRpc("cf6f48d63d7d776519762389066263927129c6ba829b48eeab381d2ca77616fa"));
var PROMPTS = {
	sort: `You sort business and household paperwork. Look at the first page(s) and say what it is,
and read the key facts. Return JSON only:
{"kind":"bank_statement"|"card_statement"|"loan_statement"|"receipt"|"bill"|"check"|"other",
 "issuer":"bank, card company, store or vendor name"|null,
 "account_last4":"last 4 digits of the bank or card account on a statement"|null,
 "period_end":"YYYY-MM-DD"|null,
 "vendor":"…"|null,"date":"YYYY-MM-DD"|null,"due_date":"YYYY-MM-DD"|null,"total":number|null,
 "tax":number|null,"bill_number":"…"|null,"category":"short guess like Supplies, Utilities, Rent"|null,
 "payer":"…"|null,"amount":number|null,"check_number":"…"|null,"memo":"…"|null,
 "loan_kind":"mortgage"|"car"|"student"|"personal"|"heloc"|"other"|null,
 "payment":number|null,"principal":number|null,"interest":number|null,"escrow":number|null,
 "fees":number|null,"balance":number|null,"rate":number|null,
 "description":"one short line saying what it is"}
kind: bank_statement = a bank account statement with many transactions; card_statement = a credit
card statement; receipt = proof of something already paid (store or online receipt, paid
invoice); bill = an invoice or bill that still has to be paid (shows an amount due or a due date);
check = a paper check someone wrote to this business; loan_statement = a monthly mortgage, car
loan, student loan, personal loan or home equity statement from a lender; other = anything else.
For a loan_statement: issuer = the lender (servicer) name as printed; account_last4 = last 4 of
the loan number; period_end = the statement date; due_date = when the payment is due;
payment = the regular monthly payment (not past-due amounts); principal, interest, escrow (taxes
and insurance) and fees = how this payment splits; balance = the unpaid principal balance;
rate = the interest rate in percent (4.625 for 4.625%).
total = the amount paid (receipt) or the amount due (bill). Never return full account, card or
routing numbers: only the last 4 digits.`,
	statement: `You read bank and credit card statements. Return JSON only:
{"account_kind":"bank"|"credit_card","period_end":"YYYY-MM-DD"|null,"ending_balance":number|null,
 "lines":[{"date":"YYYY-MM-DD","description":"…","amount":number,"ref":"check number or null"}]}
Rules: one entry per transaction line, in statement order. Money INTO the account is positive,
money OUT is negative (for a credit card: purchases and fees negative, payments and refunds
positive). Skip balances, subtotals, headers and summaries. Use the statement's year for dates.
Copy descriptions as printed (no card numbers).`,
	receipt: `You read store receipts and vendor invoices. Return JSON only:
{"vendor":"…"|null,"date":"YYYY-MM-DD"|null,"total":number|null,"tax":number|null,
 "payment":"card"|"cash"|"check"|"other"|null,"card_last4":"1234"|null,
 "category":"short guess like Supplies, Fuel, Meals, Repairs"|null,"items":"one short line"|null}
total = the amount actually paid, including tax and tip.`,
	check: `You read a paper check that a business RECEIVED from its customer. Return JSON only:
{"payer":"…"|null,"amount":number|null,"date":"YYYY-MM-DD"|null,"check_number":"…"|null,
 "memo":"…"|null,"bank":"…"|null}
payer = the person or company that wrote the check (printed top left), not the bank and not who it
is paid to. amount = the number in the amount box. check_number = the number at the top right.
memo = the memo line, often an invoice number. Never return account or routing numbers.`
};
/** Pages the built-in AI may read in a month during the free trial (online). */
/** Stop when the account's built-in AI pages for this month are used up. */
/** Read statement pages or a receipt with AI. Logs the use; stops at the monthly limit. */
var aiRead = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!PROMPTS[d.feature]) throw new Error("Unknown job.");
	if (!d.images.length) throw new Error("Nothing to read.");
	if (d.images.length > 12) throw new Error("Too many pages at once (12 at most).");
	if (d.hint && d.hint.length > 2e3) throw new Error("The note for the AI is too long.");
	if (d.images.reduce((t, i) => t + i.length, 0) > 18e6) throw new Error("These pages are too big. Try fewer pages at a time.");
	if (!d.images.every((i) => /^data:image\/(jpeg|png|webp);base64,/.test(i))) throw new Error("Pages must be images.");
	return d;
}).handler(createSsrRpc("add849362d949ebbc4eb83205c60058bb0fff83a0b7d10809a072293a387221a"));
//#endregion
export { aiSave as n, aiStatus as r, aiRead as t };
