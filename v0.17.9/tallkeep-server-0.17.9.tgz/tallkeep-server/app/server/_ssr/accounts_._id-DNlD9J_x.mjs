import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route } from "./accounts_._id-drDbKjL7.mjs";
import { t as AccountRegister } from "./AccountRegister-Bjp060cU.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/accounts_._id-DNlD9J_x.js
var import_jsx_runtime = require_jsx_runtime();
function Register() {
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRegister, {
		accountId: id,
		kind: "any",
		start: {
			...search.from ? { from: search.from } : {},
			...search.to ? { to: search.to } : {}
		},
		onAccount: (next) => next === "all" ? void navigate({
			to: "/register",
			search: { account: "all" }
		}) : void navigate({
			to: "/accounts/$id",
			params: { id: next },
			search: {}
		})
	});
}
//#endregion
export { Register as component };
