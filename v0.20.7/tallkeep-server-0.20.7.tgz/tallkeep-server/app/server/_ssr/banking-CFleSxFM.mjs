import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/banking-CFleSxFM.js
var $$splitComponentImporter = () => import("./banking-D_MLY3UL.mjs");
var Route = createFileRoute("/_authenticated/banking")({
	validateSearch: (s) => ({
		...typeof s["account"] === "string" ? { account: s["account"] } : {},
		...s["tab"] === "reconcile" || s["tab"] === "done" ? { tab: s["tab"] } : {}
	}),
	head: () => ({ meta: [{ title: "Banking · Tallkeep" }, {
		name: "description",
		content: "Bank and credit card statements: match, add and reconcile."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
