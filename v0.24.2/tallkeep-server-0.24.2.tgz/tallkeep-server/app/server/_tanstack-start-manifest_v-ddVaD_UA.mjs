//#region ../../node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-ddVaD_UA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/__root.tsx",
		children: [
			"/_authenticated",
			"/admin",
			"/auth",
			"/buy",
			"/download",
			"/early-access",
			"/reset-password",
			"/signup",
			"/testers",
			"/upgrade",
			"/welcome",
			"/buy_/done",
			"/help/$slug",
			"/manual/$slug",
			"/pay/$token",
			"/upgrade_/done",
			"/help/",
			"/manual/",
			"/api/public/connect-api",
			"/api/public/download",
			"/api/public/help-file",
			"/api/public/install-ping",
			"/api/public/license-check",
			"/api/public/pay-api",
			"/api/public/prices",
			"/api/public/report",
			"/api/public/stay-calendar",
			"/api/public/stripe-oauth",
			"/api/public/stripe-webhook",
			"/api/public/unsubscribe",
			"/help/t/$key",
			"/api/public/cron/daily-rent",
			"/api/public/cron/nightly-backup",
			"/api/public/cron/quote-followups",
			"/api/public/cron/trial-emails",
			"/api/public/office/backup-latest"
		],
		preloads: [
			"/assets/index-BJdxR8of.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-Csno6YYW.js",
			"/assets/useRouter-BGpAXxmD.js",
			"/assets/client-Bw20J02D.js",
			"/assets/useQuery-8nhBZsKX.js",
			"/assets/db-CuWl1-_-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BJdxR8of.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/accounts",
			"/_authenticated/adjust",
			"/_authenticated/ai",
			"/_authenticated/bank-transfers",
			"/_authenticated/banking",
			"/_authenticated/bills",
			"/_authenticated/budget",
			"/_authenticated/calendar",
			"/_authenticated/card-register",
			"/_authenticated/categories",
			"/_authenticated/checks",
			"/_authenticated/checks-received",
			"/_authenticated/count",
			"/_authenticated/credit-cards",
			"/_authenticated/crypto-tax",
			"/_authenticated/customers",
			"/_authenticated/deposits",
			"/_authenticated/documents",
			"/_authenticated/fast-entry",
			"/_authenticated/financials",
			"/_authenticated/forms-1099",
			"/_authenticated/household",
			"/_authenticated/investments",
			"/_authenticated/invoices",
			"/_authenticated/journal",
			"/_authenticated/labels",
			"/_authenticated/leases",
			"/_authenticated/loans",
			"/_authenticated/locations",
			"/_authenticated/monthly-review",
			"/_authenticated/movements",
			"/_authenticated/net-worth",
			"/_authenticated/new-invoice",
			"/_authenticated/new-quote",
			"/_authenticated/overview",
			"/_authenticated/pay-bills",
			"/_authenticated/payroll",
			"/_authenticated/plan",
			"/_authenticated/print-checks",
			"/_authenticated/products",
			"/_authenticated/properties",
			"/_authenticated/purchase-orders",
			"/_authenticated/quotes",
			"/_authenticated/receipts",
			"/_authenticated/recurring",
			"/_authenticated/refunds",
			"/_authenticated/register",
			"/_authenticated/rent",
			"/_authenticated/rent-roll",
			"/_authenticated/reports",
			"/_authenticated/rma",
			"/_authenticated/sales-list",
			"/_authenticated/sales-orders",
			"/_authenticated/sales-receipt",
			"/_authenticated/sales-tax",
			"/_authenticated/settings",
			"/_authenticated/setup-company",
			"/_authenticated/shelve",
			"/_authenticated/shoebox",
			"/_authenticated/statements",
			"/_authenticated/stays",
			"/_authenticated/stock",
			"/_authenticated/subscriptions",
			"/_authenticated/tech-pay",
			"/_authenticated/tickets",
			"/_authenticated/transfer",
			"/_authenticated/vendors",
			"/_authenticated/website-tickets",
			"/_authenticated/work-orders",
			"/_authenticated/year-end",
			"/_authenticated/",
			"/_authenticated/accounts_/$id",
			"/_authenticated/bills_/$id",
			"/_authenticated/checks_/$id",
			"/_authenticated/customers_/$id",
			"/_authenticated/po/$id",
			"/_authenticated/products_/$id",
			"/_authenticated/sales/$id",
			"/_authenticated/stock-doc/$id",
			"/_authenticated/tickets_/$id",
			"/_authenticated/vendors_/$id",
			"/_authenticated/website-tickets_/$id",
			"/_authenticated/go/$kind/$id"
		],
		preloads: [
			"/assets/route-nzOjlTN9.js",
			"/assets/log-out-DCMajZZT.js",
			"/assets/testers.functions-BmNXz2On.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/nav-D3_fXLpI.js",
			"/assets/ban-LJUhgKvB.js",
			"/assets/chevron-down-DxUrtHFo.js",
			"/assets/SearchSelect-DgA1Pvlu.js",
			"/assets/circle-question-mark-CW6ozlIb.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/image-plus-DR9qwBjL.js",
			"/assets/inbox-Dl262yo-.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/ScanAdd-C9MkloZR.js",
			"/assets/search-BtJsgOj6.js",
			"/assets/sparkles-DZ5Pl1vD.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/queries-CoTwIZGh.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/label-Bdbn77Ur.js",
			"/assets/textarea-CJwNT_EP.js",
			"/assets/dist-Dy_5Dewn.js",
			"/assets/dialog-BGkGDgcg.js",
			"/assets/shoebox-BFP81ESM.js",
			"/assets/company-DkFhFCR5.js",
			"/assets/reports-DU1m_pTa.js",
			"/assets/access-C5bLjGjo.js",
			"/assets/LicenseCard-V8yB7ZQt.js",
			"/assets/Logo-Dx2UTf0K.js"
		]
	},
	"/admin": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/route.tsx",
		children: [
			"/admin/customers",
			"/admin/downloads",
			"/admin/licenses",
			"/admin/prices",
			"/admin/testers",
			"/admin/waitlist",
			"/admin/",
			"/admin/customers_/$id"
		],
		preloads: [
			"/assets/route-f5HbzM_H.js",
			"/assets/log-out-DCMajZZT.js",
			"/assets/admin.functions-Yx-ROpvZ.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/users-D2taoQBY.js",
			"/assets/Logo-Dx2UTf0K.js"
		]
	},
	"/auth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-SX-o_Ut7.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/label-Bdbn77Ur.js",
			"/assets/Logo-Dx2UTf0K.js"
		]
	},
	"/buy": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy.tsx",
		children: void 0,
		preloads: [
			"/assets/buy-DCrsBjc4.js",
			"/assets/testers.functions-BmNXz2On.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/buy.functions-CEfoCF0G.js"
		]
	},
	"/download": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/download.tsx",
		children: void 0,
		preloads: [
			"/assets/download-B7nqfTMf.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/downloads.functions-RK0MecnB.js"
		]
	},
	"/early-access": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/early-access.tsx",
		children: void 0,
		preloads: [
			"/assets/early-access-BchCSNHj.js",
			"/assets/testers.functions-BmNXz2On.js",
			"/assets/createLucideIcon-CLdWFMku.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/textarea-CJwNT_EP.js"
		]
	},
	"/reset-password": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-t1QEPKiJ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/label-Bdbn77Ur.js"
		]
	},
	"/signup": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/signup.tsx",
		children: void 0,
		preloads: [
			"/assets/signup-BnGwE9kf.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/label-Bdbn77Ur.js",
			"/assets/Logo-Dx2UTf0K.js"
		]
	},
	"/upgrade": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade-BOmMmd-w.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/upgrade.functions-DWBqMcxY.js"
		]
	},
	"/welcome": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/welcome.tsx",
		children: void 0,
		preloads: [
			"/assets/welcome-Bs4_L9ai.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/label-Bdbn77Ur.js",
			"/assets/Logo-Dx2UTf0K.js"
		]
	},
	"/_authenticated/accounts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/accounts-QToF07bt.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/adjust": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/adjust.tsx",
		children: void 0,
		preloads: ["/assets/adjust-Dr4vprzt.js", "/assets/StockDocList-DLPLa9Us.js"]
	},
	"/_authenticated/ai": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/ai.tsx",
		children: void 0,
		preloads: [
			"/assets/ai-JN5gsRVP.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/ai-C3ZUejz4.js"
		]
	},
	"/_authenticated/bank-transfers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bank-transfers.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-transfers-CdF66Ggo.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js"
		]
	},
	"/_authenticated/banking": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/banking.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-C6-pYyOR.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/ai-C3ZUejz4.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/TxnEditor-BYlRMgHD.js",
			"/assets/feedWaiting-DLL1S0nn.js"
		]
	},
	"/_authenticated/bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills.tsx",
		children: void 0,
		preloads: [
			"/assets/bills-p3eYMMX7.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/budget": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/budget.tsx",
		children: void 0,
		preloads: [
			"/assets/budget-DNfCOCos.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/wand-sparkles-BI9D1HMk.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-DF9qYO3j.js"
		]
	},
	"/_authenticated/calendar": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/calendar.tsx",
		children: void 0,
		preloads: [
			"/assets/calendar-DBRYDCgT.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/card-register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/card-register.tsx",
		children: void 0,
		preloads: ["/assets/card-register-D_j9ksiM.js", "/assets/AccountRegister-ulq-DEMg.js"]
	},
	"/_authenticated/categories": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/categories.tsx",
		children: void 0,
		preloads: [
			"/assets/categories-D0UhkSSj.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js"
		]
	},
	"/_authenticated/checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-CbErQX-w.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/checks-received": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks-received.tsx",
		children: void 0,
		preloads: [
			"/assets/checks-received-BdGGGXlW.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-C3ZUejz4.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/sales-D0gD1-Vz.js"
		]
	},
	"/_authenticated/count": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/count.tsx",
		children: void 0,
		preloads: ["/assets/count-CMfTQM1j.js", "/assets/StockDocList-DLPLa9Us.js"]
	},
	"/_authenticated/credit-cards": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/credit-cards.tsx",
		children: void 0,
		preloads: [
			"/assets/credit-cards-B35TozNl.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/crypto-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/crypto-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/crypto-tax-cgbBBD9J.js",
			"/assets/check-36OnHiEM.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/QuickBooksImport-DjKjiTOO.js"
		]
	},
	"/_authenticated/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers.tsx",
		children: void 0,
		preloads: ["/assets/customers-BF3ivkOz.js", "/assets/PartyList-Dbbk9iYf.js"]
	},
	"/_authenticated/deposits": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/deposits.tsx",
		children: void 0,
		preloads: [
			"/assets/deposits-Cj85rGNb.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/documents": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/documents.tsx",
		children: void 0,
		preloads: [
			"/assets/documents-B913RRVg.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/storage.functions-CPgdcr-y.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/fast-entry": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/fast-entry.tsx",
		children: void 0,
		preloads: [
			"/assets/fast-entry-BJqa6LTt.js",
			"/assets/check-36OnHiEM.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/financials": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/financials.tsx",
		children: void 0,
		preloads: [
			"/assets/financials-aKKAvHwk.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/forms-1099": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/forms-1099.tsx",
		children: void 0,
		preloads: [
			"/assets/forms-1099-BZv_F3g4.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/household": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/household.tsx",
		children: void 0,
		preloads: [
			"/assets/household-CtLq0qMv.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/members-B1ktLCoR.js"
		]
	},
	"/_authenticated/investments": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/investments.tsx",
		children: void 0,
		preloads: [
			"/assets/investments-aVxA3rKF.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-DF9qYO3j.js"
		]
	},
	"/_authenticated/invoices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/invoices.tsx",
		children: void 0,
		preloads: ["/assets/invoices-CZR38Mlb.js", "/assets/SalesList-BtOq1m37.js"]
	},
	"/_authenticated/journal": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/journal.tsx",
		children: void 0,
		preloads: [
			"/assets/journal-DRq69Zn1.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/labels": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/labels.tsx",
		children: void 0,
		preloads: [
			"/assets/labels-CESfZ99D.js",
			"/assets/barcode-DMNyR0F0.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/leases": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/leases.tsx",
		children: void 0,
		preloads: [
			"/assets/leases-BA1xFdoI.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/loans": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/loans.tsx",
		children: void 0,
		preloads: [
			"/assets/loans-D2j6FJfM.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/loans-DlX_C_YK.js"
		]
	},
	"/_authenticated/locations": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/locations.tsx",
		children: void 0,
		preloads: [
			"/assets/locations-CArA5SDE.js",
			"/assets/map-pin-BupMBcH4.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-CjNbzYQp.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/monthly-review": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/monthly-review.tsx",
		children: void 0,
		preloads: [
			"/assets/monthly-review-qHwNb1RV.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-DF9qYO3j.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/movements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/movements.tsx",
		children: void 0,
		preloads: [
			"/assets/movements-B5oRedpY.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/_authenticated/net-worth": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/net-worth.tsx",
		children: void 0,
		preloads: [
			"/assets/net-worth-Bjq9PMPB.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/personal-DMq024VV.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-DF9qYO3j.js",
			"/assets/generateCategoricalChart-DqyfjeoR.js"
		]
	},
	"/_authenticated/overview": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/overview.tsx",
		children: void 0,
		preloads: [
			"/assets/overview-CJpsa2j-.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/generateCategoricalChart-DqyfjeoR.js",
			"/assets/BarChart-BYi70dIs.js"
		]
	},
	"/_authenticated/pay-bills": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/pay-bills.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-bills-jDRu0Dmy.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/payroll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/payroll.tsx",
		children: void 0,
		preloads: [
			"/assets/payroll-CMsDSkiJ.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/plan": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-B2cf_rDI.js",
			"/assets/createServerFn-GY53xhnE.js",
			"/assets/auth-middleware-CM6ro_pj.js",
			"/assets/check-36OnHiEM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/storage.functions-CPgdcr-y.js"
		]
	},
	"/_authenticated/print-checks": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/print-checks.tsx",
		children: void 0,
		preloads: [
			"/assets/print-checks-CT7Hq7EH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/products": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-C_6ZpJOv.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/badge-Q4yVPEA7.js",
			"/assets/checkbox-CUd9rHpq.js"
		]
	},
	"/_authenticated/properties": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/properties.tsx",
		children: void 0,
		preloads: [
			"/assets/properties-9cv9g4ZJ.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/house-DMC1VfUl.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/purchase-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/purchase-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/purchase-orders-mEA_IoXT.js",
			"/assets/arrow-down-up-CELI34d7.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js"
		]
	},
	"/_authenticated/quotes": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/quotes.tsx",
		children: void 0,
		preloads: ["/assets/quotes-B_0F4yyz.js", "/assets/SalesList-BtOq1m37.js"]
	},
	"/_authenticated/receipts": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-D6DxfdbJ.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/eye-off-DIe2-cve.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/ai-C3ZUejz4.js",
			"/assets/bankfile-DoOuU06O.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CPgdcr-y.js"
		]
	},
	"/_authenticated/recurring": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/recurring.tsx",
		children: void 0,
		preloads: [
			"/assets/recurring-wdlY28-D.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js",
			"/assets/badge-Q4yVPEA7.js"
		]
	},
	"/_authenticated/refunds": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/refunds.tsx",
		children: void 0,
		preloads: [
			"/assets/refunds-Igb8AwV7.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/register": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/register.tsx",
		children: void 0,
		preloads: ["/assets/register-BN2nvocc.js", "/assets/AccountRegister-ulq-DEMg.js"]
	},
	"/_authenticated/rent": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-BvSXRHlL.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-Q4yVPEA7.js",
			"/assets/MoneyAccountPick-B_ZHQnp4.js"
		]
	},
	"/_authenticated/rent-roll": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rent-roll.tsx",
		children: void 0,
		preloads: [
			"/assets/rent-roll-Bv8xau_1.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/reports.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CUvVJbIC.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/generateCategoricalChart-DqyfjeoR.js",
			"/assets/BarChart-BYi70dIs.js"
		]
	},
	"/_authenticated/rma": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/rma.tsx",
		children: void 0,
		preloads: ["/assets/rma-C7aaNpcw.js", "/assets/SalesList-BtOq1m37.js"]
	},
	"/_authenticated/sales-list": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-list.tsx",
		children: void 0,
		preloads: ["/assets/sales-list-Jphu1UpO.js", "/assets/SalesList-BtOq1m37.js"]
	},
	"/_authenticated/sales-tax": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales-tax.tsx",
		children: void 0,
		preloads: [
			"/assets/sales-tax-Bzon_5BI.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-B_R7Hz05.js",
			"/assets/createServerFn-GY53xhnE.js",
			"/assets/auth-middleware-CM6ro_pj.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/folder-open-EnSxr3iR.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/dist-CT9FqZPR.js",
			"/assets/dist-80T0YosZ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/QuickBooksImport-DjKjiTOO.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-CUd9rHpq.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/users.functions-Csjc_iC4.js",
			"/assets/FeaturePicker-s189Wi1Q.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/setup-company": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/setup-company.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-company-CjauXn3R.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/check-36OnHiEM.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/FeaturePicker-s189Wi1Q.js"
		]
	},
	"/_authenticated/shelve": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shelve.tsx",
		children: void 0,
		preloads: [
			"/assets/shelve-BaRExemX.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/check-36OnHiEM.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ChJ7WYud.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js"
		]
	},
	"/_authenticated/shoebox": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/shoebox.tsx",
		children: void 0,
		preloads: [
			"/assets/shoebox-CXj1rimA.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/loans-DlX_C_YK.js",
			"/assets/feedWaiting-DLL1S0nn.js",
			"/assets/scanQueue-tUCNVqIP.js",
			"/assets/storage.functions-CPgdcr-y.js"
		]
	},
	"/_authenticated/statements": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/statements.tsx",
		children: void 0,
		preloads: [
			"/assets/statements-Bv1lnjmq.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/DocPdf-DbnjSuJ2.js"
		]
	},
	"/_authenticated/stays": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stays.tsx",
		children: void 0,
		preloads: [
			"/assets/stays-Cjb1RyKO.js",
			"/assets/createServerFn-GY53xhnE.js",
			"/assets/auth-middleware-CM6ro_pj.js",
			"/assets/bed-double-CsD1bTJN.js",
			"/assets/chevron-left-BqXVpTN8.js",
			"/assets/chevron-right-CHJcvRU6.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-up-CLGI-fKs.js",
			"/assets/link-2-CjqR5iSM.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/refresh-cw-CHzni4H4.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickbooks-qXz68tRS.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/badge-Q4yVPEA7.js",
			"/assets/MoneyAccountPick-B_ZHQnp4.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js"
		]
	},
	"/_authenticated/stock": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-C_9w9_y4.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/StockDialogs-ChJ7WYud.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/checkbox-CUd9rHpq.js"
		]
	},
	"/_authenticated/subscriptions": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/subscriptions.tsx",
		children: void 0,
		preloads: [
			"/assets/subscriptions-BWPD86A2.js",
			"/assets/check-36OnHiEM.js",
			"/assets/pencil-CFgylVBP.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/members-B1ktLCoR.js",
			"/assets/WhoPicker-DF9qYO3j.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/_authenticated/tech-pay": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tech-pay.tsx",
		children: void 0,
		preloads: [
			"/assets/tech-pay-DrrGg_IE.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/tickets.functions-BFFFqRK7.js"
		]
	},
	"/_authenticated/tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets-DSN0Lu24.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-B3bzMI5V.js"
		]
	},
	"/_authenticated/transfer": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/transfer.tsx",
		children: void 0,
		preloads: ["/assets/transfer-2w2S_8ym.js", "/assets/StockDocList-DLPLa9Us.js"]
	},
	"/_authenticated/vendors": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors.tsx",
		children: void 0,
		preloads: ["/assets/vendors-D2fhPgif.js", "/assets/PartyList-Dbbk9iYf.js"]
	},
	"/_authenticated/website-tickets": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets-Bl1nKNlG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/tickets.functions-BFFFqRK7.js"
		]
	},
	"/_authenticated/work-orders": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/work-orders.tsx",
		children: void 0,
		preloads: [
			"/assets/work-orders-Dq6jf8BW.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/badge-Q4yVPEA7.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/year-end": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/year-end.tsx",
		children: void 0,
		preloads: [
			"/assets/year-end-tjantIJb.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/cryptotax-DKKJwsvj.js",
			"/assets/csv-DThz9D5k.js"
		]
	},
	"/admin/customers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-B7sDulxe.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/AdminAccount-DXeX0zSh.js"
		]
	},
	"/admin/downloads": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/downloads.tsx",
		children: void 0,
		preloads: [
			"/assets/downloads-U2UwlfAh.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/downloads.functions-RK0MecnB.js"
		]
	},
	"/admin/licenses": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/licenses.tsx",
		children: void 0,
		preloads: [
			"/assets/licenses-B8txQTe9.js",
			"/assets/createServerFn-GY53xhnE.js",
			"/assets/auth-middleware-CM6ro_pj.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/copy-Csr8bXBX.js"
		]
	},
	"/admin/prices": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/prices.tsx",
		children: void 0,
		preloads: [
			"/assets/prices-C2GUwG3d.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/admin/testers": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/testers.tsx",
		children: void 0,
		preloads: [
			"/assets/testers-BogkHnav.js",
			"/assets/testers.functions-BmNXz2On.js",
			"/assets/check-36OnHiEM.js",
			"/assets/external-link-BYVStqz6.js",
			"/assets/mail-Co1PkbeV.js",
			"/assets/triangle-alert-DvOHJyPM.js",
			"/assets/x-CGuQtexA.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/admin/waitlist": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/waitlist.tsx",
		children: void 0,
		preloads: [
			"/assets/waitlist-BctZyzLS.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/buy_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/buy_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/buy_.done-CTonSNti.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/download-CV6x-mg2.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/buy.functions-CEfoCF0G.js"
		]
	},
	"/help/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/help._slug-DJCdxgWx.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/textarea-CJwNT_EP.js",
			"/assets/support.functions-B3bzMI5V.js",
			"/assets/HelpParts-CNqpf7B_.js"
		]
	},
	"/manual/$slug": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/manual._slug-BAQeTBlX.js",
			"/assets/arrow-left-Bdt1PfM_.js",
			"/assets/ManualText-oWcD_ePT.js",
			"/assets/ManualFrame-DHsjn2bY.js",
			"/assets/manual._slug-BEMjaKGb.js"
		]
	},
	"/pay/$token": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/pay.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/pay._token-B9guebuW.js",
			"/assets/createServerFn-GY53xhnE.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/lock-CU0IKVqn.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/skeleton-CkvNen46.js"
		]
	},
	"/upgrade_/done": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/upgrade_.done.tsx",
		children: void 0,
		preloads: [
			"/assets/upgrade_.done-gFWQdDhT.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/upgrade.functions-DWBqMcxY.js"
		]
	},
	"/_authenticated/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-8ezBgepz.js",
			"/assets/arrow-right-D9dIjaq0.js",
			"/assets/layout-dashboard-NGoKoF77.js",
			"/assets/banknote-COLeVQ9z.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/landmark-CH0QNDlX.js",
			"/assets/check-36OnHiEM.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/package-D81yNTKQ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/house-plus-DUkRFhhU.js",
			"/assets/key-round-Bm1Lv5KH.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/scale-BjunWFVs.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/upload--8EEkrQJ.js",
			"/assets/users-D2taoQBY.js",
			"/assets/wallet-1QANwocZ.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/ai-C3ZUejz4.js",
			"/assets/personal-DMq024VV.js",
			"/assets/reminders-DBJqHnR3.js"
		]
	},
	"/admin/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-CMz1ixQn.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/AdminAccount-DXeX0zSh.js"
		]
	},
	"/manual/": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/manual.index.tsx",
		children: void 0,
		preloads: ["/assets/manual.index-LXQlYlej.js", "/assets/ManualFrame-DHsjn2bY.js"]
	},
	"/_authenticated/accounts_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/accounts_.$id.tsx",
		children: void 0,
		preloads: ["/assets/accounts_._id-D3H1dVNE.js", "/assets/AccountRegister-ulq-DEMg.js"]
	},
	"/_authenticated/bills_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/bills_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/bills_._id-CeE4vf5B.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/OriginalLink-DMyYzXB9.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/realestate-C9Tiuxab.js"
		]
	},
	"/_authenticated/checks_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/checks_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/checks_._id-o4Bzn-bX.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/repeat-ClE37JWw.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/accounting-5py-fNzG.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/realestate-C9Tiuxab.js",
			"/assets/money-CH9xjSUA.js"
		]
	},
	"/_authenticated/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-8BnC5Eze.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/sticky-BCLLcz8u.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-Ctn05V6G.js",
			"/assets/PartyHistory-D3mZgb3U.js",
			"/assets/tabs-BmkofWx9.js"
		]
	},
	"/_authenticated/po/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/po.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/po._id-CxuwzKd_.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-Ctn05V6G.js",
			"/assets/purchasing-DI1dCoNf.js",
			"/assets/NewProductDialog-D8ZrJtG-.js",
			"/assets/MoneyAccountPick-B_ZHQnp4.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js"
		]
	},
	"/_authenticated/products_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/products_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/products_._id-Dz5J5rMj.js",
			"/assets/camera-BFX8ak5t.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/clipboard-check-B5r6WK5-.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/image-off-CzzL32Pb.js",
			"/assets/StockDialogs-ChJ7WYud.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/shopping-cart-DkIj0NBD.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/switch-CjNbzYQp.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/badge-Q4yVPEA7.js",
			"/assets/SideList-Ctn05V6G.js",
			"/assets/tabs-BmkofWx9.js",
			"/assets/photos-DJpyezLe.js",
			"/assets/stockmove-4pnhALfB.js",
			"/assets/workorders-CiTNPjMt.js"
		]
	},
	"/_authenticated/sales/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/sales.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/sales._id-DVoQBQNd.js",
			"/assets/check-36OnHiEM.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/credit-card-CB39ehyq.js",
			"/assets/dollar-sign-DwIcqyqO.js",
			"/assets/truck-DXI15kxZ.js",
			"/assets/hammer-C8isJqNr.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/cardpay-qSaRmmtW.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/undo-2-CH8sxIQQ.js",
			"/assets/search-UFnbctRI.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-Ctn05V6G.js",
			"/assets/followups-ebMj4LTS.js",
			"/assets/NewProductDialog-D8ZrJtG-.js",
			"/assets/MoneyAccountPick-B_ZHQnp4.js",
			"/assets/footers-C066M_rV.js",
			"/assets/PrintFrame-BDo_gxJt.js",
			"/assets/checkbox-CUd9rHpq.js",
			"/assets/workorders-CiTNPjMt.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/tickets.functions-BFFFqRK7.js",
			"/assets/users.functions-Csjc_iC4.js"
		]
	},
	"/_authenticated/stock-doc/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/stock-doc.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/stock-doc._id-DglQ7obU.js",
			"/assets/select-DOTCTFeV.js",
			"/assets/circle-check-DjOsU-2G.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/printer-CYmIozLM.js",
			"/assets/trash-2-D9HI9O7Q.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/stockdocs-CwlU_2zQ.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/SideList-Ctn05V6G.js"
		]
	},
	"/_authenticated/tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/tickets_._id-BstYWd3O.js",
			"/assets/copy-B1k2VT2A.js",
			"/assets/file-text-BRzD_S8I.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/user-plus-NalbfaH2.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/quickadd-DdFcH8PN.js",
			"/assets/copy-Csr8bXBX.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-B3bzMI5V.js"
		]
	},
	"/_authenticated/vendors_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/vendors_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/vendors_._id-z_cxRxSB.js",
			"/assets/plus-qKI-KwZh.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/PartyForm-Cf6Jwg-l.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/SideList-Ctn05V6G.js",
			"/assets/PartyHistory-D3mZgb3U.js",
			"/assets/tabs-BmkofWx9.js"
		]
	},
	"/_authenticated/website-tickets_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/website-tickets_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/website-tickets_._id-C07iP_6d.js",
			"/assets/receipt-B12F5qyU.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/sales-D0gD1-Vz.js",
			"/assets/footers-C066M_rV.js",
			"/assets/tickets.functions-BFFFqRK7.js"
		]
	},
	"/admin/customers_/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/admin/customers_.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/customers_._id-C0zD5A4L.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/input-BKrg06Zz.js",
			"/assets/skeleton-CkvNen46.js",
			"/assets/AdminAccount-DXeX0zSh.js"
		]
	},
	"/help/t/$key": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/help.t.$key.tsx",
		children: void 0,
		preloads: [
			"/assets/help.t._key-DStQJAft.js",
			"/assets/loader-circle-NEOay2w5.js",
			"/assets/paperclip-BuZQQAmV.js",
			"/assets/format-ZjQvzFfc.js",
			"/assets/button-DfVZaRbj.js",
			"/assets/textarea-CJwNT_EP.js",
			"/assets/support-DC42gq8T.js",
			"/assets/support.functions-B3bzMI5V.js",
			"/assets/HelpParts-CNqpf7B_.js"
		]
	},
	"/_authenticated/go/$kind/$id": {
		filePath: "/home/claude/sunrise-office-test-copy/desktop/.build/src/routes/_authenticated/go.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/go._kind._id-CbG2jwK-.js",
			"/assets/PageHeader-A4MoQNrQ.js",
			"/assets/skeleton-CkvNen46.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
