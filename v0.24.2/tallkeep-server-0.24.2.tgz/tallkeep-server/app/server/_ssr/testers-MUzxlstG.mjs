import { i as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as fmtDateTime } from "./format-CORJO1ov.mjs";
import { n as PageHeader, t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Ht as ExternalLink, at as Mail, m as TriangleAlert, n as X, sn as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { i as listTesters, o as reviewTester, r as listProblems, s as setProblem } from "./testers.functions-D2vheM3b.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/testers-MUzxlstG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var USE_LABEL = {
	inventory: "Inventory",
	sales: "Quotes & invoices",
	purchasing: "Purchase orders",
	accounting: "Banking & accounting",
	properties: "Rentals",
	personal: "Personal money"
};
var SETUP_LABEL = {
	windows: "Windows",
	synology: "Synology / server",
	online: "Online"
};
function TestersAdmin() {
	const [tab, setTab] = (0, import_react.useState)("requests");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		wide: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Early access & problems",
				text: "People asking to test Tallkeep (from app.tallkeep.com/early-access), and problems reported from inside Tallkeep."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2",
				children: [["requests", "Early access requests"], ["problems", "Problem reports"]].map(([k, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setTab(k),
					className: cn("rounded-full border px-3 py-1.5 text-sm font-medium", tab === k ? "border-primary bg-primary text-primary-foreground" : "bg-card"),
					children: label
				}, k))
			}),
			tab === "requests" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Requests, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problems, {})
		]
	});
}
function Requests() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["admin-testers"],
		queryFn: () => listTesters()
	});
	const [show, setShow] = (0, import_react.useState)("pending");
	const [busy, setBusy] = (0, import_react.useState)("");
	async function act(id, action) {
		setBusy(id);
		try {
			const r = await reviewTester({ data: {
				id,
				action,
				origin: window.location.origin
			} });
			if (action === "decline") toast.success("Declined. No email was sent.");
			else if (r.mailed) toast.success("Approved. The license and code were emailed.");
			else toast.error(`Approved, but the email didn't go: ${r.why}`);
			await qc.invalidateQueries({ queryKey: ["admin-testers"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy("");
		}
	}
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (q.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-destructive",
		children: q.error.message
	});
	const all = q.data ?? [];
	const rows = all.filter((r) => r.status === show);
	const count = (s) => all.filter((r) => r.status === s).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 text-sm",
				children: [
					"pending",
					"approved",
					"declined"
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShow(s),
					className: cn("rounded-lg border px-3 py-1", show === s ? "bg-muted font-semibold" : "bg-card"),
					children: [
						s === "pending" ? "Waiting" : s === "approved" ? "Approved" : "Declined",
						" (",
						count(s),
						")"
					]
				}, s))
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
				children: "Nothing here."
			}),
			rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg font-semibold",
								children: r.company
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm",
								children: [
									r.name,
									" ·",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: `mailto:${r.email}`,
										className: "text-primary underline",
										children: r.email
									}),
									r.phone ? ` · ${r.phone}` : "",
									r.location ? ` · ${r.location}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: ["Asked ", fmtDateTime(r.created_at)]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								r.status !== "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									disabled: busy === r.id,
									onClick: () => void act(r.id, "approve"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), " Approve and email the license"]
								}),
								r.status === "pending" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									disabled: busy === r.id,
									onClick: () => void act(r.id, "decline"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), " Decline (no email)"]
								}),
								r.status === "approved" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									disabled: busy === r.id,
									onClick: () => void act(r.id, "resend"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email the license again"]
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 text-xs",
						children: [
							r.website ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: r.website,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-primary",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3 w-3" }),
									" ",
									r.website.replace(/^https?:\/\//, "")
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-amber-100 px-2 py-0.5 text-amber-900",
								children: "No website"
							}),
							r.emailMatchesSite && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-emerald-100 px-2 py-0.5 text-emerald-900",
								children: "Email matches the website"
							}),
							r.freeEmail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-amber-900",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-3 w-3" }), " Free email address"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://www.google.com/search?q=${encodeURIComponent(`"${r.company}" ${r.location ?? ""}`)}`,
								target: "_blank",
								rel: "noreferrer",
								className: "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3 w-3" }), " Look up the business"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2",
						children: [
							r.business && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "inline text-muted-foreground",
								children: "Does: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "inline",
								children: r.business
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "inline text-muted-foreground",
								children: "Wants: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "inline",
								children: r.uses.map((u) => USE_LABEL[u] ?? u).join(", ") || "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "inline text-muted-foreground",
								children: "People: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "inline",
								children: r.people ?? "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "inline text-muted-foreground",
								children: "Uses now: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "inline",
								children: r.now_using ?? "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "inline text-muted-foreground",
								children: "Runs on: "
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "inline",
								children: r.setup ? SETUP_LABEL[r.setup] ?? r.setup : "—"
							})] }),
							r.license_id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline text-muted-foreground",
									children: "License: "
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline font-mono",
									children: r.license_id
								}),
								r.code && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "ml-2 text-muted-foreground",
									children: [
										"· code ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono",
											children: r.code
										}),
										r.code_used_at ? ` (bought ${fmtDateTime(r.code_used_at)})` : ""
									]
								})
							] })
						]
					}),
					r.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg bg-muted/40 p-2 text-sm",
						children: r.notes
					})
				]
			}, r.id))
		]
	});
}
var STATUS = {
	new: "New",
	fixed: "Fixed",
	not_a_bug: "Not a problem"
};
function Problems() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["admin-problems"],
		queryFn: () => listProblems()
	});
	const [show, setShow] = (0, import_react.useState)("new");
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (q.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-destructive",
		children: q.error.message
	});
	const all = q.data ?? [];
	const rows = all.filter((r) => r.status === show);
	async function mark(id, status) {
		try {
			await setProblem({ data: {
				id,
				status
			} });
			await qc.invalidateQueries({ queryKey: ["admin-problems"] });
		} catch (e) {
			toast.error(e.message);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 text-sm",
				children: Object.keys(STATUS).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setShow(s),
					className: cn("rounded-lg border px-3 py-1", show === s ? "bg-muted font-semibold" : "bg-card"),
					children: [
						STATUS[s],
						" (",
						all.filter((r) => r.status === s).length,
						")"
					]
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Each report is also emailed to hello@tallkeep.com, with the picture if one was added. Reply to that email to answer the person."
			}),
			rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl border bg-card p-6 text-center text-muted-foreground",
				children: "Nothing here."
			}),
			rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 rounded-2xl border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-semibold",
								children: [r.company || r.name || r.email || "Someone", r.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${r.email}`,
									className: "ml-2 font-normal text-primary underline",
									children: r.email
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									fmtDateTime(r.created_at),
									" · ",
									r.edition ?? "?",
									" ",
									r.version ?? "",
									r.license_id ? ` · license ${r.license_id}` : "",
									r.has_picture ? " · picture in the email" : ""
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [
								r.status !== "fixed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => void mark(r.id, "fixed"),
									children: "Mark fixed"
								}),
								r.status !== "not_a_bug" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => void mark(r.id, "not_a_bug"),
									children: "Not a problem"
								}),
								r.status !== "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => void mark(r.id, "new"),
									children: "Back to new"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap text-sm",
						children: r.message
					}),
					r.page && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: ["Page: ", r.page]
					})
				]
			}, r.id))
		]
	});
}
//#endregion
export { TestersAdmin as component };
