import { i as __toESM } from "../_runtime.mjs";
import { n as db, r as fetchAll } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { s as useFeatures } from "./addons-tdRottJR.mjs";
import { S as useNavigate, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as fmtQty, r as fmtMoney, t as fmtDate } from "./format-CORJO1ov.mjs";
import { t as Page } from "./PageHeader-BwqSvPCx.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { Dt as Hammer, I as Receipt, Kt as CreditCard, L as Printer, M as RotateCcw, Nn as ArrowLeft, R as Plus, Wt as DollarSign, Z as PackageMinus, at as Mail, f as Undo2, g as Trash2, kn as Ban, nn as ChevronsUpDown, p as Truck, qt as Copy, sn as Check, zt as FileCheckCorner } from "../_libs/lucide-react.mjs";
import { c as usePaymentTerms, d as useTaxRates, i as useIsAdmin, o as useLocations } from "./queries-DKvOnwaZ.mjs";
import { n as smartSearch } from "./search-DEWqelr9.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-Dg1urBTx.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as Textarea } from "./textarea-kko37XEX.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./PartyForm-aFR9SgbK.mjs";
import { t as Skeleton } from "./skeleton-D9W9wFsj.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { a as CommandItem, c as PopoverContent, i as CommandInput, l as PopoverTrigger, n as CommandEmpty, o as CommandList, s as Popover, t as Command$1, u as SearchSelect } from "./SearchSelect-BLD0hN-C.mjs";
import { n as addLocation, r as addTerms, s as useAddVendor, t as addCustomer } from "./quickadd-CPmfd8Bg.mjs";
import { t as copyText } from "./copy-CVwvwH3g.mjs";
import { a as docName, c as isRmaDoc, f as totals, i as STATUS_STYLE, l as lineTotal, r as STATUS_LABEL, s as isQuoteLike, u as nextNumber } from "./sales-B9r0ST4P.mjs";
import { n as salesGroup, t as SideLayout } from "./SideList-CxhSC804.mjs";
import { a as paymentFollowupMessage, r as followupMessage } from "./followups-CAmQFMgv.mjs";
import { t as ScanAddButton } from "./ScanAdd-nGxsS8Bd.mjs";
import { a as defaultsFor, n as NO_FOOTERS, o as swapDefaults, s as useFooters } from "./footers-v603VGyt.mjs";
import { a as useCardPay, i as syncCardPayments, r as payLink } from "./cardpay-DhV_gB7e.mjs";
import { t as Checkbox } from "./checkbox-kt6FvQcE.mjs";
import { i as NewProductDialog, n as FooterPicker, r as Fulfilments, t as EmailDocDialog } from "./NewProductDialog-3VAyhFCH.mjs";
import { t as MoneyAccountPick } from "./MoneyAccountPick-BF3coPzD.mjs";
import { n as useCompanyLogo, t as PrintFrame } from "./PrintFrame-gVFyb6kO.mjs";
import { i as useRecipes, n as createWorkOrder, r as useLiteProducts, t as WO_STATUS } from "./workorders-CuzhTmEg.mjs";
import { t as Route } from "./sales._id-CNGSpsD6.mjs";
import { a as ticketId, i as markTicket } from "./tickets.functions-BFDjTySC.mjs";
import { r as listRepNames } from "./users.functions-DZdInPF_.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/sales._id-BFfI4_UZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NONE = "none";
/**
* Like inFlow's "Create PO" on a sales order: order this invoice's items from the
* vendors that carry them. One purchase order is made for each vendor.
*/
function CreatePoDialog({ order, lines, onClose }) {
	const addVendorNow = useAddVendor();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const ids = (0, import_react.useMemo)(() => Array.from(new Set(lines.map((l) => l.product_id).filter(Boolean))), [lines]);
	const { data } = useQuery({
		queryKey: ["create-po", ids.join(",")],
		queryFn: async () => {
			const [vendors, vi, prods, stock] = await Promise.all([
				fetchAll("vendors", "id,name,contact_name,phone,address,payment_terms_id,is_active"),
				ids.length ? db.from("vendor_items").select("vendor_id,product_id,vendor_code,cost").in("product_id", ids) : Promise.resolve({
					data: [],
					error: null
				}),
				ids.length ? db.from("products").select("id,cost,item_type").in("id", ids) : Promise.resolve({
					data: [],
					error: null
				}),
				ids.length ? db.from("stock").select("product_id,qty").in("product_id", ids) : Promise.resolve({
					data: [],
					error: null
				})
			]);
			const onHand = /* @__PURE__ */ new Map();
			(stock.data ?? []).forEach((s) => onHand.set(s.product_id, (onHand.get(s.product_id) ?? 0) + Number(s.qty)));
			return {
				vendors: vendors.filter((v) => v.is_active !== false).sort((a, b) => a.name.localeCompare(b.name)),
				items: vi.data ?? [],
				cost: new Map((prods.data ?? []).map((p) => [p.id, Number(p.cost)])),
				onHand,
				service: new Set((prods.data ?? []).filter((p) => p.item_type === "service").map((p) => p.id))
			};
		}
	});
	const [rows, setRows] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!data || rows) return;
		setRows(lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l, i) => {
			const best = data.items.filter((x) => x.product_id === l.product_id).sort((a, b) => Number(a.cost) - Number(b.cost))[0];
			return {
				key: i,
				include: !!l.product_id && !data.service.has(l.product_id),
				product_id: l.product_id,
				description: l.description ?? "",
				unit: l.unit,
				qty: Number(l.qty) || 1,
				vendor_id: best?.vendor_id ?? NONE
			};
		}));
	}, [
		data,
		lines,
		rows
	]);
	const set = (key, p) => setRows((rs) => (rs ?? []).map((r) => r.key === key ? {
		...r,
		...p
	} : r));
	const picked = (rows ?? []).filter((r) => r.include && r.qty > 0);
	const missing = picked.filter((r) => r.vendor_id === NONE).length;
	const vendorIds = Array.from(new Set(picked.map((r) => r.vendor_id))).filter((v) => v !== NONE);
	async function create() {
		if (!data) return;
		if (!picked.length) {
			toast.error("Tick at least one item.");
			return;
		}
		if (missing) {
			toast.error("Choose a vendor for every ticked item.");
			return;
		}
		setBusy(true);
		try {
			const { data: u } = await db.auth.getUser();
			const made = [];
			for (const vid of vendorIds) {
				const v = data.vendors.find((x) => x.id === vid);
				if (!v) continue;
				const poLines = picked.filter((r) => r.vendor_id === vid).map((r, i) => {
					const vi = data.items.find((x) => x.vendor_id === vid && x.product_id === r.product_id);
					const cost = vi ? Number(vi.cost) : data.cost.get(r.product_id ?? "") ?? 0;
					return {
						line_no: i + 1,
						product_id: r.product_id,
						vendor_code: vi?.vendor_code ?? null,
						description: r.description,
						qty: r.qty,
						unit: r.unit,
						unit_cost: cost,
						discount: 0,
						discount_is_percent: true,
						line_total: Math.round(r.qty * cost * 100) / 100,
						qty_received: 0
					};
				});
				const subtotal = poLines.reduce((s, l) => s + l.line_total, 0);
				const number = await nextNumber("purchase_order");
				const { data: po, error } = await db.from("purchase_orders").insert({
					number,
					status: "open",
					vendor_id: v.id,
					vendor_name: v.name,
					contact_name: v.contact_name,
					phone: v.phone,
					vendor_address: v.address,
					payment_terms_id: v.payment_terms_id,
					order_date: (/* @__PURE__ */ new Date()).toISOString(),
					subtotal,
					tax: 0,
					freight: 0,
					total: subtotal,
					amount_paid: 0,
					balance: subtotal,
					remarks: `For ${order.number}${order.customer_name ? ` — ${order.customer_name}` : ""}`,
					custom: {
						sales_order_id: order.id,
						sales_order_number: order.number
					},
					...NO_FOOTERS,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				const { error: e2 } = await db.from("purchase_order_lines").insert(poLines.map((l) => ({
					...l,
					purchase_order_id: po.id
				})));
				if (e2) throw e2;
				made.push({
					id: po.id,
					number,
					vendor: v.name
				});
				const newLinks = poLines.filter((l) => l.product_id && !data.items.some((x) => x.vendor_id === vid && x.product_id === l.product_id)).map((l) => ({
					vendor_id: vid,
					product_id: l.product_id,
					cost: l.unit_cost
				}));
				if (newLinks.length) await db.from("vendor_items").insert(newLinks);
			}
			qc.invalidateQueries({ queryKey: ["pos"] });
			qc.invalidateQueries({ queryKey: ["side-list"] });
			qc.invalidateQueries({ queryKey: ["po-for-order", order.id] });
			toast.success(made.length === 1 ? `Made purchase order ${made[0].number} for ${made[0].vendor}.` : `Made ${made.length} purchase orders: ${made.map((m) => `${m.number} (${m.vendor})`).join(", ")}.`);
			onClose();
			if (made.length === 1) navigate({
				to: "/po/$id",
				params: { id: made[0].id },
				search: {}
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Order these items from vendors" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Each item starts on the vendor that sells it cheapest. Change the vendor or quantity if needed. One purchase order is made for each vendor." })] }),
				!rows ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Loading…"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[55vh] divide-y overflow-y-auto rounded-xl border",
					children: rows.map((r) => {
						const carriers = (data?.items ?? []).filter((x) => x.product_id === r.product_id);
						const have = r.product_id ? data?.onHand.get(r.product_id) ?? 0 : null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 px-3 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: r.include,
									onCheckedChange: (c) => set(r.key, { include: c === true }),
									"aria-label": "Order this item"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-medium",
										children: r.description || "—"
									}), have != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: `text-xs ${have <= 0 ? "text-destructive" : "text-muted-foreground"}`,
										children: [fmtQty(have), " in stock"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									className: "h-8 w-20 text-right",
									value: r.qty,
									onChange: (e) => set(r.key, { qty: Number(e.target.value) }),
									"aria-label": "Quantity to order"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
									value: r.vendor_id === NONE ? null : r.vendor_id,
									onChange: (v) => set(r.key, { vendor_id: v }),
									placeholder: "Choose vendor",
									onAdd: addVendorNow,
									addLabel: "Add new vendor",
									searchText: "Type a vendor name",
									className: "h-8 w-56",
									invalid: r.include && r.vendor_id === NONE,
									options: [...carriers.flatMap((c) => {
										const v = data?.vendors.find((x) => x.id === c.vendor_id);
										return v ? [{
											value: v.id,
											label: v.name,
											hint: fmtMoney(Number(c.cost))
										}] : [];
									}), ...(data?.vendors ?? []).filter((v) => !carriers.some((c) => c.vendor_id === v.id)).map((v) => ({
										value: v.id,
										label: v.name
									}))]
								})
							]
						}, r.key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "self-center text-sm text-muted-foreground",
						children: missing ? `${missing} ticked item${missing > 1 ? "s" : ""} still need a vendor.` : `${picked.length} item${picked.length === 1 ? "" : "s"} · ${vendorIds.length} vendor${vendorIds.length === 1 ? "" : "s"}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: onClose,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void create(),
							disabled: busy || !rows || !vendorIds.length,
							children: busy ? "Making…" : vendorIds.length > 1 ? `Make ${vendorIds.length} purchase orders` : "Make purchase order"
						})]
					})]
				})
			]
		})
	});
}
/** "Build with work orders": one work order for each line whose product has parts. */
function BuildButton({ order, lines, ready }) {
	const qc = useQueryClient();
	const { data: features } = useFeatures();
	const { data: recipes } = useRecipes();
	const { data: products } = useLiteProducts();
	const { data: locations } = useLocations();
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!features?.includes("work_orders")) return null;
	const buildable = lines.filter((l) => l.product_id && Number(l.qty) > 0 && recipes?.has(l.product_id));
	if (!buildable.length) return null;
	async function run() {
		if (!await ready()) return;
		const { data: existing } = await db.from("work_orders").select("id").eq("sales_order_id", order.id).neq("status", "cancelled").limit(1);
		if (existing?.length && !window.confirm("This invoice already has work orders. Make more anyway?")) return;
		setBusy(true);
		try {
			const made = [];
			for (const l of buildable) {
				const p = products?.find((x) => x.id === l.product_id);
				const loc = order.location_id ?? p?.default_location_id ?? (locations ?? []).find((x) => x.is_active)?.id;
				if (!loc) throw new Error("Add a location first (Inventory → Locations).");
				const w = await createWorkOrder({
					product_id: l.product_id,
					qty: Number(l.qty),
					location_id: loc,
					recipe: recipes?.get(l.product_id) ?? [],
					extra_per_unit: p?.build_extra_cost ?? 0,
					sales_order_id: order.id
				});
				made.push(w.number);
			}
			toast.success(`Made ${made.join(", ")}.`);
			qc.invalidateQueries({ queryKey: ["work-orders"] });
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		onClick: () => void run(),
		disabled: busy,
		title: "Make a work order for each item on this invoice that is built from parts",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { className: "h-4 w-4" }),
			" ",
			busy ? "Making…" : "Build with work orders"
		]
	});
}
/** Work orders made from this invoice. */
function OrderWorkOrders({ orderId }) {
	const { data: features } = useFeatures();
	const on = !!features?.includes("work_orders");
	const { data } = useQuery({
		queryKey: [
			"work-orders",
			"for-order",
			orderId
		],
		enabled: on,
		queryFn: async () => {
			const { data, error } = await db.from("work_orders").select("id,number,status").eq("sales_order_id", orderId).order("number");
			if (error) return [];
			return data ?? [];
		}
	});
	if (!on || !data?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex flex-wrap items-center gap-x-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hammer, { className: "h-4 w-4 text-muted-foreground" }),
			" Work orders:",
			data.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/work-orders",
					search: { wo: w.id },
					className: "font-medium underline",
					children: w.number
				}),
				" ",
				"(",
				WO_STATUS[w.status],
				")",
				i < data.length - 1 ? "," : ""
			] }, w.id))
		]
	});
}
/** The quote / invoice / RMA as PDF content — same as the printed page. */
function salesPdf(order, lines, company, logo, terms, payments, extra = {}) {
	const rma = isRmaDoc(order);
	const name = rma ? "RMA" : docName(order.status === "cancelled" ? "quote" : order.status);
	const endFooter = order.footer_id || order.footer_text ? order.footer_text : rma ? null : order.status === "quote" ? company?.quote_footer : company?.invoice_footer;
	const date = isQuoteLike(order.status) || order.status === "open" ? order.order_date : order.invoice_date ?? order.order_date;
	const facts = [["No.", order.number ?? ""], ["Date", fmtDate(date)]];
	if (order.project_name) facts.push(["Project", order.project_name]);
	if (order.po_number && !isQuoteLike(order.status)) facts.push(["Your PO", order.po_number]);
	if (terms) facts.push(["Terms", terms]);
	if (order.sales_rep) facts.push(["Sales rep", order.sales_rep]);
	if (order.due_date && !isQuoteLike(order.status)) facts.push(["Due", fmtDate(order.due_date)]);
	const totals = [{
		label: "Subtotal",
		value: fmtMoney(order.subtotal)
	}, {
		label: `${order.tax_name || "Sales tax"} (${Number(order.tax_rate)}%)`,
		value: fmtMoney(order.tax)
	}];
	if (Number(order.shipping) !== 0) totals.push({
		label: "Shipping",
		value: fmtMoney(order.shipping)
	});
	totals.push({
		label: "Total",
		value: fmtMoney(order.total),
		big: true
	});
	if (order.status !== "quote" && !rma) [...payments].filter((p) => Number(p.amount) !== 0).sort((a, b) => a.paid_on.localeCompare(b.paid_on)).forEach((p) => totals.push({
		label: `Paid ${fmtDate(p.paid_on)}`,
		value: `– ${fmtMoney(p.amount)}`
	}));
	if (!isQuoteLike(order.status) && !rma) totals.push({
		label: "Balance due",
		value: fmtMoney(Number(order.total) - Number(order.amount_paid || 0)),
		big: true
	});
	if (extra.deposit && extra.deposit > 0) totals.push({
		label: "Deposit due now",
		value: fmtMoney(extra.deposit),
		big: true
	});
	return {
		payUrl: extra.payUrl,
		title: name.toUpperCase(),
		subtitle: rma ? "Return Merchandise Authorization" : void 0,
		logo,
		company: {
			name: company?.name ?? "",
			address: company?.mailing_address || company?.address || null,
			addressLabel: isQuoteLike(order.status) || order.status === "cancelled" ? "MAILING ADDRESS" : "MAIL PAYMENTS TO",
			phone: company?.phone ?? null,
			email: company?.email ?? null,
			website: company?.website ?? null
		},
		facts,
		leftTitle: "BILL TO",
		left: [
			order.customer_name,
			order.contact_name ? `Attn: ${order.contact_name}` : null,
			order.billing_address,
			[order.phone, order.email].filter(Boolean).join(" · ") || null
		].filter(Boolean).join("\n"),
		rightTitle: "SHIP TO",
		right: order.shipping_address ?? "",
		lines: lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l) => ({
			desc: l.description ?? "",
			qty: fmtQty(l.qty),
			price: fmtMoney(l.unit_price),
			disc: Number(l.discount) ? `${Number(l.discount)}%` : "",
			total: fmtMoney(lineTotal(l))
		})),
		remarks: order.remarks,
		totals,
		endFooter,
		pageFooter: order.page_footer_text,
		attach: order.attach_text
	};
}
/** New quotes and invoices start with this sales rep. */
var DEFAULT_REP = "Matthew Kalyani";
var blankOrder = (status) => ({
	status,
	customer_id: null,
	customer_name: null,
	contact_name: null,
	phone: null,
	email: null,
	po_number: null,
	project_name: null,
	sales_rep: DEFAULT_REP,
	location_id: null,
	order_date: (/* @__PURE__ */ new Date()).toISOString(),
	ship_by: null,
	invoice_date: null,
	due_date: null,
	payment_terms_id: null,
	billing_address: null,
	shipping_address: null,
	tax_name: null,
	tax_rate: 0,
	subtotal: 0,
	tax: 0,
	shipping: 0,
	total: 0,
	amount_paid: 0,
	balance: 0,
	remarks: null,
	custom: {},
	stock_taken_at: null,
	...NO_FOOTERS
});
var newLine = (no) => ({
	id: crypto.randomUUID(),
	line_no: no,
	product_id: null,
	description: "",
	qty: 1,
	unit: null,
	unit_price: 0,
	discount: 0,
	discount_is_percent: true,
	taxable: true,
	line_total: 0,
	serials: null,
	_new: true
});
function SalesPage() {
	const { id } = Route.useParams();
	const search = Route.useSearch();
	const isNew = id === "new";
	const qc = useQueryClient();
	const { data: card } = useCardPay();
	(0, import_react.useEffect)(() => {
		if (!card?.connected) return;
		syncCardPayments().then((r) => {
			if (r.recorded) qc.invalidateQueries();
		}).catch(() => {});
	}, [card?.connected, qc]);
	const navigate = useNavigate();
	const { data: isAdmin } = useIsAdmin();
	const { data: loaded, isLoading } = useQuery({
		queryKey: ["sale", id],
		enabled: !isNew,
		queryFn: async () => {
			const { data, error } = await db.from("sales_orders").select("*, sales_order_lines(*), payments(*)").eq("id", id).single();
			if (error) throw error;
			return data;
		}
	});
	const [order, setOrder] = (0, import_react.useState)(blankOrder(search.kind === "order" ? "open" : search.kind === "rma" ? "rma" : "quote"));
	const [lines, setLines] = (0, import_react.useState)([newLine(1)]);
	const [removed, setRemoved] = (0, import_react.useState)([]);
	const [dirty, setDirty] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ticked, setTicked] = (0, import_react.useState)([]);
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const [askedPay, setAskedPay] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!search.paid || isNew || askedPay || !loaded) return;
		if (Number(loaded.balance ?? 0) > .004) setDialog("payment");
		setAskedPay(true);
	}, [
		search.paid,
		isNew,
		askedPay,
		loaded
	]);
	const logo = useCompanyLogo();
	const [followupMode, setFollowupMode] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!order.number) return;
		const before = document.title;
		document.title = order.number;
		return () => {
			document.title = before;
		};
	}, [order.number]);
	const { data: reps } = useQuery({
		queryKey: ["rep-names"],
		staleTime: 6e5,
		queryFn: () => listRepNames()
	});
	const { data: myEmail } = useQuery({
		queryKey: ["my-email"],
		queryFn: async () => (await db.auth.getUser()).data.user?.email ?? ""
	});
	(0, import_react.useEffect)(() => {
		if (!loaded) return;
		const { sales_order_lines, payments: _p, ...o } = loaded;
		setOrder(o);
		setLines([...sales_order_lines].sort((a, b) => a.line_no - b.line_no));
		setRemoved([]);
		setDirty(false);
	}, [loaded]);
	const { data: customers } = useQuery({
		queryKey: ["customers", "full"],
		queryFn: () => fetchAll("customers", "*")
	});
	const { data: products } = useQuery({
		queryKey: ["products", "pick"],
		queryFn: () => fetchAll("products", "id,name,description,price,unit,item_type,is_active,stock(qty)")
	});
	const { data: taxes } = useTaxRates();
	const { data: terms } = usePaymentTerms();
	const { data: locations } = useLocations();
	const { data: company } = useQuery({
		queryKey: ["company"],
		queryFn: async () => {
			const { data } = await db.from("company_settings").select("*").maybeSingle();
			return data ?? {
				name: "",
				address: null,
				phone: null,
				email: null,
				website: null,
				quote_footer: null,
				invoice_footer: null
			};
		}
	});
	const { data: footers } = useFooters();
	(0, import_react.useEffect)(() => {
		if (search.followup === "1" && loaded && loaded.status === "quote") {
			setFollowupMode("quote");
			setDialog("email");
		}
		if (search.followup === "pay" && loaded && loaded.status !== "quote") {
			setFollowupMode("pay");
			setDialog("email");
		}
	}, [search.followup, loaded?.id]);
	(0, import_react.useEffect)(() => {
		if (!isNew || !footers || order.footer_id || order.page_footer_id || order.attach_id) return;
		setOrder((o) => ({
			...o,
			...defaultsFor(footers, footerKind(o.status))
		}));
	}, [isNew, footers]);
	const customer = customers?.find((c) => c.id === order.customer_id);
	const { data: listPrices } = useQuery({
		queryKey: ["list-prices", customer?.price_list_id],
		enabled: !!customer?.price_list_id,
		queryFn: async () => {
			const { data, error } = await db.from("product_prices").select("product_id,price").eq("price_list_id", customer?.price_list_id ?? "").limit(5e3);
			if (error) throw error;
			const m = /* @__PURE__ */ new Map();
			(data ?? []).forEach((r) => {
				if (Number(r.price) > 0) m.set(r.product_id, Number(r.price));
			});
			return m;
		}
	});
	(0, import_react.useEffect)(() => {
		if (isNew && search.product && products && !lines[0]?.product_id) pickProduct(0, search.product);
	}, [
		isNew,
		search.product,
		products
	]);
	(0, import_react.useEffect)(() => {
		if (isNew && search.ticket) setOrder((o) => ({
			...o,
			ticket_id: search.ticket
		}));
	}, [isNew, search.ticket]);
	const ticketLinkId = order.ticket_id ?? null;
	const { data: fromTicket } = useQuery({
		queryKey: ["ticket-of-doc", ticketLinkId],
		enabled: !!ticketLinkId,
		queryFn: async () => {
			const { data } = await db.from("tickets").select("id,number,subject").eq("id", ticketLinkId).maybeSingle();
			return data;
		}
	});
	(0, import_react.useEffect)(() => {
		if (isNew && search.customer && customers && !order.customer_id) pickCustomer(search.customer);
	}, [
		isNew,
		search.customer,
		customers
	]);
	const t = (0, import_react.useMemo)(() => totals(lines, Number(order.tax_rate), Number(order.shipping)), [
		lines,
		order.tax_rate,
		order.shipping
	]);
	const status = order.status;
	const locked = status === "cancelled";
	function patch(p) {
		setOrder((o) => ({
			...o,
			...p
		}));
		setDirty(true);
	}
	function patchLine(i, p) {
		setLines((ls) => ls.map((l, j) => j === i ? {
			...l,
			...p
		} : l));
		setDirty(true);
	}
	function pickCustomer(cid) {
		const c = customers?.find((x) => x.id === cid);
		if (!c) return;
		const tax = taxes?.find((x) => x.id === c.tax_rate_id);
		patch({
			customer_id: c.id,
			customer_name: c.name,
			contact_name: c.contact_name,
			phone: c.phone,
			email: c.email,
			billing_address: c.billing_address || c.address,
			shipping_address: c.shipping_address || c.address,
			payment_terms_id: c.payment_terms_id,
			sales_rep: c.sales_rep || DEFAULT_REP,
			...tax ? {
				tax_rate: Number(tax.rate),
				tax_name: tax.name
			} : {}
		});
	}
	const custChanges = customer ? [
		["contact_name", "contact"],
		["phone", "phone"],
		["email", "email"],
		["billing_address", "billing address"],
		["shipping_address", "shipping address"],
		["payment_terms_id", "terms"],
		["sales_rep", "sales rep"]
	].filter(([k]) => (order[k] ?? "") !== (customer[k] ?? "") && (order[k] ?? "") !== "") : [];
	async function saveToCustomer() {
		if (!customer) return;
		const patch = {};
		custChanges.forEach(([k]) => patch[k] = order[k] ?? null);
		const { error } = await db.from("customers").update(patch).eq("id", customer.id);
		if (error) toast.error(error.message);
		else {
			toast.success(`Saved to ${customer.name}.`);
			qc.invalidateQueries({ queryKey: ["customers"] });
		}
	}
	function pickProduct(i, pid, fresh) {
		const p = fresh ?? products?.find((x) => x.id === pid);
		if (!p) return;
		const price = listPrices?.get(p.id) ?? Number(p.price);
		patchLine(i, {
			product_id: p.id,
			description: p.description ? `${p.name} — ${p.description}` : p.name,
			unit: p.unit,
			unit_price: price,
			discount: Number(customer?.discount ?? 0),
			taxable: p.item_type !== "service" ? true : lines[i]?.taxable ?? true
		});
	}
	/** A scanned item: one more of it, or a new line (the first empty one) the first time. */
	async function scanned(f) {
		if (locked) return;
		const i = lines.findIndex((l) => l.product_id === f.id);
		if (i >= 0) return patchLine(i, { qty: (Number(lines[i].qty) || 0) + 1 });
		let p = products?.find((x) => x.id === f.id);
		if (!p) {
			const { data } = await db.from("products").select("id,name,description,price,unit,item_type").eq("id", f.id).maybeSingle();
			p = data ?? void 0;
			qc.invalidateQueries({ queryKey: ["products", "pick"] });
		}
		if (!p) return;
		const empty = lines.findIndex((l) => !l.product_id && !l.description);
		if (empty >= 0) return pickProduct(empty, p.id, p);
		const at = lines.length;
		setLines((ls) => [...ls, newLine(ls.length + 1)]);
		setTimeout(() => pickProduct(at, p.id, p), 0);
	}
	async function save(extra = {}) {
		if (!order.customer_name?.trim()) {
			toast.error("Choose a customer first.");
			return null;
		}
		setBusy(true);
		try {
			const row = {
				...order,
				...extra,
				subtotal: t.subtotal,
				tax: t.tax,
				total: t.total,
				balance: t.total - Number(order.amount_paid || 0)
			};
			delete row.id;
			let oid = order.id;
			if (!oid) {
				const number = await nextNumber(row.status === "quote" ? "quote" : row.status === "rma" ? "rma" : "sales_order");
				const { data: u } = await db.auth.getUser();
				const { data, error } = await db.from("sales_orders").insert({
					...row,
					number,
					created_by: u.user?.id
				}).select("id").single();
				if (error) throw error;
				oid = data.id;
			} else {
				const { error } = await db.from("sales_orders").update(row).eq("id", oid);
				if (error) throw error;
			}
			if (removed.length) {
				const { error } = await db.from("sales_order_lines").delete().in("id", removed);
				if (error) throw error;
			}
			const lineRows = lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l, i) => {
				const { _new, qty_fulfilled: _out, ...rest } = l;
				return {
					...rest,
					sales_order_id: oid,
					line_no: i + 1,
					line_total: lineTotal(l)
				};
			});
			if (lineRows.length) {
				const { error } = await db.from("sales_order_lines").upsert(lineRows, { onConflict: "id" });
				if (error) throw error;
			}
			qc.invalidateQueries({ queryKey: ["sale", oid] });
			qc.invalidateQueries({ queryKey: ["sales"] });
			qc.invalidateQueries({ queryKey: ["home"] });
			qc.invalidateQueries({ queryKey: ["side-list"] });
			setDirty(false);
			if (isNew) navigate({
				to: "/sales/$id",
				params: { id: oid },
				search: search.paid ? { paid: 1 } : {},
				replace: true
			});
			return oid;
		} catch (e) {
			toast.error(e.message);
			return null;
		} finally {
			setBusy(false);
		}
	}
	async function unfulfill() {
		if (!order.id) return;
		if (!window.confirm("Put the items on this invoice back into stock and mark it unfulfilled?")) return;
		setBusy(true);
		const { data, error } = await db.rpc("return_order_stock", { _order_id: order.id });
		setBusy(false);
		if (error) toast.error(error.message);
		else {
			toast.success(Number(data) > 0 ? "Items put back into stock. It's unfulfilled now." : "Marked unfulfilled (no stock had been taken).");
			qc.invalidateQueries({ queryKey: ["sale", id] });
			qc.invalidateQueries({ queryKey: ["products"] });
		}
	}
	async function change(next, msg) {
		if (await save(next)) toast.success(msg);
	}
	function makeInvoice() {
		const days = terms?.find((x) => x.id === order.payment_terms_id)?.days_due ?? 0;
		const now = /* @__PURE__ */ new Date();
		const due = new Date(now.getTime() + days * 864e5);
		const next = {
			status: "invoiced",
			invoice_date: now.toISOString(),
			due_date: due.toISOString(),
			...swapFooter("invoice")
		};
		setOrder((o) => ({
			...o,
			...next
		}));
		change(next, "Invoice created.");
	}
	/** If the footer is still the default for the old step, use the default for the new step. */
	function swapFooter(kind) {
		return swapDefaults(footers, order, footerKind(order.status), kind);
	}
	/** Like inFlow's Copy: a new quote (or RMA) with the same customer and items. */
	async function copyAsNew(as = isRmaDoc(order) ? "rma" : "quote") {
		setBusy(true);
		try {
			const number = await nextNumber(as);
			const { data: u } = await db.auth.getUser();
			const { id: _id, number: _n, ...rest } = order;
			const { data, error } = await db.from("sales_orders").insert({
				...rest,
				number,
				status: as,
				order_date: (/* @__PURE__ */ new Date()).toISOString(),
				...defaultsFor(footers, as),
				invoice_date: null,
				due_date: null,
				amount_paid: 0,
				balance: t.total,
				subtotal: t.subtotal,
				tax: t.tax,
				total: t.total,
				stock_taken_at: null,
				custom: {},
				created_by: u.user?.id
			}).select("id").single();
			if (error) throw error;
			const copies = lines.filter((l) => l.product_id || (l.description ?? "").trim()).map((l, i) => {
				const { _new, id: _lid, qty_fulfilled: _out, ...r } = l;
				return {
					...r,
					sales_order_id: data.id,
					line_no: i + 1,
					line_total: lineTotal(l)
				};
			});
			if (copies.length) {
				const { error: e2 } = await db.from("sales_order_lines").insert(copies);
				if (e2) throw e2;
			}
			toast.success(`Copied to new ${as === "rma" ? "RMA" : "quote"} ${number}.`);
			qc.invalidateQueries({ queryKey: ["sales"] });
			navigate({
				to: "/sales/$id",
				params: { id: data.id },
				search: {}
			});
		} catch (e) {
			toast.error(e.message);
		} finally {
			setBusy(false);
		}
	}
	async function copyPayLink() {
		if (!order.id) return;
		try {
			if (dirty && !await save()) return;
			const { url } = await payLink(order.id);
			await copyText(url);
			toast.success("Pay now link copied. Paste it in a text or email to the customer.");
		} catch (e) {
			toast.error(e.message);
		}
	}
	async function emailCustomer() {
		if (dirty && !await save()) return;
		setDialog("email");
	}
	if (!isNew && (isLoading || !loaded)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print:hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
			kind: {
				type: "sales",
				group: "all"
			},
			currentId: id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-1/2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-96" })] })
		})
	});
	const payments = loaded?.payments ?? [];
	const hasStocked = lines.some((l) => products?.find((p) => p.id === l.product_id)?.item_type === "stocked");
	const stockedLines = lines.filter((l) => products?.find((p) => p.id === l.product_id)?.item_type === "stocked");
	const someOut = stockedLines.some((l) => Number(l.qty_fulfilled ?? 0) > 0);
	const canFulfil = !isNew && !isQuoteLike(status) && !order.stock_taken_at && status !== "cancelled";
	const stockedIds = new Set(stockedLines.map((l) => l.id));
	const title = isNew ? search.paid ? "New sales receipt" : `New ${search.kind === "order" ? "invoice" : search.kind === "rma" ? "RMA" : "quote"}` : `${docName(status)} ${order.number}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "print:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideLayout, {
				kind: {
					type: "sales",
					group: salesGroup(order)
				},
				currentId: id,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/sales-list",
						className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" }), " Back"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-2xl font-bold sm:text-3xl",
								children: title
							}), !isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_STYLE[status]}`,
								children: STATUS_LABEL[status]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => window.print(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4" }), " Print or save PDF"]
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void copyAsNew(),
									disabled: busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy"]
								}),
								!isNew && !isRmaDoc(order) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void copyAsNew("rma"),
									disabled: busy,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "h-4 w-4" }), " Start an RMA from this"]
								}),
								!isNew && !isRmaDoc(order) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void (dirty ? save() : Promise.resolve(order.id)).then((ok) => ok && setDialog("po")),
									disabled: busy,
									title: "Make purchase orders for these items, one for each vendor",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4" }), " Order from vendor"]
								}),
								!isNew && !isRmaDoc(order) && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BuildButton, {
									order: {
										id: order.id,
										location_id: order.location_id ?? null
									},
									lines: lines.map((l) => ({
										product_id: l.product_id,
										qty: Number(l.qty)
									})),
									ready: () => dirty ? save() : Promise.resolve(true)
								}),
								!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void emailCustomer(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }), " Email customer"]
								}),
								!isNew && card?.linked && order.id && !isRmaDoc(order) && !isQuoteLike(status) && status !== "cancelled" && t.total - Number(order.amount_paid || 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: () => void copyPayLink(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "h-4 w-4" }), " Copy Pay now link"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => void save().then((ok) => ok && toast.success("Saved.")),
									disabled: busy || locked,
									children: busy ? "Saving…" : dirty || isNew ? "Save" : "Saved"
								})
							]
						})]
					}),
					!isNew && !locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 rounded-2xl border bg-card p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "self-center px-1 text-sm font-medium text-muted-foreground",
								children: "Next step:"
							}),
							status === "rma" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "self-center text-sm text-muted-foreground",
								children: "Print it or email it to the customer."
							}),
							status === "quote" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => change({
									status: "open",
									...swapFooter("order")
								}, "Turned into an invoice."),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "h-4 w-4" }), " Customer accepted – make invoice"]
							}),
							(status === "quote" || status === "open") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: status === "open" ? "default" : "outline",
								onClick: makeInvoice,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-4 w-4" }),
									" ",
									status === "open" ? "Mark as invoiced (sets the due date)" : "Create invoice"
								]
							}),
							(status === "invoiced" || status === "paid" || status === "open") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setDialog("payment"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "h-4 w-4" }), " Record payment"]
							}),
							!isNew && status === "quote" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									setFollowupMode("quote");
									emailCustomer();
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
									" Follow up on this quote by email",
									Number(order.followup_count ?? 0) > 0 && order.last_followup_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [
											"(last ",
											fmtDate(order.last_followup_at),
											")"
										]
									})
								]
							}),
							!isNew && !isRmaDoc(order) && !isQuoteLike(status) && t.total - Number(order.amount_paid || 0) > .005 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									setFollowupMode("pay");
									emailCustomer();
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
									" Follow up on payment",
									Number(order.followup_count ?? 0) > 0 && order.last_followup_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs text-muted-foreground",
										children: [
											"(last ",
											fmtDate(order.last_followup_at),
											")"
										]
									})
								]
							}),
							hasStocked && !order.stock_taken_at && !isQuoteLike(status) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setDialog("stock"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageMinus, { className: "h-4 w-4" }),
									" ",
									someOut ? "Fulfill the rest" : "Fulfill all (take items out of stock)"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setDialog("stock-some"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageMinus, { className: "h-4 w-4" }), " Fulfill some"]
							})] }),
							(order.stock_taken_at || someOut) && !isQuoteLike(status) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => void unfulfill(),
								disabled: busy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }), " Undo all fulfilled (put items back)"]
							}),
							status === "paid" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => change({ status: "completed" }, "Marked as completed."),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }), " Mark as completed"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => change({ status: "cancelled" }, "Cancelled."),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { className: "h-4 w-4" }),
									" Cancel this ",
									docName(status).toLowerCase()
								]
							})
						]
					}),
					locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between rounded-2xl border bg-muted p-3 text-sm",
						children: [order.closed_reason ?? "This was cancelled.", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => isRmaDoc(order) ? change({ status: "rma" }, "Reopened the RMA.") : change({
								status: "quote",
								closed_reason: null,
								followup_count: 0,
								...order.closed_reason ? { order_date: (/* @__PURE__ */ new Date()).toISOString() } : {}
							}, order.closed_reason ? "Reopened with today's date — check the prices." : "Reopened as a quote."),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "h-4 w-4" }),
								" ",
								isRmaDoc(order) ? "Reopen RMA" : "Reopen as quote"
							]
						})]
					}),
					!isNew && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderPos, { orderId: order.id }),
					!isNew && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderWorkOrders, { orderId: order.id }),
					fromTicket && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"From ticket",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/tickets/$id",
								params: { id: fromTicket.id },
								className: "font-medium underline",
								children: fromTicket.number
							}),
							": ",
							fromTicket.subject,
							". The customer sees it on their ticket."
						]
					}),
					ticketId(order.custom?.["Ticket"]) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"From website ticket",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/website-tickets/$id",
								params: { id: String(ticketId(order.custom?.["Ticket"])) },
								className: "font-medium underline",
								children: order.custom?.["Ticket"]
							}),
							". Emailing it marks the ticket invoiced; full payment marks it paid."
						]
					}),
					!isNew && !isQuoteLike(status) && hasStocked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex flex-wrap items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `rounded-full px-2.5 py-0.5 text-xs font-medium ${order.stock_taken_at ? "bg-emerald-100 text-emerald-800" : someOut ? "bg-amber-100 text-amber-900" : "bg-muted text-foreground"}`,
							children: order.stock_taken_at ? "Fulfilled" : someOut ? "Partly fulfilled" : "Unfulfilled"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: order.stock_taken_at ? `Everything went out; the last of it on ${fmtDate(order.stock_taken_at)}.` : someOut ? `Still to go: ${stockedLines.filter((l) => Number(l.qty) > Number(l.qty_fulfilled ?? 0)).map((l) => `${fmtQty(Number(l.qty) - Number(l.qty_fulfilled ?? 0))} × ${shortName(l)}`).join(", ")}.` : "Items are still counted in stock. Press Fulfill when they ship."
						})]
					}),
					!isNew && !isQuoteLike(status) && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fulfilments, {
						docId: order.id,
						lines,
						onUndo: async (batch) => {
							const { error } = await db.rpc("return_order_stock", {
								_order_id: order.id,
								_batch: batch
							});
							if (error) return void toast.error(error.message);
							toast.success("That fulfilment was undone; the items are back in stock.");
							qc.invalidateQueries({ queryKey: ["sale", id] });
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 rounded-2xl border bg-card p-4 sm:p-6 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Customer",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomerPicker, {
											customers: customers ?? [],
											value: order.customer_id,
											name: order.customer_name,
											onPick: pickCustomer,
											onAdd: async (name) => {
												const id = await addCustomer(name);
												await qc.invalidateQueries({ queryKey: ["customers"] });
												patch({
													customer_id: id,
													customer_name: name
												});
												toast.success(`${name} added. Fill in their details here, or later on their page.`);
											},
											disabled: locked
										})
									}),
									custChanges.length > 0 && !locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-900",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Changed here: ", custChanges.map(([, label]) => label).join(", ")] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											className: "h-7",
											onClick: () => void saveToCustomer(),
											children: "Save changes to the customer"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Contact",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: order.contact_name ?? "",
											onChange: (e) => patch({ contact_name: e.target.value || null })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Phone",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: order.phone ?? "",
												onChange: (e) => patch({ phone: e.target.value || null })
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Email",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "email",
												value: order.email ?? "",
												onChange: (e) => patch({ email: e.target.value || null })
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Billing address",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 3,
											value: order.billing_address ?? "",
											onChange: (e) => patch({ billing_address: e.target.value || null })
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Terms",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
											value: order.payment_terms_id ?? "none",
											disabled: locked,
											options: [{
												value: "none",
												label: "Not set"
											}, ...(terms ?? []).filter((x) => x.is_active || x.id === order.payment_terms_id).map((x) => ({
												value: x.id,
												label: x.name
											}))],
											addLabel: "Add new terms",
											onAdd: async (name) => {
												const id = await addTerms(name);
												await qc.invalidateQueries({ queryKey: ["payment_terms"] });
												return id;
											},
											onChange: (v) => {
												const days = qc.getQueryData(["payment_terms"])?.find((x) => x.id === v)?.days_due;
												const base = order.invoice_date ?? order.order_date;
												patch({
													payment_terms_id: v === "none" ? null : v,
													...days != null && !isQuoteLike(status) ? { due_date: new Date(new Date(base).getTime() + days * 864e5).toISOString() } : {}
												});
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Project name",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: order.project_name ?? "",
											placeholder: "e.g. Hearst Elementary gym screen",
											onChange: (e) => patch({ project_name: e.target.value || null })
										})
									}),
									!isQuoteLike(status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Customer's P.O. #",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: order.po_number ?? "",
											onChange: (e) => patch({ po_number: e.target.value || null })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Sales rep",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
												value: order.sales_rep ?? "none",
												disabled: locked,
												options: [{
													value: "none",
													label: "No sales rep"
												}, ...[.../* @__PURE__ */ new Set([
													DEFAULT_REP,
													...reps ?? [],
													...order.sales_rep ? [order.sales_rep] : []
												])].sort().map((r) => ({
													value: r,
													label: r
												}))],
												addLabel: "Add new sales rep",
												onAdd: async (name) => name,
												onChange: (v) => patch({ sales_rep: v === "none" ? null : v })
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Location",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchSelect, {
												value: order.location_id ?? "none",
												disabled: locked,
												options: [{
													value: "none",
													label: "Not set"
												}, ...(locations ?? []).filter((l) => l.is_active || l.id === order.location_id).map((l) => ({
													value: l.id,
													label: l.name
												}))],
												addLabel: "Add new location",
												onAdd: async (name) => {
													const id = await addLocation(name);
													await qc.invalidateQueries({ queryKey: ["locations"] });
													return id;
												},
												onChange: (v) => patch({ location_id: v === "none" ? null : v })
											})
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Paid (note)",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: order.custom?.["Paid"] ?? "",
											placeholder: "e.g. check #, deposit amount",
											onChange: (e) => {
												const c = { ...order.custom ?? {} };
												if (e.target.value) c["Paid"] = e.target.value;
												else delete c["Paid"];
												patch({ custom: c });
											}
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											"Pricing: ",
											customer?.price_list_id ? "customer price list" : "Normal price",
											customer?.discount ? ` · ${Number(customer.discount)}% discount` : ""
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3 rounded-xl bg-muted/40 p-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: status === "quote" ? "Quote #" : isRmaDoc(order) ? "RMA #" : "Order #",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: order.number ?? "(given when saved)",
												disabled: true
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: status === "quote" ? "Quote date" : isRmaDoc(order) ? "RMA date" : "Order date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: order.order_date.slice(0, 10),
												onChange: (e) => patch({ order_date: (/* @__PURE__ */ new Date(e.target.value + "T12:00:00")).toISOString() })
											})
										}),
										!isQuoteLike(status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Due date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: (order.due_date ?? "").slice(0, 10),
												onChange: (e) => patch({ due_date: e.target.value ? (/* @__PURE__ */ new Date(e.target.value + "T12:00:00")).toISOString() : null })
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Req. ship date",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "date",
												value: order.ship_by ?? "",
												onChange: (e) => patch({ ship_by: e.target.value || null })
											})
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Shipping address" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "text-xs text-primary underline",
											onClick: () => patch({ shipping_address: order.billing_address }),
											children: "Same as billing"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										rows: 3,
										value: order.shipping_address ?? "",
										onChange: (e) => patch({ shipping_address: e.target.value || null })
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl border bg-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden grid-cols-[minmax(0,1fr)_90px_120px_90px_70px_110px_40px] gap-2 border-b bg-muted/40 px-4 py-2 text-xs font-semibold text-muted-foreground md:grid",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Item" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Qty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Price"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Disc. %"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-center",
										children: "Tax"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-right",
										children: "Total"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
								]
							}),
							lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 border-b px-4 py-3 md:grid-cols-[minmax(0,1fr)_90px_120px_90px_70px_110px_40px] md:items-start",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2 space-y-1.5 md:col-span-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductPicker, {
											products: products ?? [],
											value: l.product_id,
											onPick: (pid, fresh) => pickProduct(i, pid, fresh),
											disabled: locked
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											rows: 1,
											className: "min-h-9 text-sm",
											placeholder: "Description",
											value: l.description ?? "",
											onChange: (e) => patchLine(i, { description: e.target.value })
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabeledNum, {
											label: "Qty",
											value: l.qty,
											onChange: (v) => patchLine(i, { qty: v })
										}),
										!isNew && !isQuoteLike(status) && stockedIds.has(l.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FulfilMark, {
											qty: Number(l.qty),
											out: Number(l.qty_fulfilled ?? 0),
											ticked: ticked.includes(l.id),
											canTick: canFulfil,
											onToggle: () => setTicked((t) => t.includes(l.id) ? t.filter((x) => x !== l.id) : [...t, l.id])
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnHand, {
											product: products?.find((p) => p.id === l.product_id),
											qty: Number(l.qty),
											taken: !!order.stock_taken_at
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabeledNum, {
										label: "Price",
										value: l.unit_price,
										onChange: (v) => patchLine(i, { unit_price: v })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabeledNum, {
										label: "Disc. %",
										value: l.discount,
										onChange: (v) => patchLine(i, {
											discount: v,
											discount_is_percent: true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 text-sm md:justify-center md:pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
											checked: l.taxable,
											onCheckedChange: (v) => patchLine(i, { taxable: v === true })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "md:hidden",
											children: "Taxable"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "self-center text-right font-semibold md:pt-2",
										children: fmtMoney(lineTotal(l))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": "Remove line",
										onClick: () => {
											if (!l._new) setRemoved((r) => [...r, l.id]);
											setLines((ls) => ls.filter((_, j) => j !== i));
											setDirty(true);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									})
								]
							}, l.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										size: "sm",
										disabled: locked,
										onClick: () => {
											setLines((ls) => [...ls, newLine(ls.length + 1)]);
											setDirty(true);
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add line"]
									}),
									" ",
									!locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanAddButton, {
										onProduct: (p) => void scanned(p),
										hint: "Scan each item. Each scan adds one."
									}),
									canFulfil && stockedLines.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "float-right flex flex-wrap gap-2",
										children: [ticked.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setDialog("stock-some"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageMinus, { className: "h-4 w-4" }),
												" Fulfill the ",
												ticked.length,
												" ticked"
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											onClick: () => setDialog("stock"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageMinus, { className: "h-4 w-4" }),
												" ",
												someOut ? "Fulfill the rest" : "Fulfill all"
											]
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 rounded-2xl border bg-card p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Notes for the customer (printed)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									rows: 4,
									value: order.remarks ?? "",
									onChange: (e) => patch({ remarks: e.target.value || null })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterPicker, {
								footers: footers ?? [],
								doc: order,
								onChange: patch,
								disabled: locked
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 rounded-2xl border bg-card p-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Subtotal",
									value: fmtMoney(t.subtotal)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: taxes?.find((x) => x.name === order.tax_name && Number(x.rate) === Number(order.tax_rate))?.id ?? "custom",
										onValueChange: (v) => {
											if (v === "edit-list") return void navigate({
												to: "/settings",
												hash: "sales-tax"
											});
											const x = taxes?.find((y) => y.id === v);
											if (x) patch({
												tax_name: x.name,
												tax_rate: Number(x.rate)
											});
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 w-auto max-w-[220px]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: order.tax_name ?? "Sales tax" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "custom",
												disabled: true,
												children: order.tax_name ?? "Sales tax"
											}),
											(taxes ?? []).filter((x) => x.is_active).map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
												value: x.id,
												children: [
													x.name,
													" (",
													Number(x.rate),
													"%)"
												]
											}, x.id)),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
												value: "edit-list",
												className: "text-[var(--section)]",
												children: "Add or change sales taxes (Settings → Company)"
											})
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												className: "h-8 w-20 text-right",
												inputMode: "decimal",
												value: order.tax_rate,
												onChange: (e) => patch({ tax_rate: Number(e.target.value) || 0 })
											}),
											"%",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "w-24 text-right",
												children: fmtMoney(t.tax)
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Shipping / freight" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "h-8 w-28 text-right",
										inputMode: "decimal",
										value: order.shipping,
										onChange: (e) => patch({ shipping: Number(e.target.value) || 0 })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border-t pt-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
										label: "Total",
										value: fmtMoney(t.total),
										big: true
									})
								}),
								Number(order.amount_paid) !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Paid",
									value: `– ${fmtMoney(order.amount_paid)}`
								}),
								!isQuoteLike(status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Balance due",
									value: fmtMoney(t.total - Number(order.amount_paid || 0)),
									big: true
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							onClick: () => void save().then((ok) => ok && toast.success("Saved.")),
							disabled: busy || locked,
							children: busy ? "Saving…" : dirty || isNew ? "Save" : "Saved"
						})
					}),
					payments.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-2xl border bg-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-b px-4 py-2 text-sm font-semibold",
							children: "Payments"
						}), payments.sort((a, b) => a.paid_on.localeCompare(b.paid_on)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-28",
									children: fmtDate(p.paid_on)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 truncate text-muted-foreground",
									children: [
										p.method,
										p.reference,
										p.remarks
									].filter(Boolean).join(" · ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: fmtMoney(p.amount)
								}),
								isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Remove payment",
									onClick: async () => {
										const { error } = await db.from("payments").delete().eq("id", p.id);
										if (error) toast.error(error.message);
										else {
											toast.success("Payment removed.");
											qc.invalidateQueries({ queryKey: ["sale", id] });
										}
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
								})
							]
						}, p.id))]
					})
				] })
			})
		}),
		!isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintDoc, {
			order: {
				...order,
				...t
			},
			lines,
			company,
			payments,
			terms: terms?.find((x) => x.id === order.payment_terms_id)?.name
		}),
		dialog === "po" && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreatePoDialog, {
			order: {
				id: order.id,
				number: order.number ?? "",
				customer_name: order.customer_name
			},
			lines,
			onClose: () => setDialog(null)
		}),
		dialog === "email" && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailDocDialog, {
			doc: (o) => salesPdf({
				...order,
				...t
			}, lines, company, logo ? new URL(logo, window.location.href).href : "", terms?.find((x) => x.id === order.payment_terms_id)?.name, payments, o),
			deposit: isRmaDoc(order) || status === "cancelled" || t.total - Number(order.amount_paid || 0) <= 0 ? void 0 : {
				percent: Number(terms?.find((x) => x.id === order.payment_terms_id)?.name.match(/(\d+)\s*%/)?.[1] ?? 50),
				of: t.total,
				label: `the total ${fmtMoney(t.total)}`
			},
			payNow: !isNew && order.id && !isRmaDoc(order) && !isQuoteLike(status) && status !== "cancelled" && t.total - Number(order.amount_paid || 0) > 0 ? { invoiceId: order.id } : void 0,
			filename: `${order.number ?? "document"}.pdf`,
			to: order.email ?? "",
			myEmail: myEmail || void 0,
			subject: followupMode === "pay" ? `Payment reminder: invoice ${order.number ?? ""} from ${company?.name ?? ""}` : followupMode ? `Following up: quote ${order.number ?? ""} from ${company?.name ?? ""}` : `${isRmaDoc(order) ? "RMA" : docName(status)} ${order.number ?? ""} from ${company?.name ?? ""}`,
			message: followupMode === "pay" ? paymentFollowupMessage({
				number: order.number ?? "",
				contact_name: order.contact_name,
				customer_name: order.customer_name
			}, company?.name ?? "", fmtMoney(t.total > 0 ? t.total - Number(order.amount_paid || 0) : Number(order.balance)), order.due_date ? fmtDate(order.due_date) : null, Number(order.followup_count ?? 0) >= 1) : followupMode ? followupMessage({
				number: order.number ?? "",
				contact_name: order.contact_name,
				customer_name: order.customer_name
			}, company?.name ?? "", Number(order.followup_count ?? 0) >= 1) : `Hello ${order.contact_name || order.customer_name || ""},\n\nPlease find attached our ${(isRmaDoc(order) ? "RMA" : docName(status)).toLowerCase()} ${order.number ?? ""} for ${fmtMoney(t.total)}.${order.attach_text ? "\nOur Terms & Conditions are on the last page." : ""}${!isQuoteLike(status) && !isRmaDoc(order) && t.total - Number(order.amount_paid || 0) > 0 ? "\n\nYour prompt payment is appreciated." : ""}\n\nThank you,\n${company?.name ?? ""}`,
			onClose: () => {
				setDialog(null);
				setFollowupMode(false);
			},
			onSent: (sentTo) => {
				const first = sentTo.split(/[,;]/)[0]?.trim() ?? "";
				if (first && order.id && first !== order.email) {
					patch({ email: first });
					db.from("sales_orders").update({ email: first }).eq("id", order.id);
					if (customer && !customer.email) db.from("customers").update({ email: first }).eq("id", customer.id).then(() => qc.invalidateQueries({ queryKey: ["customers"] }));
				}
				if (followupMode === "pay" && order.id) db.from("sales_orders").update({
					followup_count: Number(order.followup_count ?? 0) + 1,
					last_followup_at: (/* @__PURE__ */ new Date()).toISOString()
				}).eq("id", order.id).then(() => qc.invalidateQueries({ queryKey: ["sale", id] }));
				if (status === "quote" && order.id) {
					if (followupMode || Number(order.followup_count ?? 0) > 0 || order.order_date < (/* @__PURE__ */ new Date(Date.now() - 6048e5)).toISOString()) db.from("sales_orders").update({
						followup_count: Number(order.followup_count ?? 0) + 1,
						last_followup_at: (/* @__PURE__ */ new Date()).toISOString()
					}).eq("id", order.id).then(() => qc.invalidateQueries({ queryKey: ["sale", id] }));
				}
				setFollowupMode(false);
				const tid = ticketId(order.custom?.["Ticket"]);
				if (tid) markTicket({ data: {
					id: tid,
					action: "invoiced",
					invoice: order.number ?? "",
					amount: t.total
				} }).catch(() => toast.error("Sent, but the website ticket wasn't updated."));
			}
		}),
		dialog === "payment" && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentDialog, {
			orderId: order.id,
			balance: t.total - Number(order.amount_paid || 0),
			onClose: () => setDialog(null),
			onSaved: async () => {
				await qc.invalidateQueries({ queryKey: ["sale", id] });
				const tid = ticketId(order.custom?.["Ticket"]);
				if (!tid || !order.id) return;
				const { data: fresh } = await db.from("sales_orders").select("balance,total").eq("id", order.id).single();
				const f = fresh;
				if (f && Number(f.balance) <= .005) await markTicket({ data: {
					id: tid,
					action: "paid",
					invoice: order.number ?? "",
					amount: Number(f.total)
				} }).then(() => toast.success("Website ticket marked paid.")).catch(() => toast.error("Payment saved, but the website ticket wasn't updated."));
			}
		}),
		(dialog === "stock" || dialog === "stock-some") && order.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TakeStockDialog, {
			some: dialog === "stock-some",
			preset: ticked,
			lines: stockedLines,
			orderId: order.id,
			defaultLocation: order.location_id,
			beforeTake: async () => dirty ? !!await save() : true,
			onClose: () => setDialog(null),
			onDone: () => {
				setTicked([]);
				qc.invalidateQueries({ queryKey: ["sale", id] });
				qc.invalidateQueries({ queryKey: ["products"] });
			}
		})
	] });
}
function Row({ label, value, big }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex justify-between ${big ? "font-display text-lg font-bold" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value })]
	});
}
function LabeledNum({ label, value, onChange }) {
	const [s, setS] = (0, import_react.useState)(String(value ?? ""));
	(0, import_react.useEffect)(() => {
		if (Number(s) !== Number(value)) setS(String(value ?? ""));
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground md:hidden",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "h-9 text-right",
			inputMode: "decimal",
			value: s,
			onChange: (e) => {
				setS(e.target.value);
				const n = Number(e.target.value);
				if (Number.isFinite(n)) onChange(n);
			}
		})]
	});
}
function CustomerPicker({ customers, value, name, onPick, onAdd, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [typed, setTyped] = (0, import_react.useState)("");
	const [newName, setNewName] = (0, import_react.useState)("");
	const [adding, setAdding] = (0, import_react.useState)(false);
	async function add() {
		const n = (newName || typed).trim();
		if (!n || !onAdd) return;
		setAdding(true);
		try {
			await onAdd(n);
			setOpen(false);
			setTyped("");
			setNewName("");
		} catch (e) {
			toast.error(e.message);
		} finally {
			setAdding(false);
		}
	}
	const active = customers.filter((c) => c.is_active || c.id === value).sort((a, b) => a.name.localeCompare(b.name));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "w-full justify-between font-normal",
				disabled,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: name || "Choose a customer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[--radix-popover-trigger-width] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
					placeholder: "Type a name, phone or email",
					value: typed,
					onValueChange: (v) => {
						setTyped(v);
						setNewName(v);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No customer found. Add it below." }), active.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
					value: `${c.name} ${c.id}`,
					keywords: [c.phone ?? "", c.email ?? ""],
					onSelect: () => {
						onPick(c.id);
						setOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: `h-4 w-4 ${c.id === value ? "opacity-100" : "opacity-0"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: c.name
					})]
				}, c.id))] }),
				onAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 border-t p-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs font-semibold text-muted-foreground",
							children: "Add new customer:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "h-8",
							placeholder: "Name",
							value: newName,
							onChange: (e) => setNewName(e.target.value),
							onKeyDown: (e) => {
								e.stopPropagation();
								if (e.key === "Enter") {
									e.preventDefault();
									add();
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							disabled: adding || !(newName || typed).trim(),
							onClick: () => void add(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add"]
						})
					]
				})
			] })
		})]
	});
}
function ProductPicker({ products, value, onPick, disabled }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [adding, setAdding] = (0, import_react.useState)(null);
	const current = products.find((p) => p.id === value);
	const sorted = (0, import_react.useMemo)(() => [...products].filter((p) => p.is_active !== false || p.id === value).sort((a, b) => a.name.localeCompare(b.name, void 0, { numeric: true })), [products, value]);
	const onHand = (p) => (p.stock ?? []).reduce((s, r) => s + Number(r.qty), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "w-full justify-between font-normal",
				disabled,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: current?.name ?? "Choose a product (or just type a description)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUpDown, { className: "h-4 w-4 opacity-50" })]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverContent, {
			className: "w-[min(560px,92vw)] p-0",
			align: "start",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Command$1, {
				shouldFilter: false,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandInput, {
						placeholder: "Type to search products",
						value: q,
						onValueChange: setQ
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandEmpty, { children: "No product found." }), smartSearch(sorted, q, (p) => p.name, (p) => p.description ?? "").slice(0, 200).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CommandItem, {
						value: `${p.name} ${p.description ?? ""} ${p.id}`,
						onSelect: () => {
							onPick(p.id);
							setOpen(false);
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate",
									children: p.name
								}), p.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: p.description
								})]
							}),
							p.item_type === "stocked" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `w-16 text-right text-xs ${onHand(p) <= 0 ? "text-destructive" : "text-muted-foreground"}`,
								children: [fmtQty(onHand(p)), " in stock"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-20 text-right text-xs text-muted-foreground",
								children: fmtMoney(p.price)
							})
						]
					}, p.id))] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "w-full justify-start",
							onClick: () => {
								setAdding(q.trim());
								setOpen(false);
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }),
								" Add new product",
								q.trim() ? ` “${q.trim()}”` : ""
							]
						})
					})
				]
			})
		})]
	}), adding != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewProductDialog, {
		name: adding,
		onClose: () => setAdding(null),
		onCreated: (p) => {
			setAdding(null);
			onPick(p.id, {
				...p,
				stock: []
			});
		}
	})] });
}
function PaymentDialog({ orderId, balance, onClose, onSaved }) {
	const [amount, setAmount] = (0, import_react.useState)(balance > 0 ? balance.toFixed(2) : "");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toLocaleDateString("en-CA"));
	const [method, setMethod] = (0, import_react.useState)("");
	const [ref, setRef] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [accountId, setAccountId] = (0, import_react.useState)("");
	async function save() {
		const n = Number(amount);
		if (!n) {
			toast.error("Type the amount.");
			return;
		}
		setBusy(true);
		const { data: u } = await db.auth.getUser();
		const { error } = await db.from("payments").insert({
			sales_order_id: orderId,
			amount: n,
			paid_on: (/* @__PURE__ */ new Date(date + "T12:00:00")).toISOString(),
			method: method || null,
			reference: ref || null,
			...accountId ? { account_id: accountId } : {},
			created_by: u.user?.id
		});
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Payment recorded.");
		onSaved();
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record payment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				"Still owed: ",
				fmtMoney(balance),
				". Use a minus amount for a refund."
			] })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount ($)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							inputMode: "decimal",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							autoFocus: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Date paid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "How they paid" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								list: "pay-methods",
								value: method,
								onChange: (e) => setMethod(e.target.value),
								placeholder: "Check, card, wire…"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "pay-methods",
								children: [
									"Check",
									"Credit card",
									"Wire transfer",
									"ACH",
									"Cash",
									"Zelle"
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: m }, m))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check # or reference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoneyAccountPick, {
						label: "Deposit to",
						value: accountId,
						onChange: setAccountId
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				disabled: busy,
				children: busy ? "Saving…" : "Save payment"
			})] })
		] })
	});
}
function TakeStockDialog({ some, preset, lines, orderId, defaultLocation, beforeTake, onClose, onDone }) {
	const { data: locations } = useLocations();
	const [loc, setLoc] = (0, import_react.useState)(defaultLocation ?? "any");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const left = (l) => Math.max(Number(l.qty) - Number(l.qty_fulfilled ?? 0), 0);
	const open = lines.filter((l) => left(l) > 0);
	const [pick, setPick] = (0, import_react.useState)(() => Object.fromEntries(open.map((l) => [l.id, {
		on: !preset?.length || preset.includes(l.id),
		qty: String(left(l))
	}])));
	const busyRef = (0, import_react.useRef)(false);
	async function take() {
		if (busyRef.current) return;
		busyRef.current = true;
		setBusy(true);
		try {
			if (!await beforeTake()) return;
			const chosen = open.filter((l) => pick[l.id]?.on && Number(pick[l.id]?.qty) > 0).map((l) => ({
				line: l.id,
				qty: Math.min(Number(pick[l.id].qty), left(l))
			}));
			if (some && !chosen.length) return void toast.error("Tick at least one line and how many.");
			const { error } = await db.rpc("fulfil_order_lines", {
				_order_id: orderId,
				_location_id: loc === "any" ? null : loc,
				_lines: some ? chosen : null
			});
			if (error) if (!some && /could not find the function/i.test(error.message)) {
				const r = await db.rpc("take_order_stock", {
					_order_id: orderId,
					_location_id: loc === "any" ? null : loc
				});
				if (r.error) return void toast.error(r.error.message);
			} else return void toast.error(error.message);
			toast.success(some ? "Those items were taken out of stock." : "Fulfilled: items taken out of stock.");
			onDone();
			onClose();
		} finally {
			busyRef.current = false;
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (v) => !v && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: some ? "max-w-2xl" : void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: some ? "Fulfill some" : "Fulfill all" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					some ? "Tick what went out now and how many. The rest stays on the invoice to fulfill later." : "Everything still to go is taken out of stock",
					" ",
					"— from the place you choose first, then from anywhere else it is. If there isn't enough, the count goes below zero and shows in red so someone can check it. You can undo this."
				] })] }),
				some && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[50vh] divide-y overflow-auto rounded-xl border",
					children: open.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-3 p-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: !!pick[l.id]?.on,
								onCheckedChange: (v) => setPick((p) => ({
									...p,
									[l.id]: {
										...p[l.id],
										on: v === true
									}
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate",
								children: shortName(l)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "whitespace-nowrap text-xs text-muted-foreground",
								children: [
									fmtQty(Number(l.qty_fulfilled ?? 0)),
									" of ",
									fmtQty(Number(l.qty)),
									" out"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "h-8 w-20 text-right",
								inputMode: "decimal",
								value: pick[l.id]?.qty ?? "",
								onChange: (e) => setPick((p) => ({
									...p,
									[l.id]: {
										on: true,
										qty: e.target.value
									}
								}))
							})
						]
					}, l.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: loc,
					onValueChange: setLoc,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Take items from…" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "any",
						children: "Wherever it's stocked (biggest shelf first)"
					}), (locations ?? []).filter((l) => l.is_active).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: l.id,
						children: l.name
					}, l.id))] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => void take(),
					disabled: busy,
					children: busy ? "Working…" : some ? "Fulfill these" : "Fulfill all"
				})] })
			]
		})
	});
}
/** A stocked line's fulfilment: an empty, half or full circle, and a tick for "goes out now". */
function FulfilMark({ qty, out, ticked, canTick, onToggle }) {
	const full = qty > 0 && out >= qty;
	const half = out > 0 && !full;
	const left = Math.max(qty - out, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled: !canTick || full,
		onClick: onToggle,
		title: full ? "All of it went out" : `${fmtQty(out)} of ${fmtQty(qty)} out. Tick to fulfill the ${fmtQty(left)} left.`,
		className: `mt-1 flex w-full items-center gap-1.5 rounded-md px-1 py-0.5 text-left text-[11px] ${ticked ? "bg-[var(--section)]/15" : "hover:bg-muted"} disabled:hover:bg-transparent`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `inline-block h-3.5 w-3.5 shrink-0 rounded-full border-2 ${full ? "border-emerald-600 bg-emerald-600" : half ? "border-amber-500" : "border-muted-foreground/50"} ${ticked ? "ring-2 ring-[var(--section)]" : ""}`,
			style: half ? { background: "linear-gradient(90deg, rgb(245 158 11) 50%, transparent 50%)" } : void 0
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: full ? "Out" : out > 0 ? `${fmtQty(out)} out` : ticked ? "Goes out" : "In stock"
		})]
	});
}
/** A line's short name: the item part of its description. */
function shortName(l) {
	const d = (l.description ?? "").split("\n")[0] ?? "";
	return (d.split(" — ")[0] ?? d).slice(0, 60) || "Item";
}
/** The paper version. Only shows when printing (or saving as PDF). */
function PrintDoc({ order, lines, company, payments, terms }) {
	const rma = isRmaDoc(order);
	const name = rma ? "RMA" : docName(order.status === "cancelled" ? "quote" : order.status);
	const footer = order.footer_id || order.footer_text ? order.footer_text : rma ? null : order.status === "quote" ? company?.quote_footer : company?.invoice_footer;
	const shown = lines.filter((l) => l.product_id || (l.description ?? "").trim());
	const logo = useCompanyLogo();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrintFrame, {
		pageFooter: order.page_footer_text,
		attach: order.attach_text,
		logo,
		company: company?.name ?? "",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					logo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo,
						alt: company?.name ?? "",
						className: "mb-2 h-14 object-contain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] font-bold uppercase tracking-wide text-gray-500",
						children: isQuoteLike(order.status) || order.status === "cancelled" ? "Mailing address" : "Mail payments to"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-bold",
						children: company?.name ?? ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-line",
						children: company?.mailing_address || company?.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: [
						company?.phone,
						company?.email,
						company?.website
					].filter(Boolean).join(" · ") })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-bold uppercase",
							style: { color: "#E30613" },
							children: name
						}),
						rma && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase",
							children: "Return Merchandise Authorization"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "No." }),
							" ",
							order.number
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Date" }),
							" ",
							fmtDate(isQuoteLike(order.status) || order.status === "open" ? order.order_date : order.invoice_date ?? order.order_date)
						] }),
						order.project_name && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Project" }),
							" ",
							order.project_name
						] }),
						order.po_number && !isQuoteLike(order.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Your PO" }),
							" ",
							order.po_number
						] }),
						terms && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Terms" }),
							" ",
							terms
						] }),
						order.sales_rep && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Sales rep" }),
							" ",
							order.sales_rep
						] }),
						order.due_date && !isQuoteLike(order.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Due" }),
							" ",
							fmtDate(order.due_date)
						] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 font-bold uppercase text-gray-500",
						children: "Bill to"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold",
						children: order.customer_name
					}),
					order.contact_name && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Attn: ", order.contact_name] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-line",
						children: order.billing_address
					}),
					(order.phone || order.email) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: [order.phone, order.email].filter(Boolean).join(" · ") })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 font-bold uppercase text-gray-500",
					children: "Ship to"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-line",
					children: order.shipping_address
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-6 w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b-2 border-black text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-1",
							children: "Item"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "whitespace-nowrap py-1 pl-5 text-right",
							children: "Qty"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "whitespace-nowrap py-1 pl-5 text-right",
							children: "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "whitespace-nowrap py-1 pl-5 text-right",
							children: "Disc."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "whitespace-nowrap py-1 pl-5 text-right",
							children: "Total"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: shown.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b align-top",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-pre-line py-1.5 pr-2",
							children: l.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap py-1.5 pl-5 text-right",
							children: fmtQty(l.qty)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap py-1.5 pl-5 text-right",
							children: fmtMoney(l.unit_price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap py-1.5 pl-5 text-right",
							children: Number(l.discount) ? `${Number(l.discount)}%` : ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap py-1.5 pl-5 text-right",
							children: fmtMoney(lineTotal(l))
						})
					]
				}, l.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex justify-between gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-[55%] whitespace-pre-line",
					children: order.remarks
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-64 space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Subtotal",
							value: fmtMoney(order.subtotal)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: `${order.tax_name || "Sales tax"} (${Number(order.tax_rate)}%)`,
							value: fmtMoney(order.tax)
						}),
						Number(order.shipping) !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Shipping",
							value: fmtMoney(order.shipping)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t border-black pt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Total",
								value: fmtMoney(order.total),
								big: true
							})
						}),
						!isQuoteLike(order.status) && [...payments].filter((p) => Number(p.amount) !== 0).sort((a, b) => a.paid_on.localeCompare(b.paid_on)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: `Paid ${fmtDate(p.paid_on)}`,
							value: `– ${fmtMoney(p.amount)}`
						}, p.id)),
						!isQuoteLike(order.status) && !rma && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							label: "Balance due",
							value: fmtMoney(Number(order.total) - Number(order.amount_paid || 0)),
							big: true
						})
					]
				})]
			}),
			footer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 whitespace-pre-line border-t pt-3 text-[11px] text-gray-600",
				children: footer
			})
		]
	});
}
/** Which saved-footer default applies to a document at this step. */
function footerKind(status) {
	if (status === "quote") return "quote";
	if (status === "rma") return "rma";
	if (status === "open") return "order";
	return "invoice";
}
/** Stock on hand for a line's product — red when this line would take it below zero. */
function OnHand({ product, qty, taken }) {
	if (!product || product.item_type !== "stocked") return null;
	const on = (product.stock ?? []).reduce((s, r) => s + Number(r.qty), 0);
	const short = on < 0 || !taken && on - qty < 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: `mt-0.5 text-right text-[11px] ${short ? "font-semibold text-destructive" : "text-muted-foreground"}`,
		children: [
			"On hand ",
			fmtQty(on),
			short && !taken && on >= 0 ? ` · short ${fmtQty(qty - on)}` : ""
		]
	});
}
/** Purchase orders made from this invoice with "Order from vendor". */
function OrderPos({ orderId }) {
	const { data } = useQuery({
		queryKey: ["po-for-order", orderId],
		queryFn: async () => {
			const { data, error } = await db.from("purchase_orders").select("id,number,vendor_name,status").eq("custom->>sales_order_id", orderId).order("number");
			if (error) return [];
			return data ?? [];
		}
	});
	if (!data?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex flex-wrap items-center gap-x-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4 text-muted-foreground" }),
			" Ordered from vendor:",
			data.map((po, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/po/$id",
					params: { id: po.id },
					search: {},
					className: "font-medium underline",
					children: po.number
				}),
				" ",
				"(",
				po.vendor_name,
				po.status === "cancelled" ? ", cancelled" : "",
				")",
				i < data.length - 1 ? "," : ""
			] }, po.id))
		]
	});
}
//#endregion
export { SalesPage as component };
