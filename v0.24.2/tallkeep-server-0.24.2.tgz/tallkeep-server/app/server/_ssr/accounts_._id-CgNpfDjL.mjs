import { _ as lazyRouteComponent, v as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/accounts_._id-CgNpfDjL.js
var $$splitComponentImporter = () => import("./accounts_._id-D6q2iFxQ.mjs");
var isDay = (v) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v);
var Route = createFileRoute("/_authenticated/accounts_/$id")({
	validateSearch: (s) => ({
		...isDay(s["from"]) ? { from: s["from"] } : {},
		...isDay(s["to"]) ? { to: s["to"] } : {}
	}),
	head: () => ({ meta: [{ title: "Account · Tallkeep" }, {
		name: "description",
		content: "Transactions in one account."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
