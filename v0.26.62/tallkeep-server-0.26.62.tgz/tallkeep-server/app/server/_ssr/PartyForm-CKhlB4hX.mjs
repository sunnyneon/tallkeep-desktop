import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { n as db } from "./db-GlmaMwxG.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { S as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-BRN_qfHO.mjs";
import { l as createServerFn } from "./createServerFn-BcsZ0Mqq.mjs";
import { t as createSsrRpc } from "./createSsrRpc-C25Jx3h9.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-DrfoQPFS.mjs";
import { g as Trash2 } from "../_libs/lucide-react.mjs";
import { c as usePaymentTerms, d as useTaxRates, l as usePriceLists } from "./queries-T3nveOhM.mjs";
import { n as HistoryButton } from "./ChangeHistory-swCtjZsW.mjs";
import { t as Input } from "./input-yuBoSuqY.mjs";
import { t as Label } from "./label-qSgNmrl1.mjs";
import { t as Textarea } from "./textarea-f_uazS_R.mjs";
import { t as Switch } from "./switch-Dkd0-FGF.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DVv8gY_9.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/PartyForm-CKhlB4hX.js
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react());
/** The account (customer) a person belongs to. */
/** People in an account. */
/** The account's Owner (database step 75); null when there is none or the step isn't run. */
/** Only admins may manage users, and only the people in their own account. With `owner`,
*  only the account's Owner (an account without one: any admin). */
/** Stop when the account is read-only or its plan has no room for another person. */
/** People who use a place on the plan: everyone except look-only people. A person counts when
*  they're an admin of every company, or can change things in at least one company. Someone
*  who can only look (an accountant) in every company they open is free. */
/** Stop when the plan has no room for one more person who can change things. `except`: the
*  person being changed (they're about to start using a place). */
/** How many people use a place on the plan, and how many only look (free). */
var peopleCount = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d63080d088483e61bf0325cd1ba77143436860f780840c391d64ddebba5be95d"));
/** Stop if this person isn't in the admin's account. */
var listUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d96fc76850779782acfe0d57c8df91435fcd2dbdbbe157b34f6d9842c0ffc4b6"));
var addUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (!/^\S+@\S+\.\S+$/.test(d.email)) throw new Error("Type a valid email.");
	if ((d.password ?? "").length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(createSsrRpc("57ddaa5e4421dbf7df4d9f414643f1bb27a4c291bf5708d6c31cd31cadffedf0"));
var changeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => {
	if (d.password != null && d.password.length < 8) throw new Error("The password needs at least 8 characters.");
	return d;
}).handler(createSsrRpc("bf7e244e8d039b3b242642889b54fe2c274ff956811728d8b7818fd4aa2b3bd6"));
/** Open a company for someone (or not), as its admin, all sections or some sections. */
var setCompanyAccess = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("3428c6d6ad7cd8fa7491ab7411d6d8472cd18aba914aa7ac7fd3b8eec2fb01e4"));
var removeUser = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("9361df1a94e7b3318a7f52ef7419757434e15b7dead8b1cb6636b5adf3d5a46d"));
/** The Owner hands the role to another admin in the account. */
var handOverOwner = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => d).handler(createSsrRpc("b87d33d66f88c754a25edb36b521a4273fbe7196266c87d0ade8aaec6f498df0"));
/** Names for the Sales rep menu: everyone who can sign in (staff may call this). */
var listRepNames = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("64019a9e45f7e8b0375e3d14f1984dc6e6493f506a342471c10221dced5b5d46"));
function Field({ label, wide, children }) {
	const autoId = (0, import_react.useId)();
	const only = import_react.Children.count(children) === 1 && (0, import_react.isValidElement)(children) ? children : null;
	const props = only?.props ?? {};
	const plain = !!only && (typeof only.type === "string" ? [
		"input",
		"textarea",
		"select"
	].includes(only.type) : only.type === Input || only.type === Textarea);
	const id = props.id ?? autoId;
	const child = only && plain ? (0, import_react.cloneElement)(only, {
		id,
		"aria-label": props["aria-label"] ?? label
	}) : children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: wide ? "space-y-1.5 sm:col-span-2" : "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: only && plain ? id : void 0,
			children: label
		}), child]
	});
}
function Pick({ value, onChange, options, none }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
		value: value ?? "none",
		onValueChange: (v) => onChange(v === "none" ? null : v),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: "none",
			children: none
		}), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
			value: o.id,
			children: o.name
		}, o.id))] })]
	});
}
/** Edit form for a customer or vendor. */
function PartyForm({ kind, record }) {
	const qc = useQueryClient();
	const isCust = kind === "customers";
	const { data: terms } = usePaymentTerms();
	const { data: taxes } = useTaxRates();
	const { data: lists } = usePriceLists();
	const { data: reps } = useQuery({
		queryKey: ["rep-names"],
		staleTime: 6e5,
		enabled: isCust,
		queryFn: () => listRepNames()
	});
	const [f, setF] = (0, import_react.useState)(record);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setF(record), [record]);
	const set = (k, v) => setF((x) => ({
		...x,
		[k]: v
	}));
	const navigate = useNavigate();
	async function remove() {
		const who = isCust ? "customer" : "vendor";
		const id = String(record["id"]);
		const n = (k, one, many) => k ? `${k} ${k === 1 ? one : many}` : "";
		let parts = [];
		if (isCust) {
			const { data: so } = await db.from("sales_orders").select("status,number").eq("customer_id", id);
			const rows = so ?? [];
			const rma = rows.filter((r) => r.status === "rma" || r.number.startsWith("RMA-")).length;
			const quotes = rows.filter((r) => r.status === "quote").length;
			const orders = rows.filter((r) => r.status === "open").length;
			parts = [
				n(rows.length - rma - quotes - orders, "invoice", "invoices"),
				n(orders, "order", "orders"),
				n(quotes, "quote", "quotes"),
				n(rma, "RMA", "RMAs")
			];
		} else {
			const [po, bl] = await Promise.all([db.from("purchase_orders").select("id", {
				count: "exact",
				head: true
			}).eq("vendor_id", id), db.from("bills").select("id", {
				count: "exact",
				head: true
			}).eq("vendor_id", id)]);
			parts = [n(po.count ?? 0, "purchase order", "purchase orders"), n(bl.count ?? 0, "bill", "bills")];
		}
		parts = parts.filter(Boolean);
		const docs = parts.length;
		const list = parts.length <= 1 ? parts[0] ?? "" : `${parts.slice(0, -1).join(", ")} and ${parts.at(-1)}`;
		if (docs > 0) {
			toast.error(`${String(record["name"] ?? `This ${who}`)} has ${list}, so it can't be deleted. Hide it instead: it leaves your lists and keeps its history.`, {
				duration: 12e3,
				action: {
					label: `Hide this ${who}`,
					onClick: () => void db.from(kind).update({ is_active: false }).eq("id", id).then(({ error }) => {
						if (error) return void toast.error(error.message);
						set("is_active", false);
						toast.success(`Hidden. Tick Active to bring it back.`);
						qc.invalidateQueries({ queryKey: [kind] });
					})
				}
			});
			return;
		}
		if (!window.confirm(`Delete ${String(record["name"] ?? `this ${who}`)}? It has no documents. This can't be undone.`)) return;
		setBusy(true);
		const { error } = await db.from(kind).delete().eq("id", String(record["id"]));
		setBusy(false);
		if (error) {
			toast.error(/foreign key|violates/i.test(error.message) ? `This ${who} has ${isCust ? "quotes, invoices or payments" : "purchase orders, bills or payments"}, so it can't be deleted. Untick Active to hide it instead.` : error.message, { duration: 1e4 });
			return;
		}
		toast.success(`${isCust ? "Customer" : "Vendor"} deleted.`);
		qc.invalidateQueries({ queryKey: [kind] });
		navigate({ to: isCust ? "/customers" : "/vendors" });
	}
	const text = (k) => ({
		value: f[k] ?? "",
		onChange: (e) => set(k, e.target.value || null)
	});
	async function save(e) {
		e.preventDefault();
		if (!String(f["name"] ?? "").trim()) {
			toast.error("Name can't be empty.");
			return;
		}
		const fields = [
			"name",
			"contact_name",
			"phone",
			"fax",
			"email",
			"website",
			"address",
			"payment_terms_id",
			"remarks",
			"is_active"
		];
		if (isCust) fields.push("billing_address", "shipping_address", "price_list_id", "tax_rate_id", "discount", "sales_rep", "tax_exempt_number");
		const patch = {};
		fields.forEach((k) => patch[k] = f[k] ?? null);
		patch["name"] = String(f["name"]).trim();
		patch["is_active"] = f["is_active"] !== false;
		if (isCust) patch["discount"] = Number(f["discount"]) || 0;
		if (isCust && "no_reminders" in record && f["no_reminders"] !== record["no_reminders"]) patch["no_reminders"] = f["no_reminders"] === true;
		setBusy(true);
		const { error } = await db.from(kind).update(patch).eq("id", record["id"]);
		setBusy(false);
		if (error) {
			toast.error(error.message);
			return;
		}
		toast.success("Saved.");
		qc.invalidateQueries({ queryKey: [kind] });
		qc.invalidateQueries({ queryKey: [kind.slice(0, -1), record["id"]] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: save,
		className: "space-y-4 rounded-2xl border bg-card p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Contact person",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("contact_name") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "tel",
							...text("phone")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "email",
							...text("email")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Website",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("website") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fax",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("fax") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("address")
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bill to (if different)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("billing_address")
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ship to (if different)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							...text("shipping_address")
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Payment terms",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
							value: f["payment_terms_id"],
							onChange: (v) => set("payment_terms_id", v),
							options: terms ?? [],
							none: "Not set"
						})
					}),
					isCust && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Price list",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
								value: f["price_list_id"],
								onChange: (v) => set("price_list_id", v),
								options: lists ?? [],
								none: "Normal price"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Sales tax",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pick, {
								value: f["tax_rate_id"],
								onChange: (v) => set("tax_rate_id", v),
								options: (taxes ?? []).map((t) => ({
									id: t.id,
									name: `${t.name} (${Number(t.rate)}%)`
								})),
								none: "Not set"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Discount (%)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: f["discount"] ?? "",
								onChange: (e) => set("discount", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Sales rep",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								...text("sales_rep"),
								list: "party-rep-names",
								placeholder: "Fills in on this customer's quotes and invoices"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
							id: "party-rep-names",
							children: (reps ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: r }, r))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tax exempt / resale number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { ...text("tax_exempt_number") })
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						wide: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							...text("remarks")
						})
					})
				]
			}),
			Object.keys(f["custom"] ?? {}).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-muted/50 p-3 text-sm",
				children: Object.entries(f["custom"]).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [k, ":"]
					}),
					" ",
					v
				] }, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: f["is_active"] !== false,
								onCheckedChange: (v) => set("is_active", v)
							}),
							" ",
							"Active"
						]
					}),
					isCust && record && "no_reminders" in record && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						title: "Overdue reminders are turned on in Options → Apps",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: f["no_reminders"] !== true,
								onCheckedChange: (v) => set("no_reminders", !v)
							}),
							" ",
							"Send overdue reminders"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							record?.["id"] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryButton, { id: String(record["id"]) }),
							record?.["id"] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "ghost",
								disabled: busy,
								onClick: () => void remove(),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }),
									" Delete this ",
									isCust ? "customer" : "vendor"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								children: busy ? "Saving…" : isCust ? "Save customer" : "Save vendor"
							})
						]
					})
				]
			})
		]
	});
}
//#endregion
export { handOverOwner as a, peopleCount as c, changeUser as i, removeUser as l, PartyForm as n, listRepNames as o, addUser as r, listUsers as s, Field as t, setCompanyAccess as u };
