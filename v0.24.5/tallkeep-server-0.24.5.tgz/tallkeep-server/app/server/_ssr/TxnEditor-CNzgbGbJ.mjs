import { i as __toESM } from "../_runtime.mjs";
import { n as db } from "./db-C-LmScFU.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { m as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { r as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { i as accountLabel } from "./accounting-BZzWF9St.mjs";
import { r as fmtMoney } from "./format-CORJO1ov.mjs";
import { t as Button } from "./button-Bq5vK6RO.mjs";
import { g as Trash2 } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CwLzEEob.mjs";
import { t as OriginalLink } from "./OriginalLink-3V8CXI-D.mjs";
//#region ../../node_modules/.nitro/vite/services/ssr/assets/TxnEditor-CNzgbGbJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Change or delete one transaction right from a register: a deposit, a line added from the bank
* feed, or a typed-in entry. The date, who it's from or to, the amount and the category (the
* other side). Deleting a bank-feed line puts it back in Bank Feeds to be looked at again.
* A split payment (like a loan payment: interest, escrow, principal) can only be deleted here.
*/
var T = (t) => db.from(t);
var rpc = (f, a) => db.rpc(f, a);
/** The kinds of transaction this window can change. */
var EDITABLE = /* @__PURE__ */ new Set([
	"deposit",
	"bank",
	"manual",
	"opening",
	"adjust",
	"history"
]);
function TxnEditor({ entryId, accountId, accounts, onClose }) {
	const qc = useQueryClient();
	const [e, setE] = (0, import_react.useState)(null);
	const [depLine, setDepLine] = (0, import_react.useState)(null);
	const [f, setF] = (0, import_react.useState)({
		date: "",
		memo: "",
		amount: "",
		other: ""
	});
	const [anchor, setAnchor] = (0, import_react.useState)(accountId);
	const [dir, setDir] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data, error } = await T("journal_entries").select("id,entry_date,memo,source_type,source_id,journal_lines(id,account_id,debit,credit,memo)").eq("id", entryId).maybeSingle();
			if (error || !data) return void toast.error(error?.message ?? "Not found.");
			const en = data;
			setE(en);
			const isBank = (id) => {
				const k = accounts.find((a) => a.id === id)?.kind;
				return k === "bank" || k === "credit_card";
			};
			let side = accountId;
			if (!isBank(accountId)) {
				const b = en.journal_lines.find((l) => l.account_id !== accountId && isBank(l.account_id));
				if (b) side = b.account_id;
			}
			setAnchor(side);
			const mine = en.journal_lines.find((l) => l.account_id === side);
			const other = en.journal_lines.find((l) => l.account_id !== side);
			const amt = mine ? Math.abs(Number(mine.debit) - Number(mine.credit)) : 0;
			setDir(mine ? Number(mine.debit) > 0 : null);
			let memo = en.memo ?? "";
			if (en.source_type === "deposit" && en.source_id) {
				const { data: dl } = await T("deposit_lines").select("id,name").eq("deposit_id", en.source_id);
				if ((dl ?? []).length === 1) {
					setDepLine(dl[0]);
					memo = dl[0].name ?? memo;
				}
			}
			setF({
				date: en.entry_date,
				memo,
				amount: amt ? amt.toFixed(2) : "",
				other: other?.account_id ?? ""
			});
		})();
	}, [entryId, accountId]);
	const twoLines = !!e && e.journal_lines.length === 2;
	const canChange = !!e && (e.source_type === "deposit" ? !!depLine : twoLines && EDITABLE.has(e.source_type));
	const done = () => {
		qc.invalidateQueries();
		onClose();
	};
	async function save() {
		if (!e) return;
		const amount = Number(f.amount.replace(/[$,\s]/g, ""));
		if (!(amount > 0)) return void toast.error("Type the amount.");
		if (!f.other) return void toast.error("Pick the category.");
		setBusy(true);
		try {
			if (e.source_type === "deposit" && e.source_id && depLine) {
				const a = await T("deposits").update({ deposit_date: f.date }).eq("id", e.source_id);
				if (a.error) throw a.error;
				const b = await T("deposit_lines").update({
					amount,
					account_id: f.other,
					name: f.memo || null
				}).eq("id", depLine.id);
				if (b.error) throw b.error;
			} else {
				const mine = e.journal_lines.find((l) => l.account_id === anchor);
				const other = e.journal_lines.find((l) => l.id !== mine.id);
				const was = Number(mine.debit) > 0;
				const into = dir ?? was;
				const a = await T("journal_entries").update({
					entry_date: f.date,
					memo: f.memo || null
				}).eq("id", e.id);
				if (a.error) throw a.error;
				const b = await T("journal_lines").update({
					debit: into ? amount : 0,
					credit: into ? 0 : amount
				}).eq("id", mine.id);
				if (b.error) throw b.error;
				const c = await T("journal_lines").update({
					account_id: f.other,
					debit: into ? 0 : amount,
					credit: into ? amount : 0
				}).eq("id", other.id);
				if (c.error) throw c.error;
				if (into !== was && e.source_type === "bank") {
					const { data: bt } = await T("bank_transactions").select("id,amount").eq("source_id", e.id);
					for (const x of bt ?? []) await T("bank_transactions").update({ amount: -Number(x.amount) }).eq("id", x.id);
				}
			}
			toast.success("Saved.");
			done();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	async function remove() {
		if (!e) return;
		const fromBank = e.source_type === "bank";
		if (!window.confirm(fromBank ? "Delete this? The bank line goes back to Bank Feeds, to be recorded again." : "Delete this transaction?")) return;
		setBusy(true);
		try {
			if (e.source_type === "deposit" && e.source_id) {
				const r = await T("deposits").delete().eq("id", e.source_id);
				if (r.error) throw r.error;
			} else if (fromBank) {
				const { data: t } = await T("bank_transactions").select("id").eq("source_id", e.id);
				if ((t ?? []).length) for (const x of t) {
					const r = await rpc("undo_bank_transaction", { _txn: x.id });
					if (r.error) throw r.error;
				}
				else {
					const r = await T("journal_entries").delete().eq("id", e.id);
					if (r.error) throw r.error;
				}
			} else {
				const r = await T("journal_entries").delete().eq("id", e.id);
				if (r.error) throw r.error;
			}
			toast.success("Deleted.");
			done();
		} catch (err) {
			toast.error(err.message);
		} finally {
			setBusy(false);
		}
	}
	const cats = accounts.filter((a) => a.is_active && a.id !== anchor);
	const card = accounts.find((a) => a.id === anchor)?.type === "liability";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Change or delete" }), anchor !== accountId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"From ",
					accounts.find((a) => a.id === anchor)?.name ?? "the bank",
					": change the category to move it out of ",
					accounts.find((a) => a.id === accountId)?.name,
					"."
				]
			})] }), !e ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					canChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: f.date,
									onChange: (x) => setF({
										...f,
										date: x.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Amount"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									inputMode: "decimal",
									value: f.amount,
									onChange: (x) => setF({
										...f,
										amount: x.target.value
									})
								})]
							}),
							e.source_type !== "deposit" && dir !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1 text-sm sm:col-span-2",
								children: [[false, card ? "A charge (adds to what's owed)" : "Money out"], [true, card ? "A payment or refund (lowers what's owed)" : "Money in"]].map(([v, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setDir(v),
									className: `rounded-md border px-3 py-1 ${dir === v ? "border-primary bg-primary/10 font-medium" : "hover:bg-muted"}`,
									children: label
								}, String(v)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: e.source_type === "deposit" ? "From" : "Payee or memo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: f.memo,
									onChange: (x) => setF({
										...f,
										memo: x.target.value
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "space-y-1 text-sm sm:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted-foreground",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "h-9 w-full rounded-md border bg-background px-2 text-sm",
									value: f.other,
									onChange: (x) => setF({
										...f,
										other: x.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Pick one"
									}), cats.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: a.id,
										children: accountLabel(a)
									}, a.id))]
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"This one is split into ",
							e.journal_lines.length - 1,
							" parts, so it can only be deleted here."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "text-muted-foreground",
							children: e.journal_lines.filter((l) => l.account_id !== anchor).map((l) => {
								const a = accounts.find((x) => x.id === l.account_id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									a ? accountLabel(a) : "?",
									":",
									" ",
									fmtMoney(Math.abs(Number(l.debit) - Number(l.credit)))
								] }, l.id);
							})
						})]
					}),
					e.source_type === "deposit" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalLink, {
						type: "deposit",
						id: e.source_id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "ghost",
							className: "text-destructive",
							disabled: busy,
							onClick: () => void remove(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" }), " Delete"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: onClose,
								children: "Cancel"
							}), canChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								disabled: busy,
								onClick: () => void save(),
								children: busy ? "Saving…" : "Save"
							})]
						})]
					})
				]
			})]
		})
	});
}
//#endregion
export { TxnEditor as n, EDITABLE as t };
